import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Difficulty, GameMode, Note, Beat, RingEffect, ParticleEffect, JudgePopup, GameStats } from './types';
import { LANE_CONFIG, LEAD_IN, generateChart } from './data/charts';
import { sound } from './utils/audio';
import { StartScreen } from './components/StartScreen';
import { PauseScreen } from './components/PauseScreen';
import { ResultScreen } from './components/ResultScreen';
import { GameHud } from './components/GameHud';

export default function App() {
  // Game settings
  const [mode, setMode] = useState<GameMode>('start');
  const [selectedDiff, setSelectedDiff] = useState<Difficulty>('normal');
  const [selectedSpeed, setSelectedSpeed] = useState<number>(1);
  const [modBomb, setModBomb] = useState<boolean>(false);
  const [modStealth, setModStealth] = useState<boolean>(false);
  const [modFlip, setModFlip] = useState<boolean>(false);
  const [modSuddenDeath, setModSuddenDeath] = useState<boolean>(false);
  const [soundOn, setSoundOn] = useState<boolean>(true);

  // HUD & Stats state
  const [hudScore, setHudScore] = useState<number>(0);
  const [hudCombo, setHudCombo] = useState<number>(0);
  const [hudHp, setHudHp] = useState<number>(10);
  const [maxHp, setMaxHp] = useState<number>(10);
  const [isFever, setIsFever] = useState<boolean>(false);
  const [progress, setProgress] = useState<number>(0);
  const [isFlipped, setIsFlipped] = useState<boolean>(false);
  const [padActive, setPadActive] = useState<boolean[]>([false, false, false, false]);
  const [bestScore, setBestScore] = useState<number>(0);
  const [isNewBest, setIsNewBest] = useState<boolean>(false);
  const [resultStats, setResultStats] = useState<GameStats>({
    score: 0,
    combo: 0,
    maxCombo: 0,
    perfect: 0,
    good: 0,
    miss: 0,
    accuracy: 100,
    grade: 'S',
  });

  // Canvas and Stage references
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // High performance game state refs for RAF loop
  const modeRef = useRef<GameMode>('start');
  const notesRef = useRef<Note[]>([]);
  const beatsRef = useRef<Beat[]>([]);
  const songEndRef = useRef<number>(0);
  const songTimeRef = useRef<number>(0);
  const beatIdxRef = useRef<number>(0);
  const flipTimerRef = useRef<number>(0);
  const isFlippedRef = useRef<boolean>(false);

  const scoreRef = useRef<number>(0);
  const comboRef = useRef<number>(0);
  const maxComboRef = useRef<number>(0);
  const cPerfectRef = useRef<number>(0);
  const cGoodRef = useRef<number>(0);
  const cMissRef = useRef<number>(0);
  const hpRef = useRef<number>(10);
  const maxHpRef = useRef<number>(10);

  const laneGlowRef = useRef<number[]>([0, 0, 0, 0]);
  const padActiveRef = useRef<boolean[]>([false, false, false, false]);
  const ringsRef = useRef<RingEffect[]>([]);
  const particlesRef = useRef<ParticleEffect[]>([]);
  const judgeTextRef = useRef<JudgePopup | null>(null);
  const comboPopRef = useRef<number>(0);
  const shakeRef = useRef<number>(0);
  const bgPulseRef = useRef<number>(0);
  const scrollRef = useRef<number>(0);
  const lastTimeRef = useRef<number>(0);
  const reqIdRef = useRef<number>(0);

  // Hit windows (seconds)
  const PERFECT_W = 0.11;
  const GOOD_W = 0.22;
  const MISS_W = 0.26;

  // Load best score for current difficulty
  const loadBestScore = useCallback((diff: Difficulty) => {
    try {
      const v = window.localStorage.getItem(`lunchRhythmBest_${diff}`);
      const num = parseInt(v || '0', 10);
      return isNaN(num) ? 0 : num;
    } catch {
      return 0;
    }
  }, []);

  const saveBestScore = (diff: Difficulty, score: number) => {
    try {
      window.localStorage.setItem(`lunchRhythmBest_${diff}`, String(score));
    } catch {
      // ignore
    }
  };

  useEffect(() => {
    setBestScore(loadBestScore(selectedDiff));
  }, [selectedDiff, loadBestScore]);

  // Sync modeRef with mode
  useEffect(() => {
    modeRef.current = mode;
  }, [mode]);

  // End Game transition
  const endGame = useCallback(() => {
    setMode('result');
    modeRef.current = 'result';
    sound.victoryJingle();

    const perfect = cPerfectRef.current;
    const good = cGoodRef.current;
    const miss = cMissRef.current;
    const total = perfect + good + miss;
    const accuracy = total > 0 ? Math.round(((perfect + good * 0.5) / total) * 100) : 0;

    let grade = 'F';
    if (accuracy >= 98) grade = 'SS';
    else if (accuracy >= 90) grade = 'S';
    else if (accuracy >= 80) grade = 'A';
    else if (accuracy >= 70) grade = 'B';
    else if (accuracy >= 60) grade = 'C';

    const finalScore = scoreRef.current;
    const finalMaxCombo = maxComboRef.current;

    const prevBest = loadBestScore(selectedDiff);
    const newBestReached = finalScore > prevBest;
    if (newBestReached) {
      saveBestScore(selectedDiff, finalScore);
      setBestScore(finalScore);
    }
    setIsNewBest(newBestReached);

    setResultStats({
      score: finalScore,
      combo: comboRef.current,
      maxCombo: finalMaxCombo,
      perfect,
      good,
      miss,
      accuracy,
      grade,
    });
  }, [selectedDiff, loadBestScore]);

  // Pop Judgment text
  const popJudge = (text: string, color: string) => {
    judgeTextRef.current = { text, color, life: 0.6 };
  };

  // Add hit rings and particle sparks
  const addRing = (lane: number, color: string, isPerfect: boolean) => {
    ringsRef.current.push({
      lane,
      color,
      r: 20,
      maxR: isPerfect ? 60 : 42,
      life: 1,
    });
  };

  const addParticles = (lane: number, color: string, count: number, judgeY: number, W: number) => {
    const cx = (lane + 0.5) * (W / 4);
    for (let i = 0; i < count; i++) {
      const ang = Math.random() * Math.PI * 2;
      const spd = 40 + Math.random() * 130;
      particlesRef.current.push({
        x: cx,
        y: judgeY,
        vx: Math.cos(ang) * spd,
        vy: Math.sin(ang) * spd,
        color,
        size: 2 + Math.random() * 3.5,
        life: 0.5 + Math.random() * 0.4,
      });
    }
  };

  // Hit a lane by player input
  const hitLane = (lane: number) => {
    if (modeRef.current !== 'play') return;
    laneGlowRef.current[lane] = 1;

    const curTime = songTimeRef.current;
    let best: Note | null = null;
    let bestDist = 999;

    const notes = notesRef.current;
    for (let i = 0; i < notes.length; i++) {
      const n = notes[i];
      if (n.judged || n.lane !== lane) continue;
      const d = Math.abs(n.t - curTime);
      if (d < bestDist) {
        bestDist = d;
        best = n;
      }
    }

    if (!best || bestDist > GOOD_W) return;

    best.judged = true;
    const color = LANE_CONFIG[lane].color;
    const canvas = canvasRef.current;
    const W = canvas ? canvas.width / (window.devicePixelRatio || 1) : 320;
    const H = canvas ? canvas.height / (window.devicePixelRatio || 1) : 400;
    const judgeY = H - 56;

    // Bomb note hit penalty
    if (best.isBomb) {
      scoreRef.current = Math.max(0, scoreRef.current - 250);
      comboRef.current = 0;
      hpRef.current = Math.max(0, hpRef.current - 1);
      popJudge('BOOM! 💥', '#ff3333');
      shakeRef.current = 2.2;
      sound.bombExplode();

      setHudScore(scoreRef.current);
      setHudCombo(0);
      setHudHp(hpRef.current);
      setIsFever(false);

      if (hpRef.current <= 0) {
        endGame();
      }
      return;
    }

    const curCombo = comboRef.current;
    const feverMult = curCombo >= 20 ? 2 : 1;

    if (bestDist <= PERFECT_W) {
      cPerfectRef.current++;
      comboRef.current++;
      scoreRef.current += Math.round(100 * (1 + Math.min(comboRef.current, 50) / 50)) * feverMult;
      popJudge(feverMult > 1 ? 'FEVER PERFECT! 🔥' : 'PERFECT!', '#7ee8ff');
      addRing(lane, color, true);
      addParticles(lane, color, 12, judgeY, W);
      sound.hitPerfect(lane);
    } else {
      cGoodRef.current++;
      comboRef.current++;
      scoreRef.current += Math.round(50 * (1 + Math.min(comboRef.current, 50) / 100)) * feverMult;
      popJudge('GOOD', '#ffd23f');
      addRing(lane, color, false);
      addParticles(lane, color, 6, judgeY, W);
      sound.hitGood(lane);
    }

    if (comboRef.current > maxComboRef.current) {
      maxComboRef.current = comboRef.current;
    }

    comboPopRef.current = 1;
    setHudScore(scoreRef.current);
    setHudCombo(comboRef.current);
    setIsFever(comboRef.current >= 20);
  };

  const missNote = () => {
    cMissRef.current++;
    comboRef.current = 0;
    hpRef.current = Math.max(0, hpRef.current - 1);
    popJudge('MISS', '#ff7a9c');
    shakeRef.current = 1.2;
    sound.miss();

    setHudCombo(0);
    setHudHp(hpRef.current);
    setIsFever(false);

    if (hpRef.current <= 0) {
      endGame();
    }
  };

  // Pad visual states
  const setPadState = (lane: number, active: boolean) => {
    padActiveRef.current[lane] = active;
    setPadActive([...padActiveRef.current]);
  };

  // Start new game
  const startGame = () => {
    sound.init();
    const chart = generateChart(selectedDiff, selectedSpeed, modBomb);
    notesRef.current = chart.notes;
    beatsRef.current = chart.beats;
    songEndRef.current = chart.songEnd;

    songTimeRef.current = 0;
    beatIdxRef.current = 0;
    flipTimerRef.current = 0;
    isFlippedRef.current = false;
    setIsFlipped(false);

    scoreRef.current = 0;
    comboRef.current = 0;
    maxComboRef.current = 0;
    cPerfectRef.current = 0;
    cGoodRef.current = 0;
    cMissRef.current = 0;

    const initialHp = modSuddenDeath ? 3 : 10;
    hpRef.current = initialHp;
    maxHpRef.current = initialHp;
    setMaxHp(initialHp);
    setHudHp(initialHp);

    laneGlowRef.current = [0, 0, 0, 0];
    ringsRef.current = [];
    particlesRef.current = [];
    judgeTextRef.current = null;
    comboPopRef.current = 0;
    shakeRef.current = 0;
    bgPulseRef.current = 0;

    setHudScore(0);
    setHudCombo(0);
    setIsFever(false);
    setProgress(0);

    modeRef.current = 'play';
    setMode('play');
    sound.startFanfare();
  };

  // Canvas size and rendering loop
  const resizeCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const rect = container.getBoundingClientRect();
    const w = Math.max(160, rect.width);
    const h = Math.max(200, rect.height);
    const dpr = Math.min(window.devicePixelRatio || 1, 2);

    canvas.width = Math.round(w * dpr);
    canvas.height = Math.round(h * dpr);
  }, []);

  useEffect(() => {
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);
    return () => window.removeEventListener('resize', resizeCanvas);
  }, [resizeCanvas]);

  // Main animation frame loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    let animId: number;

    const loop = (now: number) => {
      if (!lastTimeRef.current) lastTimeRef.current = now;
      const dt = Math.min((now - lastTimeRef.current) / 1000, 0.1);
      lastTimeRef.current = now;

      // Update game dynamics
      scrollRef.current = (scrollRef.current + dt * 45) % 40;
      bgPulseRef.current = Math.max(0, bgPulseRef.current - dt * 3.5);
      comboPopRef.current = Math.max(0, comboPopRef.current - dt * 3.8);
      shakeRef.current = Math.max(0, shakeRef.current - dt * 4.5);

      for (let i = 0; i < 4; i++) {
        laneGlowRef.current[i] = Math.max(0, laneGlowRef.current[i] - dt * 4.5);
      }

      // Update rings
      const rings = ringsRef.current;
      for (let r = rings.length - 1; r >= 0; r--) {
        const ring = rings[r];
        ring.life -= dt * 3.2;
        ring.r += (ring.maxR - ring.r) * dt * 14;
        if (ring.life <= 0) rings.splice(r, 1);
      }

      // Update particles
      const parts = particlesRef.current;
      for (let p = parts.length - 1; p >= 0; p--) {
        const pt = parts[p];
        pt.life -= dt * 2.8;
        pt.x += pt.vx * dt;
        pt.y += pt.vy * dt;
        if (pt.life <= 0) parts.splice(p, 1);
      }

      // Update judge text
      if (judgeTextRef.current) {
        judgeTextRef.current.life -= dt;
        if (judgeTextRef.current.life <= 0) {
          judgeTextRef.current = null;
        }
      }

      // Update gameplay time & beats if in 'play' mode
      if (modeRef.current === 'play') {
        songTimeRef.current += dt;
        const curTime = songTimeRef.current;

        // Screen flip mechanic timer
        if (modFlip) {
          flipTimerRef.current += dt;
          if (flipTimerRef.current >= 4.0) {
            flipTimerRef.current = 0;
            isFlippedRef.current = !isFlippedRef.current;
            setIsFlipped(isFlippedRef.current);
          }
        }

        // Trigger beats audio
        const beats = beatsRef.current;
        let bIdx = beatIdxRef.current;
        while (bIdx < beats.length && curTime >= beats[bIdx].t) {
          if (beats[bIdx].strong) {
            sound.kick();
            bgPulseRef.current = 1;
          } else {
            sound.hat();
            bgPulseRef.current = Math.max(bgPulseRef.current, 0.45);
          }
          sound.beatMelody(bIdx);
          bIdx++;
        }
        beatIdxRef.current = bIdx;

        // Check missed notes
        const notes = notesRef.current;
        for (let n = 0; n < notes.length; n++) {
          const note = notes[n];
          if (!note.judged && curTime > note.t + MISS_W) {
            note.judged = true;
            if (!note.isBomb) {
              missNote();
            }
          }
        }

        // Progress bar update
        const songEnd = songEndRef.current;
        if (songEnd > 0) {
          const pVal = Math.min(1, curTime / songEnd);
          setProgress(pVal);
          if (curTime >= songEnd) {
            endGame();
          }
        }
      }

      // Render onto canvas
      const ctx = canvas.getContext('2d');
      if (ctx) {
        const dpr = Math.min(window.devicePixelRatio || 1, 2);
        const W = canvas.width / dpr;
        const H = canvas.height / dpr;
        const judgeY = H - 56;
        const laneW = W / 4;

        ctx.save();
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        ctx.clearRect(0, 0, W, H);

        // Screen shake on miss/bomb
        if (shakeRef.current > 0) {
          const sh = shakeRef.current;
          ctx.translate((Math.random() - 0.5) * 8 * sh, (Math.random() - 0.5) * 8 * sh);
        }

        // Background gradient
        const bgGrad = ctx.createLinearGradient(0, 0, 0, H);
        bgGrad.addColorStop(0, '#1c0a33');
        bgGrad.addColorStop(0.6, '#150726');
        bgGrad.addColorStop(1, '#0a0316');
        ctx.fillStyle = bgGrad;
        ctx.fillRect(-20, -20, W + 40, H + 40);

        // Radial Beat Pulse
        if (bgPulseRef.current > 0) {
          const pulseGrad = ctx.createRadialGradient(W / 2, judgeY, 10, W / 2, judgeY, H * 0.9);
          pulseGrad.addColorStop(0, `rgba(180, 90, 255, ${(0.24 * bgPulseRef.current).toFixed(3)})`);
          pulseGrad.addColorStop(1, 'rgba(180, 90, 255, 0)');
          ctx.fillStyle = pulseGrad;
          ctx.fillRect(-20, -20, W + 40, H + 40);
        }

        // Moving background grid lines
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.04)';
        ctx.lineWidth = 1;
        for (let y = -40 + scrollRef.current; y < H; y += 40) {
          ctx.beginPath();
          ctx.moveTo(0, Math.round(y) + 0.5);
          ctx.lineTo(W, Math.round(y) + 0.5);
          ctx.stroke();
        }

        // 4 Lanes rendering
        for (let i = 0; i < 4; i++) {
          const lx = i * laneW;
          const laneGrad = ctx.createLinearGradient(0, 0, 0, judgeY);
          laneGrad.addColorStop(0, 'rgba(255, 255, 255, 0.015)');
          laneGrad.addColorStop(1, 'rgba(255, 255, 255, 0.06)');
          ctx.fillStyle = laneGrad;
          ctx.fillRect(lx, 0, laneW, judgeY + 30);

          // Lane glow beam on hit
          if (laneGlowRef.current[i] > 0) {
            ctx.globalAlpha = laneGlowRef.current[i] * 0.4;
            const hitGrad = ctx.createLinearGradient(0, judgeY - 220, 0, judgeY + 20);
            hitGrad.addColorStop(0, 'rgba(255, 255, 255, 0)');
            hitGrad.addColorStop(1, LANE_CONFIG[i].color);
            ctx.fillStyle = hitGrad;
            ctx.fillRect(lx, judgeY - 220, laneW, 240);
            ctx.globalAlpha = 1;
          }

          // Lane dividing vertical lines
          ctx.strokeStyle = 'rgba(200, 150, 255, 0.16)';
          ctx.beginPath();
          ctx.moveTo(Math.round(lx) + 0.5, 0);
          ctx.lineTo(Math.round(lx) + 0.5, H);
          ctx.stroke();
        }
        ctx.strokeStyle = 'rgba(200, 150, 255, 0.16)';
        ctx.beginPath();
        ctx.moveTo(Math.round(W) - 0.5, 0);
        ctx.lineTo(Math.round(W) - 0.5, H);
        ctx.stroke();

        // Glowing Judgment Line
        ctx.save();
        ctx.shadowColor = '#ff6ae0';
        ctx.shadowBlur = 18;
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.92)';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(0, judgeY);
        ctx.lineTo(W, judgeY);
        ctx.stroke();
        ctx.restore();

        // Lane circles at judgment line
        for (let j = 0; j < 4; j++) {
          const cx = (j + 0.5) * laneW;
          const glow = laneGlowRef.current[j];
          const rr = 20 + glow * 6;

          ctx.save();
          ctx.shadowColor = LANE_CONFIG[j].color;
          ctx.shadowBlur = 12 + glow * 18;
          ctx.strokeStyle = LANE_CONFIG[j].color;
          ctx.lineWidth = 2.5;
          ctx.globalAlpha = 0.55 + glow * 0.45;
          ctx.beginPath();
          ctx.arc(cx, judgeY, rr, 0, Math.PI * 2);
          ctx.stroke();
          ctx.restore();

          // Key guide label
          ctx.fillStyle = `rgba(255, 255, 255, ${(0.35 + glow * 0.6).toFixed(2)})`;
          ctx.font = '700 12px -apple-system, sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(LANE_CONFIG[j].key, cx, judgeY + 34);
        }

        // Falling food & bomb notes
        const curTime = songTimeRef.current;
        const notes = notesRef.current;
        ctx.font = '28px -apple-system, sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';

        for (let k = 0; k < notes.length; k++) {
          const n = notes[k];
          if (n.judged) continue;

          const left = n.t - curTime;
          const p = left / n.approach;
          if (p > 1.05 || p < -0.3) continue;

          const y = judgeY - p * (judgeY + 40);
          const cx2 = (n.lane + 0.5) * laneW;

          // Stealth modifier fade
          let stealthAlpha = 1;
          if (modStealth && p < 0.4) {
            stealthAlpha = Math.max(0, p / 0.4);
          }

          // Note aura glow
          ctx.save();
          const fadeP = p > 0.92 ? Math.max(0, (1.02 - p) / 0.1) : 1;
          ctx.globalAlpha = fadeP * stealthAlpha * 0.35;
          ctx.fillStyle = n.isBomb ? '#ff2222' : LANE_CONFIG[n.lane].color;
          ctx.shadowColor = n.isBomb ? '#ff0000' : LANE_CONFIG[n.lane].color;
          ctx.shadowBlur = 16;
          ctx.beginPath();
          ctx.arc(cx2, y, 22, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();

          // Emoji item (food or bomb)
          ctx.save();
          ctx.globalAlpha = (p > 0.92 ? Math.max(0, (1.02 - p) / 0.1) : 1) * stealthAlpha;
          ctx.fillText(n.emoji, cx2, y);
          ctx.restore();
        }

        // Hit Rings Effect
        for (let r2 = 0; r2 < rings.length; r2++) {
          const ri2 = rings[r2];
          ctx.save();
          ctx.globalAlpha = Math.max(0, ri2.life) * 0.85;
          ctx.strokeStyle = ri2.color;
          ctx.shadowColor = ri2.color;
          ctx.shadowBlur = 16;
          ctx.lineWidth = 3;
          ctx.beginPath();
          ctx.arc((ri2.lane + 0.5) * laneW, judgeY, ri2.r, 0, Math.PI * 2);
          ctx.stroke();
          ctx.restore();
        }

        // Hit Particle Sparks
        for (let p2 = 0; p2 < parts.length; p2++) {
          const pa2 = parts[p2];
          ctx.save();
          ctx.globalAlpha = Math.max(0, pa2.life);
          ctx.fillStyle = pa2.color;
          ctx.shadowColor = pa2.color;
          ctx.shadowBlur = 10;
          ctx.beginPath();
          ctx.arc(pa2.x, pa2.y, pa2.size, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
        }

        // Big Combo Popup Counter
        const curCombo = comboRef.current;
        if (modeRef.current === 'play' && curCombo >= 2) {
          const sc = 1 + comboPopRef.current * 0.35;
          ctx.save();
          ctx.translate(W / 2, H * 0.38);
          ctx.scale(sc, sc);
          ctx.globalAlpha = 0.92;
          ctx.fillStyle = '#ffffff';
          ctx.shadowColor = curCombo >= 20 ? '#ffd23f' : '#ff6ae0';
          ctx.shadowBlur = 24;
          ctx.font = '900 50px -apple-system, sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(String(curCombo), 0, 0);

          ctx.font = '800 13px -apple-system, sans-serif';
          ctx.fillStyle = curCombo >= 20 ? '#ffe27a' : '#ffb3f0';
          ctx.fillText(curCombo >= 20 ? 'FEVER COMBO! 🔥' : 'COMBO', 0, 32);
          ctx.restore();
        }

        // Judge Text Popup
        if (judgeTextRef.current) {
          const jt = judgeTextRef.current;
          const lifeP = jt.life / 0.6;
          const sc2 = 1.25 - lifeP * 0.25;
          ctx.save();
          ctx.globalAlpha = Math.min(1, lifeP * 1.6);
          ctx.translate(W / 2, judgeY - 80);
          ctx.scale(sc2, sc2);
          ctx.fillStyle = jt.color;
          ctx.shadowColor = jt.color;
          ctx.shadowBlur = 20;
          ctx.font = '900 28px -apple-system, sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(jt.text, 0, 0);
          ctx.restore();
        }

        // Countdown before song starts
        if (modeRef.current === 'play' && curTime < LEAD_IN) {
          const leftSec = LEAD_IN - curTime;
          const num = Math.ceil(leftSec);
          const frac = num - leftSec;
          ctx.save();
          ctx.globalAlpha = 0.9;
          ctx.translate(W / 2, H * 0.48);
          ctx.scale(1 + frac * 0.35, 1 + frac * 0.35);
          ctx.fillStyle = '#ffffff';
          ctx.shadowColor = '#7ee8ff';
          ctx.shadowBlur = 24;
          ctx.font = '900 64px -apple-system, sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(num > 0 ? String(num) : 'START!', 0, 0);
          ctx.restore();
        }

        ctx.restore();
      }

      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);
    reqIdRef.current = animId;

    return () => {
      cancelAnimationFrame(animId);
    };
  }, [modFlip, modStealth, endGame]);

  // Keyboard input listeners
  useEffect(() => {
    const keyMap: Record<string, number> = {
      KeyA: 0,
      KeyS: 1,
      KeyD: 2,
      KeyF: 3,
      Digit1: 0,
      Digit2: 1,
      Digit3: 2,
      Digit4: 3,
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.repeat) return;
      sound.init();

      const lane = keyMap[e.code];
      if (lane !== undefined) {
        setPadState(lane, true);
        hitLane(lane);
      } else if (e.code === 'Escape' || e.code === 'Space') {
        if (modeRef.current === 'play') {
          setMode('pause');
        } else if (modeRef.current === 'pause') {
          setMode('play');
        }
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      const lane = keyMap[e.code];
      if (lane !== undefined) {
        setPadState(lane, false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  return (
    <div className="relative w-full max-w-[480px] h-full flex flex-col bg-gradient-to-b from-[#1d0c33] via-[#12061f] to-[#0b0414] shadow-[0_0_60px_rgba(160,80,255,0.35)] overflow-hidden">
      {/* Top HUD */}
      <GameHud
        score={hudScore}
        combo={hudCombo}
        hp={hudHp}
        maxHp={maxHp}
        isFever={isFever}
        progress={progress}
        soundOn={soundOn}
        onToggleSound={() => setSoundOn(sound.toggleSound())}
        onPause={() => {
          if (mode === 'play') setMode('pause');
        }}
      />

      {/* Main Game Stage */}
      <div
        className={`relative flex-1 min-h-0 flex flex-col transition-transform duration-300 ${
          isFlipped ? 'flipped-stage' : ''
        }`}
      >
        {/* Canvas container */}
        <div ref={containerRef} className="relative flex-1 min-h-0 w-full overflow-hidden">
          <canvas ref={canvasRef} className="absolute inset-0 w-full h-full block touch-none" />
        </div>

        {/* 4 Touchable Rhythm Pads */}
        <div className="flex-none grid grid-cols-4 gap-1.5 p-2 pb-3 sm:pb-4 bg-gradient-to-t from-[#0c0419] via-[#12061f] to-transparent z-10">
          {LANE_CONFIG.map((lane, i) => {
            const isActive = padActive[i];
            return (
              <button
                key={lane.key}
                type="button"
                onPointerDown={(e) => {
                  e.preventDefault();
                  sound.init();
                  setPadState(i, true);
                  hitLane(i);
                }}
                onPointerUp={(e) => {
                  e.preventDefault();
                  setPadState(i, false);
                }}
                onPointerCancel={(e) => {
                  e.preventDefault();
                  setPadState(i, false);
                }}
                className={`h-20 sm:h-24 rounded-2xl border-2 flex flex-col items-center justify-center gap-0.5 cursor-pointer touch-none select-none transition-all duration-75 ${
                  isActive
                    ? 'scale-[0.93] translate-y-1 brightness-125'
                    : 'hover:brightness-105 active:scale-[0.93]'
                }`}
                style={{
                  borderColor: lane.color,
                  background: isActive
                    ? `linear-gradient(180deg, ${lane.shadow}, rgba(255,255,255,0.2))`
                    : 'linear-gradient(180deg, rgba(255,255,255,0.12), rgba(255,255,255,0.02))',
                  boxShadow: isActive
                    ? `0 0 22px ${lane.color}, inset 0 0 15px ${lane.shadow}`
                    : `0 0 12px ${lane.shadow}`,
                }}
              >
                <span
                  className="text-2xl sm:text-3xl font-black"
                  style={{ color: lane.color, textShadow: `0 0 12px ${lane.color}` }}
                >
                  {lane.key}
                </span>
                <span className="text-xl sm:text-2xl">{lane.emojis[0]}</span>
                <span className="text-[10px] sm:text-xs font-bold text-gray-300">
                  {lane.name}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Start Screen Overlay */}
      {mode === 'start' && (
        <StartScreen
          selectedDiff={selectedDiff}
          onSelectDiff={(diff) => setSelectedDiff(diff)}
          selectedSpeed={selectedSpeed}
          onSelectSpeed={(speed) => setSelectedSpeed(speed)}
          modBomb={modBomb}
          onToggleBomb={() => setModBomb(!modBomb)}
          modStealth={modStealth}
          onToggleStealth={() => setModStealth(!modStealth)}
          modFlip={modFlip}
          onToggleFlip={() => setModFlip(!modFlip)}
          modSuddenDeath={modSuddenDeath}
          onToggleSuddenDeath={() => setModSuddenDeath(!modSuddenDeath)}
          bestScore={bestScore}
          onStart={startGame}
        />
      )}

      {/* Pause Screen Overlay */}
      {mode === 'pause' && (
        <PauseScreen
          onResume={() => setMode('play')}
          onQuit={() => setMode('start')}
        />
      )}

      {/* Result Screen Overlay */}
      {mode === 'result' && (
        <ResultScreen
          stats={resultStats}
          isNewBest={isNewBest}
          onRetry={startGame}
          onHome={() => setMode('start')}
        />
      )}
    </div>
  );
}
