class SoundEngine {
  private ac: AudioContext | null = null;
  private master: GainNode | null = null;
  private noiseBuf: AudioBuffer | null = null;
  public soundOn: boolean = true;

  public init() {
    if (!this.ac) {
      try {
        const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        if (!AudioCtx) return;
        this.ac = new AudioCtx();
        this.master = this.ac.createGain();
        this.master.gain.value = 0.4;
        this.master.connect(this.ac.destination);

        const len = Math.floor(this.ac.sampleRate * 0.2);
        this.noiseBuf = this.ac.createBuffer(1, len, this.ac.sampleRate);
        const d = this.noiseBuf.getChannelData(0);
        for (let i = 0; i < len; i++) {
          d[i] = Math.random() * 2 - 1;
        }
      } catch {
        this.ac = null;
      }
    }
    if (this.ac && this.ac.state === 'suspended') {
      this.ac.resume().catch(() => {});
    }
  }

  public toggleSound(): boolean {
    this.soundOn = !this.soundOn;
    return this.soundOn;
  }

  private tone(freq: number, freq2: number, dur: number, type: OscillatorType, vol: number) {
    if (!this.soundOn || !this.ac || !this.master) return;
    try {
      const now = this.ac.currentTime;
      const osc = this.ac.createOscillator();
      const gain = this.ac.createGain();

      osc.type = type;
      osc.frequency.setValueAtTime(freq, now);
      if (freq2 > 0) {
        osc.frequency.exponentialRampToValueAtTime(Math.max(10, freq2), now + dur);
      }
      gain.gain.setValueAtTime(vol, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + dur);

      osc.connect(gain);
      gain.connect(this.master);

      osc.start(now);
      osc.stop(now + dur + 0.02);
    } catch {
      // ignore audio context errors
    }
  }

  private noise(dur: number, vol: number, hp: number) {
    if (!this.soundOn || !this.ac || !this.noiseBuf || !this.master) return;
    try {
      const now = this.ac.currentTime;
      const src = this.ac.createBufferSource();
      src.buffer = this.noiseBuf;

      const filter = this.ac.createBiquadFilter();
      filter.type = 'highpass';
      filter.frequency.value = hp;

      const gain = this.ac.createGain();
      gain.gain.setValueAtTime(vol, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + dur);

      src.connect(filter);
      filter.connect(gain);
      gain.connect(this.master);

      src.start(now);
      src.stop(now + dur + 0.02);
    } catch {
      // ignore
    }
  }

  public hitPerfect(lane: number) {
    const freqs = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6
    const f = freqs[lane % freqs.length];
    this.tone(f, f * 1.5, 0.14, 'triangle', 0.35);
  }

  public hitGood(lane: number) {
    const freqs = [392.0, 493.88, 587.33, 783.99]; // G4, B4, D5, G5
    const f = freqs[lane % freqs.length];
    this.tone(f, f, 0.1, 'sine', 0.25);
  }

  public miss() {
    this.tone(180, 60, 0.16, 'sawtooth', 0.2);
  }

  public bombExplode() {
    this.tone(120, 30, 0.35, 'sawtooth', 0.45);
    this.noise(0.25, 0.3, 200);
  }

  public kick() {
    this.tone(140, 40, 0.15, 'sine', 0.4);
  }

  public hat() {
    this.noise(0.035, 0.12, 7500);
  }

  public beatMelody(idx: number) {
    const scale = [261.63, 329.63, 392.0, 440.0, 523.25, 659.25, 783.99];
    const note = scale[idx % scale.length];
    this.tone(note, note, 0.09, 'sine', 0.14);
  }

  public startFanfare() {
    this.tone(523.25, 1046.5, 0.2, 'triangle', 0.3);
  }

  public victoryJingle() {
    this.tone(523.25, 0, 0.15, 'triangle', 0.25);
    setTimeout(() => this.tone(659.25, 0, 0.15, 'triangle', 0.25), 140);
    setTimeout(() => this.tone(783.99, 0, 0.15, 'triangle', 0.28), 280);
    setTimeout(() => this.tone(1046.5, 0, 0.35, 'triangle', 0.32), 420);
  }
}

export const sound = new SoundEngine();
