import { Difficulty, Note, Beat } from '../types';

export const CHART_EASY = [
  {
    bpm: 105,
    bars: [
      "1...2...", "3...4...", "1..2..3.", "4...3...",
      "1...1...", "2...3...", "4..3..2.", "1...1..."
    ]
  },
  {
    bpm: 115,
    bars: [
      "1.2.3.4.", "4.3.2.1.", "1..2..3.", "12..34..",
      "1.1.2.2.", "3.3.4.4.", "1..3..2.", "4.2.4.2."
    ]
  }
];

export const CHART_NORMAL = [
  {
    bpm: 115,
    bars: [
      "1...2...", "3...4...", "1..2..3.", "4...3...",
      "1.2.3.4.", "4.3.2.1.", "1..2..3.", "12..34.."
    ]
  },
  {
    bpm: 130,
    bars: [
      "1.2.3.4.", "4.3.2.1.", "1..2..3.", "12..34..",
      "1.1.2.2.", "3.3.4.4.", "1..3..2.", "4.2.4.2.",
      "13..24..", "1.2.3.4."
    ]
  },
  {
    bpm: 145,
    bars: [
      "1.2.3.4.", "4.3.2.1.", "12.12.34", "4.4.3.3.",
      "1.3.2.4.", "2.4.1.3.", "12.34.12", "4.1.4.1."
    ]
  }
];

export const CHART_HARD = [
  {
    bpm: 130,
    bars: [
      "1.2.3.4.", "4.3.2.1.", "12.12.34", "4.4.3.3.",
      "1.3.2.4.", "2.4.1.3.", "12.34.12", "4.1.4.1."
    ]
  },
  {
    bpm: 150,
    bars: [
      "12..34..", "43..21..", "1.3.2.4.", "4.2.3.1.",
      "11223344", "44332211", "123.234.", "432.321."
    ]
  },
  {
    bpm: 165,
    bars: [
      "1.23.4.1", "2.34.1.2", "12.34.12", "34.12.34",
      "11.22.33", "44.33.22", "13.24.13", "24.13.24",
      "12341234", "43214321"
    ]
  }
];

export const CHART_HELL = [
  {
    bpm: 200,
    bars: [
      "12341234", "43214321", "13241324", "42314231",
      "11223344", "44332211", "12.34.12", "34.12.34"
    ]
  },
  {
    bpm: 240,
    bars: [
      "12344321", "13244231", "11112222", "33334444",
      "12341234", "43214321", "14231423", "41324132"
    ]
  },
  {
    bpm: 280,
    bars: [
      "12341234", "43214321", "11223344", "44332211",
      "13241324", "42314231", "12344321", "12341234",
      "12341234", "43214321"
    ]
  }
];

export const CHART_GOD = [
  {
    bpm: 280,
    bars: [
      "12341234", "43214321", "13241324", "42314231",
      "14231423", "41324132", "12..34..", "43..21.."
    ]
  },
  {
    bpm: 340,
    bars: [
      "12344321", "13244231", "11223344", "44332211",
      "14142323", "32324141", "12341234", "43214321"
    ]
  },
  {
    bpm: 400,
    bars: [
      "12341234", "43214321", "11223344", "44332211",
      "13241324", "42314231", "12344321", "12341234",
      "14234123", "41321432", "12341234", "43214321"
    ]
  }
];

export const LANE_CONFIG = [
  { key: 'A', name: '밥', emojis: ['🍚', '🍙', '🍛'], color: '#ff4fd8', shadow: 'rgba(255, 79, 216, 0.45)' },
  { key: 'S', name: '고기', emojis: ['🍗', '🍖', '🥚'], color: '#a06bff', shadow: 'rgba(160, 107, 255, 0.45)' },
  { key: 'D', name: '채소', emojis: ['🥦', '🥬', '🥒'], color: '#34e0ff', shadow: 'rgba(52, 224, 255, 0.45)' },
  { key: 'F', name: '후식', emojis: ['🍅', '🍎', '🍓'], color: '#ffd23f', shadow: 'rgba(255, 210, 63, 0.45)' }
];

export const LEAD_IN = 2.5;

export function generateChart(
  diff: Difficulty,
  speed: number,
  modBomb: boolean
): { notes: Note[]; beats: Beat[]; songEnd: number } {
  const sections =
    diff === 'easy'
      ? CHART_EASY
      : diff === 'hard'
      ? CHART_HARD
      : diff === 'hell'
      ? CHART_HELL
      : diff === 'god'
      ? CHART_GOD
      : CHART_NORMAL;

  const notes: Note[] = [];
  const beats: Beat[] = [];
  let t = LEAD_IN;
  let idx = 0;

  for (let s = 0; s < sections.length; s++) {
    const bpm = sections[s].bpm;
    const beatDur = 60 / bpm;
    const slot = beatDur / 2;
    // Normal approach time scale: at 1x speed it takes roughly 1.3-1.6s to approach
    const approach = Math.max(0.25, (beatDur * 2.8) / speed);

    for (let b = 0; b < sections[s].bars.length; b++) {
      const bar = sections[s].bars[b];
      for (let q = 0; q < 4; q++) {
        beats.push({ t: t + q * beatDur, strong: q % 2 === 0, bpm });
      }

      for (let i = 0; i < bar.length; i++) {
        const ch = bar.charAt(i);
        if (ch >= '1' && ch <= '4') {
          const lane = ch.charCodeAt(0) - 49;
          const isBomb = modBomb && Math.random() < 0.12;
          const foodEmoji = LANE_CONFIG[lane].emojis[idx % 3];

          notes.push({
            t: t + i * slot,
            lane,
            approach,
            emoji: isBomb ? '💣' : foodEmoji,
            isBomb,
            judged: false
          });
          idx++;
        }
      }
      t += beatDur * 4;
    }
  }

  notes.sort((a, b) => a.t - b.t);
  const songEnd = t + 2.0;

  return { notes, beats, songEnd };
}
