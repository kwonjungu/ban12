import React from 'react';
import { Difficulty } from '../types';
import { bannerImg, trayImg } from '../assets/images';

interface StartScreenProps {
  selectedDiff: Difficulty;
  onSelectDiff: (diff: Difficulty) => void;
  selectedSpeed: number;
  onSelectSpeed: (speed: number) => void;
  modBomb: boolean;
  onToggleBomb: () => void;
  modStealth: boolean;
  onToggleStealth: () => void;
  modFlip: boolean;
  onToggleFlip: () => void;
  modSuddenDeath: boolean;
  onToggleSuddenDeath: () => void;
  bestScore: number;
  onStart: () => void;
}

export const StartScreen: React.FC<StartScreenProps> = ({
  selectedDiff,
  onSelectDiff,
  selectedSpeed,
  onSelectSpeed,
  modBomb,
  onToggleBomb,
  modStealth,
  onToggleStealth,
  modFlip,
  onToggleFlip,
  modSuddenDeath,
  onToggleSuddenDeath,
  bestScore,
  onStart,
}) => {
  const difficulties: { id: Difficulty; label: string; icon: string; color: string }[] = [
    { id: 'easy', label: '순한맛', icon: '🥛', color: 'from-blue-500 to-cyan-400' },
    { id: 'normal', label: '중간맛', icon: '🍱', color: 'from-purple-500 to-pink-500' },
    { id: 'hard', label: '매운맛', icon: '🌶️', color: 'from-orange-500 to-red-500' },
    { id: 'hell', label: '불지옥', icon: '☠️', color: 'from-red-600 to-rose-700' },
    { id: 'god', label: 'GOD 神', icon: '⚡', color: 'from-red-600 to-yellow-500' }
  ];

  const speeds = [
    { val: 1, label: '1x' },
    { val: 1.5, label: '1.5x' },
    { val: 2, label: '2x' },
    { val: 3, label: '3x' },
    { val: 4, label: '4x ⚡' },
    { val: 100, label: '100x 💥' },
  ];

  return (
    <div className="absolute inset-0 z-20 flex flex-col items-center justify-between p-4 text-center bg-radial from-[#371264]/95 via-[#18082e]/98 to-[#090312]/98 backdrop-blur-md overflow-y-auto">
      {/* Top Banner Asset */}
      <div className="w-full max-w-sm mt-1 mb-2">
        <div className="relative rounded-2xl overflow-hidden shadow-[0_0_25px_rgba(160,80,255,0.45)] border border-purple-400/30">
          <img
            src={bannerImg}
            alt="급식 리듬 게임 배너"
            referrerPolicy="no-referrer"
            className="w-full h-32 sm:h-36 object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#150726] via-transparent to-black/20" />
          <div className="absolute bottom-2 left-3 right-3 flex items-center justify-between">
            <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-black/60 border border-white/20 text-xs font-bold text-pink-300">
              <img
                src={trayImg}
                alt="급식판"
                referrerPolicy="no-referrer"
                className="w-4 h-4 rounded-sm object-cover"
              />
              급식실 라이브
            </span>
            <span className="text-[11px] font-semibold text-purple-200/90 bg-purple-950/70 px-2 py-0.5 rounded-full border border-purple-400/20">
              맛있는 비트 타임
            </span>
          </div>
        </div>
      </div>

      {/* Header Titles */}
      <div className="flex flex-col items-center gap-1 my-1">
        <h1 className="text-2xl sm:text-3xl font-black tracking-tight bg-gradient-to-r from-[#ff4fd8] via-[#a06bff] to-[#34e0ff] bg-clip-text text-transparent drop-shadow-[0_0_15px_rgba(255,90,220,0.6)] animate-hue">
          급식 리듬 게임 🥁
        </h1>
        <p className="text-xs sm:text-sm text-purple-200 font-medium">
          떨어지는 반찬이 판정선에 닿을 때 박자에 맞춰 <b>딱!</b> 눌러주세요!
        </p>
      </div>

      {/* Difficulty Selector */}
      <div className="w-full max-w-sm flex flex-col gap-1 my-1.5">
        <div className="text-[11px] font-bold text-purple-300 tracking-wider text-left pl-1">
          난이도 선택
        </div>
        <div className="grid grid-cols-5 gap-1.5">
          {difficulties.map((diff) => {
            const isActive = selectedDiff === diff.id;
            return (
              <button
                key={diff.id}
                type="button"
                onClick={() => onSelectDiff(diff.id)}
                className={`py-2 px-1 rounded-xl text-xs font-black transition-all cursor-pointer flex flex-col items-center gap-0.5 border ${
                  isActive
                    ? `bg-gradient-to-br ${diff.color} text-white border-white/40 shadow-[0_0_14px_rgba(255,79,216,0.6)] scale-[1.03]`
                    : 'bg-white/5 hover:bg-white/10 text-purple-200/80 border-white/10'
                }`}
              >
                <span className="text-sm">{diff.icon}</span>
                <span className="text-[11px] leading-tight truncate">{diff.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Speed Selector */}
      <div className="w-full max-w-sm flex flex-col gap-1 my-1">
        <div className="flex items-center justify-between pl-1 pr-1">
          <span className="text-[11px] font-bold text-purple-300 tracking-wider">노트 낙하 속도</span>
          {selectedSpeed >= 100 && (
            <span className="text-[10px] text-red-400 font-bold animate-pulse">초광속 모드 주의!</span>
          )}
        </div>
        <div className="grid grid-cols-6 gap-1">
          {speeds.map((s) => {
            const isActive = selectedSpeed === s.val;
            return (
              <button
                key={s.val}
                type="button"
                onClick={() => onSelectSpeed(s.val)}
                className={`py-1.5 px-0.5 rounded-lg text-xs font-extrabold transition-all cursor-pointer border ${
                  isActive
                    ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white border-pink-300 shadow-[0_0_10px_rgba(255,79,216,0.5)]'
                    : 'bg-white/5 hover:bg-white/10 text-purple-200/70 border-white/10'
                }`}
              >
                {s.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Chaos Modifiers Box */}
      <div className="w-full max-w-sm my-1 p-2 rounded-xl bg-black/40 border border-purple-500/30 flex flex-col gap-1.5">
        <div className="text-[11px] font-bold text-pink-300 flex items-center justify-center gap-1">
          <span>🌀 기믹 / 재미 모드 (선택)</span>
        </div>
        <div className="grid grid-cols-2 gap-1.5">
          <button
            type="button"
            onClick={onToggleBomb}
            className={`py-1.5 px-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 border ${
              modBomb
                ? 'bg-gradient-to-r from-red-600 to-orange-600 text-white border-red-300 shadow-[0_0_8px_rgba(255,50,50,0.5)]'
                : 'bg-white/5 text-gray-400 border-white/10 hover:bg-white/10'
            }`}
          >
            <span>💣</span>
            <span>폭탄 반전</span>
          </button>
          <button
            type="button"
            onClick={onToggleStealth}
            className={`py-1.5 px-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 border ${
              modStealth
                ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white border-purple-300 shadow-[0_0_8px_rgba(180,80,255,0.5)]'
                : 'bg-white/5 text-gray-400 border-white/10 hover:bg-white/10'
            }`}
          >
            <span>👻</span>
            <span>유령 스텔스</span>
          </button>
          <button
            type="button"
            onClick={onToggleFlip}
            className={`py-1.5 px-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 border ${
              modFlip
                ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white border-cyan-300 shadow-[0_0_8px_rgba(50,200,255,0.5)]'
                : 'bg-white/5 text-gray-400 border-white/10 hover:bg-white/10'
            }`}
          >
            <span>🔄</span>
            <span>화면 뒤집기</span>
          </button>
          <button
            type="button"
            onClick={onToggleSuddenDeath}
            className={`py-1.5 px-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 border ${
              modSuddenDeath
                ? 'bg-gradient-to-r from-rose-600 to-pink-600 text-white border-rose-300 shadow-[0_0_8px_rgba(255,50,100,0.5)]'
                : 'bg-white/5 text-gray-400 border-white/10 hover:bg-white/10'
            }`}
          >
            <span>💀</span>
            <span>3목숨 제한</span>
          </button>
        </div>
      </div>

      {/* Key Cap Preview Guide */}
      <div className="grid grid-cols-4 gap-2 w-full max-w-sm my-1">
        {[
          { key: 'A', name: '밥', icon: '🍚', color: '#ff4fd8' },
          { key: 'S', name: '고기', icon: '🍗', color: '#a06bff' },
          { key: 'D', name: '채소', icon: '🥦', color: '#34e0ff' },
          { key: 'F', name: '과일', icon: '🍅', color: '#ffd23f' },
        ].map((item) => (
          <div
            key={item.key}
            className="p-1.5 rounded-xl bg-white/5 border border-white/15 flex flex-col items-center justify-center shadow-sm"
          >
            <span className="text-base font-black" style={{ color: item.color }}>
              {item.key}
            </span>
            <span className="text-sm mt-0.5">{item.icon}</span>
            <span className="text-[10px] text-gray-300">{item.name}</span>
          </div>
        ))}
      </div>

      <p className="text-[11px] text-purple-300/80 my-0.5">
        💻 키보드(A, S, D, F) 또는 📱 화면 하단 패드를 직접 터치하세요!
      </p>

      {/* Start Button & Best Score */}
      <div className="w-full max-w-sm flex flex-col items-center gap-1.5 mt-1 mb-2">
        <button
          type="button"
          onClick={onStart}
          className="w-full py-3.5 px-6 rounded-2xl font-black text-lg text-white bg-gradient-to-r from-[#ff4fd8] via-[#a06bff] to-[#34e0ff] shadow-[0_0_24px_rgba(255,79,216,0.65)] hover:shadow-[0_0_30px_rgba(52,224,255,0.85)] active:scale-[0.97] transition-all cursor-pointer border border-white/30"
        >
          급식 받으러 가기 ▶
        </button>

        {bestScore > 0 && (
          <div className="text-xs font-bold text-yellow-300 flex items-center gap-1">
            <span>🏆 최고 기록 ({selectedDiff.toUpperCase()}):</span>
            <span className="text-sm font-extrabold text-white">{bestScore.toLocaleString()}점</span>
          </div>
        )}
      </div>
    </div>
  );
};
