import React, { useRef, useEffect, useCallback } from 'react';
import { Note, Beat, RingEffect, ParticleEffect, JudgePopup } from '../types';
import { LANE_CONFIG, LEAD_IN } from '../data/charts';
import { sound } from '../utils/audio';

interface GameStageProps {
  notes: Note[];
  beats: Beat[];
  songEnd: number;
  songTime: number;
  isFlipped: boolean;
  modStealth: boolean;
  isFever: boolean;
  padActive: boolean[];
  onHitLane: (lane: number) => void;
  onPadDown: (lane: number) => void;
  onPadUp: (lane: number) => void;
  onEndGame: () => void;
  onMissNote: () => void;
  combo: number;
  judgePopup: JudgePopup | null;
  rings: RingEffect[];
  particles: ParticleEffect[];
  shake: number;
}

export const GameStage: React.FC<GameStageProps> = ({
  notes,
  isFlipped,
  modStealth,
  padActive,
  onHitLane,
  onPadDown,
  onPadUp,
  combo,
  judgePopup,
  rings,
  particles,
  shake,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const bgPulseRef = useRef<number>(0);
  const scrollRef = useRef<number>(0);

  // Resize canvas according to container
  const updateCanvasSize = useCallback(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const rect = container.getBoundingClientRect();
    const w = Math.max(160, rect.width);
    const h = Math.max(200, rect.height);
    const dpr = Math.min(window.devicePixelRatio || 1, 2);

    canvas.width = Math.round(w * dpr);
    canvas.height = Math.round(h * dpr);
  }, []);

  useEffect(() => {
    updateCanvasSize();
    const handleResize = () => updateCanvasSize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [updateCanvasSize]);

  // Pointer down/up handler for lane pads
  const handlePointerDown = (lane: number, e: React.PointerEvent) => {
    e.preventDefault();
    sound.init();
    onPadDown(lane);
    onHitLane(lane);
  };

  const handlePointerUp = (lane: number, e: React.PointerEvent) => {
    e.preventDefault();
    onPadUp(lane);
  };

  return (
    <div
      className={`relative flex-1 min-h-0 flex flex-col transition-transform duration-300 ${
        isFlipped ? 'flipped-stage' : ''
      }`}
    >
      {/* Canvas Field */}
      <div ref={containerRef} className="relative flex-1 min-h-0 w-full overflow-hidden">
        <canvas
          ref={canvasRef}
          className="absolute inset-0 w-full h-full block touch-none"
        />
      </div>

      {/* 4 Touchable Rhythm Pads */}
      <div className="flex-none grid grid-cols-4 gap-1.5 p-2 pb-3 sm:pb-4 bg-gradient-to-t from-[#0c0419] via-[#12061f] to-transparent z-10">
        {LANE_CONFIG.map((lane, i) => {
          const isActive = padActive[i];
          return (
            <button
              key={lane.key}
              type="button"
              onPointerDown={(e) => handlePointerDown(i, e)}
              onPointerUp={(e) => handlePointerUp(i, e)}
              onPointerCancel={(e) => handlePointerUp(i, e)}
              className={`h-20 sm:h-24 rounded-2xl border-2 flex flex-col items-center justify-center gap-0.5 cursor-pointer touch-none select-none transition-all duration-75 ${
                isActive
                  ? 'scale-[0.94] translate-y-1 brightness-125'
                  : 'hover:brightness-105 active:scale-[0.94]'
              }`}
              style={{
                borderColor: lane.color,
                background: isActive
                  ? `linear-gradient(180deg, ${lane.shadow}, rgba(255,255,255,0.2))`
                  : 'linear-gradient(180deg, rgba(255,255,255,0.12), rgba(255,255,255,0.02))',
                boxShadow: isActive
                  ? `0 0 22px ${lane.color}, inset 0 0 15px ${lane.shadow}`
                  : `0 0 12px ${lane.shadow}`,
              }}
            >
              <span
                className="text-2xl sm:text-3xl font-black"
                style={{ color: lane.color, textShadow: `0 0 12px ${lane.color}` }}
              >
                {lane.key}
              </span>
              <span className="text-xl sm:text-2xl">{lane.emojis[0]}</span>
              <span className="text-[10px] sm:text-xs font-bold text-gray-300">
                {lane.name}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
