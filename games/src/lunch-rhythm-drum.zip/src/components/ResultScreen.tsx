import React from 'react';
import { GameStats } from '../types';
import { mascotImg } from '../assets/images';

interface ResultScreenProps {
  stats: GameStats;
  isNewBest: boolean;
  onRetry: () => void;
  onHome: () => void;
}

export const ResultScreen: React.FC<ResultScreenProps> = ({
  stats,
  isNewBest,
  onRetry,
  onHome,
}) => {
  const getGradeColor = (grade: string) => {
    switch (grade) {
      case 'SS':
        return 'text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 via-pink-300 to-cyan-300 drop-shadow-[0_0_20px_rgba(255,215,0,0.8)]';
      case 'S':
        return 'text-yellow-300 drop-shadow-[0_0_18px_rgba(255,215,0,0.7)]';
      case 'A':
        return 'text-cyan-300 drop-shadow-[0_0_16px_rgba(52,224,255,0.7)]';
      case 'B':
        return 'text-purple-300 drop-shadow-[0_0_14px_rgba(160,107,255,0.6)]';
      case 'C':
        return 'text-orange-300 drop-shadow-[0_0_12px_rgba(255,165,0,0.5)]';
      default:
        return 'text-red-400 drop-shadow-[0_0_12px_rgba(255,79,79,0.5)]';
    }
  };

  const getMessage = (accuracy: number) => {
    if (accuracy >= 98) return '🌟 완벽한 칼각 배식! 전설의 급식 마스터!';
    if (accuracy >= 90) return '🎉 급식 완판 성공! 영양사님도 감탄한 리듬감!';
    if (accuracy >= 80) return '🍚 훌륭해요! 든든하고 맛있는 한 끼 완성!';
    if (accuracy >= 70) return '🍱 좋은 타이밍! 다음엔 올 콤보를 노려보세요!';
    return '💪 힘내세요! 반찬을 흘리지 않게 다시 도전!';
  };

  return (
    <div className="absolute inset-0 z-20 flex flex-col items-center justify-between p-5 text-center bg-radial from-[#35105a]/95 via-[#18072d]/98 to-[#090312]/98 backdrop-blur-md overflow-y-auto">
      {/* Top Victory Mascot */}
      <div className="flex flex-col items-center gap-1 mt-2">
        <div className="relative">
          <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-3xl overflow-hidden border-2 border-pink-400/50 shadow-[0_0_30px_rgba(255,79,216,0.6)]">
            <img
              src={mascotImg}
              alt="승리 마스코트"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
          </div>
          {isNewBest && (
            <span className="absolute -top-2 -right-3 px-2 py-0.5 rounded-full bg-gradient-to-r from-amber-400 to-pink-500 text-[11px] font-black text-white shadow-lg animate-bounce">
              NEW BEST!
            </span>
          )}
        </div>

        <h2 className="text-sm font-extrabold text-purple-200 mt-2">
          급식 완판! 오늘의 리듬 성적표
        </h2>
      </div>

      {/* Grade and Accuracy */}
      <div className="flex flex-col items-center my-1">
        <div className={`text-6xl sm:text-7xl font-black tracking-tight ${getGradeColor(stats.grade)}`}>
          {stats.grade}
        </div>
        <div className="text-xl sm:text-2xl font-black text-white drop-shadow-md">
          정확도 {stats.accuracy}%
        </div>
      </div>

      {/* Score & Max Combo Pills */}
      <div className="flex gap-2 w-full max-w-xs justify-center">
        <div className="flex-1 py-2 px-3 rounded-xl bg-white/10 border border-white/20 text-xs font-bold text-gray-200 flex flex-col items-center">
          <span className="text-[11px] text-yellow-300 font-extrabold">🍚 최종 점수</span>
          <span className="text-lg font-black text-white">{stats.score.toLocaleString()}</span>
        </div>
        <div className="flex-1 py-2 px-3 rounded-xl bg-white/10 border border-white/20 text-xs font-bold text-gray-200 flex flex-col items-center">
          <span className="text-[11px] text-pink-300 font-extrabold">🔥 최고 콤보</span>
          <span className="text-lg font-black text-white">{stats.maxCombo}</span>
        </div>
      </div>

      {/* Accuracy Breakdown Grid */}
      <div className="grid grid-cols-3 gap-2 w-full max-w-xs my-1">
        <div className="p-2 rounded-xl bg-cyan-950/40 border border-cyan-500/30 flex flex-col items-center">
          <span className="text-cyan-300 text-lg font-black">{stats.perfect}</span>
          <span className="text-[10px] font-extrabold text-cyan-200/80">PERFECT</span>
        </div>
        <div className="p-2 rounded-xl bg-yellow-950/40 border border-yellow-500/30 flex flex-col items-center">
          <span className="text-yellow-300 text-lg font-black">{stats.good}</span>
          <span className="text-[10px] font-extrabold text-yellow-200/80">GOOD</span>
        </div>
        <div className="p-2 rounded-xl bg-pink-950/40 border border-pink-500/30 flex flex-col items-center">
          <span className="text-pink-400 text-lg font-black">{stats.miss}</span>
          <span className="text-[10px] font-extrabold text-pink-200/80">MISS</span>
        </div>
      </div>

      <p className="text-xs sm:text-sm font-bold text-purple-200 px-2 my-1">
        {getMessage(stats.accuracy)}
      </p>

      {/* Action Buttons */}
      <div className="flex flex-col gap-2 w-full max-w-xs mt-1 mb-2">
        <button
          type="button"
          onClick={onRetry}
          className="w-full py-3 px-6 rounded-xl font-black text-base text-white bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-500 shadow-[0_0_20px_rgba(255,79,216,0.6)] hover:brightness-110 active:scale-95 transition-all cursor-pointer border border-white/30"
        >
          한 판 더 도전! 🔁
        </button>
        <button
          type="button"
          onClick={onHome}
          className="w-full py-2.5 px-6 rounded-xl font-bold text-sm text-purple-200 bg-white/10 hover:bg-white/15 active:scale-95 transition-all cursor-pointer border border-white/15"
        >
          메뉴 화면으로 🏠
        </button>
      </div>
    </div>
  );
};
