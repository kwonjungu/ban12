import React from 'react';
import { trayImg } from '../assets/images';

interface GameHudProps {
  score: number;
  combo: number;
  hp: number;
  maxHp: number;
  isFever: boolean;
  progress: number;
  soundOn: boolean;
  onToggleSound: () => void;
  onPause: () => void;
}

export const GameHud: React.FC<GameHudProps> = ({
  score,
  combo,
  hp,
  maxHp,
  isFever,
  progress,
  soundOn,
  onToggleSound,
  onPause,
}) => {
  return (
    <div className="flex-none p-2 sm:px-3 sm:py-2.5 border-b border-purple-500/25 bg-gradient-to-b from-purple-950/80 to-transparent z-10">
      <div className="flex items-center gap-1.5 sm:gap-2">
        {/* Tray icon badge */}
        <div className="flex-none w-8 h-8 rounded-lg overflow-hidden border border-purple-400/40 shadow-sm">
          <img
            src={trayImg}
            alt="급식판"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
        </div>

        {/* Score Chip */}
        <div className="flex-1 min-w-0 flex items-center justify-center gap-1 py-1 px-1.5 rounded-xl bg-white/10 border border-white/15 text-[11px] sm:text-xs font-bold whitespace-nowrap">
          <span className="text-yellow-300">🍚</span>
          <span className="text-yellow-300 font-extrabold truncate drop-shadow-[0_0_8px_rgba(255,210,63,0.7)]">
            {score.toLocaleString()}
          </span>
        </div>

        {/* Combo Chip with Fever Indicator */}
        <div
          className={`flex-1 min-w-0 flex items-center justify-center gap-1 py-1 px-1.5 rounded-xl border text-[11px] sm:text-xs font-bold whitespace-nowrap transition-all ${
            isFever
              ? 'bg-gradient-to-r from-pink-600/60 to-purple-600/60 border-pink-400 shadow-[0_0_12px_rgba(255,79,216,0.8)] animate-pulse'
              : 'bg-white/10 border-white/15'
          }`}
        >
          <span className={isFever ? 'text-pink-300 animate-bounce' : 'text-pink-400'}>
            {isFever ? '🔥x2' : '🔥'}
          </span>
          <span className="text-pink-300 font-extrabold truncate drop-shadow-[0_0_8px_rgba(255,79,216,0.7)]">
            {combo}
          </span>
        </div>

        {/* HP / Lives Chip */}
        <div className="flex-1 min-w-0 flex items-center justify-center gap-1 py-1 px-1.5 rounded-xl bg-white/10 border border-white/15 text-[11px] sm:text-xs font-bold whitespace-nowrap">
          <span className="text-red-400">❤️</span>
          <span
            className={`font-extrabold truncate ${
              hp <= 1 ? 'text-red-400 animate-ping' : 'text-red-300'
            }`}
          >
            {hp}/{maxHp}
          </span>
        </div>

        {/* Controls: Pause & Sound */}
        <button
          type="button"
          onClick={onPause}
          className="flex-none w-8 h-8 rounded-xl border border-white/20 bg-white/10 hover:bg-white/20 text-white flex items-center justify-center text-sm cursor-pointer active:scale-90 transition-transform"
          aria-label="일시정지"
        >
          ⏸️
        </button>

        <button
          type="button"
          onClick={onToggleSound}
          className="flex-none w-8 h-8 rounded-xl border border-white/20 bg-white/10 hover:bg-white/20 text-white flex items-center justify-center text-sm cursor-pointer active:scale-90 transition-transform"
          aria-label="소리 토글"
        >
          {soundOn ? '🔊' : '🔇'}
        </button>
      </div>

      {/* Song Progress Time Bar */}
      <div className="mt-1.5 h-1.5 w-full rounded-full bg-white/10 overflow-hidden border border-white/10">
        <div
          className="h-full bg-gradient-to-r from-[#ff4fd8] via-[#a06bff] to-[#34e0ff] shadow-[0_0_10px_rgba(255,120,240,0.8)] transition-all duration-75"
          style={{ width: `${Math.min(100, Math.max(0, progress * 100))}%` }}
        />
      </div>
    </div>
  );
};
