import React from 'react';
import { trayImg } from '../assets/images';

interface PauseScreenProps {
  onResume: () => void;
  onQuit: () => void;
}

export const PauseScreen: React.FC<PauseScreenProps> = ({ onResume, onQuit }) => {
  return (
    <div className="absolute inset-0 z-20 flex flex-col items-center justify-center p-6 text-center bg-radial from-[#2a0e4e]/95 to-[#080211]/98 backdrop-blur-md gap-4">
      <div className="relative">
        <div className="w-20 h-20 rounded-2xl overflow-hidden border-2 border-purple-400/40 shadow-[0_0_25px_rgba(160,80,255,0.5)]">
          <img
            src={trayImg}
            alt="급식판"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
        </div>
        <div className="absolute -bottom-2 -right-2 text-2xl">⏸️</div>
      </div>

      <h1 className="text-3xl font-black tracking-tight text-white drop-shadow-[0_0_12px_rgba(255,255,255,0.5)]">
        잠시 쉬어가기
      </h1>
      <p className="text-sm text-purple-200 font-medium max-w-xs">
        급식실 배식대 앞에서 잠시 숨을 고르고 있습니다. 준비되시면 다시 시작하세요!
      </p>

      <div className="flex flex-col gap-2.5 w-full max-w-xs mt-2">
        <button
          type="button"
          onClick={onResume}
          className="w-full py-3 px-6 rounded-xl font-extrabold text-base text-white bg-gradient-to-r from-pink-500 to-purple-600 shadow-[0_0_18px_rgba(255,79,216,0.6)] hover:brightness-110 active:scale-95 transition-all cursor-pointer border border-white/20"
        >
          계속 리듬 타기 ▶
        </button>
        <button
          type="button"
          onClick={onQuit}
          className="w-full py-2.5 px-6 rounded-xl font-bold text-sm text-purple-200 bg-white/10 hover:bg-white/15 active:scale-95 transition-all cursor-pointer border border-white/15"
        >
          처음 화면으로 🏠
        </button>
      </div>
    </div>
  );
};
