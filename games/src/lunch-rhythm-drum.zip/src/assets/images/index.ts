import bannerImg from './lunch_game_banner_1789882173282.jpg';
import trayImg from './korean_lunch_tray_1789882186495.jpg';
import mascotImg from './lunch_fever_mascot_1789882204541.jpg';

export { bannerImg, trayImg, mascotImg };
