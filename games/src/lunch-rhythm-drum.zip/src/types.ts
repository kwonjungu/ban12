export type Difficulty = 'easy' | 'normal' | 'hard' | 'hell' | 'god';

export type GameMode = 'start' | 'play' | 'pause' | 'result';

export interface Note {
  t: number;
  lane: number;
  approach: number;
  emoji: string;
  isBomb?: boolean;
  judged?: boolean;
}

export interface Beat {
  t: number;
  strong: boolean;
  bpm: number;
}

export interface RingEffect {
  lane: number;
  color: string;
  r: number;
  maxR: number;
  life: number;
}

export interface ParticleEffect {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  size: number;
  life: number;
}

export interface JudgePopup {
  text: string;
  color: string;
  life: number;
}

export interface GameStats {
  score: number;
  combo: number;
  maxCombo: number;
  perfect: number;
  good: number;
  miss: number;
  accuracy: number;
  grade: string;
}
