export type GameState = 'title' | 'play' | 'over';
export type HookState = 'idle' | 'down' | 'up';

export type SpriteKey =
  | 'boat'
  | 'tropicalFish'
  | 'pufferFish'
  | 'giantWhale'
  | 'goldenFish'
  | 'shark'
  | 'trash'
  | 'jellyfish'
  | 'mine'
  | 'turtle'
  | 'shell'
  | 'treasure';

export interface FishType {
  e: string;
  name: string;
  band: number;
  value: number;
  w: number;
  sp: number;
  size: number;
  spriteKey: SpriteKey;
}

export type EntityKind =
  | 'fish'
  | 'trash'
  | 'jellyfish'
  | 'bomb'
  | 'bottle'
  | 'shell'
  | 'turtle'
  | 'crown'
  | 'shark';

export interface GameEntity {
  id: number;
  kind: EntityKind;
  e: string;
  name: string;
  value: number;
  w: number;
  size: number;
  x: number;
  y: number;
  vx: number;
  baseY: number;
  wob: number;
  wobA: number;
  hooked: boolean;
  pop: number;
  gold: boolean;
  band: number;
  life?: number;
  isOpen?: boolean;
  openTimer?: number;
  spriteKey?: SpriteKey;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  life: number;
  t: number;
  c: string;
}

export interface PopText {
  id: number;
  x: number;
  y: number;
  txt: string;
  c: string;
  t: number;
  s: number;
}

export interface Bubble {
  x: number;
  y: number;
  r: number;
  v: number;
  t: number;
}

export interface Cloud {
  x: number;
  y: number;
  s: number;
  v: number;
}
