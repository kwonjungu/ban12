/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import { sounds } from './audio';
import { assetManager, assetPaths } from './assets';
import { GameEntity, Particle, PopText, Bubble, Cloud, FishType, SpriteKey } from './types';
import { Volume2, VolumeX, ArrowLeft, ArrowRight, Anchor, RotateCcw, Play, Sparkles, BookOpen, X, Trophy, ShieldAlert } from 'lucide-react';

const FISH_TYPES: FishType[] = [
  { e: '🐟', name: '멸치/정어리', band: 0, value: 20, w: 0.5, sp: 42, size: 30, spriteKey: 'tropicalFish' },
  { e: '🐠', name: '열대어', band: 0, value: 30, w: 0.7, sp: 52, size: 34, spriteKey: 'tropicalFish' },
  { e: '🐡', name: '가시복어', band: 1, value: 60, w: 1.2, sp: 34, size: 38, spriteKey: 'pufferFish' },
  { e: '🦑', name: '심해오징어', band: 1, value: 90, w: 1.6, sp: 30, size: 38, spriteKey: 'pufferFish' },
  { e: '🐬', name: '돌고래', band: 1, value: 120, w: 1.8, sp: 66, size: 48, spriteKey: 'giantWhale' },
  { e: '🐙', name: '대왕문어', band: 2, value: 180, w: 2.6, sp: 26, size: 46, spriteKey: 'pufferFish' },
  { e: '🐋', name: '향유고래', band: 2, value: 300, w: 4.0, sp: 22, size: 66, spriteKey: 'giantWhale' },
];

const TRASH_INFO = [
  { name: '낡은 장화와 찌그러진 캔', desc: '물고기를 놓치게 하고 40원 감점' },
];

const GOAL_BASE = 180;

export default function App() {
  // Game states for UI
  const [gameState, setGameState] = useState<'title' | 'play' | 'over'>('title');
  const [day, setDay] = useState<number>(1);
  const [lives, setLives] = useState<number>(3);
  const [money, setMoney] = useState<number>(0);
  const [totalMoney, setTotalMoney] = useState<number>(0);
  const [goalMoney, setGoalMoney] = useState<number>(GOAL_BASE);
  const [timeLeft, setTimeLeft] = useState<number>(60);
  const [streak, setStreak] = useState<number>(0);
  const [bestScore, setBestScore] = useState<number>(() => {
    try {
      const v = window.localStorage.getItem('fishingMasterBest');
      const n = parseInt(v || '0', 10);
      return Number.isFinite(n) && n > 0 ? n : 0;
    } catch {
      return 0;
    }
  });
  const [soundEnabled, setSoundEnabled] = useState<boolean>(sounds.enabled);
  const [actionLabel, setActionLabel] = useState<string>('🎣 줄 내리기');
  const [bannerText, setBannerText] = useState<string>('');
  const [bannerKey, setBannerKey] = useState<number>(0);
  const [flashOpacity, setFlashOpacity] = useState<number>(0);

  // Result screen data
  const [overData, setOverData] = useState<{
    success: boolean;
    reason: string;
    icon: string;
    title: string;
    message: string;
    caughtCount: number;
    bonus: number;
    spriteSrc?: string;
  }>({
    success: false,
    reason: '',
    icon: '🏆',
    title: '',
    message: '',
    caughtCount: 0,
    bonus: 0,
  });

  // Guide modal state
  const [showGuide, setShowGuide] = useState<boolean>(false);

  // Canvas & Stage references
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const stageRef = useRef<HTMLDivElement | null>(null);
  const gameOverTimeoutRef = useRef<number | null>(null);

  // Core mutable game engine reference
  const engineRef = useRef({
    idCounter: 1,
    W: 400,
    H: 600,
    waterTop: 110,
    bandY: [110, 250, 420],
    seabed: 580,
    state: 'title' as 'title' | 'play' | 'over',
    hookState: 'idle' as 'idle' | 'down' | 'up',
    day: 1,
    lives: 3,
    money: 0,
    total: 0,
    goal: GOAL_BASE,
    timeLeft: 60,
    elapsed: 0,
    eventTimer: 0,
    eventIdx: 0,
    streak: 0,
    caughtCount: 0,
    bestCatch: 0,
    overLock: 0,
    lastClear: false,
    tickAt: 99,
    shake: 0,
    shakeMag: 0,
    hitstop: 0,
    animT: 0,
    targetX: 200,
    keyL: false,
    keyR: false,
    btnL: false,
    btnR: false,
    pointerX: -1,
    pointerActive: false,
    hook: { x: 200, y: 122, immune: 0, pop: 0, stun: 0 },
    boat: { x: 200, y: 110, bobT: 0 },
    hooked: [] as GameEntity[],
    fishes: [] as GameEntity[],
    particles: [] as Particle[],
    pops: [] as PopText[],
    bubbles: [] as Bubble[],
    clouds: [] as Cloud[],
  });

  // Show banner utility
  const showBanner = useCallback((txt: string) => {
    setBannerText(txt);
    setBannerKey((k) => k + 1);
  }, []);

  // Flash screen utility
  const triggerFlash = useCallback((alpha = 0.5) => {
    setFlashOpacity(alpha);
    window.setTimeout(() => setFlashOpacity(0), 180);
  }, []);

  // Sync React state with Engine state
  const syncReactState = useCallback(() => {
    const e = engineRef.current;
    setDay(e.day);
    setLives(e.lives);
    setMoney(e.money);
    setGoalMoney(e.goal);
    setTimeLeft(Math.max(0, Math.ceil(e.timeLeft)));
    setStreak(e.streak);

    if (e.hookState === 'idle') setActionLabel('🎣 줄 내리기');
    else if (e.hookState === 'down') setActionLabel('⬆️ 당기기!');
    else setActionLabel('⏳ 올리는 중');
  }, []);

  // Trigger sound engine toggle
  const toggleSound = () => {
    const s = sounds.toggle();
    setSoundEnabled(s);
  };

  // Layout & Spawning
  const computeLayout = (w: number, h: number) => {
    const e = engineRef.current;
    e.waterTop = Math.round(h * 0.19);
    const wh = h - e.waterTop;
    e.bandY[0] = e.waterTop + wh * 0.3;
    e.bandY[1] = e.waterTop + wh * 0.62;
    e.bandY[2] = h;
    e.seabed = h - 16;
    e.boat.y = e.waterTop;
  };

  const bandTop = (b: number) => {
    const e = engineRef.current;
    return b === 0 ? e.waterTop + 24 : e.bandY[b - 1];
  };

  const bandBot = (b: number) => {
    const e = engineRef.current;
    return b === 2 ? e.seabed - 16 : e.bandY[b];
  };

  const speedMultiplier = () => {
    const e = engineRef.current;
    return 1 + (e.day - 1) * 0.12 + Math.min(e.elapsed, 180) * 0.0012;
  };

  const spawnFish = (band: number, atEdge: boolean): GameEntity => {
    const e = engineRef.current;
    const pool = FISH_TYPES.filter((f) => f.band === band);
    const t = pool[Math.floor(Math.random() * pool.length)];
    const top = bandTop(band);
    const bot = bandBot(band);
    const f: GameEntity = {
      id: e.idCounter++,
      kind: 'fish',
      e: t.e,
      name: t.name,
      value: t.value,
      w: t.w,
      size: t.size,
      x: atEdge ? (Math.random() < 0.5 ? -30 : e.W + 30) : 20 + Math.random() * (e.W - 40),
      y: top + Math.random() * Math.max(20, bot - top),
      vx: (Math.random() < 0.5 ? -1 : 1) * t.sp * (0.75 + Math.random() * 0.55) * speedMultiplier(),
      baseY: 0,
      wob: Math.random() * 6.28,
      wobA: 4 + Math.random() * 8,
      hooked: false,
      pop: 0,
      gold: false,
      band,
      spriteKey: t.spriteKey,
    };
    f.baseY = f.y;
    e.fishes.push(f);
    return f;
  };

  const spawnTrash = () => {
    const e = engineRef.current;
    const band = Math.floor(Math.random() * 3);
    const top = bandTop(band);
    const bot = bandBot(band);
    const f: GameEntity = {
      id: e.idCounter++,
      kind: 'trash',
      e: '🗑️',
      name: '해양 쓰레기',
      value: -40,
      w: 1.4,
      size: 34,
      x: 20 + Math.random() * (e.W - 40),
      y: top + Math.random() * Math.max(20, bot - top),
      vx: (Math.random() < 0.5 ? -1 : 1) * 14,
      baseY: 0,
      wob: Math.random() * 6.28,
      wobA: 3,
      hooked: false,
      pop: 0,
      gold: false,
      band,
      spriteKey: 'trash',
    };
    f.baseY = f.y;
    e.fishes.push(f);
  };

  const spawnShark = () => {
    const e = engineRef.current;
    const f: GameEntity = {
      id: e.idCounter++,
      kind: 'shark',
      e: '🦈',
      name: '식인 백상아리',
      value: 0,
      w: 0,
      size: 58,
      x: Math.random() < 0.5 ? -60 : e.W + 60,
      y: e.bandY[0] + Math.random() * Math.max(30, e.seabed - 26 - e.bandY[0]),
      vx: (Math.random() < 0.5 ? -1 : 1) * (62 + Math.random() * 24) * speedMultiplier(),
      baseY: 0,
      wob: Math.random() * 6.28,
      wobA: 6,
      hooked: false,
      pop: 0,
      gold: false,
      band: 2,
      spriteKey: 'shark',
    };
    f.baseY = f.y;
    f.vx = (f.x < 0 ? 1 : -1) * Math.abs(f.vx);
    e.fishes.push(f);
  };

  const spawnGoldFish = () => {
    const e = engineRef.current;
    const f: GameEntity = {
      id: e.idCounter++,
      kind: 'fish',
      e: '✨',
      name: '황금 잉어',
      value: 400,
      w: 1.0,
      size: 44,
      x: Math.random() * e.W,
      y: e.bandY[0] + Math.random() * (e.bandY[1] - e.bandY[0]),
      vx: (Math.random() < 0.5 ? -1 : 1) * 115,
      baseY: 0,
      wob: Math.random() * 6.28,
      wobA: 10,
      hooked: false,
      pop: 0,
      gold: true,
      life: 24,
      band: 1,
      spriteKey: 'goldenFish',
    };
    f.baseY = f.y;
    e.fishes.push(f);
  };

  const spawnTreasureChest = () => {
    const e = engineRef.current;
    const f: GameEntity = {
      id: e.idCounter++,
      kind: 'fish',
      e: '💎',
      name: '해저 보물상자',
      value: 600,
      w: 4.5,
      size: 46,
      x: 40 + Math.random() * (e.W - 80),
      y: e.seabed - 20,
      vx: (Math.random() < 0.5 ? -1 : 1) * 8,
      baseY: 0,
      wob: Math.random() * 6.28,
      wobA: 2,
      hooked: false,
      pop: 0,
      gold: true,
      life: 35,
      band: 2,
      spriteKey: 'treasure',
    };
    f.baseY = f.y;
    e.fishes.push(f);
  };

  const spawnJellyfish = () => {
    const e = engineRef.current;
    const f: GameEntity = {
      id: e.idCounter++,
      kind: 'jellyfish',
      e: '🪼',
      name: '전기 해파리',
      value: 0,
      w: 0,
      size: 42,
      x: Math.random() < 0.5 ? -40 : e.W + 40,
      y: e.bandY[0] + Math.random() * (e.bandY[1] - e.bandY[0]),
      vx: (Math.random() < 0.5 ? -1 : 1) * 35 * speedMultiplier(),
      baseY: 0,
      wob: Math.random() * 6.28,
      wobA: 12,
      hooked: false,
      pop: 0,
      gold: false,
      band: 1,
      spriteKey: 'jellyfish',
    };
    f.baseY = f.y;
    e.fishes.push(f);
  };

  const spawnBomb = () => {
    const e = engineRef.current;
    const f: GameEntity = {
      id: e.idCounter++,
      kind: 'bomb',
      e: '💣',
      name: '심해 기뢰',
      value: 0,
      w: 0,
      size: 40,
      x: 30 + Math.random() * (e.W - 60),
      y: e.bandY[1] + Math.random() * (e.seabed - 30 - e.bandY[1]),
      vx: (Math.random() < 0.5 ? -1 : 1) * 12,
      baseY: 0,
      wob: Math.random() * 6.28,
      wobA: 4,
      hooked: false,
      pop: 0,
      gold: false,
      band: 2,
      spriteKey: 'mine',
    };
    f.baseY = f.y;
    e.fishes.push(f);
  };

  const spawnBottle = () => {
    const e = engineRef.current;
    const f: GameEntity = {
      id: e.idCounter++,
      kind: 'bottle',
      e: '🍾',
      name: '보물 유리병',
      value: 0,
      w: 0.8,
      size: 36,
      x: Math.random() < 0.5 ? -30 : e.W + 30,
      y: e.waterTop + 20 + Math.random() * (e.bandY[0] - e.waterTop - 15),
      vx: (Math.random() < 0.5 ? -1 : 1) * 24,
      baseY: 0,
      wob: Math.random() * 6.28,
      wobA: 6,
      hooked: false,
      pop: 0,
      gold: true,
      band: 0,
      spriteKey: 'treasure',
    };
    f.baseY = f.y;
    e.fishes.push(f);
  };

  const spawnShell = () => {
    const e = engineRef.current;
    const f: GameEntity = {
      id: e.idCounter++,
      kind: 'shell',
      e: '🐚',
      name: '진주조개',
      value: 300,
      w: 1.2,
      size: 38,
      x: 40 + Math.random() * (e.W - 80),
      y: e.seabed - 18,
      vx: 0,
      baseY: e.seabed - 18,
      wob: 0,
      wobA: 0,
      hooked: false,
      pop: 0,
      gold: true,
      band: 2,
      isOpen: false,
      openTimer: 1.5 + Math.random() * 2,
      spriteKey: 'shell',
    };
    e.fishes.push(f);
  };

  const spawnTurtle = () => {
    const e = engineRef.current;
    const f: GameEntity = {
      id: e.idCounter++,
      kind: 'turtle',
      e: '🐢',
      name: '바다거북',
      value: 250,
      w: 1.8,
      size: 46,
      x: Math.random() < 0.5 ? -40 : e.W + 40,
      y: e.bandY[0] + Math.random() * (e.bandY[1] - e.bandY[0] - 20),
      vx: (Math.random() < 0.5 ? -1 : 1) * 26,
      baseY: 0,
      wob: Math.random() * 6.28,
      wobA: 8,
      hooked: false,
      pop: 0,
      gold: true,
      band: 1,
      spriteKey: 'turtle',
    };
    f.baseY = f.y;
    e.fishes.push(f);
  };

  const spawnCrown = () => {
    const e = engineRef.current;
    const f: GameEntity = {
      id: e.idCounter++,
      kind: 'crown',
      e: '👑',
      name: '심해 왕관',
      value: 500,
      w: 3.0,
      size: 40,
      x: 30 + Math.random() * (e.W - 60),
      y: e.seabed - 16,
      vx: (Math.random() < 0.5 ? -1 : 1) * 10,
      baseY: e.seabed - 16,
      wob: 0,
      wobA: 2,
      hooked: false,
      pop: 0,
      gold: true,
      band: 2,
      spriteKey: 'treasure',
    };
    e.fishes.push(f);
  };

  const refillWorld = (atEdge: boolean) => {
    const e = engineRef.current;
    const cnt = [0, 0, 0];
    let tr = 0,
      sh = 0,
      jf = 0,
      bm = 0,
      tt = 0,
      bt = 0;

    for (let i = 0; i < e.fishes.length; i++) {
      const f = e.fishes[i];
      if (f.hooked) continue;
      if (f.kind === 'trash') tr++;
      else if (f.kind === 'shark') sh++;
      else if (f.kind === 'jellyfish') jf++;
      else if (f.kind === 'bomb') bm++;
      else if (f.kind === 'turtle') tt++;
      else if (f.kind === 'bottle') bt++;
      else if (!f.gold) cnt[f.band]++;
    }

    const wantCount = (band: number) => {
      if (band === 0) return 6;
      if (band === 1) return 4 + Math.min(2, Math.floor(e.day / 2));
      return 2 + Math.min(2, Math.floor(e.day / 2));
    };
    const wantTrash = 2 + Math.min(3, e.day - 1);
    const wantShark = e.day <= 1 ? 0 : Math.min(2, e.day - 1);

    for (let b = 0; b < 3; b++) {
      const need = wantCount(b) - cnt[b];
      for (let i = 0; i < need; i++) spawnFish(b, atEdge);
    }
    for (let i = 0; i < wantTrash - tr; i++) spawnTrash();
    for (let i = 0; i < wantShark - sh; i++) spawnShark();
    if (tt < 1) spawnTurtle();
    if (bt < 1) spawnBottle();
    if (jf < 1 && e.day >= 2) spawnJellyfish();
    if (bm < 1 && e.day >= 2 && Math.random() < 0.6) spawnBomb();
    if (Math.random() < 0.35) spawnShell();
  };

  const addParticles = (x: number, y: number, n: number, color: string, spd: number, life = 0.7) => {
    const e = engineRef.current;
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      const s = spd * (0.35 + Math.random());
      e.particles.push({
        x,
        y,
        vx: Math.cos(a) * s,
        vy: Math.sin(a) * s - spd * 0.35,
        r: 2 + Math.random() * 3.5,
        life,
        t: life,
        c: color,
      });
    }
  };

  const addPop = (x: number, y: number, txt: string, color: string, size = 20) => {
    const e = engineRef.current;
    e.pops.push({
      id: e.idCounter++,
      x,
      y,
      txt,
      c: color,
      t: 1.05,
      s: size,
    });
  };

  const doShake = (mag: number, dur: number) => {
    const e = engineRef.current;
    e.shakeMag = Math.max(e.shakeMag, mag);
    e.shake = Math.max(e.shake, dur);
  };

  // Day Lifecycle
  const startDay = useCallback(() => {
    const e = engineRef.current;
    e.state = 'play';
    setGameState('play');
    if (gameOverTimeoutRef.current) {
      window.clearTimeout(gameOverTimeoutRef.current);
      gameOverTimeoutRef.current = null;
    }

    e.goal = Math.round((GOAL_BASE * Math.pow(1.5, e.day - 1)) / 10) * 10;
    e.timeLeft = Math.max(42, 62 - e.day * 2);
    e.money = 0;
    e.streak = 0;
    e.caughtCount = 0;
    e.hookState = 'idle';
    e.hooked = [];
    e.hook.immune = 0;
    e.hook.pop = 0;
    e.hook.stun = 0;
    e.fishes = [];
    e.particles = [];
    e.pops = [];
    e.targetX = e.W / 2;
    e.boat.x = e.W / 2;
    e.hook.x = e.W / 2;
    e.hook.y = e.boat.y + 12;

    refillWorld(false);

    // Initial boost of fish near the boat
    for (let i = 0; i < 3; i++) {
      const f = spawnFish(0, false);
      f.x = e.W / 2 + (i - 1) * 44 + (Math.random() * 16 - 8);
      f.y = e.waterTop + 40 + i * 14;
      f.baseY = f.y;
    }

    e.tickAt = 99;
    syncReactState();
    showBanner(`${e.day}일차 시작! 목표 ${e.goal}원`);
    sounds.start();
  }, [syncReactState, showBanner]);

  const startGame = useCallback(() => {
    const e = engineRef.current;
    e.day = 1;
    e.lives = 3;
    e.total = 0;
    e.bestCatch = 0;
    e.eventIdx = 0;
    e.elapsed = 0;
    e.eventTimer = 0;
    startDay();
  }, [startDay]);

  const nextDay = useCallback(() => {
    const e = engineRef.current;
    e.day++;
    startDay();
  }, [startDay]);

  const finishDay = useCallback(() => {
    const e = engineRef.current;
    const bonus = Math.round(Math.max(0, e.timeLeft) * 5);
    e.total += e.money + bonus;
    e.lastClear = true;
    e.state = 'over';
    e.overLock = window.performance.now() + 650;
    e.hookState = 'idle';

    if (e.total > bestScore) {
      setBestScore(e.total);
      try {
        window.localStorage.setItem('fishingMasterBest', String(e.total));
      } catch {}
    }

    setOverData({
      success: true,
      reason: 'clear',
      icon: '🏆',
      title: `${e.day}일차 조업 성공!`,
      message: `🐟 ${e.caughtCount}마리 어획 성공! 시간 보너스 +${bonus}원 획득!`,
      caughtCount: e.caughtCount,
      bonus,
      spriteSrc: assetPaths.treasure,
    });
    setGameState('over');
    syncReactState();
    sounds.clear();
    triggerFlash(0.55);
  }, [bestScore, syncReactState, triggerFlash]);

  const gameOver = useCallback(
    (reason: string) => {
      const e = engineRef.current;
      e.state = 'over';
      e.overLock = window.performance.now() + 650;
      e.lastClear = false;
      e.hookState = 'idle';
      e.total += e.money;

      const wasBest = e.total > bestScore;
      if (wasBest) {
        setBestScore(e.total);
        try {
          window.localStorage.setItem('fishingMasterBest', String(e.total));
        } catch {}
      }

      let icon = '⏰';
      let title = `${e.day}일차 조업 실패...`;
      let miss = '';
      let spriteSrc: string | undefined;

      if (reason === 'shark') {
        icon = '🦈';
        title = '줄이 끊어져 버렸다!';
        miss = '거대 상어에게 낚싯줄이 뜯겼습니다. 상어가 오면 즉시 줄을 감아 피하세요!';
        spriteSrc = assetPaths.shark;
      } else if (reason === 'bomb') {
        icon = '💥';
        title = '기뢰 폭발로 조업 중단!';
        miss = '심해에 도사린 폭탄 기뢰를 건드리지 않도록 주의하세요!';
        spriteSrc = assetPaths.mine;
      } else {
        if (wasBest) {
          miss = '🎉 대단합니다! 신기록을 달성했습니다!';
          spriteSrc = assetPaths.goldenFish;
        } else {
          const diff = Math.max(0, e.goal - e.money);
          miss = `목표 금액까지 ${diff}원이 부족했습니다. 다음 번엔 큰 물고기를 노려보세요!`;
          spriteSrc = assetPaths.tropicalFish;
        }
      }

      setOverData({
        success: false,
        reason,
        icon,
        title,
        message: miss,
        caughtCount: e.caughtCount,
        bonus: 0,
        spriteSrc,
      });
      setGameState('over');
      syncReactState();
      sounds.over();
      doShake(18, 0.5);
    },
    [bestScore, syncReactState]
  );

  // Actions
  const castLine = useCallback(() => {
    const e = engineRef.current;
    e.hookState = 'down';
    e.hook.y = e.boat.y + 12;
    sounds.cast();
    addParticles(e.hook.x, e.waterTop, 8, '#bfe9ff', 90, 0.5);
    syncReactState();
  }, [syncReactState]);

  const reelUp = useCallback(() => {
    const e = engineRef.current;
    e.hookState = 'up';
    syncReactState();
  }, [syncReactState]);

  const pressAction = useCallback(() => {
    sounds.init();
    const e = engineRef.current;

    if (e.state === 'title') {
      startGame();
      return;
    }
    if (e.state === 'over') {
      if (window.performance.now() < e.overLock) return;
      if (e.lastClear) nextDay();
      else startGame();
      return;
    }
    if (e.state !== 'play') return;

    if (e.hookState === 'idle') castLine();
    else if (e.hookState === 'down') reelUp();
  }, [startGame, nextDay, castLine, reelUp]);

  const totalWeight = () => {
    const e = engineRef.current;
    return e.hooked.reduce((acc, f) => acc + f.w, 0);
  };

  const catchThing = (f: GameEntity) => {
    const e = engineRef.current;
    f.hooked = true;
    f.pop = 1;
    e.hooked.push(f);
    e.hook.pop = 1;

    if (f.kind === 'trash') {
      sounds.trash();
      addParticles(f.x, f.y, 10, '#9aa7b0', 90, 0.6);
      addPop(f.x, f.y - 18, '쓰레기 -40', '#ff9f9f', 17);
      doShake(6, 0.2);
      e.hitstop = 0.05;
    } else {
      sounds.hook(Math.min(e.hooked.length - 1, 9));
      addParticles(f.x, f.y, 14, f.gold ? '#ffe27a' : '#bfe9ff', 120, 0.6);
      addPop(f.x, f.y - 20, `+${f.value}`, f.gold ? '#ffe27a' : '#b6ffd0', f.gold ? 24 : 19);
      doShake(f.gold ? 10 : 5 + f.w * 1.6, 0.22);
      e.hitstop = f.gold ? 0.08 : 0.045;
      if (f.gold) triggerFlash(0.3);
    }
    reelUp();
  };

  const snapLine = () => {
    const e = engineRef.current;
    e.lives--;
    // Cleanly unhook without corrupting array
    const toRemoveIds = new Set(e.hooked.map((h) => h.id));
    e.fishes = e.fishes.filter((item) => !toRemoveIds.has(item.id));
    e.hooked = [];

    e.hookState = 'up';
    e.hook.immune = 1.4;
    e.streak = 0;

    sounds.shark();
    doShake(20, 0.55);
    triggerFlash(0.5);
    e.hitstop = 0.09;
    addParticles(e.hook.x, e.hook.y, 24, '#ff6b6b', 170, 0.8);
    addPop(e.hook.x, e.hook.y - 26, '줄이 끊어졌다!', '#ff8a8a', 22);
    showBanner('🦈 상어에게 물려 줄이 끊어졌습니다!');
    syncReactState();

    if (e.lives <= 0) {
      gameOverTimeoutRef.current = window.setTimeout(() => {
        if (e.state === 'play') gameOver('shark');
      }, 420);
    }
  };

  const cashIn = () => {
    const e = engineRef.current;
    if (e.hooked.length === 0) {
      e.streak = 0;
      syncReactState();
      return;
    }

    let sum = 0;
    let n = 0;
    let hasFish = false;

    for (let i = 0; i < e.hooked.length; i++) {
      sum += e.hooked[i].value;
      if (e.hooked[i].kind !== 'trash') {
        n++;
        hasFish = true;
      }
    }

    if (hasFish && sum > 0) {
      if (n > e.bestCatch) e.bestCatch = n;
      e.streak++;
      const comboMul = 1 + (n - 1) * 0.5;
      const streakMul = 1 + Math.min(e.streak - 1, 8) * 0.1;
      const gain = Math.round(sum * comboMul * streakMul);
      e.money += gain;
      e.caughtCount += n;

      addPop(e.boat.x, e.boat.y - 34, `+${gain}원`, '#ffe27a', 26);
      if (n >= 2) addPop(e.boat.x, e.boat.y - 62, `${n}마리 콤보! x${comboMul.toFixed(1)}`, '#ffd0f5', 18);
      if (e.streak >= 3) addPop(e.boat.x, e.boat.y - 84, `🔥${e.streak}연속 x${streakMul.toFixed(1)}`, '#ff9f5a', 16);

      addParticles(e.boat.x, e.boat.y - 10, 16 + n * 4, '#ffe27a', 150, 0.8);
      doShake(6 + n * 2, 0.25);
      sounds.coin(n + Math.min(e.streak, 3));
    } else {
      e.money += sum;
      if (e.money < 0) e.money = 0;
      e.streak = 0;
      addPop(e.boat.x, e.boat.y - 34, `${sum}원`, '#ff9f9f', 22);
    }

    // Cleanly remove hooked fishes
    const hookedIds = new Set(e.hooked.map((h) => h.id));
    e.fishes = e.fishes.filter((item) => !hookedIds.has(item.id));
    e.hooked = [];

    refillWorld(true);
    syncReactState();

    if (e.money >= e.goal) finishDay();
  };

  const fireRandomEvent = () => {
    const e = engineRef.current;
    const events = [
      {
        t: '🌟 황금 물고기 등장! 400원 가치!',
        run: () => {
          spawnGoldFish();
          spawnGoldFish();
        },
      },
      {
        t: '🪼 전기 해파리 떼 출현! 감전 조심!',
        run: () => {
          spawnJellyfish();
          spawnJellyfish();
        },
      },
      {
        t: '🍾 바다에서 보물병이 떠내려왔다!',
        run: () => {
          spawnBottle();
        },
      },
      {
        t: '🐠 열대어 떼가 몰려왔다!',
        run: () => {
          for (let i = 0; i < 7; i++) spawnFish(i % 2, true);
        },
      },
      {
        t: '💣 위협적인 심해 기뢰 주의!',
        run: () => {
          spawnBomb();
        },
      },
      {
        t: '🐢 행운의 바다거북 등장!',
        run: () => {
          spawnTurtle();
        },
      },
      {
        t: '👑 고대 해저 왕관 발견!',
        run: () => {
          spawnCrown();
        },
      },
      {
        t: '💎 해저 보물상자 발견! 600원!',
        run: () => {
          spawnTreasureChest();
        },
      },
    ];

    const ev = events[e.eventIdx % events.length];
    e.eventIdx++;
    ev.run();
    showBanner(ev.t);
    sounds.event();
    triggerFlash(0.22);
  };

  // Main Simulation Update Loop
  const updateEngine = (dt: number) => {
    const e = engineRef.current;
    e.animT += dt;

    if (e.shake > 0) {
      e.shake -= dt;
      if (e.shake <= 0) {
        e.shake = 0;
        e.shakeMag = 0;
      }
    }

    // Clouds drift
    for (let c = 0; c < e.clouds.length; c++) {
      const cl = e.clouds[c];
      cl.x += cl.v * dt;
      if (cl.x > e.W + 60) cl.x = -60;
    }

    if (e.hitstop > 0) {
      e.hitstop -= dt;
      return;
    }

    // Controls input to targetX
    let dir = 0;
    if (e.keyL || e.btnL) dir -= 1;
    if (e.keyR || e.btnR) dir += 1;
    if (dir !== 0) e.targetX += dir * 320 * dt;
    if (e.pointerActive && e.pointerX >= 0) e.targetX = e.pointerX;
    if (e.targetX < 14) e.targetX = 14;
    if (e.targetX > e.W - 14) e.targetX = e.W - 14;

    // Bubbles, Particles, Pops update
    for (let i = e.bubbles.length - 1; i >= 0; i--) {
      const b = e.bubbles[i];
      b.y -= b.v * dt;
      b.x += Math.sin(b.y * 0.08) * 12 * dt;
      b.t -= dt * 0.6;
      if (b.y < e.waterTop || b.t <= 0) e.bubbles.splice(i, 1);
    }
    for (let i = e.particles.length - 1; i >= 0; i--) {
      const p = e.particles[i];
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vy += 120 * dt;
      p.t -= dt;
      if (p.t <= 0) e.particles.splice(i, 1);
    }
    for (let i = e.pops.length - 1; i >= 0; i--) {
      const p = e.pops[i];
      p.y -= 28 * dt;
      p.t -= dt;
      if (p.t <= 0) e.pops.splice(i, 1);
    }

    if (e.hook.stun > 0) {
      e.hook.stun -= dt;
      if (e.hook.stun < 0) e.hook.stun = 0;
    }

    if (e.state === 'title') {
      e.boat.x += (e.W / 2 - e.boat.x) * Math.min(1, dt * 2);
      e.hook.x = e.boat.x;
      e.hook.y = e.boat.y + 12;
      updateFishes(dt, false);
      e.boat.bobT += dt;
      return;
    }
    if (e.state !== 'play') {
      e.boat.bobT += dt;
      updateFishes(dt, false);
      return;
    }

    e.boat.bobT += dt;
    e.timeLeft -= dt;
    e.elapsed += dt;
    e.eventTimer += dt;
    if (e.eventTimer >= 28) {
      e.eventTimer -= 28;
      fireRandomEvent();
    }

    if (e.timeLeft <= 5.4 && e.timeLeft > 0) {
      const sec = Math.ceil(e.timeLeft);
      if (sec !== e.tickAt) {
        e.tickAt = sec;
        sounds.tick();
      }
    }
    if (e.timeLeft <= 0) {
      e.timeLeft = 0;
      syncReactState();
      gameOver('time');
      return;
    }

    // Boat and hook positions
    if (e.hookState === 'idle') {
      e.boat.x += (e.targetX - e.boat.x) * Math.min(1, dt * 9);
      if (e.boat.x < 30) e.boat.x = 30;
      if (e.boat.x > e.W - 30) e.boat.x = e.W - 30;
      e.hook.x = e.boat.x;
      e.hook.y = e.boat.y + 12 + Math.sin(e.boat.bobT * 2.4) * 2;
    } else if (e.hook.stun <= 0) {
      const maxSpd = 300 / (1 + totalWeight() * 0.35);
      const dx = e.targetX - e.hook.x;
      const mv = Math.max(-maxSpd * dt, Math.min(maxSpd * dt, dx));
      e.hook.x += mv;
      if (e.hook.x < 12) e.hook.x = 12;
      if (e.hook.x > e.W - 12) e.hook.x = e.W - 12;
    }

    if (e.hook.stun <= 0) {
      if (e.hookState === 'down') {
        e.hook.y += 300 * dt;
        if (e.hook.y >= e.seabed) {
          e.hook.y = e.seabed;
          reelUp();
        }
      } else if (e.hookState === 'up') {
        let rs = 330 / (1 + totalWeight() * 0.55);
        if (rs < 55) rs = 55;
        e.hook.y -= rs * dt;
        if (e.hook.y <= e.boat.y + 12) {
          e.hook.y = e.boat.y + 12;
          e.hookState = 'idle';
          cashIn();
        }
      }
    }

    if (e.hook.immune > 0) e.hook.immune -= dt;
    if (e.hook.pop > 0) {
      e.hook.pop -= dt * 3.4;
      if (e.hook.pop < 0) e.hook.pop = 0;
    }

    updateFishes(dt, true);

    if (e.hookState !== 'idle' && Math.random() < dt * 12) {
      e.bubbles.push({
        x: e.hook.x + (Math.random() * 10 - 5),
        y: e.hook.y,
        r: 1.5 + Math.random() * 2.5,
        v: 22 + Math.random() * 24,
        t: 1,
      });
    }

    // Sync state to UI periodically
    syncReactState();
  };

  const updateFishes = (dt: number, canCatch: boolean) => {
    const e = engineRef.current;
    const hx = e.hook.x;
    const hy = e.hook.y;

    const removedEntityIds = new Set<number>();

    for (let i = e.fishes.length - 1; i >= 0; i--) {
      const f = e.fishes[i];
      if (f.pop > 0) {
        f.pop -= dt * 3;
        if (f.pop < 0) f.pop = 0;
      }

      if (f.kind === 'shell') {
        f.openTimer = (f.openTimer || 2) - dt;
        if (f.openTimer <= 0) {
          f.isOpen = !f.isOpen;
          f.openTimer = f.isOpen ? 2.0 : 2.5;
        }
      }

      if (f.hooked) {
        const idx = e.hooked.indexOf(f);
        const tx = hx;
        const ty = hy + 18 + idx * 22;
        f.x += (tx - f.x) * Math.min(1, dt * 18);
        f.y += (ty - f.y) * Math.min(1, dt * 18);
        continue;
      }

      if (f.gold && f.kind === 'fish' && f.life !== undefined) {
        f.life -= dt;
        if (f.life <= 0) {
          removedEntityIds.add(f.id);
          continue;
        }
      }

      f.wob += dt * 3.2;
      f.y = f.baseY + Math.sin(f.wob) * f.wobA;
      f.x += f.vx * dt;

      if (f.vx < 0 && f.x < -70) {
        if (f.gold) removedEntityIds.add(f.id);
        else {
          f.x = e.W + 60;
          f.y = f.baseY = bandTop(f.band) + Math.random() * (bandBot(f.band) - bandTop(f.band));
        }
      } else if (f.vx > 0 && f.x > e.W + 70) {
        if (f.gold) removedEntityIds.add(f.id);
        else {
          f.x = -60;
          f.y = f.baseY = bandTop(f.band) + Math.random() * (bandBot(f.band) - bandTop(f.band));
        }
      }

      if (canCatch && e.hookState !== 'idle' && e.hook.immune <= 0 && e.hook.stun <= 0 && !f.hooked) {
        const dist = Math.hypot(f.x - hx, f.y - hy);
        const hitR = f.size * 0.48 + 12;

        if (dist < hitR) {
          if (f.kind === 'shark') {
            snapLine();
            break;
          } else if (f.kind === 'jellyfish') {
            sounds.zap();
            e.hook.stun = 1.2;
            for (const h of e.hooked) removedEntityIds.add(h.id);
            e.hooked = [];
            addPop(hx, hy - 20, '⚡ 감전! 물고기를 놓쳤다!', '#79f2ff', 20);
            addParticles(hx, hy, 20, '#79f2ff', 160, 0.6);
            doShake(10, 0.3);
            reelUp();
            break;
          } else if (f.kind === 'bomb') {
            sounds.explode();
            e.lives--;
            for (const h of e.hooked) removedEntityIds.add(h.id);
            e.hooked = [];
            removedEntityIds.add(f.id);
            addPop(hx, hy - 20, '💥 기뢰 폭발!', '#ff4d4d', 24);
            addParticles(hx, hy, 32, '#ff7b00', 220, 0.8);
            doShake(24, 0.6);
            triggerFlash(0.6);
            syncReactState();
            reelUp();
            if (e.lives <= 0) {
              gameOverTimeoutRef.current = window.setTimeout(() => {
                if (e.state === 'play') gameOver('bomb');
              }, 420);
            }
            break;
          } else if (f.kind === 'shell') {
            if (f.isOpen) {
              catchThing(f);
            } else {
              sounds.trash();
              addPop(f.x, f.y - 20, '단단해서 튕겨나갔다!', '#b0c4de', 16);
              addParticles(f.x, f.y, 8, '#ffffff', 80, 0.4);
              e.hook.y = Math.max(e.boat.y + 20, e.hook.y - 25);
              reelUp();
            }
          } else if (f.kind === 'bottle') {
            removedEntityIds.add(f.id);
            sounds.bonus();
            const rnd = Math.random();
            if (rnd < 0.35) {
              e.timeLeft += 12;
              addPop(hx, hy - 20, '🍾 보물 유리병: ⏱ 시간 +12초!', '#79f2ff', 22);
              showBanner('🍾 보물 유리병 획득! +12초');
            } else if (rnd < 0.7) {
              e.money += 300;
              addPop(hx, hy - 20, '🍾 보물 유리병: 💰 +300원!', '#ffe27a', 22);
              showBanner('🍾 보물 유리병 획득! +300원');
            } else if (rnd < 0.85) {
              if (e.lives < 3) e.lives++;
              addPop(hx, hy - 20, '🍾 보물 유리병: ❤️ 체력 회복!', '#ff8a8a', 22);
              showBanner('🍾 보물 유리병 획득! ❤️ 체력 회복');
            } else {
              spawnCrown();
              addPop(hx, hy - 20, '🗺️ 보물 지도 발견! 👑 왕관 등장!', '#ffd0f5', 22);
              showBanner('🗺️ 보물 지도! 심해에 왕관 생성!');
            }
            addParticles(hx, hy, 22, '#ffe27a', 150, 0.8);
            syncReactState();
            reelUp();
            break;
          } else if (f.kind === 'turtle') {
            e.timeLeft += 8;
            addPop(hx, hy - 36, '🐢 바다거북! ⏱ 시간 +8초!', '#79f2ff', 20);
            showBanner('🐢 장수 바다거북 낚음! +8초');
            catchThing(f);
          } else {
            catchThing(f);
          }
        }
      }
    }

    if (removedEntityIds.size > 0) {
      e.fishes = e.fishes.filter((item) => !removedEntityIds.has(item.id));
    }
  };

  // Canvas Drawing Routine
  const drawEngine = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const e = engineRef.current;
    const W = e.W;
    const H = e.H;

    ctx.save();
    ctx.clearRect(0, 0, W, H);

    // Screen Shake effect
    if (e.shake > 0) {
      const rx = (Math.random() * 2 - 1) * e.shakeMag;
      const ry = (Math.random() * 2 - 1) * e.shakeMag;
      ctx.translate(rx, ry);
    }

    // 1. Sky
    const skyGrad = ctx.createLinearGradient(0, 0, 0, e.waterTop);
    skyGrad.addColorStop(0, '#0f2f4c');
    skyGrad.addColorStop(1, '#3478a8');
    ctx.fillStyle = skyGrad;
    ctx.fillRect(0, 0, W, e.waterTop);

    // Clouds
    ctx.fillStyle = 'rgba(255,255,255,0.48)';
    for (let c = 0; c < e.clouds.length; c++) {
      const cl = e.clouds[c];
      ctx.beginPath();
      ctx.arc(cl.x, cl.y, 14 * cl.s, 0, Math.PI * 2);
      ctx.arc(cl.x + 12 * cl.s, cl.y - 4 * cl.s, 10 * cl.s, 0, Math.PI * 2);
      ctx.arc(cl.x + 22 * cl.s, cl.y, 12 * cl.s, 0, Math.PI * 2);
      ctx.fill();
    }

    // 2. Sea gradient (3 depths)
    const seaGrad = ctx.createLinearGradient(0, e.waterTop, 0, H);
    seaGrad.addColorStop(0, '#16638d');
    seaGrad.addColorStop(0.35, '#0b4267');
    seaGrad.addColorStop(0.7, '#06263e');
    seaGrad.addColorStop(1, '#02101b');
    ctx.fillStyle = seaGrad;
    ctx.fillRect(0, e.waterTop, W, H - e.waterTop);

    // Underwater Sun Rays
    ctx.save();
    ctx.fillStyle = 'rgba(255,255,255,0.04)';
    ctx.beginPath();
    ctx.moveTo(W * 0.2, e.waterTop);
    ctx.lineTo(W * 0.36, H);
    ctx.lineTo(W * 0.58, H);
    ctx.lineTo(W * 0.36, e.waterTop);
    ctx.fill();
    ctx.restore();

    // Seabed
    ctx.fillStyle = '#010a12';
    ctx.beginPath();
    ctx.moveTo(0, H);
    ctx.lineTo(0, e.seabed + 4);
    for (let sx = 0; sx <= W; sx += 28) {
      ctx.lineTo(sx, e.seabed + Math.sin(sx * 0.05) * 6);
    }
    ctx.lineTo(W, H);
    ctx.fill();

    // Water Surface Waves
    ctx.fillStyle = 'rgba(255,255,255,0.24)';
    ctx.beginPath();
    ctx.moveTo(0, e.waterTop);
    for (let wx = 0; wx <= W; wx += 18) {
      ctx.lineTo(wx, e.waterTop + Math.sin(wx * 0.045 + e.animT * 3.2) * 3);
    }
    ctx.lineTo(W, e.waterTop + 6);
    ctx.lineTo(0, e.waterTop + 6);
    ctx.fill();

    // 3. Bubbles
    ctx.fillStyle = 'rgba(255,255,255,0.48)';
    for (let bIdx = 0; bIdx < e.bubbles.length; bIdx++) {
      const bb = e.bubbles[bIdx];
      ctx.globalAlpha = Math.max(0, bb.t);
      ctx.beginPath();
      ctx.arc(bb.x, bb.y, bb.r, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1.0;

    // 4. Fishes, Hazards, Trash, Treasures - Drawing all with Concrete Sprite Images
    for (let fIdx = 0; fIdx < e.fishes.length; fIdx++) {
      const f = e.fishes[fIdx];
      ctx.save();
      ctx.translate(f.x, f.y);
      const scl = 1 + f.pop * 0.35;
      const flipX = f.vx < 0 && !f.hooked ? -1 : 1;
      ctx.scale(flipX * scl, scl);

      const spriteImg = f.spriteKey ? assetManager.sprites[f.spriteKey] : null;

      if (spriteImg) {
        // Concrete Sprite Image Rendering
        let drawW = f.size;
        let drawH = f.size;

        if (f.spriteKey === 'tropicalFish') {
          drawW = f.size * 1.35;
          drawH = f.size * 0.95;
        } else if (f.spriteKey === 'pufferFish') {
          drawW = f.size * 1.15;
          drawH = f.size * 1.15;
        } else if (f.spriteKey === 'giantWhale') {
          drawW = f.size * 1.65;
          drawH = f.size * 1.05;
        } else if (f.spriteKey === 'shark') {
          drawW = f.size * 1.5;
          drawH = f.size * 0.95;
          ctx.shadowColor = '#00e5ff';
          ctx.shadowBlur = 12;
        } else if (f.spriteKey === 'goldenFish') {
          drawW = f.size * 1.3;
          drawH = f.size * 0.95;
          ctx.shadowColor = '#ffe27a';
          ctx.shadowBlur = 18;
        } else if (f.spriteKey === 'jellyfish') {
          drawW = f.size * 1.05;
          drawH = f.size * 1.35;
          ctx.shadowColor = '#79f2ff';
          ctx.shadowBlur = 14;
        } else if (f.spriteKey === 'mine') {
          drawW = f.size * 1.15;
          drawH = f.size * 1.15;
          ctx.shadowColor = '#ff4d4d';
          ctx.shadowBlur = 12;
        } else if (f.spriteKey === 'turtle') {
          drawW = f.size * 1.35;
          drawH = f.size * 1.05;
        } else if (f.spriteKey === 'shell') {
          drawW = f.size * 1.25;
          drawH = f.size * 1.15;
          if (f.isOpen) {
            ctx.shadowColor = '#ffffff';
            ctx.shadowBlur = 14;
          }
        } else if (f.spriteKey === 'trash') {
          drawW = f.size * 1.25;
          drawH = f.size * 1.15;
        } else if (f.spriteKey === 'treasure') {
          drawW = f.size * 1.25;
          drawH = f.size * 1.1;
          ctx.shadowColor = '#ffe27a';
          ctx.shadowBlur = 16;
        }

        ctx.drawImage(spriteImg, -drawW / 2, -drawH / 2, drawW, drawH);
      } else {
        // High-contrast fallback
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.font = `${f.size}px sans-serif`;
        if (f.gold) {
          ctx.shadowColor = '#ffe27a';
          ctx.shadowBlur = 14;
        }
        ctx.fillText(f.e, 0, 0);
      }
      ctx.restore();
    }

    // 5. Fishing Line
    ctx.strokeStyle =
      e.hook.immune > 0
        ? 'rgba(255,70,70,0.9)'
        : e.hook.stun > 0
          ? '#79f2ff'
          : 'rgba(255,255,255,0.85)';
    ctx.lineWidth = e.hook.stun > 0 ? 3 : 1.6;
    ctx.beginPath();
    ctx.moveTo(e.boat.x, e.boat.y);
    ctx.lineTo(e.hook.x, e.hook.y);
    ctx.stroke();

    // 6. Hook / Stun Icon
    ctx.save();
    ctx.translate(e.hook.x, e.hook.y);
    const hScale = 1 + e.hook.pop * 0.4;
    ctx.scale(hScale, hScale);
    ctx.font = '22px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(e.hook.stun > 0 ? '⚡' : '🪝', 0, 6);
    ctx.restore();

    // 7. Boat & Fisherman (Using Generated Asset Sprite)
    const bBob = Math.sin(e.boat.bobT * 2.4) * 2;
    ctx.save();
    ctx.translate(e.boat.x, e.boat.y + bBob);

    if (assetManager.sprites.boat) {
      const bw = 84;
      const bh = 58;
      ctx.drawImage(assetManager.sprites.boat, -bw / 2, -bh + 14, bw, bh);
    } else {
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.font = '38px sans-serif';
      ctx.fillText('🚣', 0, -10);
    }
    ctx.restore();

    // 8. Particles
    for (let pIdx = 0; pIdx < e.particles.length; pIdx++) {
      const pt = e.particles[pIdx];
      ctx.fillStyle = pt.c;
      ctx.globalAlpha = Math.max(0, pt.t / pt.life);
      ctx.beginPath();
      ctx.arc(pt.x, pt.y, pt.r, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1.0;

    // 9. Popups (Floating text)
    for (let popIdx = 0; popIdx < e.pops.length; popIdx++) {
      const pp = e.pops[popIdx];
      ctx.save();
      ctx.globalAlpha = Math.min(1.0, pp.t);
      ctx.font = `900 ${pp.s}px -apple-system, sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = pp.c;
      ctx.strokeStyle = 'rgba(0,0,0,0.7)';
      ctx.lineWidth = 3;
      ctx.strokeText(pp.txt, pp.x, pp.y);
      ctx.fillText(pp.txt, pp.x, pp.y);
      ctx.restore();
    }

    ctx.restore();
  };

  // Resize handler using ResizeObserver
  const handleResize = useCallback(() => {
    if (!stageRef.current || !canvasRef.current) return;
    const r = stageRef.current.getBoundingClientRect();
    const w = Math.max(260, Math.floor(r.width));
    const h = Math.max(240, Math.floor(r.height));
    const dpr = Math.min(window.devicePixelRatio || 1, 2.5);

    const canvas = canvasRef.current;
    canvas.width = Math.floor(w * dpr);
    canvas.height = Math.floor(h * dpr);
    canvas.style.width = `${w}px`;
    canvas.style.height = `${h}px`;

    const ctx = canvas.getContext('2d');
    if (ctx) ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    const e = engineRef.current;
    const ow = e.W;
    const oh = e.H;
    e.W = w;
    e.H = h;
    computeLayout(w, h);

    if (ow > 0 && oh > 0) {
      const sx = w / ow;
      const sy = h / oh;
      for (const f of e.fishes) {
        f.x *= sx;
        f.y *= sy;
        f.baseY *= sy;
      }
      for (const b of e.bubbles) {
        b.x *= sx;
        b.y *= sy;
      }
      e.hook.x *= sx;
      e.hook.y *= sy;
      e.boat.x *= sx;
      e.targetX *= sx;
    } else {
      e.hook.x = e.boat.x = e.targetX = w / 2;
      e.hook.y = e.boat.y + 10;
    }

    e.clouds = [];
    for (let i = 0; i < 3; i++) {
      e.clouds.push({
        x: Math.random() * w,
        y: 8 + Math.random() * (e.waterTop * 0.45),
        s: 0.6 + Math.random() * 0.7,
        v: 4 + Math.random() * 7,
      });
    }
  }, []);

  // Preload Assets & Initialize
  useEffect(() => {
    assetManager.preload().then(() => {
      handleResize();
    });
  }, [handleResize]);

  // Game Loop & Window Listeners
  useEffect(() => {
    handleResize();

    const ro = new ResizeObserver(() => handleResize());
    if (stageRef.current) ro.observe(stageRef.current);

    let animationFrameId: number;
    let lastT = window.performance.now();

    const loop = (now: number) => {
      const dt = Math.min(0.08, (now - lastT) / 1000);
      lastT = now;

      updateEngine(dt);
      drawEngine();

      animationFrameId = requestAnimationFrame(loop);
    };

    animationFrameId = requestAnimationFrame(loop);

    const onKeyDown = (e: KeyboardEvent) => {
      sounds.init();
      const eng = engineRef.current;
      if (e.code === 'ArrowLeft' || e.code === 'KeyA') eng.keyL = true;
      if (e.code === 'ArrowRight' || e.code === 'KeyD') eng.keyR = true;
      if (e.code === 'Space' || e.code === 'ArrowDown' || e.code === 'KeyS') {
        e.preventDefault();
        pressAction();
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      const eng = engineRef.current;
      if (e.code === 'ArrowLeft' || e.code === 'KeyA') eng.keyL = false;
      if (e.code === 'ArrowRight' || e.code === 'KeyD') eng.keyR = false;
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);

    return () => {
      cancelAnimationFrame(animationFrameId);
      ro.disconnect();
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      if (gameOverTimeoutRef.current) {
        window.clearTimeout(gameOverTimeoutRef.current);
      }
    };
  }, [handleResize, pressAction]);

  // Pointer Handlers on Stage
  const setPointerPos = (clientX: number) => {
    if (!stageRef.current) return;
    const r = stageRef.current.getBoundingClientRect();
    const eng = engineRef.current;
    eng.pointerX = ((clientX - r.left) / r.width) * eng.W;
    eng.pointerActive = true;
  };

  const handlePointerDown = (e: React.PointerEvent) => {
    sounds.init();
    setPointerPos(e.clientX);
    const eng = engineRef.current;
    if (eng.state === 'play' && eng.hookState === 'idle') {
      castLine();
    }
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    const eng = engineRef.current;
    if (eng.pointerActive) setPointerPos(e.clientX);
  };

  const handlePointerUp = () => {
    const eng = engineRef.current;
    eng.pointerActive = false;
    eng.pointerX = -1;
  };

  return (
    <div className="relative w-full h-[100dvh] max-w-[520px] mx-auto flex flex-col overflow-hidden bg-radial from-[#1a5c8a] via-[#07304d] to-[#021624] text-white select-none">
      {/* Top HUD */}
      <header className="flex-none px-3 pt-2 pb-1.5 flex flex-col gap-1.5 z-20" id="hud">
        <div className="flex items-center gap-1.5">
          <div className="bg-white/10 border border-white/20 rounded-full px-2.5 py-1 text-xs font-bold tracking-tight flex items-center gap-1">
            🗓 <span>{day}일차</span>
          </div>

          {streak >= 2 && (
            <div className="bg-gradient-to-r from-amber-500 to-yellow-400 text-amber-950 border border-amber-200/50 rounded-full px-2.5 py-1 text-xs font-black flex items-center gap-1 shadow-sm">
              🔥 <span>{streak}연속</span>
            </div>
          )}

          <div className="flex-1" />

          {/* Lives */}
          <div className="bg-white/10 border border-white/20 rounded-full px-2.5 py-1 text-xs font-bold flex items-center gap-1">
            {[0, 1, 2].map((i) => (
              <span
                key={i}
                className={`transition-transform duration-200 ${i < lives ? 'scale-100' : 'scale-75 opacity-30 grayscale'}`}
              >
                ❤️
              </span>
            ))}
          </div>

          {/* Timer */}
          <div
            className={`bg-white/10 border border-white/20 rounded-full px-2.5 py-1 text-xs font-black flex items-center gap-1 ${
              timeLeft <= 10 ? 'bg-red-500/30 border-red-400 anim-tick' : ''
            }`}
          >
            ⏱ <span className={timeLeft <= 10 ? 'text-red-300' : 'text-amber-200'}>{timeLeft}초</span>
          </div>

          {/* Guide Modal Button */}
          <button
            onClick={() => setShowGuide(true)}
            title="물고기 & 에셋 도감"
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 border border-white/20 flex items-center justify-center text-xs text-amber-300 transition-transform active:scale-90"
            id="guideBtn"
          >
            <BookOpen className="w-4 h-4" />
          </button>

          {/* Sound Toggle */}
          <button
            onClick={toggleSound}
            title="소리 켜기/끄기"
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 border border-white/20 flex items-center justify-center text-xs transition-transform active:scale-90"
            id="soundBtn"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4 text-white" /> : <VolumeX className="w-4 h-4 text-slate-400" />}
          </button>
        </div>

        {/* Target Progress Bar */}
        <div className="h-3.5 rounded-full bg-black/40 border border-white/20 overflow-hidden relative" id="barWrap">
          <div
            className="h-full rounded-full bg-gradient-to-r from-emerald-400 via-amber-300 to-yellow-400 transition-all duration-300"
            style={{ width: `${Math.min(100, (money / goalMoney) * 100)}%` }}
            id="bar"
          />
          <div className="absolute inset-0 flex items-center justify-center text-[10px] font-black tracking-tight text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.8)]">
            💰 {money.toLocaleString()}원 / {goalMoney.toLocaleString()}원 ({Math.round((money / goalMoney) * 100)}%)
          </div>
        </div>
      </header>

      {/* Main Game Stage */}
      <main
        ref={stageRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerUp}
        className="relative flex-1 min-h-0 overflow-hidden touch-none cursor-crosshair"
        id="stage"
      >
        <canvas ref={canvasRef} id="cv" className="block w-full h-full" />

        {/* White Screen Flash */}
        <div
          className="absolute inset-0 bg-white pointer-events-none transition-opacity duration-200"
          style={{ opacity: flashOpacity }}
          id="flash"
        />

        {/* In-game Notification Banner */}
        {bannerText && (
          <div
            key={bannerKey}
            className="absolute left-1/2 top-[16%] -translate-x-1/2 bg-gradient-to-b from-amber-100 to-amber-300 text-amber-950 font-black text-sm px-4 py-2 rounded-xl shadow-2xl border-2 border-white pointer-events-none whitespace-nowrap anim-banner"
            id="banner"
          >
            {bannerText}
          </div>
        )}
      </main>

      {/* Bottom Control Bar */}
      <footer className="flex-none p-2.5 flex items-stretch gap-2 z-20 bg-slate-950/60 backdrop-blur-sm border-t border-white/10" id="ctrl">
        <button
          onPointerDown={(e) => {
            e.preventDefault();
            sounds.init();
            engineRef.current.btnL = true;
          }}
          onPointerUp={(e) => {
            e.preventDefault();
            engineRef.current.btnL = false;
          }}
          onPointerLeave={() => {
            engineRef.current.btnL = false;
          }}
          className="flex-1 py-3 bg-white/10 hover:bg-white/20 active:scale-95 border border-white/20 rounded-2xl flex items-center justify-center font-black text-xl transition-all"
          id="leftBtn"
          aria-label="왼쪽 이동"
        >
          <ArrowLeft className="w-6 h-6" />
        </button>

        <button
          onClick={pressAction}
          className="flex-[2] py-3 bg-gradient-to-b from-amber-400 to-orange-500 hover:from-amber-300 hover:to-orange-400 text-amber-950 font-black text-base rounded-2xl border border-amber-200 shadow-md active:translate-y-0.5 active:shadow-sm transition-all flex items-center justify-center gap-2"
          id="actBtn"
        >
          <Anchor className="w-5 h-5 text-amber-900" />
          <span>{actionLabel}</span>
        </button>

        <button
          onPointerDown={(e) => {
            e.preventDefault();
            sounds.init();
            engineRef.current.btnR = true;
          }}
          onPointerUp={(e) => {
            e.preventDefault();
            engineRef.current.btnR = false;
          }}
          onPointerLeave={() => {
            engineRef.current.btnR = false;
          }}
          className="flex-1 py-3 bg-white/10 hover:bg-white/20 active:scale-95 border border-white/20 rounded-2xl flex items-center justify-center font-black text-xl transition-all"
          id="rightBtn"
          aria-label="오른쪽 이동"
        >
          <ArrowRight className="w-6 h-6" />
        </button>
      </footer>

      {/* Title Screen Overlay */}
      {gameState === 'title' && (
        <section
          className="absolute inset-0 z-30 flex flex-col items-center justify-center gap-3 p-5 bg-gradient-to-b from-[#031a2c]/85 via-[#031424]/95 to-[#020e1a]/98 backdrop-blur-sm text-center"
          id="titleScreen"
        >
          <div className="flex items-center gap-3 anim-swim">
            <img src={assetPaths.tropicalFish} alt="열대어" referrerPolicy="no-referrer" className="w-10 h-10 object-contain drop-shadow" />
            <img src={assetPaths.goldenFish} alt="황금어" referrerPolicy="no-referrer" className="w-12 h-12 object-contain drop-shadow" />
            <img src={assetPaths.shark} alt="상어" referrerPolicy="no-referrer" className="w-12 h-12 object-contain drop-shadow" />
            <img src={assetPaths.treasure} alt="보물" referrerPolicy="no-referrer" className="w-10 h-10 object-contain drop-shadow" />
          </div>

          <h1 className="text-4xl font-black tracking-tight bg-gradient-to-b from-white via-amber-200 to-orange-400 bg-clip-text text-transparent drop-shadow-[0_2px_10px_rgba(255,200,0,0.3)]">
            낚시왕
          </h1>
          <p className="text-sm font-semibold text-sky-200 max-w-xs">
            모든 물고기, 쓰레기, 장애물이 고화질 일러스트 그래픽으로 생생하게 변신했습니다!
          </p>

          {/* All Generated Sprites Showcase */}
          <div className="w-full max-w-xs bg-white/10 border border-white/20 rounded-2xl p-3 text-xs flex flex-col gap-2 shadow-lg">
            <div className="flex items-center justify-between text-amber-300 font-bold px-1">
              <span className="flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                전체 그래픽 스프라이트 적용 완료
              </span>
              <button
                onClick={() => setShowGuide(true)}
                className="text-[11px] underline text-sky-300 hover:text-white"
              >
                도감 보기
              </button>
            </div>
            <div className="grid grid-cols-4 gap-1.5 pt-1">
              {[
                { src: assetPaths.boat, name: '낚싯배' },
                { src: assetPaths.tropicalFish, name: '열대어' },
                { src: assetPaths.pufferFish, name: '가시복어' },
                { src: assetPaths.giantWhale, name: '고래/돌고래' },
                { src: assetPaths.goldenFish, name: '황금어' },
                { src: assetPaths.trash, name: '바다쓰레기' },
                { src: assetPaths.jellyfish, name: '전기해파리' },
                { src: assetPaths.mine, name: '심해기뢰' },
                { src: assetPaths.turtle, name: '바다거북' },
                { src: assetPaths.shell, name: '진주조개' },
                { src: assetPaths.shark, name: '식인상어' },
                { src: assetPaths.treasure, name: '보물상자' },
              ].map((item, idx) => (
                <div key={idx} className="flex flex-col items-center gap-0.5 bg-black/30 p-1 rounded-lg border border-white/10">
                  <img src={item.src} alt={item.name} referrerPolicy="no-referrer" className="w-8 h-8 object-contain rounded" />
                  <span className="text-[9px] text-slate-200 truncate max-w-[54px]">{item.name}</span>
                </div>
              ))}
            </div>
          </div>

          <button
            onClick={pressAction}
            className="mt-1 px-8 py-3.5 rounded-full font-black text-base tracking-tight bg-gradient-to-b from-amber-400 to-orange-500 text-amber-950 shadow-lg border border-amber-200 anim-bob active:scale-95 flex items-center gap-2"
            id="startBtn"
          >
            <Play className="w-5 h-5 fill-current" />
            <span>낚시 시작하기!</span>
          </button>

          <div className="text-xs font-bold text-amber-300 flex items-center gap-1" id="bestTitle">
            <Trophy className="w-3.5 h-3.5" />
            <span>최고 기록: {bestScore.toLocaleString()}원</span>
          </div>
          <div className="text-[11px] text-sky-300">스페이스바로 즉시 시작 · 드래그/버튼으로 조종</div>
        </section>
      )}

      {/* Result / Game Over Screen Overlay */}
      {gameState === 'over' && (
        <section
          className="absolute inset-0 z-30 flex flex-col items-center justify-center gap-3 p-5 bg-gradient-to-b from-[#031a2c]/90 via-[#031424]/95 to-[#020e1a]/98 backdrop-blur-sm text-center"
          id="overScreen"
        >
          {/* Dynamic Graphic Sprite */}
          <div className="relative">
            {overData.spriteSrc ? (
              <img
                src={overData.spriteSrc}
                alt="결과 아이콘"
                referrerPolicy="no-referrer"
                className="w-24 h-24 object-contain drop-shadow-2xl animate-bounce"
              />
            ) : (
              <div className="text-5xl">{overData.icon}</div>
            )}
          </div>

          <h2 className="text-3xl font-black tracking-tight text-white" id="overTitle">
            {overData.title}
          </h2>

          <p className={`text-xs font-bold max-w-xs ${overData.success ? 'text-emerald-300' : 'text-red-300'}`} id="missTxt">
            {overData.message}
          </p>

          <div className="grid grid-cols-3 gap-2 w-full max-w-xs pt-1">
            <div className="bg-white/10 border border-white/20 rounded-xl p-2.5 text-center">
              <span className="text-[11px] text-sky-200">오늘 번 돈</span>
              <b className="block text-sm text-amber-300 mt-0.5">{money.toLocaleString()}원</b>
            </div>
            <div className="bg-white/10 border border-white/20 rounded-xl p-2.5 text-center">
              <span className="text-[11px] text-sky-200">전체 누적</span>
              <b className="block text-sm text-amber-300 mt-0.5">{totalMoney.toLocaleString()}원</b>
            </div>
            <div className="bg-white/10 border border-white/20 rounded-xl p-2.5 text-center">
              <span className="text-[11px] text-sky-200">최고 기록</span>
              <b className="block text-sm text-yellow-400 mt-0.5">{bestScore.toLocaleString()}원</b>
            </div>
          </div>

          <button
            onClick={pressAction}
            className="mt-2 px-8 py-3.5 rounded-full font-black text-base bg-gradient-to-b from-amber-400 to-orange-500 text-amber-950 shadow-lg border border-amber-200 anim-bob active:scale-95 flex items-center gap-2"
            id="againBtn"
          >
            {overData.success ? (
              <>
                <Play className="w-5 h-5 fill-current" />
                <span>다음 날({day + 1}일차) 출항!</span>
              </>
            ) : (
              <>
                <RotateCcw className="w-5 h-5" />
                <span>처음부터 다시 하기</span>
              </>
            )}
          </button>

          <div className="text-[11px] text-sky-300">스페이스바를 눌러도 바로 진행됩니다</div>
        </section>
      )}

      {/* Ocean Creature & Asset Guide Modal */}
      {showGuide && (
        <div className="absolute inset-0 z-40 bg-black/85 backdrop-blur-md p-4 flex flex-col items-center justify-center">
          <div className="w-full max-w-sm bg-slate-900 border border-white/20 rounded-2xl overflow-hidden flex flex-col max-h-[88vh] shadow-2xl">
            <div className="p-3.5 border-b border-white/10 flex items-center justify-between bg-slate-800/80">
              <div className="flex items-center gap-2 text-sm font-bold text-amber-300">
                <BookOpen className="w-4 h-4" />
                <span>해양 도감 - 모든 생선 & 장애물 그래픽</span>
              </div>
              <button
                onClick={() => setShowGuide(false)}
                className="w-7 h-7 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-slate-300"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3.5 overflow-y-auto space-y-3.5 text-xs">
              {/* Fish list */}
              <div>
                <h4 className="font-bold text-amber-300 mb-2 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>수중 어종 (수심층별 고화질 스프라이트)</span>
                </h4>
                <div className="space-y-1.5">
                  {[
                    { src: assetPaths.tropicalFish, name: '멸치 / 정어리 / 열대어', band: '수면층 (얕은 바다)', val: '+20~30원' },
                    { src: assetPaths.pufferFish, name: '가시복어 / 심해오징어', band: '중간층', val: '+60~90원' },
                    { src: assetPaths.giantWhale, name: '돌고래 / 거대 향유고래', band: '심해층', val: '+120~300원' },
                    { src: assetPaths.goldenFish, name: '황금 잉어 (초희귀)', band: '중간층 (특수 출현)', val: '+400원' },
                  ].map((item, idx) => (
                    <div key={idx} className="flex items-center gap-2.5 bg-white/5 border border-white/10 p-2 rounded-xl">
                      <img src={item.src} alt={item.name} referrerPolicy="no-referrer" className="w-10 h-10 object-contain rounded-lg bg-black/20" />
                      <div className="flex-1">
                        <b className="block text-white text-xs">{item.name}</b>
                        <span className="text-[10px] text-sky-300">{item.band}</span>
                      </div>
                      <b className="text-amber-300 text-xs">{item.val}</b>
                    </div>
                  ))}
                </div>
              </div>

              {/* Trash & Hazards */}
              <div>
                <h4 className="font-bold text-red-300 mb-2 flex items-center gap-1.5">
                  <ShieldAlert className="w-3.5 h-3.5" />
                  <span>위험 장애물 & 해양 쓰레기</span>
                </h4>
                <div className="space-y-1.5">
                  {[
                    { src: assetPaths.trash, name: '해양 쓰레기 (장화/깡통)', desc: '줄이 무거워지고 40원 감점', color: 'text-amber-300' },
                    { src: assetPaths.shark, name: '식인 백상아리', desc: '닿으면 낚싯줄 즉시 절단!', color: 'text-red-400' },
                    { src: assetPaths.jellyfish, name: '전기 해파리', desc: '감전 쇼크 + 낚은 물고기 방출', color: 'text-cyan-300' },
                    { src: assetPaths.mine, name: '심해 폭탄 기뢰', desc: '대폭발 + 하트 1개 즉시 소모', color: 'text-red-400' },
                  ].map((item, idx) => (
                    <div key={idx} className="flex items-center gap-2.5 bg-red-950/20 border border-red-800/20 p-2 rounded-xl">
                      <img src={item.src} alt={item.name} referrerPolicy="no-referrer" className="w-10 h-10 object-contain rounded-lg bg-black/20" />
                      <div className="flex-1">
                        <b className="block text-white text-xs">{item.name}</b>
                        <span className={`text-[10px] ${item.color}`}>{item.desc}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Special Treasures */}
              <div>
                <h4 className="font-bold text-yellow-300 mb-2 flex items-center gap-1.5">
                  <Trophy className="w-3.5 h-3.5" />
                  <span>특수 보물 & 행운의 생물</span>
                </h4>
                <div className="space-y-1.5">
                  {[
                    { src: assetPaths.turtle, name: '장수 바다거북', desc: '+250원 및 보너스 시간 +8초' },
                    { src: assetPaths.shell, name: '진주조개', desc: '입을 벌렸을 때만 획득 가능 (+300원)' },
                    { src: assetPaths.treasure, name: '해저 보물상자 & 왕관', desc: '심해 최고 가치 (+500~600원)' },
                  ].map((item, idx) => (
                    <div key={idx} className="flex items-center gap-2.5 bg-yellow-950/20 border border-yellow-800/20 p-2 rounded-xl">
                      <img src={item.src} alt={item.name} referrerPolicy="no-referrer" className="w-10 h-10 object-contain rounded-lg bg-black/20" />
                      <div className="flex-1">
                        <b className="block text-white text-xs">{item.name}</b>
                        <span className="text-[10px] text-yellow-200/80">{item.desc}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="p-3 border-t border-white/10 bg-slate-800/50 flex justify-end">
              <button
                onClick={() => setShowGuide(false)}
                className="px-4 py-1.5 bg-amber-400 hover:bg-amber-300 text-amber-950 rounded-xl font-bold text-xs"
              >
                닫기
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
