// Web Audio API Synthesizer for 8-bit retro ocean sound effects

class SoundEngine {
  private actx: AudioContext | null = null;
  private master: GainNode | null = null;
  public enabled: boolean = true;

  constructor() {
    try {
      this.enabled = window.localStorage.getItem('fishingMasterSnd') !== '0';
    } catch {
      this.enabled = true;
    }
  }

  public init() {
    if (this.actx) {
      if (this.actx.state === 'suspended') {
        try {
          this.actx.resume();
        } catch {}
      }
      return;
    }
    try {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AC) return;
      this.actx = new AC();
      this.master = this.actx.createGain();
      this.master.gain.value = 0.28;
      this.master.connect(this.actx.destination);
      if (this.actx.state === 'suspended') {
        try {
          this.actx.resume();
        } catch {}
      }
    } catch {
      this.actx = null;
    }
  }

  public toggle(): boolean {
    this.enabled = !this.enabled;
    try {
      window.localStorage.setItem('fishingMasterSnd', this.enabled ? '1' : '0');
    } catch {}
    if (this.enabled) this.init();
    return this.enabled;
  }

  private tone(f: number, d: number, type: OscillatorType = 'sine', v: number = 0.3, delay: number = 0, f2?: number) {
    if (!this.actx || !this.master || !this.enabled) return;
    try {
      const t0 = this.actx.currentTime + delay;
      const o = this.actx.createOscillator();
      const g = this.actx.createGain();
      o.type = type;
      o.frequency.setValueAtTime(f, t0);
      if (f2) o.frequency.exponentialRampToValueAtTime(Math.max(24, f2), t0 + d);
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.exponentialRampToValueAtTime(Math.max(0.002, v), t0 + 0.012);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + d);
      o.connect(g);
      g.connect(this.master);
      o.start(t0);
      o.stop(t0 + d + 0.04);
    } catch {}
  }

  private noiseBurst(d: number, v: number, f1: number, f2: number, delay: number = 0) {
    if (!this.actx || !this.master || !this.enabled) return;
    try {
      const t0 = this.actx.currentTime + delay;
      const len = Math.max(1, Math.floor(this.actx.sampleRate * d));
      const buf = this.actx.createBuffer(1, len, this.actx.sampleRate);
      const data = buf.getChannelData(0);
      for (let i = 0; i < len; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / len);
      const src = this.actx.createBufferSource();
      src.buffer = buf;
      const flt = this.actx.createBiquadFilter();
      flt.type = 'bandpass';
      flt.frequency.setValueAtTime(f1, t0);
      flt.frequency.exponentialRampToValueAtTime(Math.max(40, f2), t0 + d);
      flt.Q.value = 1.0;
      const g = this.actx.createGain();
      g.gain.setValueAtTime(v, t0);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + d);
      src.connect(flt);
      flt.connect(g);
      g.connect(this.master);
      src.start(t0);
      src.stop(t0 + d + 0.03);
    } catch {}
  }

  private note(step: number, d: number = 0.16, v: number = 0.3, delay: number = 0, type: OscillatorType = 'triangle') {
    const PENTA = [0, 2, 4, 7, 9, 12, 14, 16, 19, 21, 24, 26];
    const st = PENTA[Math.min(step, PENTA.length - 1)];
    this.tone(523.25 * Math.pow(2, st / 12), d, type, v, delay);
  }

  public cast() {
    this.tone(700, 0.12, 'sine', 0.18, 0, 220);
    this.noiseBurst(0.22, 0.22, 1400, 300, 0.1);
  }

  public hook(step: number) {
    this.note(step, 0.15, 0.32, 0, 'triangle');
    this.note(step + 2, 0.12, 0.16, 0.055, 'sine');
  }

  public coin(n: number) {
    for (let i = 0; i < Math.min(n, 6); i++) {
      this.note(4 + i, 0.13, 0.26, i * 0.065, 'square');
    }
  }

  public trash() {
    this.tone(150, 0.3, 'sawtooth', 0.22, 0, 60);
    this.noiseBurst(0.2, 0.14, 500, 120, 0);
  }

  public zap() {
    this.tone(880, 0.08, 'sawtooth', 0.25, 0, 120);
    this.tone(220, 0.15, 'square', 0.3, 0.05, 880);
    this.noiseBurst(0.2, 0.2, 2000, 400, 0.08);
  }

  public explode() {
    this.noiseBurst(0.6, 0.45, 800, 40, 0);
    this.tone(120, 0.5, 'sawtooth', 0.4, 0, 30);
  }

  public bonus() {
    this.note(7, 0.1, 0.3, 0, 'sine');
    this.note(12, 0.1, 0.3, 0.08, 'sine');
    this.note(16, 0.2, 0.35, 0.16, 'sine');
  }

  public shark() {
    this.noiseBurst(0.5, 0.34, 1800, 90, 0);
    this.tone(320, 0.5, 'sawtooth', 0.3, 0, 46);
    this.tone(160, 0.6, 'square', 0.2, 0.05, 32);
  }

  public event() {
    this.note(5, 0.12, 0.22, 0, 'square');
    this.note(7, 0.12, 0.22, 0.08, 'square');
    this.note(10, 0.22, 0.24, 0.16, 'square');
  }

  public clear() {
    const s = [0, 4, 7, 9, 11];
    for (let i = 0; i < s.length; i++) this.note(s[i], 0.24, 0.3, i * 0.1, 'triangle');
    this.tone(1046.5, 0.5, 'sine', 0.2, 0.5);
  }

  public over() {
    this.tone(392, 0.28, 'sawtooth', 0.24, 0, 300);
    this.tone(294, 0.32, 'sawtooth', 0.24, 0.16, 220);
    this.tone(196, 0.6, 'sawtooth', 0.26, 0.34, 90);
  }

  public start() {
    this.note(0, 0.12, 0.26, 0, 'square');
    this.note(4, 0.12, 0.26, 0.09, 'square');
    this.note(7, 0.26, 0.3, 0.18, 'square');
  }

  public tick() {
    this.tone(880, 0.07, 'square', 0.16, 0);
  }
}

export const sounds = new SoundEngine();
