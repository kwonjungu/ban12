// Game Asset Manager & Sprite Processor
import { SpriteKey } from './types';

import boatImgPath from './assets/images/fishing_boat_1789882006141.jpg';
import sharkImgPath from './assets/images/deepsea_shark_1789882020024.jpg';
import goldenFishImgPath from './assets/images/golden_fish_1789882031690.jpg';
import treasureChestImgPath from './assets/images/treasure_chest_1789882052092.jpg';
import tropicalFishImgPath from './assets/images/tropical_fish_1789882853020.jpg';
import pufferFishImgPath from './assets/images/puffer_fish_1789882867312.jpg';
import giantWhaleImgPath from './assets/images/giant_whale_1789882880920.jpg';
import oceanTrashImgPath from './assets/images/ocean_trash_1789882891224.jpg';
import electricJellyfishImgPath from './assets/images/electric_jellyfish_1789882904965.jpg';
import navalMineImgPath from './assets/images/naval_mine_1789882915035.jpg';
import seaTurtleImgPath from './assets/images/sea_turtle_1789882927760.jpg';
import pearlShellImgPath from './assets/images/pearl_shell_1789882943811.jpg';

export type GameSpriteMap = Record<SpriteKey, CanvasImageSource | null>;

export const assetPaths: Record<SpriteKey, string> = {
  boat: boatImgPath,
  shark: sharkImgPath,
  goldenFish: goldenFishImgPath,
  treasure: treasureChestImgPath,
  tropicalFish: tropicalFishImgPath,
  pufferFish: pufferFishImgPath,
  giantWhale: giantWhaleImgPath,
  trash: oceanTrashImgPath,
  jellyfish: electricJellyfishImgPath,
  mine: navalMineImgPath,
  turtle: seaTurtleImgPath,
  shell: pearlShellImgPath,
};

// Process solid white/near-white background into transparent alpha channel
function createTransparentSprite(img: HTMLImageElement, tolerance = 240): HTMLCanvasElement {
  const canvas = document.createElement('canvas');
  canvas.width = img.naturalWidth || img.width || 256;
  canvas.height = img.naturalHeight || img.height || 256;
  const ctx = canvas.getContext('2d');
  if (!ctx) return canvas;

  ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
  try {
    const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const data = imgData.data;
    const len = data.length;

    for (let i = 0; i < len; i += 4) {
      const r = data[i];
      const g = data[i + 1];
      const b = data[i + 2];

      // Detect white / off-white background
      if (r >= tolerance && g >= tolerance && b >= tolerance) {
        data[i + 3] = 0; // Fully transparent
      } else if (r >= 216 && g >= 216 && b >= 216) {
        // Soft feathering at the sprite boundary
        const avg = (r + g + b) / 3;
        const factor = (255 - avg) / (255 - 216);
        data[i + 3] = Math.min(255, Math.floor(factor * 255));
      }
    }
    ctx.putImageData(imgData, 0, 0);
  } catch (e) {
    console.warn('Canvas sprite transparency fallback active', e);
  }
  return canvas;
}

export class AssetManager {
  public sprites: GameSpriteMap = {
    boat: null,
    shark: null,
    goldenFish: null,
    treasure: null,
    tropicalFish: null,
    pufferFish: null,
    giantWhale: null,
    trash: null,
    jellyfish: null,
    mine: null,
    turtle: null,
    shell: null,
  };
  public loaded: boolean = false;

  public async preload(): Promise<void> {
    const entries = Object.entries(assetPaths) as [SpriteKey, string][];

    const promises = entries.map(([key, src]) => {
      return new Promise<void>((resolve) => {
        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.onload = () => {
          try {
            const transparentCanvas = createTransparentSprite(img);
            this.sprites[key] = transparentCanvas;
          } catch {
            this.sprites[key] = img;
          }
          resolve();
        };
        img.onerror = () => {
          console.warn(`Failed to load asset image for ${key}`);
          resolve();
        };
        img.src = src;
      });
    });

    await Promise.all(promises);
    this.loaded = true;
  }
}

export const assetManager = new AssetManager();
