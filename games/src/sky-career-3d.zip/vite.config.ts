import {defineConfig} from 'vite';
export default defineConfig({
  base: './',
  build: {chunkSizeWarningLimit: 10000, assetsInlineLimit: 0, target: 'esnext'},
});
