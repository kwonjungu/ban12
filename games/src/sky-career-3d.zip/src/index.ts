import * as xb from 'xrblocks';

import {SkyCareerScene} from './SkyCareerScene.ts';

function start(): void {
  const options = new xb.Options();
  options.setAppTitle('Sky Career 3D');
  options.setAppDescription(
    '글로벌 항공 운송 & 초음속 비행 시뮬레이터 (XR Blocks + Three.js)'
  );
  options.xrButton.enabled = false;
  options.reticles.enabled = false;
  // 데스크톱 시뮬레이터의 기본 안내·설정 UI가 게임 HUD를 가려서 끈다.
  options.simulator.instructions.enabled = false;
  options.simulator.instructions.overlayEnabled = false;
  options.simulator.simulatorSettingsPanel.enabled = false;
  options.simulator.handPosePanel.enabled = false;

  xb.add(new SkyCareerScene());
  void xb.init(options);
}

document.addEventListener('DOMContentLoaded', start);
