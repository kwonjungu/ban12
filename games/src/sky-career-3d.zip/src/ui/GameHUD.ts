import {AIRCRAFT_DB, TEXTURE_ASSETS} from '../constants.ts';
import type {
  AircraftId,
  AircraftSpec,
  CameraMode,
  FlightInputState,
  FlightPhysicsState,
  FlightResultSummary,
  MissionContract,
  PlayerCareerState,
  TimeOfDay,
} from '../types.ts';

export interface GameHUDCallbacks {
  onSelectAircraft: (id: AircraftId) => void;
  onSelectMission: (id: string) => void;
  onRefreshMissions: () => void;
  onTimeOfDayChange: (tod: TimeOfDay) => void;
  onStartFlight: () => void;
  onSetCameraMode: (mode: CameraMode) => void;
  onToggleAutopilot: () => void;
  onAbortFlight: () => void;
  onToggleGear: () => void;
  onCycleFlaps: () => void;
  onToggleBrake: () => void;
  onToggleDroopNose: () => void;
  onToggleMute: () => boolean;
  onReturnToHangar: () => void;
  onRetryFlight: () => void;
  onResetCareer: () => void;
  onToggleInspect3D: (inspecting: boolean) => void;
  onEnterXR?: () => void;
}

const SVG_PLANE = `<svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.8 19.2 16 11l3.5-3.5C21 6 21.5 4 21 3c-1-.5-3 0-4.5 1.5L13 8 4.8 6.2c-.5-.1-.9.1-1.1.5l-.3.5c-.2.5-.1 1 .3 1.3L9 12l-2 3H4l-1 1 3 2 2 3 1-1v-3l3-2 3.5 5.3c.3.4.8.5 1.3.3l.5-.2c.4-.3.6-.7.5-1.2z"/></svg>`;
const SVG_VOLUME_ON = `<svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/></svg>`;
const SVG_VOLUME_OFF = `<svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><line x1="23" y1="9" x2="17" y2="15"/><line x1="17" y1="9" x2="23" y2="15"/></svg>`;
const SVG_REFRESH = `<svg class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/><path d="M8 16H3v5"/></svg>`;
const SVG_EYE = `<svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>`;

function getPilotRank(flights: number): string {
  if (flights >= 15) return '수석 기장 (Captain)';
  if (flights >= 8) return '선임 부기장 (Senior FO)';
  if (flights >= 3) return '정식 부기장 (First Officer)';
  return '수습 조종사 (Cadet)';
}

export class GameHUD {
  private root: HTMLElement;
  private callbacks: GameHUDCallbacks;
  private inputs: FlightInputState;
  private toastTimer: number | null = null;
  private hudCompact = false;
  private resetPending = false;

  // Cached DOM references
  private hangarModal!: HTMLElement;
  private inspectBar!: HTMLElement;
  private flightHud!: HTMLElement;
  private mobileControls!: HTMLElement;
  private resultModal!: HTMLElement;
  private cockpitFrame!: HTMLElement;
  private passengerFrame!: HTMLElement;
  private alertToast!: HTMLElement;
  private alertToastText!: HTMLElement;

  // Hangar fields
  private uiMoney!: HTMLElement;
  private uiFlights!: HTMLElement;
  private uiRank!: HTMLElement;
  private aircraftList!: HTMLElement;
  private missionList!: HTMLElement;
  private selectedSummary!: HTMLElement;
  private heroPreviewImg!: HTMLImageElement;
  private heroPreviewTitle!: HTMLElement;
  private heroPreviewMeta!: HTMLElement;
  private btnMute!: HTMLButtonElement;
  private btnXrEnter!: HTMLButtonElement;
  private btnResetCareer!: HTMLButtonElement;
  private todButtons = new Map<TimeOfDay, HTMLButtonElement>();

  // HUD fields
  private hudMissionType!: HTMLElement;
  private hudWeather!: HTMLElement;
  private hudMissionTitle!: HTMLElement;
  private hudDistance!: HTMLElement;
  private hudFuel!: HTMLElement;
  private hudSatisfaction!: HTMLElement;
  private hudHeading!: HTMLElement;
  private ilsIndicator!: HTMLElement;
  private papiLights: HTMLElement[] = [];
  private hudDestCode!: HTMLElement;
  private radarDestDot!: HTMLElement;
  private btnAutopilot!: HTMLButtonElement;
  private hudSpeed!: HTMLElement;
  private hudMach!: HTMLElement;
  private hudAlt!: HTMLElement;
  private hudVs!: HTMLElement;
  private hudThrottle!: HTMLElement;
  private throttleBar!: HTMLElement;
  private horizonSkyGround!: HTMLElement;
  private hudPitchText!: HTMLElement;
  private btnGear!: HTMLButtonElement;
  private btnFlaps!: HTMLButtonElement;
  private btnBrake!: HTMLButtonElement;
  private btnNose!: HTMLButtonElement;
  private hudBottomDock!: HTMLElement;
  private camButtons = new Map<CameraMode, HTMLButtonElement>();

  // Result fields
  private resBadge!: HTMLElement;
  private resTitle!: HTMLElement;
  private resFpm!: HTMLElement;
  private resBase!: HTMLElement;
  private resLanding!: HTMLElement;
  private resSat!: HTMLElement;
  private resTotal!: HTMLElement;

  private onResizeBound = () => this.syncMobileControlsVisibility();

  constructor(
    container: HTMLElement,
    inputs: FlightInputState,
    callbacks: GameHUDCallbacks
  ) {
    this.root = container;
    this.inputs = inputs;
    this.callbacks = callbacks;
    this.mount();
    window.addEventListener('resize', this.onResizeBound);
  }

  private syncMobileControlsVisibility(): void {
    if (this.flightHud.classList.contains('hidden')) return;
    const isTouchDevice = window.innerWidth < 768 || 'ontouchstart' in window;
    this.mobileControls.classList.toggle('hidden', !isTouchDevice);
    this.mobileControls.classList.toggle('flex', isTouchDevice);
  }

  private mount(): void {
    this.root.innerHTML = `
      <!-- Alert Toast -->
      <div id="sc-toast" class="fixed top-16 left-1/2 -translate-x-1/2 z-50 pointer-events-none opacity-0 transition-opacity duration-200 max-w-[92vw]">
        <div id="sc-toast-text" class="px-5 py-2.5 rounded-full bg-slate-950/95 border border-sky-400/50 text-sky-200 text-xs sm:text-sm font-semibold shadow-2xl text-center whitespace-nowrap truncate max-w-[90vw]">
          안내 메시지
        </div>
      </div>

      <!-- 3D Inspect Floating Bar (shown when Hangar is minimized) -->
      <div id="sc-inspect-bar" class="fixed bottom-5 left-1/2 -translate-x-1/2 z-30 hidden">
        <div class="hud-panel rounded-xl px-4 py-2.5 flex items-center gap-4">
          <span class="text-xs text-slate-300 hidden sm:inline">마우스 드래그로 3D 기체 회전 · 휠로 확대/축소</span>
          <button id="sc-btn-open-hangar" class="px-4 py-2 rounded-lg bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold text-xs sm:text-sm transition-colors whitespace-nowrap shrink-0">
            격납고 열기
          </button>
        </div>
      </div>

      <!-- Hangar & Career Lobby Overlay -->
      <div id="sc-hangar" class="fixed inset-0 z-30 flex items-center justify-center p-2 sm:p-5 bg-slate-950/80">
        <div class="w-full max-w-6xl max-h-[94vh] bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl flex flex-col overflow-hidden">
          <!-- Top Bar -->
          <header class="relative overflow-hidden border-b border-slate-800 bg-slate-950">
            <img src="${TEXTURE_ASSETS.apronBackdrop}" alt="국제공항 계류장 전경" referrerpolicy="no-referrer" class="absolute inset-0 w-full h-full object-cover opacity-30 pointer-events-none" />
            <div class="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-950/85 to-slate-950/65 pointer-events-none"></div>
            <div class="relative z-10 px-4 py-3.5 sm:px-6 sm:py-4 flex flex-wrap items-center justify-between gap-4">
              <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-xl bg-sky-500/20 border border-sky-400/40 text-sky-300 flex items-center justify-center shrink-0">
                  ${SVG_PLANE}
                </div>
                <div>
                  <h1 class="text-lg sm:text-xl font-extrabold tracking-tight text-white">SKY CAREER 3D</h1>
                  <p class="text-xs text-slate-300">글로벌 항공 운송 &amp; 초음속 비행 시뮬레이터</p>
                </div>
              </div>

              <div class="flex flex-wrap items-center gap-3 sm:gap-5">
                <div class="text-right">
                  <div class="text-[11px] text-slate-400">보유 자금</div>
                  <div id="sc-money" class="text-sm sm:text-base font-extrabold text-emerald-400 mono">$10,000</div>
                </div>
                <div class="h-7 w-px bg-slate-800 hidden sm:block"></div>
                <div class="text-right">
                  <div class="text-[11px] text-slate-400">완료 비행</div>
                  <div id="sc-flights" class="text-sm sm:text-base font-extrabold text-amber-400 mono">0회</div>
                </div>
                <div class="h-7 w-px bg-slate-800 hidden sm:block"></div>
                <div class="text-right">
                  <div class="text-[11px] text-slate-400">조종사 등급</div>
                  <div id="sc-rank" class="text-xs sm:text-sm font-bold text-sky-300">수습 조종사 (Cadet)</div>
                </div>
                <div class="flex items-center gap-1.5 ml-1">
                  <button id="sc-btn-inspect" title="3D 기체 둘러보기" class="px-2.5 py-2 rounded-lg bg-slate-800/90 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0">
                    ${SVG_EYE}
                    <span class="hidden md:inline">3D 감상</span>
                  </button>
                  <button id="sc-btn-mute" title="오디오 음소거 전환" class="p-2 rounded-lg bg-slate-800/90 hover:bg-slate-700 border border-slate-700 text-slate-200 transition-colors shrink-0">
                    ${SVG_VOLUME_ON}
                  </button>
                  <button id="sc-btn-xr" class="hidden px-2.5 py-2 rounded-lg bg-sky-500/20 hover:bg-sky-500/30 border border-sky-400/50 text-sky-200 text-xs font-bold transition-colors whitespace-nowrap shrink-0">
                    XR 진입
                  </button>
                  <button id="sc-btn-reset-career" class="px-2.5 py-2 rounded-lg bg-slate-800/80 hover:bg-rose-950/70 border border-slate-700 text-slate-400 hover:text-rose-300 text-xs font-semibold transition-colors whitespace-nowrap shrink-0">
                    초기화
                  </button>
                </div>
              </div>
            </div>
          </header>

          <!-- Main Two-Column Content -->
          <div class="grid grid-cols-1 lg:grid-cols-12 flex-1 overflow-y-auto hangar-scroll">
            <!-- Left: Aircraft Fleet Showcase -->
            <section class="lg:col-span-5 p-4 sm:p-5 border-b lg:border-b-0 lg:border-r border-slate-800 bg-slate-900/70 flex flex-col gap-3">
              <div class="flex items-center justify-between">
                <h2 class="text-xs sm:text-sm font-bold tracking-wide text-sky-300">01. 항공기 선택 및 구매</h2>
                <span class="text-[11px] text-slate-400">Tier 1 – 5</span>
              </div>

              <!-- Featured Selected Aircraft Card -->
              <div class="relative rounded-xl overflow-hidden border border-slate-700/80 bg-slate-950 aspect-[16/9] shrink-0">
                <img id="sc-hero-img" src="${AIRCRAFT_DB[0].imageUrl}" alt="${AIRCRAFT_DB[0].name}" referrerpolicy="no-referrer" class="w-full h-full object-cover" />
                <div class="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/35 to-transparent"></div>
                <div class="absolute bottom-3 left-3.5 right-3.5 flex items-end justify-between gap-2">
                  <div>
                    <div id="sc-hero-title" class="text-sm sm:text-base font-extrabold text-white leading-tight">${AIRCRAFT_DB[0].name}</div>
                    <div id="sc-hero-meta" class="text-[11px] text-slate-300 mt-0.5">${AIRCRAFT_DB[0].type} · 최고 ${AIRCRAFT_DB[0].maxSpeed} KTS</div>
                  </div>
                </div>
              </div>

              <div id="sc-aircraft-list" class="space-y-2 overflow-y-auto hangar-scroll pr-0.5"></div>
            </section>

            <!-- Right: Contracts & Flight Launch -->
            <section class="lg:col-span-7 p-4 sm:p-5 flex flex-col justify-between bg-slate-950/60 gap-4">
              <div class="flex flex-col gap-3">
                <div class="flex flex-wrap items-center justify-between gap-2">
                  <h2 class="text-xs sm:text-sm font-bold tracking-wide text-amber-300">02. 취항 노선 및 운송 계약</h2>
                  <div class="flex flex-wrap items-center gap-1.5">
                    <div class="flex items-center p-0.5 rounded-lg bg-slate-900 border border-slate-700/80">
                      <button data-tod="day" class="px-2.5 py-1 rounded-md text-xs font-semibold transition-colors whitespace-nowrap">주간</button>
                      <button data-tod="sunset" class="px-2.5 py-1 rounded-md text-xs font-semibold transition-colors whitespace-nowrap">노을 +15%</button>
                      <button data-tod="night" class="px-2.5 py-1 rounded-md text-xs font-semibold transition-colors whitespace-nowrap">야간 +35%</button>
                    </div>
                    <button id="sc-btn-refresh" class="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0">
                      ${SVG_REFRESH}
                      <span>노선 갱신</span>
                    </button>
                  </div>
                </div>

                <div id="sc-mission-list" class="space-y-2.5"></div>
              </div>

              <div class="pt-3 border-t border-slate-800/90 space-y-3">
                <div id="sc-summary" class="p-3 rounded-xl bg-slate-900/90 border border-slate-800 text-xs text-slate-300 flex flex-wrap justify-between items-center gap-2"></div>
                <button id="sc-btn-launch" class="w-full py-3.5 px-6 bg-sky-500 hover:bg-sky-400 text-slate-950 font-extrabold rounded-xl shadow-lg transition-colors flex items-center justify-center gap-2 text-sm sm:text-base whitespace-nowrap">
                  ${SVG_PLANE}
                  <span>활주로로 이동 및 이륙 준비</span>
                </button>
              </div>
            </section>
          </div>
        </div>
      </div>

      <!-- In-Flight HUD -->
      <div id="sc-hud" class="fixed inset-0 z-10 pointer-events-none hidden flex flex-col justify-between p-2.5 sm:p-5">
        <!-- Cockpit View Frame -->
        <div id="sc-cockpit-frame" class="fixed inset-0 pointer-events-none hidden z-0 flex flex-col justify-between">
          <div class="h-4 sm:h-6 bg-gradient-to-b from-slate-950/90 to-transparent"></div>
          <div class="mx-auto w-28 h-28 border border-sky-400/35 rounded-full flex items-center justify-center">
            <div class="w-6 h-0.5 bg-sky-400/75"></div>
          </div>
          <div class="h-24 sm:h-28 bg-gradient-to-t from-slate-950/95 via-slate-950/60 to-transparent border-t border-slate-800/40"></div>
        </div>

        <!-- Passenger Cabin Window Frame -->
        <div id="sc-passenger-frame" class="fixed inset-0 pointer-events-none hidden z-0 flex items-center justify-center">
          <div class="w-[84vw] h-[72vh] rounded-[56px] border-[24px] sm:border-[44px] border-slate-950/95 shadow-[inset_0_0_50px_rgba(0,0,0,0.9)] relative">
            <div class="absolute bottom-2.5 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-slate-950/90 border border-slate-800 text-[11px] text-slate-300 whitespace-nowrap">
              좌측 창가석 (Window Seat) · 순항 중
            </div>
          </div>
        </div>

        <!-- Top Telemetry Row -->
        <div class="relative z-10 flex flex-wrap justify-between items-start gap-2 pointer-events-auto">
          <!-- Mission Telemetry Card -->
          <div class="hud-panel rounded-xl p-2.5 sm:p-3 max-w-[260px] sm:max-w-sm">
            <div class="flex items-center gap-2 text-[11px] text-slate-300 mb-0.5">
              <span id="sc-hud-mtype" class="font-bold text-amber-300">화물 운송</span>
              <span aria-hidden="true">·</span>
              <span id="sc-hud-weather" class="text-sky-300 truncate">맑음</span>
            </div>
            <div id="sc-hud-mtitle" class="font-bold text-xs sm:text-sm text-white truncate">노선 정보</div>
            <div class="mt-2 grid grid-cols-3 gap-2 pt-2 border-t border-slate-800 text-xs">
              <div>
                <span class="text-slate-400 block text-[10px]">남은 거리</span>
                <span id="sc-hud-dist" class="font-bold text-emerald-400 mono">0.0 km</span>
              </div>
              <div>
                <span class="text-slate-400 block text-[10px]">잔여 연료</span>
                <span id="sc-hud-fuel" class="font-bold text-amber-400 mono">100%</span>
              </div>
              <div>
                <span class="text-slate-400 block text-[10px]">안정도</span>
                <span id="sc-hud-sat" class="font-bold text-sky-400 mono">100%</span>
              </div>
            </div>
          </div>

          <!-- Camera Mode & ILS / PAPI Approach Strip -->
          <div class="flex flex-col items-center gap-1.5 order-3 sm:order-2 w-full sm:w-auto">
            <div class="hud-panel rounded-xl p-1 flex items-center gap-1">
              <button data-cam="chase" class="px-2.5 py-1.5 rounded-lg text-xs font-bold transition-colors whitespace-nowrap">외부 3인칭</button>
              <button data-cam="cockpit" class="px-2.5 py-1.5 rounded-lg text-xs font-bold transition-colors whitespace-nowrap">조종석</button>
              <button data-cam="passenger" class="px-2.5 py-1.5 rounded-lg text-xs font-bold transition-colors whitespace-nowrap">승객 창가</button>
            </div>

            <div class="hud-panel px-3 py-1.5 rounded-full flex items-center gap-2.5 text-[10px]">
              <div class="flex items-center gap-1">
                <span class="text-slate-400 font-bold">HDG</span>
                <span id="sc-hud-hdg" class="font-extrabold text-sky-300 mono">360°</span>
              </div>
              <div class="h-3 w-px bg-slate-700"></div>
              <div class="flex items-center gap-1.5">
                <span class="text-slate-400 font-bold">ILS</span>
                <div class="w-20 sm:w-24 h-2 bg-slate-800 rounded-full relative overflow-hidden border border-slate-700">
                  <div class="w-0.5 h-full bg-emerald-400 absolute left-1/2 -translate-x-1/2"></div>
                  <div id="sc-ils-dot" class="w-2.5 h-2 rounded-full bg-amber-400 absolute top-0 left-1/2 -translate-x-1/2"></div>
                </div>
              </div>
              <div class="h-3 w-px bg-slate-700"></div>
              <div class="flex items-center gap-1" title="PAPI 진입각 지시등 (백2 적2 적정)">
                <span class="text-slate-400 font-bold">PAPI</span>
                <div id="sc-papi-1" class="papi-light bg-white"></div>
                <div id="sc-papi-2" class="papi-light bg-white"></div>
                <div id="sc-papi-3" class="papi-light bg-rose-500"></div>
                <div id="sc-papi-4" class="papi-light bg-rose-500"></div>
              </div>
              <span id="sc-hud-dest" class="font-bold text-emerald-300 mono">RKSI</span>
            </div>
          </div>

          <!-- Radar, Autopilot & Abort -->
          <div class="flex items-start gap-2 order-2 sm:order-3">
            <div class="hidden md:flex hud-panel w-20 h-20 rounded-full relative items-center justify-center overflow-hidden border-emerald-500/30">
              <div class="w-12 h-12 rounded-full border border-emerald-500/20 absolute"></div>
              <div class="w-full h-px bg-emerald-500/20 absolute"></div>
              <div class="h-full w-px bg-emerald-500/20 absolute"></div>
              <div class="w-0 h-0 border-l-[4px] border-l-transparent border-r-[4px] border-r-transparent border-b-[8px] border-b-sky-400 z-10"></div>
              <div id="sc-radar-dot" class="w-2.5 h-2.5 rounded-full bg-emerald-400 shadow-[0_0_8px_#34d399] absolute top-2 left-1/2 -translate-x-1/2"></div>
            </div>
            <div class="flex flex-col gap-1.5">
              <button id="sc-btn-ap" class="hud-panel px-3 py-2 rounded-xl text-xs font-bold text-slate-200 hover:border-sky-400 transition-colors whitespace-nowrap">
                AI 부기장: OFF
              </button>
              <button id="sc-btn-abort" class="hud-panel px-3 py-2 rounded-xl text-xs font-bold text-rose-400 hover:bg-rose-950/60 transition-colors whitespace-nowrap">
                비행 중단
              </button>
            </div>
          </div>
        </div>

        <!-- Mobile / Touch Flight Controls -->
        <div id="sc-mobile-pad" class="relative z-10 hidden justify-between items-end pointer-events-none my-auto">
          <div class="flex flex-col gap-2 pointer-events-auto">
            <button data-hold="throttleUp" class="w-12 h-12 rounded-xl hud-panel font-extrabold text-xs text-amber-300 active:bg-amber-500/30">THR+</button>
            <button data-hold="throttleDown" class="w-12 h-12 rounded-xl hud-panel font-extrabold text-xs text-slate-200 active:bg-slate-700">THR-</button>
          </div>
          <div class="grid grid-cols-3 gap-1.5 pointer-events-auto">
            <div></div>
            <button data-hold="pitchDown" class="w-12 h-12 rounded-xl hud-panel font-bold text-xs text-sky-300 active:bg-sky-500/30">기수▼</button>
            <div></div>
            <button data-hold="rollLeft" class="w-12 h-12 rounded-xl hud-panel font-bold text-xs text-sky-300 active:bg-sky-500/30">◀좌</button>
            <button data-hold="pitchUp" class="w-12 h-12 rounded-xl hud-panel font-bold text-xs text-sky-300 active:bg-sky-500/30">기수▲</button>
            <button data-hold="rollRight" class="w-12 h-12 rounded-xl hud-panel font-bold text-xs text-sky-300 active:bg-sky-500/30">우▶</button>
          </div>
        </div>

        <!-- Bottom Primary Flight Display Dock -->
        <div id="sc-bottom-dock" class="relative z-10 flex flex-wrap justify-between items-end gap-2.5 pointer-events-auto transition-transform duration-200">
          <!-- Throttle & Keys -->
          <div class="hud-panel rounded-2xl p-2.5 sm:p-3 flex items-center gap-3">
            <div class="flex flex-col items-center">
              <span class="text-[10px] text-slate-400 font-bold mb-1">THR</span>
              <div class="w-3.5 h-16 sm:h-20 bg-slate-800 rounded-full overflow-hidden flex flex-col justify-end border border-slate-700">
                <div id="sc-thr-bar" class="w-full bg-gradient-to-t from-sky-500 to-amber-400" style="height: 0%;"></div>
              </div>
              <span id="sc-hud-thr" class="text-xs font-extrabold text-amber-400 mono mt-1">0%</span>
            </div>
            <div class="hidden lg:block text-[11px] text-slate-300 space-y-1 border-l border-slate-800 pl-3">
              <div><kbd class="px-1.5 py-0.5 bg-slate-800 rounded text-sky-300 font-bold">Shift</kbd> / <kbd class="px-1.5 py-0.5 bg-slate-800 rounded text-sky-300 font-bold">Ctrl</kbd> 출력 증감</div>
              <div><kbd class="px-1.5 py-0.5 bg-slate-800 rounded text-sky-300 font-bold">W S</kbd> 기수 · <kbd class="px-1.5 py-0.5 bg-slate-800 rounded text-sky-300 font-bold">A D</kbd> 선회</div>
              <div><kbd class="px-1.5 py-0.5 bg-slate-800 rounded text-sky-300 font-bold">G</kbd> 기어 · <kbd class="px-1.5 py-0.5 bg-slate-800 rounded text-sky-300 font-bold">F</kbd> 플랩 · <kbd class="px-1.5 py-0.5 bg-slate-800 rounded text-sky-300 font-bold">B</kbd> 브레이크 · <kbd class="px-1.5 py-0.5 bg-slate-800 rounded text-sky-300 font-bold">C</kbd> 시점</div>
            </div>
          </div>

          <!-- Center Primary Flight Instruments -->
          <div class="hud-panel rounded-2xl p-2.5 sm:p-3 flex items-center gap-3 sm:gap-4 mx-auto">
            <div class="text-center w-16 sm:w-20">
              <div class="text-[10px] text-slate-400 font-bold">속도 (IAS)</div>
              <div id="sc-hud-spd" class="text-lg sm:text-2xl font-extrabold text-sky-400 mono">0</div>
              <div id="sc-hud-mach" class="text-[10px] text-sky-300 mono">M 0.00</div>
            </div>

            <div class="horizon-ring">
              <div id="sc-horizon" class="horizon-sky-ground"></div>
              <div class="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div class="w-14 h-0.5 bg-amber-400 relative">
                  <div class="w-2 h-2 rounded-full bg-amber-400 absolute left-1/2 -top-[3px] -translate-x-1/2"></div>
                </div>
              </div>
              <div id="sc-hud-pitch" class="absolute bottom-1 left-1/2 -translate-x-1/2 text-[10px] font-bold mono bg-slate-950/75 px-1.5 rounded">0°</div>
            </div>

            <div class="text-center w-16 sm:w-20">
              <div class="text-[10px] text-slate-400 font-bold">고도 (ALT)</div>
              <div id="sc-hud-alt" class="text-lg sm:text-2xl font-extrabold text-emerald-400 mono">0</div>
              <div id="sc-hud-vs" class="text-[10px] text-slate-400 mono">0 FPM</div>
            </div>
          </div>

          <!-- Aircraft Systems Toggle Cluster -->
          <div class="hud-panel rounded-2xl p-2 flex flex-wrap items-center gap-1.5">
            <button id="sc-btn-gear" class="px-2.5 py-2 rounded-xl text-xs font-bold border transition-colors whitespace-nowrap">기어: DOWN</button>
            <button id="sc-btn-flaps" class="px-2.5 py-2 rounded-xl text-xs font-bold bg-sky-500/20 text-sky-300 border border-sky-500/40 transition-colors whitespace-nowrap">플랩: 15°</button>
            <button id="sc-btn-brake" class="px-2.5 py-2 rounded-xl text-xs font-bold border transition-colors whitespace-nowrap">브레이크: OFF</button>
            <button id="sc-btn-nose" class="hidden px-2.5 py-2 rounded-xl text-xs font-bold bg-rose-500/20 text-rose-300 border border-rose-500/40 transition-colors whitespace-nowrap">노즈: UP</button>
          </div>
        </div>
      </div>

      <!-- Flight Settlement Result Modal -->
      <div id="sc-result" class="fixed inset-0 z-40 hidden items-center justify-center p-4 bg-slate-950/85">
        <div class="w-full max-w-md bg-slate-900 border border-slate-700 rounded-2xl p-6 shadow-2xl text-center">
          <div id="sc-res-badge" class="text-xs font-bold uppercase tracking-wider mb-1 text-emerald-400">SAFE LANDING</div>
          <h2 id="sc-res-title" class="text-xl font-extrabold text-white mb-1">도착 완료</h2>
          <p id="sc-res-fpm" class="text-xs text-slate-400 mono mb-4">Touchdown: -180 FPM</p>

          <div class="bg-slate-950/80 rounded-xl p-4 border border-slate-800 space-y-2.5 text-sm mb-5">
            <div class="flex justify-between text-slate-400">
              <span>기본 운송 계약금</span>
              <span id="sc-res-base" class="font-bold text-white mono">$0</span>
            </div>
            <div class="flex justify-between text-slate-400">
              <span>착륙 정밀도 보너스</span>
              <span id="sc-res-landing" class="font-bold text-sky-400 mono">+$0</span>
            </div>
            <div class="flex justify-between text-slate-400">
              <span>승객 · 화물 안정도</span>
              <span id="sc-res-sat" class="font-bold text-amber-400 mono">+$0</span>
            </div>
            <div class="pt-2.5 border-t border-slate-800 flex justify-between items-center">
              <span class="font-bold text-slate-200">최종 정산 수익</span>
              <span id="sc-res-total" class="text-xl font-extrabold text-emerald-400 mono">$0</span>
            </div>
          </div>

          <div class="grid grid-cols-2 gap-2.5">
            <button id="sc-btn-retry" class="py-3 px-4 bg-slate-800 hover:bg-slate-700 text-slate-100 font-bold rounded-xl border border-slate-700 transition-colors text-sm">
              동일 노선 재비행
            </button>
            <button id="sc-btn-hangar-return" class="py-3 px-4 bg-sky-500 hover:bg-sky-400 text-slate-950 font-extrabold rounded-xl transition-colors text-sm">
              격납고 복귀
            </button>
          </div>
        </div>
      </div>
    `;

    // Bind elements
    this.hangarModal = this.q('#sc-hangar');
    this.inspectBar = this.q('#sc-inspect-bar');
    this.flightHud = this.q('#sc-hud');
    this.mobileControls = this.q('#sc-mobile-pad');
    this.resultModal = this.q('#sc-result');
    this.cockpitFrame = this.q('#sc-cockpit-frame');
    this.passengerFrame = this.q('#sc-passenger-frame');
    this.alertToast = this.q('#sc-toast');
    this.alertToastText = this.q('#sc-toast-text');

    this.uiMoney = this.q('#sc-money');
    this.uiFlights = this.q('#sc-flights');
    this.uiRank = this.q('#sc-rank');
    this.aircraftList = this.q('#sc-aircraft-list');
    this.missionList = this.q('#sc-mission-list');
    this.selectedSummary = this.q('#sc-summary');
    this.heroPreviewImg = this.q('#sc-hero-img') as HTMLImageElement;
    this.heroPreviewTitle = this.q('#sc-hero-title');
    this.heroPreviewMeta = this.q('#sc-hero-meta');
    this.btnMute = this.q('#sc-btn-mute') as HTMLButtonElement;
    this.btnXrEnter = this.q('#sc-btn-xr') as HTMLButtonElement;
    this.btnResetCareer = this.q('#sc-btn-reset-career') as HTMLButtonElement;

    this.hudMissionType = this.q('#sc-hud-mtype');
    this.hudWeather = this.q('#sc-hud-weather');
    this.hudMissionTitle = this.q('#sc-hud-mtitle');
    this.hudDistance = this.q('#sc-hud-dist');
    this.hudFuel = this.q('#sc-hud-fuel');
    this.hudSatisfaction = this.q('#sc-hud-sat');
    this.hudHeading = this.q('#sc-hud-hdg');
    this.ilsIndicator = this.q('#sc-ils-dot');
    this.papiLights = [
      this.q('#sc-papi-1'),
      this.q('#sc-papi-2'),
      this.q('#sc-papi-3'),
      this.q('#sc-papi-4'),
    ];
    this.hudDestCode = this.q('#sc-hud-dest');
    this.radarDestDot = this.q('#sc-radar-dot');
    this.btnAutopilot = this.q('#sc-btn-ap') as HTMLButtonElement;
    this.hudSpeed = this.q('#sc-hud-spd');
    this.hudMach = this.q('#sc-hud-mach');
    this.hudAlt = this.q('#sc-hud-alt');
    this.hudVs = this.q('#sc-hud-vs');
    this.hudThrottle = this.q('#sc-hud-thr');
    this.throttleBar = this.q('#sc-thr-bar');
    this.horizonSkyGround = this.q('#sc-horizon');
    this.hudPitchText = this.q('#sc-hud-pitch');
    this.btnGear = this.q('#sc-btn-gear') as HTMLButtonElement;
    this.btnFlaps = this.q('#sc-btn-flaps') as HTMLButtonElement;
    this.btnBrake = this.q('#sc-btn-brake') as HTMLButtonElement;
    this.btnNose = this.q('#sc-btn-nose') as HTMLButtonElement;
    this.hudBottomDock = this.q('#sc-bottom-dock');

    this.resBadge = this.q('#sc-res-badge');
    this.resTitle = this.q('#sc-res-title');
    this.resFpm = this.q('#sc-res-fpm');
    this.resBase = this.q('#sc-res-base');
    this.resLanding = this.q('#sc-res-landing');
    this.resSat = this.q('#sc-res-sat');
    this.resTotal = this.q('#sc-res-total');

    // Bind listeners
    this.q('#sc-btn-refresh').addEventListener('click', () => this.callbacks.onRefreshMissions());
    this.q('#sc-btn-launch').addEventListener('click', () => this.callbacks.onStartFlight());
    this.q('#sc-btn-abort').addEventListener('click', () => this.callbacks.onAbortFlight());
    this.q('#sc-btn-hangar-return').addEventListener('click', () => this.callbacks.onReturnToHangar());
    this.q('#sc-btn-retry').addEventListener('click', () => this.callbacks.onRetryFlight());
    this.btnAutopilot.addEventListener('click', () => this.callbacks.onToggleAutopilot());
    this.btnGear.addEventListener('click', () => this.callbacks.onToggleGear());
    this.btnFlaps.addEventListener('click', () => this.callbacks.onCycleFlaps());
    this.btnBrake.addEventListener('click', () => this.callbacks.onToggleBrake());
    this.btnNose.addEventListener('click', () => this.callbacks.onToggleDroopNose());

    this.btnMute.addEventListener('click', () => {
      const muted = this.callbacks.onToggleMute();
      this.btnMute.innerHTML = muted ? SVG_VOLUME_OFF : SVG_VOLUME_ON;
    });

    this.q('#sc-btn-inspect').addEventListener('click', () => {
      this.hangarModal.classList.add('hidden');
      this.inspectBar.classList.remove('hidden');
      this.callbacks.onToggleInspect3D(true);
    });
    this.q('#sc-btn-open-hangar').addEventListener('click', () => {
      this.inspectBar.classList.add('hidden');
      this.hangarModal.classList.remove('hidden');
      this.callbacks.onToggleInspect3D(false);
    });

    this.btnXrEnter.addEventListener('click', () => this.callbacks.onEnterXR?.());

    this.btnResetCareer.addEventListener('click', () => {
      if (!this.resetPending) {
        this.resetPending = true;
        this.btnResetCareer.textContent = '재확인 클릭';
        this.btnResetCareer.classList.add('text-rose-300', 'border-rose-500/60');
        window.setTimeout(() => {
          this.resetPending = false;
          this.btnResetCareer.textContent = '초기화';
          this.btnResetCareer.classList.remove('text-rose-300', 'border-rose-500/60');
        }, 3000);
        return;
      }
      this.resetPending = false;
      this.btnResetCareer.textContent = '초기화';
      this.btnResetCareer.classList.remove('text-rose-300', 'border-rose-500/60');
      this.callbacks.onResetCareer();
    });

    this.root.querySelectorAll<HTMLButtonElement>('[data-tod]').forEach((btn) => {
      const tod = btn.dataset.tod as TimeOfDay;
      this.todButtons.set(tod, btn);
      btn.addEventListener('click', () => this.callbacks.onTimeOfDayChange(tod));
    });

    this.root.querySelectorAll<HTMLButtonElement>('[data-cam]').forEach((btn) => {
      const mode = btn.dataset.cam as CameraMode;
      this.camButtons.set(mode, btn);
      btn.addEventListener('click', () => this.callbacks.onSetCameraMode(mode));
    });

    // Touch/Pointer hold buttons for mobile controls
    this.root.querySelectorAll<HTMLButtonElement>('[data-hold]').forEach((btn) => {
      const key = btn.dataset.hold as keyof FlightInputState;
      const start = (e: Event) => {
        e.preventDefault();
        this.inputs[key] = true;
      };
      const end = (e: Event) => {
        e.preventDefault();
        this.inputs[key] = false;
      };
      btn.addEventListener('pointerdown', start);
      btn.addEventListener('pointerup', end);
      btn.addEventListener('pointercancel', end);
      btn.addEventListener('pointerleave', end);
    });
  }

  private q(selector: string): HTMLElement {
    const el = this.root.querySelector<HTMLElement>(selector);
    if (!el) throw new Error(`HUD element missing: ${selector}`);
    return el;
  }

  setXRSupported(supported: boolean): void {
    this.btnXrEnter.classList.toggle('hidden', !supported);
  }

  showAlert(message: string): void {
    this.alertToastText.textContent = message;
    this.alertToast.classList.remove('opacity-0');
    this.alertToast.classList.add('opacity-100');
    if (this.toastTimer !== null) window.clearTimeout(this.toastTimer);
    this.toastTimer = window.setTimeout(() => {
      this.alertToast.classList.remove('opacity-100');
      this.alertToast.classList.add('opacity-0');
    }, 3400);
  }

  triggerSonicShake(): void {
    document.body.classList.add('sonic-shake');
    window.setTimeout(() => document.body.classList.remove('sonic-shake'), 600);
  }

  toggleCompactHUD(): void {
    this.hudCompact = !this.hudCompact;
    this.hudBottomDock.classList.toggle('translate-y-[120%]', this.hudCompact);
  }

  renderHangar(
    career: PlayerCareerState,
    missions: MissionContract[],
    selectedMission: MissionContract | null,
    timeOfDay: TimeOfDay
  ): void {
    this.uiMoney.textContent = `$${career.money.toLocaleString()}`;
    this.uiFlights.textContent = `${career.completedFlights}회`;
    this.uiRank.textContent = getPilotRank(career.completedFlights);

    for (const [tod, btn] of this.todButtons.entries()) {
      const active = tod === timeOfDay;
      btn.className = active
        ? 'px-2.5 py-1 rounded-md text-xs font-bold bg-sky-500 text-slate-950 transition-colors whitespace-nowrap'
        : 'px-2.5 py-1 rounded-md text-xs font-semibold text-slate-300 hover:text-white transition-colors whitespace-nowrap';
    }

    const selectedAc =
      AIRCRAFT_DB.find((a) => a.id === career.selectedAircraftId) ?? AIRCRAFT_DB[0];
    this.heroPreviewImg.src = selectedAc.imageUrl;
    this.heroPreviewImg.alt = selectedAc.name;
    this.heroPreviewTitle.textContent = selectedAc.name;
    this.heroPreviewMeta.textContent = `${selectedAc.type} · 최고 ${selectedAc.maxSpeed} KTS · 이륙 Vr ${selectedAc.vrSpeed} KTS`;

    this.aircraftList.innerHTML = '';
    for (const ac of AIRCRAFT_DB) {
      const unlocked = career.unlockedIds.includes(ac.id);
      const isSelected = ac.id === career.selectedAircraftId;
      const canAfford = career.money >= ac.price;

      const card = document.createElement('button');
      card.type = 'button';
      card.className = `w-full text-left p-2.5 rounded-xl border transition-colors flex items-center gap-3 ${
        isSelected
          ? 'bg-sky-950/60 border-sky-400'
          : 'bg-slate-800/50 border-slate-700/70 hover:border-slate-500'
      }`;
      card.addEventListener('click', () => this.callbacks.onSelectAircraft(ac.id));

      const statusLabel = unlocked
        ? isSelected
          ? '<span class="text-[11px] font-bold text-sky-300 whitespace-nowrap">운항 선택</span>'
          : '<span class="text-[11px] font-semibold text-slate-400 whitespace-nowrap">보유 중</span>'
        : `<span class="text-xs font-bold mono whitespace-nowrap ${
            canAfford ? 'text-emerald-400' : 'text-slate-500'
          }">구매 $${ac.price.toLocaleString()}</span>`;

      card.innerHTML = `
        <div class="w-16 h-12 rounded-lg overflow-hidden bg-slate-950 border border-slate-700/70 shrink-0">
          <img src="${ac.imageUrl}" alt="${ac.name}" referrerpolicy="no-referrer" class="w-full h-full object-cover" />
        </div>
        <div class="min-w-0 flex-1">
          <div class="flex items-center justify-between gap-2">
            <span class="font-bold text-xs sm:text-sm text-white truncate">${ac.name}</span>
            ${statusLabel}
          </div>
          <div class="text-[11px] text-slate-300 mt-0.5 truncate">Tier ${ac.tier} · ${ac.type} · 최고 ${ac.maxSpeed} KTS</div>
          <div class="text-[11px] text-slate-400 truncate">${ac.capacityDesc}</div>
        </div>
      `;
      this.aircraftList.appendChild(card);
    }

    this.missionList.innerHTML = '';
    for (const m of missions) {
      const isSelected = selectedMission?.id === m.id;
      const card = document.createElement('button');
      card.type = 'button';
      card.className = `w-full text-left p-3 rounded-xl border transition-colors flex items-center justify-between gap-3 ${
        isSelected
          ? 'bg-amber-950/30 border-amber-400'
          : 'bg-slate-900/80 border-slate-800 hover:border-slate-600'
      }`;
      card.addEventListener('click', () => this.callbacks.onSelectMission(m.id));

      card.innerHTML = `
        <div class="min-w-0 flex-1">
          <div class="text-[11px] text-slate-400 truncate">
            <span class="text-amber-300 font-semibold">${m.type}</span>
            <span aria-hidden="true"> · </span>
            <span>${m.weather.name}</span>
          </div>
          <div class="font-bold text-sm text-white mt-0.5 truncate">${m.title}</div>
          <div class="text-xs text-slate-400 mt-0.5 truncate">
            도착 <strong class="text-emerald-300 font-semibold">${m.destAirport.name}</strong> · 거리 <span class="mono text-slate-200">${m.distanceKm} km</span> · 적재 <span class="mono text-slate-200">${m.payloadTons}t</span>
          </div>
        </div>
        <div class="text-right shrink-0">
          <div class="text-[10px] text-slate-400">계약 보상</div>
          <div class="text-sm sm:text-base font-extrabold text-emerald-400 mono">$${m.reward.toLocaleString()}</div>
        </div>
      `;
      this.missionList.appendChild(card);
    }

    const bonusText =
      timeOfDay === 'night'
        ? ' · 야간 계기비행 +35%'
        : timeOfDay === 'sunset'
          ? ' · 노을 비행 +15%'
          : '';
    if (selectedMission) {
      this.selectedSummary.innerHTML = `
        <div class="truncate">
          <strong class="text-white">${selectedAc.name}</strong>
          <span class="text-slate-500 mx-1">→</span>
          <strong class="text-emerald-300">${selectedMission.destAirport.name} (${selectedMission.distanceKm} km)</strong>
          <span class="text-amber-300">${bonusText}</span>
        </div>
        <div class="text-sky-300 font-bold mono shrink-0">이륙 Vr ${selectedAc.vrSpeed} KTS</div>
      `;
    }
  }

  showFlightHUD(ac: AircraftSpec, mission: MissionContract): void {
    this.hangarModal.classList.add('hidden');
    this.inspectBar.classList.add('hidden');
    this.resultModal.classList.add('hidden');
    this.resultModal.classList.remove('flex');
    this.flightHud.classList.remove('hidden');
    this.syncMobileControlsVisibility();

    this.btnNose.classList.toggle('hidden', !ac.hasDroopNose);
    this.hudMissionType.textContent = mission.type;
    this.hudWeather.textContent = mission.weather.name;
    this.hudMissionTitle.textContent = mission.title;
    this.hudDestCode.textContent = mission.destAirport.code;
  }

  updateCameraUI(mode: CameraMode): void {
    for (const [m, btn] of this.camButtons.entries()) {
      btn.className =
        m === mode
          ? 'px-2.5 py-1.5 rounded-lg text-xs font-bold bg-sky-500 text-slate-950 transition-colors whitespace-nowrap'
          : 'px-2.5 py-1.5 rounded-lg text-xs font-bold text-slate-300 hover:text-white transition-colors whitespace-nowrap';
    }
    this.cockpitFrame.classList.toggle('hidden', mode !== 'cockpit');
    this.passengerFrame.classList.toggle('hidden', mode !== 'passenger');
  }

  updateSystemButtons(flight: FlightPhysicsState): void {
    this.btnGear.textContent = flight.gearDown ? '기어: DOWN' : '기어: UP';
    this.btnGear.className = flight.gearDown
      ? 'px-2.5 py-2 rounded-xl text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 transition-colors whitespace-nowrap'
      : 'px-2.5 py-2 rounded-xl text-xs font-bold bg-slate-800 text-slate-400 border border-slate-700 transition-colors whitespace-nowrap';

    this.btnFlaps.textContent = `플랩: ${flight.flaps}°`;

    this.btnBrake.textContent = flight.brake ? '브레이크: ON' : '브레이크: OFF';
    this.btnBrake.className = flight.brake
      ? 'px-2.5 py-2 rounded-xl text-xs font-bold bg-amber-500/25 text-amber-300 border border-amber-500/50 transition-colors whitespace-nowrap'
      : 'px-2.5 py-2 rounded-xl text-xs font-bold bg-slate-800 text-slate-300 border border-slate-700 transition-colors whitespace-nowrap';

    this.btnNose.textContent = flight.droopNose ? '노즈: DOWN' : '노즈: UP';

    this.btnAutopilot.textContent = flight.autopilot ? 'AI 부기장: ON' : 'AI 부기장: OFF';
    this.btnAutopilot.className = flight.autopilot
      ? 'hud-panel px-3 py-2 rounded-xl text-xs font-bold bg-sky-500/30 text-sky-300 border border-sky-400 transition-colors whitespace-nowrap'
      : 'hud-panel px-3 py-2 rounded-xl text-xs font-bold text-slate-200 hover:border-sky-400 transition-colors whitespace-nowrap';
  }

  updateTelemetry(flight: FlightPhysicsState): void {
    const altFt = Math.max(0, Math.round((flight.pos.y - 2) * 3.28));
    const speedKts = Math.round(flight.speed);
    const machNum = flight.speed / 661;
    const runLen = flight.currentMission?.destAirport.runLen ?? 1600;
    const runwayCenterZ = flight.destZ - runLen / 2 + 100;
    const distRemKm = Math.max(0, (flight.pos.z - runwayCenterZ) / 220).toFixed(1);

    this.hudSpeed.textContent = String(speedKts);
    this.hudMach.textContent = `M ${machNum.toFixed(2)}`;
    this.hudMach.className =
      machNum >= 1.0
        ? 'text-[10px] text-rose-400 font-extrabold mono'
        : 'text-[10px] text-sky-300 mono';

    this.hudAlt.textContent = altFt.toLocaleString();
    this.hudVs.textContent = `${flight.verticalSpeedFpm > 0 ? '+' : ''}${flight.verticalSpeedFpm} FPM`;
    this.hudThrottle.textContent = `${Math.round(flight.throttle)}%`;
    this.throttleBar.style.height = `${flight.throttle}%`;
    this.hudDistance.textContent = `${distRemKm} km`;
    this.hudSatisfaction.textContent = `${Math.round(flight.satisfaction)}%`;

    let hdg = Math.round((-(flight.rot.y * 180) / Math.PI) % 360);
    if (hdg <= 0) hdg += 360;
    this.hudHeading.textContent = `${String(hdg).padStart(3, '0')}°`;

    const distToThreshold = Math.max(100, flight.pos.z - flight.destZ);
    const glideAngleDeg = (Math.atan2(flight.pos.y, distToThreshold) * 180) / Math.PI;
    const whites =
      glideAngleDeg > 5.5
        ? 4
        : glideAngleDeg > 4.2
          ? 3
          : glideAngleDeg > 2.6
            ? 2
            : glideAngleDeg > 1.5
              ? 1
              : 0;
    for (let i = 0; i < 4; i++) {
      this.papiLights[i].className =
        i < whites
          ? 'papi-light bg-white shadow-[0_0_6px_#ffffff]'
          : 'papi-light bg-rose-500 shadow-[0_0_6px_#f43f5e]';
    }

    const relX = Math.max(12, Math.min(88, 50 - flight.pos.x / 40));
    const relY = Math.max(12, Math.min(88, 50 - (flight.pos.z - runwayCenterZ) / 250));
    this.radarDestDot.style.left = `${relX}%`;
    this.radarDestDot.style.top = `${relY}%`;

    this.hudFuel.textContent = `${Math.ceil(flight.fuel)}%`;
    this.hudFuel.className =
      flight.fuel <= 20
        ? 'font-bold text-rose-400 mono'
        : 'font-bold text-amber-400 mono';

    const ilsPct = Math.max(5, Math.min(95, 50 - flight.pos.x / 6));
    this.ilsIndicator.style.left = `${ilsPct}%`;

    const pitchDeg = Math.round((flight.rot.x * 180) / Math.PI);
    const rollDeg = (flight.rot.z * 180) / Math.PI;
    this.horizonSkyGround.style.transform = `rotate(${rollDeg}deg) translateY(${pitchDeg * 1.8}px)`;
    this.hudPitchText.textContent = `${pitchDeg}°`;
  }

  showResult(summary: FlightResultSummary): void {
    this.mobileControls.classList.add('hidden');
    this.mobileControls.classList.remove('flex');

    if (summary.success) {
      if (summary.isEmergency) {
        this.resBadge.className = 'text-xs font-bold uppercase tracking-wider mb-1 text-amber-400';
        this.resBadge.textContent = 'EMERGENCY GLIDE LANDING';
        this.resTitle.textContent = '비상 활공 착륙 성공 — 전원 무사';
      } else {
        this.resBadge.className = 'text-xs font-bold uppercase tracking-wider mb-1 text-emerald-400';
        this.resBadge.textContent = summary.isButter
          ? 'BUTTER LANDING · 정밀 착륙'
          : 'SAFE LANDING · 안전 착륙';
        this.resTitle.textContent = `${summary.airportName} 도착 완료`;
      }
      this.resFpm.textContent = `Touchdown Vertical Speed: -${summary.touchdownFpm} FPM`;
    } else {
      this.resBadge.className = 'text-xs font-bold uppercase tracking-wider mb-1 text-rose-400';
      this.resBadge.textContent = 'LANDING FAILURE';
      this.resTitle.textContent = summary.failReason;
      this.resFpm.textContent = `Impact Vertical Speed: -${summary.touchdownFpm} FPM`;
    }

    this.resBase.textContent = `$${summary.basePay.toLocaleString()}`;
    this.resLanding.textContent = `+$${summary.landingBonus.toLocaleString()}`;
    this.resSat.textContent = `+$${summary.satBonus.toLocaleString()} (${summary.satisfactionPct}%)`;
    this.resTotal.textContent = `$${summary.totalPay.toLocaleString()}`;

    this.resultModal.classList.remove('hidden');
    this.resultModal.classList.add('flex');
  }

  showHangar(): void {
    this.resultModal.classList.add('hidden');
    this.resultModal.classList.remove('flex');
    this.flightHud.classList.add('hidden');
    this.mobileControls.classList.add('hidden');
    this.mobileControls.classList.remove('flex');
    this.cockpitFrame.classList.add('hidden');
    this.passengerFrame.classList.add('hidden');
    this.inspectBar.classList.add('hidden');
    this.hangarModal.classList.remove('hidden');
  }

  dispose(): void {
    window.removeEventListener('resize', this.onResizeBound);
    if (this.toastTimer !== null) window.clearTimeout(this.toastTimer);
    this.root.innerHTML = '';
  }
}
