import aerialTerrainUrl from './assets/images/aerial_terrain_texture_1794636433011.jpg';
import runwayAsphaltUrl from './assets/images/runway_asphalt_texture_1794636433319.jpg';
import oceanWaterUrl from './assets/images/ocean_water_texture_1794636433235.jpg';
import skyscraperFacadeUrl from './assets/images/skyscraper_facade_texture_1794636433915.jpg';
import aerospaceHullUrl from './assets/images/aerospace_hull_texture_1794636435092.jpg';
import skyDomeUrl from './assets/images/sky_dome_panorama_1794636434846.jpg';
import cessnaImageUrl from './assets/images/cessna_skyhawk_hangar_1794636435987.jpg';
import kingAirImageUrl from './assets/images/kingair_turboprop_hangar_1794636436628.jpg';
import boeing737ImageUrl from './assets/images/boeing_737_tarmac_1794636437225.jpg';
import boeing747ImageUrl from './assets/images/boeing_747_jumbo_1794636437433.jpg';
import concordeImageUrl from './assets/images/concorde_supersonic_hangar_1794636437010.jpg';
import apronTwilightUrl from './assets/images/airport_apron_twilight_1794636437923.jpg';

import type {AircraftSpec, AirportSpec, WeatherCondition} from './types.ts';

export const TEXTURE_ASSETS = {
  aerialTerrain: aerialTerrainUrl,
  runwayAsphalt: runwayAsphaltUrl,
  oceanWater: oceanWaterUrl,
  skyscraperFacade: skyscraperFacadeUrl,
  aerospaceHull: aerospaceHullUrl,
  skyDome: skyDomeUrl,
  apronBackdrop: apronTwilightUrl,
} as const;

export const AIRPORTS_DB: AirportSpec[] = [
  {code: 'RKSS', name: '김포 도심 공항', desc: '단거리/경비행기 허브', runLen: 1400},
  {code: 'RKPC', name: '제주 해안 국제공항', desc: '해풍 및 관광 노선', runLen: 1600},
  {code: 'RKSI', name: '인천 글로벌 허브', desc: '대형 화물/여객 허브', runLen: 2000},
  {code: 'RJTT', name: '도쿄 하네다 공항', desc: '동북아 비즈니스 노선', runLen: 1800},
  {code: 'KJFK', name: '뉴욕 JFK 초음속 터미널', desc: '대륙간 초음속 특급 노선', runLen: 2400},
];

export const AIRCRAFT_DB: AircraftSpec[] = [
  {
    id: 'cessna',
    tier: 1,
    name: '세스타 172 스카이호프',
    type: '경비행기 (단발 프로펠러)',
    price: 0,
    maxSpeed: 165,
    vrSpeed: 55,
    stallSpeed: 40,
    accel: 26,
    turnRate: 1.4,
    pitchRate: 1.25,
    mass: 1.1,
    fuelBurnRate: 0.2,
    capacityDesc: '소형 화물 300kg / VIP 2명',
    color: 0xf8fafc,
    accentColor: 0x0284c7,
    hasDroopNose: false,
    imageUrl: cessnaImageUrl,
  },
  {
    id: 'kingair',
    tier: 2,
    name: '비치윙 킹에어로 350',
    type: '쌍발 터보프롭',
    price: 22000,
    maxSpeed: 330,
    vrSpeed: 90,
    stallSpeed: 70,
    accel: 38,
    turnRate: 1.2,
    pitchRate: 1.1,
    mass: 2.5,
    fuelBurnRate: 0.27,
    capacityDesc: '중형 화물 1.5톤 / 승객 10명',
    color: 0xe2e8f0,
    accentColor: 0xd97706,
    hasDroopNose: false,
    imageUrl: kingAirImageUrl,
  },
  {
    id: 'b737',
    tier: 3,
    name: '보윙 737-800 NG',
    type: '중단거리 제트 여객기',
    price: 75000,
    maxSpeed: 520,
    vrSpeed: 130,
    stallSpeed: 105,
    accel: 55,
    turnRate: 0.9,
    pitchRate: 0.9,
    mass: 6.0,
    fuelBurnRate: 0.34,
    capacityDesc: '항공 수하물 8톤 / 승객 160명',
    color: 0xffffff,
    accentColor: 0x2563eb,
    hasDroopNose: false,
    imageUrl: boeing737ImageUrl,
  },
  {
    id: 'b747',
    tier: 4,
    name: '보윙 747-8 점보 제트',
    type: '초대형 화물/여객기',
    price: 190000,
    maxSpeed: 610,
    vrSpeed: 150,
    stallSpeed: 120,
    accel: 64,
    turnRate: 0.72,
    pitchRate: 0.75,
    mass: 12.0,
    fuelBurnRate: 0.42,
    capacityDesc: '특수 중장비 40톤 / 승객 410명',
    color: 0xf1f5f9,
    accentColor: 0x1e3a8a,
    hasDroopNose: false,
    imageUrl: boeing747ImageUrl,
  },
  {
    id: 'concorde',
    tier: 5,
    name: '콩코디아 (Concordia)',
    type: '초음속 여객기 (Mach 2.04)',
    price: 480000,
    maxSpeed: 1350,
    vrSpeed: 190,
    stallSpeed: 150,
    accel: 115,
    turnRate: 0.95,
    pitchRate: 1.0,
    mass: 8.5,
    fuelBurnRate: 0.54,
    capacityDesc: '초고액 VIP 100명 / 긴급 특수 화물',
    color: 0xffffff,
    accentColor: 0xe11d48,
    hasDroopNose: true,
    imageUrl: concordeImageUrl,
  },
];

export const CARGO_TEMPLATES: Array<{
  title: string;
  type: string;
  category: 'cargo' | 'passenger' | 'vip';
  baseTimeSec: number;
  rewardBase: number;
}> = [
  {title: '긴급 의료품 및 혈액 택배', type: '화물 운송', category: 'cargo', baseTimeSec: 55, rewardBase: 5200},
  {title: '정밀 반도체 웨이퍼 수송', type: '화물 운송', category: 'cargo', baseTimeSec: 70, rewardBase: 8500},
  {title: 'VIP 비즈니스 전세기 운항', type: '승객 수송', category: 'vip', baseTimeSec: 65, rewardBase: 7800},
  {title: '정기 여객 및 위탁 수하물', type: '승객 수송', category: 'passenger', baseTimeSec: 85, rewardBase: 13500},
  {title: '초특급 외교 행낭 및 귀빈', type: '특수 운송', category: 'vip', baseTimeSec: 95, rewardBase: 22000},
];

export const WEATHER_PRESETS: WeatherCondition[] = [
  {name: '맑음 · 순풍 2kt', windX: 0.15, vis: 1.0, bonus: 1.0},
  {name: '부분 구름 · 측풍 8kt', windX: 1.1, vis: 0.85, bonus: 1.25},
  {name: '우천 시계불량 · 강풍 16kt', windX: 2.3, vis: 0.65, bonus: 1.55},
];

export const CAREER_STORAGE_KEY = 'sky_career_3d_save_v1';
