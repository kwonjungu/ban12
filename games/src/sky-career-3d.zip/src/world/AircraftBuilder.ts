import * as THREE from 'three';

import {TEXTURE_ASSETS} from '../constants.ts';
import type {AircraftSpec} from '../types.ts';

export interface AircraftModelHandles {
  root: THREE.Group;
  gearGroup: THREE.Group;
  noseGroup: THREE.Group;
  propellers: THREE.Object3D[];
  sonicCone: THREE.Mesh;
  landingLight: THREE.SpotLight;
  dispose: () => void;
}

export function buildAircraftModel(
  ac: AircraftSpec,
  renderer: THREE.WebGLRenderer,
  sharedHullTexture?: THREE.Texture
): AircraftModelHandles {
  const root = new THREE.Group();
  const propellers: THREE.Object3D[] = [];
  const geometries: THREE.BufferGeometry[] = [];
  const materials: THREE.Material[] = [];

  const ownsHullTexture = !sharedHullTexture;
  const hullTexture =
    sharedHullTexture ??
    (() => {
      const loader = new THREE.TextureLoader();
      const tex = loader.load(TEXTURE_ASSETS.aerospaceHull);
      tex.colorSpace = THREE.SRGBColorSpace;
      tex.anisotropy = Math.min(4, renderer.capabilities.getMaxAnisotropy());
      tex.wrapS = THREE.RepeatWrapping;
      tex.wrapT = THREE.RepeatWrapping;
      tex.repeat.set(2, 3);
      return tex;
    })();

  const scale = 0.7 + ac.tier * 0.28;
  const bodyLen = ac.id === 'concorde' ? 18.5 : 8.2 + ac.tier * 2.2;
  const bodyRad = ac.id === 'concorde' ? 0.86 : 0.75 + ac.tier * 0.25;

  const hullMat = new THREE.MeshPhysicalMaterial({
    color: ac.color,
    map: hullTexture,
    metalness: 0.35,
    roughness: 0.28,
    clearcoat: 0.85,
    clearcoatRoughness: 0.14,
  });
  const accentMat = new THREE.MeshPhysicalMaterial({
    color: ac.accentColor,
    metalness: 0.45,
    roughness: 0.26,
    clearcoat: 0.9,
    clearcoatRoughness: 0.12,
  });
  const chromeMat = new THREE.MeshStandardMaterial({
    color: 0xdbeafe,
    metalness: 0.92,
    roughness: 0.16,
  });
  const glassMat = new THREE.MeshPhysicalMaterial({
    color: 0x0f172a,
    metalness: 0.15,
    roughness: 0.08,
    clearcoat: 1.0,
    clearcoatRoughness: 0.05,
  });
  const rubberMat = new THREE.MeshStandardMaterial({
    color: 0x090d16,
    roughness: 0.88,
    metalness: 0.05,
  });
  const burnerMat = new THREE.MeshBasicMaterial({color: 0xf97316});
  materials.push(hullMat, accentMat, chromeMat, glassMat, rubberMat, burnerMat);

  // 1. Primary Fuselage
  const fuselageGeo = new THREE.CylinderGeometry(bodyRad * 0.88, bodyRad, bodyLen, 24);
  geometries.push(fuselageGeo);
  const fuselage = new THREE.Mesh(fuselageGeo, hullMat);
  fuselage.rotation.x = Math.PI / 2;
  fuselage.castShadow = true;
  root.add(fuselage);

  // Boeing 747 Upper Deck Hump
  if (ac.id === 'b747') {
    const humpGeo = new THREE.CapsuleGeometry(bodyRad * 0.62, bodyLen * 0.24, 8, 16);
    geometries.push(humpGeo);
    const hump = new THREE.Mesh(humpGeo, hullMat);
    hump.rotation.x = Math.PI / 2;
    hump.position.set(0, bodyRad * 0.56, -bodyLen * 0.24);
    root.add(hump);
  }

  // Airline Livery Cheatline Stripe
  const stripeGeo = new THREE.CylinderGeometry(bodyRad * 0.905, bodyRad * 1.005, bodyLen * 0.86, 20);
  geometries.push(stripeGeo);
  const stripe = new THREE.Mesh(stripeGeo, accentMat);
  stripe.rotation.x = Math.PI / 2;
  stripe.scale.set(1.01, 1, 0.14);
  root.add(stripe);

  // 2. Nose Cone (Hinged Droop Nose for Concorde)
  const noseGroup = new THREE.Group();
  noseGroup.position.set(0, 0, -bodyLen / 2);
  const noseLen = ac.id === 'concorde' ? 4.9 : 2.3;
  const noseGeo = new THREE.ConeGeometry(bodyRad * 0.88, noseLen, 22);
  geometries.push(noseGeo);
  const noseCone = new THREE.Mesh(noseGeo, ac.id === 'concorde' ? hullMat : accentMat);
  noseCone.rotation.x = -Math.PI / 2;
  noseCone.position.z = -noseLen / 2;
  noseGroup.add(noseCone);
  root.add(noseGroup);

  // Cockpit Canopy Glass
  const canopyGeo = new THREE.BoxGeometry(bodyRad * 1.12, bodyRad * 0.52, 1.6);
  geometries.push(canopyGeo);
  const canopy = new THREE.Mesh(canopyGeo, glassMat);
  canopy.position.set(0, bodyRad * 0.68, -bodyLen / 2 + 0.65);
  root.add(canopy);

  // 3. Wings & Engine Nacelles
  if (ac.id === 'concorde') {
    const deltaShape = new THREE.Shape();
    deltaShape.moveTo(0, 0);
    deltaShape.lineTo(7.8, -6.8);
    deltaShape.lineTo(0, -8.8);
    deltaShape.lineTo(-7.8, -6.8);
    deltaShape.closePath();

    const wingGeo = new THREE.ExtrudeGeometry(deltaShape, {
      depth: 0.22,
      bevelEnabled: true,
      bevelThickness: 0.06,
      bevelSize: 0.06,
      bevelSegments: 2,
    });
    geometries.push(wingGeo);
    const deltaWing = new THREE.Mesh(wingGeo, hullMat);
    deltaWing.rotation.x = Math.PI / 2;
    deltaWing.position.set(0, -0.08, -1.4);
    deltaWing.castShadow = true;
    root.add(deltaWing);

    // 4 Concorde Olympus Underwing Engine Nacelles
    const boxEngGeo = new THREE.BoxGeometry(0.9, 0.55, 3.2);
    const exhGeo = new THREE.CylinderGeometry(0.24, 0.28, 0.5, 12);
    geometries.push(boxEngGeo, exhGeo);
    [-2.5, -1.5, 1.5, 2.5].forEach((ox) => {
      const eng = new THREE.Mesh(boxEngGeo, chromeMat);
      eng.position.set(ox, -0.45, 3.8);
      const exhaust = new THREE.Mesh(exhGeo, burnerMat);
      exhaust.rotation.x = Math.PI / 2;
      exhaust.position.set(ox, -0.45, 5.55);
      root.add(eng, exhaust);
    });
  } else {
    const span = 10.5 + ac.tier * 4.1;
    const chord = 1.65 + ac.tier * 0.45;
    const wingGeo = new THREE.BoxGeometry(span, 0.22, chord);
    geometries.push(wingGeo);
    const wing = new THREE.Mesh(wingGeo, hullMat);
    const wingY = ac.tier === 1 ? bodyRad * 0.84 : -0.1;
    wing.position.set(0, wingY, -0.5);
    wing.castShadow = true;
    root.add(wing);

    if (ac.tier >= 3) {
      const wingletGeo = new THREE.BoxGeometry(0.14, 0.95, chord * 0.58);
      geometries.push(wingletGeo);
      [-span / 2, span / 2].forEach((wx) => {
        const winglet = new THREE.Mesh(wingletGeo, accentMat);
        winglet.position.set(wx, 0.36, -0.5);
        root.add(winglet);
      });

      const engineCount = ac.tier === 4 ? 4 : 2;
      const offsets = engineCount === 4 ? [-5.8, -3.1, 3.1, 5.8] : [-3.3, 3.3];
      const engGeo = new THREE.CylinderGeometry(0.46, 0.4, 2.1, 16);
      const lipGeo = new THREE.TorusGeometry(0.44, 0.06, 8, 18);
      geometries.push(engGeo, lipGeo);
      offsets.forEach((ox) => {
        const eng = new THREE.Mesh(engGeo, accentMat);
        eng.rotation.x = Math.PI / 2;
        eng.position.set(ox, -0.55, -0.8);
        const lip = new THREE.Mesh(lipGeo, chromeMat);
        lip.position.set(ox, -0.55, -1.85);
        root.add(eng, lip);
      });
    } else if (ac.tier === 2) {
      // King Air twin turboprop nacelles
      const nacGeo = new THREE.CylinderGeometry(0.32, 0.28, 1.8, 14);
      const propGeo = new THREE.BoxGeometry(2.1, 0.14, 0.06);
      geometries.push(nacGeo, propGeo);
      [-2.8, 2.8].forEach((ox) => {
        const nac = new THREE.Mesh(nacGeo, accentMat);
        nac.rotation.x = Math.PI / 2;
        nac.position.set(ox, -0.05, -1.1);
        const prop = new THREE.Mesh(propGeo, rubberMat);
        prop.position.set(ox, -0.05, -2.08);
        root.add(nac, prop);
        propellers.push(prop);
      });
    }
  }

  // Single nose propeller for Cessna 172
  if (ac.tier === 1) {
    const propGroup = new THREE.Group();
    const bladeGeo = new THREE.BoxGeometry(2.6, 0.16, 0.06);
    const spinnerGeo = new THREE.ConeGeometry(0.2, 0.45, 12);
    geometries.push(bladeGeo, spinnerGeo);
    const blade = new THREE.Mesh(bladeGeo, rubberMat);
    const spinner = new THREE.Mesh(spinnerGeo, chromeMat);
    spinner.rotation.x = -Math.PI / 2;
    spinner.position.z = -0.15;
    propGroup.add(blade, spinner);
    propGroup.position.set(0, 0, -bodyLen / 2 - 2.3);
    root.add(propGroup);
    propellers.push(propGroup);
  }

  // 4. Tail Empennage
  const vStabGeo = new THREE.BoxGeometry(0.22, 2.4 + ac.tier * 0.4, 2.3);
  geometries.push(vStabGeo);
  const vStab = new THREE.Mesh(vStabGeo, accentMat);
  vStab.position.set(0, 1.3 + ac.tier * 0.2, bodyLen / 2 - 1.1);
  root.add(vStab);

  if (ac.id !== 'concorde') {
    const hStabGeo = new THREE.BoxGeometry(3.8 + ac.tier * 1.1, 0.16, 1.2);
    geometries.push(hStabGeo);
    const hStab = new THREE.Mesh(hStabGeo, accentMat);
    hStab.position.set(0, ac.tier === 2 ? 2.4 : 0.2, bodyLen / 2 - 0.9);
    root.add(hStab);
  }

  // 5. Supersonic Vapor Cone (Mach 1.0+)
  const coneGeo = new THREE.ConeGeometry(4.6, 6.8, 24, 1, true);
  const coneMat = new THREE.MeshBasicMaterial({
    color: 0xe0f2fe,
    transparent: true,
    opacity: 0.36,
    side: THREE.DoubleSide,
    depthWrite: false,
  });
  geometries.push(coneGeo);
  materials.push(coneMat);
  const sonicCone = new THREE.Mesh(coneGeo, coneMat);
  sonicCone.rotation.x = Math.PI / 2;
  sonicCone.position.set(0, 0, 1.5);
  sonicCone.visible = false;
  root.add(sonicCone);

  // 6. Retractable Landing Gear & Spotlight
  const gearGroup = new THREE.Group();
  const wheelGeo = new THREE.CylinderGeometry(0.45, 0.45, 0.32, 14);
  const strutGeo = new THREE.CylinderGeometry(0.1, 0.1, 1.25, 10);
  geometries.push(wheelGeo, strutGeo);

  const wheelPositions: Array<[number, number, number]> = [
    [0, -bodyRad - 0.7, -bodyLen / 3],
    [-1.8, -bodyRad - 0.7, 1.2],
    [1.8, -bodyRad - 0.7, 1.2],
  ];
  for (const [wx, wy, wz] of wheelPositions) {
    const strut = new THREE.Mesh(strutGeo, chromeMat);
    strut.position.set(wx, wy + 0.5, wz);
    const wheel = new THREE.Mesh(wheelGeo, rubberMat);
    wheel.rotation.z = Math.PI / 2;
    wheel.position.set(wx, wy, wz);
    gearGroup.add(strut, wheel);
  }

  const landingLight = new THREE.SpotLight(0xfffbeb, 3.0, 560, Math.PI / 6, 0.5, 1);
  landingLight.position.set(0, -bodyRad - 0.5, -bodyLen / 3);
  landingLight.target.position.set(0, -35, -180);
  gearGroup.add(landingLight, landingLight.target);
  root.add(gearGroup);

  // Wingtip Navigation Strobe Lights
  const navGeo = new THREE.SphereGeometry(0.24, 10, 10);
  const navRedMat = new THREE.MeshBasicMaterial({color: 0xef4444});
  const navGreenMat = new THREE.MeshBasicMaterial({color: 0x22c55e});
  geometries.push(navGeo);
  materials.push(navRedMat, navGreenMat);

  const navOffset = 5.2 + ac.tier * 2;
  const navRed = new THREE.Mesh(navGeo, navRedMat);
  navRed.position.set(-navOffset, 0.2, -1);
  const navGreen = new THREE.Mesh(navGeo, navGreenMat);
  navGreen.position.set(navOffset, 0.2, -1);
  root.add(navRed, navGreen);

  root.scale.setScalar(scale);

  return {
    root,
    gearGroup,
    noseGroup,
    propellers,
    sonicCone,
    landingLight,
    dispose: () => {
      if (ownsHullTexture) hullTexture.dispose();
      geometries.forEach((g) => g.dispose());
      materials.forEach((m) => m.dispose());
    },
  };
}
