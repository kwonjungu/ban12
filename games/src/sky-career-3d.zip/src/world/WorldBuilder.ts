import * as THREE from 'three';
import {RoomEnvironment} from 'three/addons/environments/RoomEnvironment.js';

import {TEXTURE_ASSETS} from '../constants.ts';
import type {TimeOfDay, WeatherCondition} from '../types.ts';

export interface WorldHandles {
  skyDome: THREE.Mesh<THREE.SphereGeometry, THREE.MeshBasicMaterial>;
  groundMesh: THREE.Mesh<THREE.PlaneGeometry, THREE.MeshStandardMaterial>;
  waterMesh: THREE.Mesh<THREE.PlaneGeometry, THREE.MeshStandardMaterial>;
  waterTexture: THREE.Texture;
  hemiLight: THREE.HemisphereLight;
  dirLight: THREE.DirectionalLight;
  rimLight: THREE.DirectionalLight;
  cityMaterial: THREE.MeshStandardMaterial;
  createAirport: (
    x: number,
    z: number,
    runLen: number,
    withApproachBeacon: boolean,
    isNight: boolean
  ) => THREE.Group;
  applyAtmosphere: (timeOfDay: TimeOfDay, weather: WeatherCondition) => void;
  update: (dt: number, cameraPos: THREE.Vector3) => void;
  dispose: () => void;
}

function loadSRGBTexture(
  loader: THREE.TextureLoader,
  url: string,
  maxAnisotropy: number,
  repeatX = 1,
  repeatY = 1
): THREE.Texture {
  const tex = loader.load(url);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  if (repeatX !== 1 || repeatY !== 1) {
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(repeatX, repeatY);
  }
  return tex;
}

export function buildFlightWorld(
  scene: THREE.Scene,
  renderer: THREE.WebGLRenderer
): WorldHandles {
  const maxAniso = Math.min(4, renderer.capabilities.getMaxAnisotropy());
  const loader = new THREE.TextureLoader();
  const disposables: Array<{dispose: () => void}> = [];

  // Studio environment IBL for metallic aircraft & water reflections
  const pmremGenerator = new THREE.PMREMGenerator(renderer);
  const envRT = pmremGenerator.fromScene(new RoomEnvironment(), 0.04);
  scene.environment = envRT.texture;
  pmremGenerator.dispose();
  disposables.push(envRT);

  // Sky Dome using generated panoramic sky texture
  const skyTex = loadSRGBTexture(loader, TEXTURE_ASSETS.skyDome, maxAniso);
  disposables.push(skyTex);
  const skyGeo = new THREE.SphereGeometry(42000, 24, 16);
  const skyMat = new THREE.MeshBasicMaterial({
    map: skyTex,
    side: THREE.BackSide,
    depthWrite: false,
    fog: false,
    color: 0xffffff,
  });
  const skyDome = new THREE.Mesh(skyGeo, skyMat);
  skyDome.renderOrder = -10;
  scene.add(skyDome);
  disposables.push(skyGeo, skyMat);

  scene.background = new THREE.Color(0x38bdf8);
  scene.fog = new THREE.FogExp2(0x7dd3fc, 0.00011);

  // Three-point outdoor aviation lighting
  const hemiLight = new THREE.HemisphereLight(0xdbeafe, 0x334155, 1.0);
  scene.add(hemiLight);

  const dirLight = new THREE.DirectionalLight(0xfffbeb, 1.45);
  dirLight.position.set(600, 1100, 450);
  dirLight.castShadow = true;
  dirLight.shadow.mapSize.set(1024, 1024);
  dirLight.shadow.camera.near = 10;
  dirLight.shadow.camera.far = 2400;
  dirLight.shadow.camera.left = -65;
  dirLight.shadow.camera.right = 65;
  dirLight.shadow.camera.top = 65;
  dirLight.shadow.camera.bottom = -65;
  dirLight.shadow.bias = -0.0005;
  scene.add(dirLight);

  const rimLight = new THREE.DirectionalLight(0x93c5fd, 0.55);
  rimLight.position.set(-500, 400, -700);
  scene.add(rimLight);

  // Satellite terrain mesh
  const terrainTex = loadSRGBTexture(loader, TEXTURE_ASSETS.aerialTerrain, maxAniso, 110, 110);
  disposables.push(terrainTex);
  const groundGeo = new THREE.PlaneGeometry(180000, 180000);
  const groundMat = new THREE.MeshStandardMaterial({
    map: terrainTex,
    roughness: 0.9,
    metalness: 0.04,
    color: 0xffffff,
  });
  const groundMesh = new THREE.Mesh(groundGeo, groundMat);
  groundMesh.rotation.x = -Math.PI / 2;
  groundMesh.position.y = 0;
  groundMesh.receiveShadow = true;
  scene.add(groundMesh);
  disposables.push(groundGeo, groundMat);

  // Coastal ocean surface
  const waterTex = loadSRGBTexture(loader, TEXTURE_ASSETS.oceanWater, maxAniso, 90, 180);
  disposables.push(waterTex);
  const waterGeo = new THREE.PlaneGeometry(90000, 180000);
  const waterMat = new THREE.MeshStandardMaterial({
    map: waterTex,
    roughness: 0.22,
    metalness: 0.38,
    color: 0xffffff,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });
  const waterMesh = new THREE.Mesh(waterGeo, waterMat);
  waterMesh.rotation.x = -Math.PI / 2;
  waterMesh.position.set(-48500, 0.05, 0);
  waterMesh.receiveShadow = false;
  scene.add(waterMesh);
  disposables.push(waterGeo, waterMat);

  // Shared Runway Texture
  const runwayTex = loadSRGBTexture(loader, TEXTURE_ASSETS.runwayAsphalt, maxAniso, 1, 8);
  disposables.push(runwayTex);
  const runwayMat = new THREE.MeshStandardMaterial({
    map: runwayTex,
    roughness: 0.78,
    metalness: 0.06,
    polygonOffset: true,
    polygonOffsetFactor: -2,
    polygonOffsetUnits: -2,
  });
  disposables.push(runwayMat);

  // Shared Skyscraper Facade Texture (InstancedMesh for crisp skyline)
  const facadeTex = loadSRGBTexture(loader, TEXTURE_ASSETS.skyscraperFacade, maxAniso, 1, 2);
  disposables.push(facadeTex);
  const cityMaterial = new THREE.MeshStandardMaterial({
    map: facadeTex,
    emissiveMap: facadeTex,
    emissive: new THREE.Color(0xfde047),
    emissiveIntensity: 0.15,
    roughness: 0.25,
    metalness: 0.6,
  });
  disposables.push(cityMaterial);

  const cityCount = 140;
  const cityGeo = new THREE.BoxGeometry(1, 1, 1);
  const cityInstanced = new THREE.InstancedMesh(cityGeo, cityMaterial, cityCount);
  const dummy = new THREE.Object3D();
  for (let i = 0; i < cityCount; i++) {
    const w = 32 + Math.random() * 44;
    const d = 32 + Math.random() * 44;
    const h = 65 + Math.random() * 250;
    const bx = 340 + Math.random() * 2600;
    const bz = -300 - Math.random() * 38000;
    dummy.position.set(bx, h / 2, bz);
    dummy.scale.set(w, h, d);
    dummy.updateMatrix();
    cityInstanced.setMatrixAt(i, dummy.matrix);
  }
  cityInstanced.instanceMatrix.needsUpdate = true;
  cityInstanced.computeBoundingSphere();
  scene.add(cityInstanced);
  disposables.push(cityGeo);

  // Mountain ridge peaks (InstancedMesh)
  const hillCount = 90;
  const hillGeo = new THREE.ConeGeometry(340, 290, 7);
  const hillMat = new THREE.MeshStandardMaterial({
    map: terrainTex,
    color: 0x4b7f5a,
    roughness: 0.92,
    metalness: 0.02,
  });
  const hillInstanced = new THREE.InstancedMesh(hillGeo, hillMat, hillCount);
  for (let i = 0; i < hillCount; i++) {
    const side = Math.random() > 0.35 ? 1 : -1;
    const sx = 1 + Math.random() * 2.2;
    const sy = 0.8 + Math.random() * 2.4;
    const sz = 1 + Math.random() * 2.2;
    dummy.position.set(
      side * (900 + Math.random() * 8200),
      (290 * sy) / 2 - 20,
      -Math.random() * 45000 + 1000
    );
    dummy.scale.set(sx, sy, sz);
    dummy.rotation.y = Math.random() * Math.PI;
    dummy.updateMatrix();
    hillInstanced.setMatrixAt(i, dummy.matrix);
  }
  hillInstanced.instanceMatrix.needsUpdate = true;
  hillInstanced.computeBoundingSphere();
  scene.add(hillInstanced);
  disposables.push(hillGeo, hillMat);

  // Volumetric-style Cloud Clusters (InstancedMesh)
  const cloudCount = 300;
  const cloudGeo = new THREE.DodecahedronGeometry(55, 0);
  const cloudMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    roughness: 0.95,
    metalness: 0.0,
    transparent: true,
    opacity: 0.84,
    depthWrite: false,
  });
  const cloudInstanced = new THREE.InstancedMesh(cloudGeo, cloudMat, cloudCount);
  for (let i = 0; i < cloudCount; i++) {
    const cx = (Math.random() - 0.5) * 20000;
    const cy = 420 + Math.random() * 1200;
    const cz = -Math.random() * 45000 + 2000;
    const s = 0.75 + Math.random() * 1.4;
    dummy.position.set(cx, cy, cz);
    dummy.scale.set(s * 1.7, s * 0.55, s * 1.1);
    dummy.rotation.set(0, Math.random() * Math.PI, 0);
    dummy.updateMatrix();
    cloudInstanced.setMatrixAt(i, dummy.matrix);
  }
  cloudInstanced.instanceMatrix.needsUpdate = true;
  cloudInstanced.computeBoundingSphere();
  scene.add(cloudInstanced);
  disposables.push(cloudGeo, cloudMat);

  // Shared Airport Geometries & Materials
  const edgeLightGeo = new THREE.BoxGeometry(1.1, 1.1, 1.1);
  const edgeLightMat = new THREE.MeshBasicMaterial({color: 0x38bdf8});
  const threshLightMat = new THREE.MeshBasicMaterial({color: 0x10b981});
  const endLightMat = new THREE.MeshBasicMaterial({color: 0xf43f5e});
  const alsMat = new THREE.MeshBasicMaterial({color: 0xfbbf24});
  const alsGeo = new THREE.BoxGeometry(8, 0.8, 1.2);
  const terminalMat = new THREE.MeshStandardMaterial({
    map: facadeTex,
    emissiveMap: facadeTex,
    emissive: new THREE.Color(0xfde047),
    emissiveIntensity: 0.3,
    roughness: 0.35,
    metalness: 0.45,
  });
  const towerGlassMat = new THREE.MeshBasicMaterial({color: 0x38bdf8});
  disposables.push(
    edgeLightGeo,
    edgeLightMat,
    threshLightMat,
    endLightMat,
    alsMat,
    alsGeo,
    terminalMat,
    towerGlassMat
  );

  function createAirport(
    x: number,
    z: number,
    runLen: number,
    withApproachBeacon: boolean,
    isNight: boolean
  ): THREE.Group {
    const airportGroup = new THREE.Group();
    airportGroup.position.set(x, 0.08, z);

    const localDisposables: Array<{dispose: () => void}> = [];

    const halfLen = runLen / 2;
    const rwyGeo = new THREE.PlaneGeometry(54, runLen);
    localDisposables.push(rwyGeo);
    const rwy = new THREE.Mesh(rwyGeo, runwayMat);
    rwy.rotation.x = -Math.PI / 2;
    rwy.position.z = -halfLen + 100;
    rwy.receiveShadow = true;
    airportGroup.add(rwy);

    // Runway Edge, Threshold & End Lights
    for (let lz = 90; lz > -runLen + 110; lz -= 45) {
      let mat = edgeLightMat;
      if (lz > 20) mat = threshLightMat;
      else if (lz < -runLen + 200) mat = endLightMat;

      const leftL = new THREE.Mesh(edgeLightGeo, mat);
      leftL.position.set(-26, 0.55, lz);
      const rightL = new THREE.Mesh(edgeLightGeo, mat);
      rightL.position.set(26, 0.55, lz);
      airportGroup.add(leftL, rightL);
    }

    // Approach Lighting System (ALS)
    for (let az = 130; az <= 450; az += 40) {
      const alsBar = new THREE.Mesh(alsGeo, alsMat);
      alsBar.position.set(0, 0.4, az);
      airportGroup.add(alsBar);
    }

    // Terminal & Air Traffic Control Tower
    const termGeo = new THREE.BoxGeometry(42, 18, 114);
    localDisposables.push(termGeo);
    const terminal = new THREE.Mesh(termGeo, terminalMat);
    terminal.position.set(68, 9, -320);
    airportGroup.add(terminal);

    const towerBaseGeo = new THREE.CylinderGeometry(4.5, 6.2, 46, 12);
    const towerBase = new THREE.Mesh(towerBaseGeo, terminalMat);
    towerBase.position.set(68, 23, -240);
    const towerTopGeo = new THREE.CylinderGeometry(8.5, 5.5, 7, 12);
    const towerTop = new THREE.Mesh(towerTopGeo, towerGlassMat);
    towerTop.position.set(68, 49, -240);
    localDisposables.push(towerBaseGeo, towerTopGeo);
    airportGroup.add(towerBase, towerTop);

    if (withApproachBeacon) {
      const beaconGeo = new THREE.CylinderGeometry(24, 24, 1600, 16, 1, true);
      const beaconMat = new THREE.MeshBasicMaterial({
        color: 0x10b981,
        transparent: true,
        opacity: isNight ? 0.34 : 0.18,
        side: THREE.DoubleSide,
        depthWrite: false,
      });
      localDisposables.push(beaconGeo, beaconMat);
      const beacon = new THREE.Mesh(beaconGeo, beaconMat);
      beacon.position.set(0, 800, -runLen / 2 + 100);
      airportGroup.add(beacon);
    }

    airportGroup.userData.dispose = () => {
      for (const item of localDisposables) {
        item.dispose();
      }
    };

    scene.add(airportGroup);
    return airportGroup;
  }

  function applyAtmosphere(timeOfDay: TimeOfDay, weather: WeatherCondition): void {
    const isNight = timeOfDay === 'night';
    const isSunset = timeOfDay === 'sunset';

    cityMaterial.emissiveIntensity = isNight ? 1.15 : isSunset ? 0.55 : 0.12;
    terminalMat.emissiveIntensity = isNight ? 1.1 : isSunset ? 0.5 : 0.15;

    if (isNight) {
      scene.background = new THREE.Color(0x030712);
      scene.fog = new THREE.FogExp2(0x060d1f, 0.00016);
      skyMat.color.setHex(0x1e293b);
      hemiLight.intensity = 0.35;
      dirLight.intensity = 0.32;
      dirLight.color.setHex(0x93c5fd);
      groundMat.color.setHex(0x334155);
      waterMat.color.setHex(0x0f172a);
      cloudMat.color.setHex(0x334155);
    } else if (isSunset) {
      scene.background = new THREE.Color(0xf97316);
      scene.fog = new THREE.FogExp2(0xfb923c, 0.00014);
      skyMat.color.setHex(0xfdba74);
      hemiLight.intensity = 0.78;
      dirLight.intensity = 1.25;
      dirLight.color.setHex(0xfdba74);
      groundMat.color.setHex(0xd6b49c);
      waterMat.color.setHex(0xfb923c);
      cloudMat.color.setHex(0xfed7aa);
    } else {
      if (weather.vis < 0.7) {
        scene.background = new THREE.Color(0x475569);
        scene.fog = new THREE.FogExp2(0x64748b, 0.00024);
        skyMat.color.setHex(0x94a3b8);
        cloudMat.color.setHex(0xcbd5e1);
      } else if (weather.vis < 0.9) {
        scene.background = new THREE.Color(0x0284c7);
        scene.fog = new THREE.FogExp2(0x93c5fd, 0.00015);
        skyMat.color.setHex(0xe0f2fe);
        cloudMat.color.setHex(0xf8fafc);
      } else {
        scene.background = new THREE.Color(0x38bdf8);
        scene.fog = new THREE.FogExp2(0x7dd3fc, 0.00011);
        skyMat.color.setHex(0xffffff);
        cloudMat.color.setHex(0xffffff);
      }
      hemiLight.intensity = 1.0;
      dirLight.intensity = 1.45;
      dirLight.color.setHex(0xfffbeb);
      groundMat.color.setHex(0xffffff);
      waterMat.color.setHex(0xffffff);
    }
  }

  function update(dt: number, cameraPos: THREE.Vector3): void {
    // Keep sky dome centered around camera so horizon stays infinite
    skyDome.position.set(cameraPos.x, 0, cameraPos.z);
    // Subtle ocean current animation
    waterTex.offset.x = (waterTex.offset.x + dt * 0.008) % 1;
    waterTex.offset.y = (waterTex.offset.y + dt * 0.012) % 1;
  }

  function dispose(): void {
    for (const d of disposables) {
      d.dispose();
    }
  }

  return {
    skyDome,
    groundMesh,
    waterMesh,
    waterTexture: waterTex,
    hemiLight,
    dirLight,
    rimLight,
    cityMaterial,
    createAirport,
    applyAtmosphere,
    update,
    dispose,
  };
}
