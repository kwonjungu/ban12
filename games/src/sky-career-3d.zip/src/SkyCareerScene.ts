import * as THREE from 'three';
import * as xb from 'xrblocks';

import {FlightAudio} from './audio/FlightAudio.ts';
import {
  AIRCRAFT_DB,
  AIRPORTS_DB,
  CAREER_STORAGE_KEY,
  CARGO_TEMPLATES,
  TEXTURE_ASSETS,
  WEATHER_PRESETS,
} from './constants.ts';
import type {
  AircraftId,
  AircraftSpec,
  CameraMode,
  FlightInputState,
  FlightPhysicsState,
  MissionContract,
  PlayerCareerState,
  TimeOfDay,
} from './types.ts';
import {GameHUD} from './ui/GameHUD.ts';
import {type AircraftModelHandles, buildAircraftModel} from './world/AircraftBuilder.ts';
import {type WorldHandles, buildFlightWorld} from './world/WorldBuilder.ts';

interface ParticleSlot {
  mesh: THREE.Mesh<THREE.DodecahedronGeometry, THREE.MeshBasicMaterial>;
  vel: THREE.Vector3;
  life: number;
  maxLife: number;
  active: boolean;
}

const PARTICLE_POOL_SIZE = 64;

export class SkyCareerScene extends xb.Script {
  private audio = new FlightAudio();
  private world: WorldHandles | null = null;
  private aircraftModel: AircraftModelHandles | null = null;
  private departureAirport: THREE.Group | null = null;
  private destAirport: THREE.Group | null = null;
  private sharedHullTexture: THREE.Texture | null = null;
  private hud: GameHUD | null = null;

  // Spatial XR Cockpit Card (active inside WebXR sessions)
  private xrHudCard: xb.UICard | null = null;
  private xrHudTitle: xb.UIText | null = null;
  private xrHudTelemetry: xb.UIText | null = null;
  private inXRSession = false;

  // Particle Pool
  private particleGeo = new THREE.DodecahedronGeometry(1, 0);
  private particlePool: ParticleSlot[] = [];

  // Reusable math scratch objects (zero per-frame GC)
  private readonly _dirVec = new THREE.Vector3();
  private readonly _offsetVec = new THREE.Vector3();
  private readonly _lookTarget = new THREE.Vector3();
  private readonly _camTargetPos = new THREE.Vector3();
  private readonly _tmpEuler = new THREE.Euler(0, 0, 0, 'YXZ');
  private readonly _spawnPos = new THREE.Vector3();
  private readonly _spawnVel = new THREE.Vector3();

  // State
  private isFlying = false;
  private isInspecting3D = false;
  private timeOfDay: TimeOfDay = 'day';
  private missions: MissionContract[] = [];
  private selectedMission: MissionContract | null = null;
  private career: PlayerCareerState = this.loadCareer();

  private camOrbit = {yaw: 0.45, pitch: 0.18, zoom: 1.0};
  private isDraggingCamera = false;
  private prevMouse = {x: 0, y: 0};

  private inputs: FlightInputState = {
    throttleUp: false,
    throttleDown: false,
    pitchUp: false,
    pitchDown: false,
    rollLeft: false,
    rollRight: false,
  };

  private flight: FlightPhysicsState = {
    pos: new THREE.Vector3(0, 1.8, 0),
    rot: new THREE.Euler(0, 0, 0, 'YXZ'),
    speed: 0,
    throttle: 0,
    fuel: 100,
    gearDown: true,
    flaps: 15,
    brake: false,
    droopNose: false,
    autopilot: false,
    cameraMode: 'chase',
    onGround: true,
    hasTakenOff: false,
    wasSupersonic: false,
    lastCalloutAlt: 9999,
    satisfaction: 100,
    touchdownVSpeed: 0,
    verticalSpeedFpm: 0,
    destZ: -4500,
    timeOfDay: 'day',
    currentAircraft: null,
    currentMission: null,
  };

  private onKeyDownBound = (e: KeyboardEvent) => this.handleKeyDown(e);
  private onKeyUpBound = (e: KeyboardEvent) => this.handleKeyUp(e);
  private onPointerDownBound = (e: PointerEvent) => this.handlePointerDown(e);
  private onPointerMoveBound = (e: PointerEvent) => this.handlePointerMove(e);
  private onPointerUpBound = () => {
    this.isDraggingCamera = false;
  };
  private onWheelBound = (e: WheelEvent) => {
    this.camOrbit.zoom = THREE.MathUtils.clamp(this.camOrbit.zoom + e.deltaY * 0.0008, 0.55, 2.4);
  };

  init(): void {
    const renderer = xb.core.renderer as THREE.WebGLRenderer;
    const scene = xb.core.scene;
    const camera = xb.core.camera;

    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.08;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFShadowMap;

    camera.near = 0.3;
    camera.far = 55000;
    camera.updateProjectionMatrix();

    // Preload shared aircraft fuselage texture once
    const texLoader = new THREE.TextureLoader();
    const hullTex = texLoader.load(TEXTURE_ASSETS.aerospaceHull);
    hullTex.colorSpace = THREE.SRGBColorSpace;
    hullTex.anisotropy = Math.min(4, renderer.capabilities.getMaxAnisotropy());
    hullTex.wrapS = THREE.RepeatWrapping;
    hullTex.wrapT = THREE.RepeatWrapping;
    hullTex.repeat.set(2, 3);
    this.sharedHullTexture = hullTex;

    // Build 3D World with generated textures
    this.world = buildFlightWorld(scene, renderer);
    this.departureAirport = this.world.createAirport(0, 0, 1400, false, false);

    // Build particle pool
    for (let i = 0; i < PARTICLE_POOL_SIZE; i++) {
      const mat = new THREE.MeshBasicMaterial({
        color: 0xffffff,
        transparent: true,
        opacity: 0.6,
        depthWrite: false,
      });
      const mesh = new THREE.Mesh(this.particleGeo, mat);
      mesh.visible = false;
      this.add(mesh);
      this.particlePool.push({
        mesh,
        vel: new THREE.Vector3(),
        life: 0,
        maxLife: 1,
        active: false,
      });
    }

    // Build initial aircraft
    this.rebuildAircraftMesh(this.getSelectedAircraft());

    // Build Spatial XR Cockpit Card (shown inside WebXR sessions)
    this.buildXRSpatialHUD();

    // Mount responsive 2D DOM HUD
    const rootEl = document.getElementById('root') ?? document.body;
    this.hud = new GameHUD(rootEl, this.inputs, {
      onSelectAircraft: (id) => this.selectOrBuyAircraft(id),
      onSelectMission: (id) => this.selectMission(id),
      onRefreshMissions: () => this.generateMissions(),
      onTimeOfDayChange: (tod) => {
        this.timeOfDay = tod;
        this.world?.applyAtmosphere(tod, this.selectedMission?.weather ?? WEATHER_PRESETS[0]);
        this.renderHangar();
      },
      onStartFlight: () => this.startFlight(),
      onSetCameraMode: (mode) => this.setCameraMode(mode),
      onToggleAutopilot: () => this.toggleAutopilot(),
      onAbortFlight: () => this.abortFlight(),
      onToggleGear: () => this.toggleGear(),
      onCycleFlaps: () => this.cycleFlaps(),
      onToggleBrake: () => this.toggleBrake(),
      onToggleDroopNose: () => this.toggleDroopNose(),
      onToggleMute: () => this.audio.toggleMute(),
      onReturnToHangar: () => this.returnToHangar(),
      onRetryFlight: () => this.startFlight(),
      onResetCareer: () => this.resetCareer(),
      onToggleInspect3D: (inspecting) => {
        this.isInspecting3D = inspecting;
        if (inspecting) {
          this.camOrbit = {yaw: 0.55, pitch: 0.16, zoom: 1.0};
        }
      },
      onEnterXR: () => {
        xb.core.webXRSessionManager?.startSession();
      },
    });

    // Detect WebXR capability for optional XR button
    window.setTimeout(() => {
      const supported = Boolean(xb.core.webXRSessionManager?.isXRSupported());
      this.hud?.setXRSupported(supported);
    }, 300);

    // Input listeners
    window.addEventListener('keydown', this.onKeyDownBound);
    window.addEventListener('keyup', this.onKeyUpBound);
    const canvas = renderer.domElement;
    canvas.addEventListener('pointerdown', this.onPointerDownBound);
    window.addEventListener('pointermove', this.onPointerMoveBound);
    window.addEventListener('pointerup', this.onPointerUpBound);
    canvas.addEventListener('wheel', this.onWheelBound, {passive: true});

    this.generateMissions();
    this.world.applyAtmosphere(this.timeOfDay, this.selectedMission?.weather ?? WEATHER_PRESETS[0]);
  }

  private buildXRSpatialHUD(): void {
    this.xrHudTitle = new xb.UIText({
      text: 'SKY CAREER 3D · XR',
      style: {fontSize: 22, fontWeight: 'bold', textAlign: 'center', color: '#38bdf8'},
    });
    this.xrHudTelemetry = new xb.UIText({
      text: 'IAS 0 KTS · ALT 0 FT · HDG 360°',
      style: {fontSize: 18, textAlign: 'center', color: '#f8fafc', whiteSpace: 'pre-line'},
    });
    this.xrHudCard = new xb.UICard({
      size: {width: 0.62, height: 'auto'},
      manipulation: true,
      style: {padding: 16, gap: 10, borderRadius: 18},
      children: [
        this.xrHudTitle,
        this.xrHudTelemetry,
        new xb.UIButton({
          label: 'AI 부기장 전환',
          onClick: () => this.toggleAutopilot(),
        }),
      ],
    });
    this.xrHudCard.position.set(0, 1.35, -1.1);
    this.xrHudCard.visible = false;
    this.add(this.xrHudCard);
  }

  onXRSessionStarted(): void {
    this.inXRSession = true;
    if (this.xrHudCard) this.xrHudCard.visible = true;
  }

  onXRSessionEnded(): void {
    this.inXRSession = false;
    if (this.xrHudCard) this.xrHudCard.visible = false;
  }

  onSelectEnd(): void {
    if (this.inXRSession && this.isFlying) {
      this.toggleAutopilot();
    }
  }

  private loadCareer(): PlayerCareerState {
    try {
      const raw = localStorage.getItem(CAREER_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as Partial<PlayerCareerState>;
        const unlocked = Array.isArray(parsed.unlockedIds) && parsed.unlockedIds.length > 0
          ? parsed.unlockedIds
          : (['cessna'] as AircraftId[]);
        return {
          money: typeof parsed.money === 'number' ? parsed.money : 10000,
          completedFlights: typeof parsed.completedFlights === 'number' ? parsed.completedFlights : 0,
          unlockedIds: unlocked,
          selectedAircraftId: parsed.selectedAircraftId ?? 'cessna',
          bestLandingFpm: typeof parsed.bestLandingFpm === 'number' ? parsed.bestLandingFpm : null,
        };
      }
    } catch {
      // Ignore storage failures
    }
    return {
      money: 10000,
      completedFlights: 0,
      unlockedIds: ['cessna'],
      selectedAircraftId: 'cessna',
      bestLandingFpm: null,
    };
  }

  private saveCareer(): void {
    try {
      localStorage.setItem(CAREER_STORAGE_KEY, JSON.stringify(this.career));
    } catch {
      // Ignore
    }
  }

  private resetCareer(): void {
    this.career = {
      money: 10000,
      completedFlights: 0,
      unlockedIds: ['cessna'],
      selectedAircraftId: 'cessna',
      bestLandingFpm: null,
    };
    this.saveCareer();
    this.rebuildAircraftMesh(this.getSelectedAircraft());
    this.generateMissions();
    this.hud?.showAlert('커리어 데이터가 초기화되었습니다.');
  }

  private getSelectedAircraft(): AircraftSpec {
    return (
      AIRCRAFT_DB.find((a) => a.id === this.career.selectedAircraftId) ?? AIRCRAFT_DB[0]
    );
  }

  private rebuildAircraftMesh(ac: AircraftSpec): void {
    if (this.aircraftModel) {
      this.remove(this.aircraftModel.root);
      this.aircraftModel.dispose();
      this.aircraftModel = null;
    }
    const renderer = xb.core.renderer as THREE.WebGLRenderer;
    this.aircraftModel = buildAircraftModel(ac, renderer, this.sharedHullTexture ?? undefined);
    const groundY = 1.8 * (0.7 + ac.tier * 0.28);
    this.aircraftModel.root.position.set(0, groundY, 0);
    this.add(this.aircraftModel.root);
  }

  private generateMissions(): void {
    const ac = this.getSelectedAircraft();
    const tier = ac.tier;
    const nextMissions: MissionContract[] = [];

    for (let i = 0; i < 4; i++) {
      const tpl = CARGO_TEMPLATES[Math.min(i + Math.floor(tier / 2), CARGO_TEMPLATES.length - 1)];
      const w = WEATHER_PRESETS[i % WEATHER_PRESETS.length];
      const destAirport = AIRPORTS_DB[Math.min(i + tier - 1, AIRPORTS_DB.length - 1)];

      const cruiseSpeedMs = ac.maxSpeed * 0.78 * 0.514;
      const flightDurationSec = tpl.baseTimeSec + i * 12;
      const worldDistMeters = Math.round(cruiseSpeedMs * flightDurationSec);
      const displayKm = parseFloat((worldDistMeters / 220).toFixed(1));
      const payloadTons = parseFloat((tier * 1.8 * (0.85 + Math.random() * 0.35)).toFixed(1));
      const reward = Math.round(tpl.rewardBase * (1 + (tier - 1) * 0.85) * w.bonus);

      nextMissions.push({
        id: `m_${i}`,
        title: `[${destAirport.code}] ${tpl.title}`,
        destAirport,
        type: tpl.type,
        category: tpl.category,
        distanceKm: displayKm,
        worldDistMeters,
        payloadTons,
        weather: w,
        reward,
      });
    }

    this.missions = nextMissions;
    this.selectedMission = nextMissions[0];
    this.renderHangar();
  }

  private renderHangar(): void {
    this.hud?.renderHangar(this.career, this.missions, this.selectedMission, this.timeOfDay);
  }

  private selectOrBuyAircraft(id: AircraftId): void {
    this.audio.init();
    const ac = AIRCRAFT_DB.find((a) => a.id === id);
    if (!ac) return;

    if (this.career.unlockedIds.includes(id)) {
      this.career.selectedAircraftId = id;
      this.saveCareer();
      this.rebuildAircraftMesh(ac);
      this.generateMissions();
      return;
    }

    if (this.career.money >= ac.price) {
      this.career.money -= ac.price;
      this.career.unlockedIds.push(id);
      this.career.selectedAircraftId = id;
      this.saveCareer();
      this.rebuildAircraftMesh(ac);
      this.audio.playChime('success');
      this.hud?.showAlert(`${ac.name} 기체를 구매하여 격납고에 배치했습니다.`);
      this.generateMissions();
    } else {
      this.audio.playChime('warn');
      this.hud?.showAlert(`자금이 부족합니다. 필요 금액: $${ac.price.toLocaleString()}`);
    }
  }

  private selectMission(id: string): void {
    const found = this.missions.find((m) => m.id === id);
    if (found) {
      this.selectedMission = found;
      this.renderHangar();
    }
  }

  private startFlight(): void {
    this.audio.init();
    const ac = this.getSelectedAircraft();
    const mission = this.selectedMission ?? this.missions[0];
    if (!ac || !mission || !this.world) return;

    // Dispose previous destination airport if any
    if (this.destAirport) {
      xb.core.scene.remove(this.destAirport);
      (this.destAirport.userData.dispose as (() => void) | undefined)?.();
      this.destAirport = null;
    }

    const groundY = 1.8 * (0.7 + ac.tier * 0.28);
    this.flight = {
      pos: new THREE.Vector3(0, groundY, 0),
      rot: new THREE.Euler(0, 0, 0, 'YXZ'),
      speed: 0,
      throttle: 0,
      fuel: 100,
      gearDown: true,
      flaps: 15,
      brake: false,
      droopNose: false,
      autopilot: false,
      cameraMode: 'chase',
      onGround: true,
      hasTakenOff: false,
      wasSupersonic: false,
      lastCalloutAlt: 9999,
      satisfaction: 100,
      touchdownVSpeed: 0,
      verticalSpeedFpm: 0,
      destZ: -mission.worldDistMeters,
      timeOfDay: this.timeOfDay,
      currentAircraft: ac,
      currentMission: mission,
    };
    this.camOrbit = {yaw: 0, pitch: 0.12, zoom: 1.0};
    this.clearParticles();

    const runLen = mission.destAirport.runLen || 1600;
    this.destAirport = this.world.createAirport(
      0,
      this.flight.destZ,
      runLen,
      true,
      this.timeOfDay === 'night'
    );
    this.world.applyAtmosphere(this.timeOfDay, mission.weather);
    this.rebuildAircraftMesh(ac);

    this.hud?.showFlightHUD(ac, mission);
    this.hud?.updateSystemButtons(this.flight);
    this.setCameraMode('chase');
    this.hud?.showAlert(
      `이륙 준비 완료! Shift 키로 출력을 올려 ${mission.destAirport.name}으로 출발하세요.`
    );
    this.isInspecting3D = false;
    this.isFlying = true;
  }

  private setCameraMode(mode: CameraMode): void {
    this.flight.cameraMode = mode;
    this.camOrbit = {yaw: 0, pitch: 0.12, zoom: 1.0};
    this.hud?.updateCameraUI(mode);
    if (this.aircraftModel) {
      this.aircraftModel.root.visible = mode !== 'cockpit';
    }
  }

  private toggleGear(): void {
    if (this.flight.onGround && this.flight.gearDown) {
      this.hud?.showAlert('지상에서는 랜딩 기어를 접을 수 없습니다.');
      return;
    }
    this.flight.gearDown = !this.flight.gearDown;
    if (this.aircraftModel) {
      this.aircraftModel.gearGroup.visible = this.flight.gearDown;
    }
    this.hud?.updateSystemButtons(this.flight);
    this.hud?.showAlert(
      this.flight.gearDown ? '랜딩 기어 전개 (GEAR DOWN)' : '랜딩 기어 수납 (GEAR UP)'
    );
  }

  private cycleFlaps(): void {
    const levels = [0, 15, 30];
    this.flight.flaps = levels[(levels.indexOf(this.flight.flaps) + 1) % levels.length];
    this.hud?.updateSystemButtons(this.flight);
    this.hud?.showAlert(`플랩 각도 설정: ${this.flight.flaps}°`);
  }

  private toggleBrake(): void {
    this.flight.brake = !this.flight.brake;
    this.hud?.updateSystemButtons(this.flight);
    this.hud?.showAlert(this.flight.brake ? '에어/휠 브레이크 작동' : '브레이크 해제');
  }

  private toggleDroopNose(): void {
    if (!this.flight.currentAircraft?.hasDroopNose) return;
    this.flight.droopNose = !this.flight.droopNose;
    if (this.aircraftModel) {
      this.aircraftModel.noseGroup.rotation.x = this.flight.droopNose ? -0.22 : 0;
    }
    this.hud?.updateSystemButtons(this.flight);
    this.hud?.showAlert(
      this.flight.droopNose
        ? '콩코디아 드룹 노즈 하강 (이착륙 시야 확보)'
        : '콩코디아 드룹 노즈 상승 (초음속 순항 모드)'
    );
  }

  private toggleAutopilot(): void {
    if (this.flight.onGround) {
      this.hud?.showAlert('이륙 후 공중에서 AI 부기장을 활성화할 수 있습니다.');
      return;
    }
    this.flight.autopilot = !this.flight.autopilot;
    this.hud?.updateSystemButtons(this.flight);
    this.hud?.showAlert(
      this.flight.autopilot ? 'AI 부기장 자동 순항 모드 ON' : '수동 조종 전환 (AI 부기장 OFF)'
    );
  }

  private abortFlight(): void {
    this.isFlying = false;
    this.audio.updateEngine(0, 0);
    this.returnToHangar();
    this.hud?.showAlert('비행이 중단되어 격납고로 복귀했습니다.');
  }

  private returnToHangar(): void {
    this.isFlying = false;
    this.isInspecting3D = false;
    this.camOrbit = {yaw: 0.45, pitch: 0.18, zoom: 1.0};
    this.rebuildAircraftMesh(this.getSelectedAircraft());
    this.hud?.showHangar();
    this.generateMissions();
  }

  private handleKeyDown(e: KeyboardEvent): void {
    if (!this.isFlying) return;
    if (e.key === 'Shift') this.inputs.throttleUp = true;
    if (e.key === 'Control') this.inputs.throttleDown = true;
    if (e.key === 'w' || e.key === 'W' || e.key === 'ArrowUp') {
      this.inputs.pitchDown = true;
      if (e.key === 'ArrowUp') e.preventDefault();
    }
    if (e.key === 's' || e.key === 'S' || e.key === 'ArrowDown') {
      this.inputs.pitchUp = true;
      if (e.key === 'ArrowDown') e.preventDefault();
    }
    if (e.key === 'a' || e.key === 'A' || e.key === 'ArrowLeft') {
      this.inputs.rollLeft = true;
      if (e.key === 'ArrowLeft') e.preventDefault();
    }
    if (e.key === 'd' || e.key === 'D' || e.key === 'ArrowRight') {
      this.inputs.rollRight = true;
      if (e.key === 'ArrowRight') e.preventDefault();
    }

    if (e.key === 'g' || e.key === 'G') this.toggleGear();
    if (e.key === 'f' || e.key === 'F') this.cycleFlaps();
    if (e.key === 'b' || e.key === 'B') this.toggleBrake();
    if (e.key === 'n' || e.key === 'N') this.toggleDroopNose();
    if (e.key === 'p' || e.key === 'P') this.toggleAutopilot();
    if (e.key === 'h' || e.key === 'H') this.hud?.toggleCompactHUD();
    if (e.key === 'c' || e.key === 'C') {
      const modes: CameraMode[] = ['chase', 'cockpit', 'passenger'];
      const next = modes[(modes.indexOf(this.flight.cameraMode) + 1) % modes.length];
      this.setCameraMode(next);
    }
  }

  private handleKeyUp(e: KeyboardEvent): void {
    if (e.key === 'Shift') this.inputs.throttleUp = false;
    if (e.key === 'Control') this.inputs.throttleDown = false;
    if (e.key === 'w' || e.key === 'W' || e.key === 'ArrowUp') this.inputs.pitchDown = false;
    if (e.key === 's' || e.key === 'S' || e.key === 'ArrowDown') this.inputs.pitchUp = false;
    if (e.key === 'a' || e.key === 'A' || e.key === 'ArrowLeft') this.inputs.rollLeft = false;
    if (e.key === 'd' || e.key === 'D' || e.key === 'ArrowRight') this.inputs.rollRight = false;
  }

  private handlePointerDown(e: PointerEvent): void {
    this.isDraggingCamera = true;
    this.prevMouse = {x: e.clientX, y: e.clientY};
  }

  private handlePointerMove(e: PointerEvent): void {
    if (!this.isDraggingCamera) return;
    const dx = e.clientX - this.prevMouse.x;
    const dy = e.clientY - this.prevMouse.y;
    this.prevMouse = {x: e.clientX, y: e.clientY};
    this.camOrbit.yaw -= dx * 0.007;
    this.camOrbit.pitch = THREE.MathUtils.clamp(this.camOrbit.pitch + dy * 0.005, -0.35, 0.85);
  }

  private spawnParticle(
    pos: THREE.Vector3,
    colorHex: number,
    size: number,
    vel: THREE.Vector3,
    lifeSec: number
  ): void {
    for (const slot of this.particlePool) {
      if (!slot.active) {
        slot.active = true;
        slot.life = lifeSec;
        slot.maxLife = lifeSec;
        slot.vel.copy(vel);
        slot.mesh.position.copy(pos);
        slot.mesh.scale.setScalar(size);
        slot.mesh.material.color.setHex(colorHex);
        slot.mesh.material.opacity = 0.6;
        slot.mesh.visible = true;
        return;
      }
    }
  }

  private clearParticles(): void {
    for (const slot of this.particlePool) {
      slot.active = false;
      slot.mesh.visible = false;
    }
  }

  private updateParticles(dt: number): void {
    for (const slot of this.particlePool) {
      if (!slot.active) continue;
      slot.life -= dt;
      if (slot.life <= 0) {
        slot.active = false;
        slot.mesh.visible = false;
      } else {
        slot.mesh.position.addScaledVector(slot.vel, dt);
        const ratio = slot.life / slot.maxLife;
        slot.mesh.scale.multiplyScalar(1 + dt * 0.9);
        slot.mesh.material.opacity = ratio * 0.55;
      }
    }
  }

  update(): void {
    const dt = Math.min(xb.getDeltaTime(), 0.05);
    const camera = xb.core.camera;

    if (this.isFlying) {
      this.updateFlightPhysics(dt);
    } else if (!this.inXRSession) {
      // Hangar / 3D Inspection Camera Orbit around parked aircraft
      if (!this.isDraggingCamera && !this.isInspecting3D) {
        this.camOrbit.yaw += dt * 0.14;
      }
      const ac = this.getSelectedAircraft();
      const scale = 0.7 + ac.tier * 0.28;
      const dist = 24 * scale * this.camOrbit.zoom;
      const targetY = 3 * scale;
      camera.position.set(
        Math.sin(this.camOrbit.yaw) * dist,
        targetY + Math.sin(this.camOrbit.pitch) * dist * 0.65 + 4,
        Math.cos(this.camOrbit.yaw) * dist
      );
      camera.lookAt(0, targetY, -2);
    }

    this.world?.update(dt, camera.position);
  }

  private updateFlightPhysics(dt: number): void {
    const ac = this.flight.currentAircraft;
    const mission = this.flight.currentMission;
    if (!ac || !mission) return;

    // 1. Throttle & Fuel
    if (this.flight.fuel > 0) {
      if (this.inputs.throttleUp) this.flight.throttle = Math.min(100, this.flight.throttle + 50 * dt);
      if (this.inputs.throttleDown) this.flight.throttle = Math.max(0, this.flight.throttle - 50 * dt);

      const burn = ac.fuelBurnRate * (0.2 + (this.flight.throttle / 100) * 0.8) * dt;
      const prevFuel = this.flight.fuel;
      this.flight.fuel = Math.max(0, this.flight.fuel - burn);

      if (prevFuel > 15 && this.flight.fuel <= 15) {
        this.hud?.showAlert('연료 부족 경고 (LOW FUEL)! 스로틀을 줄여 경제 순항하세요.');
        this.audio.playChime('warn');
      }
    } else if (this.flight.throttle > 0) {
      this.flight.throttle = 0;
      this.hud?.showAlert('연료 고갈로 엔진이 정지되었습니다. 기수를 낮춰 활공 착륙하세요!');
      this.audio.playChime('warn');
    }

    // 2. Attitude Control (Autopilot vs Manual)
    if (this.flight.autopilot && !this.flight.onGround) {
      const distToDest = Math.abs(this.flight.pos.z - this.flight.destZ);
      const targetAlt = distToDest < 2500 ? Math.max(120, distToDest * 0.14) : 480;
      const altDiff = targetAlt - this.flight.pos.y;
      const desiredPitch = THREE.MathUtils.clamp(altDiff * 0.0045, -0.18, 0.22);
      this.flight.rot.x += (desiredPitch - this.flight.rot.x) * 2.2 * dt;
      this.flight.rot.z += (0 - this.flight.rot.z) * 3 * dt;

      const desiredYaw = THREE.MathUtils.clamp(-this.flight.pos.x * 0.0018, -0.35, 0.35);
      this.flight.rot.y += (desiredYaw - this.flight.rot.y) * 2.2 * dt;
      if (this.flight.fuel > 0) {
        this.flight.throttle = distToDest < 2200 ? 45 : 85;
      }
    } else {
      const pitchInput = (this.inputs.pitchUp ? 1 : 0) - (this.inputs.pitchDown ? 1 : 0);
      const rollInput = (this.inputs.rollLeft ? 1 : 0) - (this.inputs.rollRight ? 1 : 0);

      if (this.flight.onGround) {
        this.flight.rot.y += rollInput * 0.65 * dt;
        if (this.flight.speed >= ac.vrSpeed * 0.85 && pitchInput > 0) {
          this.flight.rot.x = Math.min(0.28, this.flight.rot.x + ac.pitchRate * 0.6 * dt);
        } else {
          this.flight.rot.x = Math.max(0, this.flight.rot.x - 0.5 * dt);
        }
        this.flight.rot.z = 0;
      } else {
        this.flight.rot.x = THREE.MathUtils.clamp(
          this.flight.rot.x + pitchInput * ac.pitchRate * dt,
          -0.65,
          0.65
        );
        this.flight.rot.z = THREE.MathUtils.clamp(
          this.flight.rot.z + rollInput * ac.turnRate * 1.35 * dt,
          -0.85,
          0.85
        );
        this.flight.rot.y += Math.sin(this.flight.rot.z) * ac.turnRate * 0.85 * dt;
        if (rollInput === 0) {
          this.flight.rot.z *= Math.pow(0.25, dt);
        }
      }
    }

    // 3. Speed & Drag
    const targetSpeed = (this.flight.throttle / 100) * ac.maxSpeed;
    const dragPenalty =
      (this.flight.gearDown ? 0.08 : 0) +
      this.flight.flaps * 0.003 +
      (this.flight.brake ? 0.35 : 0);
    const effectiveTarget = targetSpeed * (1 - dragPenalty);

    if (this.flight.speed < effectiveTarget) {
      this.flight.speed = Math.min(effectiveTarget, this.flight.speed + ac.accel * dt);
    } else {
      const decelRate = this.flight.brake ? ac.accel * 1.4 : ac.accel * 0.45;
      this.flight.speed = Math.max(0, this.flight.speed - decelRate * dt);
    }

    // 4. Lift & Vertical Velocity
    const forwardSpeedMs = this.flight.speed * 0.514 * 1.65;
    const flapLiftBonus = 1 + this.flight.flaps * 0.015;
    const liftRatio = (this.flight.speed / ac.vrSpeed) * flapLiftBonus;
    let verticalVel = 0;

    if (this.flight.onGround) {
      if (liftRatio >= 1.0 && this.flight.rot.x > 0.05) {
        this.flight.onGround = false;
        this.flight.hasTakenOff = true;
        verticalVel = Math.sin(this.flight.rot.x) * forwardSpeedMs;
        this.hud?.showAlert('이륙 성공! G 키를 눌러 랜딩 기어를 수납하세요.');
      }
    } else {
      const stallFactor =
        this.flight.speed < ac.stallSpeed ? -22 * (1 - this.flight.speed / ac.stallSpeed) : 0;
      verticalVel = Math.sin(this.flight.rot.x) * forwardSpeedMs + stallFactor;
      this.flight.verticalSpeedFpm = Math.round(verticalVel * 196.85);

      if (Math.abs(this.flight.rot.z) > 0.55 || Math.abs(this.flight.rot.x) > 0.4) {
        this.flight.satisfaction = Math.max(40, this.flight.satisfaction - 4 * dt);
      }
    }

    // 5. Integration + Crosswind
    this._tmpEuler.set(0, this.flight.rot.y, 0);
    this._dirVec.set(0, 0, -1).applyEuler(this._tmpEuler);
    const windDrift = this.flight.onGround ? 0 : mission.weather.windX * 1.8;

    this.flight.pos.x += (this._dirVec.x * forwardSpeedMs + windDrift) * dt;
    this.flight.pos.z += this._dirVec.z * forwardSpeedMs * dt;
    this.flight.pos.y += verticalVel * dt;

    // 6. Ground & Landing Evaluation
    const groundHeight = 1.8 * (0.7 + ac.tier * 0.28);
    if (!this.flight.onGround && this.flight.pos.y <= groundHeight) {
      this.flight.pos.y = groundHeight;
      this.flight.onGround = true;
      this.flight.touchdownVSpeed = Math.abs(verticalVel);
      this.flight.verticalSpeedFpm = 0;
      this.audio.playTouchdown();

      for (let s = 0; s < 10; s++) {
        this._spawnPos.set(
          this.flight.pos.x + (Math.random() - 0.5) * 4,
          0.5,
          this.flight.pos.z
        );
        this._spawnVel.set((Math.random() - 0.5) * 6, 2 + Math.random() * 3, 8);
        this.spawnParticle(this._spawnPos, 0xe2e8f0, 1.3, this._spawnVel, 1.0);
      }

      const runLen = mission.destAirport.runLen || 1600;
      const runwayCenterZ = this.flight.destZ - runLen / 2 + 100;
      const distToDestZ = Math.abs(this.flight.pos.z - runwayCenterZ);
      const onRunwayWidth = Math.abs(this.flight.pos.x) < 38;

      if (this.flight.hasTakenOff && distToDestZ < runLen * 0.58 && onRunwayWidth) {
        if (!this.flight.gearDown) {
          this.finishFlight(false, '동체 착륙 사고: 랜딩 기어가 전개되지 않았습니다.');
          return;
        }
        if (this.flight.touchdownVSpeed > 16) {
          this.finishFlight(false, '하드 랜딩 충돌: 하강 속도가 안전 한계를 초과했습니다.');
          return;
        }
        this.flight.brake = true;
        this.hud?.updateSystemButtons(this.flight);
        this.finishFlight(true, '');
        return;
      } else if (
        this.flight.hasTakenOff &&
        this.flight.fuel <= 0 &&
        this.flight.touchdownVSpeed <= 16
      ) {
        this.flight.brake = true;
        this.finishFlight(true, 'emergency');
        return;
      } else if (this.flight.hasTakenOff) {
        this.flight.satisfaction = Math.max(20, this.flight.satisfaction - 25);
        this.hud?.showAlert('활주로 밖 지면입니다. 재이륙하여 목적지 활주로로 진입하세요.');
      }
      this.flight.rot.x = 0;
      this.flight.rot.z = 0;
    }

    // 7. Supersonic Sonic Boom & Contrail Particles
    const machNum = this.flight.speed / 661;
    if (machNum >= 1.0) {
      if (!this.flight.wasSupersonic) {
        this.flight.wasSupersonic = true;
        this.audio.playSonicBoom();
        this.hud?.showAlert('SONIC BOOM! 마하 1.0 음속 돌파');
        this.hud?.triggerSonicShake();
      }
      if (this.aircraftModel) {
        this.aircraftModel.sonicCone.visible = true;
        this.aircraftModel.sonicCone.scale.setScalar(0.95 + Math.random() * 0.1);
      }
    } else {
      this.flight.wasSupersonic = false;
      if (this.aircraftModel) this.aircraftModel.sonicCone.visible = false;
    }

    if (!this.flight.onGround && ac.tier >= 3 && this.flight.throttle > 40 && Math.random() < 0.45) {
      this._spawnPos.copy(this.flight.pos).add(this._dirVec.set(0, 0, 6));
      this._spawnVel.set(0, 0.2, 0);
      this.spawnParticle(this._spawnPos, 0xffffff, 0.85, this._spawnVel, 1.3);
    }

    // GPWS Altitude Callouts
    if (!this.flight.onGround && this.flight.hasTakenOff && this.flight.verticalSpeedFpm < -100) {
      const altFt = Math.round((this.flight.pos.y - 2) * 3.28);
      if (altFt <= 500 && this.flight.lastCalloutAlt > 500) {
        this.flight.lastCalloutAlt = 500;
        this.audio.speakGPWS('Five hundred');
      } else if (altFt <= 100 && this.flight.lastCalloutAlt > 100) {
        this.flight.lastCalloutAlt = 100;
        this.audio.speakGPWS('One hundred, minimum');
      } else if (altFt <= 40 && this.flight.lastCalloutAlt > 40) {
        this.flight.lastCalloutAlt = 40;
        this.audio.speakGPWS('Retard, retard');
      }
    }

    // 8. Sync 3D Aircraft, Camera, Particles, Audio, HUD & XR Spatial Card
    if (this.aircraftModel) {
      this.aircraftModel.root.position.copy(this.flight.pos);
      this.aircraftModel.root.rotation.copy(this.flight.rot);
      for (const prop of this.aircraftModel.propellers) {
        prop.rotation.z += (12 + this.flight.throttle * 0.9) * dt;
      }
    }

    this.updateParticles(dt);
    if (!this.inXRSession) {
      this.updateFlightCamera(dt);
    }
    this.hud?.updateTelemetry(this.flight);
    this.audio.updateEngine(this.flight.throttle, this.flight.speed / ac.maxSpeed);

    if (this.inXRSession && this.xrHudTelemetry) {
      const altFt = Math.max(0, Math.round((this.flight.pos.y - 2) * 3.28));
      this.xrHudTelemetry.text = `IAS ${Math.round(this.flight.speed)} KTS · ALT ${altFt} FT\nFUEL ${Math.ceil(this.flight.fuel)}% · THR ${Math.round(this.flight.throttle)}%`;
    }
  }

  private updateFlightCamera(dt: number): void {
    const camera = xb.core.camera;
    const ac = this.flight.currentAircraft;
    const scale = ac ? 0.7 + ac.tier * 0.28 : 1;

    if (this.flight.cameraMode === 'chase') {
      const dist = 18 * scale * this.camOrbit.zoom;
      this._offsetVec.set(
        Math.sin(this.camOrbit.yaw) * dist,
        (4.5 + Math.sin(this.camOrbit.pitch) * 14) * scale * this.camOrbit.zoom,
        Math.cos(this.camOrbit.yaw) * dist
      );
      this._tmpEuler.set(this.flight.rot.x * 0.35, this.flight.rot.y, 0, 'YXZ');
      this._offsetVec.applyEuler(this._tmpEuler);
      this._camTargetPos.copy(this.flight.pos).add(this._offsetVec);
      const dampAlpha = 1 - Math.exp(-12 * dt);
      camera.position.lerp(this._camTargetPos, dampAlpha);

      this._lookTarget.set(0, 1.2 * scale, -12 * scale).applyEuler(this.flight.rot);
      this._lookTarget.add(this.flight.pos);
      camera.lookAt(this._lookTarget);
    } else if (this.flight.cameraMode === 'cockpit') {
      this._offsetVec.set(0, 1.25 * scale, -3.5 * scale).applyEuler(this.flight.rot);
      camera.position.copy(this.flight.pos).add(this._offsetVec);

      this._lookTarget
        .set(
          Math.sin(this.camOrbit.yaw) * 25,
          (0.8 - Math.sin(this.camOrbit.pitch) * 18) * scale,
          -40 * scale
        )
        .applyEuler(this.flight.rot)
        .add(this.flight.pos);
      camera.lookAt(this._lookTarget);
    } else {
      this._offsetVec.set(-1.35 * scale, 0.85 * scale, 1.6 * scale).applyEuler(this.flight.rot);
      camera.position.copy(this.flight.pos).add(this._offsetVec);

      this._lookTarget
        .set(-32 * scale, -3.5 * scale, -8 * scale)
        .applyEuler(this.flight.rot)
        .add(this.flight.pos);
      camera.lookAt(this._lookTarget);
    }
  }

  private finishFlight(success: boolean, failReason: string): void {
    this.isFlying = false;
    this.audio.updateEngine(0, 0);
    const touchdownFpm = Math.round(this.flight.touchdownVSpeed * 196.85);
    const mission = this.flight.currentMission;

    if (success && mission) {
      this.audio.playChime('success');
      const isEmergency = failReason === 'emergency';
      const todMult =
        this.flight.timeOfDay === 'night'
          ? 1.35
          : this.flight.timeOfDay === 'sunset'
            ? 1.15
            : 1.0;
      const basePay = Math.round(mission.reward * todMult * (isEmergency ? 0.5 : 1.0));
      const isButter = this.flight.touchdownVSpeed < 5.0;
      const landingBonus = isEmergency
        ? 0
        : isButter
          ? Math.round(basePay * 0.35)
          : Math.round(basePay * 0.15);
      const satBonus = Math.round(basePay * (this.flight.satisfaction / 100) * 0.25);
      const totalPay = basePay + landingBonus + satBonus;

      this.career.money += totalPay;
      this.career.completedFlights += 1;
      if (
        this.career.bestLandingFpm === null ||
        touchdownFpm < this.career.bestLandingFpm
      ) {
        this.career.bestLandingFpm = touchdownFpm;
      }
      this.saveCareer();

      this.hud?.showResult({
        success: true,
        isEmergency,
        isButter,
        failReason: '',
        airportName: mission.destAirport.name,
        basePay,
        landingBonus,
        satBonus,
        satisfactionPct: Math.round(this.flight.satisfaction),
        totalPay,
        touchdownFpm,
      });
    } else {
      this.audio.playChime('warn');
      this.hud?.showResult({
        success: false,
        isEmergency: false,
        isButter: false,
        failReason,
        airportName: mission?.destAirport.name ?? '',
        basePay: 0,
        landingBonus: 0,
        satBonus: 0,
        satisfactionPct: Math.round(this.flight.satisfaction),
        totalPay: 0,
        touchdownFpm,
      });
    }
  }

  dispose(): void {
    window.removeEventListener('keydown', this.onKeyDownBound);
    window.removeEventListener('keyup', this.onKeyUpBound);
    window.removeEventListener('pointermove', this.onPointerMoveBound);
    window.removeEventListener('pointerup', this.onPointerUpBound);

    const canvas = (xb.core.renderer as THREE.WebGLRenderer | undefined)?.domElement;
    if (canvas) {
      canvas.removeEventListener('pointerdown', this.onPointerDownBound);
      canvas.removeEventListener('wheel', this.onWheelBound);
    }

    this.audio.dispose();
    this.hud?.dispose();
    this.aircraftModel?.dispose();
    this.sharedHullTexture?.dispose();
    this.sharedHullTexture = null;
    if (this.destAirport) {
      xb.core.scene.remove(this.destAirport);
      (this.destAirport.userData.dispose as (() => void) | undefined)?.();
      this.destAirport = null;
    }
    if (this.departureAirport) {
      xb.core.scene.remove(this.departureAirport);
      (this.departureAirport.userData.dispose as (() => void) | undefined)?.();
      this.departureAirport = null;
    }
    this.world?.dispose();
    this.particleGeo.dispose();
    for (const slot of this.particlePool) {
      slot.mesh.material.dispose();
    }
  }
}
