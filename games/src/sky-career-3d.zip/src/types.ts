import * as THREE from 'three';

export type AircraftId = 'cessna' | 'kingair' | 'b737' | 'b747' | 'concorde';

export type TimeOfDay = 'day' | 'sunset' | 'night';

export type CameraMode = 'chase' | 'cockpit' | 'passenger';

export interface AirportSpec {
  code: string;
  name: string;
  desc: string;
  runLen: number;
}

export interface AircraftSpec {
  id: AircraftId;
  tier: number;
  name: string;
  type: string;
  price: number;
  maxSpeed: number;
  vrSpeed: number;
  stallSpeed: number;
  accel: number;
  turnRate: number;
  pitchRate: number;
  mass: number;
  fuelBurnRate: number;
  capacityDesc: string;
  color: number;
  accentColor: number;
  hasDroopNose: boolean;
  imageUrl: string;
}

export interface WeatherCondition {
  name: string;
  windX: number;
  vis: number;
  bonus: number;
}

export interface MissionContract {
  id: string;
  title: string;
  destAirport: AirportSpec;
  type: string;
  category: 'cargo' | 'passenger' | 'vip';
  distanceKm: number;
  worldDistMeters: number;
  payloadTons: number;
  weather: WeatherCondition;
  reward: number;
}

export interface PlayerCareerState {
  money: number;
  completedFlights: number;
  unlockedIds: AircraftId[];
  selectedAircraftId: AircraftId;
  bestLandingFpm: number | null;
}

export interface FlightInputState {
  throttleUp: boolean;
  throttleDown: boolean;
  pitchUp: boolean;
  pitchDown: boolean;
  rollLeft: boolean;
  rollRight: boolean;
}

export interface FlightPhysicsState {
  pos: THREE.Vector3;
  rot: THREE.Euler;
  speed: number;
  throttle: number;
  fuel: number;
  gearDown: boolean;
  flaps: number;
  brake: boolean;
  droopNose: boolean;
  autopilot: boolean;
  cameraMode: CameraMode;
  onGround: boolean;
  hasTakenOff: boolean;
  wasSupersonic: boolean;
  lastCalloutAlt: number;
  satisfaction: number;
  touchdownVSpeed: number;
  verticalSpeedFpm: number;
  destZ: number;
  timeOfDay: TimeOfDay;
  currentAircraft: AircraftSpec | null;
  currentMission: MissionContract | null;
}

export interface FlightResultSummary {
  success: boolean;
  isEmergency: boolean;
  isButter: boolean;
  failReason: string;
  airportName: string;
  basePay: number;
  landingBonus: number;
  satBonus: number;
  satisfactionPct: number;
  totalPay: number;
  touchdownFpm: number;
}
