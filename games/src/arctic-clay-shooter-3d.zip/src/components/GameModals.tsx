import { Home, Play, RotateCcw, Sliders, Volume2, VolumeX } from 'lucide-react';
import type { ProcessedGameAssets } from '../game/assets';
import { CHARACTER_DATA, type GameHUDState } from '../game/types';

interface PauseModalProps {
  sensitivity: number;
  onChangeSensitivity: (val: number) => void;
  muted: boolean;
  onToggleMute: () => void;
  onResume: () => void;
  onRestart: () => void;
  onReturnTitle: () => void;
}

export function PauseModal({
  sensitivity,
  onChangeSensitivity,
  muted,
  onToggleMute,
  onResume,
  onRestart,
  onReturnTitle,
}: PauseModalProps) {
  return (
    <div className="fixed inset-0 z-40 bg-slate-950/75 flex items-center justify-center p-4">
      <div className="w-full max-w-sm rounded-3xl bg-slate-900 border border-white/15 p-6 shadow-2xl text-white">
        <div className="flex items-center justify-between mb-5">
          <h2 className="font-display text-2xl">전투 일시정지</h2>
          <button
            type="button"
            onClick={onToggleMute}
            className="h-9 px-3 rounded-xl bg-slate-800 border border-white/10 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
          >
            {muted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-sky-400" />}
            <span>{muted ? '음소거' : '효과음 켜짐'}</span>
          </button>
        </div>

        {/* Sensitivity Control */}
        <div className="rounded-2xl bg-slate-950/70 border border-white/10 p-4 mb-5">
          <div className="flex items-center justify-between text-xs text-slate-300 mb-2">
            <span className="flex items-center gap-1.5 font-semibold">
              <Sliders className="w-3.5 h-3.5 text-sky-400" />
              시선 회전 감도
            </span>
            <span className="tabular-nums font-bold text-sky-400">{sensitivity.toFixed(1)}x</span>
          </div>
          <input
            type="range"
            min={0.4}
            max={2.2}
            step={0.1}
            value={sensitivity}
            onChange={(e) => onChangeSensitivity( parseFloat(e.target.value) )}
            className="w-full accent-sky-400 cursor-pointer"
          />
        </div>

        <div className="flex flex-col gap-2.5">
          <button
            type="button"
            onClick={onResume}
            className="h-12 rounded-2xl bg-sky-500 hover:bg-sky-400 text-slate-950 font-display text-lg flex items-center justify-center gap-2 cursor-pointer transition-colors"
          >
            <Play className="w-5 h-5 fill-current" />
            <span>전투 계속하기</span>
          </button>
          <button
            type="button"
            onClick={onRestart}
            className="h-11 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-sm flex items-center justify-center gap-2 cursor-pointer transition-colors"
          >
            <RotateCcw className="w-4 h-4" />
            <span>처음부터 다시 시작</span>
          </button>
          <button
            type="button"
            onClick={onReturnTitle}
            className="h-11 rounded-2xl bg-slate-950 hover:bg-slate-800 border border-white/10 text-slate-300 font-semibold text-sm flex items-center justify-center gap-2 cursor-pointer transition-colors"
          >
            <Home className="w-4 h-4" />
            <span>타이틀 화면으로</span>
          </button>
        </div>
      </div>
    </div>
  );
}

interface GameOverModalProps {
  assets: ProcessedGameAssets;
  hud: GameHUDState;
  onRespawn: () => void;
  onReturnTitle: () => void;
}

export function GameOverModal({
  assets,
  hud,
  onRespawn,
  onReturnTitle,
}: GameOverModalProps) {
  const char = CHARACTER_DATA[hud.charKey];
  const accuracy =
    hud.shotsFired > 0 ? Math.min(100, Math.round((hud.shotsHit / hud.shotsFired) * 100)) : 0;

  return (
    <div className="fixed inset-0 z-40 bg-slate-950/80 flex items-center justify-center p-4">
      <div className="w-full max-w-md rounded-3xl bg-slate-900 border border-white/15 p-6 sm:p-7 shadow-2xl text-white text-center">
        <div className="w-24 h-24 mx-auto rounded-2xl bg-slate-800/80 border border-white/10 p-2 mb-3">
          <img
            src={assets.characters[hud.charKey].dataUrl}
            alt={char.name}
            referrerPolicy="no-referrer"
            className="w-full h-full object-contain opacity-85"
          />
        </div>
        <h2 className="font-display text-3xl text-white">전투 불능!</h2>
        <p className="text-sm text-slate-300 mt-1">
          북극 눈싸움 전장에서 {char.name} 대원이 쓰러졌습니다.
        </p>

        {/* Battle Summary Stats */}
        <div className="grid grid-cols-2 gap-2.5 my-5 text-left">
          <div className="rounded-2xl bg-slate-950/80 border border-white/10 p-3 tabular-nums">
            <div className="text-xs text-slate-400">처치 수</div>
            <div className="font-display text-2xl text-rose-400">{hud.kills}명</div>
          </div>
          <div className="rounded-2xl bg-slate-950/80 border border-white/10 p-3 tabular-nums">
            <div className="text-xs text-slate-400">달성 레벨 · 웨이브</div>
            <div className="font-display text-2xl text-amber-300">
              Lv.{hud.level} <span className="text-sm text-slate-400">/ W{hud.wave}</span>
            </div>
          </div>
          <div className="rounded-2xl bg-slate-950/80 border border-white/10 p-3 tabular-nums">
            <div className="text-xs text-slate-400">생존 시간</div>
            <div className="font-display text-xl text-sky-300">{hud.elapsedSeconds}초</div>
          </div>
          <div className="rounded-2xl bg-slate-950/80 border border-white/10 p-3 tabular-nums">
            <div className="text-xs text-slate-400">사격 명중률</div>
            <div className="font-display text-xl text-emerald-300">{accuracy}%</div>
          </div>
        </div>

        <div className="flex flex-col gap-2.5">
          <button
            type="button"
            onClick={onRespawn}
            className="h-13 rounded-2xl bg-sky-500 hover:bg-sky-400 text-slate-950 font-display text-xl flex items-center justify-center gap-2 cursor-pointer transition-colors"
          >
            <RotateCcw className="w-5 h-5" />
            <span>다시 출격하기</span>
          </button>
          <button
            type="button"
            onClick={onReturnTitle}
            className="h-11 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-sm flex items-center justify-center gap-2 cursor-pointer transition-colors"
          >
            <Home className="w-4 h-4" />
            <span>대원 선택으로 돌아가기</span>
          </button>
        </div>
      </div>
    </div>
  );
}
