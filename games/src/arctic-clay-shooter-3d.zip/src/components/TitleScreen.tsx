import { Crosshair, Home, Play, Shield, Volume2, VolumeX, Zap } from 'lucide-react';
import type { ProcessedGameAssets } from '../game/assets';
import { CHARACTER_DATA, CHARACTER_KEYS, type CharacterKey } from '../game/types';

interface TitleScreenProps {
  assets: ProcessedGameAssets;
  selectedChar: CharacterKey;
  onSelectChar: (key: CharacterKey) => void;
  onStart: () => void;
  muted: boolean;
  onToggleMute: () => void;
}

export function TitleScreen({
  assets,
  selectedChar,
  onSelectChar,
  onStart,
  muted,
  onToggleMute,
}: TitleScreenProps) {
  const activeStats = CHARACTER_DATA[selectedChar];

  return (
    <div className="fixed inset-0 z-30 flex flex-col justify-between p-4 sm:p-6 md:p-8 bg-slate-950/65 overflow-y-auto">
      {/* Subtle atmospheric sky panorama frame tint */}
      <img
        src={assets.skyPanoramaUrl}
        alt="북극 설원 전장 배경"
        referrerPolicy="no-referrer"
        className="pointer-events-none fixed inset-0 w-full h-full object-cover opacity-30 -z-10"
      />

      {/* Top Header */}
      <header className="w-full max-w-6xl mx-auto flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-sky-500 flex items-center justify-center text-white shadow-md">
            <Crosshair className="w-5 h-5" />
          </div>
          <div>
            <h1 className="font-display text-xl sm:text-2xl text-white tracking-tight leading-none">
              북극 클레이 배틀 슈터 3D
            </h1>
            <p className="text-xs text-sky-200 mt-1">
              1인칭 설원 전장 · 3연발 눈덩이 블래스터 · 실시간 캐릭터 교체
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={onToggleMute}
          className="h-10 px-3.5 rounded-xl bg-slate-900/85 border border-white/15 text-slate-100 hover:bg-slate-800 transition-colors flex items-center gap-2 text-xs font-semibold cursor-pointer whitespace-nowrap shrink-0"
          aria-label={muted ? '사운드 켜기' : '사운드 끄기'}
        >
          {muted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-sky-400" />}
          <span className="hidden sm:inline">{muted ? '음소거' : '사운드 켜짐'}</span>
        </button>
      </header>

      {/* Main Content Grid */}
      <main className="w-full max-w-6xl mx-auto my-auto py-4 grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">
        {/* Left: Hero Showcase + Launch CTA */}
        <section className="lg:col-span-5 rounded-3xl bg-slate-950/88 border border-white/15 p-5 sm:p-6 flex flex-col justify-between shadow-2xl">
          <div>
            <div className="text-xs font-semibold text-sky-300 tracking-wide mb-2">
              출격 대원 선택 · {activeStats.role}
            </div>
            <div className="flex items-center gap-4">
              <div className="w-28 h-28 sm:w-32 sm:h-32 rounded-2xl bg-gradient-to-b from-sky-400/20 to-slate-900/80 border border-white/10 flex items-center justify-center p-2 shrink-0">
                <img
                  src={assets.characters[selectedChar].dataUrl}
                  alt={activeStats.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-contain drop-shadow-lg"
                />
              </div>
              <div className="min-w-0">
                <h2 className="font-display text-3xl sm:text-4xl text-white leading-tight">
                  {activeStats.name}
                </h2>
                <p className="text-sm text-slate-300 mt-1">{activeStats.weaponName}</p>
                <div className="mt-3 grid grid-cols-3 gap-3 text-xs tabular-nums">
                  <div>
                    <div className="text-slate-400">체력</div>
                    <div className="font-bold text-emerald-400 text-sm">{activeStats.maxHp}</div>
                  </div>
                  <div>
                    <div className="text-slate-400">공격력</div>
                    <div className="font-bold text-amber-400 text-sm">{activeStats.damage}</div>
                  </div>
                  <div>
                    <div className="text-slate-400">이동속도</div>
                    <div className="font-bold text-sky-400 text-sm">{Math.round(activeStats.speed * 100)}</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Tactical Highlights */}
            <div className="mt-5 pt-4 border-t border-white/10 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-slate-300">
              <div className="flex items-start gap-2.5">
                <Zap className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
                <div>
                  <div className="font-semibold text-white">3연발 부채꼴 사격</div>
                  <div className="text-slate-400 mt-0.5">Space, 좌클릭 또는 우측 발사 버튼으로 3발 동시 발사</div>
                </div>
              </div>
              <div className="flex items-start gap-2.5">
                <Home className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <div className="font-semibold text-white">집 3채 은신 전술</div>
                  <div className="text-slate-400 mt-0.5">오두막 내부로 들어가면 적이 추적과 사격을 멈춤</div>
                </div>
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={onStart}
            className="mt-6 w-full h-14 rounded-2xl bg-sky-500 hover:bg-sky-400 active:translate-y-0.5 text-slate-950 font-display text-2xl flex items-center justify-center gap-2.5 shadow-lg transition-all cursor-pointer"
          >
            <Play className="w-6 h-6 fill-current" />
            <span>전장 출격하기</span>
          </button>
        </section>

        {/* Right: 4-Hero Roster Grid + Controls */}
        <section className="lg:col-span-7 flex flex-col gap-4 justify-between">
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-2 gap-3">
            {CHARACTER_KEYS.map((key, idx) => {
              const char = CHARACTER_DATA[key];
              const isSelected = key === selectedChar;
              return (
                <button
                  key={key}
                  type="button"
                  onClick={() => onSelectChar(key)}
                  className={`text-left rounded-2xl p-3.5 transition-all cursor-pointer border ${
                    isSelected
                      ? 'bg-slate-900/95 border-sky-400 shadow-lg ring-2 ring-sky-400/40'
                      : 'bg-slate-950/80 border-white/10 hover:border-white/30 hover:bg-slate-900/85'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-16 h-16 rounded-xl bg-slate-800/80 flex items-center justify-center p-1 shrink-0">
                      <img
                        src={assets.characters[key].dataUrl}
                        alt={char.name}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-contain"
                      />
                    </div>
                    <div className="min-w-0">
                      <div className="text-[11px] text-slate-400 tabular-nums">단축키 {idx + 1}</div>
                      <div className="font-display text-lg text-white truncate">{char.name}</div>
                      <div className="text-xs text-slate-300 truncate">{char.role}</div>
                    </div>
                  </div>
                  <div className="mt-2.5 pt-2 border-t border-white/10 flex items-center justify-between text-[11px] text-slate-400 tabular-nums">
                    <span>HP {char.maxHp}</span>
                    <span>·</span>
                    <span>DMG {char.damage}</span>
                    <span>·</span>
                    <span>연사 {Math.round(1000 / char.fireRate)}/s</span>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Control Strip */}
          <div className="rounded-2xl bg-slate-950/85 border border-white/15 p-4 text-xs text-slate-300 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2 text-white font-semibold">
              <Shield className="w-4 h-4 text-sky-400" />
              <span>PC / 모바일 완벽 대응</span>
            </div>
            <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-slate-300">
              <span>이동: WASD / 조이스틱</span>
              <span aria-hidden="true">·</span>
              <span>시점: 마우스 드래그 / 터치 회전</span>
              <span aria-hidden="true">·</span>
              <span>교체: 숫자 1–4</span>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
