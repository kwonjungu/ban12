import { useRef, useState } from 'react';
import { Crosshair, Home, MousePointer, Pause, Volume2, VolumeX } from 'lucide-react';
import type { ProcessedGameAssets } from '../game/assets';
import {
  CHARACTER_DATA,
  CHARACTER_KEYS,
  type CharacterKey,
  type DamagePopup,
  type GameHUDState,
  type WeaponViewState,
} from '../game/types';
import { TacticalRadar } from './TacticalRadar';

interface GameHUDProps {
  assets: ProcessedGameAssets;
  hud: GameHUDState;
  weapon: WeaponViewState;
  popups: DamagePopup[];
  muted: boolean;
  onToggleMute: () => void;
  onPause: () => void;
  onSwitchChar: (key: CharacterKey) => void;
  onFire: () => void;
  onJoystickMove: (x: number, y: number) => void;
  onLookDelta: (dx: number, dy: number) => void;
  onTogglePointerLock: () => void;
}

export function GameHUD({
  assets,
  hud,
  weapon,
  popups,
  muted,
  onToggleMute,
  onPause,
  onSwitchChar,
  onFire,
  onJoystickMove,
  onLookDelta,
  onTogglePointerLock,
}: GameHUDProps) {
  const activeChar = CHARACTER_DATA[hud.charKey];
  const enemyChar = hud.activeEnemy ? CHARACTER_DATA[hud.activeEnemy.charKey] : null;

  const hpPct = Math.max(0, Math.min(100, (hud.hp / hud.maxHp) * 100));
  const expPct = Math.max(0, Math.min(100, (hud.exp / hud.nextExp) * 100));
  const enemyHpPct = hud.activeEnemy
    ? Math.max(0, Math.min(100, (hud.activeEnemy.hp / hud.activeEnemy.maxHp) * 100))
    : 0;

  // Virtual Joystick State
  const joyZoneRef = useRef<HTMLDivElement>(null);
  const [knobOffset, setKnobOffset] = useState({ x: 0, y: 0 });
  const joyPointerId = useRef<number | null>(null);

  // Touch Look State (right side drag)
  const lookPointerId = useRef<number | null>(null);
  const lastLookPos = useRef({ x: 0, y: 0 });

  const updateJoystick = (clientX: number, clientY: number) => {
    const el = joyZoneRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const maxR = rect.width / 2 - 18;
    let dx = clientX - cx;
    let dy = clientY - cy;
    const dist = Math.hypot(dx, dy);
    if (dist > maxR && dist > 0) {
      dx = (dx / dist) * maxR;
      dy = (dy / dist) * maxR;
    }
    setKnobOffset({ x: dx, y: dy });
    onJoystickMove(dx / maxR, dy / maxR);
  };

  const resetJoystick = () => {
    joyPointerId.current = null;
    setKnobOffset({ x: 0, y: 0 });
    onJoystickMove(0, 0);
  };

  // Weapon Viewmodel Transform
  const weaponTranslateX = weapon.bobX + weapon.recoil * 18;
  const weaponTranslateY = weapon.bobY + weapon.recoil * 22;
  const weaponRotate = weapon.recoil * 7;

  return (
    <div className="fixed inset-0 z-20 pointer-events-none select-none overflow-hidden">
      {/* Damage Vignette Flash */}
      {hud.damageFlashAlpha > 0.03 && (
        <div
          className="fixed inset-0 pointer-events-none border-[10px] border-rose-500/80 bg-rose-600/15"
          style={{ opacity: hud.damageFlashAlpha }}
        />
      )}

      {/* Floating Damage Numbers */}
      {popups.map((p) => (
        <div
          key={p.id}
          className={`fixed pointer-events-none font-display tabular-nums drop-shadow-md animate-float-damage ${
            p.isCrit ? 'text-2xl sm:text-3xl text-amber-300' : 'text-xl sm:text-2xl text-white'
          }`}
          style={{ left: `${p.x}px`, top: `${p.y}px` }}
        >
          -{p.amount}
        </div>
      ))}

      {/* Level Up Banner */}
      {hud.levelUpToast > 0.05 && (
        <div
          className="fixed top-28 left-1/2 -translate-x-1/2 rounded-2xl bg-amber-400 text-slate-950 font-display text-lg sm:text-xl px-5 py-2 shadow-xl border-2 border-white"
          style={{ opacity: Math.min(1, hud.levelUpToast * 1.4) }}
        >
          레벨 업! Lv.{hud.level} 달성 (최대 체력 및 화력 증가)
        </div>
      )}

      {/* Stealth Status Banner */}
      {hud.isHidden && (
        <div className="fixed top-20 sm:top-24 left-1/2 -translate-x-1/2 rounded-2xl bg-emerald-600/95 border border-emerald-300/60 px-4 py-1.5 text-xs sm:text-sm font-bold text-white shadow-lg flex items-center gap-2 whitespace-nowrap">
          <Home className="w-4 h-4 shrink-0" />
          <span>집 내부 은신 중 · 적이 발견하지 못함</span>
        </div>
      )}

      {/* Center Crosshair + Hitmarker */}
      <div
        className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none transition-transform duration-75"
        style={{
          transform: `translate(-50%, -50%) scale(${1 + weapon.recoil * 0.25})`,
        }}
      >
        <svg width="34" height="34" viewBox="0 0 34 34" className="drop-shadow">
          <circle cx="17" cy="17" r="10" fill="none" stroke="rgba(255,255,255,0.88)" strokeWidth="1.8" />
          <circle cx="17" cy="17" r="2.3" fill={activeChar.accentHex} />
          <line x1="17" y1="2" x2="17" y2="7" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" />
          <line x1="17" y1="27" x2="17" y2="32" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" />
          <line x1="2" y1="17" x2="7" y2="17" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" />
          <line x1="27" y1="17" x2="32" y2="17" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" />

          {hud.hitMarkerAlpha > 0.08 && (
            <g stroke="#facc15" strokeWidth="2.4" strokeLinecap="round" opacity={hud.hitMarkerAlpha}>
              <line x1="9" y1="9" x2="13" y2="13" />
              <line x1="25" y1="9" x2="21" y2="13" />
              <line x1="9" y1="25" x2="13" y2="21" />
              <line x1="25" y1="25" x2="21" y2="21" />
            </g>
          )}
        </svg>
      </div>

      {/* First-Person Generative Blaster Viewmodel */}
      <div
        className="fixed bottom-0 right-[8%] sm:right-[14%] w-48 sm:w-72 md:w-80 pointer-events-none z-10 origin-bottom-right"
        style={{
          transform: `translate3d(${weaponTranslateX}px, ${weaponTranslateY}px, 0) rotate(${weaponRotate}deg)`,
        }}
      >
        {/* Muzzle Flash Glow */}
        {weapon.muzzleFlash > 0.05 && (
          <div
            className="absolute top-[16%] left-[12%] w-24 h-24 rounded-full pointer-events-none"
            style={{
              opacity: weapon.muzzleFlash,
              background: `radial-gradient(circle, #ffffff 0%, ${activeChar.accentHex} 45%, transparent 72%)`,
              transform: `scale(${0.8 + weapon.muzzleFlash * 0.6})`,
            }}
          />
        )}
        <img
          src={assets.weaponDataUrl}
          alt={activeChar.weaponName}
          referrerPolicy="no-referrer"
          className="w-full h-auto block drop-shadow-2xl"
        />
      </div>

      {/* TOP HUD BAR */}
      <div className="fixed top-0 left-0 right-0 p-2 sm:p-4 flex items-start justify-between gap-2 z-30">
        {/* Top-Left: Active Hero Card & Switcher */}
        <div className="pointer-events-auto flex flex-col gap-1.5 max-w-[235px] sm:max-w-[310px]">
          <div className="rounded-2xl bg-slate-950/85 border border-white/15 p-2 sm:p-3.5 shadow-lg">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 min-w-0">
                <div className="w-9 h-9 sm:w-12 sm:h-12 rounded-xl bg-slate-800 border border-white/10 p-0.5 sm:p-1 shrink-0">
                  <img
                    src={assets.characters[hud.charKey].dataUrl}
                    alt={activeChar.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-contain"
                  />
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="font-display text-sm sm:text-lg text-white truncate">
                      {activeChar.name}
                    </span>
                    <span className="text-[11px] sm:text-xs font-bold text-amber-300 tabular-nums">
                      Lv.{hud.level}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-400 truncate hidden sm:block">
                    {activeChar.role}
                  </div>
                </div>
              </div>

              <div className="text-right shrink-0 tabular-nums">
                <div className="text-[10px] text-slate-400 hidden sm:block">처치 · 웨이브</div>
                <div className="font-display text-sm sm:text-lg text-white leading-tight">
                  {hud.kills} <span className="text-slate-400 text-[11px] sm:text-xs">/ W{hud.wave}</span>
                </div>
              </div>
            </div>

            {/* HP & EXP Bars */}
            <div className="mt-1.5 sm:mt-2 space-y-1.5">
              <div>
                <div className="flex justify-between text-[10px] sm:text-[11px] font-semibold text-slate-200 tabular-nums mb-0.5">
                  <span>체력</span>
                  <span>
                    {hud.hp} / {hud.maxHp}
                  </span>
                </div>
                <div className="w-full h-2 sm:h-2.5 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-150 ${
                      hpPct > 35 ? 'bg-emerald-400' : 'bg-rose-500'
                    }`}
                    style={{ width: `${hpPct}%` }}
                  />
                </div>
              </div>

              <div className="hidden sm:block">
                <div className="flex justify-between text-[10px] text-slate-400 tabular-nums mb-0.5">
                  <span>경험치</span>
                  <span>
                    {hud.exp} / {hud.nextExp}
                  </span>
                </div>
                <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-sky-400 rounded-full transition-all duration-150"
                    style={{ width: `${expPct}%` }}
                  />
                </div>
              </div>
            </div>

            {/* 4-Character Instant Switcher */}
            <div className="mt-1.5 sm:mt-2.5 pt-1.5 sm:pt-2 border-t border-white/10 grid grid-cols-4 gap-1 sm:gap-1.5">
              {CHARACTER_KEYS.map((key, idx) => {
                const c = CHARACTER_DATA[key];
                const active = key === hud.charKey;
                return (
                  <button
                    key={key}
                    type="button"
                    onClick={() => onSwitchChar(key)}
                    className={`h-8 sm:h-10 rounded-lg sm:rounded-xl flex items-center justify-center gap-1 px-1 transition-all cursor-pointer border ${
                      active
                        ? 'bg-sky-500/25 border-sky-400 text-white'
                        : 'bg-slate-900/80 border-white/10 text-slate-300 hover:bg-slate-800'
                    }`}
                    title={`${c.name} (${idx + 1})`}
                  >
                    <img
                      src={assets.characters[key].dataUrl}
                      alt={c.name}
                      referrerPolicy="no-referrer"
                      className="w-5 h-5 sm:w-6 sm:h-6 object-contain shrink-0"
                    />
                    <span className="text-[10px] font-bold hidden sm:inline truncate">{c.name}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Top-Right: Tactical Radar + Active Enemy Target + Quick Controls */}
        <div className="pointer-events-auto flex flex-col items-end gap-2">
          <div className="flex items-start gap-2">
            {/* Utility Icon Buttons */}
            <div className="flex flex-col sm:flex-row gap-1.5">
              <button
                type="button"
                onClick={onTogglePointerLock}
                className="hidden md:flex h-10 px-3 rounded-xl bg-slate-950/85 border border-white/15 text-slate-200 hover:bg-slate-800 items-center gap-1.5 text-xs font-semibold cursor-pointer whitespace-nowrap"
                title="FPS 마우스 조준 잠금 전환"
              >
                <MousePointer className="w-3.5 h-3.5 text-sky-400" />
                <span>FPS 조준</span>
              </button>
              <button
                type="button"
                onClick={onToggleMute}
                className="w-10 h-10 rounded-xl bg-slate-950/85 border border-white/15 text-slate-200 hover:bg-slate-800 flex items-center justify-center cursor-pointer"
                aria-label={muted ? '사운드 켜기' : '사운드 끄기'}
              >
                {muted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-sky-400" />}
              </button>
              <button
                type="button"
                onClick={onPause}
                className="w-10 h-10 rounded-xl bg-slate-950/85 border border-white/15 text-slate-200 hover:bg-slate-800 flex items-center justify-center cursor-pointer"
                aria-label="일시정지"
              >
                <Pause className="w-4 h-4" />
              </button>
            </div>

            <div className="hidden sm:block">
              <TacticalRadar
                playerX={hud.playerX}
                playerZ={hud.playerZ}
                playerYaw={hud.playerYaw}
                houses={hud.houses}
                activeEnemy={hud.activeEnemy}
                isHidden={hud.isHidden}
              />
            </div>
          </div>

          {/* Active Target Card */}
          {hud.activeEnemy && enemyChar && (
            <div className="rounded-2xl bg-slate-950/85 border border-white/15 px-3 py-2 flex items-center gap-2.5 min-w-[170px] sm:min-w-[215px] shadow-lg">
              <div className="w-9 h-9 rounded-lg bg-slate-800 p-0.5 shrink-0">
                <img
                  src={assets.characters[hud.activeEnemy.charKey].dataUrl}
                  alt={enemyChar.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-contain"
                />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-display text-white truncate">{enemyChar.name}</span>
                  <span className="text-[11px] text-rose-400 font-bold tabular-nums">
                    {hud.activeEnemy.stageNumber}/3
                  </span>
                </div>
                <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden mt-1">
                  <div
                    className="h-full bg-rose-500 rounded-full transition-all duration-150"
                    style={{ width: `${enemyHpPct}%` }}
                  />
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Right-Side Touch Look Zone (for mobile/tablet touch aiming without blocking HUD or Fire button) */}
      <div
        className="fixed top-24 bottom-32 right-0 w-1/2 pointer-events-auto sm:pointer-events-none touch-none z-10"
        onPointerDown={(e) => {
          if (e.pointerType !== 'touch') return;
          lookPointerId.current = e.pointerId;
          lastLookPos.current = { x: e.clientX, y: e.clientY };
          (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
        }}
        onPointerMove={(e) => {
          if (lookPointerId.current !== e.pointerId) return;
          const dx = e.clientX - lastLookPos.current.x;
          const dy = e.clientY - lastLookPos.current.y;
          lastLookPos.current = { x: e.clientX, y: e.clientY };
          onLookDelta(dx * 1.4, dy * 1.4);
        }}
        onPointerUp={(e) => {
          if (lookPointerId.current === e.pointerId) {
            lookPointerId.current = null;
          }
        }}
        onPointerCancel={() => {
          lookPointerId.current = null;
        }}
      />

      {/* Bottom Controls: Virtual Joystick + Desktop Hint + Ergonomic Fire Button */}
      <div className="fixed bottom-4 left-4 right-4 sm:bottom-6 sm:left-6 sm:right-6 flex items-end justify-between gap-4 z-30 pointer-events-none">
        {/* Virtual Joystick */}
        <div
          ref={joyZoneRef}
          className="pointer-events-auto w-26 h-26 sm:w-28 sm:h-28 rounded-full bg-slate-950/50 border-2 border-white/40 relative touch-none flex items-center justify-center shadow-lg"
          onPointerDown={(e) => {
            e.stopPropagation();
            joyPointerId.current = e.pointerId;
            (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
            updateJoystick(e.clientX, e.clientY);
          }}
          onPointerMove={(e) => {
            if (joyPointerId.current !== e.pointerId) return;
            updateJoystick(e.clientX, e.clientY);
          }}
          onPointerUp={(e) => {
            if (joyPointerId.current === e.pointerId) resetJoystick();
          }}
          onPointerCancel={resetJoystick}
          aria-label="이동 조이스틱"
        >
          <div
            className="w-11 h-11 rounded-full bg-white border-2 border-sky-400 shadow-md pointer-events-none"
            style={{ transform: `translate(${knobOffset.x}px, ${knobOffset.y}px)` }}
          />
        </div>

        {/* Desktop Compact Control Hint */}
        <div className="hidden lg:flex items-center gap-3 rounded-xl bg-slate-950/75 border border-white/10 px-4 py-2 text-xs text-slate-300">
          <span>WASD 이동</span>
          <span aria-hidden="true">·</span>
          <span>드래그 시선 회전</span>
          <span aria-hidden="true">·</span>
          <span>Space / 클릭 3연발</span>
          <span aria-hidden="true">·</span>
          <span>1–4 캐릭터 교체</span>
        </div>

        {/* 3-Shot Fire Button */}
        <button
          type="button"
          onPointerDown={(e) => {
            e.stopPropagation();
            onFire();
          }}
          className="pointer-events-auto w-20 h-20 sm:w-24 sm:h-24 rounded-full bg-rose-600 hover:bg-rose-500 active:scale-95 border-4 border-white text-white font-display flex flex-col items-center justify-center shadow-2xl transition-transform cursor-pointer touch-none"
          aria-label="3발 발사"
        >
          <Crosshair className="w-7 h-7 sm:w-8 sm:h-8 mb-0.5" />
          <span className="text-xs sm:text-sm leading-none">3발 발사</span>
        </button>
      </div>
    </div>
  );
}
