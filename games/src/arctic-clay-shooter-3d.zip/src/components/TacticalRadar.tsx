import type { RadarEnemy, RadarHouse } from '../game/types';

interface TacticalRadarProps {
  playerX: number;
  playerZ: number;
  playerYaw: number;
  houses: RadarHouse[];
  activeEnemy: RadarEnemy | null;
  isHidden: boolean;
}

export function TacticalRadar({
  playerX,
  playerZ,
  playerYaw,
  houses,
  activeEnemy,
  isHidden,
}: TacticalRadarProps) {
  const size = 96;
  const center = size / 2;
  const maxRange = 64;

  const toRadarCoords = (wx: number, wz: number) => {
    const dx = wx - playerX;
    const dz = wz - playerZ;
    // Rotate world delta by playerYaw so "up" on radar is always forward
    const cos = Math.cos(-playerYaw);
    const sin = Math.sin(-playerYaw);
    const rx = dx * cos - dz * sin;
    const rz = dx * sin + dz * cos;

    const scale = (center - 10) / maxRange;
    const px = center + rx * scale;
    const py = center + rz * scale;

    // Clamp inside radar circle
    const dist = Math.hypot(px - center, py - center);
    const maxR = center - 8;
    if (dist > maxR && dist > 0) {
      const k = maxR / dist;
      return {
        x: center + (px - center) * k,
        y: center + (py - center) * k,
      };
    }
    return { x: px, y: py };
  };

  const enemyPos = activeEnemy ? toRadarCoords(activeEnemy.x, activeEnemy.z) : null;

  return (
    <div
      className="relative rounded-2xl bg-slate-950/85 border border-white/15 p-1.5 shadow-lg"
      aria-label="전술 레이더"
    >
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="block">
        <defs>
          <radialGradient id="radarBg" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="rgba(14, 165, 233, 0.22)" />
            <stop offset="100%" stopColor="rgba(15, 23, 42, 0.9)" />
          </radialGradient>
        </defs>

        <circle cx={center} cy={center} r={center - 3} fill="url(#radarBg)" stroke="rgba(148,163,184,0.35)" strokeWidth="1" />
        <circle cx={center} cy={center} r={(center - 3) * 0.55} fill="none" stroke="rgba(148,163,184,0.18)" strokeWidth="1" strokeDasharray="3 3" />

        {/* Forward FOV cone */}
        <path
          d={`M ${center} ${center} L ${center - 18} ${center - 34} A 38 38 0 0 1 ${center + 18} ${center - 34} Z`}
          fill={isHidden ? 'rgba(16, 185, 129, 0.22)' : 'rgba(56, 189, 248, 0.18)'}
        />

        {/* 3 Hideout Houses */}
        {houses.map((h) => {
          const pos = toRadarCoords(h.x, h.z);
          return (
            <rect
              key={h.id}
              x={pos.x - 4}
              y={pos.y - 4}
              width={8}
              height={8}
              rx={2}
              fill={h.color}
              stroke="#ffffff"
              strokeWidth={1.2}
            />
          );
        })}

        {/* Active Enemy */}
        {enemyPos && (
          <g>
            <circle cx={enemyPos.x} cy={enemyPos.y} r={5.5} fill="rgba(239, 68, 68, 0.35)" />
            <circle cx={enemyPos.x} cy={enemyPos.y} r={3.5} fill="#ef4444" stroke="#ffffff" strokeWidth={1.2} />
          </g>
        )}

        {/* Player Center Triangle */}
        <polygon
          points={`${center},${center - 5} ${center - 4},${center + 4} ${center + 4},${center + 4}`}
          fill={isHidden ? '#10b981' : '#ffffff'}
        />
      </svg>
    </div>
  );
}
