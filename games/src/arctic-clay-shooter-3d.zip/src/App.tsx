import { useCallback, useEffect, useRef, useState } from 'react';
import { GameHUD } from './components/GameHUD';
import { GameOverModal, PauseModal } from './components/GameModals';
import { TitleScreen } from './components/TitleScreen';
import { ArcticBattleEngine } from './game/ArcticBattleEngine';
import { preloadAllGameAssets, RAW_PREVIEW_URLS, type ProcessedGameAssets } from './game/assets';
import { soundEngine } from './game/sound';
import {
  CHARACTER_DATA,
  type CharacterKey,
  type DamagePopup,
  type GameHUDState,
  type WeaponViewState,
} from './game/types';

const INITIAL_HUD: GameHUDState = {
  phase: 'title',
  charKey: 'pororo',
  hp: CHARACTER_DATA.pororo.maxHp,
  maxHp: CHARACTER_DATA.pororo.maxHp,
  level: 1,
  exp: 0,
  nextExp: 100,
  kills: 0,
  wave: 1,
  shotsFired: 0,
  shotsHit: 0,
  elapsedSeconds: 0,
  isHidden: false,
  playerX: 0,
  playerZ: 4,
  playerYaw: 0,
  houses: [],
  activeEnemy: null,
  hitMarkerAlpha: 0,
  damageFlashAlpha: 0,
  levelUpToast: 0,
};

const INITIAL_WEAPON: WeaponViewState = {
  recoil: 0,
  bobX: 0,
  bobY: 0,
  muzzleFlash: 0,
};

export default function App() {
  const canvasMountRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<ArcticBattleEngine | null>(null);

  const [assets, setAssets] = useState<ProcessedGameAssets | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [contextLost, setContextLost] = useState(false);

  const [selectedStartChar, setSelectedStartChar] = useState<CharacterKey>('pororo');
  const [hud, setHud] = useState<GameHUDState>(INITIAL_HUD);
  const [weapon, setWeapon] = useState<WeaponViewState>(INITIAL_WEAPON);
  const [popups, setPopups] = useState<DamagePopup[]>([]);
  const [muted, setMuted] = useState(false);
  const [sensitivity, setSensitivity] = useState(1.0);

  // Load and chroma-key process all generative assets once
  useEffect(() => {
    let active = true;
    preloadAllGameAssets(4)
      .then((bundle) => {
        if (active) setAssets(bundle);
      })
      .catch((err) => {
        if (active) {
          setLoadError(err instanceof Error ? err.message : '에셋을 불러오지 못했습니다.');
        }
      });
    return () => {
      active = false;
    };
  }, []);

  // Initialize Three.js engine once assets and mount container are ready
  useEffect(() => {
    if (!assets || !canvasMountRef.current) return;

    const engine = new ArcticBattleEngine(canvasMountRef.current, assets, {
      onHudUpdate: (nextHud) => setHud(nextHud),
      onWeaponUpdate: (nextWeapon) => setWeapon(nextWeapon),
      onDamagePopup: (popup) => {
        setPopups((prev) => [...prev.slice(-6), popup]);
        window.setTimeout(() => {
          setPopups((prev) => prev.filter((item) => item.id !== popup.id));
        }, 740);
      },
      onContextLost: (lost) => setContextLost(lost),
    });

    engineRef.current = engine;
    return () => {
      engine.dispose();
      engineRef.current = null;
    };
  }, [assets]);

  const handleToggleMute = useCallback(() => {
    setMuted((prev) => {
      const next = !prev;
      soundEngine.setMuted(next);
      return next;
    });
  }, []);

  const handleStart = useCallback(() => {
    engineRef.current?.startGame(selectedStartChar);
  }, [selectedStartChar]);

  const handleSwitchChar = useCallback((key: CharacterKey) => {
    setSelectedStartChar(key);
    engineRef.current?.switchCharacter(key);
  }, []);

  const handleChangeSensitivity = useCallback((val: number) => {
    setSensitivity(val);
    engineRef.current?.setSensitivity(val);
  }, []);

  return (
    <div className="relative w-full h-full overflow-hidden bg-sky-200">
      {/* Dedicated WebGL Mount Container */}
      <div ref={canvasMountRef} className="absolute inset-0 w-full h-full" />

      {/* Loading State */}
      {!assets && !loadError && (
        <div className="fixed inset-0 z-50 flex flex-col items-center justify-center p-6 bg-slate-950 text-white">
          <img
            src={RAW_PREVIEW_URLS.skyPanorama}
            alt="북극 전장 로딩 배경"
            referrerPolicy="no-referrer"
            className="fixed inset-0 w-full h-full object-cover opacity-35 -z-10"
          />
          <div className="w-12 h-12 rounded-full border-4 border-sky-400 border-t-transparent animate-spin mb-4" />
          <h1 className="font-display text-2xl sm:text-3xl">북극 설원 전장 준비 중</h1>
          <p className="text-sm text-sky-200 mt-1.5">클레이 캐릭터 및 3D 텍스처를 불러오고 있습니다.</p>
        </div>
      )}

      {/* Load Error / WebGL Fallback */}
      {(loadError || contextLost) && (
        <div className="fixed inset-0 z-50 flex flex-col items-center justify-center p-6 bg-slate-950/95 text-white text-center">
          <h2 className="font-display text-2xl mb-2">
            {contextLost ? '3D 그래픽 컨텍스트 복구 중' : '게임 에셋 로드 오류'}
          </h2>
          <p className="text-sm text-slate-300 max-w-md mb-5">
            {loadError || '브라우저의 WebGL 연결이 잠시 중단되었습니다. 새로고침하면 정상 복구됩니다.'}
          </p>
          <button
            type="button"
            onClick={() => window.location.reload()}
            className="px-6 py-3 rounded-2xl bg-sky-500 hover:bg-sky-400 text-slate-950 font-display text-lg cursor-pointer"
          >
            다시 불러오기
          </button>
        </div>
      )}

      {/* Title Screen */}
      {assets && hud.phase === 'title' && (
        <TitleScreen
          assets={assets}
          selectedChar={selectedStartChar}
          onSelectChar={setSelectedStartChar}
          onStart={handleStart}
          muted={muted}
          onToggleMute={handleToggleMute}
        />
      )}

      {/* Active Gameplay HUD */}
      {assets && hud.phase !== 'title' && (
        <GameHUD
          assets={assets}
          hud={hud}
          weapon={weapon}
          popups={popups}
          muted={muted}
          onToggleMute={handleToggleMute}
          onPause={() => engineRef.current?.setPaused(true)}
          onSwitchChar={handleSwitchChar}
          onFire={() => engineRef.current?.triggerPlayerFire()}
          onJoystickMove={(x, y) => engineRef.current?.setJoystickInput(x, y)}
          onLookDelta={(dx, dy) => engineRef.current?.applyLookDelta(dx, dy)}
          onTogglePointerLock={() => engineRef.current?.togglePointerLock()}
        />
      )}

      {/* Pause Modal */}
      {assets && hud.phase === 'paused' && (
        <PauseModal
          sensitivity={sensitivity}
          onChangeSensitivity={handleChangeSensitivity}
          muted={muted}
          onToggleMute={handleToggleMute}
          onResume={() => engineRef.current?.setPaused(false)}
          onRestart={() => engineRef.current?.restartGame()}
          onReturnTitle={() => engineRef.current?.returnToTitle()}
        />
      )}

      {/* Game Over Modal */}
      {assets && hud.phase === 'gameover' && (
        <GameOverModal
          assets={assets}
          hud={hud}
          onRespawn={() => engineRef.current?.restartGame()}
          onReturnTitle={() => engineRef.current?.returnToTitle()}
        />
      )}
    </div>
  );
}
