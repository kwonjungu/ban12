import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import type { ProcessedGameAssets } from './assets';
import { soundEngine } from './sound';
import {
  CHARACTER_DATA,
  ENEMY_SPAWN_SEQUENCE,
  type CharacterKey,
  type DamagePopup,
  type GameHUDState,
  type GamePhase,
  type RadarHouse,
  type WeaponViewState,
} from './types';

interface HouseData {
  id: string;
  x: number;
  z: number;
  halfW: number;
  halfD: number;
  outerHalfW: number;
  outerHalfD: number;
  color: string;
}

interface ObstacleData {
  x: number;
  z: number;
  radius: number;
}

interface EnemyEntity {
  group: THREE.Group;
  standee: THREE.Mesh;
  standeeMat: THREE.MeshStandardMaterial;
  hpBarGroup: THREE.Group;
  hpFgMesh: THREE.Mesh;
  charKey: CharacterKey;
  stageNumber: number;
  hp: number;
  maxHp: number;
  speed: number;
  damage: number;
  lastFireTime: number;
  fireRate: number;
  hitFlashTimer: number;
  strafeSign: number;
  strafeTimer: number;
  standeeBaseY: number;
}

interface BulletEntity {
  mesh: THREE.Mesh;
  velocity: THREE.Vector3;
  isPlayer: boolean;
  damage: number;
  life: number;
}

interface ParticleEntity {
  mesh: THREE.Mesh;
  velocity: THREE.Vector3;
  life: number;
}

// Reusable module-scope math helpers (zero per-frame GC allocation)
const _vForward = new THREE.Vector3();
const _vRight = new THREE.Vector3();
const _vMove = new THREE.Vector3();
const _vToPlayer = new THREE.Vector3();
const _vShotDir = new THREE.Vector3();
const _vLookDir = new THREE.Vector3();
const _vUp = new THREE.Vector3(0, 1, 0);
const _vProj = new THREE.Vector3();

function detectSoftwareWebGL(): boolean {
  try {
    const probeCanvas = document.createElement('canvas');
    const gl = probeCanvas.getContext('webgl2') || probeCanvas.getContext('webgl');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param) || '');
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return true;
  }
}

function groundHeightAt(x: number, z: number): number {
  const dist = Math.hypot(x, z);
  let h = Math.sin(x * 0.08) * Math.cos(z * 0.08) * 0.25;
  if (dist > 68) {
    h += (dist - 68) * 0.55 + Math.sin(x * 0.2) * 2.2;
  }
  return h;
}

function createRadialShadowTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 64;
  canvas.height = 64;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    const grad = ctx.createRadialGradient(32, 32, 4, 32, 32, 30);
    grad.addColorStop(0, 'rgba(15, 23, 42, 0.45)');
    grad.addColorStop(0.6, 'rgba(15, 23, 42, 0.18)');
    grad.addColorStop(1, 'rgba(15, 23, 42, 0)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 64, 64);
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.needsUpdate = true;
  return tex;
}

export interface EngineCallbacks {
  onHudUpdate: (hud: GameHUDState) => void;
  onWeaponUpdate: (weapon: WeaponViewState) => void;
  onDamagePopup: (popup: DamagePopup) => void;
  onContextLost: (lost: boolean) => void;
}

export class ArcticBattleEngine {
  private container: HTMLElement;
  private assets: ProcessedGameAssets;
  private callbacks: EngineCallbacks;
  private isSoftwareGl: boolean;

  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private renderer: THREE.WebGLRenderer;
  private clock = new THREE.Clock();

  private frameId = 0;
  private disposed = false;

  // Game State
  private phase: GamePhase = 'title';
  private currentCharKey: CharacterKey = 'pororo';
  private hp = 120;
  private maxHp = 120;
  private level = 1;
  private exp = 0;
  private nextExp = 100;
  private kills = 0;
  private wave = 1;
  private shotsFired = 0;
  private shotsHit = 0;
  private elapsedSeconds = 0;
  private isHidden = false;
  private currentSpawnIndex = 0;
  private lastFireTime = 0;

  // Visual Feedback State
  private recoil = 0;
  private muzzleFlash = 0;
  private bobPhase = 0;
  private bobIntensity = 0;
  private hitMarkerAlpha = 0;
  private damageFlashAlpha = 0;
  private levelUpToast = 0;
  private popupCounter = 1;
  private hudEmitAccum = 0;

  // Player & Camera Controls
  private playerPos = new THREE.Vector3(0, 0, 4);
  private cameraYaw = 0;
  private cameraPitch = 0.02;
  private sensitivity = 1.0;
  private keys: Record<string, boolean> = {};
  private joyInput = { x: 0, y: 0 };

  private isPointerDown = false;
  private dragMovedDist = 0;
  private prevPointerX = 0;
  private prevPointerY = 0;

  // World Entities
  private houses: HouseData[] = [];
  private obstacles: ObstacleData[] = [];
  private enemies: EnemyEntity[] = [];
  private bullets: BulletEntity[] = [];
  private particles: ParticleEntity[] = [];
  private snowSystem: THREE.Points | null = null;
  private shadowTex: THREE.CanvasTexture;

  // Shared Geometries & Cached Materials for bullets & particles
  private playerBulletGeo = new THREE.SphereGeometry(0.24, 14, 14);
  private enemyBulletGeo = new THREE.SphereGeometry(0.28, 14, 14);
  private particleGeo = new THREE.DodecahedronGeometry(0.22, 0);
  private bulletMatCache = new Map<number, THREE.MeshStandardMaterial>();
  private particleMatCache = new Map<number, THREE.MeshStandardMaterial>();

  constructor(
    container: HTMLElement,
    assets: ProcessedGameAssets,
    callbacks: EngineCallbacks
  ) {
    this.container = container;
    this.assets = assets;
    this.callbacks = callbacks;
    this.isSoftwareGl = detectSoftwareWebGL();
    this.shadowTex = createRadialShadowTexture();

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0xc7e6fb);
    this.scene.fog = new THREE.FogExp2(0xc7e6fb, 0.0082);

    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;
    this.camera = new THREE.PerspectiveCamera(68, width / height, 0.1, 280);

    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.08;
    this.renderer.setPixelRatio(
      this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio || 1, 2)
    );
    this.renderer.setSize(width, height);
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    const canvas = this.renderer.domElement;
    canvas.style.width = '100%';
    canvas.style.height = '100%';
    canvas.style.display = 'block';
    canvas.style.touchAction = 'none';
    this.container.appendChild(canvas);

    // Studio Environment Reflection (PMREM + RoomEnvironment)
    const pmremGenerator = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    this.setupLighting();
    this.buildArcticWorld();
    this.bindEvents();

    if (!this.isSoftwareGl) {
      this.renderer.compile(this.scene, this.camera);
    }

    this.emitHUDState();
    this.startLoop();
  }

  private setupLighting() {
    const hemiLight = new THREE.HemisphereLight(0xe0f2fe, 0x93c5fd, 0.88);
    hemiLight.position.set(0, 50, 0);
    this.scene.add(hemiLight);

    const dirLight = new THREE.DirectionalLight(0xfffbeb, 0.95);
    dirLight.position.set(35, 55, 25);
    dirLight.castShadow = !this.isSoftwareGl;
    dirLight.shadow.mapSize.width = 2048;
    dirLight.shadow.mapSize.height = 2048;
    dirLight.shadow.camera.near = 5;
    dirLight.shadow.camera.far = 160;
    const d = 65;
    dirLight.shadow.camera.left = -d;
    dirLight.shadow.camera.right = d;
    dirLight.shadow.camera.top = d;
    dirLight.shadow.camera.bottom = -d;
    dirLight.shadow.bias = -0.0005;
    dirLight.shadow.normalBias = 0.02;
    this.scene.add(dirLight);

    const rimLight = new THREE.DirectionalLight(0xbae6fd, 0.35);
    rimLight.position.set(-40, 25, -35);
    this.scene.add(rimLight);
  }

  private buildArcticWorld() {
    // 1. Panoramic Sky Dome mapped with generative arctic_sky_panorama
    const skyGeo = new THREE.SphereGeometry(210, 32, 20);
    const skyMat = new THREE.MeshBasicMaterial({
      map: this.assets.skyTexture,
      side: THREE.BackSide,
      fog: false,
    });
    const skyDome = new THREE.Mesh(skyGeo, skyMat);
    skyDome.position.y = 14;
    this.scene.add(skyDome);

    // 2. Sculpted Textured Snow Terrain (generative tex_arctic_snow)
    const groundGeo = new THREE.PlaneGeometry(200, 200, 56, 56);
    const posAttr = groundGeo.attributes.position;
    for (let i = 0; i < posAttr.count; i++) {
      const gx = posAttr.getX(i);
      const gy = posAttr.getY(i);
      // Note plane rotated -PI/2 around X maps local Y -> -world Z
      const wz = -gy;
      posAttr.setZ(i, groundHeightAt(gx, wz));
    }
    groundGeo.computeVertexNormals();

    const groundMat = new THREE.MeshStandardMaterial({
      map: this.assets.snowTexture,
      bumpMap: this.assets.snowTexture,
      bumpScale: 0.14,
      roughness: 0.86,
      metalness: 0.04,
    });
    const ground = new THREE.Mesh(groundGeo, groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    this.scene.add(ground);

    // 3. 3 Hideout Houses (은신처 집 3채) built with generative clay cabin texture
    this.createHideoutHouse('red', -15, -12, '#ef4444', 0xef4444);
    this.createHideoutHouse('blue', 16, -10, '#3b82f6', 0x3b82f6);
    this.createHideoutHouse('amber', 0, 18, '#f59e0b', 0xf59e0b);

    // 4. 24 Articulated Arctic Obstacles (generative ice crystal + snow + timber textures)
    const iceMat = new THREE.MeshStandardMaterial({
      map: this.assets.iceTexture,
      roughness: 0.25,
      metalness: 0.12,
    });
    const snowBlockMat = new THREE.MeshStandardMaterial({
      map: this.assets.snowTexture,
      roughness: 0.82,
      metalness: 0.04,
    });
    const crateMat = new THREE.MeshStandardMaterial({
      map: this.assets.cabinTexture,
      roughness: 0.72,
      metalness: 0.08,
    });

    for (let i = 0; i < 24; i++) {
      const angle = (i / 24) * Math.PI * 2 + (i % 3) * 0.12;
      const dist = 24 + ((i * 7) % 36);
      const ox = Math.cos(angle) * dist;
      const oz = Math.sin(angle) * dist;
      const gy = groundHeightAt(ox, oz);

      const propGroup = new THREE.Group();
      const type = i % 3;

      if (type === 0) {
        // Multi-part Glacier Ice Cluster
        const mainCrystal = new THREE.Mesh(new THREE.DodecahedronGeometry(1.65, 0), iceMat);
        mainCrystal.position.y = 1.2;
        mainCrystal.rotation.set(0.2 * i, 0.5 * i, 0.15);
        const sideCrystal = new THREE.Mesh(new THREE.DodecahedronGeometry(0.95, 0), iceMat);
        sideCrystal.position.set(1.1, 0.7, 0.6);
        const snowCap = new THREE.Mesh(new THREE.CylinderGeometry(1.9, 2.2, 0.35, 10), snowBlockMat);
        snowCap.position.y = 0.18;
        propGroup.add(mainCrystal, sideCrystal, snowCap);
      } else if (type === 1) {
        // Fortified Snow & Ice Barricade
        const wallBase = new THREE.Mesh(new THREE.BoxGeometry(3.8, 1.35, 1.05), snowBlockMat);
        wallBase.position.y = 0.68;
        const iceTrim = new THREE.Mesh(new THREE.BoxGeometry(3.9, 0.3, 1.15), iceMat);
        iceTrim.position.y = 1.32;
        propGroup.add(wallBase, iceTrim);
        propGroup.rotation.y = angle + Math.PI / 2;
      } else {
        // Timber Supply Crate + Ice Core
        const crate = new THREE.Mesh(new THREE.BoxGeometry(1.7, 1.5, 1.7), crateMat);
        crate.position.y = 0.75;
        const topIce = new THREE.Mesh(new THREE.OctahedronGeometry(0.65, 0), iceMat);
        topIce.position.y = 1.95;
        propGroup.add(crate, topIce);
        propGroup.rotation.y = i * 0.4;
      }

      propGroup.traverse((child) => {
        if ((child as THREE.Mesh).isMesh) {
          child.castShadow = true;
          child.receiveShadow = true;
        }
      });

      propGroup.position.set(ox, gy, oz);
      this.scene.add(propGroup);
      this.obstacles.push({ x: ox, z: oz, radius: 1.9 });
    }

    // 5. Snowfall Particle System
    const snowCount = 700;
    const snowGeo = new THREE.BufferGeometry();
    const snowPositions = new Float32Array(snowCount * 3);
    for (let i = 0; i < snowCount; i++) {
      snowPositions[i * 3] = (Math.random() - 0.5) * 140;
      snowPositions[i * 3 + 1] = Math.random() * 34;
      snowPositions[i * 3 + 2] = (Math.random() - 0.5) * 140;
    }
    snowGeo.setAttribute('position', new THREE.BufferAttribute(snowPositions, 3));
    const snowMat = new THREE.PointsMaterial({
      color: 0xffffff,
      size: 0.32,
      transparent: true,
      opacity: 0.82,
    });
    this.snowSystem = new THREE.Points(snowGeo, snowMat);
    this.scene.add(this.snowSystem);
  }

  private createHideoutHouse(
    id: string,
    x: number,
    z: number,
    roofHex: string,
    roofColorNum: number
  ) {
    const houseGroup = new THREE.Group();
    const w = 7.2;
    const d = 7.2;
    const h = 3.9;
    const wallThick = 0.48;

    const wallMat = new THREE.MeshStandardMaterial({
      map: this.assets.cabinTexture,
      roughness: 0.78,
      metalness: 0.05,
    });
    const roofMat = new THREE.MeshStandardMaterial({
      color: roofColorNum,
      map: this.assets.snowTexture,
      roughness: 0.65,
      metalness: 0.06,
    });
    const floorMat = new THREE.MeshStandardMaterial({
      color: 0xb45309,
      map: this.assets.cabinTexture,
      roughness: 0.85,
    });
    const trimMat = new THREE.MeshStandardMaterial({
      color: 0xfef3c7,
      emissive: 0xfbbf24,
      emissiveIntensity: 0.35,
      roughness: 0.4,
    });

    const floor = new THREE.Mesh(new THREE.BoxGeometry(w, 0.22, d), floorMat);
    floor.position.y = 0.11;
    floor.receiveShadow = true;
    houseGroup.add(floor);

    const backWall = new THREE.Mesh(new THREE.BoxGeometry(w, h, wallThick), wallMat);
    backWall.position.set(0, h / 2, -d / 2 + wallThick / 2);
    backWall.castShadow = true;
    backWall.receiveShadow = true;

    const leftWall = new THREE.Mesh(new THREE.BoxGeometry(wallThick, h, d), wallMat);
    leftWall.position.set(-w / 2 + wallThick / 2, h / 2, 0);
    leftWall.castShadow = true;
    leftWall.receiveShadow = true;

    const rightWall = new THREE.Mesh(new THREE.BoxGeometry(wallThick, h, d), wallMat);
    rightWall.position.set(w / 2 - wallThick / 2, h / 2, 0);
    rightWall.castShadow = true;
    rightWall.receiveShadow = true;

    // Front wall with wide 2.8m doorway
    const doorWidth = 2.8;
    const frontSideWidth = (w - doorWidth) / 2;
    const frontLeft = new THREE.Mesh(new THREE.BoxGeometry(frontSideWidth, h, wallThick), wallMat);
    frontLeft.position.set(-w / 2 + frontSideWidth / 2, h / 2, d / 2 - wallThick / 2);
    frontLeft.castShadow = true;
    frontLeft.receiveShadow = true;

    const frontRight = new THREE.Mesh(new THREE.BoxGeometry(frontSideWidth, h, wallThick), wallMat);
    frontRight.position.set(w / 2 - frontSideWidth / 2, h / 2, d / 2 - wallThick / 2);
    frontRight.castShadow = true;
    frontRight.receiveShadow = true;

    const doorHeader = new THREE.Mesh(new THREE.BoxGeometry(doorWidth, 0.95, wallThick), wallMat);
    doorHeader.position.set(0, h - 0.47, d / 2 - wallThick / 2);
    doorHeader.castShadow = true;

    // Glowing lantern sign above doorway so hideouts are easy to spot from across the snowfield
    const lantern = new THREE.Mesh(new THREE.SphereGeometry(0.28, 12, 12), trimMat);
    lantern.position.set(0, h - 0.35, d / 2 + 0.25);

    const roof = new THREE.Mesh(new THREE.ConeGeometry(5.8, 2.5, 4), roofMat);
    roof.position.y = h + 1.25;
    roof.rotation.y = Math.PI / 4;
    roof.castShadow = true;

    houseGroup.add(backWall, leftWall, rightWall, frontLeft, frontRight, doorHeader, lantern, roof);
    const gy = groundHeightAt(x, z);
    houseGroup.position.set(x, gy, z);
    this.scene.add(houseGroup);

    this.houses.push({
      id,
      x,
      z,
      halfW: w / 2 - 0.5,
      halfD: d / 2 - 0.5,
      outerHalfW: w / 2 + 0.25,
      outerHalfD: d / 2 + 0.25,
      color: roofHex,
    });
  }

  private spawnEnemyAI() {
    if (this.enemies.length >= 1 || this.phase !== 'playing') return;

    const chosenKey = ENEMY_SPAWN_SEQUENCE[this.currentSpawnIndex % ENEMY_SPAWN_SEQUENCE.length];
    const stageNumber = (this.currentSpawnIndex % ENEMY_SPAWN_SEQUENCE.length) + 1;
    this.currentSpawnIndex++;

    const data = CHARACTER_DATA[chosenKey];
    const group = new THREE.Group();

    // Ground contact shadow disc
    const shadowPlane = new THREE.Mesh(
      new THREE.PlaneGeometry(2.3, 2.3),
      new THREE.MeshBasicMaterial({
        map: this.shadowTex,
        transparent: true,
        depthWrite: false,
      })
    );
    shadowPlane.rotation.x = -Math.PI / 2;
    shadowPlane.position.y = 0.04;
    group.add(shadowPlane);

    // Generative clay character standee mesh
    const standeeH = 2.75 * data.scale;
    const standeeGeo = new THREE.PlaneGeometry(standeeH, standeeH);
    const standeeMat = new THREE.MeshStandardMaterial({
      map: this.assets.characters[chosenKey].texture,
      transparent: true,
      alphaTest: 0.35,
      side: THREE.DoubleSide,
      roughness: 0.72,
      metalness: 0.04,
      emissive: new THREE.Color(0x000000),
      emissiveIntensity: 0,
    });
    const standee = new THREE.Mesh(standeeGeo, standeeMat);
    standee.position.y = standeeH * 0.48;
    standee.castShadow = true;
    group.add(standee);

    // 3D floating HP bar above enemy
    const hpBarGroup = new THREE.Group();
    const bgMesh = new THREE.Mesh(
      new THREE.PlaneGeometry(1.6, 0.22),
      new THREE.MeshBasicMaterial({ color: 0x0f172a, side: THREE.DoubleSide })
    );
    const fgMesh = new THREE.Mesh(
      new THREE.PlaneGeometry(1.5, 0.14),
      new THREE.MeshBasicMaterial({ color: 0xef4444, side: THREE.DoubleSide })
    );
    fgMesh.position.z = 0.015;
    hpBarGroup.add(bgMesh, fgMesh);
    hpBarGroup.position.y = standeeH + 0.35;
    group.add(hpBarGroup);

    // Pick spawn point away from houses
    let sx = 0;
    let sz = 0;
    for (let attempt = 0; attempt < 8; attempt++) {
      const angle = Math.random() * Math.PI * 2;
      const dist = 26 + Math.random() * 12;
      sx = THREE.MathUtils.clamp(this.playerPos.x + Math.cos(angle) * dist, -54, 54);
      sz = THREE.MathUtils.clamp(this.playerPos.z + Math.sin(angle) * dist, -54, 54);
      if (!this.checkPosInHouse(sx, sz)) break;
    }
    group.position.set(sx, groundHeightAt(sx, sz), sz);
    this.scene.add(group);

    // Gentle scaling with waves while preserving approachable baseline
    const waveScale = 1 + (this.wave - 1) * 0.12;
    const maxEnemyHp = Math.round(data.maxHp * 0.46 * waveScale);

    this.enemies.push({
      group,
      standee,
      standeeMat,
      hpBarGroup,
      hpFgMesh: fgMesh,
      charKey: chosenKey,
      stageNumber,
      hp: maxEnemyHp,
      maxHp: maxEnemyHp,
      speed: data.speed * (0.44 + Math.min(0.18, (this.wave - 1) * 0.03)),
      damage: Math.max(5, Math.round(data.damage * 0.22 * (1 + (this.wave - 1) * 0.06))),
      lastFireTime: Date.now() + 1400,
      fireRate: Math.max(620, data.fireRate * 3.4 - (this.wave - 1) * 60),
      hitFlashTimer: 0,
      strafeSign: Math.random() < 0.5 ? 1 : -1,
      strafeTimer: 1.5,
      standeeBaseY: standeeH * 0.48,
    });
  }

  private checkPosInHouse(x: number, z: number): boolean {
    for (let i = 0; i < this.houses.length; i++) {
      const h = this.houses[i];
      if (Math.abs(x - h.x) < h.halfW && Math.abs(z - h.z) < h.halfD) {
        return true;
      }
    }
    return false;
  }

  private checkHitHouseWall(x: number, z: number): boolean {
    for (let i = 0; i < this.houses.length; i++) {
      const h = this.houses[i];
      const dx = Math.abs(x - h.x);
      const dz = Math.abs(z - h.z);
      if (dx < h.outerHalfW && dz < h.outerHalfD) {
        const isDoorway = dx < 1.3 && z > h.z + h.halfD - 0.8;
        if (!isDoorway) return true;
      }
    }
    return false;
  }

  private resolveSolidCollisions(pos: THREE.Vector3) {
    // Keep within arena bounds
    pos.x = THREE.MathUtils.clamp(pos.x, -64, 64);
    pos.z = THREE.MathUtils.clamp(pos.z, -64, 64);

    // Push out of obstacle pillars
    for (let i = 0; i < this.obstacles.length; i++) {
      const obs = this.obstacles[i];
      const dx = pos.x - obs.x;
      const dz = pos.z - obs.z;
      const dist = Math.hypot(dx, dz);
      const minDist = obs.radius + 0.55;
      if (dist < minDist && dist > 0.001) {
        const push = (minDist - dist) / dist;
        pos.x += dx * push;
        pos.z += dz * push;
      }
    }

    // Prevent clipping straight through house outer walls (doorway stays open)
    for (let i = 0; i < this.houses.length; i++) {
      const h = this.houses[i];
      const dx = pos.x - h.x;
      const dz = pos.z - h.z;
      const absX = Math.abs(dx);
      const absZ = Math.abs(dz);
      const padOuterW = h.outerHalfW + 0.35;
      const padOuterD = h.outerHalfD + 0.35;

      if (absX < padOuterW && absZ < padOuterD) {
        const inDoorLane = absX < 1.15 && dz > h.halfD - 0.9;
        const alreadyInside = absX < h.halfW - 0.15 && absZ < h.halfD - 0.15;
        if (!inDoorLane && !alreadyInside) {
          const penX = padOuterW - absX;
          const penZ = padOuterD - absZ;
          if (penX < penZ) {
            pos.x += dx >= 0 ? penX : -penX;
          } else {
            pos.z += dz >= 0 ? penZ : -penZ;
          }
        }
      }
    }
  }

  public startGame(initialChar?: CharacterKey) {
    if (initialChar) {
      this.currentCharKey = initialChar;
    }
    this.resetRunState();
    this.phase = 'playing';
    this.spawnEnemyAI();
    this.emitHUDState();
  }

  public restartGame() {
    this.resetRunState();
    this.phase = 'playing';
    this.spawnEnemyAI();
    this.emitHUDState();
  }

  public returnToTitle() {
    this.resetRunState();
    this.phase = 'title';
    if (document.pointerLockElement === this.renderer.domElement) {
      document.exitPointerLock?.();
    }
    this.emitHUDState();
  }

  private resetRunState() {
    const data = CHARACTER_DATA[this.currentCharKey];
    this.hp = data.maxHp;
    this.maxHp = data.maxHp;
    this.level = 1;
    this.exp = 0;
    this.nextExp = 100;
    this.kills = 0;
    this.wave = 1;
    this.shotsFired = 0;
    this.shotsHit = 0;
    this.elapsedSeconds = 0;
    this.currentSpawnIndex = 0;
    this.isHidden = false;
    this.playerPos.set(0, groundHeightAt(0, 4), 4);
    this.cameraYaw = 0;
    this.cameraPitch = 0.02;

    this.enemies.forEach((e) => this.scene.remove(e.group));
    this.enemies = [];
    this.bullets.forEach((b) => this.scene.remove(b.mesh));
    this.bullets = [];
    this.particles.forEach((p) => this.scene.remove(p.mesh));
    this.particles = [];
  }

  public setPaused(paused: boolean) {
    if (this.phase === 'playing' && paused) {
      this.phase = 'paused';
      if (document.pointerLockElement === this.renderer.domElement) {
        document.exitPointerLock?.();
      }
      this.emitHUDState();
    } else if (this.phase === 'paused' && !paused) {
      this.phase = 'playing';
      this.clock.getDelta();
      this.emitHUDState();
    }
  }

  public switchCharacter(charKey: CharacterKey) {
    if (this.phase === 'gameover') return;
    if (this.currentCharKey === charKey) return;

    const ratio = this.hp / this.maxHp;
    this.currentCharKey = charKey;
    const data = CHARACTER_DATA[charKey];
    this.maxHp = data.maxHp + (this.level - 1) * 20;
    this.hp = Math.max(10, Math.round(this.maxHp * ratio));
    soundEngine.playSwitch();
    this.spawnClayExplosion(this.playerPos, data.bulletColor, 10);
    this.emitHUDState();
  }

  public setSensitivity(val: number) {
    this.sensitivity = THREE.MathUtils.clamp(val, 0.4, 2.2);
  }

  public setJoystickInput(x: number, y: number) {
    this.joyInput.x = THREE.MathUtils.clamp(x, -1, 1);
    this.joyInput.y = THREE.MathUtils.clamp(y, -1, 1);
  }

  public applyLookDelta(dx: number, dy: number) {
    if (this.phase !== 'playing') return;
    this.cameraYaw -= dx * 0.0048 * this.sensitivity;
    this.cameraPitch = THREE.MathUtils.clamp(
      this.cameraPitch - dy * 0.004 * this.sensitivity,
      -0.55,
      0.62
    );
  }

  public togglePointerLock() {
    const canvas = this.renderer.domElement;
    if (document.pointerLockElement === canvas) {
      document.exitPointerLock?.();
    } else {
      try {
        const r: any = (canvas as any).requestPointerLock?.();
        if (r && typeof r.catch === 'function') r.catch(() => {});
      } catch {
        /* pointer lock unavailable (iframe/headless): drag-look still works */
      }
    }
  }

  public triggerPlayerFire() {
    if (this.phase !== 'playing') return;
    const now = Date.now();
    const data = CHARACTER_DATA[this.currentCharKey];
    if (now - this.lastFireTime < data.fireRate) return;
    this.lastFireTime = now;

    this.recoil = 1;
    this.muzzleFlash = 1;
    this.shotsFired += 3;
    soundEngine.playShoot(this.currentCharKey);

    _vForward.set(
      -Math.sin(this.cameraYaw) * Math.cos(this.cameraPitch),
      Math.sin(this.cameraPitch) * 0.4,
      -Math.cos(this.cameraYaw) * Math.cos(this.cameraPitch)
    ).normalize();

    const spreadAngles = [-0.16, 0, 0.16];
    for (let i = 0; i < spreadAngles.length; i++) {
      _vShotDir.copy(_vForward).applyAxisAngle(_vUp, spreadAngles[i]);
      this.fireProjectile(this.playerPos, _vShotDir, true, this.currentCharKey);
    }
  }

  private getBulletMaterial(colorHex: number): THREE.MeshStandardMaterial {
    let mat = this.bulletMatCache.get(colorHex);
    if (!mat) {
      mat = new THREE.MeshStandardMaterial({
        color: colorHex,
        emissive: colorHex,
        emissiveIntensity: 0.55,
        roughness: 0.25,
      });
      this.bulletMatCache.set(colorHex, mat);
    }
    return mat;
  }

  private getParticleMaterial(colorHex: number): THREE.MeshStandardMaterial {
    let mat = this.particleMatCache.get(colorHex);
    if (!mat) {
      mat = new THREE.MeshStandardMaterial({
        color: colorHex,
        roughness: 0.62,
        metalness: 0.08,
      });
      this.particleMatCache.set(colorHex, mat);
    }
    return mat;
  }

  private fireProjectile(
    origin: THREE.Vector3,
    dir: THREE.Vector3,
    isPlayer: boolean,
    charKey: CharacterKey
  ) {
    const data = CHARACTER_DATA[charKey];
    const mat = this.getBulletMaterial(isPlayer ? data.bulletColor : 0xef4444);
    const mesh = new THREE.Mesh(
      isPlayer ? this.playerBulletGeo : this.enemyBulletGeo,
      mat
    );
    mesh.position.set(
      origin.x + dir.x * 0.9,
      origin.y + 1.05 + dir.y * 0.5,
      origin.z + dir.z * 0.9
    );
    mesh.castShadow = true;
    this.scene.add(mesh);

    const speed = isPlayer ? data.bulletSpeed : data.bulletSpeed * 0.65;
    const dmg = isPlayer
      ? Math.round(data.damage * (1 + (this.level - 1) * 0.15))
      : Math.max(5, Math.round(data.damage * 0.22));

    this.bullets.push({
      mesh,
      velocity: dir.clone().multiplyScalar(speed),
      isPlayer,
      damage: dmg,
      life: 95,
    });
  }

  private spawnClayExplosion(pos: THREE.Vector3, colorHex: number, count = 10) {
    const mat = this.getParticleMaterial(colorHex);
    for (let i = 0; i < count; i++) {
      const p = new THREE.Mesh(this.particleGeo, mat);
      p.position.set(pos.x, pos.y + 0.9, pos.z);
      this.scene.add(p);
      this.particles.push({
        mesh: p,
        velocity: new THREE.Vector3(
          (Math.random() - 0.5) * 0.44,
          Math.random() * 0.34 + 0.1,
          (Math.random() - 0.5) * 0.44
        ),
        life: 28 + Math.random() * 14,
      });
    }
  }

  private gainExp(amount: number) {
    this.exp += amount;
    if (this.exp >= this.nextExp) {
      this.exp -= this.nextExp;
      this.level++;
      this.nextExp = Math.round(this.nextExp * 1.25);
      this.maxHp += 20;
      this.hp = this.maxHp;
      this.levelUpToast = 1;
      soundEngine.playLevelUp();
      this.spawnClayExplosion(this.playerPos, 0xfacc15, 16);
    }
  }

  private emitDamagePopup(worldPos: THREE.Vector3, amount: number, isCrit: boolean) {
    _vProj.copy(worldPos);
    _vProj.y += 2.1;
    _vProj.project(this.camera);
    if (_vProj.z > 1) return;

    const w = this.container.clientWidth || window.innerWidth;
    const h = this.container.clientHeight || window.innerHeight;
    const x = (_vProj.x * 0.5 + 0.5) * w;
    const y = (-_vProj.y * 0.5 + 0.5) * h;

    this.callbacks.onDamagePopup({
      id: this.popupCounter++,
      x,
      y,
      amount,
      isCrit,
    });
  }

  private emitHUDState() {
    const active = this.enemies[0];
    const radarHouses: RadarHouse[] = this.houses.map((h) => ({
      id: h.id,
      x: h.x,
      z: h.z,
      color: h.color,
    }));

    this.callbacks.onHudUpdate({
      phase: this.phase,
      charKey: this.currentCharKey,
      hp: Math.max(0, Math.ceil(this.hp)),
      maxHp: this.maxHp,
      level: this.level,
      exp: this.exp,
      nextExp: this.nextExp,
      kills: this.kills,
      wave: this.wave,
      shotsFired: this.shotsFired,
      shotsHit: this.shotsHit,
      elapsedSeconds: Math.floor(this.elapsedSeconds),
      isHidden: this.isHidden,
      playerX: this.playerPos.x,
      playerZ: this.playerPos.z,
      playerYaw: this.cameraYaw,
      houses: radarHouses,
      activeEnemy: active
        ? {
            x: active.group.position.x,
            z: active.group.position.z,
            charKey: active.charKey,
            hp: Math.max(0, Math.ceil(active.hp)),
            maxHp: active.maxHp,
            stageNumber: active.stageNumber,
          }
        : null,
      hitMarkerAlpha: this.hitMarkerAlpha,
      damageFlashAlpha: this.damageFlashAlpha,
      levelUpToast: this.levelUpToast,
    });
  }

  private startLoop() {
    const tick = () => {
      if (this.disposed) return;

      const dt = Math.min(this.clock.getDelta(), 0.05);
      const step = dt * 60; // Normalized to 60fps
      this.update(dt, step);
      this.renderer.render(this.scene, this.camera);

      if (this.isSoftwareGl) {
        this.afterDraw(tick);
      } else {
        this.frameId = requestAnimationFrame(tick);
      }
    };

    if (this.isSoftwareGl) {
      this.afterDraw(tick);
    } else {
      this.frameId = requestAnimationFrame(tick);
    }
  }

  private afterDraw(cb: () => void) {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    if (!gl || typeof gl.fenceSync !== 'function') {
      this.frameId = window.setTimeout(cb, 80);
      return;
    }
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      if (this.disposed) return;
      const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
      if (state === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 80);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }

  private update(dt: number, step: number) {
    const elapsed = this.clock.elapsedTime;

    // Snowfall animation
    if (this.snowSystem) {
      const positions = this.snowSystem.geometry.attributes.position.array as Float32Array;
      for (let i = 0; i < positions.length; i += 3) {
        positions[i + 1] -= 0.08 * step;
        positions[i] += Math.sin(elapsed + i) * 0.015 * step;
        if (positions[i + 1] < 0) {
          positions[i + 1] = 34;
        }
      }
      this.snowSystem.geometry.attributes.position.needsUpdate = true;
    }

    // Title screen orbital preview camera
    if (this.phase === 'title') {
      const orbitAngle = elapsed * 0.16;
      this.camera.position.set(
        Math.cos(orbitAngle) * 32,
        14,
        Math.sin(orbitAngle) * 32
      );
      this.camera.lookAt(0, 2, 0);
      return;
    }

    if (this.phase !== 'playing') return;

    this.elapsedSeconds += dt;
    const now = Date.now();
    const charStats = CHARACTER_DATA[this.currentCharKey];

    // Respawn next enemy if arena is clear
    if (this.enemies.length === 0) {
      this.spawnEnemyAI();
    }

    // 1. Player Movement
    let moveForward = 0;
    let moveRight = 0;
    if (this.keys['KeyW'] || this.keys['ArrowUp']) moveForward += 1;
    if (this.keys['KeyS'] || this.keys['ArrowDown']) moveForward -= 1;
    if (this.keys['KeyD'] || this.keys['ArrowRight']) moveRight += 1;
    if (this.keys['KeyA'] || this.keys['ArrowLeft']) moveRight -= 1;

    moveForward -= this.joyInput.y;
    moveRight += this.joyInput.x;

    const isMoving = Math.abs(moveForward) > 0.04 || Math.abs(moveRight) > 0.04;
    if (isMoving) {
      _vForward.set(-Math.sin(this.cameraYaw), 0, -Math.cos(this.cameraYaw));
      _vRight.set(Math.cos(this.cameraYaw), 0, -Math.sin(this.cameraYaw));
      _vMove
        .set(0, 0, 0)
        .addScaledVector(_vForward, moveForward)
        .addScaledVector(_vRight, moveRight)
        .normalize();

      this.playerPos.addScaledVector(_vMove, charStats.speed * step);
      this.resolveSolidCollisions(this.playerPos);
      this.playerPos.y = groundHeightAt(this.playerPos.x, this.playerPos.z);

      this.bobPhase += dt * 11;
      this.bobIntensity = THREE.MathUtils.damp(this.bobIntensity, 1, 10, dt);
    } else {
      this.bobIntensity = THREE.MathUtils.damp(this.bobIntensity, 0, 10, dt);
    }

    // Check stealth inside the 3 hideout houses
    const nextHidden = this.checkPosInHouse(this.playerPos.x, this.playerPos.z);
    if (nextHidden !== this.isHidden) {
      this.isHidden = nextHidden;
      soundEngine.playStealth(nextHidden);
      this.emitHUDState();
    }

    // Update 1st-person camera with smooth head-bobbing
    const headBobY = Math.abs(Math.sin(this.bobPhase)) * 0.08 * this.bobIntensity;
    this.camera.position.set(
      this.playerPos.x,
      this.playerPos.y + 1.35 + headBobY,
      this.playerPos.z
    );
    _vLookDir.set(
      -Math.sin(this.cameraYaw) * Math.cos(this.cameraPitch),
      Math.sin(this.cameraPitch),
      -Math.cos(this.cameraYaw) * Math.cos(this.cameraPitch)
    );
    this.camera.lookAt(
      this.camera.position.x + _vLookDir.x * 12,
      this.camera.position.y + _vLookDir.y * 12,
      this.camera.position.z + _vLookDir.z * 12
    );

    // 2. Weapon viewmodel recoil & bobbing update
    this.recoil = THREE.MathUtils.damp(this.recoil, 0, 16, dt);
    this.muzzleFlash = THREE.MathUtils.damp(this.muzzleFlash, 0, 24, dt);
    this.hitMarkerAlpha = THREE.MathUtils.damp(this.hitMarkerAlpha, 0, 10, dt);
    this.damageFlashAlpha = THREE.MathUtils.damp(this.damageFlashAlpha, 0, 7, dt);
    this.levelUpToast = THREE.MathUtils.damp(this.levelUpToast, 0, 1.2, dt);

    this.callbacks.onWeaponUpdate({
      recoil: this.recoil,
      bobX: Math.cos(this.bobPhase * 0.5) * 10 * this.bobIntensity,
      bobY: Math.abs(Math.sin(this.bobPhase)) * 9 * this.bobIntensity,
      muzzleFlash: this.muzzleFlash,
    });

    // 3. Enemy AI Update
    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const enemy = this.enemies[i];
      enemy.hpBarGroup.lookAt(this.camera.position);

      // Standee billboard faces camera horizontally
      const dxCam = this.camera.position.x - enemy.group.position.x;
      const dzCam = this.camera.position.z - enemy.group.position.z;
      enemy.standee.rotation.y = Math.atan2(dxCam, dzCam);

      // Hit flash decay
      if (enemy.hitFlashTimer > 0) {
        enemy.hitFlashTimer = Math.max(0, enemy.hitFlashTimer - dt);
        enemy.standeeMat.emissive.setHex(0xffffff);
        enemy.standeeMat.emissiveIntensity = enemy.hitFlashTimer * 3.5;
      } else {
        enemy.standeeMat.emissiveIntensity = 0;
      }

      // If player is hidden inside a house, enemy patrols/looks around
      if (this.isHidden) {
        enemy.standee.rotation.z = Math.sin(elapsed * 2) * 0.04;
        enemy.standee.position.y = enemy.standeeBaseY;
        continue;
      }

      _vToPlayer.subVectors(this.playerPos, enemy.group.position);
      _vToPlayer.y = 0;
      const dist = _vToPlayer.length();
      if (dist > 0.001) _vToPlayer.divideScalar(dist);

      enemy.strafeTimer -= dt;
      if (enemy.strafeTimer <= 0) {
        enemy.strafeSign *= -1;
        enemy.strafeTimer = 1.6 + Math.random() * 1.4;
      }

      // Move toward player or strafe at medium range
      if (dist > 11.5) {
        _vMove.copy(_vToPlayer).multiplyScalar(enemy.speed * step);
        const nx = enemy.group.position.x + _vMove.x;
        const nz = enemy.group.position.z + _vMove.z;
        if (!this.checkPosInHouse(nx, nz)) {
          enemy.group.position.x = THREE.MathUtils.clamp(nx, -62, 62);
          enemy.group.position.z = THREE.MathUtils.clamp(nz, -62, 62);
        }
        const walkBob = Math.abs(Math.sin(elapsed * 9 + i)) * 0.14;
        enemy.standee.position.y = enemy.standeeBaseY + walkBob;
        enemy.standee.rotation.z = Math.sin(elapsed * 9 + i) * 0.06;
      } else {
        // Light strafing at combat range
        _vRight.set(-_vToPlayer.z, 0, _vToPlayer.x);
        const nx = enemy.group.position.x + _vRight.x * enemy.speed * 0.55 * enemy.strafeSign * step;
        const nz = enemy.group.position.z + _vRight.z * enemy.speed * 0.55 * enemy.strafeSign * step;
        if (!this.checkPosInHouse(nx, nz) && !this.checkHitHouseWall(nx, nz)) {
          enemy.group.position.x = THREE.MathUtils.clamp(nx, -62, 62);
          enemy.group.position.z = THREE.MathUtils.clamp(nz, -62, 62);
        }
        enemy.standee.position.y = enemy.standeeBaseY + Math.abs(Math.sin(elapsed * 6)) * 0.06;
        enemy.standee.rotation.z = 0;
      }
      enemy.group.position.y = groundHeightAt(enemy.group.position.x, enemy.group.position.z);

      // Enemy firing
      if (dist < 34 && now - enemy.lastFireTime > enemy.fireRate) {
        enemy.lastFireTime = now;
        this.fireProjectile(enemy.group.position, _vToPlayer, false, enemy.charKey);
      }
    }

    // 4. Bullets & Collisions
    for (let i = this.bullets.length - 1; i >= 0; i--) {
      const b = this.bullets[i];
      b.mesh.position.addScaledVector(b.velocity, step);
      b.life -= step;

      let hit = false;

      // Hit house wall
      if (this.checkHitHouseWall(b.mesh.position.x, b.mesh.position.z)) {
        hit = true;
        this.spawnClayExplosion(b.mesh.position, 0xffffff, 4);
      }

      // Hit ground
      if (!hit && b.mesh.position.y < groundHeightAt(b.mesh.position.x, b.mesh.position.z) + 0.1) {
        hit = true;
        this.spawnClayExplosion(b.mesh.position, 0xe0f2fe, 4);
      }

      // Hit obstacle
      if (!hit) {
        for (let k = 0; k < this.obstacles.length; k++) {
          const obs = this.obstacles[k];
          if (
            Math.hypot(b.mesh.position.x - obs.x, b.mesh.position.z - obs.z) < obs.radius &&
            b.mesh.position.y < groundHeightAt(obs.x, obs.z) + 2.0
          ) {
            hit = true;
            this.spawnClayExplosion(b.mesh.position, 0x7dd3fc, 5);
            break;
          }
        }
      }

      if (!hit && b.isPlayer) {
        for (let j = this.enemies.length - 1; j >= 0; j--) {
          const enemy = this.enemies[j];
          const dx = b.mesh.position.x - enemy.group.position.x;
          const dz = b.mesh.position.z - enemy.group.position.z;
          if (Math.hypot(dx, dz) < 1.35 && b.mesh.position.y < enemy.group.position.y + 3.0) {
            hit = true;
            this.shotsHit++;
            this.hitMarkerAlpha = 1;
            enemy.hp -= b.damage;
            enemy.hitFlashTimer = 0.16;
            soundEngine.playHit(this.currentCharKey === 'loopy');
            this.emitDamagePopup(enemy.group.position, b.damage, this.currentCharKey === 'loopy');
            this.spawnClayExplosion(b.mesh.position, CHARACTER_DATA[this.currentCharKey].bulletColor, 6);

            const ratio = Math.max(0.01, enemy.hp / enemy.maxHp);
            enemy.hpFgMesh.scale.x = ratio;

            if (enemy.hp <= 0) {
              soundEngine.playKill();
              this.spawnClayExplosion(enemy.group.position, 0xfacc15, 18);
              this.scene.remove(enemy.group);
              this.enemies.splice(j, 1);

              this.kills++;
              if (this.kills % 3 === 0) {
                this.wave++;
              }
              this.hp = Math.min(this.maxHp, this.hp + 15);
              this.gainExp(45);
              this.emitHUDState();
            }
            break;
          }
        }
      } else if (!hit && !b.isPlayer && !this.isHidden) {
        const dx = b.mesh.position.x - this.playerPos.x;
        const dz = b.mesh.position.z - this.playerPos.z;
        if (Math.hypot(dx, dz) < 0.95) {
          hit = true;
          this.hp -= b.damage;
          this.damageFlashAlpha = 1;
          soundEngine.playDamage();
          this.spawnClayExplosion(this.playerPos, 0xef4444, 6);

          if (this.hp <= 0) {
            this.hp = 0;
            this.phase = 'gameover';
            if (document.pointerLockElement === this.renderer.domElement) {
              document.exitPointerLock?.();
            }
          }
          this.emitHUDState();
        }
      }

      if (hit || b.life <= 0) {
        this.scene.remove(b.mesh);
        this.bullets.splice(i, 1);
      }
    }

    // 5. Particles
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.mesh.position.addScaledVector(p.velocity, step);
      p.velocity.y -= 0.018 * step;
      p.mesh.rotation.x += 0.12 * step;
      p.mesh.rotation.y += 0.12 * step;
      p.life -= step;
      if (p.life <= 0) {
        this.scene.remove(p.mesh);
        this.particles.splice(i, 1);
      }
    }

    // Throttled HUD sync (~12Hz) so React radar/timer/enemy HP stay crisp without thrashing
    this.hudEmitAccum += dt;
    if (this.hudEmitAccum >= 0.08) {
      this.hudEmitAccum = 0;
      this.emitHUDState();
    }
  }

  private onKeyDown = (e: KeyboardEvent) => {
    this.keys[e.code] = true;
    if (this.phase === 'playing') {
      if (e.code === 'Space') {
        e.preventDefault();
        this.triggerPlayerFire();
      } else if (e.code === 'Digit1') {
        this.switchCharacter('pororo');
      } else if (e.code === 'Digit2') {
        this.switchCharacter('petty');
      } else if (e.code === 'Digit3') {
        this.switchCharacter('loopy');
      } else if (e.code === 'Digit4') {
        this.switchCharacter('poby');
      } else if (e.code === 'KeyP') {
        this.setPaused(true);
      }
    } else if (this.phase === 'paused' && (e.code === 'KeyP' || e.code === 'Escape')) {
      this.setPaused(false);
    }
  };

  private onKeyUp = (e: KeyboardEvent) => {
    this.keys[e.code] = false;
  };

  private onPointerDown = (e: PointerEvent) => {
    if (this.phase !== 'playing') return;
    if (e.pointerType === 'mouse' && e.button !== 0) return;

    this.isPointerDown = true;
    this.dragMovedDist = 0;
    this.prevPointerX = e.clientX;
    this.prevPointerY = e.clientY;
  };

  private onPointerMove = (e: PointerEvent) => {
    if (this.phase !== 'playing') return;

    if (document.pointerLockElement === this.renderer.domElement) {
      this.applyLookDelta(e.movementX, e.movementY);
      return;
    }

    if (!this.isPointerDown) return;
    const dx = e.clientX - this.prevPointerX;
    const dy = e.clientY - this.prevPointerY;
    this.dragMovedDist += Math.hypot(dx, dy);
    this.applyLookDelta(dx, dy);
    this.prevPointerX = e.clientX;
    this.prevPointerY = e.clientY;
  };

  private onPointerUp = (e: PointerEvent) => {
    if (this.phase !== 'playing') return;
    if (document.pointerLockElement === this.renderer.domElement) {
      if (e.button === 0) this.triggerPlayerFire();
      return;
    }
    if (this.isPointerDown && this.dragMovedDist < 6) {
      this.triggerPlayerFire();
    }
    this.isPointerDown = false;
  };

  private onResize = () => {
    if (this.disposed) return;
    const width = this.container.clientWidth || window.innerWidth;
    const height = this.container.clientHeight || window.innerHeight;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(
      this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio || 1, 2)
    );
  };

  private onContextLost = (e: Event) => {
    e.preventDefault();
    this.callbacks.onContextLost(true);
  };

  private onContextRestored = () => {
    this.callbacks.onContextLost(false);
  };

  private bindEvents() {
    const canvas = this.renderer.domElement;
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('resize', this.onResize);
    canvas.addEventListener('pointerdown', this.onPointerDown);
    window.addEventListener('pointermove', this.onPointerMove);
    window.addEventListener('pointerup', this.onPointerUp);
    canvas.addEventListener('webglcontextlost', this.onContextLost);
    canvas.addEventListener('webglcontextrestored', this.onContextRestored);
  }

  public dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.frameId);
    clearTimeout(this.frameId);

    const canvas = this.renderer.domElement;
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('resize', this.onResize);
    canvas.removeEventListener('pointerdown', this.onPointerDown);
    window.removeEventListener('pointermove', this.onPointerMove);
    window.removeEventListener('pointerup', this.onPointerUp);
    canvas.removeEventListener('webglcontextlost', this.onContextLost);
    canvas.removeEventListener('webglcontextrestored', this.onContextRestored);

    this.scene.traverse((obj) => {
      const mesh = obj as THREE.Mesh;
      if (mesh.geometry) mesh.geometry.dispose();
      if (mesh.material) {
        if (Array.isArray(mesh.material)) {
          mesh.material.forEach((m) => m.dispose());
        } else {
          mesh.material.dispose();
        }
      }
    });

    this.shadowTex.dispose();
    this.playerBulletGeo.dispose();
    this.enemyBulletGeo.dispose();
    this.particleGeo.dispose();
    this.bulletMatCache.forEach((m) => m.dispose());
    this.bulletMatCache.clear();
    this.particleMatCache.forEach((m) => m.dispose());
    this.particleMatCache.clear();
    this.renderer.dispose();

    if (canvas.parentElement === this.container) {
      this.container.removeChild(canvas);
    }
  }
}
