export type CharacterKey = 'pororo' | 'petty' | 'loopy' | 'poby';

export type GamePhase = 'title' | 'playing' | 'paused' | 'gameover';

export interface CharacterStats {
  key: CharacterKey;
  name: string;
  role: string;
  weaponName: string;
  maxHp: number;
  speed: number;
  damage: number;
  fireRate: number;
  bulletSpeed: number;
  bulletColor: number;
  accentHex: string;
  badgeBgClass: string;
  scale: number;
}

export const CHARACTER_KEYS: CharacterKey[] = ['pororo', 'petty', 'loopy', 'poby'];

export const ENEMY_SPAWN_SEQUENCE: CharacterKey[] = ['poby', 'petty', 'loopy'];

export const CHARACTER_DATA: Record<CharacterKey, CharacterStats> = {
  pororo: {
    key: 'pororo',
    name: '뽀로롱',
    role: '밸런스형 돌격대장',
    weaponName: '스카이 프로스트 블래스터',
    maxHp: 120,
    speed: 0.22,
    damage: 32,
    fireRate: 260,
    bulletSpeed: 1.35,
    bulletColor: 0x38bdf8,
    accentHex: '#0ea5e9',
    badgeBgClass: 'bg-sky-600',
    scale: 1.0,
  },
  petty: {
    key: 'petty',
    name: '패피',
    role: '초고속 연사 스나이퍼',
    weaponName: '바이올렛 래피드 라이플',
    maxHp: 105,
    speed: 0.26,
    damage: 25,
    fireRate: 180,
    bulletSpeed: 1.65,
    bulletColor: 0xc084fc,
    accentHex: '#9333ea',
    badgeBgClass: 'bg-purple-600',
    scale: 0.98,
  },
  loopy: {
    key: 'loopy',
    name: '루삐',
    role: '고화력 폭발 포격수',
    weaponName: '로즈 버스트 캐논',
    maxHp: 115,
    speed: 0.2,
    damage: 48,
    fireRate: 440,
    bulletSpeed: 1.2,
    bulletColor: 0xf472b6,
    accentHex: '#db2777',
    badgeBgClass: 'bg-pink-600',
    scale: 0.96,
  },
  poby: {
    key: 'poby',
    name: '포보',
    role: '강철 체력 헤비 탱커',
    weaponName: '골든 헤비 런처',
    maxHp: 190,
    speed: 0.17,
    damage: 38,
    fireRate: 340,
    bulletSpeed: 1.25,
    bulletColor: 0xfacc15,
    accentHex: '#d97706',
    badgeBgClass: 'bg-amber-600',
    scale: 1.15,
  },
};

export interface RadarHouse {
  id: string;
  x: number;
  z: number;
  color: string;
}

export interface RadarEnemy {
  x: number;
  z: number;
  charKey: CharacterKey;
  hp: number;
  maxHp: number;
  stageNumber: number;
}

export interface DamagePopup {
  id: number;
  x: number;
  y: number;
  amount: number;
  isCrit: boolean;
}

export interface WeaponViewState {
  recoil: number; // 0 to 1
  bobX: number;
  bobY: number;
  muzzleFlash: number; // 0 to 1
}

export interface GameHUDState {
  phase: GamePhase;
  charKey: CharacterKey;
  hp: number;
  maxHp: number;
  level: number;
  exp: number;
  nextExp: number;
  kills: number;
  wave: number;
  shotsFired: number;
  shotsHit: number;
  elapsedSeconds: number;
  isHidden: boolean;
  playerX: number;
  playerZ: number;
  playerYaw: number;
  houses: RadarHouse[];
  activeEnemy: RadarEnemy | null;
  hitMarkerAlpha: number;
  damageFlashAlpha: number;
  levelUpToast: number;
}
