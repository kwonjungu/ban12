import * as THREE from 'three';
import type { CharacterKey } from './types';

import heroPenguinAviatorSrc from '../assets/images/hero_penguin_aviator_1794636386961.jpg';
import heroPenguinSniperSrc from '../assets/images/hero_penguin_sniper_1794636388205.jpg';
import heroBeaverBomberSrc from '../assets/images/hero_beaver_bomber_1794636388687.jpg';
import heroPolarTankSrc from '../assets/images/hero_polar_tank_1794636389959.jpg';
import fpSnowBlasterSrc from '../assets/images/fp_snow_blaster_1794636389858.jpg';
import arcticSkyPanoramaSrc from '../assets/images/arctic_sky_panorama_1794636390655.jpg';
import texArcticSnowSrc from '../assets/images/tex_arctic_snow_1794636390930.jpg';
import texClayCabinSrc from '../assets/images/tex_clay_cabin_1794636391355.jpg';
import texIceCrystalSrc from '../assets/images/tex_ice_crystal_1794636392106.jpg';

export interface CharacterAssetBundle {
  dataUrl: string;
  texture: THREE.Texture;
}

export interface ProcessedGameAssets {
  characters: Record<CharacterKey, CharacterAssetBundle>;
  weaponDataUrl: string;
  skyPanoramaUrl: string;
  skyTexture: THREE.Texture;
  snowTexture: THREE.Texture;
  cabinTexture: THREE.Texture;
  iceTexture: THREE.Texture;
}

const CHARACTER_RAW_SOURCES: Record<CharacterKey, string> = {
  pororo: heroPenguinAviatorSrc,
  petty: heroPenguinSniperSrc,
  loopy: heroBeaverBomberSrc,
  poby: heroPolarTankSrc,
};

function loadHtmlImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error(`Failed to load asset: ${src}`));
    img.src = src;
  });
}

/**
 * Removes uniform #00FF00 chroma-key studio background from generated clay artwork
 * with smooth alpha edge feathering and green-despill so white/pastel edges stay crisp.
 */
function createChromaKeyCutout(img: HTMLImageElement): { canvas: HTMLCanvasElement; dataUrl: string } {
  const canvas = document.createElement('canvas');
  canvas.width = img.naturalWidth || img.width;
  canvas.height = img.naturalHeight || img.height;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  if (!ctx) {
    return { canvas, dataUrl: img.src };
  }

  ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
  const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const data = imageData.data;

  const lowThresh = 26;
  const highThresh = 74;

  for (let i = 0; i < data.length; i += 4) {
    const r = data[i];
    const g = data[i + 1];
    const b = data[i + 2];

    const maxRB = Math.max(r, b);
    const gExcess = g - maxRB;

    if (gExcess >= highThresh) {
      data[i + 3] = 0;
    } else if (gExcess > lowThresh) {
      const t = (gExcess - lowThresh) / (highThresh - lowThresh);
      data[i + 3] = Math.round(255 * (1 - t));
      // Green despill on semi-transparent fringe pixels
      data[i + 1] = Math.min(g, maxRB + 6);
    } else if (gExcess > 10) {
      // Subtle despill on immediate border pixels
      data[i + 1] = Math.min(g, maxRB + 10);
    }
  }

  ctx.putImageData(imageData, 0, 0);
  return {
    canvas,
    dataUrl: canvas.toDataURL('image/png'),
  };
}

function createTiledTexture(
  img: HTMLImageElement,
  repeatX: number,
  repeatY: number,
  maxAnisotropy: number
): THREE.Texture {
  const tex = new THREE.Texture(img);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(repeatX, repeatY);
  tex.anisotropy = Math.min(8, maxAnisotropy);
  tex.needsUpdate = true;
  return tex;
}

function createSkyTexture(img: HTMLImageElement): THREE.Texture {
  const tex = new THREE.Texture(img);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.ClampToEdgeWrapping;
  tex.needsUpdate = true;
  return tex;
}

let cachedAssetsPromise: Promise<ProcessedGameAssets> | null = null;

export function preloadAllGameAssets(maxAnisotropy = 4): Promise<ProcessedGameAssets> {
  if (cachedAssetsPromise) return cachedAssetsPromise;

  cachedAssetsPromise = (async () => {
    const [
      pororoImg,
      pettyImg,
      loopyImg,
      pobyImg,
      blasterImg,
      skyImg,
      snowImg,
      cabinImg,
      iceImg,
    ] = await Promise.all([
      loadHtmlImage(CHARACTER_RAW_SOURCES.pororo),
      loadHtmlImage(CHARACTER_RAW_SOURCES.petty),
      loadHtmlImage(CHARACTER_RAW_SOURCES.loopy),
      loadHtmlImage(CHARACTER_RAW_SOURCES.poby),
      loadHtmlImage(fpSnowBlasterSrc),
      loadHtmlImage(arcticSkyPanoramaSrc),
      loadHtmlImage(texArcticSnowSrc),
      loadHtmlImage(texClayCabinSrc),
      loadHtmlImage(texIceCrystalSrc),
    ]);

    const buildCharBundle = (img: HTMLImageElement): CharacterAssetBundle => {
      const { canvas, dataUrl } = createChromaKeyCutout(img);
      const texture = new THREE.CanvasTexture(canvas);
      texture.colorSpace = THREE.SRGBColorSpace;
      texture.anisotropy = Math.min(8, maxAnisotropy);
      texture.needsUpdate = true;
      return { dataUrl, texture };
    };

    const blasterCutout = createChromaKeyCutout(blasterImg);

    return {
      characters: {
        pororo: buildCharBundle(pororoImg),
        petty: buildCharBundle(pettyImg),
        loopy: buildCharBundle(loopyImg),
        poby: buildCharBundle(pobyImg),
      },
      weaponDataUrl: blasterCutout.dataUrl,
      skyPanoramaUrl: arcticSkyPanoramaSrc,
      skyTexture: createSkyTexture(skyImg),
      snowTexture: createTiledTexture(snowImg, 22, 22, maxAnisotropy),
      cabinTexture: createTiledTexture(cabinImg, 2, 1, maxAnisotropy),
      iceTexture: createTiledTexture(iceImg, 2, 2, maxAnisotropy),
    };
  })();

  return cachedAssetsPromise;
}

export const RAW_PREVIEW_URLS = {
  skyPanorama: arcticSkyPanoramaSrc,
  characters: CHARACTER_RAW_SOURCES,
};
