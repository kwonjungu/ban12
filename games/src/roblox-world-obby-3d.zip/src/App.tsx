import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GameStats, PlayerCustomization } from './types';
import { TOTAL_STAGES, STAGES } from './game/stages';
import { GameCanvas } from './game/GameCanvas';
import { TopBar } from './components/TopBar';
import { StageModal } from './components/StageModal';
import { AvatarModal } from './components/AvatarModal';
import { ControlsModal } from './components/ControlsModal';
import { ResetConfirmModal } from './components/ResetConfirmModal';
import { VictoryModal } from './components/VictoryModal';
import { LeaderboardModal } from './components/LeaderboardModal';
import { MobileControls } from './components/MobileControls';
import { soundFX } from './game/audio';

const STORAGE_KEY = 'roblox_obby_3d_v5';

const DEFAULT_CUSTOMIZATION: PlayerCustomization = {
  shirtColor: '#1e1e24',
  pantsColor: '#1e293b',
  skinColor: '#f5e0c3',
  hat: 'bacon',
  face: 'smile',
};

const DEFAULT_STATS: GameStats = {
  currentStageIndex: 0,
  maxUnlockedStage: 0,
  starsCollectedCount: 0,
  deathCount: 0,
  collectedStarIds: [],
  startTime: Date.now(),
  isGameCompleted: false,
  rebirthCount: 0,
};

export default function App() {
  // Load saved state from LocalStorage
  const [stats, setStats] = useState<GameStats>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        return {
          currentStageIndex: parsed.currentStageIndex ?? 0,
          maxUnlockedStage: parsed.maxUnlockedStage ?? 0,
          starsCollectedCount: parsed.starsCollectedCount ?? 0,
          deathCount: parsed.deathCount ?? 0,
          collectedStarIds: parsed.collectedStarIds ?? [],
          startTime: parsed.startTime ?? Date.now(),
          isGameCompleted: parsed.isGameCompleted ?? false,
          rebirthCount: parsed.rebirthCount ?? 0,
        };
      }
    } catch (e) {
      console.error('Failed to load save:', e);
    }
    return DEFAULT_STATS;
  });

  const [customization, setCustomization] = useState<PlayerCustomization>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_avatar`);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to load avatar:', e);
    }
    return DEFAULT_CUSTOMIZATION;
  });

  const [isMuted, setIsMuted] = useState(false);
  const [practiceMode, setPracticeMode] = useState(false);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);

  // Modals state
  const [isStageModalOpen, setIsStageModalOpen] = useState(false);
  const [isAvatarModalOpen, setIsAvatarModalOpen] = useState(false);
  const [isControlsModalOpen, setIsControlsModalOpen] = useState(false);
  const [isResetConfirmOpen, setIsResetConfirmOpen] = useState(false);
  const [isVictoryModalOpen, setIsVictoryModalOpen] = useState(false);
  const [isLeaderboardOpen, setIsLeaderboardOpen] = useState(false);
  const [showCenterGuide, setShowCenterGuide] = useState(true);
  const [showRebirthNotice, setShowRebirthNotice] = useState(true);

  // Mobile controller state & refs
  const mobileDirRef = useRef<{ x: number; z: number }>({ x: 0, z: 0 });
  const isMobileSprintingRef = useRef<boolean>(false);
  const [isMobileSprinting, setIsMobileSprinting] = useState(false);

  // Action callback refs for GameCanvas
  const jumpTriggerRef = useRef<(() => void) | null>(null);
  const warpTriggerRef = useRef<((stageIdx: number) => void) | null>(null);
  const respawnTriggerRef = useRef<(() => void) | null>(null);

  // Save to LocalStorage whenever stats change
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(stats));
    } catch (e) {
      console.error('Failed to save progress:', e);
    }
  }, [stats]);

  // Save customization changes
  const handleSaveAvatar = useCallback((newCust: PlayerCustomization) => {
    setCustomization(newCust);
    try {
      localStorage.setItem(`${STORAGE_KEY}_avatar`, JSON.stringify(newCust));
    } catch (e) {
      console.error('Failed to save avatar:', e);
    }
  }, []);

  // Timer loop
  useEffect(() => {
    const timer = setInterval(() => {
      setElapsedSeconds(Math.floor((Date.now() - stats.startTime) / 1000));
    }, 1000);
    return () => clearInterval(timer);
  }, [stats.startTime]);

  // Audio mute toggle
  const handleToggleMute = useCallback(() => {
    const newMuted = !isMuted;
    setIsMuted(newMuted);
    soundFX.setMuted(newMuted);
  }, [isMuted]);

  // Practice mode toggle
  const handleTogglePractice = useCallback(() => {
    setPracticeMode((prev) => !prev);
  }, []);

  // Quick navigation through unlocked stages
  const handlePrevStage = useCallback(() => {
    if (stats.currentStageIndex > 0) {
      const prevIdx = stats.currentStageIndex - 1;
      warpTriggerRef.current?.(prevIdx);
    }
  }, [stats.currentStageIndex]);

  const handleNextStage = useCallback(() => {
    if (stats.currentStageIndex < stats.maxUnlockedStage) {
      const nextIdx = stats.currentStageIndex + 1;
      warpTriggerRef.current?.(nextIdx);
    }
  }, [stats.currentStageIndex, stats.maxUnlockedStage]);

  // Warp from stage modal
  const handleSelectStage = useCallback((stageIndex: number) => {
    warpTriggerRef.current?.(stageIndex);
  }, []);

  // Reset entire progress
  const handleConfirmReset = useCallback(() => {
    localStorage.removeItem(STORAGE_KEY);
    const newStats: GameStats = {
      ...DEFAULT_STATS,
      startTime: Date.now(),
    };
    setStats(newStats);
    warpTriggerRef.current?.(0);
    setIsResetConfirmOpen(false);
  }, []);

  // Stage 100 reached
  const handleStage100Reached = useCallback(() => {
    setStats((prev) => ({ ...prev, isGameCompleted: true }));
    setIsVictoryModalOpen(true);
  }, []);

  // Handle Rebirth (+1 Rebirth, resets stage progress to 0 but increases rebirth count)
  const handleRebirth = useCallback(() => {
    soundFX.playFanfare();
    setStats((prev) => ({
      ...prev,
      currentStageIndex: 0,
      maxUnlockedStage: 0,
      collectedStarIds: [],
      starsCollectedCount: 0,
      startTime: Date.now(),
      isGameCompleted: false,
      rebirthCount: (prev.rebirthCount ?? 0) + 1,
    }));
    warpTriggerRef.current?.(0);
    setIsVictoryModalOpen(false);
    setIsLeaderboardOpen(true);
  }, []);

  return (
    <div className="relative w-screen h-screen overflow-hidden select-none bg-slate-950 font-sans text-white">
      {/* 3D WebGL Canvas Layer */}
      <GameCanvas
        stats={stats}
        customization={customization}
        practiceMode={practiceMode}
        onUpdateStats={setStats}
        onStage100Reached={handleStage100Reached}
        onOpenLeaderboard={() => setIsLeaderboardOpen(true)}
        mobileDirRef={mobileDirRef}
        isMobileSprintingRef={isMobileSprintingRef}
        jumpTriggerRef={jumpTriggerRef}
        warpTriggerRef={warpTriggerRef}
        respawnTriggerRef={respawnTriggerRef}
      />

      {/* UI Overlay Container (Pointer-events none on backdrop, auto on controls) */}
      <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-3 sm:p-4 z-10">
        {/* Top Bar HUD */}
        <TopBar
          stats={stats}
          isMuted={isMuted}
          practiceMode={practiceMode}
          elapsedSeconds={elapsedSeconds}
          onToggleMute={handleToggleMute}
          onTogglePractice={handleTogglePractice}
          onOpenStageList={() => setIsStageModalOpen(true)}
          onOpenResetConfirm={() => setIsResetConfirmOpen(true)}
          onOpenAvatar={() => setIsAvatarModalOpen(true)}
          onOpenControls={() => setIsControlsModalOpen(true)}
          onOpenLeaderboard={() => setIsLeaderboardOpen(true)}
          onPrevStage={handlePrevStage}
          onNextStage={handleNextStage}
        />

        {/* Initial Rebirth Leaderboard Welcome Notification ("처음에") */}
        {stats.currentStageIndex === 0 && showRebirthNotice && (
          <div className="absolute top-16 left-1/2 -translate-x-1/2 z-20 pointer-events-auto">
            <button
              type="button"
              onClick={() => setShowRebirthNotice(false)}
              className="px-4 py-1.5 bg-slate-900/90 hover:bg-slate-800 text-amber-300 hover:text-amber-200 text-xs sm:text-sm font-bold rounded-full border border-amber-500/40 shadow-xl backdrop-blur-md flex items-center gap-2 cursor-pointer transition-all group"
              title="클릭하면 닫힙니다"
            >
              <span>🏆</span>
              <span
                onClick={(e) => {
                  e.stopPropagation();
                  setIsLeaderboardOpen(true);
                }}
                className="underline decoration-amber-400 hover:text-white"
              >
                환생 리더보드: 상단 [환생 순위표] 버튼을 눌러 플레이어들의 환생 기록을 확인해보세요!
              </span>
              <span className="text-[10px] bg-amber-500/20 group-hover:bg-amber-500/40 px-1.5 py-0.5 rounded-full text-amber-200">
                ✕
              </span>
            </button>
          </div>
        )}

        {/* Center Crosshair & Quick Mouse Guide (Desktop only) */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none flex flex-col items-center">
          <div className="w-2.5 h-2.5 rounded-full border-2 border-white/80 bg-slate-900/40 shadow-sm" />
          {showCenterGuide && (
            <button
              type="button"
              onClick={() => setShowCenterGuide(false)}
              className="mt-2.5 px-3.5 py-1 bg-slate-900/85 hover:bg-slate-800 text-amber-300 hover:text-white rounded-full text-xs font-semibold border border-amber-500/30 hover:border-amber-400/50 backdrop-blur-md shadow-lg pointer-events-auto cursor-pointer transition-all flex items-center gap-1.5 group select-none hidden md:flex"
              title="클릭하면 닫힙니다"
            >
              <span>[휠] 줌 | [우클릭 드래그] 회전 | [Space] 1단 점프 | [W/↑] 사다리 등반 | [🌪️ 회오리 발판] 고공 도약</span>
              <span className="text-[10px] bg-amber-500/20 group-hover:bg-amber-500/40 text-amber-200 px-1.5 py-0.5 rounded-full ml-0.5">✕</span>
            </button>
          )}
        </div>

        {/* Bottom Mobile Virtual Controls */}
        <MobileControls
          onMove={(dir) => {
            mobileDirRef.current = dir;
          }}
          onJump={() => {
            jumpTriggerRef.current?.();
          }}
          onSprintToggle={(sprinting) => {
            isMobileSprintingRef.current = sprinting;
            setIsMobileSprinting(sprinting);
          }}
          onQuickRespawn={() => {
            respawnTriggerRef.current?.();
          }}
          isSprinting={isMobileSprinting}
        />
      </div>

      {/* 100 Stages List Modal */}
      <StageModal
        isOpen={isStageModalOpen}
        currentStageIndex={stats.currentStageIndex}
        maxUnlockedStage={stats.maxUnlockedStage}
        collectedStarIds={stats.collectedStarIds}
        onSelectStage={handleSelectStage}
        onClose={() => setIsStageModalOpen(false)}
      />

      {/* Avatar Customization Modal */}
      <AvatarModal
        isOpen={isAvatarModalOpen}
        customization={customization}
        onSave={handleSaveAvatar}
        onClose={() => setIsAvatarModalOpen(false)}
      />

      {/* Controls & Help Modal */}
      <ControlsModal
        isOpen={isControlsModalOpen}
        practiceMode={practiceMode}
        onTogglePractice={handleTogglePractice}
        onClose={() => setIsControlsModalOpen(false)}
      />

      {/* Reset Confirmation Modal */}
      <ResetConfirmModal
        isOpen={isResetConfirmOpen}
        onConfirm={handleConfirmReset}
        onClose={() => setIsResetConfirmOpen(false)}
      />

      {/* Stage 100 Victory Celebration Modal */}
      <VictoryModal
        isOpen={isVictoryModalOpen}
        elapsedSeconds={elapsedSeconds}
        deaths={stats.deathCount}
        starsCount={stats.starsCollectedCount}
        rebirthCount={stats.rebirthCount ?? 0}
        onRebirth={handleRebirth}
        onRestart={handleConfirmReset}
        onContinue={() => setIsVictoryModalOpen(false)}
      />

      {/* Rebirth Leaderboard Modal */}
      <LeaderboardModal
        isOpen={isLeaderboardOpen}
        stats={stats}
        customization={customization}
        onClose={() => setIsLeaderboardOpen(false)}
      />
    </div>
  );
}
