import * as THREE from 'three';
import { FaceType, HatType, PlayerCustomization } from '../types';

export interface CharacterController {
  mesh: THREE.Group;
  torso: THREE.Mesh;
  head: THREE.Mesh;
  faceMesh: THREE.Mesh;
  leftArm: THREE.Group;
  rightArm: THREE.Group;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
  hatGroup: THREE.Group;
  materials: {
    skinMat: THREE.MeshStandardMaterial;
    shirtMat: THREE.MeshStandardMaterial;
    pantsMat: THREE.MeshStandardMaterial;
    shoeMat: THREE.MeshStandardMaterial;
    hairMat: THREE.MeshStandardMaterial;
  };
  updateCustomization: (cust: PlayerCustomization) => void;
  setAnimation: (isWalking: boolean, walkCycle: number, isGrounded: boolean, velY: number) => void;
}

// Draw classic or stylish face textures on canvas
function createFaceTexture(faceType: FaceType, skinColor: string): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const ctx = canvas.getContext('2d')!;

  // Transparent background
  ctx.clearRect(0, 0, 128, 128);

  ctx.fillStyle = '#111827';
  ctx.strokeStyle = '#111827';
  ctx.lineWidth = 6;
  ctx.lineCap = 'round';

  if (faceType === 'cool') {
    // Cool pixel sunglasses
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(24, 38, 36, 22);
    ctx.fillRect(68, 38, 36, 22);
    ctx.fillRect(58, 44, 12, 6);
    // Glare on sunglasses
    ctx.fillStyle = '#38bdf8';
    ctx.fillRect(28, 42, 8, 4);
    ctx.fillRect(72, 42, 8, 4);
    // Smirk
    ctx.beginPath();
    ctx.arc(68, 80, 20, 0.1 * Math.PI, 0.7 * Math.PI, false);
    ctx.stroke();
  } else if (faceType === 'wink') {
    // Left eye open
    ctx.beginPath();
    ctx.arc(38, 45, 9, 0, Math.PI * 2);
    ctx.fill();
    // Right eye winking line
    ctx.beginPath();
    ctx.moveTo(76, 45);
    ctx.lineTo(96, 45);
    ctx.stroke();
    // Happy smile
    ctx.beginPath();
    ctx.arc(64, 70, 26, 0.1 * Math.PI, 0.9 * Math.PI, false);
    ctx.stroke();
    // Blush
    ctx.fillStyle = '#f43f5e88';
    ctx.beginPath();
    ctx.arc(30, 62, 7, 0, Math.PI * 2);
    ctx.arc(98, 62, 7, 0, Math.PI * 2);
    ctx.fill();
  } else if (faceType === 'excited') {
    // Starry eyes
    ctx.beginPath();
    ctx.arc(38, 44, 10, 0, Math.PI * 2);
    ctx.arc(90, 44, 10, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(36, 42, 3, 0, Math.PI * 2);
    ctx.arc(88, 42, 3, 0, Math.PI * 2);
    ctx.fill();
    // Open happy mouth :D
    ctx.fillStyle = '#be123c';
    ctx.beginPath();
    ctx.arc(64, 72, 22, 0, Math.PI, false);
    ctx.fill();
    ctx.stroke();
  } else {
    // Classic Roblox Smile Face
    ctx.beginPath();
    ctx.arc(38, 45, 9, 0, Math.PI * 2);
    ctx.arc(90, 45, 9, 0, Math.PI * 2);
    ctx.fill();

    ctx.beginPath();
    ctx.arc(64, 68, 28, 0.1 * Math.PI, 0.9 * Math.PI, false);
    ctx.stroke();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.needsUpdate = true;
  return texture;
}

// Draw front shirt texture with iconic Roblox emblem/stripe
function createShirtFrontTexture(shirtColorHex: string): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = shirtColorHex;
  ctx.fillRect(0, 0, 128, 128);

  // Center graphic: stylish white/black sporty stripe
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(38, 0, 52, 128);

  ctx.fillStyle = '#0f172a';
  ctx.fillRect(44, 20, 40, 40);

  // R logo or Star
  ctx.fillStyle = '#f59e0b';
  ctx.font = 'bold 28px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('R', 64, 40);

  // Belt / waistband
  ctx.fillStyle = '#1e293b';
  ctx.fillRect(0, 114, 128, 14);

  const tex = new THREE.CanvasTexture(canvas);
  tex.needsUpdate = true;
  return tex;
}

export function createRobloxCharacter(initialCust: PlayerCustomization): CharacterController {
  const playerGroup = new THREE.Group();

  const skinMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color(initialCust.skinColor),
    roughness: 0.35,
  });

  const shirtMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color(initialCust.shirtColor),
    roughness: 0.35,
  });

  const pantsMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color(initialCust.pantsColor),
    roughness: 0.4,
  });

  const hairMat = new THREE.MeshStandardMaterial({
    color: 0x5d3a1a,
    roughness: 0.5,
  });

  const shoeMat = new THREE.MeshStandardMaterial({
    color: 0xf8fafc,
    roughness: 0.2,
  });

  // Torso
  const torsoGeo = new THREE.BoxGeometry(1.2, 1.4, 0.6);
  const shirtTex = createShirtFrontTexture(initialCust.shirtColor);
  const torsoFrontMat = new THREE.MeshStandardMaterial({ map: shirtTex, roughness: 0.4 });
  const torsoMaterials = [shirtMat, shirtMat, shirtMat, shirtMat, torsoFrontMat, shirtMat];
  const torso = new THREE.Mesh(torsoGeo, torsoMaterials);
  torso.position.y = 1.3;
  torso.castShadow = true;
  torso.receiveShadow = true;
  playerGroup.add(torso);

  // Head
  const headGeo = new THREE.BoxGeometry(0.85, 0.85, 0.85);
  const head = new THREE.Mesh(headGeo, skinMat);
  head.position.y = 2.45;
  head.castShadow = true;
  playerGroup.add(head);

  // Face Plane
  const faceTex = createFaceTexture(initialCust.face, initialCust.skinColor);
  const faceMat = new THREE.MeshBasicMaterial({ map: faceTex, transparent: true });
  const faceMesh = new THREE.Mesh(new THREE.PlaneGeometry(0.83, 0.83), faceMat);
  faceMesh.position.set(0, 2.45, 0.43);
  playerGroup.add(faceMesh);

  // Bacon Hair strands group
  const baconHairGroup = new THREE.Group();
  baconHairGroup.position.set(0, 2.85, 0);

  const strandTop = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.25, 0.95), hairMat);
  strandTop.position.set(0, 0.08, 0);
  baconHairGroup.add(strandTop);

  const strandF1 = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.65, 0.25), hairMat);
  strandF1.position.set(-0.25, -0.18, 0.38);
  strandF1.rotation.z = 0.2;
  strandF1.rotation.x = -0.2;
  baconHairGroup.add(strandF1);

  const strandF2 = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.75, 0.25), hairMat);
  strandF2.position.set(0.2, -0.22, 0.38);
  strandF2.rotation.z = -0.25;
  strandF2.rotation.x = -0.2;
  baconHairGroup.add(strandF2);

  const strandS1 = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.6, 0.9), hairMat);
  strandS1.position.set(-0.42, -0.15, 0);
  baconHairGroup.add(strandS1);

  const strandS2 = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.6, 0.9), hairMat);
  strandS2.position.set(0.42, -0.15, 0);
  baconHairGroup.add(strandS2);

  playerGroup.add(baconHairGroup);

  // Hat Attachment Container
  const hatGroup = new THREE.Group();
  hatGroup.position.set(0, 2.88, 0);
  playerGroup.add(hatGroup);

  // Arms with pivot points at shoulders
  const armGeo = new THREE.BoxGeometry(0.48, 1.3, 0.48);

  // Left Arm Group
  const leftArmGroup = new THREE.Group();
  leftArmGroup.position.set(-0.92, 1.95, 0);
  const leftArmMesh = new THREE.Mesh(armGeo, shirtMat);
  leftArmMesh.position.set(0, -0.65, 0);
  leftArmMesh.castShadow = true;
  leftArmGroup.add(leftArmMesh);
  playerGroup.add(leftArmGroup);

  // Right Arm Group
  const rightArmGroup = new THREE.Group();
  rightArmGroup.position.set(0.92, 1.95, 0);
  const rightArmMesh = new THREE.Mesh(armGeo, shirtMat);
  rightArmMesh.position.set(0, -0.65, 0);
  rightArmMesh.castShadow = true;
  rightArmGroup.add(rightArmMesh);
  playerGroup.add(rightArmGroup);

  // Legs with pivot points at hips
  const legGeo = new THREE.BoxGeometry(0.54, 1.05, 0.54);
  const shoeGeo = new THREE.BoxGeometry(0.56, 0.25, 0.62);

  // Left Leg Group
  const leftLegGroup = new THREE.Group();
  leftLegGroup.position.set(-0.35, 1.15, 0);
  const leftLegMesh = new THREE.Mesh(legGeo, pantsMat);
  leftLegMesh.position.set(0, -0.5, 0);
  leftLegMesh.castShadow = true;
  leftLegGroup.add(leftLegMesh);

  const leftShoe = new THREE.Mesh(shoeGeo, shoeMat);
  leftShoe.position.set(0, -1.02, 0.04);
  leftShoe.castShadow = true;
  leftLegGroup.add(leftShoe);
  playerGroup.add(leftLegGroup);

  // Right Leg Group
  const rightLegGroup = new THREE.Group();
  rightLegGroup.position.set(0.35, 1.15, 0);
  const rightLegMesh = new THREE.Mesh(legGeo, pantsMat);
  rightLegMesh.position.set(0, -0.5, 0);
  rightLegMesh.castShadow = true;
  rightLegGroup.add(rightLegMesh);

  const rightShoe = new THREE.Mesh(shoeGeo, shoeMat);
  rightShoe.position.set(0, -1.02, 0.04);
  rightShoe.castShadow = true;
  rightLegGroup.add(rightShoe);
  playerGroup.add(rightLegGroup);

  function rebuildHat(hatType: HatType) {
    while (hatGroup.children.length > 0) {
      hatGroup.remove(hatGroup.children[0]);
    }

    if (hatType === 'bacon') {
      baconHairGroup.visible = true;
      return;
    }

    // For other hats, hide bacon hair or adjust
    baconHairGroup.visible = hatType === 'none';

    if (hatType === 'crown') {
      const crownMat = new THREE.MeshStandardMaterial({
        color: 0xffd700,
        metalness: 0.85,
        roughness: 0.2,
      });
      const base = new THREE.Mesh(new THREE.CylinderGeometry(0.48, 0.44, 0.25, 12), crownMat);
      base.position.y = 0.15;
      hatGroup.add(base);

      for (let i = 0; i < 5; i++) {
        const spike = new THREE.Mesh(new THREE.ConeGeometry(0.1, 0.25, 4), crownMat);
        const a = (i / 5) * Math.PI * 2;
        spike.position.set(Math.sin(a) * 0.45, 0.35, Math.cos(a) * 0.45);
        hatGroup.add(spike);
      }
    } else if (hatType === 'cap') {
      const capMat = new THREE.MeshStandardMaterial({ color: 0x2563eb, roughness: 0.4 });
      const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.46, 0.46, 0.22, 16), capMat);
      cap.position.y = 0.12;
      const visor = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.06, 0.38), capMat);
      visor.position.set(0, -0.05, 0.35);
      cap.add(visor);
      hatGroup.add(cap);
    } else if (hatType === 'horns') {
      const hornMat = new THREE.MeshStandardMaterial({ color: 0xdc2626, roughness: 0.3 });
      const h1 = new THREE.Mesh(new THREE.ConeGeometry(0.14, 0.5, 8), hornMat);
      h1.position.set(-0.32, 0.18, 0);
      h1.rotation.z = -0.35;
      const h2 = new THREE.Mesh(new THREE.ConeGeometry(0.14, 0.5, 8), hornMat);
      h2.position.set(0.32, 0.18, 0);
      h2.rotation.z = 0.35;
      hatGroup.add(h1);
      hatGroup.add(h2);
    } else if (hatType === 'halo') {
      const haloMat = new THREE.MeshStandardMaterial({
        color: 0xfef08a,
        emissive: 0xfde047,
        emissiveIntensity: 0.6,
        metalness: 0.6,
      });
      const halo = new THREE.Mesh(new THREE.TorusGeometry(0.5, 0.06, 8, 24), haloMat);
      halo.rotation.x = Math.PI / 2;
      halo.position.y = 0.55;
      hatGroup.add(halo);
    } else if (hatType === 'party') {
      const partyMat = new THREE.MeshStandardMaterial({ color: 0xec4899, roughness: 0.3 });
      const cone = new THREE.Mesh(new THREE.ConeGeometry(0.35, 0.8, 12), partyMat);
      cone.position.y = 0.45;
      const pomPom = new THREE.Mesh(
        new THREE.SphereGeometry(0.1, 8, 8),
        new THREE.MeshStandardMaterial({ color: 0xfacc15 })
      );
      pomPom.position.y = 0.85;
      hatGroup.add(cone);
      hatGroup.add(pomPom);
    } else if (hatType === 'cat_ears') {
      const earMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.4 });
      const innerMat = new THREE.MeshStandardMaterial({ color: 0xf472b6, roughness: 0.4 });

      const e1 = new THREE.Mesh(new THREE.ConeGeometry(0.18, 0.38, 4), earMat);
      e1.position.set(-0.35, 0.18, 0);
      e1.rotation.y = Math.PI / 4;
      const in1 = new THREE.Mesh(new THREE.ConeGeometry(0.12, 0.28, 4), innerMat);
      in1.position.set(0, -0.04, 0.06);
      e1.add(in1);

      const e2 = new THREE.Mesh(new THREE.ConeGeometry(0.18, 0.38, 4), earMat);
      e2.position.set(0.35, 0.18, 0);
      e2.rotation.y = Math.PI / 4;
      const in2 = new THREE.Mesh(new THREE.ConeGeometry(0.12, 0.28, 4), innerMat);
      in2.position.set(0, -0.04, 0.06);
      e2.add(in2);

      hatGroup.add(e1);
      hatGroup.add(e2);
    }
  }

  // Initialize with initial hat
  rebuildHat(initialCust.hat);

  const controller: CharacterController = {
    mesh: playerGroup,
    torso,
    head,
    faceMesh,
    leftArm: leftArmGroup,
    rightArm: rightArmGroup,
    leftLeg: leftLegGroup,
    rightLeg: rightLegGroup,
    hatGroup,
    materials: {
      skinMat,
      shirtMat,
      pantsMat,
      shoeMat,
      hairMat,
    },
    updateCustomization: (cust: PlayerCustomization) => {
      skinMat.color.set(cust.skinColor);
      shirtMat.color.set(cust.shirtColor);
      pantsMat.color.set(cust.pantsColor);

      // Rebuild torso front texture
      const newShirtTex = createShirtFrontTexture(cust.shirtColor);
      torsoMaterials[4] = new THREE.MeshStandardMaterial({ map: newShirtTex, roughness: 0.4 });

      // Rebuild face texture
      const newFaceTex = createFaceTexture(cust.face, cust.skinColor);
      faceMesh.material = new THREE.MeshBasicMaterial({ map: newFaceTex, transparent: true });

      rebuildHat(cust.hat);
    },
    setAnimation: (isWalking: boolean, walkCycle: number, isGrounded: boolean, velY: number) => {
      if (!isGrounded) {
        // Jump / Air pose
        if (velY > 0) {
          // Jumping up - arms raised
          leftArmGroup.rotation.x = THREE.MathUtils.lerp(leftArmGroup.rotation.x, -2.2, 0.2);
          rightArmGroup.rotation.x = THREE.MathUtils.lerp(rightArmGroup.rotation.x, -2.2, 0.2);
          leftLegGroup.rotation.x = THREE.MathUtils.lerp(leftLegGroup.rotation.x, 0.4, 0.2);
          rightLegGroup.rotation.x = THREE.MathUtils.lerp(rightLegGroup.rotation.x, -0.3, 0.2);
        } else {
          // Falling - arms out wide
          leftArmGroup.rotation.x = THREE.MathUtils.lerp(leftArmGroup.rotation.x, -0.8, 0.2);
          leftArmGroup.rotation.z = THREE.MathUtils.lerp(leftArmGroup.rotation.z, -0.8, 0.2);
          rightArmGroup.rotation.x = THREE.MathUtils.lerp(rightArmGroup.rotation.x, -0.8, 0.2);
          rightArmGroup.rotation.z = THREE.MathUtils.lerp(rightArmGroup.rotation.z, 0.8, 0.2);
          leftLegGroup.rotation.x = THREE.MathUtils.lerp(leftLegGroup.rotation.x, 0.2, 0.2);
          rightLegGroup.rotation.x = THREE.MathUtils.lerp(rightLegGroup.rotation.x, 0.2, 0.2);
        }
      } else if (isWalking) {
        // Walking / Running cycle
        leftArmGroup.rotation.z = 0;
        rightArmGroup.rotation.z = 0;
        const armSwing = Math.sin(walkCycle) * 0.75;
        const legSwing = Math.sin(walkCycle) * 0.75;

        leftArmGroup.rotation.x = armSwing;
        rightArmGroup.rotation.x = -armSwing;
        leftLegGroup.rotation.x = -legSwing;
        rightLegGroup.rotation.x = legSwing;
      } else {
        // Idle breathing pose
        leftArmGroup.rotation.z = 0;
        rightArmGroup.rotation.z = 0;
        leftArmGroup.rotation.x = THREE.MathUtils.lerp(leftArmGroup.rotation.x, 0, 0.2);
        rightArmGroup.rotation.x = THREE.MathUtils.lerp(rightArmGroup.rotation.x, 0, 0.2);
        leftLegGroup.rotation.x = THREE.MathUtils.lerp(leftLegGroup.rotation.x, 0, 0.2);
        rightLegGroup.rotation.x = THREE.MathUtils.lerp(rightLegGroup.rotation.x, 0, 0.2);
      }
    },
  };

  return controller;
}
