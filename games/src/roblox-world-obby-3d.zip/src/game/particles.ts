import * as THREE from 'three';

export interface ParticleSystem {
  group: THREE.Group;
  update: (dt: number) => void;
  spawnBurst: (pos: THREE.Vector3, color: number, count?: number, speed?: number) => void;
  spawnRing: (pos: THREE.Vector3, color: number) => void;
  spawnTornadoVortex: (pos: THREE.Vector3) => void;
}

export function createParticleSystem(scene: THREE.Scene): ParticleSystem {
  const group = new THREE.Group();
  scene.add(group);

  interface ActiveParticle {
    mesh: THREE.Mesh;
    vel: THREE.Vector3;
    life: number;
    maxLife: number;
    initialScale: number;
  }

  interface ActiveRing {
    mesh: THREE.Mesh;
    life: number;
    maxLife: number;
  }

  const particles: ActiveParticle[] = [];
  const rings: ActiveRing[] = [];
  const cubeGeo = new THREE.BoxGeometry(0.25, 0.25, 0.25);
  const ringGeo = new THREE.TorusGeometry(0.6, 0.08, 6, 16);

  function spawnBurst(pos: THREE.Vector3, colorHex: number, count: number = 18, speed: number = 7) {
    const mat = new THREE.MeshBasicMaterial({ color: colorHex, transparent: true });

    for (let i = 0; i < count; i++) {
      const mesh = new THREE.Mesh(cubeGeo, mat);
      mesh.position.copy(pos);

      // Random spherical velocity with upward bias
      const phi = Math.random() * Math.PI * 2;
      const theta = Math.random() * Math.PI;
      const spd = (Math.random() * 0.7 + 0.5) * speed;

      const vel = new THREE.Vector3(
        Math.sin(theta) * Math.cos(phi) * spd,
        Math.abs(Math.cos(theta)) * spd + 1.5,
        Math.sin(theta) * Math.sin(phi) * spd
      );

      group.add(mesh);
      particles.push({
        mesh,
        vel,
        life: 0.6 + Math.random() * 0.3,
        maxLife: 0.9,
        initialScale: 0.8 + Math.random() * 0.5,
      });
    }
  }

  function spawnRing(pos: THREE.Vector3, colorHex: number) {
    const mat = new THREE.MeshBasicMaterial({ color: colorHex, transparent: true, opacity: 0.9 });
    const mesh = new THREE.Mesh(ringGeo, mat);
    mesh.position.copy(pos);
    mesh.rotation.x = Math.PI / 2;
    group.add(mesh);

    rings.push({
      mesh,
      life: 0.35,
      maxLife: 0.35,
    });
  }

  function spawnTornadoVortex(pos: THREE.Vector3) {
    // Spawns upward spinning whirlwind rings & cyan breeze particles
    const colors = [0x06b6d4, 0xa5f3fc, 0x38bdf8, 0xffffff];
    for (let i = 0; i < 3; i++) {
      const ringMat = new THREE.MeshBasicMaterial({
        color: colors[i % colors.length],
        transparent: true,
        opacity: 0.85,
      });
      const ringMesh = new THREE.Mesh(ringGeo, ringMat);
      ringMesh.position.set(pos.x, pos.y + i * 0.8, pos.z);
      ringMesh.rotation.x = Math.PI / 2;
      group.add(ringMesh);
      rings.push({
        mesh: ringMesh,
        life: 0.45 + i * 0.1,
        maxLife: 0.45 + i * 0.1,
      });
    }

    // Cyclone vortex swirling cubes
    for (let i = 0; i < 20; i++) {
      const angle = (i / 20) * Math.PI * 2;
      const radius = 1.0 + Math.random() * 0.8;
      const mat = new THREE.MeshBasicMaterial({
        color: colors[i % colors.length],
        transparent: true,
        opacity: 0.9,
      });
      const mesh = new THREE.Mesh(cubeGeo, mat);
      mesh.position.set(
        pos.x + Math.cos(angle) * radius,
        pos.y + (i / 20) * 2.0,
        pos.z + Math.sin(angle) * radius
      );
      // Tangential velocity + upward lift for spiral motion
      const vel = new THREE.Vector3(
        -Math.sin(angle) * 9,
        14 + Math.random() * 8,
        Math.cos(angle) * 9
      );
      group.add(mesh);
      particles.push({
        mesh,
        vel,
        life: 0.5 + Math.random() * 0.3,
        maxLife: 0.8,
        initialScale: 0.9,
      });
    }
  }

  function update(dt: number) {
    // Update cube particles
    for (let i = particles.length - 1; i >= 0; i--) {
      const p = particles[i];
      p.life -= dt;

      p.mesh.position.addScaledVector(p.vel, dt);
      p.vel.y -= 18 * dt; // Gravity

      const progress = Math.max(0, p.life / p.maxLife);
      const scale = p.initialScale * progress;
      p.mesh.scale.set(scale, scale, scale);
      (p.mesh.material as THREE.MeshBasicMaterial).opacity = progress;

      if (p.life <= 0) {
        group.remove(p.mesh);
        p.mesh.geometry.dispose();
        particles.splice(i, 1);
      }
    }

    // Update rings
    for (let i = rings.length - 1; i >= 0; i--) {
      const r = rings[i];
      r.life -= dt;
      const progress = 1 - r.life / r.maxLife;
      const scale = 1 + progress * 2.5;
      r.mesh.scale.set(scale, scale, 1);
      (r.mesh.material as THREE.MeshBasicMaterial).opacity = 1 - progress;

      if (r.life <= 0) {
        group.remove(r.mesh);
        r.mesh.geometry.dispose();
        rings.splice(i, 1);
      }
    }
  }

  return {
    group,
    update,
    spawnBurst,
    spawnRing,
    spawnTornadoVortex,
  };
}
