import React, { useEffect, useRef, useCallback } from 'react';
import * as THREE from 'three';
import { GameStats, PlayerCustomization, Vector3D } from '../types';
import { createRobloxCharacter, CharacterController } from './character';
import { createBlockMaterial, BLOCK_DEFS } from './textures';
import {
  generateWorldData,
  STAGES,
  TOTAL_STAGES,
  BLOCK_SIZE,
  MovingPlatformData,
} from './stages';
import {
  createPlayerPhysicsState,
  updatePlayerPhysics,
  getBlockKey,
  BlockEntity,
  MovingPlatformInstance,
  PlayerPhysicsState,
  SpatialGrid,
} from './physics';
import { createParticleSystem, ParticleSystem } from './particles';
import { createStarGeometry, createCheckpointFlag, createLeaderboardStand } from './props';
import { soundFX } from './audio';

interface GameCanvasProps {
  stats: GameStats;
  customization: PlayerCustomization;
  practiceMode: boolean;
  onUpdateStats: React.Dispatch<React.SetStateAction<GameStats>>;
  onStage100Reached: () => void;
  onOpenLeaderboard?: () => void;
  mobileDirRef: React.MutableRefObject<{ x: number; z: number }>;
  isMobileSprintingRef: React.MutableRefObject<boolean>;
  jumpTriggerRef: React.MutableRefObject<(() => void) | null>;
  warpTriggerRef: React.MutableRefObject<((stageIdx: number) => void) | null>;
  respawnTriggerRef: React.MutableRefObject<(() => void) | null>;
}

export const GameCanvas: React.FC<GameCanvasProps> = ({
  stats,
  customization,
  practiceMode,
  onUpdateStats,
  onStage100Reached,
  onOpenLeaderboard,
  mobileDirRef,
  isMobileSprintingRef,
  jumpTriggerRef,
  warpTriggerRef,
  respawnTriggerRef,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // References to keep game loop fresh
  const characterRef = useRef<CharacterController | null>(null);
  const physicsStateRef = useRef<PlayerPhysicsState | null>(null);
  const practiceModeRef = useRef<boolean>(practiceMode);
  practiceModeRef.current = practiceMode;

  const onOpenLeaderboardRef = useRef<(() => void) | undefined>(onOpenLeaderboard);
  onOpenLeaderboardRef.current = onOpenLeaderboard;

  const [isOnLadder, setIsOnLadder] = React.useState(false);
  const [dismissLadderBadge, setDismissLadderBadge] = React.useState(false);
  const isOnLadderRef = useRef<boolean>(false);

  const [isNearLeaderboard, setIsNearLeaderboard] = React.useState(false);
  const isNearLeaderboardRef = useRef<boolean>(false);
  const [dismissLeaderboardPrompt, setDismissLeaderboardPrompt] = React.useState(false);

  const currentStageRef = useRef<number>(stats.currentStageIndex);
  currentStageRef.current = stats.currentStageIndex;

  const maxUnlockedStageRef = useRef<number>(stats.maxUnlockedStage);
  maxUnlockedStageRef.current = stats.maxUnlockedStage;

  const starsCollectedSetRef = useRef<Set<number>>(new Set(stats.collectedStarIds));

  // Update customization when props change
  useEffect(() => {
    if (characterRef.current) {
      characterRef.current.updateCustomization(customization);
    }
  }, [customization]);

  // Main Three.js Scene Setup & Game Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    // 1. SCENE & RENDERER
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x60a5fa);
    scene.fog = new THREE.FogExp2(0x60a5fa, 0.009);

    const camera = new THREE.PerspectiveCamera(
      70,
      window.innerWidth / window.innerHeight,
      0.1,
      1200
    );

    const renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    // 2. LIGHTING
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.65);
    scene.add(ambientLight);

    const hemiLight = new THREE.HemisphereLight(0xffffff, 0x444444, 0.35);
    hemiLight.position.set(0, 100, 0);
    scene.add(hemiLight);

    const sunLight = new THREE.DirectionalLight(0xffffff, 0.9);
    sunLight.position.set(60, 120, 60);
    sunLight.castShadow = true;
    sunLight.shadow.mapSize.width = 2048;
    sunLight.shadow.mapSize.height = 2048;
    sunLight.shadow.camera.near = 0.5;
    sunLight.shadow.camera.far = 300;
    const shadowSize = 80;
    sunLight.shadow.camera.left = -shadowSize;
    sunLight.shadow.camera.right = shadowSize;
    sunLight.shadow.camera.top = shadowSize;
    sunLight.shadow.camera.bottom = -shadowSize;
    scene.add(sunLight);

    // 3. PARTICLES SYSTEM
    const particles = createParticleSystem(scene);

    // 4. GENERATE WORLD
    const { blocks: generatedBlocks, stars: generatedStars, movingPlatforms: mpDefs } =
      generateWorldData();

    const boxGeo = new THREE.BoxGeometry(BLOCK_SIZE, BLOCK_SIZE, BLOCK_SIZE);
    const spatialGrid = new SpatialGrid(4);
    const addedKeys = new Set<string>();

    // Cache materials to avoid duplication
    const materialCache = new Map<string, THREE.Material>();
    function getCachedMaterial(typeId: string): THREE.Material {
      if (!materialCache.has(typeId)) {
        materialCache.set(typeId, createBlockMaterial(typeId as any));
      }
      return materialCache.get(typeId)!;
    }

    // Add static blocks
    generatedBlocks.forEach((gb) => {
      const key = getBlockKey(gb.x, gb.y, gb.z);
      if (addedKeys.has(key)) return;
      addedKeys.add(key);

      const mat = getCachedMaterial(gb.typeId);
      const mesh = new THREE.Mesh(boxGeo, mat);
      mesh.position.set(gb.x, gb.y, gb.z);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      scene.add(mesh);

      const blockDef = BLOCK_DEFS[gb.typeId] || { id: gb.typeId, name: gb.typeId, color: 0, type: 'normal' };
      const blockEntity: BlockEntity = {
        mesh,
        def: blockDef,
        x: gb.x,
        y: gb.y,
        z: gb.z,
        minX: gb.x - BLOCK_SIZE / 2,
        maxX: gb.x + BLOCK_SIZE / 2,
        minY: gb.y - BLOCK_SIZE / 2,
        maxY: gb.y + BLOCK_SIZE / 2,
        minZ: gb.z - BLOCK_SIZE / 2,
        maxZ: gb.z + BLOCK_SIZE / 2,
      };
      spatialGrid.add(blockEntity);
    });

    // Add moving platforms
    const movingPlatforms: MovingPlatformInstance[] = [];
    mpDefs.forEach((mp: MovingPlatformData) => {
      const mat = getCachedMaterial(mp.typeId);
      const mesh = new THREE.Mesh(boxGeo, mat);
      mesh.position.set(mp.basePos.x, mp.basePos.y, mp.basePos.z);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      scene.add(mesh);

      const mpDef = BLOCK_DEFS[mp.typeId] || { id: mp.typeId, name: mp.typeId, color: 0, type: 'normal' };
      movingPlatforms.push({
        mesh,
        def: mpDef,
        basePos: { ...mp.basePos },
        axis: mp.axis,
        amplitude: mp.amplitude,
        speed: mp.speed,
        currentPos: { ...mp.basePos },
        delta: { x: 0, y: 0, z: 0 },
      });
    });

    // 5. CHECKPOINT FLAGS
    const flagGroups: { stageIdx: number; group: THREE.Group }[] = [];
    STAGES.forEach((stage) => {
      const isUnlocked = stage.id <= stats.maxUnlockedStage;
      const flagGroup = createCheckpointFlag(isUnlocked);
      flagGroup.position.set(stage.pos.x + 2, stage.pos.y, stage.pos.z);
      scene.add(flagGroup);
      flagGroups.push({ stageIdx: stage.id, group: flagGroup });
    });

    // 5.2. REBIRTH LEADERBOARD STAND (Starting Plaza)
    const leaderboardStand = createLeaderboardStand();
    leaderboardStand.position.set(0, 0, -5.2);
    scene.add(leaderboardStand);

    // 6. COLLECTIBLE STARS
    const starGeo = createStarGeometry();
    const starMat = new THREE.MeshStandardMaterial({
      color: 0xffd700,
      metalness: 0.85,
      roughness: 0.2,
      emissive: 0xf59e0b,
      emissiveIntensity: 0.35,
    });

    interface StarObject {
      mesh: THREE.Mesh;
      initialY: number;
      stageIdx: number;
      collected: boolean;
    }

    const starObjects: StarObject[] = [];
    generatedStars.forEach((s) => {
      if (starsCollectedSetRef.current.has(s.stageIdx)) return;

      const starMesh = new THREE.Mesh(starGeo, starMat);
      starMesh.position.set(s.x, s.y, s.z);
      starMesh.castShadow = true;
      scene.add(starMesh);

      starObjects.push({
        mesh: starMesh,
        initialY: s.y,
        stageIdx: s.stageIdx,
        collected: false,
      });
    });

    // 7. CREATE CHARACTER
    const currentStage = STAGES[stats.currentStageIndex] || STAGES[0];
    const initialPos = { x: currentStage.pos.x, y: currentStage.pos.y, z: currentStage.pos.z };

    const character = createRobloxCharacter(customization);
    characterRef.current = character;
    scene.add(character.mesh);

    const physicsState = createPlayerPhysicsState(initialPos);
    physicsStateRef.current = physicsState;
    character.mesh.position.copy(physicsState.pos);

    // 8. CAMERA & INPUT STATE
    let cameraAngleX = 0;
    let cameraAngleY = 0.25;
    let cameraDistance = 9.5;
    let isDragging = false;
    let prevMouseX = 0;
    let prevMouseY = 0;

    const keys: Record<string, boolean> = {};

    const handleKeyDown = (e: KeyboardEvent) => {
      keys[e.code] = true;
      if (e.key) keys[e.key.toLowerCase()] = true;

      // Jump trigger
      if ((e.code === 'Space' || e.key === ' ') && !e.repeat) {
        triggerJump();
      }

      // Quick Respawn
      if (e.code === 'KeyR' || e.key === 'r' || e.key === 'ㄱ') {
        respawnPlayer(false);
      }

      // Leaderboard Stand Interaction (KeyE)
      if ((e.code === 'KeyE' || e.key === 'e' || e.key === 'ㄷ') && isNearLeaderboardRef.current) {
        soundFX.playClick();
        onOpenLeaderboardRef.current?.();
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      keys[e.code] = false;
      if (e.key) keys[e.key.toLowerCase()] = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    // Mouse drag orbit
    const handleMouseDown = (e: MouseEvent) => {
      // Right click or middle click or left click on canvas
      if (e.button === 2 || e.button === 0) {
        // If clicking on UI overlay, don't drag
        if ((e.target as HTMLElement).tagName !== 'CANVAS') return;
        isDragging = true;
        prevMouseX = e.clientX;
        prevMouseY = e.clientY;
      }
    };

    const handleMouseUp = () => {
      isDragging = false;
    };

    // Canvas click detection for 3D Leaderboard Stand
    const raycaster = new THREE.Raycaster();
    const handleCanvasClick = (e: MouseEvent) => {
      if ((e.target as HTMLElement).tagName !== 'CANVAS') return;
      const rect = canvas.getBoundingClientRect();
      const mouse = new THREE.Vector2(
        ((e.clientX - rect.left) / rect.width) * 2 - 1,
        -((e.clientY - rect.top) / rect.height) * 2 + 1
      );
      raycaster.setFromCamera(mouse, camera);
      const intersects = raycaster.intersectObjects(leaderboardStand.children, true);
      if (intersects.length > 0) {
        soundFX.playClick();
        onOpenLeaderboardRef.current?.();
      }
    };
    window.addEventListener('click', handleCanvasClick);

    const handleMouseMove = (e: MouseEvent) => {
      if (isDragging) {
        const dx = e.clientX - prevMouseX;
        const dy = e.clientY - prevMouseY;

        cameraAngleX -= dx * 0.005;
        cameraAngleY = Math.max(-0.25, Math.min(Math.PI / 2 - 0.08, cameraAngleY + dy * 0.005));

        prevMouseX = e.clientX;
        prevMouseY = e.clientY;
      }
    };

    const handleWheel = (e: WheelEvent) => {
      cameraDistance = Math.max(0, Math.min(25, cameraDistance + e.deltaY * 0.015));
    };

    const handleContextMenu = (e: MouseEvent) => e.preventDefault();

    window.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', handleMouseUp);
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('wheel', handleWheel, { passive: true });
    window.addEventListener('contextmenu', handleContextMenu);

    // 9. JUMP & RESPAWN ACTIONS
    function triggerJump() {
      if (!physicsState) return;

      if (practiceModeRef.current) {
        // Practice Mode: multi-jumps for practice
        physicsState.vel.y = physicsState.jumpPower * 1.05;
        physicsState.isGrounded = false;
        soundFX.playDoubleJump();
        particles.spawnBurst(physicsState.pos, 0x818cf8, 10, 6);
        return;
      }

      // 1단 점프 (Single Jump) or Jumping off Ladder
      if (physicsState.isGrounded || physicsState.coyoteTimer > 0 || physicsState.isOnLadder) {
        physicsState.vel.y = physicsState.jumpPower;
        physicsState.isGrounded = false;
        physicsState.isOnLadder = false;
        physicsState.coyoteTimer = 0;
        soundFX.playJump();
        particles.spawnRing(physicsState.pos, 0xffffff);
      } else {
        // Buffer jump input
        physicsState.jumpBufferTimer = 0.14;
      }
    }

    function respawnPlayer(isDeath: boolean = false) {
      if (!physicsState) return;

      if (isDeath) {
        soundFX.playOof();
        particles.spawnBurst(physicsState.pos, 0xef4444, 25, 9);
        onUpdateStats((prev) => ({
          ...prev,
          deathCount: prev.deathCount + 1,
        }));
      }

      const st = STAGES[currentStageRef.current] || STAGES[0];
      physicsState.pos.set(st.pos.x, st.pos.y, st.pos.z);
      physicsState.vel.set(0, 0, 0);
      physicsState.isOnLadder = false;
      physicsState.isGrounded = true;
      character.mesh.position.copy(physicsState.pos);
    }

    function warpToStage(stageIndex: number) {
      if (!physicsState || stageIndex < 0 || stageIndex >= STAGES.length) return;
      currentStageRef.current = stageIndex;
      const target = STAGES[stageIndex];

      physicsState.pos.set(target.pos.x, target.pos.y, target.pos.z);
      physicsState.vel.set(0, 0, 0);
      physicsState.isOnLadder = false;
      physicsState.isGrounded = true;
      character.mesh.position.copy(physicsState.pos);

      particles.spawnBurst(physicsState.pos, 0xa855f7, 20, 8);
      soundFX.playBounce();

      onUpdateStats((prev) => ({
        ...prev,
        currentStageIndex: stageIndex,
      }));
    }

    // Expose refs for external buttons
    jumpTriggerRef.current = triggerJump;
    respawnTriggerRef.current = () => respawnPlayer(false);
    warpTriggerRef.current = (idx: number) => warpToStage(idx);

    // 10. CHECKPOINT & DEATH CALLBACKS
    const onCheckpointReached = (matchedStageIdx: number) => {
      let didUnlock = false;

      if (matchedStageIdx > maxUnlockedStageRef.current) {
        maxUnlockedStageRef.current = matchedStageIdx;
        didUnlock = true;
      }

      if (matchedStageIdx !== currentStageRef.current) {
        currentStageRef.current = matchedStageIdx;
        soundFX.playCheckpoint();
        particles.spawnRing(physicsState.pos, 0xfacc15);
        particles.spawnBurst(physicsState.pos, 0xfde047, 18, 7);

        // Update flag color
        const foundFlag = flagGroups.find((f) => f.stageIdx === matchedStageIdx);
        if (foundFlag) {
          const mat = (foundFlag.group.userData as { flagMat: THREE.MeshStandardMaterial }).flagMat;
          mat.color.set(0x10b981);
        }

        onUpdateStats((prev) => ({
          ...prev,
          currentStageIndex: matchedStageIdx,
          maxUnlockedStage: Math.max(prev.maxUnlockedStage, matchedStageIdx),
        }));

        // Final Stage 100 victory check!
        if (matchedStageIdx === TOTAL_STAGES - 1) {
          onStage100Reached();
        }
      } else if (didUnlock) {
        onUpdateStats((prev) => ({
          ...prev,
          maxUnlockedStage: Math.max(prev.maxUnlockedStage, matchedStageIdx),
        }));
      }
    };

    const onPlayerDeath = () => {
      if (practiceModeRef.current) {
        // God Mode in Practice Mode: bounce back up instead of dying
        physicsState.vel.y = 28;
        soundFX.playBounce();
        return;
      }
      respawnPlayer(true);
    };

    // 11. MAIN ANIMATION LOOP
    let animationFrameId: number;
    let lastTime = performance.now();
    let walkCycle = 0;

    const animate = (currentTime: number) => {
      animationFrameId = requestAnimationFrame(animate);

      const dt = Math.min((currentTime - lastTime) / 1000, 0.1);
      lastTime = currentTime;

      // A. Update Moving Platforms
      const t = currentTime * 0.0015;
      movingPlatforms.forEach((mp) => {
        const prev = { ...mp.currentPos };
        const offset = Math.sin(t * mp.speed) * mp.amplitude;

        if (mp.axis === 'x') {
          mp.currentPos.x = mp.basePos.x + offset;
        } else if (mp.axis === 'y') {
          mp.currentPos.y = mp.basePos.y + offset;
        } else {
          mp.currentPos.z = mp.basePos.z + offset;
        }

        mp.mesh.position.set(mp.currentPos.x, mp.currentPos.y, mp.currentPos.z);
        mp.delta.x = mp.currentPos.x - prev.x;
        mp.delta.y = mp.currentPos.y - prev.y;
        mp.delta.z = mp.currentPos.z - prev.z;
      });

      // B. Update Player Movement Inputs
      let inputX = 0;
      let inputZ = 0;

      if (keys['KeyW'] || keys['ArrowUp'] || keys['w'] || keys['ㅈ']) inputZ -= 1;
      if (keys['KeyS'] || keys['ArrowDown'] || keys['s'] || keys['ㄴ']) inputZ += 1;
      if (keys['KeyA'] || keys['ArrowLeft'] || keys['a'] || keys['ㅁ']) inputX -= 1;
      if (keys['KeyD'] || keys['ArrowRight'] || keys['d'] || keys['ㅇ']) inputX += 1;

      // Mobile joystick input
      if (mobileDirRef.current.x !== 0 || mobileDirRef.current.z !== 0) {
        inputX = mobileDirRef.current.x;
        inputZ = mobileDirRef.current.z;
      }

      // Sprinting modifier
      const isShift = keys['ShiftLeft'] || keys['ShiftRight'] || isMobileSprintingRef.current;
      const sprintFactor = isShift ? 1.45 : 1.0;
      const boostFactor = physicsState.boostTimer > 0 ? 1.7 : 1.0;
      const totalSpeed = physicsState.speed * sprintFactor * boostFactor;

      const inputLength = Math.hypot(inputX, inputZ);
      const isMoving = inputLength > 0.1;

      if (isMoving) {
        const normX = inputX / Math.max(1, inputLength);
        const normZ = inputZ / Math.max(1, inputLength);

        // Move relative to camera yaw
        const angle = cameraAngleX;
        const dirX = normX * Math.cos(angle) + normZ * Math.sin(angle);
        const dirZ = -normX * Math.sin(angle) + normZ * Math.cos(angle);

        physicsState.vel.x = dirX * totalSpeed;
        physicsState.vel.z = dirZ * totalSpeed;

        physicsState.rotationY = Math.atan2(dirX, dirZ);

        walkCycle += dt * 14 * sprintFactor;
      } else {
        physicsState.vel.x = 0;
        physicsState.vel.z = 0;
      }

      // C. Update Physics with ladder climbing inputs and stage height
      const inputUp =
        !!(keys['KeyW'] ||
        keys['ArrowUp'] ||
        keys['w'] ||
        keys['ㅈ'] ||
        keys['Space'] ||
        keys[' '] ||
        mobileDirRef.current.z < -0.2);

      const inputDown =
        !!(keys['KeyS'] ||
        keys['ArrowDown'] ||
        keys['s'] ||
        keys['ㄴ'] ||
        mobileDirRef.current.z > 0.2);

      const currentStageY = (STAGES[currentStageRef.current] || STAGES[0]).pos.y;

      updatePlayerPhysics(
        physicsState,
        spatialGrid,
        movingPlatforms,
        dt,
        particles,
        inputUp,
        inputDown,
        currentStageY,
        onCheckpointReached,
        onPlayerDeath
      );

      // Tornado spin effect: rapid aerial rotation while launched
      if (physicsState.tornadoSpinTimer > 0) {
        physicsState.rotationY += dt * 18;
      }

      // Sync ladder state to React badge
      if (physicsState.isOnLadder !== isOnLadderRef.current) {
        isOnLadderRef.current = physicsState.isOnLadder;
        setIsOnLadder(physicsState.isOnLadder);
      }

      // D. Update Character Mesh & Animation
      character.mesh.position.copy(physicsState.pos);
      character.mesh.rotation.y = physicsState.rotationY;
      character.setAnimation(
        isMoving || physicsState.isOnLadder,
        walkCycle,
        physicsState.isGrounded,
        physicsState.vel.y
      );

      // E. Update Camera Mode (1st person vs 3rd person)
      if (cameraDistance < 0.8) {
        // 1st-person view
        character.mesh.visible = false;
        const eyeY = physicsState.pos.y + 2.3;
        camera.position.set(physicsState.pos.x, eyeY, physicsState.pos.z);

        const lookX = physicsState.pos.x - Math.sin(cameraAngleX) * Math.cos(cameraAngleY);
        const lookY = eyeY - Math.sin(cameraAngleY);
        const lookZ = physicsState.pos.z - Math.cos(cameraAngleX) * Math.cos(cameraAngleY);
        camera.lookAt(lookX, lookY, lookZ);
      } else {
        // 3rd-person follow view with smooth easing
        character.mesh.visible = true;

        const targetCamX =
          physicsState.pos.x + cameraDistance * Math.sin(cameraAngleX) * Math.cos(cameraAngleY);
        const targetCamY =
          physicsState.pos.y + 1.8 + cameraDistance * Math.sin(cameraAngleY);
        const targetCamZ =
          physicsState.pos.z + cameraDistance * Math.cos(cameraAngleX) * Math.cos(cameraAngleY);

        camera.position.x = THREE.MathUtils.lerp(camera.position.x, targetCamX, 0.25);
        camera.position.y = THREE.MathUtils.lerp(camera.position.y, targetCamY, 0.25);
        camera.position.z = THREE.MathUtils.lerp(camera.position.z, targetCamZ, 0.25);

        camera.lookAt(physicsState.pos.x, physicsState.pos.y + 1.6, physicsState.pos.z);
      }

      // Directional light follows player for crisp shadow map
      sunLight.position.set(
        physicsState.pos.x + 40,
        physicsState.pos.y + 80,
        physicsState.pos.z + 40
      );
      sunLight.target.position.copy(physicsState.pos);
      sunLight.target.updateMatrixWorld();

      // F. Update Collectible Stars
      for (let i = starObjects.length - 1; i >= 0; i--) {
        const star = starObjects[i];
        if (!star.collected) {
          star.mesh.rotation.y += dt * 2.2;
          star.mesh.position.y = star.initialY + Math.sin(currentTime * 0.003 + star.stageIdx) * 0.25;

          const dist = physicsState.pos.distanceTo(star.mesh.position);
          if (dist < 2.1) {
            star.collected = true;
            soundFX.playStar();
            particles.spawnBurst(star.mesh.position, 0xffd700, 24, 8);
            scene.remove(star.mesh);
            starObjects.splice(i, 1);

            starsCollectedSetRef.current.add(star.stageIdx);

            onUpdateStats((prev) => ({
              ...prev,
              starsCollectedCount: prev.starsCollectedCount + 1,
              collectedStarIds: [...prev.collectedStarIds, star.stageIdx],
            }));
          }
        }
      }

      // G. Update Particles
      particles.update(dt);

      // G.2 Check proximity to Leaderboard Stand (at stage 0)
      if (currentStageRef.current === 0) {
        const distToLeaderboard = physicsState.pos.distanceTo(new THREE.Vector3(0, 0, -5.2));
        const nearBoard = distToLeaderboard < 5.8;
        if (nearBoard !== isNearLeaderboardRef.current) {
          isNearLeaderboardRef.current = nearBoard;
          setIsNearLeaderboard(nearBoard);
        }
      } else if (isNearLeaderboardRef.current) {
        isNearLeaderboardRef.current = false;
        setIsNearLeaderboard(false);
      }

      // H. Render
      renderer.render(scene, camera);
    };

    animationFrameId = requestAnimationFrame(animate);

    // Resize handler
    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };
    window.addEventListener('resize', handleResize);

    // Cleanup
    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      window.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mouseup', handleMouseUp);
      window.removeEventListener('click', handleCanvasClick);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('wheel', handleWheel);
      window.removeEventListener('contextmenu', handleContextMenu);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
    };
  }, []);

  return (
    <div ref={containerRef} className="fixed inset-0 w-screen h-screen overflow-hidden">
      <canvas ref={canvasRef} className="w-full h-full block touch-none" />
      {isOnLadder && !dismissLadderBadge && (
        <div className="absolute top-20 left-1/2 -translate-x-1/2 z-30 animate-bounce">
          <button
            type="button"
            onClick={() => setDismissLadderBadge(true)}
            className="px-4 py-1.5 bg-amber-500/90 hover:bg-amber-400 text-slate-950 font-black text-xs sm:text-sm rounded-full shadow-xl border-2 border-amber-300 backdrop-blur-md flex items-center gap-1.5 cursor-pointer pointer-events-auto transition-all"
            title="클릭하면 닫힙니다"
          >
            <span>🪜</span>
            <span>사다리 등반 중: [W/↑] 위로 | [S/↓] 아래로 | [Space] 도약</span>
            <span className="text-xs bg-slate-950/20 px-1 rounded-full ml-1">✕</span>
          </button>
        </div>
      )}

      {isNearLeaderboard && !dismissLeaderboardPrompt && (
        <div className="absolute bottom-24 left-1/2 -translate-x-1/2 z-30 animate-bounce pointer-events-auto">
          <button
            type="button"
            onClick={() => {
              soundFX.playClick();
              onOpenLeaderboard?.();
            }}
            className="px-4 py-2 bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs sm:text-sm rounded-2xl shadow-2xl border-2 border-amber-300 backdrop-blur-md flex items-center gap-2 cursor-pointer transition-all"
            title="클릭하면 환생 순위표가 열립니다"
          >
            <span>🏆</span>
            <span>환생 명예의 전당: [E] 또는 클릭하여 순위표 확인</span>
            <span
              onClick={(e) => {
                e.stopPropagation();
                setDismissLeaderboardPrompt(true);
              }}
              className="text-xs bg-slate-950/20 hover:bg-slate-950/40 px-1.5 py-0.5 rounded-full ml-1"
              title="닫기"
            >
              ✕
            </span>
          </button>
        </div>
      )}
    </div>
  );
};
