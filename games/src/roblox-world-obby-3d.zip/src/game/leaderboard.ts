import { LeaderboardEntry, PlayerCustomization } from '../types';

const LEADERBOARD_STORAGE_KEY = 'roblox_obby_rebirth_leaderboard_v1';
const PLAYER_NICKNAME_KEY = 'roblox_obby_player_nickname';

// Initial community players who have played and achieved rebirths
const INITIAL_COMMUNITY_ENTRIES: Omit<LeaderboardEntry, 'rank' | 'isCurrentPlayer'>[] = [
  {
    id: 'user_1',
    nickname: '🔥 불꽃파쿠러',
    rebirths: 58,
    stars: 99,
    title: '전설의 신',
    hat: 'crown',
    face: 'cool',
    color: '#ef4444',
  },
  {
    id: 'user_2',
    nickname: '도도_ObbyKing',
    rebirths: 43,
    stars: 99,
    title: '황금 마스터',
    hat: 'halo',
    face: 'excited',
    color: '#f59e0b',
  },
  {
    id: 'user_3',
    nickname: '민트초코러너',
    rebirths: 37,
    stars: 96,
    title: '스피드 악마',
    hat: 'horns',
    face: 'cool',
    color: '#10b981',
  },
  {
    id: 'user_4',
    nickname: '하늘달리기',
    rebirths: 29,
    stars: 92,
    title: '공중 지배자',
    hat: 'cap',
    face: 'smile',
    color: '#06b6d4',
  },
  {
    id: 'user_5',
    nickname: '별빛소년',
    rebirths: 22,
    stars: 88,
    title: '베테랑 점퍼',
    hat: 'party',
    face: 'wink',
    color: '#8b5cf6',
  },
  {
    id: 'user_6',
    nickname: 'Robloxian_KR',
    rebirths: 16,
    stars: 85,
    title: '도약 장인',
    hat: 'bacon',
    face: 'smile',
    color: '#3b82f6',
  },
  {
    id: 'user_7',
    nickname: '구름위의나비',
    rebirths: 11,
    stars: 79,
    title: '고공 탐험가',
    hat: 'cat_ears',
    face: 'excited',
    color: '#ec4899',
  },
  {
    id: 'user_8',
    nickname: '점프마스터99',
    rebirths: 8,
    stars: 74,
    title: '숙련된 러너',
    hat: 'cap',
    face: 'cool',
    color: '#6366f1',
  },
  {
    id: 'user_9',
    nickname: '황금토끼',
    rebirths: 5,
    stars: 68,
    title: '파쿠르 챌린저',
    hat: 'crown',
    face: 'wink',
    color: '#eab308',
  },
  {
    id: 'user_10',
    nickname: '초보탈출넘버원',
    rebirths: 2,
    stars: 45,
    title: '새싹 환생자',
    hat: 'bacon',
    face: 'smile',
    color: '#14b8a6',
  },
];

export function getStoredPlayerNickname(): string {
  try {
    const name = localStorage.getItem(PLAYER_NICKNAME_KEY);
    if (name && name.trim()) return name.trim();
  } catch (e) {
    console.error('Failed to get stored nickname:', e);
  }
  return '나 (Player)';
}

export function saveStoredPlayerNickname(nickname: string): void {
  try {
    localStorage.setItem(PLAYER_NICKNAME_KEY, nickname.trim() || '나 (Player)');
  } catch (e) {
    console.error('Failed to save nickname:', e);
  }
}

export function getFullLeaderboard(
  currentPlayerRebirths: number,
  currentPlayerStars: number,
  customization: PlayerCustomization,
  customNickname?: string
): { entries: LeaderboardEntry[]; currentPlayerRank: number } {
  const nickname = customNickname || getStoredPlayerNickname();

  let community: Omit<LeaderboardEntry, 'rank' | 'isCurrentPlayer'>[] = INITIAL_COMMUNITY_ENTRIES;

  try {
    const saved = localStorage.getItem(LEADERBOARD_STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed) && parsed.length > 0) {
        community = parsed;
      }
    }
  } catch (e) {
    console.error('Failed to parse leaderboard storage:', e);
  }

  // Determine current player title based on rebirths
  let playerTitle = '초심자 러너';
  if (currentPlayerRebirths >= 50) playerTitle = '👑 오비의 절대신';
  else if (currentPlayerRebirths >= 30) playerTitle = '🔥 전설의 마스터';
  else if (currentPlayerRebirths >= 15) playerTitle = '⚡ 초월한 환생자';
  else if (currentPlayerRebirths >= 5) playerTitle = '🌟 베테랑 환생자';
  else if (currentPlayerRebirths >= 1) playerTitle = '✨ 1차 환생 도약자';

  const currentPlayerEntry: LeaderboardEntry = {
    id: 'current_player',
    nickname,
    rebirths: currentPlayerRebirths,
    stars: currentPlayerStars,
    title: playerTitle,
    hat: customization.hat,
    face: customization.face,
    color: customization.shirtColor,
    isCurrentPlayer: true,
  };

  // Combine and sort by rebirths desc, then stars desc
  const allEntries: LeaderboardEntry[] = [
    ...community.map((c) => ({ ...c, isCurrentPlayer: false })),
    currentPlayerEntry,
  ];

  allEntries.sort((a, b) => {
    if (b.rebirths !== a.rebirths) {
      return b.rebirths - a.rebirths;
    }
    return b.stars - a.stars;
  });

  // Assign ranks
  let playerRank = 1;
  allEntries.forEach((entry, idx) => {
    entry.rank = idx + 1;
    if (entry.isCurrentPlayer) {
      playerRank = idx + 1;
    }
  });

  return {
    entries: allEntries,
    currentPlayerRank: playerRank,
  };
}
