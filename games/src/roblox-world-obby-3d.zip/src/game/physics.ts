import * as THREE from 'three';
import { BlockDef, Vector3D } from '../types';
import { BLOCK_SIZE, STAGES } from './stages';
import { soundFX } from './audio';
import { ParticleSystem } from './particles';

export interface PlayerPhysicsState {
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  isGrounded: boolean;
  canDoubleJump: boolean;
  rotationY: number;
  radius: number;
  height: number;
  speed: number;
  sprintMultiplier: number;
  jumpPower: number;
  boostTimer: number;
  coyoteTimer: number;
  jumpBufferTimer: number;
  isOnLadder: boolean;
  ladderSoundTimer: number;
  tornadoSpinTimer: number;
}

export interface BlockEntity {
  mesh: THREE.Mesh;
  def: BlockDef;
  stageId?: number;
  x: number;
  y: number;
  z: number;
  minX: number;
  maxX: number;
  minY: number;
  maxY: number;
  minZ: number;
  maxZ: number;
}

export interface MovingPlatformInstance {
  mesh: THREE.Mesh;
  def: BlockDef;
  basePos: Vector3D;
  axis: 'x' | 'y' | 'z';
  amplitude: number;
  speed: number;
  currentPos: Vector3D;
  delta: Vector3D;
}

/**
 * 3D Spatial Grid for O(1) broadphase collision lookup.
 * Guarantees every single block regardless of coordinate alignment is detected and steppable.
 */
export class SpatialGrid {
  public cellSize: number;
  private cells: Map<string, BlockEntity[]> = new Map();
  public allBlocks: BlockEntity[] = [];

  constructor(cellSize: number = 4) {
    this.cellSize = cellSize;
  }

  public clear() {
    this.cells.clear();
    this.allBlocks = [];
  }

  public add(block: BlockEntity) {
    this.allBlocks.push(block);
    const minCX = Math.floor(block.minX / this.cellSize);
    const maxCX = Math.floor(block.maxX / this.cellSize);
    const minCY = Math.floor(block.minY / this.cellSize);
    const maxCY = Math.floor(block.maxY / this.cellSize);
    const minCZ = Math.floor(block.minZ / this.cellSize);
    const maxCZ = Math.floor(block.maxZ / this.cellSize);

    for (let cx = minCX; cx <= maxCX; cx++) {
      for (let cy = minCY; cy <= maxCY; cy++) {
        for (let cz = minCZ; cz <= maxCZ; cz++) {
          const key = `${cx},${cy},${cz}`;
          let list = this.cells.get(key);
          if (!list) {
            list = [];
            this.cells.set(key, list);
          }
          list.push(block);
        }
      }
    }
  }

  public queryAABB(
    minX: number,
    maxX: number,
    minY: number,
    maxY: number,
    minZ: number,
    maxZ: number
  ): BlockEntity[] {
    const minCX = Math.floor(minX / this.cellSize);
    const maxCX = Math.floor(maxX / this.cellSize);
    const minCY = Math.floor(minY / this.cellSize);
    const maxCY = Math.floor(maxY / this.cellSize);
    const minCZ = Math.floor(minZ / this.cellSize);
    const maxCZ = Math.floor(maxZ / this.cellSize);

    const candidates: BlockEntity[] = [];
    const seen = new Set<BlockEntity>();

    for (let cx = minCX; cx <= maxCX; cx++) {
      for (let cy = minCY; cy <= maxCY; cy++) {
        for (let cz = minCZ; cz <= maxCZ; cz++) {
          const key = `${cx},${cy},${cz}`;
          const list = this.cells.get(key);
          if (list) {
            for (let i = 0; i < list.length; i++) {
              const b = list[i];
              if (!seen.has(b)) {
                seen.add(b);
                candidates.push(b);
              }
            }
          }
        }
      }
    }
    return candidates;
  }
}

export function createPlayerPhysicsState(initialPos: Vector3D): PlayerPhysicsState {
  return {
    pos: new THREE.Vector3(initialPos.x, initialPos.y, initialPos.z),
    vel: new THREE.Vector3(0, 0, 0),
    isGrounded: false,
    canDoubleJump: false,
    rotationY: 0,
    radius: 0.58,
    height: 2.7,
    speed: 13.5,
    sprintMultiplier: 1.0,
    jumpPower: 19.5,
    boostTimer: 0,
    coyoteTimer: 0,
    jumpBufferTimer: 0,
    isOnLadder: false,
    ladderSoundTimer: 0,
    tornadoSpinTimer: 0,
  };
}

export function getBlockKey(x: number, y: number, z: number): string {
  return `${Math.round(x)},${Math.round(y)},${Math.round(z)}`;
}

export function updatePlayerPhysics(
  state: PlayerPhysicsState,
  grid: SpatialGrid,
  movingPlatforms: MovingPlatformInstance[],
  dt: number,
  particles: ParticleSystem,
  inputUp: boolean,
  inputDown: boolean,
  currentStageY: number,
  onCheckpointReached: (stageIndex: number) => void,
  onPlayerDeath: () => void
) {
  // Update timers
  if (state.boostTimer > 0) {
    state.boostTimer -= dt;
  }
  if (state.coyoteTimer > 0) {
    state.coyoteTimer -= dt;
  }
  if (state.jumpBufferTimer > 0) {
    state.jumpBufferTimer -= dt;
  }
  if (state.tornadoSpinTimer > 0) {
    state.tornadoSpinTimer -= dt;
  }
  if (state.ladderSoundTimer > 0) {
    state.ladderSoundTimer -= dt;
  }

  // Handle jump buffering (Single Jump: only grounded or on ladder or within coyote time)
  if (state.jumpBufferTimer > 0 && (state.isGrounded || state.coyoteTimer > 0 || state.isOnLadder)) {
    state.vel.y = state.jumpPower;
    state.isGrounded = false;
    state.isOnLadder = false;
    state.coyoteTimer = 0;
    state.jumpBufferTimer = 0;
    soundFX.playJump();
    particles.spawnRing(state.pos, 0xffffff);
  }

  // Ladder detection query
  const ladderCheckRadius = state.radius + 0.35;
  const ladderCandidates = grid.queryAABB(
    state.pos.x - ladderCheckRadius,
    state.pos.x + ladderCheckRadius,
    state.pos.y - 0.2,
    state.pos.y + state.height + 0.2,
    state.pos.z - ladderCheckRadius,
    state.pos.z + ladderCheckRadius
  );

  const touchingLadder = ladderCandidates.find(
    (b) =>
      b.def.type === 'ladder' &&
      Math.abs(state.pos.x - b.x) <= BLOCK_SIZE / 2 + state.radius + 0.25 &&
      Math.abs(state.pos.z - b.z) <= BLOCK_SIZE / 2 + state.radius + 0.25 &&
      state.pos.y + state.height >= b.minY &&
      state.pos.y <= b.maxY + 0.4
  );

  state.isOnLadder = !!touchingLadder;

  const prevY = state.pos.y;

  if (touchingLadder) {
    // Climbing or clinging to ladder
    state.isGrounded = true;
    if (inputUp) {
      state.vel.y = 10.5;
      if (state.ladderSoundTimer <= 0) {
        soundFX.playLadder();
        state.ladderSoundTimer = 0.24;
      }
      // Smoothly boost player over ladder top
      if (state.pos.y >= touchingLadder.maxY - 0.35) {
        state.vel.y = 7.5;
        state.pos.y = touchingLadder.maxY + 0.05;
      }
    } else if (inputDown) {
      state.vel.y = -6.5;
    } else {
      // Clinging in place
      state.vel.y = 0;
    }
  } else {
    // Standard Gravity
    const gravity = 38;
    state.vel.y -= gravity * dt;
  }

  // Apply vertical velocity
  state.pos.y += state.vel.y * dt;

  const wasGrounded = state.isGrounded;
  if (!touchingLadder) {
    state.isGrounded = false;
  }

  let pMinX = state.pos.x - state.radius;
  let pMaxX = state.pos.x + state.radius;
  let pMinY = state.pos.y;
  let pMaxY = state.pos.y + state.height;
  let pMinZ = state.pos.z - state.radius;
  let pMaxZ = state.pos.z + state.radius;

  // Check moving platforms first for collision & riding
  for (const mp of movingPlatforms) {
    const bMinX = mp.currentPos.x - BLOCK_SIZE / 2;
    const bMaxX = mp.currentPos.x + BLOCK_SIZE / 2;
    const bMinY = mp.currentPos.y - BLOCK_SIZE / 2;
    const bMaxY = mp.currentPos.y + BLOCK_SIZE / 2;
    const bMinZ = mp.currentPos.z - BLOCK_SIZE / 2;
    const bMaxZ = mp.currentPos.z + BLOCK_SIZE / 2;

    if (pMaxX > bMinX && pMinX < bMaxX && pMaxZ > bMinZ && pMinZ < bMaxZ) {
      if (pMinY <= bMaxY && pMaxY >= bMinY) {
        if (state.vel.y <= 0 && prevY >= bMaxY - 0.7) {
          state.pos.y = bMaxY;
          state.vel.y = 0;
          state.isGrounded = true;
          // Carry player with moving platform!
          state.pos.x += mp.delta.x;
          state.pos.y += mp.delta.y;
          state.pos.z += mp.delta.z;
        } else if (state.vel.y > 0 && pMaxY > bMinY && prevY + state.height <= bMinY + 0.5) {
          state.pos.y = bMinY - state.height;
          state.vel.y = 0;
        }
      }
    }
  }

  // Spatial Grid query for static blocks
  const queryMinY = Math.min(prevY, state.pos.y) - 0.2;
  const queryMaxY = Math.max(prevY, state.pos.y) + state.height + 0.2;
  const verticalCandidates = grid.queryAABB(
    pMinX - 0.1,
    pMaxX + 0.1,
    queryMinY,
    queryMaxY,
    pMinZ - 0.1,
    pMaxZ + 0.1
  );

  let steppedBlock: BlockEntity | null = null;
  let highestGroundY = -Infinity;

  for (const block of verticalCandidates) {
    if (pMaxX > block.minX && pMinX < block.maxX && pMaxZ > block.minZ && pMinZ < block.maxZ) {
      if (pMinY <= block.maxY && pMaxY >= block.minY) {
        // Landing on top of block
        if (state.vel.y <= 0 && prevY >= block.maxY - 0.7) {
          if (block.maxY > highestGroundY) {
            highestGroundY = block.maxY;
            steppedBlock = block;
          }
        } else if (state.vel.y > 0 && pMaxY > block.minY && prevY + state.height <= block.minY + 0.5) {
          // Ceiling collision
          state.pos.y = block.minY - state.height;
          state.vel.y = 0;
        }
      }
    }
  }

  // Land firmly on the highest ground stepped on
  if (steppedBlock && highestGroundY > -Infinity) {
    state.pos.y = highestGroundY;
    state.vel.y = 0;
    state.isGrounded = true;

    // Trigger block-specific interactions
    if (steppedBlock.def.type === 'bounce') {
      state.vel.y = 35;
      state.isGrounded = false;
      soundFX.playBounce();
      particles.spawnRing(state.pos, 0x7c4dff);
      particles.spawnBurst(state.pos, 0xa855f7, 12, 8);
    } else if (steppedBlock.def.type === 'tornado') {
      // 회오리 점프대: massive vortex launch + spin
      state.vel.y = 38;
      state.isGrounded = false;
      state.tornadoSpinTimer = 0.8;
      soundFX.playTornado();
      particles.spawnTornadoVortex(state.pos);
    } else if (steppedBlock.def.type === 'speed') {
      state.boostTimer = 0.5;
      soundFX.playSpeed();
      particles.spawnBurst(state.pos, 0x10b981, 8, 6);
    } else if (steppedBlock.def.type === 'checkpoint') {
      // Smooth checkpoint registration without artificial velocity brake or wall-like deceleration
      let targetIdx = steppedBlock.stageId;
      if (targetIdx === undefined) {
        targetIdx = STAGES.findIndex(
          (s) =>
            Math.abs(s.pos.x - steppedBlock!.x) <= BLOCK_SIZE &&
            Math.abs(s.pos.y - steppedBlock!.y) <= BLOCK_SIZE * 2 &&
            Math.abs(s.pos.z - steppedBlock!.z) <= BLOCK_SIZE
        );
      }
      if (targetIdx !== undefined && targetIdx !== -1) {
        onCheckpointReached(targetIdx);
      }
    } else if (steppedBlock.def.type === 'lava') {
      // Lava is steppable! Player safely stands on it with fiery burst
      if (Math.random() < 0.25) {
        particles.spawnBurst(state.pos, 0xef4444, 4, 3);
      }
    }
  }

  // Coyote time trigger when walking off edge
  if (wasGrounded && !state.isGrounded && state.vel.y <= 0) {
    state.coyoteTimer = 0.12;
  }

  // 2. Horizontal X Movement & Collision
  state.pos.x += state.vel.x * dt;
  pMinX = state.pos.x - state.radius;
  pMaxX = state.pos.x + state.radius;
  pMinY = state.pos.y + 0.25; // Slightly above ground so floor isn't treated as a wall
  pMaxY = state.pos.y + state.height;
  pMinZ = state.pos.z - state.radius;
  pMaxZ = state.pos.z + state.radius;

  const xCandidates = grid.queryAABB(
    pMinX,
    pMaxX,
    pMinY,
    pMaxY,
    pMinZ,
    pMaxZ
  );

  for (const block of xCandidates) {
    if (block.def.type === 'ladder') continue; // Ladders do not block horizontal motion
    if (pMaxY > block.minY && pMinY < block.maxY && pMaxZ > block.minZ && pMinZ < block.maxZ) {
      if (pMaxX > block.minX && pMinX < block.maxX) {
        if (state.vel.x > 0) {
          state.pos.x = block.minX - state.radius;
        } else if (state.vel.x < 0) {
          state.pos.x = block.maxX + state.radius;
        }
        state.vel.x = 0;
      }
    }
  }

  // 3. Horizontal Z Movement & Collision
  state.pos.z += state.vel.z * dt;
  pMinX = state.pos.x - state.radius;
  pMaxX = state.pos.x + state.radius;
  pMinY = state.pos.y + 0.25;
  pMaxY = state.pos.y + state.height;
  pMinZ = state.pos.z - state.radius;
  pMaxZ = state.pos.z + state.radius;

  const zCandidates = grid.queryAABB(
    pMinX,
    pMaxX,
    pMinY,
    pMaxY,
    pMinZ,
    pMaxZ
  );

  for (const block of zCandidates) {
    if (block.def.type === 'ladder') continue; // Ladders do not block horizontal motion
    if (pMaxY > block.minY && pMinY < block.maxY && pMaxX > block.minX && pMinX < block.maxX) {
      if (pMaxZ > block.minZ && pMinZ < block.maxZ) {
        if (state.vel.z > 0) {
          state.pos.z = block.minZ - state.radius;
        } else if (state.vel.z < 0) {
          state.pos.z = block.maxZ + state.radius;
        }
        state.vel.z = 0;
      }
    }
  }

  // Fall into void death: quick respawn when falling well below current stage height
  if (state.pos.y < currentStageY - 18 || state.pos.y < -20) {
    onPlayerDeath();
  }
}
