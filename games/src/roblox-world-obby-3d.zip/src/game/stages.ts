import { BlockTypeId, StageInfo } from '../types';

export const BLOCK_SIZE = 2;
export const TOTAL_STAGES = 100;

export interface MovingPlatformData {
  id: string;
  basePos: { x: number; y: number; z: number };
  axis: 'x' | 'y' | 'z';
  amplitude: number;
  speed: number;
  typeId: BlockTypeId;
}

export interface GeneratedBlock {
  x: number;
  y: number;
  z: number;
  typeId: BlockTypeId;
  stageId?: number;
}

export interface StarCollectible {
  x: number;
  y: number;
  z: number;
  stageIdx: number;
}

// Generate the list of 100 stages
export function generateStagesList(): StageInfo[] {
  const stages: StageInfo[] = [];
  let cx = 0;
  let cy = 0;
  let cz = 0;

  for (let i = 0; i < TOTAL_STAGES; i++) {
    if (i === 0) {
      stages.push({
        id: 0,
        name: '시작의 평원 (Stage 1)',
        theme: 'Starter',
        pos: { x: 0, y: 1, z: 0 },
        description: '튜토리얼 점프와 체크포인트',
      });
    } else if (i === TOTAL_STAGES - 1) {
      // Final Stage
      const angle = i * 0.38;
      const dist = 16;
      cx += Math.sin(angle) * dist;
      cz -= Math.cos(angle) * dist;
      cy += 2;

      const rx = Math.round(cx / BLOCK_SIZE) * BLOCK_SIZE;
      const ry = Math.round(cy / BLOCK_SIZE) * BLOCK_SIZE + 1;
      const rz = Math.round(cz / BLOCK_SIZE) * BLOCK_SIZE;

      stages.push({
        id: i,
        name: '황금의 전당 (Stage 100) 🏆',
        theme: 'Victory Summit',
        pos: { x: rx, y: ry, z: rz },
        description: '최종 챔피언 정상! 모든 도전을 완주하세요.',
      });
    } else {
      const angle = i * 0.38;
      const dist = 12 + (i % 4) * 2;
      cx += Math.sin(angle) * dist;
      cz -= Math.cos(angle) * dist;
      cy += 2;

      const rx = Math.round(cx / BLOCK_SIZE) * BLOCK_SIZE;
      const ry = Math.round(cy / BLOCK_SIZE) * BLOCK_SIZE + 1;
      const rz = Math.round(cz / BLOCK_SIZE) * BLOCK_SIZE;

      let theme = 'Grassland';
      let description = '파쿠르 챌린지';

      if (i >= 4 && i < 14) {
        theme = 'Truss Ladder (사다리 타워)';
        description = '사다리를 붙잡고 위로 등반하세요 (W / ↑ 키)';
      } else if (i >= 14 && i < 28) {
        theme = 'Whirlwind Jump (회오리 점프)';
        description = '회오리 점프대로 하늘 높이 솟구치세요!';
      } else if (i >= 28 && i < 42) {
        theme = 'Neon Bounce';
        description = '네온 트램펄린 도약 챌린지';
      } else if (i >= 42 && i < 58) {
        theme = 'Tornado Spiral (회오리 나선 코스)';
        description = '회오리형 나선 발판을 밟고 점프하세요';
      } else if (i >= 58 && i < 72) {
        theme = 'Lava Inferno & Ladder';
        description = '용암 지대와 공중 사다리 파쿠르';
      } else if (i >= 72 && i < 86) {
        theme = 'Sky High Glass & Ladders';
        description = '투명 유리 발판과 고공 사다리 등반';
      } else if (i >= 86) {
        theme = 'Void Cyclone Gauntlet';
        description = '회오리 점프와 사다리가 결합된 궁극의 시련';
      }

      stages.push({
        id: i,
        name: `Stage ${i + 1}`,
        theme,
        pos: { x: rx, y: ry, z: rz },
        description,
      });
    }
  }

  return stages;
}

export const STAGES = generateStagesList();

// Helper to verify whether coordinates interfere with or cover any stage checkpoint platform
function isCheckpointProtectedZone(x: number, y: number, z: number): boolean {
  for (let i = 0; i < STAGES.length; i++) {
    const st = STAGES[i];
    const isStage0 = st.id === 0;
    const hLimit = isStage0 ? 7.2 : 3.4;
    const dx = Math.abs(x - st.pos.x);
    const dz = Math.abs(z - st.pos.z);

    if (dx <= hLimit && dz <= hLimit) {
      // Any block from the platform layer (pos.y - 1) up to player head/star space (pos.y + 8)
      // would block, bury, or cover the checkpoint platform
      if (y >= st.pos.y - 1 && y <= st.pos.y + 8) {
        return true;
      }
    }
  }
  return false;
}

// Generate world blocks, stars, and moving platforms
export function generateWorldData() {
  const blocks: GeneratedBlock[] = [];
  const stars: StarCollectible[] = [];
  const movingPlatforms: MovingPlatformData[] = [];
  const blockCoordSet = new Set<string>();

  const addBlockSafely = (
    x: number,
    y: number,
    z: number,
    typeId: BlockTypeId,
    stageId: number,
    isPlatformBlock: boolean = false
  ): boolean => {
    // Non-platform obstacle blocks must never cover or obstruct any checkpoint
    if (!isPlatformBlock && isCheckpointProtectedZone(x, y, z)) {
      return false;
    }

    const key = `${x},${y},${z}`;
    if (blockCoordSet.has(key)) {
      return false; // Prevent duplicate blocks at the same coordinate
    }
    blockCoordSet.add(key);

    blocks.push({ x, y, z, typeId, stageId });
    return true;
  };

  // Stage 1 Base Ground (7x7 safe grass starting plaza)
  for (let x = -6; x <= 6; x += BLOCK_SIZE) {
    for (let z = -6; z <= 6; z += BLOCK_SIZE) {
      const isCenter = x === 0 && z === 0;
      addBlockSafely(
        x,
        0,
        z,
        isCenter ? 'checkpoint' : 'grass',
        0,
        true // platform block
      );
    }
  }

  // Connect every stage to the next with varied parkour obstacles
  for (let s = 0; s < TOTAL_STAGES - 1; s++) {
    const s1 = STAGES[s];
    const s2 = STAGES[s + 1];

    // Checkpoint landing pad: 3x3 sturdy foundation so the player never slides off on respawn
    for (let dx = -BLOCK_SIZE; dx <= BLOCK_SIZE; dx += BLOCK_SIZE) {
      for (let dz = -BLOCK_SIZE; dz <= BLOCK_SIZE; dz += BLOCK_SIZE) {
        const isCenter = dx === 0 && dz === 0;
        const padType: BlockTypeId = isCenter
          ? 'checkpoint'
          : s2.id === TOTAL_STAGES - 1
            ? 'gold'
            : 'stone';

        addBlockSafely(
          s2.pos.x + dx,
          s2.pos.y - 1, // center at y-1 means top surface is exactly at s2.pos.y
          s2.pos.z + dz,
          padType,
          s2.id,
          true // platform block
        );
      }
    }

    // Add star collectible hovering cleanly above the checkpoint
    stars.push({
      x: s2.pos.x,
      y: s2.pos.y + 1.6,
      z: s2.pos.z,
      stageIdx: s2.id,
    });

    const dx = s2.pos.x - s1.pos.x;
    const dy = s2.pos.y - s1.pos.y;
    const dz = s2.pos.z - s1.pos.z;
    const hDist = Math.hypot(dx, dz);
    const dirX = dx / (hDist || 1);
    const dirZ = dz / (hDist || 1);

    // Platform clearance: each platform extends 2 units, plus buffer = 3.8 units
    const startDist = 3.8;
    const endDist = Math.max(startDist + 2.0, hDist - 3.8);
    const usableSpan = Math.max(2.0, endDist - startDist);

    // Determine obstacle type based on theme
    const isLadderStage = s1.theme.includes('Ladder') || s % 6 === 2;
    const isWhirlwindStage = s1.theme.includes('Whirlwind') || s1.theme.includes('Cyclone') || s % 6 === 3;
    const isSpiralStage = s1.theme.includes('Spiral') || s % 6 === 4;

    if (isSpiralStage) {
      // 회오리 나선 점프 코스: Helix spiral steps cleanly between platforms
      const spiralCount = 3;
      for (let sp = 1; sp <= spiralCount; sp++) {
        const frac = sp / (spiralCount + 1);
        const currDist = startDist + usableSpan * frac;
        const spinAngle = s * 0.7 + (sp / spiralCount) * Math.PI * 1.5;
        const radius = 2.0;

        const mx = s1.pos.x + dirX * currDist;
        const my = s1.pos.y + dy * frac;
        const mz = s1.pos.z + dirZ * currDist;

        const bx = Math.round((mx + Math.cos(spinAngle) * radius) / BLOCK_SIZE) * BLOCK_SIZE;
        const by = Math.round(my / BLOCK_SIZE) * BLOCK_SIZE - 1;
        const bz = Math.round((mz + Math.sin(spinAngle) * radius) / BLOCK_SIZE) * BLOCK_SIZE;

        const typeId: BlockTypeId = sp === 2 ? 'tornado' : sp % 2 === 0 ? 'neon_pink' : 'neon_blue';
        addBlockSafely(bx, by, bz, typeId, s, false);
      }
    } else if (isLadderStage) {
      // 사다리 타워 코스: Place in midpoint between platforms
      const midDist = (startDist + endDist) / 2;
      const midX = Math.round((s1.pos.x + dirX * midDist) / BLOCK_SIZE) * BLOCK_SIZE;
      const midY = Math.round((s1.pos.y + dy * 0.5) / BLOCK_SIZE) * BLOCK_SIZE - 1;
      const midZ = Math.round((s1.pos.z + dirZ * midDist) / BLOCK_SIZE) * BLOCK_SIZE;

      // Base block
      addBlockSafely(midX, midY, midZ, 'stone', s, false);

      // Vertical Ladder blocks (2 blocks high)
      for (let ly = 1; ly <= 2; ly++) {
        addBlockSafely(midX, midY + ly * BLOCK_SIZE, midZ, 'ladder', s, false);
      }

      // Top resting/jumping pad at ladder head
      addBlockSafely(midX, midY + 3 * BLOCK_SIZE, midZ, 'wood', s, false);
    } else {
      // Parkour path steps cleanly spanning between s1 and s2
      const numSteps = usableSpan > 8 ? 3 : usableSpan > 4 ? 2 : 1;
      for (let step = 1; step <= numSteps; step++) {
        const frac = step / (numSteps + 1);
        const currDist = startDist + usableSpan * frac;

        const bx = Math.round((s1.pos.x + dirX * currDist) / BLOCK_SIZE) * BLOCK_SIZE;
        const by = Math.round((s1.pos.y + dy * frac) / BLOCK_SIZE) * BLOCK_SIZE - 1;
        const bz = Math.round((s1.pos.z + dirZ * currDist) / BLOCK_SIZE) * BLOCK_SIZE;

        let typeId: BlockTypeId = 'brick';

        if (isWhirlwindStage && step === 1) {
          typeId = 'tornado'; // 회오리 점프대
        } else if (s >= 14 && s < 28) {
          typeId = step === 1 ? 'tornado' : 'neon_blue';
        } else if (s >= 28 && s < 42) {
          typeId = step % 2 === 0 ? 'trampoline' : 'neon_pink';
        } else if (s >= 58 && s < 72) {
          typeId = step === 1 ? 'ladder' : step === 2 ? 'lava' : 'stone';
        } else if (s >= 72 && s < 86) {
          typeId = step % 2 === 0 ? 'glass' : 'neon_blue';
        } else if (s >= 86) {
          typeId = step === 1 ? 'tornado' : step === 2 ? 'ladder' : 'stone';
        } else {
          typeId = step % 3 === 1 ? 'wood' : 'brick';
        }

        // Add dynamic moving platform occasionally
        if (s > 20 && s % 7 === 1 && step === 2 && !isCheckpointProtectedZone(bx, by, bz)) {
          movingPlatforms.push({
            id: `moving_${s}_${step}`,
            basePos: { x: bx, y: by, z: bz },
            axis: s % 2 === 0 ? 'x' : 'z',
            amplitude: 2.5,
            speed: 1.5,
            typeId: 'neon_blue',
          });
        } else {
          addBlockSafely(bx, by, bz, typeId, s, false);
        }
      }
    }
  }

  // Final Stage 100 Monument
  const finalStage = STAGES[TOTAL_STAGES - 1];
  // 4 Golden Corner Pillars
  const offsets = [
    { dx: -BLOCK_SIZE * 2, dz: -BLOCK_SIZE * 2 },
    { dx: BLOCK_SIZE * 2, dz: -BLOCK_SIZE * 2 },
    { dx: -BLOCK_SIZE * 2, dz: BLOCK_SIZE * 2 },
    { dx: BLOCK_SIZE * 2, dz: BLOCK_SIZE * 2 },
  ];
  offsets.forEach((off) => {
    for (let py = 0; py <= 6; py += BLOCK_SIZE) {
      addBlockSafely(
        finalStage.pos.x + off.dx,
        finalStage.pos.y + py,
        finalStage.pos.z + off.dz,
        'gold',
        finalStage.id,
        true
      );
    }
  });

  return { blocks, stars, movingPlatforms };
}
