import * as THREE from 'three';
import { BlockDef, BlockTypeId } from '../types';

export const BLOCK_DEFS: Record<BlockTypeId, BlockDef> = {
  grass: { id: 'grass', name: '잔디', color: 0x4caf50, type: 'normal' },
  brick: { id: 'brick', name: '벽돌', color: 0xe53935, type: 'normal' },
  stone: { id: 'stone', name: '석재', color: 0x64748b, type: 'normal' },
  wood: { id: 'wood', name: '나무', color: 0x8d6e63, type: 'normal' },
  glass: { id: 'glass', name: '유리', color: 0x38bdf8, opacity: 0.55, type: 'normal' },
  trampoline: {
    id: 'trampoline',
    name: '트램펄린',
    color: 0x7c4dff,
    type: 'bounce',
    emissive: 0x5b21b6,
    emissiveIntensity: 0.3,
  },
  speed: {
    id: 'speed',
    name: '가속 패드',
    color: 0x10b981,
    type: 'speed',
    emissive: 0x059669,
    emissiveIntensity: 0.4,
  },
  lava: {
    id: 'lava',
    name: '용암 킬블록',
    color: 0xef4444,
    type: 'lava',
    emissive: 0xdc2626,
    emissiveIntensity: 0.7,
  },
  checkpoint: {
    id: 'checkpoint',
    name: '체크포인트',
    color: 0xfacc15,
    type: 'checkpoint',
    emissive: 0xeab308,
    emissiveIntensity: 0.4,
  },
  gold: { id: 'gold', name: '황금', color: 0xffd700, type: 'normal' },
  neon_blue: {
    id: 'neon_blue',
    name: '네온 블루',
    color: 0x06b6d4,
    type: 'normal',
    emissive: 0x0891b2,
    emissiveIntensity: 0.4,
  },
  neon_pink: {
    id: 'neon_pink',
    name: '네온 핑크',
    color: 0xec4899,
    type: 'normal',
    emissive: 0xdb2777,
    emissiveIntensity: 0.4,
  },
  ladder: {
    id: 'ladder',
    name: '사다리 (트러스)',
    color: 0xf59e0b,
    type: 'ladder',
    emissive: 0xd97706,
    emissiveIntensity: 0.25,
  },
  tornado: {
    id: 'tornado',
    name: '회오리 점프대',
    color: 0x06b6d4,
    type: 'tornado',
    emissive: 0x0284c7,
    emissiveIntensity: 0.55,
  },
};

export function createBlockMaterial(typeId: BlockTypeId): THREE.Material {
  const def = BLOCK_DEFS[typeId] || BLOCK_DEFS.brick;

  if (def.opacity) {
    return new THREE.MeshStandardMaterial({
      color: def.color,
      transparent: true,
      opacity: def.opacity,
      roughness: 0.1,
      metalness: 0.1,
    });
  }

  // Draw procedural texture with Roblox stud pattern on canvas
  const canvas = document.createElement('canvas');
  canvas.width = 64;
  canvas.height = 64;
  const ctx = canvas.getContext('2d')!;

  const hex = '#' + def.color.toString(16).padStart(6, '0');
  ctx.fillStyle = hex;
  ctx.fillRect(0, 0, 64, 64);

  // Border bevel
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.28)';
  ctx.lineWidth = 4;
  ctx.strokeRect(2, 2, 60, 60);

  ctx.strokeStyle = 'rgba(0, 0, 0, 0.22)';
  ctx.strokeRect(4, 4, 56, 56);

  // Studs or icons
  if (def.id === 'trampoline') {
    // Spiral bounce icon
    ctx.fillStyle = '#f59e0b';
    ctx.beginPath();
    ctx.arc(32, 32, 18, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(32, 32, 10, 0, Math.PI * 2);
    ctx.stroke();
  } else if (def.id === 'speed') {
    // Forward chevrons
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.moveTo(32, 12);
    ctx.lineTo(48, 28);
    ctx.lineTo(40, 28);
    ctx.lineTo(40, 52);
    ctx.lineTo(24, 52);
    ctx.lineTo(24, 28);
    ctx.lineTo(16, 28);
    ctx.closePath();
    ctx.fill();
  } else if (def.id === 'lava') {
    // Hot spots
    ctx.fillStyle = '#fef08a';
    ctx.beginPath();
    ctx.arc(20, 24, 8, 0, Math.PI * 2);
    ctx.arc(44, 40, 10, 0, Math.PI * 2);
    ctx.fill();
  } else if (def.id === 'ladder') {
    // Classic Roblox Truss / Ladder: 2 vertical rails and 4 horizontal crossbars
    ctx.fillStyle = '#b45309';
    ctx.fillRect(8, 0, 10, 64);
    ctx.fillRect(46, 0, 10, 64);
    // Ladder Rungs
    ctx.fillStyle = '#fef3c7';
    [10, 24, 38, 52].forEach((ry) => {
      ctx.fillRect(14, ry, 36, 6);
    });
    // Diagonal truss struts
    ctx.strokeStyle = 'rgba(180, 83, 9, 0.7)';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(18, 10);
    ctx.lineTo(46, 38);
    ctx.moveTo(18, 38);
    ctx.lineTo(46, 52);
    ctx.stroke();
  } else if (def.id === 'tornado') {
    // Whirlwind / Tornado Vortex spiral icon
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 4;
    ctx.beginPath();
    // Swirling spiral
    for (let a = 0; a < Math.PI * 4; a += 0.2) {
      const r = 4 + a * 4.5;
      const sx = 32 + Math.cos(a) * r;
      const sy = 32 + Math.sin(a) * r;
      if (a === 0) ctx.moveTo(sx, sy);
      else ctx.lineTo(sx, sy);
    }
    ctx.stroke();

    // Central vortex core
    ctx.fillStyle = '#a5f3fc';
    ctx.beginPath();
    ctx.arc(32, 32, 6, 0, Math.PI * 2);
    ctx.fill();
  } else if (def.id === 'checkpoint') {
    // Star or checkered flag icon
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(32, 32, 16, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#f59e0b';
    ctx.beginPath();
    ctx.arc(32, 32, 10, 0, Math.PI * 2);
    ctx.fill();
  } else if (def.id === 'grass') {
    // Top studs
    ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
    const studs = [
      [18, 18],
      [46, 18],
      [18, 46],
      [46, 46],
    ];
    studs.forEach(([sx, sy]) => {
      ctx.beginPath();
      ctx.arc(sx, sy, 8, 0, Math.PI * 2);
      ctx.fill();
    });
  } else {
    // Standard Roblox 4-stud surface
    ctx.fillStyle = 'rgba(255, 255, 255, 0.18)';
    const studs = [
      [18, 18],
      [46, 18],
      [18, 46],
      [46, 46],
    ];
    studs.forEach(([sx, sy]) => {
      ctx.beginPath();
      ctx.arc(sx, sy, 7, 0, Math.PI * 2);
      ctx.fill();
    });
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;

  return new THREE.MeshStandardMaterial({
    map: texture,
    roughness: def.id === 'gold' ? 0.2 : 0.55,
    metalness: def.id === 'gold' ? 0.8 : 0.05,
    emissive: def.emissive ? new THREE.Color(def.emissive) : new THREE.Color(0x000000),
    emissiveIntensity: def.emissiveIntensity || 0,
  });
}
