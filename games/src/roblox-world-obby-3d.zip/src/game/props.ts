import * as THREE from 'three';

// Create 3D 5-pointed star geometry
export function createStarGeometry(): THREE.BufferGeometry {
  const shape = new THREE.Shape();
  const points = 5;
  const outerRadius = 0.7;
  const innerRadius = 0.32;

  for (let i = 0; i < points * 2; i++) {
    const r = i % 2 === 0 ? outerRadius : innerRadius;
    const a = (i / (points * 2)) * Math.PI * 2 - Math.PI / 2;
    const x = Math.cos(a) * r;
    const y = Math.sin(a) * r;
    if (i === 0) shape.moveTo(x, y);
    else shape.lineTo(x, y);
  }
  shape.closePath();

  const extrudeSettings = {
    depth: 0.28,
    bevelEnabled: true,
    bevelSegments: 2,
    steps: 1,
    bevelSize: 0.06,
    bevelThickness: 0.06,
  };

  const geo = new THREE.ExtrudeGeometry(shape, extrudeSettings);
  geo.center();
  return geo;
}

// Create checkpoint flag pole with flag cloth (100% non-colliding pass-through prop)
export function createCheckpointFlag(isUnlocked: boolean): THREE.Group {
  const group = new THREE.Group();

  // Pole
  const poleGeo = new THREE.CylinderGeometry(0.08, 0.08, 3.2, 8);
  const poleMat = new THREE.MeshStandardMaterial({
    color: 0x94a3b8,
    metalness: 0.7,
    roughness: 0.3,
  });
  const pole = new THREE.Mesh(poleGeo, poleMat);
  pole.position.y = 1.6;
  pole.castShadow = true;
  // Ensure flag pole has no collision or raycast blocking
  pole.raycast = () => {};
  group.add(pole);

  // Ball top
  const ballGeo = new THREE.SphereGeometry(0.18, 8, 8);
  const ballMat = new THREE.MeshStandardMaterial({
    color: 0xf59e0b,
    metalness: 0.8,
    roughness: 0.2,
  });
  const ball = new THREE.Mesh(ballGeo, ballMat);
  ball.position.y = 3.2;
  ball.raycast = () => {};
  group.add(ball);

  // Flag cloth
  const flagGeo = new THREE.PlaneGeometry(1.2, 0.75, 4, 2);
  const flagMat = new THREE.MeshStandardMaterial({
    color: isUnlocked ? 0x10b981 : 0xef4444,
    side: THREE.DoubleSide,
    roughness: 0.5,
  });
  const flag = new THREE.Mesh(flagGeo, flagMat);
  flag.position.set(0.6, 2.7, 0);
  flag.castShadow = true;
  flag.raycast = () => {};
  group.add(flag);

  group.userData = { flagMesh: flag, flagMat, isNonCollidable: true };
  return group;
}

// Create 3D Leaderboard Billboard Stand for the starting plaza
export function createLeaderboardStand(): THREE.Group {
  const stand = new THREE.Group();

  // Base platform
  const baseGeo = new THREE.BoxGeometry(4.4, 0.4, 1.6);
  const baseMat = new THREE.MeshStandardMaterial({
    color: 0x1e293b,
    roughness: 0.4,
    metalness: 0.6,
  });
  const base = new THREE.Mesh(baseGeo, baseMat);
  base.position.y = 0.2;
  base.castShadow = true;
  base.receiveShadow = true;
  stand.add(base);

  // Side pillars
  const pillarGeo = new THREE.BoxGeometry(0.35, 4.6, 0.35);
  const pillarMat = new THREE.MeshStandardMaterial({
    color: 0xf59e0b,
    metalness: 0.8,
    roughness: 0.2,
  });
  const leftPillar = new THREE.Mesh(pillarGeo, pillarMat);
  leftPillar.position.set(-2.0, 2.5, 0);
  leftPillar.castShadow = true;
  stand.add(leftPillar);

  const rightPillar = new THREE.Mesh(pillarGeo, pillarMat);
  rightPillar.position.set(2.0, 2.5, 0);
  rightPillar.castShadow = true;
  stand.add(rightPillar);

  // Top header banner
  const headerGeo = new THREE.BoxGeometry(4.4, 0.8, 0.4);
  const headerMat = new THREE.MeshStandardMaterial({
    color: 0xb45309,
    metalness: 0.5,
    roughness: 0.3,
    emissive: 0x78350f,
    emissiveIntensity: 0.4,
  });
  const header = new THREE.Mesh(headerGeo, headerMat);
  header.position.set(0, 4.5, 0);
  stand.add(header);

  // Billboard Board Display Canvas
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 384;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    // Dark background with gradient
    const grad = ctx.createLinearGradient(0, 0, 0, 384);
    grad.addColorStop(0, '#0f172a');
    grad.addColorStop(1, '#1e1b4b');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 512, 384);

    // Border
    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 8;
    ctx.strokeRect(4, 4, 504, 376);

    // Title
    ctx.fillStyle = '#fef08a';
    ctx.font = 'bold 30px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('🏆 환생 명예의 전당 🏆', 256, 45);

    ctx.font = 'bold 18px sans-serif';
    ctx.fillStyle = '#93c5fd';
    ctx.fillText('REBIRTH LEADERBOARD', 256, 75);

    // Divider
    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(30, 90);
    ctx.lineTo(482, 90);
    ctx.stroke();

    // Top players list
    const topList = [
      { rank: '1위 👑', name: '불꽃파쿠러', rebirth: '환생 58회', color: '#fbbf24' },
      { rank: '2위 🥈', name: '도도_ObbyKing', rebirth: '환생 43회', color: '#e2e8f0' },
      { rank: '3위 🥉', name: '민트초코러너', rebirth: '환생 37회', color: '#f97316' },
      { rank: '4위 ⭐', name: '하늘달리기', rebirth: '환생 29회', color: '#38bdf8' },
    ];

    topList.forEach((item, idx) => {
      const y = 130 + idx * 48;
      ctx.fillStyle = idx % 2 === 0 ? 'rgba(30, 41, 59, 0.7)' : 'rgba(15, 23, 42, 0.7)';
      ctx.fillRect(30, y - 26, 452, 40);

      ctx.fillStyle = item.color;
      ctx.font = 'bold 20px sans-serif';
      ctx.textAlign = 'left';
      ctx.fillText(item.rank, 45, y);

      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 20px sans-serif';
      ctx.fillText(item.name, 160, y);

      ctx.fillStyle = '#fde047';
      ctx.font = 'bold 20px monospace';
      ctx.textAlign = 'right';
      ctx.fillText(item.rebirth, 465, y);
    });

    // Prompt footer
    ctx.fillStyle = '#4ade80';
    ctx.font = 'bold 20px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('👉 클릭하여 전체 순위표 보기', 256, 350);
  }

  const texture = new THREE.CanvasTexture(canvas);
  const screenGeo = new THREE.PlaneGeometry(3.8, 2.8);
  const screenMat = new THREE.MeshBasicMaterial({
    map: texture,
    side: THREE.DoubleSide,
  });
  const screenFront = new THREE.Mesh(screenGeo, screenMat);
  screenFront.position.set(0, 2.7, 0.2);
  stand.add(screenFront);

  const screenBack = new THREE.Mesh(screenGeo, screenMat);
  screenBack.position.set(0, 2.7, -0.2);
  screenBack.rotation.y = Math.PI;
  stand.add(screenBack);

  stand.userData = { isLeaderboardStand: true };
  return stand;
}
