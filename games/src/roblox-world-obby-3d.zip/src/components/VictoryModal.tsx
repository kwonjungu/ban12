import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Trophy, Star, Skull, Clock, RotateCcw, ArrowRight, Sparkles } from 'lucide-react';
import { TOTAL_STAGES } from '../game/stages';
import { soundFX } from '../game/audio';

interface VictoryModalProps {
  isOpen: boolean;
  elapsedSeconds: number;
  deaths: number;
  starsCount: number;
  rebirthCount: number;
  onRebirth: () => void;
  onRestart: () => void;
  onContinue: () => void;
}

export const VictoryModal: React.FC<VictoryModalProps> = ({
  isOpen,
  elapsedSeconds,
  deaths,
  starsCount,
  rebirthCount,
  onRebirth,
  onRestart,
  onContinue,
}) => {
  useEffect(() => {
    if (!isOpen) return;

    soundFX.playFanfare();

    // Fireworks confetti blast
    const count = 200;
    const defaults = {
      origin: { y: 0.7 },
    };

    function fire(particleRatio: number, opts: confetti.Options) {
      confetti({
        ...defaults,
        ...opts,
        particleCount: Math.floor(count * particleRatio),
      });
    }

    fire(0.25, { spread: 26, startVelocity: 55 });
    fire(0.2, { spread: 60 });
    fire(0.35, { spread: 100, decay: 0.91, scalar: 0.8 });
    fire(0.1, { spread: 120, startVelocity: 25, decay: 0.92, scalar: 1.2 });
    fire(0.1, { spread: 120, startVelocity: 45 });
  }, [isOpen]);

  if (!isOpen) return null;

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md flex items-center justify-center z-50 p-4">
      <div className="bg-gradient-to-b from-slate-900 via-slate-900 to-indigo-950 border border-amber-500/50 rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl relative text-center">
        {/* Trophy icon */}
        <div className="w-20 h-20 bg-amber-500/20 border-2 border-amber-400 rounded-full flex items-center justify-center mx-auto mb-4 text-amber-300 shadow-xl animate-bounce">
          <Trophy className="w-10 h-10 fill-amber-400" />
        </div>

        <h2 className="text-2xl sm:text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-yellow-400 to-amber-200 mb-1">
          오비 파쿠르 완주!
        </h2>
        <p className="text-sm text-slate-300 mb-5">
          100개 스테이지의 험난한 파쿠르를 모두 정복하고 황금의 전당에 도달했습니다!
        </p>

        {/* Rebirth Grand Callout */}
        <div className="bg-amber-500/15 border border-amber-400/40 rounded-2xl p-3.5 mb-5 text-center">
          <div className="text-xs text-amber-300 font-bold mb-1 flex items-center justify-center gap-1">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>현재 환생 기록: {rebirthCount}회</span>
          </div>
          <div className="text-xs text-slate-300">
            지금 환생하면 <span className="text-amber-300 font-black">환생 {rebirthCount + 1}회</span>를 달성하고 환생 순위표 상위권으로 도약합니다!
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-3 gap-2 mb-6">
          <div className="bg-slate-800/80 p-3 rounded-2xl border border-slate-700">
            <Clock className="w-5 h-5 text-sky-400 mx-auto mb-1" />
            <div className="text-[11px] text-slate-400 font-medium">클리어 타임</div>
            <div className="text-sm font-black text-white font-mono">{formatTime(elapsedSeconds)}</div>
          </div>

          <div className="bg-slate-800/80 p-3 rounded-2xl border border-slate-700">
            <Star className="w-5 h-5 text-amber-400 fill-amber-400 mx-auto mb-1" />
            <div className="text-[11px] text-slate-400 font-medium">수집한 별</div>
            <div className="text-sm font-black text-white font-mono">
              {starsCount} / {TOTAL_STAGES - 1}
            </div>
          </div>

          <div className="bg-slate-800/80 p-3 rounded-2xl border border-slate-700">
            <Skull className="w-5 h-5 text-rose-400 mx-auto mb-1" />
            <div className="text-[11px] text-slate-400 font-medium">총 데스 카운트</div>
            <div className="text-sm font-black text-white font-mono">{deaths}회</div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col gap-2.5">
          <button
            onClick={() => {
              soundFX.playClick();
              onRebirth();
            }}
            className="btn-game w-full bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-black px-6 py-3.5 rounded-xl border border-amber-200 text-sm flex items-center justify-center gap-2 shadow-xl animate-pulse cursor-pointer"
          >
            <Sparkles className="w-4 h-4 fill-slate-950" />
            <span>🌟 환생하기 (+1 환생 후 1스테이지로 귀환)</span>
          </button>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-2">
            <button
              onClick={() => {
                soundFX.playClick();
                onContinue();
              }}
              className="btn-game w-full sm:w-1/2 bg-slate-800 hover:bg-slate-700 text-white font-bold px-4 py-2.5 rounded-xl border border-slate-600 text-xs flex items-center justify-center gap-1.5"
            >
              <span>자유 탐험 계속하기</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={() => {
                soundFX.playClick();
                onRestart();
              }}
              className="btn-game w-full sm:w-1/2 bg-slate-700 hover:bg-slate-600 text-slate-200 font-bold px-4 py-2.5 rounded-xl border border-slate-600 text-xs flex items-center justify-center gap-1.5"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>단순 재도전</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
