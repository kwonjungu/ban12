import React from 'react';
import { X, Gamepad2, Keyboard, MousePointer, ShieldCheck } from 'lucide-react';
import { soundFX } from '../game/audio';

interface ControlsModalProps {
  isOpen: boolean;
  practiceMode: boolean;
  onTogglePractice: () => void;
  onClose: () => void;
}

export const ControlsModal: React.FC<ControlsModalProps> = ({
  isOpen,
  practiceMode,
  onTogglePractice,
  onClose,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md flex items-center justify-center z-50 p-3 sm:p-4">
      <div className="bg-slate-900 border border-slate-700/80 rounded-3xl p-5 sm:p-6 max-w-md w-full shadow-2xl relative">
        {/* Close Button */}
        <button
          onClick={() => {
            soundFX.playClick();
            onClose();
          }}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-xl hover:bg-slate-800 transition-colors"
        >
          <X className="w-6 h-6" />
        </button>

        {/* Title */}
        <div className="flex items-center space-x-2.5 mb-4">
          <div className="p-2 rounded-xl bg-sky-500/20 text-sky-400 border border-sky-500/30">
            <Gamepad2 className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-white">게임 조작법 & 꿀팁</h2>
            <p className="text-xs text-slate-400">PC 키보드/마우스 및 모바일 터치 지원</p>
          </div>
        </div>

        {/* Control List */}
        <div className="space-y-2 text-xs sm:text-sm text-slate-300">
          <div className="flex justify-between items-center bg-slate-800/80 p-2.5 rounded-xl border border-slate-700">
            <span className="flex items-center gap-1.5">
              <Keyboard className="w-4 h-4 text-amber-400" />
              캐릭터 이동
            </span>
            <span className="font-mono bg-slate-700 px-2 py-0.5 rounded text-amber-300 font-bold">
              WASD / 방향키 / ㅈㅁㄴㅇ
            </span>
          </div>

          <div className="flex justify-between items-center bg-slate-800/80 p-2.5 rounded-xl border border-slate-700">
            <span className="flex items-center gap-1.5">
              <Keyboard className="w-4 h-4 text-emerald-400" />
              점프 (1단 점프)
            </span>
            <span className="font-mono bg-slate-700 px-2 py-0.5 rounded text-emerald-300 font-bold">
              Spacebar (정통 1단 점프)
            </span>
          </div>

          <div className="flex justify-between items-center bg-slate-800/80 p-2.5 rounded-xl border border-slate-700">
            <span className="flex items-center gap-1.5">
              <span className="text-sm">🪜</span>
              사다리 등반
            </span>
            <span className="font-mono bg-slate-700 px-2 py-0.5 rounded text-amber-300 font-bold">
              W / ↑ 위로, S / ↓ 아래로, Space 도약
            </span>
          </div>

          <div className="flex justify-between items-center bg-slate-800/80 p-2.5 rounded-xl border border-slate-700">
            <span className="flex items-center gap-1.5">
              <span className="text-sm">🌪️</span>
              회오리 점프대 (토네이도)
            </span>
            <span className="font-mono bg-slate-700 px-2 py-0.5 rounded text-cyan-300 font-bold">
              밟으면 고공 회전 도약!
            </span>
          </div>

          <div className="flex justify-between items-center bg-slate-800/80 p-2.5 rounded-xl border border-slate-700">
            <span className="flex items-center gap-1.5">
              <Keyboard className="w-4 h-4 text-sky-400" />
              달리기 / 대시
            </span>
            <span className="font-mono bg-slate-700 px-2 py-0.5 rounded text-sky-300 font-bold">
              Shift 키 누른 채 이동
            </span>
          </div>

          <div className="flex justify-between items-center bg-slate-800/80 p-2.5 rounded-xl border border-slate-700">
            <span className="flex items-center gap-1.5">
              <MousePointer className="w-4 h-4 text-indigo-400" />
              화면 회전 / 시점
            </span>
            <span className="font-mono bg-slate-700 px-2 py-0.5 rounded text-indigo-300 font-bold">
              마우스 우클릭 드래그
            </span>
          </div>

          <div className="flex justify-between items-center bg-slate-800/80 p-2.5 rounded-xl border border-slate-700">
            <span className="flex items-center gap-1.5">
              <MousePointer className="w-4 h-4 text-purple-400" />
              1인칭 ↔ 3인칭 줌
            </span>
            <span className="font-mono bg-slate-700 px-2 py-0.5 rounded text-purple-300 font-bold">
              마우스 휠 스크롤
            </span>
          </div>

          <div className="flex justify-between items-center bg-slate-800/80 p-2.5 rounded-xl border border-slate-700">
            <span className="flex items-center gap-1.5">
              <Keyboard className="w-4 h-4 text-rose-400" />
              체크포인트 재시작
            </span>
            <span className="font-mono bg-slate-700 px-2 py-0.5 rounded text-rose-300 font-bold">
              R 키 (빠른 리스폰)
            </span>
          </div>

          <div className="flex items-center gap-2 bg-amber-500/10 p-2.5 rounded-xl border border-amber-500/30 text-amber-200 text-xs">
            <span className="text-base">🧱</span>
            <span>
              <strong>모든 블록 밟기 지원:</strong> 일반 블록, 체크포인트 발판, 유리, 트램펄린, 무빙 플랫폼 및 용암 블록까지 모든 블록을 안전하게 밟고 올라설 수 있습니다!
            </span>
          </div>
        </div>

        {/* Practice Mode Toggle */}
        <div className="mt-4 p-3 bg-slate-800/60 rounded-2xl border border-purple-500/30 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <ShieldCheck className="w-5 h-5 text-purple-400" />
            <div>
              <div className="text-xs font-bold text-white">무한 연습 모드</div>
              <div className="text-[11px] text-slate-400">용암 무적 & 무제한 다단 점프</div>
            </div>
          </div>
          <button
            onClick={() => {
              soundFX.playClick();
              onTogglePractice();
            }}
            className={`px-3 py-1.5 rounded-xl font-bold text-xs transition-all ${
              practiceMode
                ? 'bg-purple-600 text-white shadow-md'
                : 'bg-slate-700 text-slate-400 hover:text-white'
            }`}
          >
            {practiceMode ? '켜짐 (ON)' : '꺼짐 (OFF)'}
          </button>
        </div>

        {/* Confirm Button */}
        <div className="mt-5 flex justify-end">
          <button
            onClick={() => {
              soundFX.playClick();
              onClose();
            }}
            className="btn-game bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold px-6 py-2 rounded-xl border border-sky-300 text-sm"
          >
            확인했습니다
          </button>
        </div>
      </div>
    </div>
  );
};
