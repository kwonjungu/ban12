import React from 'react';
import { AlertTriangle } from 'lucide-react';
import { soundFX } from '../game/audio';

interface ResetConfirmModalProps {
  isOpen: boolean;
  onConfirm: () => void;
  onClose: () => void;
}

export const ResetConfirmModal: React.FC<ResetConfirmModalProps> = ({
  isOpen,
  onConfirm,
  onClose,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md flex items-center justify-center z-50 p-4">
      <div className="bg-slate-900 border border-rose-600/50 rounded-3xl p-6 max-w-sm w-full shadow-2xl relative text-center">
        <div className="w-16 h-16 bg-rose-500/20 border border-rose-500/40 rounded-full flex items-center justify-center mx-auto mb-4 text-rose-400">
          <AlertTriangle className="w-8 h-8" />
        </div>

        <h3 className="text-xl font-bold text-white mb-2">진행상황 초기화</h3>
        <p className="text-sm text-slate-300 mb-6 leading-relaxed">
          수집한 모든 별과 해금된 100개 스테이지 진행 기록이 초기화됩니다. 처음 1스테이지부터 다시
          시작하시겠습니까?
        </p>

        <div className="flex items-center justify-center space-x-3">
          <button
            onClick={() => {
              soundFX.playClick();
              onClose();
            }}
            className="btn-game bg-slate-800 hover:bg-slate-700 text-white font-bold px-5 py-2.5 rounded-xl border border-slate-600 text-sm"
          >
            취소
          </button>
          <button
            onClick={() => {
              soundFX.playOof();
              onConfirm();
            }}
            className="btn-game bg-rose-600 hover:bg-rose-500 text-white font-bold px-5 py-2.5 rounded-xl border border-rose-400 text-sm"
          >
            초기화하기
          </button>
        </div>
      </div>
    </div>
  );
};
