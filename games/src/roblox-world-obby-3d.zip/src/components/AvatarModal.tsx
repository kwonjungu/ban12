import React, { useState } from 'react';
import { X, Sparkles, Check, Palette } from 'lucide-react';
import { FaceType, HatType, PlayerCustomization } from '../types';
import { soundFX } from '../game/audio';

interface AvatarModalProps {
  isOpen: boolean;
  customization: PlayerCustomization;
  onSave: (cust: PlayerCustomization) => void;
  onClose: () => void;
}

const SHIRT_COLORS = [
  '#1e1e24',
  '#dc2626',
  '#2563eb',
  '#16a34a',
  '#ca8a04',
  '#9333ea',
  '#db2777',
  '#0891b2',
  '#ea580c',
  '#ffffff',
];

const PANTS_COLORS = [
  '#1e293b',
  '#0f172a',
  '#1e3a8a',
  '#3f3f46',
  '#713f12',
  '#831843',
  '#14532d',
  '#f8fafc',
];

const SKIN_TONES = [
  { label: '클래식 옐로우', color: '#f5d76e' },
  { label: '살구빛', color: '#f5e0c3' },
  { label: '탠/골드', color: '#d4a373' },
  { label: '다크 브라운', color: '#8c5332' },
  { label: '쿨 사이언', color: '#67e8f9' },
  { label: '외계인 그린', color: '#86efac' },
];

const HATS: { id: HatType; name: string; icon: string }[] = [
  { id: 'bacon', name: '베이컨 헤어', icon: '🥓' },
  { id: 'crown', name: '황금 왕관', icon: '👑' },
  { id: 'cap', name: '캐주얼 캡', icon: '🧢' },
  { id: 'horns', name: '악마 뿔', icon: '😈' },
  { id: 'halo', name: '천사 헤일로', icon: '😇' },
  { id: 'party', name: '파티 고깔모자', icon: '🎉' },
  { id: 'cat_ears', name: '고양이 귀', icon: '🐱' },
  { id: 'none', name: '모자 없음', icon: '🚫' },
];

const FACES: { id: FaceType; name: string; icon: string }[] = [
  { id: 'smile', name: '클래식 스마일', icon: '🙂' },
  { id: 'cool', name: '선글라스', icon: '😎' },
  { id: 'wink', name: '윙크 & 볼터치', icon: '😉' },
  { id: 'excited', name: '별눈 감탄', icon: '🤩' },
];

export const AvatarModal: React.FC<AvatarModalProps> = ({
  isOpen,
  customization,
  onSave,
  onClose,
}) => {
  const [form, setForm] = useState<PlayerCustomization>(customization);

  if (!isOpen) return null;

  const handleApplyPreset = (preset: Partial<PlayerCustomization>) => {
    soundFX.playClick();
    setForm((prev) => ({ ...prev, ...preset }));
  };

  const handleSave = () => {
    soundFX.playCheckpoint();
    onSave(form);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md flex items-center justify-center z-50 p-3 sm:p-4">
      <div className="bg-slate-900 border border-slate-700/80 rounded-3xl p-5 sm:p-6 max-w-lg w-full shadow-2xl relative max-h-[92vh] flex flex-col">
        {/* Close Button */}
        <button
          id="btn-close-avatar"
          onClick={() => {
            soundFX.playClick();
            onClose();
          }}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-xl hover:bg-slate-800 transition-colors"
        >
          <X className="w-6 h-6" />
        </button>

        {/* Title */}
        <div className="flex items-center space-x-2.5 mb-3">
          <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
            <Palette className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-white flex items-center gap-2">
              로블록스 아바타 꾸미기
            </h2>
            <p className="text-xs text-slate-400">
              셔츠, 바지, 헤어 액세서리 및 표정을 나만의 스타일로 변경해보세요.
            </p>
          </div>
        </div>

        {/* Quick Presets */}
        <div className="flex items-center space-x-1.5 overflow-x-auto pb-2 mb-3 border-b border-slate-800 text-xs">
          <span className="text-slate-400 font-semibold flex items-center gap-1 shrink-0">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" /> 추천 프리셋:
          </span>
          <button
            onClick={() =>
              handleApplyPreset({
                shirtColor: '#1e1e24',
                pantsColor: '#222831',
                skinColor: '#f5e0c3',
                hat: 'bacon',
                face: 'smile',
              })
            }
            className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-amber-300 rounded-lg shrink-0 font-medium"
          >
            🥓 원조 베이컨
          </button>
          <button
            onClick={() =>
              handleApplyPreset({
                shirtColor: '#ca8a04',
                pantsColor: '#1e293b',
                skinColor: '#f5d76e',
                hat: 'crown',
                face: 'cool',
              })
            }
            className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-yellow-300 rounded-lg shrink-0 font-medium"
          >
            👑 골든 킹
          </button>
          <button
            onClick={() =>
              handleApplyPreset({
                shirtColor: '#dc2626',
                pantsColor: '#0f172a',
                skinColor: '#8c5332',
                hat: 'horns',
                face: 'excited',
              })
            }
            className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-rose-300 rounded-lg shrink-0 font-medium"
          >
            😈 레드 데빌
          </button>
          <button
            onClick={() =>
              handleApplyPreset({
                shirtColor: '#2563eb',
                pantsColor: '#1e3a8a',
                skinColor: '#f5e0c3',
                hat: 'cap',
                face: 'cool',
              })
            }
            className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-blue-300 rounded-lg shrink-0 font-medium"
          >
            🧢 블루 캡
          </button>
        </div>

        {/* Customization Options Scrollable */}
        <div className="space-y-4 overflow-y-auto pr-1 flex-1">
          {/* Shirt Color */}
          <div>
            <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
              상의 / 셔츠 컬러
            </label>
            <div className="flex flex-wrap items-center gap-2">
              {SHIRT_COLORS.map((c) => (
                <button
                  key={c}
                  onClick={() => {
                    soundFX.playClick();
                    setForm((p) => ({ ...p, shirtColor: c }));
                  }}
                  style={{ backgroundColor: c }}
                  className={`w-7 h-7 sm:w-8 sm:h-8 rounded-xl border-2 transition-transform ${
                    form.shirtColor.toLowerCase() === c.toLowerCase()
                      ? 'border-white scale-110 shadow-lg'
                      : 'border-slate-700 hover:scale-105'
                  }`}
                />
              ))}
              <input
                type="color"
                value={form.shirtColor}
                onChange={(e) => setForm((p) => ({ ...p, shirtColor: e.target.value }))}
                className="w-7 h-7 sm:w-8 sm:h-8 rounded-xl bg-transparent cursor-pointer border border-slate-600"
                title="직접 색상 선택"
              />
            </div>
          </div>

          {/* Pants Color */}
          <div>
            <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
              하의 / 바지 컬러
            </label>
            <div className="flex flex-wrap items-center gap-2">
              {PANTS_COLORS.map((c) => (
                <button
                  key={c}
                  onClick={() => {
                    soundFX.playClick();
                    setForm((p) => ({ ...p, pantsColor: c }));
                  }}
                  style={{ backgroundColor: c }}
                  className={`w-7 h-7 sm:w-8 sm:h-8 rounded-xl border-2 transition-transform ${
                    form.pantsColor.toLowerCase() === c.toLowerCase()
                      ? 'border-white scale-110 shadow-lg'
                      : 'border-slate-700 hover:scale-105'
                  }`}
                />
              ))}
              <input
                type="color"
                value={form.pantsColor}
                onChange={(e) => setForm((p) => ({ ...p, pantsColor: e.target.value }))}
                className="w-7 h-7 sm:w-8 sm:h-8 rounded-xl bg-transparent cursor-pointer border border-slate-600"
                title="직접 색상 선택"
              />
            </div>
          </div>

          {/* Skin Tone */}
          <div>
            <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
              피부 스킨 톤
            </label>
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
              {SKIN_TONES.map((t) => (
                <button
                  key={t.color}
                  onClick={() => {
                    soundFX.playClick();
                    setForm((p) => ({ ...p, skinColor: t.color }));
                  }}
                  className={`p-1.5 rounded-xl border flex flex-col items-center gap-1 transition-all ${
                    form.skinColor.toLowerCase() === t.color.toLowerCase()
                      ? 'border-amber-400 bg-slate-800 shadow-md'
                      : 'border-slate-700 hover:border-slate-500 bg-slate-850'
                  }`}
                >
                  <div
                    className="w-5 h-5 rounded-full border border-black/20"
                    style={{ backgroundColor: t.color }}
                  />
                  <span className="text-[10px] text-slate-300 font-medium truncate w-full text-center">
                    {t.label}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Hats & Headwear */}
          <div>
            <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
              헤어 및 모자 액세서리
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {HATS.map((h) => (
                <button
                  key={h.id}
                  onClick={() => {
                    soundFX.playClick();
                    setForm((p) => ({ ...p, hat: h.id }));
                  }}
                  className={`p-2 rounded-xl border flex items-center space-x-2 text-left transition-all ${
                    form.hat === h.id
                      ? 'border-amber-400 bg-amber-500/20 text-amber-300 font-bold'
                      : 'border-slate-700 hover:border-slate-500 bg-slate-800/80 text-slate-300'
                  }`}
                >
                  <span className="text-lg">{h.icon}</span>
                  <span className="text-xs truncate">{h.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Faces */}
          <div>
            <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
              표정 페이스 데칼
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {FACES.map((f) => (
                <button
                  key={f.id}
                  onClick={() => {
                    soundFX.playClick();
                    setForm((p) => ({ ...p, face: f.id }));
                  }}
                  className={`p-2 rounded-xl border flex items-center space-x-2 text-left transition-all ${
                    form.face === f.id
                      ? 'border-sky-400 bg-sky-500/20 text-sky-300 font-bold'
                      : 'border-slate-700 hover:border-slate-500 bg-slate-800/80 text-slate-300'
                  }`}
                >
                  <span className="text-lg">{f.icon}</span>
                  <span className="text-xs truncate">{f.name}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Footer actions */}
        <div className="pt-3 border-t border-slate-800 flex justify-end space-x-2">
          <button
            onClick={() => {
              soundFX.playClick();
              onClose();
            }}
            className="btn-game bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold px-4 py-2 rounded-xl border border-slate-600 text-sm"
          >
            취소
          </button>
          <button
            id="btn-save-avatar"
            onClick={handleSave}
            className="btn-game bg-amber-500 hover:bg-amber-400 text-slate-950 font-black px-6 py-2 rounded-xl border border-amber-300 text-sm flex items-center gap-1.5"
          >
            <Check className="w-4 h-4" />
            저장 및 즉시 적용
          </button>
        </div>
      </div>
    </div>
  );
};
