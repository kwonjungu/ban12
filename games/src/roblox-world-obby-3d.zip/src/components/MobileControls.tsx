import React, { useRef, useEffect } from 'react';
import { ChevronsUp, Zap, RotateCcw } from 'lucide-react';

interface MobileControlsProps {
  onMove: (dir: { x: number; z: number }) => void;
  onJump: () => void;
  onSprintToggle: (sprinting: boolean) => void;
  onQuickRespawn: () => void;
  isSprinting: boolean;
}

export const MobileControls: React.FC<MobileControlsProps> = ({
  onMove,
  onJump,
  onSprintToggle,
  onQuickRespawn,
  isSprinting,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const knobRef = useRef<HTMLDivElement>(null);
  const touchIdRef = useRef<number | null>(null);

  useEffect(() => {
    const container = containerRef.current;
    const knob = knobRef.current;
    if (!container || !knob) return;

    const handleTouchStart = (e: TouchEvent) => {
      e.preventDefault();
      for (let i = 0; i < e.changedTouches.length; i++) {
        const t = e.changedTouches[i];
        if (touchIdRef.current === null) {
          touchIdRef.current = t.identifier;
          updatePosition(t);
        }
      }
    };

    const handleTouchMove = (e: TouchEvent) => {
      e.preventDefault();
      for (let i = 0; i < e.changedTouches.length; i++) {
        const t = e.changedTouches[i];
        if (t.identifier === touchIdRef.current) {
          updatePosition(t);
        }
      }
    };

    const handleTouchEnd = (e: TouchEvent) => {
      for (let i = 0; i < e.changedTouches.length; i++) {
        const t = e.changedTouches[i];
        if (t.identifier === touchIdRef.current) {
          touchIdRef.current = null;
          knob.style.transform = 'translate(0px, 0px)';
          onMove({ x: 0, z: 0 });
        }
      }
    };

    function updatePosition(touch: Touch) {
      const rect = container!.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;
      let dx = touch.clientX - centerX;
      let dy = touch.clientY - centerY;
      const maxRadius = rect.width / 2 - 12;
      const dist = Math.hypot(dx, dy);

      if (dist > maxRadius) {
        dx = (dx / dist) * maxRadius;
        dy = (dy / dist) * maxRadius;
      }

      knob!.style.transform = `translate(${dx}px, ${dy}px)`;
      onMove({
        x: dx / maxRadius,
        z: dy / maxRadius,
      });
    }

    container.addEventListener('touchstart', handleTouchStart, { passive: false });
    window.addEventListener('touchmove', handleTouchMove, { passive: false });
    window.addEventListener('touchend', handleTouchEnd);
    window.addEventListener('touchcancel', handleTouchEnd);

    return () => {
      container.removeEventListener('touchstart', handleTouchStart);
      window.removeEventListener('touchmove', handleTouchMove);
      window.removeEventListener('touchend', handleTouchEnd);
      window.removeEventListener('touchcancel', handleTouchEnd);
    };
  }, [onMove]);

  return (
    <div className="w-full flex items-end justify-between px-3 pb-3 pointer-events-auto md:hidden select-none">
      {/* Virtual Joystick */}
      <div
        ref={containerRef}
        className="relative w-28 h-28 bg-slate-900/70 rounded-full border-2 border-slate-600/60 flex items-center justify-center backdrop-blur-md shadow-2xl touch-none"
      >
        <div
          ref={knobRef}
          className="w-12 h-12 bg-indigo-500/90 rounded-full border-2 border-indigo-300 shadow-lg pointer-events-none transition-transform duration-75"
        />
      </div>

      {/* Action Buttons: Sprint, Respawn, Jump */}
      <div className="flex items-center space-x-2.5">
        {/* Quick Respawn */}
        <button
          onClick={onQuickRespawn}
          className="btn-game w-12 h-12 bg-slate-800 active:bg-slate-700 text-rose-400 rounded-full border border-slate-600 flex items-center justify-center shadow-lg"
          title="체크포인트로 리스폰"
        >
          <RotateCcw className="w-5 h-5" />
        </button>

        {/* Sprint / Dash */}
        <button
          onClick={() => onSprintToggle(!isSprinting)}
          className={`btn-game w-13 h-13 rounded-full border flex items-center justify-center shadow-lg transition-all ${
            isSprinting
              ? 'bg-amber-500 border-amber-300 text-slate-950'
              : 'bg-slate-800 border-slate-600 text-amber-400'
          }`}
          title="달리기 토글"
        >
          <Zap className="w-6 h-6 fill-current" />
        </button>

        {/* Jump / Double Jump */}
        <button
          onClick={onJump}
          className="btn-game w-16 h-16 bg-emerald-500 active:bg-emerald-600 rounded-full border-2 border-emerald-300 flex items-center justify-center text-white font-bold shadow-2xl active:scale-95"
          title="점프 / 2단 점프"
        >
          <ChevronsUp className="w-8 h-8" />
        </button>
      </div>
    </div>
  );
};
