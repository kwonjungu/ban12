import React from 'react';
import {
  Star,
  Flag,
  Skull,
  Timer as TimerIcon,
  Volume2,
  VolumeX,
  ListOrdered,
  RotateCcw,
  UserCheck,
  HelpCircle,
  ChevronLeft,
  ChevronRight,
  ShieldAlert,
  Trophy,
} from 'lucide-react';
import { GameStats } from '../types';
import { TOTAL_STAGES } from '../game/stages';

interface TopBarProps {
  stats: GameStats;
  isMuted: boolean;
  practiceMode: boolean;
  elapsedSeconds: number;
  onToggleMute: () => void;
  onTogglePractice: () => void;
  onOpenStageList: () => void;
  onOpenResetConfirm: () => void;
  onOpenAvatar: () => void;
  onOpenControls: () => void;
  onOpenLeaderboard: () => void;
  onPrevStage: () => void;
  onNextStage: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  stats,
  isMuted,
  practiceMode,
  elapsedSeconds,
  onToggleMute,
  onTogglePractice,
  onOpenStageList,
  onOpenResetConfirm,
  onOpenAvatar,
  onOpenControls,
  onOpenLeaderboard,
  onPrevStage,
  onNextStage,
}) => {
  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const isPrevDisabled = stats.currentStageIndex <= 0;
  const isNextDisabled = stats.currentStageIndex >= stats.maxUnlockedStage;

  return (
    <div className="flex items-start justify-between w-full flex-wrap gap-2 pointer-events-auto">
      {/* Left Info HUD */}
      <div className="bg-slate-900/90 backdrop-blur-md px-3 py-2 rounded-2xl border border-slate-700/70 shadow-2xl flex items-center space-x-2 sm:space-x-3">
        {/* Rebirth Counter & Quick Leaderboard Trigger */}
        <button
          id="hud-rebirths"
          onClick={onOpenLeaderboard}
          className="flex items-center space-x-1.5 bg-amber-500/20 hover:bg-amber-500/30 px-2.5 py-1 rounded-xl border border-amber-500/40 text-amber-300 hover:text-amber-200 transition-all cursor-pointer"
          title="클릭하여 환생 리더보드 열기"
        >
          <Trophy className="w-4 h-4 fill-amber-400 text-amber-400" />
          <span className="font-extrabold text-xs sm:text-sm font-mono">
            환생 {stats.rebirthCount ?? 0}회
          </span>
        </button>

        {/* Star Collection */}
        <div
          id="hud-stars"
          className="flex items-center space-x-1.5 bg-slate-800/90 px-2.5 py-1 rounded-xl border border-slate-700"
          title="수집한 별"
        >
          <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
          <span className="font-bold text-xs sm:text-sm text-amber-300 font-mono">
            {stats.starsCollectedCount} / {TOTAL_STAGES - 1}
          </span>
        </div>

        {/* Current Checkpoint */}
        <div
          id="hud-checkpoint"
          className="flex items-center space-x-1.5 bg-slate-800/90 px-2.5 py-1 rounded-xl border border-slate-700"
          title="현재 체크포인트"
        >
          <Flag className="w-4 h-4 text-emerald-400 fill-emerald-400" />
          <span className="font-semibold text-xs sm:text-sm text-emerald-300">
            Stage {stats.currentStageIndex + 1}
          </span>
        </div>

        {/* Death Counter */}
        <div
          id="hud-deaths"
          className="flex items-center space-x-1.5 bg-slate-800/90 px-2.5 py-1 rounded-xl border border-slate-700"
          title="사망 횟수"
        >
          <Skull className="w-4 h-4 text-rose-400" />
          <span className="font-semibold text-xs sm:text-sm text-rose-300 font-mono">
            {stats.deathCount}
          </span>
        </div>

        {/* Speedrun Timer */}
        <div
          id="hud-timer"
          className="flex items-center space-x-1.5 bg-slate-800/90 px-2.5 py-1 rounded-xl border border-slate-700"
          title="경과 시간"
        >
          <TimerIcon className="w-4 h-4 text-sky-400" />
          <span className="font-mono text-xs sm:text-sm text-sky-300">
            {formatTime(elapsedSeconds)}
          </span>
        </div>

        {/* Practice Mode indicator */}
        {practiceMode && (
          <div className="hidden sm:flex items-center space-x-1 bg-purple-900/60 px-2 py-1 rounded-xl border border-purple-500/50 text-purple-300 text-xs font-semibold">
            <ShieldAlert className="w-3.5 h-3.5 text-purple-400" />
            <span>연습 모드</span>
          </div>
        )}
      </div>

      {/* Right Controls & Quick Stage Navigator */}
      <div className="flex items-center space-x-1.5 sm:space-x-2">
        {/* Rebirth Leaderboard Button */}
        <button
          id="btn-leaderboard-modal"
          onClick={onOpenLeaderboard}
          title="환생 순위표 (리더보드)"
          className="btn-game bg-amber-500 hover:bg-amber-400 text-slate-950 font-black px-3 py-2 sm:py-2.5 rounded-xl border border-amber-300 shadow-lg flex items-center gap-1.5 text-xs sm:text-sm cursor-pointer"
        >
          <Trophy className="w-4 h-4 fill-slate-950" />
          <span className="hidden sm:inline">환생 순위표</span>
        </button>

        {/* Sound Toggle */}
        <button
          id="btn-sound-toggle"
          onClick={onToggleMute}
          title={isMuted ? '음소거 해제' : '소리 끄기'}
          className="btn-game bg-indigo-600 hover:bg-indigo-500 text-white p-2 sm:p-2.5 rounded-xl border border-indigo-400/80"
        >
          {isMuted ? (
            <VolumeX className="w-4 h-4 sm:w-5 sm:h-5 text-rose-300" />
          ) : (
            <Volume2 className="w-4 h-4 sm:w-5 sm:h-5" />
          )}
        </button>

        {/* Stage List Modal Trigger */}
        <button
          id="btn-stage-list"
          onClick={onOpenStageList}
          title="100개 스테이지 목록"
          className="btn-game bg-purple-600 hover:bg-purple-500 text-white p-2 sm:p-2.5 rounded-xl border border-purple-400/80"
        >
          <ListOrdered className="w-4 h-4 sm:w-5 sm:h-5" />
        </button>

        {/* Quick Stage Warp Pager */}
        <div className="flex items-center space-x-1 bg-slate-900/90 border border-slate-700/80 rounded-2xl p-1 shadow-xl backdrop-blur-md">
          <button
            id="btn-stage-prev"
            onClick={onPrevStage}
            disabled={isPrevDisabled}
            title="이전 해금 스테이지"
            className="w-7 h-7 sm:w-8 sm:h-8 rounded-xl bg-slate-800 hover:bg-slate-700 active:scale-95 transition-all disabled:opacity-30 disabled:cursor-not-allowed flex items-center justify-center font-bold text-amber-400 border border-slate-600"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <div
            id="btn-stage-nav-text"
            onClick={onOpenStageList}
            className="px-2 min-w-[72px] sm:min-w-[84px] text-center cursor-pointer hover:bg-slate-800/80 rounded-lg py-1 transition-colors"
            title="클릭하여 스테이지 선택 열기"
          >
            <span className="font-extrabold text-xs sm:text-sm text-amber-300 font-mono tracking-wide">
              Stage {stats.currentStageIndex + 1}
            </span>
          </div>
          <button
            id="btn-stage-next"
            onClick={onNextStage}
            disabled={isNextDisabled}
            title="다음 해금 스테이지"
            className="w-7 h-7 sm:w-8 sm:h-8 rounded-xl bg-slate-800 hover:bg-slate-700 active:scale-95 transition-all disabled:opacity-30 disabled:cursor-not-allowed flex items-center justify-center font-bold text-amber-400 border border-slate-600"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* Avatar Customizer */}
        <button
          id="btn-avatar-modal"
          onClick={onOpenAvatar}
          title="아바타 꾸미기"
          className="btn-game bg-amber-600 hover:bg-amber-500 text-white p-2 sm:p-2.5 rounded-xl border border-amber-400/80"
        >
          <UserCheck className="w-4 h-4 sm:w-5 sm:h-5" />
        </button>

        {/* Controls Help */}
        <button
          id="btn-controls-modal"
          onClick={onOpenControls}
          title="조작법 안내"
          className="btn-game bg-slate-700 hover:bg-slate-600 text-white p-2 sm:p-2.5 rounded-xl border border-slate-500/80"
        >
          <HelpCircle className="w-4 h-4 sm:w-5 sm:h-5" />
        </button>

        {/* Reset Progress */}
        <button
          id="btn-reset-save"
          onClick={onOpenResetConfirm}
          title="진행상황 초기화"
          className="btn-game bg-rose-700 hover:bg-rose-600 text-white p-2 sm:p-2.5 rounded-xl border border-rose-500/80"
        >
          <RotateCcw className="w-4 h-4 sm:w-5 sm:h-5" />
        </button>
      </div>
    </div>
  );
};
