import React, { useState } from 'react';
import { X, Star, Lock, CheckCircle2, MapPin } from 'lucide-react';
import { TOTAL_STAGES } from '../game/stages';
import { soundFX } from '../game/audio';

interface StageModalProps {
  isOpen: boolean;
  currentStageIndex: number;
  maxUnlockedStage: number;
  collectedStarIds: number[];
  onSelectStage: (index: number) => void;
  onClose: () => void;
}

export const StageModal: React.FC<StageModalProps> = ({
  isOpen,
  currentStageIndex,
  maxUnlockedStage,
  collectedStarIds,
  onSelectStage,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'all' | '1-25' | '26-50' | '51-75' | '76-100'>('all');

  if (!isOpen) return null;

  const starSet = new Set(collectedStarIds);

  const getStageRange = () => {
    switch (activeTab) {
      case '1-25':
        return [0, 24];
      case '26-50':
        return [25, 49];
      case '51-75':
        return [50, 74];
      case '76-100':
        return [75, 99];
      default:
        return [0, TOTAL_STAGES - 1];
    }
  };

  const [startIdx, endIdx] = getStageRange();
  const stagesToRender: number[] = [];
  for (let i = startIdx; i <= endIdx; i++) {
    stagesToRender.push(i);
  }

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md flex items-center justify-center z-50 p-3 sm:p-4">
      <div className="bg-slate-900 border border-slate-700/80 rounded-3xl p-5 max-w-2xl w-full shadow-2xl relative max-h-[90vh] flex flex-col">
        {/* Close Button */}
        <button
          id="btn-close-stage-list"
          onClick={() => {
            soundFX.playClick();
            onClose();
          }}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-xl hover:bg-slate-800 transition-colors"
        >
          <X className="w-6 h-6" />
        </button>

        {/* Header */}
        <div className="flex items-center space-x-2.5 mb-1">
          <div className="p-2 rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/30">
            <MapPin className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-white flex items-center gap-2">
              스테이지 워프 <span className="text-sm font-normal text-purple-400">(1~100)</span>
            </h2>
            <p className="text-xs text-slate-400">
              해금된 스테이지를 클릭하면 해당 위치로 즉시 이동합니다.
            </p>
          </div>
        </div>

        {/* Tab Filters */}
        <div className="flex items-center space-x-1.5 overflow-x-auto py-3 border-b border-slate-800 text-xs font-semibold">
          {(
            [
              ['all', '전체 (100개)'],
              ['1-25', '1~25'],
              ['26-50', '26~50'],
              ['51-75', '51~75'],
              ['76-100', '76~100'],
            ] as const
          ).map(([key, label]) => (
            <button
              key={key}
              onClick={() => {
                soundFX.playClick();
                setActiveTab(key);
              }}
              className={`px-3 py-1.5 rounded-xl transition-all whitespace-nowrap ${
                activeTab === key
                  ? 'bg-purple-600 text-white shadow-md'
                  : 'bg-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        {/* Stages Grid */}
        <div className="grid grid-cols-4 sm:grid-cols-5 md:grid-cols-6 lg:grid-cols-8 gap-2 overflow-y-auto p-1.5 my-3 pr-2 flex-1">
          {stagesToRender.map((stageIndex) => {
            const isUnlocked = stageIndex <= maxUnlockedStage;
            const isCurrent = stageIndex === currentStageIndex;
            const hasStar = starSet.has(stageIndex);
            const isFinal = stageIndex === TOTAL_STAGES - 1;

            return (
              <button
                key={stageIndex}
                disabled={!isUnlocked}
                onClick={() => {
                  soundFX.playClick();
                  onSelectStage(stageIndex);
                  onClose();
                }}
                className={`p-2 sm:p-2.5 rounded-2xl flex flex-col items-center justify-center transition-all border relative min-h-[58px] ${
                  isCurrent
                    ? 'bg-amber-500 text-slate-950 border-amber-300 ring-2 ring-amber-400 shadow-lg scale-[1.02]'
                    : isUnlocked
                      ? isFinal
                        ? 'bg-gradient-to-br from-amber-600 to-yellow-500 text-white border-yellow-400 shadow-md hover:scale-105'
                        : 'bg-slate-800 hover:bg-purple-600/80 text-purple-200 hover:text-white border-slate-700 hover:border-purple-400 active:scale-95'
                      : 'bg-slate-900/50 text-slate-600 border-slate-800 cursor-not-allowed opacity-40'
                }`}
              >
                <span className="text-xs sm:text-sm font-black font-mono">
                  {stageIndex + 1}
                </span>

                <div className="flex items-center space-x-1 mt-1">
                  {isUnlocked ? (
                    hasStar ? (
                      <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                    ) : (
                      <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                    )
                  ) : (
                    <Lock className="w-3 h-3 text-slate-500" />
                  )}
                </div>

                {isFinal && (
                  <span className="absolute -top-1.5 -right-1.5 bg-yellow-400 text-slate-950 text-[9px] font-black px-1 rounded-full">
                    👑
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Footer info */}
        <div className="pt-2 border-t border-slate-800 flex justify-between items-center text-xs text-slate-400">
          <span>
            해금 진행률:{' '}
            <strong className="text-purple-400">
              {Math.round(((maxUnlockedStage + 1) / TOTAL_STAGES) * 100)}%
            </strong>
          </span>
          <button
            onClick={() => {
              soundFX.playClick();
              onClose();
            }}
            className="btn-game bg-slate-800 hover:bg-slate-700 text-white px-4 py-1.5 rounded-xl border border-slate-600 font-bold"
          >
            닫기
          </button>
        </div>
      </div>
    </div>
  );
};
