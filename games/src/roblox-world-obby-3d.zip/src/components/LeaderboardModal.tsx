import React, { useState, useMemo } from 'react';
import { Trophy, Star, Medal, RotateCcw, X, Edit3, Check, Sparkles } from 'lucide-react';
import { GameStats, PlayerCustomization } from '../types';
import { getFullLeaderboard, getStoredPlayerNickname, saveStoredPlayerNickname } from '../game/leaderboard';
import { soundFX } from '../game/audio';

interface LeaderboardModalProps {
  isOpen: boolean;
  stats: GameStats;
  customization: PlayerCustomization;
  onClose: () => void;
}

export const LeaderboardModal: React.FC<LeaderboardModalProps> = ({
  isOpen,
  stats,
  customization,
  onClose,
}) => {
  const [nickname, setNickname] = useState<string>(() => getStoredPlayerNickname());
  const [isEditingNickname, setIsEditingNickname] = useState<boolean>(false);
  const [tempNickname, setTempNickname] = useState<string>('');
  const [sortMode, setSortMode] = useState<'rebirths' | 'stars'>('rebirths');

  const { entries, currentPlayerRank } = useMemo(() => {
    return getFullLeaderboard(
      stats.rebirthCount ?? 0,
      stats.starsCollectedCount ?? 0,
      customization,
      nickname
    );
  }, [stats.rebirthCount, stats.starsCollectedCount, customization, nickname]);

  const sortedEntries = useMemo(() => {
    const list = [...entries];
    if (sortMode === 'stars') {
      list.sort((a, b) => {
        if (b.stars !== a.stars) return b.stars - a.stars;
        return b.rebirths - a.rebirths;
      });
      list.forEach((e, idx) => {
        e.rank = idx + 1;
      });
    }
    return list;
  }, [entries, sortMode]);

  if (!isOpen) return null;

  const handleSaveNickname = () => {
    if (tempNickname.trim()) {
      const valid = tempNickname.trim().slice(0, 12);
      setNickname(valid);
      saveStoredPlayerNickname(valid);
    }
    setIsEditingNickname(false);
  };

  const startEditNickname = () => {
    setTempNickname(nickname);
    setIsEditingNickname(true);
  };

  return (
    <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md flex items-center justify-center z-50 p-3 sm:p-4">
      <div className="bg-gradient-to-b from-slate-900 via-slate-900 to-indigo-950 border border-amber-500/50 rounded-3xl p-5 sm:p-6 max-w-xl w-full shadow-2xl relative flex flex-col max-h-[90vh]">
        {/* Close Button */}
        <button
          onClick={() => {
            soundFX.playClick();
            onClose();
          }}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 transition-colors border border-slate-700 cursor-pointer"
          title="닫기"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border-2 border-amber-400 flex items-center justify-center text-amber-300 shadow-lg">
            <Trophy className="w-6 h-6 fill-amber-400" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-yellow-400 to-amber-200">
              환생 명예의 전당 (리더보드)
            </h2>
            <p className="text-xs sm:text-sm text-slate-300">
              플레이어들의 총 환생 횟수 및 파쿠르 기록 순위
            </p>
          </div>
        </div>

        {/* My Ranking Card */}
        <div className="bg-gradient-to-r from-amber-950/40 via-slate-800/80 to-indigo-950/40 border border-amber-500/40 rounded-2xl p-3.5 mb-4 shadow-md flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-3">
            {/* Rank badge */}
            <div className="w-10 h-10 rounded-xl bg-amber-500 text-slate-950 font-black flex items-center justify-center text-sm shadow">
              #{currentPlayerRank}
            </div>

            {/* Avatar & Name */}
            <div>
              <div className="flex items-center gap-1.5">
                {isEditingNickname ? (
                  <div className="flex items-center gap-1">
                    <input
                      type="text"
                      value={tempNickname}
                      onChange={(e) => setTempNickname(e.target.value)}
                      maxLength={12}
                      className="bg-slate-900 border border-amber-400 text-white text-xs font-bold px-2 py-0.5 rounded-lg focus:outline-none w-28 sm:w-36"
                      autoFocus
                    />
                    <button
                      onClick={handleSaveNickname}
                      className="bg-emerald-600 hover:bg-emerald-500 text-white p-1 rounded-lg"
                      title="저장"
                    >
                      <Check className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center gap-1.5">
                    <span className="font-extrabold text-sm sm:text-base text-white">
                      {nickname}
                    </span>
                    <button
                      onClick={startEditNickname}
                      className="text-slate-400 hover:text-amber-300 p-0.5 transition-colors"
                      title="닉네임 변경"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
                <span className="text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/30 px-1.5 py-0.5 rounded-md font-semibold">
                  나의 기록
                </span>
              </div>
              <div className="text-xs text-slate-300 flex items-center gap-2 mt-0.5">
                <span className="text-amber-300 font-bold flex items-center gap-0.5">
                  <RotateCcw className="w-3 h-3" /> 환생 {stats.rebirthCount ?? 0}회
                </span>
                <span>•</span>
                <span className="text-yellow-300 flex items-center gap-0.5">
                  <Star className="w-3 h-3 fill-yellow-400" /> 별 {stats.starsCollectedCount}개
                </span>
              </div>
            </div>
          </div>

          {/* Prompt info */}
          <div className="text-right text-[11px] text-slate-400">
            {stats.rebirthCount ? (
              <span className="text-emerald-400 font-semibold flex items-center gap-1">
                <Sparkles className="w-3 h-3" /> 다음 순위까지 계속 환생해보세요!
              </span>
            ) : (
              <span className="text-amber-300 font-medium">
                Stage 100 클리어 시 첫 환생 달성 가능!
              </span>
            )}
          </div>
        </div>

        {/* Sort Filter Tabs */}
        <div className="flex items-center justify-between mb-2.5">
          <div className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
            <Medal className="w-4 h-4 text-amber-400" />
            <span>TOP 10 명예의 전당</span>
          </div>

          <div className="flex bg-slate-800/90 rounded-xl p-0.5 border border-slate-700 text-xs">
            <button
              onClick={() => setSortMode('rebirths')}
              className={`px-3 py-1 rounded-lg font-bold transition-all ${
                sortMode === 'rebirths'
                  ? 'bg-amber-500 text-slate-950 shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              🔄 환생 횟수 순
            </button>
            <button
              onClick={() => setSortMode('stars')}
              className={`px-3 py-1 rounded-lg font-bold transition-all ${
                sortMode === 'stars'
                  ? 'bg-amber-500 text-slate-950 shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              ⭐ 별 수집 순
            </button>
          </div>
        </div>

        {/* Leaderboard Table List */}
        <div className="flex-1 overflow-y-auto pr-1 space-y-1.5 custom-scrollbar min-h-[220px]">
          {sortedEntries.map((player) => {
            const isTop1 = player.rank === 1;
            const isTop2 = player.rank === 2;
            const isTop3 = player.rank === 3;
            const isMe = player.isCurrentPlayer;

            let rankBg = 'bg-slate-800 text-slate-300';
            if (isTop1) rankBg = 'bg-gradient-to-r from-amber-400 to-yellow-500 text-slate-950 shadow-amber-500/50 shadow-md font-black';
            else if (isTop2) rankBg = 'bg-gradient-to-r from-slate-200 to-slate-400 text-slate-950 shadow-md font-black';
            else if (isTop3) rankBg = 'bg-gradient-to-r from-amber-700 to-amber-600 text-amber-100 shadow-md font-black';

            let rowBg = 'bg-slate-800/60 hover:bg-slate-800/90 border-slate-700/60';
            if (isMe) {
              rowBg = 'bg-amber-500/15 border-amber-400/60 ring-1 ring-amber-400/40';
            } else if (isTop1) {
              rowBg = 'bg-amber-950/30 border-amber-500/40';
            }

            return (
              <div
                key={player.id}
                className={`flex items-center justify-between p-2.5 rounded-2xl border ${rowBg} transition-all`}
              >
                <div className="flex items-center gap-2.5 sm:gap-3">
                  {/* Rank number */}
                  <div
                    className={`w-7 h-7 rounded-xl flex items-center justify-center text-xs font-mono font-black ${rankBg}`}
                  >
                    {player.rank}
                  </div>

                  {/* Player avatar color & details */}
                  <div className="flex items-center gap-2">
                    <div
                      className="w-7 h-7 rounded-lg flex items-center justify-center text-xs border border-white/20 shadow-sm"
                      style={{ backgroundColor: player.color }}
                    >
                      {player.hat === 'crown' ? '👑' : player.hat === 'halo' ? '😇' : player.hat === 'horns' ? '😈' : player.hat === 'party' ? '🎉' : '🧢'}
                    </div>

                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className={`text-xs sm:text-sm font-bold ${isMe ? 'text-amber-300 font-black' : 'text-white'}`}>
                          {player.nickname}
                        </span>
                        {isMe && (
                          <span className="text-[10px] bg-amber-400 text-slate-950 px-1 rounded font-black">
                            ME
                          </span>
                        )}
                        <span className="text-[10px] text-slate-400 hidden sm:inline">
                          ({player.title})
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Score & Rebirth count */}
                <div className="flex items-center gap-3 sm:gap-4 text-right">
                  <div className="text-right">
                    <div className="text-xs sm:text-sm font-black text-amber-300 font-mono flex items-center justify-end gap-1">
                      <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
                      <span>{player.rebirths}회</span>
                    </div>
                    <div className="text-[10px] text-slate-400 font-medium flex items-center justify-end gap-0.5">
                      <Star className="w-2.5 h-2.5 text-yellow-400 fill-yellow-400" />
                      <span>{player.stars}개</span>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer Info & Guide */}
        <div className="mt-4 pt-3 border-t border-slate-800 text-center text-xs text-slate-400 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>💡 100스테이지 완주 시 환생하여 환생 횟수와 순위를 올릴 수 있습니다!</span>
          <button
            onClick={() => {
              soundFX.playClick();
              onClose();
            }}
            className="btn-game bg-amber-500 hover:bg-amber-400 text-slate-950 font-black px-5 py-2 rounded-xl text-xs"
          >
            확인
          </button>
        </div>
      </div>
    </div>
  );
};
