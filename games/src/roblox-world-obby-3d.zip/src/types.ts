export type BlockTypeId =
  | 'grass'
  | 'brick'
  | 'stone'
  | 'wood'
  | 'glass'
  | 'trampoline'
  | 'speed'
  | 'lava'
  | 'checkpoint'
  | 'gold'
  | 'neon_blue'
  | 'neon_pink'
  | 'ladder'
  | 'tornado';

export interface BlockDef {
  id: BlockTypeId;
  name: string;
  color: number;
  opacity?: number;
  type?: 'bounce' | 'speed' | 'lava' | 'checkpoint' | 'normal' | 'fade' | 'ladder' | 'tornado';
  emissive?: number;
  emissiveIntensity?: number;
}

export interface Vector3D {
  x: number;
  y: number;
  z: number;
}

export interface StageInfo {
  id: number;
  name: string;
  theme: string;
  pos: Vector3D;
  description?: string;
}

export type HatType = 'none' | 'bacon' | 'crown' | 'cap' | 'horns' | 'halo' | 'party' | 'cat_ears';
export type FaceType = 'smile' | 'cool' | 'wink' | 'excited';

export interface PlayerCustomization {
  shirtColor: string;
  pantsColor: string;
  skinColor: string;
  hat: HatType;
  face: FaceType;
}

export interface GameStats {
  currentStageIndex: number;
  maxUnlockedStage: number;
  starsCollectedCount: number;
  deathCount: number;
  collectedStarIds: number[];
  startTime: number;
  isGameCompleted: boolean;
  rebirthCount: number; // 환생 횟수
}

export interface LeaderboardEntry {
  id: string;
  rank?: number;
  nickname: string;
  rebirths: number;
  stars: number;
  title: string;
  hat: HatType;
  face: FaceType;
  color: string;
  isCurrentPlayer?: boolean;
}

export interface GameSettings {
  soundMuted: boolean;
  volume: number;
  cameraSensitivity: number;
  viewDistance: number;
  practiceMode: boolean;
}
