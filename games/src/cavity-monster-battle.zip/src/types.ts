export interface ToothData {
  id: number;
  row: 'top' | 'bottom';
  index: number;
  cx: number;
  cy: number;
  isSick: boolean;
  flash: boolean;
}

export interface Monster {
  id: number;
  toothId: number;
  hp: number;
  maxHp: number;
  type: 'normal' | 'boss';
  popping: boolean;
}

export interface Particle {
  id: number;
  x: number;
  y: number;
  size: number;
  type: 'bubble' | 'sparkle';
  vx?: number;
  vy?: number;
}

export type GameState = 'start' | 'play' | 'over';

export interface StageConfig {
  stage: number;
  name: string;
  duration: number; // in seconds
  maxMonsters: number;
  spawnInterval: number; // in seconds
  drainMultiplier: number;
  description: string;
}
