import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Volume2, VolumeX, RotateCcw, Play, Sparkles, Shield, Trophy, Award } from 'lucide-react';
import type { ToothData, Monster, Particle, GameState, StageConfig } from './types';
import {
  playBrushSound,
  playPopSound,
  playStageClearSound,
  playGameOverSound,
  toggleMute,
  getIsMuted
} from './utils/audio';

// Asset Images
import toothbrushImg from './assets/images/toothbrush_asset_1789882087982.jpg';
import cavityMonImg from './assets/images/cavity_monster_asset_1789882098575.jpg';
import bossMonImg from './assets/images/boss_monster_asset_1789882108142.jpg';
import cleanToothImg from './assets/images/clean_tooth_asset_1789882115173.jpg';
import bathroomBgImg from './assets/images/bathroom_sink_bg_1789882126905.jpg';

const TEETH_PER_ROW = 8;
const TOTAL_TEETH = TEETH_PER_ROW * 2;

const STAGE_CONFIGS: StageConfig[] = [
  {
    stage: 1,
    name: '🔥 1단계 (기초 양치)',
    duration: 20,
    maxMonsters: 3,
    spawnInterval: 1.8,
    drainMultiplier: 1.0,
    description: '느릿느릿 다가오는 충치균을 칫솔로 닦아내세요!',
  },
  {
    stage: 2,
    name: '⚡ 2단계 (구석구석)',
    duration: 20,
    maxMonsters: 5,
    spawnInterval: 1.1,
    drainMultiplier: 1.5,
    description: '충치균들이 빨라집니다. 어금니 쪽도 꼼꼼히!',
  },
  {
    stage: 3,
    name: '🚨 3단계 (강력 충치 출현)',
    duration: 20,
    maxMonsters: 7,
    spawnInterval: 0.8,
    drainMultiplier: 2.1,
    description: '단단한 보스 설탕 몬스터가 나타납니다!',
  },
  {
    stage: 4,
    name: '👑 4단계 (최종 방어전)',
    duration: 20,
    maxMonsters: 9,
    spawnInterval: 0.5,
    drainMultiplier: 2.8,
    description: '폭풍처럼 몰려옵니다! 20초간 치아를 완벽히 지켜내세요!',
  },
];

export default function App() {
  const stageRef = useRef<HTMLDivElement>(null);
  const teethElementsRef = useRef<(HTMLDivElement | null)[]>([]);

  const [gameState, setGameState] = useState<GameState>('start');
  const [cleanliness, setCleanliness] = useState<number>(100);
  const [currentStageIndex, setCurrentStageIndex] = useState<number>(0);
  const [stageElapsed, setStageElapsed] = useState<number>(0);
  const [totalElapsed, setTotalElapsed] = useState<number>(0);
  const [monstersKilled, setMonstersKilled] = useState<number>(0);
  const [isMutedState, setIsMutedState] = useState<boolean>(false);
  const [bestTime, setBestTime] = useState<number>(0);
  const [isNewRecord, setIsNewRecord] = useState<boolean>(false);
  const [isVictory, setIsVictory] = useState<boolean>(false);

  // Transition between stages
  const [isTransitioning, setIsTransitioning] = useState<boolean>(false);
  const [transitionCountdown, setTransitionCountdown] = useState<number>(3);

  // Brush state
  const [brushPos, setBrushPos] = useState<{ x: number; y: number }>({ x: 200, y: 200 });
  const [brushRotation, setBrushRotation] = useState<number>(0);
  const [isBrushingActive, setIsBrushingActive] = useState<boolean>(false);

  // Active Monsters & Particles
  const [monsters, setMonsters] = useState<Monster[]>([]);
  const [particles, setParticles] = useState<Particle[]>([]);
  const [flashingTeeth, setFlashingTeeth] = useState<Record<number, boolean>>({});

  // Internal mutable animation loop refs
  const loopStateRef = useRef({
    gameState: 'start' as GameState,
    clean: 100,
    stageIdx: 0,
    stageTimer: 0,
    totalTimer: 0,
    spawnTimer: 0.8,
    killed: 0,
    isTransition: false,
    transTimer: 3,
    bx: 200,
    by: 200,
    pbx: 200,
    pby: 200,
    wobble: 0,
    keys: {} as Record<string, boolean>,
    isPointerDown: false,
    isMobileActionButton: false,
    monsters: [] as Monster[],
    lastTime: performance.now(),
    nextMonsterId: 1,
    nextParticleId: 1,
  });

  // Load best time on mount
  useEffect(() => {
    try {
      const saved = localStorage.getItem('cavity_best_time');
      if (saved) setBestTime(parseFloat(saved) || 0);
    } catch {
      // ignore
    }
  }, []);

  // Synchronize tooth positions
  const getToothCenter = useCallback((toothId: number) => {
    const el = teethElementsRef.current[toothId];
    const stage = stageRef.current;
    if (!el || !stage) return { x: 0, y: 0 };
    const r = el.getBoundingClientRect();
    const sr = stage.getBoundingClientRect();
    return {
      x: r.left - sr.left + r.width / 2,
      y: r.top - sr.top + r.height / 2,
    };
  }, []);

  // Spawn bubble or sparkle particles
  const addParticle = useCallback((x: number, y: number, type: 'bubble' | 'sparkle') => {
    const id = loopStateRef.current.nextParticleId++;
    const s = type === 'bubble' ? 10 + Math.random() * 16 : 20 + Math.random() * 8;
    const p: Particle = {
      id,
      x: x + (Math.random() * 40 - 20),
      y: y + (Math.random() * 30 - 15),
      size: s,
      type,
    };
    setParticles((prev) => [...prev.slice(-25), p]);
    setTimeout(() => {
      setParticles((prev) => prev.filter((item) => item.id !== id));
    }, 700);
  }, []);

  // Spawn monster
  const spawnMonster = useCallback(() => {
    const active = loopStateRef.current.monsters;
    const occupiedToothIds = new Set(active.map((m) => m.toothId));
    const availableTeeth: number[] = [];
    for (let i = 0; i < TOTAL_TEETH; i++) {
      if (!occupiedToothIds.has(i)) {
        availableTeeth.push(i);
      }
    }
    if (availableTeeth.length === 0) return;

    const randomTooth = availableTeeth[Math.floor(Math.random() * availableTeeth.length)];
    const currentStage = STAGE_CONFIGS[loopStateRef.current.stageIdx];

    // Determine type & HP based on stage
    const isBoss = currentStage.stage >= 3 && Math.random() > 0.65;
    const maxHp = isBoss ? 3 : currentStage.stage === 1 ? 1 : Math.random() > 0.5 ? 2 : 1;

    const newMonster: Monster = {
      id: loopStateRef.current.nextMonsterId++,
      toothId: randomTooth,
      hp: maxHp,
      maxHp,
      type: isBoss ? 'boss' : 'normal',
      popping: false,
    };

    loopStateRef.current.monsters.push(newMonster);
    setMonsters([...loopStateRef.current.monsters]);
  }, []);

  // Start game handler
  const handleStartGame = useCallback(() => {
    loopStateRef.current.gameState = 'play';
    loopStateRef.current.clean = 100;
    loopStateRef.current.stageIdx = 0;
    loopStateRef.current.stageTimer = 0;
    loopStateRef.current.totalTimer = 0;
    loopStateRef.current.spawnTimer = 0.5;
    loopStateRef.current.killed = 0;
    loopStateRef.current.isTransition = false;
    loopStateRef.current.transTimer = 3;
    loopStateRef.current.monsters = [];
    loopStateRef.current.lastTime = performance.now();

    if (stageRef.current) {
      const sr = stageRef.current.getBoundingClientRect();
      loopStateRef.current.bx = sr.width / 2;
      loopStateRef.current.by = sr.height / 2;
      loopStateRef.current.pbx = loopStateRef.current.bx;
      loopStateRef.current.pby = loopStateRef.current.by;
      setBrushPos({ x: loopStateRef.current.bx, y: loopStateRef.current.by });
    }

    setCleanliness(100);
    setCurrentStageIndex(0);
    setStageElapsed(0);
    setTotalElapsed(0);
    setMonstersKilled(0);
    setIsTransitioning(false);
    setIsVictory(false);
    setIsNewRecord(false);
    setMonsters([]);
    setParticles([]);
    setGameState('play');
  }, []);

  // Game over handler
  const handleGameOver = useCallback((victory: boolean) => {
    loopStateRef.current.gameState = 'over';
    setGameState('over');
    setIsVictory(victory);

    if (victory) {
      playStageClearSound();
    } else {
      playGameOverSound();
    }

    const t = Math.round(loopStateRef.current.totalTimer * 10) / 10;
    try {
      const savedBest = parseFloat(localStorage.getItem('cavity_best_time') || '0') || 0;
      if (t > savedBest) {
        localStorage.setItem('cavity_best_time', String(t));
        setBestTime(t);
        setIsNewRecord(true);
      }
    } catch {
      // ignore
    }
  }, []);

  // Pointer position tracking
  const updatePointer = useCallback((clientX: number, clientY: number) => {
    if (!stageRef.current) return;
    const sr = stageRef.current.getBoundingClientRect();
    const nx = Math.max(10, Math.min(sr.width - 10, clientX - sr.left));
    const ny = Math.max(10, Math.min(sr.height - 10, clientY - sr.top));
    loopStateRef.current.bx = nx;
    loopStateRef.current.by = ny;
    setBrushPos({ x: nx, y: ny });
  }, []);

  // Event Listeners for Keyboard and Pointer
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === ' ' || e.code === 'Space' || e.key.startsWith('Arrow')) {
        e.preventDefault();
      }
      loopStateRef.current.keys[e.key] = true;
      if (e.code === 'Space') loopStateRef.current.keys['Space'] = true;

      if (loopStateRef.current.gameState === 'start' && (e.key === ' ' || e.code === 'Space' || e.key === 'Enter')) {
        handleStartGame();
      } else if (loopStateRef.current.gameState === 'over' && (e.key === ' ' || e.code === 'Space' || e.key === 'Enter')) {
        handleStartGame();
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      loopStateRef.current.keys[e.key] = false;
      if (e.code === 'Space') loopStateRef.current.keys['Space'] = false;
    };

    window.addEventListener('keydown', handleKeyDown, { passive: false });
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [handleStartGame]);

  // Main Game Loop (requestAnimationFrame)
  useEffect(() => {
    let animId: number;
    let bubThrottle = 0;

    const gameLoop = (now: number) => {
      animId = requestAnimationFrame(gameLoop);
      const loop = loopStateRef.current;
      const dt = Math.min(0.05, Math.max(0.001, (now - loop.lastTime) / 1000));
      loop.lastTime = now;

      if (loop.gameState !== 'play') return;

      // Handle Stage Transition (3-second break)
      if (loop.isTransition) {
        loop.transTimer -= dt;
        const countdown = Math.max(1, Math.ceil(loop.transTimer));
        setTransitionCountdown(countdown);

        if (loop.transTimer <= 0) {
          loop.isTransition = false;
          loop.stageIdx++;
          loop.stageTimer = 0;
          setIsTransitioning(false);
          setCurrentStageIndex(loop.stageIdx);
        }
        return;
      }

      loop.totalTimer += dt;
      loop.stageTimer += dt;
      setTotalElapsed(loop.totalTimer);
      setStageElapsed(loop.stageTimer);

      const currentStageCfg = STAGE_CONFIGS[loop.stageIdx];

      // Check Stage Completion (20 seconds per stage)
      if (loop.stageTimer >= currentStageCfg.duration) {
        if (loop.stageIdx < STAGE_CONFIGS.length - 1) {
          // Advance to next stage with 3s transition countdown
          loop.isTransition = true;
          loop.transTimer = 3.0;
          loop.clean = Math.min(100, loop.clean + 25); // Bonus cleanliness recovery
          loop.monsters = [];
          setMonsters([]);
          setIsTransitioning(true);
          setTransitionCountdown(3);
          playStageClearSound();
          return;
        } else {
          // Completed all 4 stages -> Victory!
          handleGameOver(true);
          return;
        }
      }

      // Keyboard movement (Arrows / WASD)
      const moveSpeed = 440 * dt;
      if (loop.keys['ArrowLeft'] || loop.keys['a'] || loop.keys['A']) loop.bx -= moveSpeed;
      if (loop.keys['ArrowRight'] || loop.keys['d'] || loop.keys['D']) loop.bx += moveSpeed;
      if (loop.keys['ArrowUp'] || loop.keys['w'] || loop.keys['W']) loop.by -= moveSpeed;
      if (loop.keys['ArrowDown'] || loop.keys['s'] || loop.keys['S']) loop.by += moveSpeed;

      // Stage boundary clamp
      if (stageRef.current) {
        const sr = stageRef.current.getBoundingClientRect();
        loop.bx = Math.max(10, Math.min(sr.width - 10, loop.bx));
        loop.by = Math.max(10, Math.min(sr.height - 10, loop.by));
      }

      // Brushing trigger:
      // 1. Spacebar or Space code
      // 2. Mouse click & drag / touch active
      // 3. Dedicated mobile action button
      const isSpaceHeld = !!(loop.keys[' '] || loop.keys['Spacebar'] || loop.keys['Space']);
      const isBrushing = isSpaceHeld || loop.isPointerDown || loop.isMobileActionButton;
      setIsBrushingActive(isBrushing);

      // Wobble animation calculation
      let extraScrub = 0;
      if (isBrushing) {
        const prevW = loop.wobble;
        loop.wobble += dt * 18;
        extraScrub = Math.abs(Math.sin(loop.wobble) - Math.sin(prevW)) * 25;
      }

      // Movement vector for rotation & scrub distance
      const dx = loop.bx - loop.pbx;
      const dy = loop.by - loop.pby;
      const dist = Math.sqrt(dx * dx + dy * dy) + extraScrub;
      loop.pbx = loop.bx;
      loop.pby = loop.by;

      let rot = dx * 1.5;
      if (isBrushing) {
        rot += Math.sin(loop.wobble) * 22;
      }
      rot = Math.max(-35, Math.min(35, rot));
      setBrushPos({ x: loop.bx, y: loop.by });
      setBrushRotation(rot);

      // Play brush sound when actively scrubbing or moving brush over mouth
      if (isBrushing && dist > 1.5) {
        playBrushSound();
        bubThrottle -= dt;
        if (bubThrottle <= 0) {
          addParticle(loop.bx, loop.by, 'bubble');
          bubThrottle = 0.08;
        }
      }

      // Process Cavity Monsters & Cleanliness
      let aliveCount = 0;
      let drainRate = 0;
      const attackReach = 55; // Collision hit radius in pixels
      const updatedMonsters: Monster[] = [];

      for (const m of loop.monsters) {
        if (m.popping) continue;
        aliveCount++;
        // Balanced damage drain
        drainRate += (1.4 + 0.6 * (m.maxHp - 1)) * currentStageCfg.drainMultiplier;

        const toothCenter = getToothCenter(m.toothId);
        const distance = Math.hypot(loop.bx - toothCenter.x, loop.by - toothCenter.y);

        // ATTACK TRIGGER FIX:
        // Attack applies if brush is within range AND player is brushing (Space, Mouse click/drag, Touch, or Action Button)
        if (distance <= attackReach && isBrushing) {
          m.hp -= dt * 3.5;
          bubThrottle -= dt;
          if (bubThrottle <= 0) {
            addParticle(toothCenter.x, toothCenter.y, 'bubble');
            bubThrottle = 0.06;
          }

          if (m.hp <= 0) {
            // Monster defeated!
            m.popping = true;
            loop.killed++;
            setMonstersKilled(loop.killed);
            playPopSound();
            addParticle(toothCenter.x, toothCenter.y, 'sparkle');

            // Flash tooth
            setFlashingTeeth((prev) => ({ ...prev, [m.toothId]: true }));
            setTimeout(() => {
              setFlashingTeeth((prev) => {
                const next = { ...prev };
                delete next[m.toothId];
                return next;
              });
            }, 600);

            // Clean bonus for defeating monster
            loop.clean = Math.min(100, loop.clean + 2.5);
          }
        }

        if (!m.popping) {
          updatedMonsters.push(m);
        }
      }

      loop.monsters = updatedMonsters;
      setMonsters([...updatedMonsters]);

      // Cleanliness natural recovery vs tooth decay drain
      if (aliveCount === 0) {
        loop.clean = Math.min(100, loop.clean + 5.0 * dt);
      } else {
        loop.clean -= drainRate * dt;
      }
      setCleanliness(Math.max(0, loop.clean));

      // Spawn timer update
      loop.spawnTimer -= dt;
      if (loop.spawnTimer <= 0) {
        if (aliveCount < currentStageCfg.maxMonsters) {
          spawnMonster();
        }
        loop.spawnTimer = currentStageCfg.spawnInterval;
      }

      // Check Game Over condition
      if (loop.clean <= 0) {
        loop.clean = 0;
        setCleanliness(0);
        handleGameOver(false);
      }
    };

    animId = requestAnimationFrame(gameLoop);
    return () => cancelAnimationFrame(animId);
  }, [addParticle, getToothCenter, handleGameOver, spawnMonster]);

  // Teeth data array
  const teethData = Array.from({ length: TOTAL_TEETH }, (_, i) => ({
    id: i,
    row: i < TEETH_PER_ROW ? ('top' as const) : ('bottom' as const),
    index: i < TEETH_PER_ROW ? i : i - TEETH_PER_ROW,
  }));

  const currentStage = STAGE_CONFIGS[currentStageIndex];
  const activeMonsterToothMap = monsters.reduce<Record<number, Monster>>((acc, m) => {
    acc[m.toothId] = m;
    return acc;
  }, {});

  return (
    <div
      id="gameStageWrapper"
      className="relative w-full h-screen overflow-hidden select-none bg-slate-900 font-sans text-slate-800"
    >
      {/* Background Ambient Bathroom Image Layer */}
      <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
        <img
          src={bathroomBgImg}
          alt="Bathroom Sink Mirror Background"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center opacity-30 filter blur-[2px] scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-sky-200/60 via-cyan-100/40 to-sky-300/70" />
      </div>

      {/* Main Interactive Stage */}
      <div
        ref={stageRef}
        id="stage"
        onPointerDown={(e) => {
          loopStateRef.current.isPointerDown = true;
          updatePointer(e.clientX, e.clientY);
        }}
        onPointerMove={(e) => {
          updatePointer(e.clientX, e.clientY);
        }}
        onPointerUp={() => {
          loopStateRef.current.isPointerDown = false;
        }}
        onPointerCancel={() => {
          loopStateRef.current.isPointerDown = false;
        }}
        className={`relative z-10 w-full h-full flex flex-col items-center justify-between cursor-none touch-none ${
          cleanliness < 30 && gameState === 'play' ? 'animate-shake' : ''
        }`}
      >
        {/* Top Header Bar */}
        <header
          id="topHeader"
          className="w-full max-w-4xl mx-auto px-4 py-2 mt-2 flex items-center justify-between bg-white/85 backdrop-blur-md rounded-2xl border border-white/80 shadow-md z-20"
        >
          <div className="flex items-center gap-2">
            <img
              src={cleanToothImg}
              alt="Healthy Tooth Mascot"
              referrerPolicy="no-referrer"
              className="w-8 h-8 rounded-full border border-sky-300 shadow-sm object-cover"
            />
            <div>
              <h1 className="text-sm sm:text-base font-extrabold text-sky-900 leading-tight">
                충치 몬스터 무찌르기 🦷
              </h1>
              <p className="text-xs text-sky-700 hidden sm:block">
                스페이스 바를 누르거나 화면을 문질러 충치를 물리치세요!
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              id="soundToggleBtn"
              onClick={() => {
                const muted = toggleMute();
                setIsMutedState(muted);
              }}
              className="p-2 rounded-xl bg-sky-50 hover:bg-sky-100 text-sky-700 border border-sky-200 transition-colors shadow-sm cursor-pointer"
              title={isMutedState ? '소리 켜기' : '소리 끄기'}
            >
              {isMutedState ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
            </button>
            <div className="px-3 py-1 bg-amber-50 border border-amber-200 rounded-xl text-xs sm:text-sm font-bold text-amber-900 flex items-center gap-1 shadow-sm">
              <Trophy className="w-4 h-4 text-amber-500" />
              <span>최고 {bestTime.toFixed(1)}s</span>
            </div>
          </div>
        </header>

        {/* HUD: Cleanliness & Stage Bar */}
        <div id="hud" className="w-full max-w-2xl px-4 mt-2 flex flex-col gap-2 z-20">
          <div className="flex items-center gap-2 bg-white/90 backdrop-blur-sm p-2.5 rounded-2xl border border-white shadow-sm">
            <div className="text-xs sm:text-sm font-black text-sky-900 whitespace-nowrap flex items-center gap-1">
              <span>🫧 깨끗함</span>
            </div>
            <div className="flex-1 h-5 bg-sky-100/90 rounded-full border-2 border-white shadow-inner overflow-hidden relative">
              <div
                className={`h-full transition-all duration-200 rounded-full ${
                  cleanliness > 60
                    ? 'bg-gradient-to-r from-emerald-400 to-green-500'
                    : cleanliness > 30
                    ? 'bg-gradient-to-r from-amber-400 to-amber-500'
                    : 'bg-gradient-to-r from-rose-500 to-red-600 animate-pulse'
                }`}
                style={{ width: `${Math.max(0, Math.min(100, cleanliness))}%` }}
              />
            </div>
            <div className="text-xs sm:text-sm font-black text-sky-950 w-12 text-right">
              {Math.ceil(cleanliness)}%
            </div>
          </div>

          <div className="flex items-center justify-between px-1">
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 bg-rose-500 text-white rounded-full text-xs sm:text-sm font-black shadow-sm">
                {currentStage.name}
              </span>
              <span className="text-xs sm:text-sm font-bold text-sky-900 bg-white/80 px-2.5 py-0.5 rounded-full border border-sky-100">
                남은 시간: {Math.max(0, Math.ceil(currentStage.duration - stageElapsed))}초
              </span>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs sm:text-sm font-extrabold text-sky-900 bg-white/80 px-2.5 py-0.5 rounded-full border border-sky-100">
                ⏱ {totalElapsed.toFixed(1)}초
              </span>
              <span className="text-xs sm:text-sm font-extrabold text-purple-700 bg-purple-100 px-2.5 py-0.5 rounded-full border border-purple-200">
                퇴치: {monstersKilled}
              </span>
            </div>
          </div>
        </div>

        {/* Bathroom Mirror & Mouth Stage Area */}
        <div id="mouthWrap" className="relative flex-1 w-full flex items-center justify-center p-2 z-10">
          {/* Mirror Visual Frame */}
          <div
            id="mirrorFrame"
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[92vw] max-w-[580px] h-[58vh] max-h-[440px] rounded-[60px] border-8 border-white bg-gradient-to-br from-white/70 via-sky-50/40 to-white/60 shadow-2xl backdrop-blur-xs pointer-events-none overflow-hidden"
          >
            <div className="absolute top-4 right-6 text-xl animate-glint select-none">✨</div>
            {/* Mirror reflective diagonal sheen */}
            <div className="absolute -top-1/2 -left-1/2 w-[200%] h-[200%] bg-gradient-to-tr from-transparent via-white/20 to-transparent rotate-25 pointer-events-none" />
          </div>

          {/* Mouth Frame Container */}
          <div
            id="mouth"
            className="relative z-10 flex flex-col gap-4 sm:gap-6 bg-gradient-to-b from-rose-200 via-rose-300 to-rose-400 p-4 sm:p-6 rounded-[36px] border-4 border-white shadow-xl max-w-[94vw]"
          >
            {/* Upper Teeth Row */}
            <div className="flex justify-center gap-1.5 sm:gap-2.5">
              {teethData.slice(0, TEETH_PER_ROW).map((t) => {
                const monster = activeMonsterToothMap[t.id];
                const isFlashing = flashingTeeth[t.id];
                return (
                  <div
                    key={t.id}
                    ref={(el) => {
                      teethElementsRef.current[t.id] = el;
                    }}
                    className={`relative w-8 sm:w-11 h-11 sm:h-14 rounded-t-lg rounded-b-xl transition-all duration-200 border border-white/60 flex items-center justify-center ${
                      monster
                        ? 'bg-gradient-to-b from-amber-100 to-yellow-300 border-amber-400 scale-95 shadow-inner'
                        : 'bg-gradient-to-b from-white to-sky-50 shadow-md'
                    } ${isFlashing ? 'ring-4 ring-white scale-105 duration-75' : ''}`}
                  >
                    {/* Tooth shine glint */}
                    <div className="absolute top-1 left-1.5 w-1.5 h-3 bg-white/70 rounded-full" />

                    {/* Active Monster Sprite on Tooth */}
                    {monster && (
                      <div className="absolute inset-0 flex flex-col items-center justify-center animate-wob pointer-events-none z-20">
                        {/* Monster HP Bar */}
                        <div className="w-7 h-1.5 bg-black/40 rounded-full overflow-hidden mb-0.5 border border-white/40">
                          <div
                            className="h-full bg-rose-500 transition-all duration-100"
                            style={{ width: `${Math.max(0, (monster.hp / monster.maxHp) * 100)}%` }}
                          />
                        </div>

                        {/* Monster Image Asset */}
                        <div className="relative w-8 h-8 sm:w-10 sm:h-10 rounded-full overflow-hidden border border-white/80 shadow-md">
                          <img
                            src={monster.type === 'boss' ? bossMonImg : cavityMonImg}
                            alt="충치 몬스터"
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover"
                          />
                          {monster.type === 'boss' && (
                            <span className="absolute -top-1 -right-1 text-[10px]">👑</span>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Tongue & Inner Mouth Visual Gap */}
            <div className="h-3 sm:h-4 w-full bg-rose-500/50 rounded-full border border-rose-300/60 shadow-inner flex items-center justify-center">
              <span className="text-[10px] text-white/70 font-bold tracking-widest uppercase">치아 건강</span>
            </div>

            {/* Lower Teeth Row */}
            <div className="flex justify-center gap-1.5 sm:gap-2.5">
              {teethData.slice(TEETH_PER_ROW, TOTAL_TEETH).map((t) => {
                const monster = activeMonsterToothMap[t.id];
                const isFlashing = flashingTeeth[t.id];
                return (
                  <div
                    key={t.id}
                    ref={(el) => {
                      teethElementsRef.current[t.id] = el;
                    }}
                    className={`relative w-8 sm:w-11 h-11 sm:h-14 rounded-t-xl rounded-b-lg transition-all duration-200 border border-white/60 flex items-center justify-center ${
                      monster
                        ? 'bg-gradient-to-b from-yellow-300 to-amber-200 border-amber-400 scale-95 shadow-inner'
                        : 'bg-gradient-to-b from-sky-50 to-white shadow-md'
                    } ${isFlashing ? 'ring-4 ring-white scale-105 duration-75' : ''}`}
                  >
                    <div className="absolute bottom-1 left-1.5 w-1.5 h-3 bg-white/70 rounded-full" />

                    {monster && (
                      <div className="absolute inset-0 flex flex-col items-center justify-center animate-wob pointer-events-none z-20">
                        <div className="w-7 h-1.5 bg-black/40 rounded-full overflow-hidden mb-0.5 border border-white/40">
                          <div
                            className="h-full bg-rose-500 transition-all duration-100"
                            style={{ width: `${Math.max(0, (monster.hp / monster.maxHp) * 100)}%` }}
                          />
                        </div>
                        <div className="relative w-8 h-8 sm:w-10 sm:h-10 rounded-full overflow-hidden border border-white/80 shadow-md">
                          <img
                            src={monster.type === 'boss' ? bossMonImg : cavityMonImg}
                            alt="충치 몬스터"
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover"
                          />
                          {monster.type === 'boss' && (
                            <span className="absolute -top-1 -right-1 text-[10px]">👑</span>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Bottom Basin & Controls Area */}
        <footer className="relative w-full max-w-3xl px-4 pb-4 flex flex-col items-center gap-2 z-20">
          {/* Instruction Tip */}
          <div className="px-4 py-1.5 bg-white/85 backdrop-blur-md rounded-full border border-white/90 text-xs sm:text-sm font-extrabold text-sky-900 shadow-sm text-center">
            {isBrushingActive ? (
              <span className="text-emerald-600 flex items-center gap-1 justify-center">
                <Sparkles className="w-4 h-4 animate-spin" /> 치카치카 양치질 중! 충치를 문지르세요!
              </span>
            ) : (
              <span>⌨️ 스페이스 바를 누르거나 마우스/터치로 몬스터를 싹싹 문질러 물리치세요!</span>
            )}
          </div>

          {/* Mobile Quick Action Scrubbing Button */}
          <div className="w-full flex justify-center items-center gap-3">
            <button
              id="mobileScrubBtn"
              onPointerDown={() => {
                loopStateRef.current.isMobileActionButton = true;
                setIsBrushingActive(true);
              }}
              onPointerUp={() => {
                loopStateRef.current.isMobileActionButton = false;
                setIsBrushingActive(false);
              }}
              onPointerLeave={() => {
                loopStateRef.current.isMobileActionButton = false;
                setIsBrushingActive(false);
              }}
              className={`w-full max-w-sm py-3 px-6 rounded-2xl font-black text-sm sm:text-base text-white shadow-lg transition-all transform active:scale-95 flex items-center justify-center gap-2 cursor-pointer ${
                isBrushingActive
                  ? 'bg-gradient-to-r from-emerald-500 to-teal-500 ring-4 ring-emerald-200'
                  : 'bg-gradient-to-r from-sky-500 to-cyan-500 hover:from-sky-600 hover:to-cyan-600'
              }`}
            >
              <img
                src={toothbrushImg}
                alt="칫솔 아이콘"
                referrerPolicy="no-referrer"
                className="w-6 h-6 rounded-full object-cover border border-white"
              />
              <span>{isBrushingActive ? '치카치카 닦는 중! 🫧' : '꾹 눌러서 닦기 (스페이스 바)'}</span>
            </button>
          </div>
        </footer>

        {/* Dynamic Toothbrush Asset Cursor */}
        {gameState === 'play' && (
          <div
            id="toothbrushCursor"
            className="fixed pointer-events-none z-40 transition-transform duration-75 ease-out"
            style={{
              left: `${brushPos.x}px`,
              top: `${brushPos.y}px`,
              transform: 'translate(-50%, -50%)',
            }}
          >
            <div
              className={`relative transition-transform duration-100 ${
                isBrushingActive ? 'scale-110' : 'scale-100'
              }`}
              style={{ transform: `rotate(${brushRotation}deg)` }}
            >
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full border-2 border-white shadow-2xl overflow-hidden bg-white/95">
                <img
                  src={toothbrushImg}
                  alt="플레이어 칫솔"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover pointer-events-none"
                />
              </div>

              {/* Fresh mint foam bubbles on brush */}
              {isBrushingActive && (
                <div className="absolute -top-2 -right-2 text-base animate-bounce">🫧</div>
              )}
            </div>
          </div>
        )}

        {/* Particle Overlay (Bubbles & Sparkles) */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden z-30">
          {particles.map((p) => (
            <div
              key={p.id}
              className={`absolute ${p.type === 'bubble' ? 'animate-bubble' : 'animate-sparkle'}`}
              style={{
                left: `${p.x}px`,
                top: `${p.y}px`,
              }}
            >
              {p.type === 'bubble' ? (
                <div
                  className="rounded-full bg-white/90 border border-sky-300 shadow-sm"
                  style={{ width: `${p.size}px`, height: `${p.size}px` }}
                />
              ) : (
                <span className="text-xl">✨</span>
              )}
            </div>
          ))}
        </div>

        {/* Danger Edge Flash Overlay when cleanliness < 30 */}
        {cleanliness < 30 && gameState === 'play' && (
          <div className="absolute inset-0 pointer-events-none z-20 border-[8px] border-rose-500/40 animate-pulse" />
        )}

        {/* Stage Transition Toast Notification */}
        {isTransitioning && (
          <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-gradient-to-r from-emerald-500 to-teal-600 text-white px-6 py-4 rounded-3xl shadow-2xl border-4 border-white flex flex-col items-center gap-1 z-50 text-center animate-bounce">
            <span className="text-xl sm:text-2xl font-black">🎉 클리어! 다음 단계로 넘어갑니다!</span>
            <span className="text-sm sm:text-base font-bold text-emerald-100">
              ⏱ ({transitionCountdown}초 후 시작)
            </span>
          </div>
        )}

        {/* START OVERLAY */}
        {gameState === 'start' && (
          <div
            id="startModal"
            className="absolute inset-0 z-50 bg-sky-900/60 backdrop-blur-sm flex items-center justify-center p-4"
          >
            <div className="bg-white/95 backdrop-blur-md rounded-3xl border-4 border-white shadow-2xl max-w-md w-full p-6 sm:p-8 flex flex-col items-center text-center gap-4">
              <div className="relative">
                <img
                  src={cleanToothImg}
                  alt="건강한 치아"
                  referrerPolicy="no-referrer"
                  className="w-24 h-24 sm:w-28 sm:h-28 rounded-3xl border-4 border-sky-200 shadow-xl object-cover"
                />
                <span className="absolute -bottom-2 -right-2 text-2xl">✨</span>
              </div>

              <div>
                <h1 className="text-2xl sm:text-3xl font-black text-sky-950">충치 몬스터 무찌르기</h1>
                <p className="text-sm text-sky-700 font-semibold mt-1">
                  이빨에 몰려오는 충치 몬스터를 칫솔로 싹싹!
                </p>
              </div>

              {/* Game Asset Showcase Preview */}
              <div className="flex items-center justify-center gap-3 py-2 px-4 bg-sky-50 rounded-2xl border border-sky-100 w-full">
                <div className="flex flex-col items-center">
                  <img
                    src={toothbrushImg}
                    alt="칫솔"
                    referrerPolicy="no-referrer"
                    className="w-10 h-10 rounded-xl object-cover border border-sky-200 shadow-sm"
                  />
                  <span className="text-[11px] font-bold text-sky-800 mt-1">칫솔</span>
                </div>
                <span className="text-sky-300 font-bold">vs</span>
                <div className="flex flex-col items-center">
                  <img
                    src={cavityMonImg}
                    alt="일반 충치"
                    referrerPolicy="no-referrer"
                    className="w-10 h-10 rounded-xl object-cover border border-purple-200 shadow-sm"
                  />
                  <span className="text-[11px] font-bold text-purple-800 mt-1">충치균</span>
                </div>
                <div className="flex flex-col items-center">
                  <img
                    src={bossMonImg}
                    alt="보스 충치"
                    referrerPolicy="no-referrer"
                    className="w-10 h-10 rounded-xl object-cover border border-rose-200 shadow-sm"
                  />
                  <span className="text-[11px] font-bold text-rose-800 mt-1">설탕 보스</span>
                </div>
              </div>

              {/* Instructions Card */}
              <div className="bg-sky-50/80 rounded-2xl p-4 text-xs sm:text-sm text-left font-bold text-sky-900 border border-sky-100 flex flex-col gap-2 w-full">
                <p className="flex items-start gap-1.5">
                  <span>🖱️</span>
                  <span>
                    <b>마우스 이동</b> 또는 <b>화면 터치/방향키</b>로 칫솔을 몬스터 위치로 이동!
                  </span>
                </p>
                <p className="flex items-start gap-1.5">
                  <span>⌨️</span>
                  <span>
                    <b>스페이스 바</b>를 누르거나 <b>마우스 클릭/터치 문지르기</b>로 칫솔질!
                  </span>
                </p>
                <p className="flex items-start gap-1.5">
                  <span>💧</span>
                  <span>
                    충치를 방치하면 <b>깨끗함</b>이 줄어들어요. 0%가 되면 게임 오버!
                  </span>
                </p>
              </div>

              <button
                id="startGameBtn"
                onClick={handleStartGame}
                className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-sky-500 to-cyan-500 hover:from-sky-600 hover:to-cyan-600 text-white font-black text-base sm:text-lg shadow-lg hover:shadow-xl transition-all transform active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
              >
                <Play className="w-5 h-5 fill-current" />
                <span>시작하기 (Space)</span>
              </button>
            </div>
          </div>
        )}

        {/* GAME OVER / VICTORY OVERLAY */}
        {gameState === 'over' && (
          <div
            id="gameOverModal"
            className="absolute inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4"
          >
            <div className="bg-white rounded-3xl border-4 border-white shadow-2xl max-w-md w-full p-6 sm:p-8 flex flex-col items-center text-center gap-4">
              <div className="relative">
                <img
                  src={isVictory ? cleanToothImg : bossMonImg}
                  alt={isVictory ? '승리 치아' : '게임 오버 몬스터'}
                  referrerPolicy="no-referrer"
                  className="w-24 h-24 sm:w-28 sm:h-28 rounded-3xl border-4 border-sky-200 shadow-xl object-cover"
                />
                <span className="absolute -bottom-2 -right-2 text-2xl">
                  {isVictory ? '👑' : '😖'}
                </span>
              </div>

              <div>
                <h2
                  className={`text-2xl sm:text-3xl font-black ${
                    isVictory ? 'text-emerald-600' : 'text-rose-600'
                  }`}
                >
                  {isVictory ? '모든 단계 전설 클리어!' : '이빨이 위험해요!'}
                </h2>
                <p className="text-xs sm:text-sm text-slate-600 font-bold mt-1">
                  {isVictory
                    ? '🎉 완벽합니다! 모든 충치 몬스터를 물리치고 치아를 지켜냈습니다!'
                    : '충치균이 너무 많이 번식했어요. 다시 도전해볼까요?'}
                </p>
              </div>

              {/* Results Stats */}
              <div className="w-full bg-slate-50 border border-slate-200 rounded-2xl p-4 flex flex-col gap-2 text-xs sm:text-sm font-bold text-slate-800 text-left">
                <div className="flex justify-between items-center py-1 border-b border-slate-200/80">
                  <span className="text-slate-500">🎯 도달 단계:</span>
                  <span className="font-extrabold text-sky-900">
                    {currentStage.name} {isVictory ? '(완료)' : ''}
                  </span>
                </div>
                <div className="flex justify-between items-center py-1 border-b border-slate-200/80">
                  <span className="text-slate-500">🦠 무찌른 몬스터:</span>
                  <span className="font-extrabold text-purple-700">{monstersKilled}마리</span>
                </div>
                <div className="flex justify-between items-center py-1 border-b border-slate-200/80">
                  <span className="text-slate-500">⏱ 버틴 시간:</span>
                  <span className="font-extrabold text-sky-950">{totalElapsed.toFixed(1)}초</span>
                </div>
                <div className="flex justify-between items-center py-1">
                  <span className="text-slate-500">🏆 최고 기록:</span>
                  <span className="font-extrabold text-amber-600 flex items-center gap-1">
                    {bestTime.toFixed(1)}초
                    {isNewRecord && (
                      <span className="text-[10px] bg-rose-500 text-white px-1.5 py-0.5 rounded-full animate-bounce">
                        NEW!
                      </span>
                    )}
                  </span>
                </div>
              </div>

              <button
                id="playAgainBtn"
                onClick={handleStartGame}
                className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-sky-500 to-cyan-500 hover:from-sky-600 hover:to-cyan-600 text-white font-black text-base sm:text-lg shadow-lg hover:shadow-xl transition-all transform active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
              >
                <RotateCcw className="w-5 h-5" />
                <span>다시 도전하기 (Space)</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
