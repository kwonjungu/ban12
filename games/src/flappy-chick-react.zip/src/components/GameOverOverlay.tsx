import React from 'react';
import { GameDifficulty, MedalInfo } from '../types';
import { ASSET_URLS } from '../utils/assets';

interface GameOverOverlayProps {
  score: number;
  best: number;
  isNewRecord: boolean;
  passedPipes: number;
  starCount: number;
  maxCombo: number;
  currentDiff: GameDifficulty;
  onChangeDiff: (diff: GameDifficulty) => void;
  onRestart: () => void;
  onHome: () => void;
}

export function getMedalInfo(score: number): MedalInfo {
  if (score >= 100) return { icon: '🌈', name: '전설의 무지개 메달', desc: '경이로운 비행 실력! 전설의 병아리입니다!' };
  if (score >= 60) return { icon: '🥇', name: '빛나는 금메달', desc: '하늘의 지배자! 정말 훌륭해요!' };
  if (score >= 30) return { icon: '🥈', name: '멋진 은메달', desc: '안정적인 실력! 다음엔 금메달 도전!' };
  if (score >= 12) return { icon: '🥉', name: '자랑스러운 동메달', desc: '좋은 시작이에요! 조금만 더 비행해봐요.' };
  return { icon: '🥚', name: '따뜻한 달걀 메달', desc: '아직 메달이 없어요. 별을 모아 힘을 내보세요!' };
}

export const GameOverOverlay: React.FC<GameOverOverlayProps> = ({
  score,
  best,
  isNewRecord,
  passedPipes,
  starCount,
  maxCombo,
  currentDiff,
  onChangeDiff,
  onRestart,
  onHome,
}) => {
  const medal = getMedalInfo(score);
  const diffToBest = best - score;

  return (
    <div
      id="overScreen"
      className="absolute inset-0 flex flex-col items-center justify-center p-3 text-center bg-gradient-to-b from-slate-900/60 via-slate-900/75 to-slate-950/90 z-20 backdrop-blur-[2px]"
      onClick={onRestart}
    >
      {/* Title */}
      <h2
        id="over-heading"
        className={`text-2xl font-black mb-1 drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)] ${
          isNewRecord ? 'text-amber-300 animate-pulse' : 'text-rose-400'
        }`}
      >
        {isNewRecord ? '🎉 신기록 달성!' : '💥 부딪혔다!'}
      </h2>

      {/* Score Summary Card */}
      <div
        className="w-full max-w-[270px] bg-white/95 rounded-2xl p-3.5 shadow-2xl border-2 border-amber-300 text-slate-800 space-y-2.5"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Medal Badge */}
        <div className="flex flex-col items-center justify-center -mt-1">
          <div className="text-4xl filter drop-shadow leading-tight animate-bounce">
            {medal.icon}
          </div>
          <div className="text-xs font-black text-amber-900 mt-0.5">
            {medal.name}
          </div>
          <p className="text-[10px] text-slate-500 font-semibold m-0">
            {medal.desc}
          </p>
        </div>

        {/* Current Score Display */}
        <div className="bg-amber-50 rounded-xl py-2 px-3 border border-amber-200/80">
          <div className="text-[10px] font-bold text-amber-800/80">이번 비행 점수</div>
          <div className="text-3xl font-black text-amber-600 tracking-tight leading-none my-1">
            {score}
            <span className="text-sm font-bold text-amber-700 ml-1">점</span>
          </div>

          <div className="text-[11px] font-extrabold text-slate-600 flex items-center justify-center gap-2">
            <span>🏆 최고 기록: {best}점</span>
          </div>
        </div>

        {/* Detail Stats */}
        <div className="grid grid-cols-3 gap-1 bg-slate-50 rounded-xl p-1.5 border border-slate-200 text-center text-[10px]">
          <div>
            <div className="text-slate-400 font-bold">통과 파이프</div>
            <div className="font-extrabold text-slate-700">{passedPipes}개</div>
          </div>
          <div className="border-x border-slate-200">
            <div className="text-slate-400 font-bold">모은 별</div>
            <div className="font-extrabold text-amber-600 flex items-center justify-center gap-0.5">
              <span>⭐</span> {starCount}
            </div>
          </div>
          <div>
            <div className="text-slate-400 font-bold">최대 콤보</div>
            <div className="font-extrabold text-indigo-600">{maxCombo}연속</div>
          </div>
        </div>

        {/* Encouraging Remark */}
        <div className="text-[11px] font-extrabold">
          {isNewRecord ? (
            <span className="text-emerald-600">✨ 멋져요! 최고 점수를 갱신했습니다!</span>
          ) : diffToBest <= 0 ? (
            <span className="text-amber-600">아쉬워요! 최고 기록과 동점! 1점만 더!</span>
          ) : (
            <span className="text-rose-500">최고 기록까지 {diffToBest}점 남았어요!</span>
          )}
        </div>

        {/* Difficulty Selector in Game Over */}
        <div className="pt-0.5">
          <div className="text-[10px] font-bold text-slate-500 mb-1">난이도 재선택</div>
          <div className="grid grid-cols-3 gap-1">
            {([0, 1, 2] as GameDifficulty[]).map((d) => (
              <button
                key={d}
                type="button"
                id={`gameover-diff-btn-${d}`}
                onClick={() => onChangeDiff(d)}
                className={`py-1 px-1.5 rounded-lg text-[10px] font-black transition-all cursor-pointer ${
                  currentDiff === d
                    ? 'bg-amber-400 text-amber-950 shadow border border-amber-600'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200 border border-slate-200'
                }`}
              >
                {d === 0 ? '🌱 쉬움' : d === 1 ? '🐥 보통' : '🔥 어려움'}
              </button>
            ))}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-2 pt-1">
          <button
            type="button"
            id="btn-game-retry"
            onClick={onRestart}
            className="flex-1 py-2 px-3 rounded-xl font-black text-xs text-amber-950 bg-gradient-to-b from-amber-300 via-amber-400 to-amber-500 hover:from-amber-200 hover:to-amber-400 active:scale-95 shadow border-b-2 border-amber-600 transition-all cursor-pointer flex items-center justify-center gap-1"
          >
            <span>🔄</span> 다시 도전
          </button>
          <button
            type="button"
            id="btn-game-home"
            onClick={onHome}
            className="py-2 px-3 rounded-xl font-bold text-xs text-slate-700 bg-slate-100 hover:bg-slate-200 active:scale-95 border border-slate-300 transition-all cursor-pointer"
          >
            메인으로
          </button>
        </div>
      </div>

      <div className="mt-3 text-[11px] font-bold text-amber-200/90 drop-shadow animate-pulse pointer-events-none">
        스페이스나 화면 터치로 바로 다시 시작할 수 있어요!
      </div>
    </div>
  );
};
