import React from 'react';
import { GameDifficulty } from '../types';
import { ASSET_URLS } from '../utils/assets';

interface TitleOverlayProps {
  currentDiff: GameDifficulty;
  onChangeDiff: (diff: GameDifficulty) => void;
  onStart: () => void;
}

const DIFF_LABELS: { [key in GameDifficulty]: { name: string; desc: string; icon: string } } = {
  0: { name: '쉬움', desc: '느린 속도 & 넓은 파이프', icon: '🌱' },
  1: { name: '보통', desc: '기본 권장 밸런스', icon: '🐥' },
  2: { name: '어려움', desc: '빠른 속도 & 좁은 간격', icon: '🔥' },
};

export const TitleOverlay: React.FC<TitleOverlayProps> = ({
  currentDiff,
  onChangeDiff,
  onStart,
}) => {
  return (
    <div
      id="titleScreen"
      className="absolute inset-0 flex flex-col items-center justify-center p-3 text-center bg-gradient-to-b from-slate-900/50 via-slate-900/70 to-slate-950/85 z-20 backdrop-blur-[2px]"
      onClick={onStart}
    >
      {/* App Header with Character Asset */}
      <div className="flex flex-col items-center gap-1.5 mb-2 pointer-events-none">
        <div className="relative">
          <img
            src={ASSET_URLS.chick}
            alt="귀여운 병아리"
            referrerPolicy="no-referrer"
            className="w-20 h-20 rounded-full shadow-2xl border-4 border-amber-300 ring-4 ring-amber-400/40 animate-bounce object-cover bg-amber-100"
          />
          <span className="absolute -bottom-1 -right-1 text-xl drop-shadow-md">✨</span>
        </div>

        <h1
          id="title-heading"
          className="text-2xl font-black tracking-tight text-amber-300 drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)] m-0"
        >
          파닥파닥 병아리 🐤
        </h1>
        <p className="text-xs font-semibold text-amber-100/90 drop-shadow m-0">
          탭 한 번에 파닥! 파이프 사이를 쏙쏙!
        </p>
      </div>

      {/* Main Info Card */}
      <div
        className="w-full max-w-[270px] bg-white/95 rounded-2xl p-3.5 shadow-2xl border-2 border-amber-300 text-slate-800 space-y-2.5"
        onClick={(e) => e.stopPropagation()}
      >
        <div>
          <div className="text-[11px] font-bold text-slate-500 mb-1.5 flex items-center justify-center gap-1">
            <span>🎯</span> 난이도 선택
          </div>
          <div className="grid grid-cols-3 gap-1.5">
            {([0, 1, 2] as GameDifficulty[]).map((d) => (
              <button
                key={d}
                type="button"
                id={`diff-btn-${d}`}
                onClick={() => onChangeDiff(d)}
                className={`py-1.5 px-2 rounded-xl text-xs font-extrabold transition-all cursor-pointer ${
                  currentDiff === d
                    ? 'bg-gradient-to-b from-amber-400 to-amber-500 text-amber-950 shadow-md scale-105 border-2 border-amber-600'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200 border border-slate-300/80'
                }`}
              >
                <div>{DIFF_LABELS[d].icon} {DIFF_LABELS[d].name}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Feature & Rules Guide */}
        <div className="bg-amber-50/80 rounded-xl p-2 text-[11px] font-medium text-slate-700 leading-relaxed border border-amber-200/70 text-left space-y-1">
          <div className="flex items-center gap-1.5">
            <span className="text-sm">👆</span>
            <span><b>화면 터치/클릭</b> 또는 <b>스페이스바</b> 로 점프</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-sm">🟩</span>
            <span>파이프 통과 시 <b>+4점</b> (정중앙 <b>PERFECT 콤보</b>)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <img
              src={ASSET_URLS.star}
              alt="별"
              referrerPolicy="no-referrer"
              className="w-4 h-4 rounded-full inline-block object-cover border border-amber-400"
            />
            <span>별 획득 시 <b>+12점</b> 및 <b>🛡 보호막</b> 충전!</span>
          </div>
        </div>

        {/* Start Button */}
        <button
          type="button"
          id="btn-game-start"
          onClick={onStart}
          className="w-full py-2.5 px-4 rounded-xl font-black text-sm text-amber-950 bg-gradient-to-b from-amber-300 via-amber-400 to-amber-500 hover:from-amber-200 hover:to-amber-400 active:scale-[0.98] shadow-lg border-b-4 border-amber-600 transition-all cursor-pointer flex items-center justify-center gap-2"
        >
          <span>🚀</span>
          <span>지금 바로 시작하기</span>
        </button>
      </div>

      <div className="mt-3 text-[11px] font-bold text-amber-200/90 drop-shadow animate-pulse pointer-events-none">
        화면 아무 곳이나 톡 치면 바로 시작해요!
      </div>
    </div>
  );
};
