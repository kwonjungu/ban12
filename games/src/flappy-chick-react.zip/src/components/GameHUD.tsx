import React from 'react';
import { GameDifficulty } from '../types';
import { ASSET_URLS } from '../utils/assets';

interface GameHUDProps {
  score: number;
  best: number;
  timeSec: number;
  starCount: number;
  shields: number;
  currentDiff: GameDifficulty;
  muted: boolean;
  onToggleMute: () => void;
}

const DIFF_BADGES: { [key in GameDifficulty]: string } = {
  0: '🌱 쉬움',
  1: '🐥 보통',
  2: '🔥 어려움',
};

export const GameHUD: React.FC<GameHUDProps> = ({
  score,
  best,
  timeSec,
  starCount,
  shields,
  currentDiff,
  muted,
  onToggleMute,
}) => {
  return (
    <div
      id="hud"
      className="absolute left-0 right-0 top-0 flex items-center justify-between p-2 pointer-events-none z-10 select-none text-[11px] font-extrabold text-white"
    >
      {/* Left group */}
      <div className="flex items-center gap-1.5 flex-wrap">
        {/* Score Chip */}
        <div
          id="chipScore"
          className="bg-gradient-to-r from-amber-500 to-amber-600 border border-amber-300 rounded-full px-2.5 py-0.5 shadow-md flex items-center gap-1 text-xs font-black tracking-wide"
        >
          <span>🎯</span>
          <span>{score}점</span>
        </div>

        {/* Difficulty Chip */}
        <div className="bg-black/40 backdrop-blur-sm border border-white/20 rounded-full px-2 py-0.5 shadow-sm text-[10px] hidden xs:flex">
          {DIFF_BADGES[currentDiff]}
        </div>

        {/* Time Chip */}
        <div className="bg-black/40 backdrop-blur-sm border border-white/20 rounded-full px-2 py-0.5 shadow-sm text-[10px]">
          ⏱ {timeSec}s
        </div>

        {/* Star Chip with Asset icon */}
        <div
          id="chipStar"
          className="bg-amber-950/50 backdrop-blur-sm border border-amber-400/60 rounded-full px-2 py-0.5 shadow-sm flex items-center gap-1 text-amber-300"
        >
          <img
            src={ASSET_URLS.star}
            alt="별"
            referrerPolicy="no-referrer"
            className="w-3.5 h-3.5 rounded-full object-cover inline-block"
          />
          <span>{starCount}</span>
        </div>

        {/* Shield Chip with Asset icon */}
        <div
          id="chipShield"
          className={`backdrop-blur-sm rounded-full px-2 py-0.5 shadow-sm flex items-center gap-1 transition-all ${
            shields > 0
              ? 'bg-cyan-600/80 border border-cyan-300 text-cyan-100 shadow-[0_0_8px_rgba(6,182,212,0.6)] animate-pulse'
              : 'bg-black/40 border border-white/20 text-slate-300'
          }`}
        >
          <img
            src={ASSET_URLS.shield}
            alt="방패"
            referrerPolicy="no-referrer"
            className="w-3.5 h-3.5 rounded-full object-cover inline-block"
          />
          <span>{shields}</span>
        </div>
      </div>

      {/* Right group */}
      <div className="flex items-center gap-1.5 pointer-events-auto">
        {/* Best Score */}
        <div
          id="chipBest"
          className="bg-black/40 backdrop-blur-sm border border-white/20 rounded-full px-2 py-0.5 shadow-sm text-[10px] text-amber-200"
        >
          🏆 {best}
        </div>

        {/* Mute Button */}
        <button
          type="button"
          id="btn-mute"
          onClick={onToggleMute}
          aria-label={muted ? '음소거 해제' : '음소거'}
          className="bg-black/50 hover:bg-black/70 active:scale-90 backdrop-blur-sm border border-white/30 rounded-full p-1 w-7 h-7 flex items-center justify-center cursor-pointer transition-transform shadow"
        >
          <span className="text-xs">{muted ? '🔇' : '🔊'}</span>
        </button>
      </div>
    </div>
  );
};
