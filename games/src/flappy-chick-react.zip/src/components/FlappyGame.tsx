import React, { useEffect, useRef, useState, useCallback } from 'react';
import {
  Bird,
  Cloud,
  FloatText,
  GameDifficulty,
  GameState,
  Particle,
  Pipe,
  StarItem,
  ThemeColors,
} from '../types';
import { loadGameAssets, GameAssets, ASSET_URLS } from '../utils/assets';
import { SoundFX } from '../utils/audio';
import { GameHUD } from './GameHUD';
import { TitleOverlay } from './TitleOverlay';
import { GameOverOverlay } from './GameOverOverlay';

const STORE_BEST = 'flappy-chick-best-v2';
const STORE_MUTE = 'flappy-chick-mute-v2';
const STORE_DIFF = 'flappy-chick-diff-v2';

const BH = 640;
const GROUND_H = 84;
const PIPE_W = 64;
const BIRD_R = 17;

const THEMES: ThemeColors[] = [
  // Day
  {
    skyTop: [126, 200, 227],
    skyBot: [210, 238, 245],
    hill: [110, 190, 110],
    hill2: [80, 160, 90],
    pipe: [100, 200, 80],
    pipeDark: [60, 140, 50],
    ground: [222, 216, 149],
    groundDark: [200, 190, 120],
    night: 0,
  },
  // Sunset
  {
    skyTop: [240, 140, 90],
    skyBot: [255, 210, 150],
    hill: [180, 120, 90],
    hill2: [140, 90, 70],
    pipe: [120, 190, 80],
    pipeDark: [80, 130, 50],
    ground: [210, 180, 130],
    groundDark: [180, 150, 100],
    night: 0,
  },
  // Night
  {
    skyTop: [12, 24, 50],
    skyBot: [30, 50, 90],
    hill: [40, 70, 70],
    hill2: [25, 45, 55],
    pipe: [80, 170, 110],
    pipeDark: [40, 100, 70],
    ground: [160, 150, 120],
    groundDark: [120, 110, 90],
    night: 1,
  },
];

function circleRect(
  cx: number,
  cy: number,
  r: number,
  rx: number,
  ry: number,
  rw: number,
  rh: number
): boolean {
  const nx = Math.max(rx, Math.min(cx, rx + rw));
  const ny = Math.max(ry, Math.min(cy, ry + rh));
  const dx = cx - nx;
  const dy = cy - ny;
  return dx * dx + dy * dy < r * r;
}

function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}

function lerpColor(
  c1: [number, number, number],
  c2: [number, number, number],
  t: number
): [number, number, number] {
  return [
    Math.round(lerp(c1[0], c2[0], t)),
    Math.round(lerp(c1[1], c2[1], t)),
    Math.round(lerp(c1[2], c2[2], t)),
  ];
}

function rgb(c: [number, number, number]): string {
  return `rgb(${c[0]},${c[1]},${c[2]})`;
}

function drawStarShape(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  spikes: number,
  outerRadius: number,
  innerRadius: number
) {
  let rot = (Math.PI / 2) * 3;
  const step = Math.PI / spikes;
  ctx.beginPath();
  ctx.moveTo(cx, cy - outerRadius);
  for (let i = 0; i < spikes; i++) {
    let x = cx + Math.cos(rot) * outerRadius;
    let y = cy + Math.sin(rot) * outerRadius;
    ctx.lineTo(x, y);
    rot += step;
    x = cx + Math.cos(rot) * innerRadius;
    y = cy + Math.sin(rot) * innerRadius;
    ctx.lineTo(x, y);
    rot += step;
  }
  ctx.lineTo(cx, cy - outerRadius);
  ctx.closePath();
}

export const FlappyGame: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Stored preferences
  const [currentDiff, setCurrentDiff] = useState<GameDifficulty>(() => {
    try {
      const v = localStorage.getItem(STORE_DIFF);
      return v !== null ? (parseInt(v, 10) as GameDifficulty) : 1;
    } catch {
      return 1;
    }
  });

  const [muted, setMuted] = useState<boolean>(() => {
    try {
      return localStorage.getItem(STORE_MUTE) === '1';
    } catch {
      return false;
    }
  });

  const [bestScore, setBestScore] = useState<number>(() => {
    try {
      const v = localStorage.getItem(STORE_BEST);
      return v !== null ? parseInt(v, 10) : 0;
    } catch {
      return 0;
    }
  });

  // UI state
  const [gameState, setGameState] = useState<GameState>(GameState.TITLE);
  const [hudScore, setHudScore] = useState<number>(0);
  const [hudTime, setHudTime] = useState<number>(0);
  const [hudStars, setHudStars] = useState<number>(0);
  const [hudShields, setHudShields] = useState<number>(0);
  const [isNewRecord, setIsNewRecord] = useState<boolean>(false);
  const [passedCount, setPassedCount] = useState<number>(0);
  const [maxCombo, setMaxCombo] = useState<number>(0);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Engine Refs
  const engineRef = useRef({
    state: GameState.TITLE,
    currentDiff: 1 as GameDifficulty,
    muted: false,
    best: 0,
    assets: null as GameAssets | null,
    score: 0,
    combo: 0,
    bestCombo: 0,
    starCount: 0,
    shields: 0,
    passed: 0,
    runTime: 0,
    groundX: 0,
    shake: 0,
    hitStop: 0,
    flashWhite: 0,
    overWait: 0,
    eventIdx: 0,
    themeFrom: 0,
    themeTo: 0,
    themeMix: 1,
    nowSec: 0,
    lastStartAt: -9,
    cssW: 400,
    cssH: 640,
    BW: 400,
    S: 1,
    bird: {
      x: 120,
      y: 300,
      vy: 0,
      rot: 0,
      pop: 1,
      stretch: 1,
      wing: 0,
      alive: true,
      inv: 0,
    } as Bird,
    pipes: [] as Pipe[],
    stars: [] as StarItem[],
    parts: [] as Particle[],
    floats: [] as FloatText[],
    clouds: [
      { x: 30, y: 70, s: 1.1, sp: 18 },
      { x: 180, y: 110, s: 0.8, sp: 12 },
      { x: 320, y: 50, s: 1.3, sp: 22 },
    ] as Cloud[],
    nightStars: [
      { x: 0.1, y: 0.15, r: 1.5, tw: 0.2 },
      { x: 0.28, y: 0.08, r: 2.2, tw: 1.4 },
      { x: 0.55, y: 0.22, r: 1.8, tw: 2.8 },
      { x: 0.72, y: 0.11, r: 1.2, tw: 0.9 },
      { x: 0.88, y: 0.28, r: 2.0, tw: 3.5 },
    ],
  });

  // Sync state into engineRef
  useEffect(() => {
    engineRef.current.currentDiff = currentDiff;
  }, [currentDiff]);

  useEffect(() => {
    engineRef.current.muted = muted;
  }, [muted]);

  useEffect(() => {
    engineRef.current.best = bestScore;
  }, [bestScore]);

  // Toast Helper
  const toastTimeoutRef = useRef<number | null>(null);
  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    if (toastTimeoutRef.current) window.clearTimeout(toastTimeoutRef.current);
    toastTimeoutRef.current = window.setTimeout(() => {
      setToastMessage(null);
    }, 1800);
  }, []);

  // Pipe Speed calculation based on difficulty and score
  const getPipeSpeed = useCallback((passed: number, diff: GameDifficulty) => {
    const baseSpeed = 120 + diff * 28;
    const accel = 1.3 + diff * 0.4;
    return baseSpeed + Math.min(passed, 50) * accel;
  }, []);

  // Pipe Gap calculation
  const getGapHeight = useCallback((passed: number, diff: GameDifficulty) => {
    const baseGap = 185 - diff * 16; // 185, 169, 153
    const minGap = 152 - diff * 14;  // 152, 138, 124
    if (passed < 5) return baseGap;
    const g = baseGap - (passed - 5) * (1.1 + diff * 0.3);
    return Math.max(minGap, g);
  }, []);

  // Pipe Spacing calculation (Bug in original code fixed here: 86px -> 210-240px)
  const getPipeSpacing = useCallback((passed: number, diff: GameDifficulty) => {
    const baseSpace = 240 - diff * 20; // 240, 220, 200
    const minSpace = 185 - diff * 15;  // 185, 170, 155
    if (passed < 5) return baseSpace;
    return Math.max(minSpace, baseSpace - (passed - 5) * 1.0);
  }, []);

  const spawnPipe = useCallback(
    (x: number, fixedY?: number) => {
      const e = engineRef.current;
      const gap = getGapHeight(e.passed, e.currentDiff);
      const minY = 90 + gap / 2;
      const maxY = BH - GROUND_H - 90 - gap / 2;
      const py = fixedY !== undefined ? fixedY : Math.random() * (maxY - minY) + minY;

      const pipe: Pipe = {
        x,
        y: py,
        baseY: py,
        gap,
        w: PIPE_W,
        scored: false,
        amp: e.passed > 6 && Math.random() < 0.35 ? Math.random() * 25 + 10 : 0,
        phase: Math.random() * Math.PI * 2,
      };
      e.pipes.push(pipe);

      // Star item chance (38%)
      if (Math.random() < 0.42) {
        const off = (Math.random() - 0.5) * (gap * 0.45);
        e.stars.push({
          pipe,
          off,
          x: x + PIPE_W * 0.5,
          y: py + off,
          spin: 0,
          got: false,
        });
      }
    },
    [getGapHeight]
  );

  const burstParticles = useCallback(
    (x: number, y: number, count: number, colors: string[], speed = 200, life = 0.6) => {
      const e = engineRef.current;
      for (let i = 0; i < count; i++) {
        const angle = Math.random() * Math.PI * 2;
        const spd = Math.random() * speed + 50;
        e.parts.push({
          x,
          y,
          vx: Math.cos(angle) * spd,
          vy: Math.sin(angle) * spd,
          g: 400,
          r: Math.random() * 3.5 + 2,
          c: colors[Math.floor(Math.random() * colors.length)],
          life,
          max: life,
        });
      }
    },
    []
  );

  const addFloatText = useCallback(
    (x: number, y: number, text: string, color = '#fff', size = 20) => {
      engineRef.current.floats.push({
        x,
        y,
        vy: -60,
        t: text,
        c: color,
        s: size,
        life: 0.8,
        max: 0.8,
      });
    },
    []
  );

  const resetRun = useCallback(() => {
    const e = engineRef.current;
    e.pipes = [];
    e.stars = [];
    e.parts = [];
    e.floats = [];

    e.bird.x = Math.max(90, e.BW * 0.28);
    e.bird.y = BH * 0.42;
    e.bird.vy = 0;
    e.bird.rot = 0;
    e.bird.pop = 1;
    e.bird.stretch = 1;
    e.bird.wing = 0;
    e.bird.alive = true;
    e.bird.inv = 0;

    e.score = 0;
    e.combo = 0;
    e.bestCombo = 0;
    e.starCount = 0;
    e.shields = 0;
    e.passed = 0;
    e.runTime = 0;
    e.shake = 0;
    e.hitStop = 0;
    e.flashWhite = 0;
    e.overWait = 0;
    e.eventIdx = 0;
    e.themeFrom = 0;
    e.themeTo = 0;
    e.themeMix = 1;

    setHudScore(0);
    setHudTime(0);
    setHudStars(0);
    setHudShields(0);
    setIsNewRecord(false);

    spawnPipe(e.BW + 40, BH * 0.42);
  }, [spawnPipe]);

  const startGame = useCallback(() => {
    const e = engineRef.current;
    if (e.nowSec - e.lastStartAt < 0.25) return;
    e.lastStartAt = e.nowSec;

    resetRun();
    e.state = GameState.READY;
    setGameState(GameState.READY);
    SoundFX.start(e.muted);
    showToast('준비! 화면을 톡 치면 출발! 🐤');
  }, [resetRun, showToast]);

  const flap = useCallback(() => {
    const e = engineRef.current;

    if (e.state === GameState.TITLE) {
      startGame();
      return;
    }

    if (e.state === GameState.READY) {
      e.state = GameState.PLAY;
      setGameState(GameState.PLAY);
      e.bird.vy = -380;
      e.bird.pop = 1.25;
      e.bird.stretch = 0.85;
      e.bird.wing = 1;
      SoundFX.flap(e.muted);
      return;
    }

    if (e.state === GameState.PLAY) {
      e.bird.vy = -380;
      e.bird.pop = 1.28;
      e.bird.stretch = 0.85;
      e.bird.wing = 1;
      SoundFX.flap(e.muted);
      return;
    }

    if (e.state === GameState.OVER) {
      if (e.overWait <= 0) {
        startGame();
      }
    }
  }, [startGame]);

  const loseShield = useCallback(() => {
    const e = engineRef.current;
    e.shields--;
    setHudShields(e.shields);
    e.bird.inv = 1.3;
    e.bird.vy = -420;
    e.shake = 16;
    e.hitStop = 0.09;
    e.flashWhite = 0.5;
    SoundFX.shieldBreak(e.muted);
    burstParticles(e.bird.x, e.bird.y, 26, ['#bfe9ff', '#7fd0ff', '#ffffff', '#4fa8e0'], 240, 0.7);
    addFloatText(e.bird.x, e.bird.y - 34, '🛡 방패가 막았어!', '#3fa8ff', 20);
    e.combo = 0;
  }, [burstParticles, addFloatText]);

  const die = useCallback(() => {
    const e = engineRef.current;
    if (!e.bird.alive) return;
    e.bird.alive = false;
    e.state = GameState.DYING;
    setGameState(GameState.DYING);
    if (e.bird.vy < -140) e.bird.vy = -140;
    e.shake = 22;
    e.hitStop = 0.1;
    e.flashWhite = 0.8;
    SoundFX.hit(e.muted);
    SoundFX.fall(e.muted);
    burstParticles(e.bird.x, e.bird.y, 30, ['#ffd85e', '#ff9f1c', '#ffffff', '#ff6b6b'], 260, 0.85);
  }, [burstParticles]);

  const showGameOver = useCallback(() => {
    const e = engineRef.current;
    e.state = GameState.OVER;
    e.overWait = 0.25;

    let isNew = false;
    if (e.score > e.best) {
      e.best = e.score;
      setBestScore(e.score);
      try {
        localStorage.setItem(STORE_BEST, String(e.score));
      } catch {
        // ignore
      }
      isNew = true;
      setIsNewRecord(true);
      SoundFX.medal(e.muted);
    } else {
      setIsNewRecord(false);
      if (e.score >= 12) SoundFX.medal(e.muted);
    }

    setPassedCount(e.passed);
    setMaxCombo(e.bestCombo);
    setGameState(GameState.OVER);
  }, []);

  // Difficulty switch handler
  const handleDiffChange = useCallback((d: GameDifficulty) => {
    setCurrentDiff(d);
    try {
      localStorage.setItem(STORE_DIFF, String(d));
    } catch {
      // ignore
    }
    SoundFX.event(engineRef.current.muted);
  }, []);

  // Mute toggle handler
  const handleToggleMute = useCallback(() => {
    setMuted((prev) => {
      const next = !prev;
      try {
        localStorage.setItem(STORE_MUTE, next ? '1' : '0');
      } catch {
        // ignore
      }
      return next;
    });
  }, []);

  // Return to Title
  const handleHome = useCallback(() => {
    engineRef.current.state = GameState.TITLE;
    setGameState(GameState.TITLE);
  }, []);

  // Resize handler
  const handleResize = useCallback(() => {
    const stage = containerRef.current;
    const cv = canvasRef.current;
    if (!stage || !cv) return;

    const r = stage.getBoundingClientRect();
    const cssW = Math.max(160, Math.round(r.width));
    const cssH = Math.max(240, Math.round(r.height));
    const dpr = Math.min(window.devicePixelRatio || 1, 3);

    cv.width = Math.round(cssW * dpr);
    cv.height = Math.round(cssH * dpr);
    cv.style.width = `${cssW}px`;
    cv.style.height = `${cssH}px`;

    const e = engineRef.current;
    e.cssW = cssW;
    e.cssH = cssH;
    e.S = cssH / BH;
    e.BW = cssW / e.S;
  }, []);

  // Game Loop
  useEffect(() => {
    const assets = loadGameAssets();
    engineRef.current.assets = assets;

    handleResize();
    window.addEventListener('resize', handleResize);

    const ro = window.ResizeObserver ? new ResizeObserver(handleResize) : null;
    if (ro && containerRef.current) ro.observe(containerRef.current);

    let animId: number;
    let lastTime = performance.now();

    const loop = (timestamp: number) => {
      let dt = (timestamp - lastTime) / 1000;
      lastTime = timestamp;
      if (dt > 0.08) dt = 0.08;

      const e = engineRef.current;
      e.nowSec = timestamp / 1000;

      // UPDATE PHASE
      if (e.shake > 0) e.shake = Math.max(0, e.shake - dt * 55);
      if (e.flashWhite > 0) e.flashWhite = Math.max(0, e.flashWhite - dt * 2.6);
      if (e.themeMix < 1) e.themeMix = Math.min(1, e.themeMix + dt * 1.2);
      e.bird.pop += (1 - e.bird.pop) * Math.min(1, dt * 9);
      e.bird.wing = Math.max(0, e.bird.wing - dt * 3.4);

      // Particles
      for (let i = e.parts.length - 1; i >= 0; i--) {
        const p = e.parts[i];
        p.life -= dt;
        if (p.life <= 0) {
          e.parts.splice(i, 1);
          continue;
        }
        p.vy += p.g * dt;
        p.x += p.vx * dt;
        p.y += p.vy * dt;
      }

      // Floating text
      for (let i = e.floats.length - 1; i >= 0; i--) {
        const f = e.floats[i];
        f.life -= dt;
        if (f.life <= 0) {
          e.floats.splice(i, 1);
          continue;
        }
        f.y += f.vy * dt;
        f.vy += 40 * dt;
      }

      const moveClouds = (delta: number, mult = 1) => {
        for (let i = 0; i < e.clouds.length; i++) {
          e.clouds[i].x -= e.clouds[i].sp * delta * mult;
          if (e.clouds[i].x < -100) e.clouds[i].x = e.BW + 80;
        }
      };

      if (e.state === GameState.TITLE) {
        e.bird.x = e.BW * 0.5;
        e.bird.y = BH * 0.44 + Math.sin(e.nowSec * 2.4) * 12;
        e.bird.rot = Math.sin(e.nowSec * 2.4) * 0.18;
        e.groundX -= 60 * dt;
        moveClouds(dt, 1);
      } else if (e.state === GameState.PAUSE || e.state === GameState.OVER) {
        if (e.overWait > 0) e.overWait = Math.max(0, e.overWait - dt);
        moveClouds(dt, 0.3);
      } else if (e.hitStop > 0) {
        e.hitStop -= dt;
      } else {
        const groundY = BH - GROUND_H;

        if (e.state === GameState.DYING) {
          e.bird.vy += 1500 * dt;
          e.bird.y += e.bird.vy * dt;
          e.bird.rot = Math.min(1.6, e.bird.rot + dt * 4.2);
          if (e.bird.y + BIRD_R >= groundY) {
            e.bird.y = groundY - BIRD_R;
            showGameOver();
          }
        } else if (e.state === GameState.READY) {
          e.bird.y = BH * 0.42 + Math.sin(e.nowSec * 4) * 8;
          e.bird.rot = Math.sin(e.nowSec * 4) * 0.08;
          e.groundX -= 100 * dt;
          moveClouds(dt, 1);
        } else if (e.state === GameState.PLAY) {
          e.runTime += dt;
          setHudTime(Math.floor(e.runTime));

          // Day / Sunset / Night dynamic events
          if (e.eventIdx === 0 && (e.runTime >= 18 || e.passed >= 8)) {
            e.themeFrom = 0;
            e.themeTo = 1;
            e.themeMix = 0;
            e.eventIdx++;
            SoundFX.event(e.muted);
            showToast('노을이 지고 있어! 🌇');
          } else if (e.eventIdx === 1 && (e.runTime >= 40 || e.passed >= 20)) {
            e.themeFrom = 1;
            e.themeTo = 2;
            e.themeMix = 0;
            e.eventIdx++;
            SoundFX.event(e.muted);
            showToast('밤이 찾아왔어! ⭐');
          }

          const spd = getPipeSpeed(e.passed, e.currentDiff);
          e.groundX -= spd * dt;
          moveClouds(dt, 1);

          e.bird.vy += 1350 * dt;
          e.bird.y += e.bird.vy * dt;
          if (e.bird.inv > 0) e.bird.inv = Math.max(0, e.bird.inv - dt);

          if (e.bird.vy < 0) {
            e.bird.rot = Math.max(-0.5, e.bird.rot - dt * 3.2);
          } else {
            e.bird.rot = Math.min(1.2, e.bird.rot + dt * 2.8);
          }

          // Ceiling bounce
          if (e.bird.y - BIRD_R <= 0) {
            e.bird.y = BIRD_R;
            e.bird.vy = 0;
          }

          // Ground collision
          if (e.bird.y + BIRD_R >= groundY) {
            e.bird.y = groundY - BIRD_R;
            die();
          } else {
            // Pipes update & collision
            for (let i = e.pipes.length - 1; i >= 0; i--) {
              const pp = e.pipes[i];
              pp.x -= spd * dt;
              if (pp.amp > 0) {
                pp.y = pp.baseY + Math.sin(e.runTime * 3 + pp.phase) * pp.amp;
              }

              // Score calculation
              if (!pp.scored && pp.x + pp.w < e.bird.x) {
                pp.scored = true;
                e.passed++;
                e.score += 4;
                setHudScore(e.score);

                const distCenter = Math.abs(e.bird.y - pp.y);
                if (distCenter < 24) {
                  e.combo++;
                  if (e.combo > e.bestCombo) e.bestCombo = e.combo;
                  const bonus = Math.min(e.combo, 5) * 4;
                  e.score += bonus;
                  setHudScore(e.score);
                  SoundFX.perfect(e.combo, e.muted);
                  addFloatText(e.bird.x, e.bird.y - 30, `PERFECT! +${4 + bonus}`, '#ffe27a', 24);
                  burstParticles(
                    e.bird.x,
                    e.bird.y,
                    14,
                    ['#ffe27a', '#ffffff', '#ffaa00'],
                    180,
                    0.6
                  );
                } else {
                  e.combo = 0;
                  SoundFX.score(0, e.muted);
                  addFloatText(e.bird.x, e.bird.y - 26, '+4', '#ffffff', 20);
                }
              }

              // Accurate collision with pipe lips & bodies
              const topH = pp.y - pp.gap / 2;
              const botY = pp.y + pp.gap / 2;
              const hitTopBody = circleRect(e.bird.x, e.bird.y, BIRD_R - 2, pp.x, 0, pp.w, topH - 24);
              const hitTopLip = circleRect(e.bird.x, e.bird.y, BIRD_R - 2, pp.x - 4, topH - 24, pp.w + 8, 24);
              const hitBotLip = circleRect(e.bird.x, e.bird.y, BIRD_R - 2, pp.x - 4, botY, pp.w + 8, 24);
              const hitBotBody = circleRect(e.bird.x, e.bird.y, BIRD_R - 2, pp.x, botY + 24, pp.w, groundY - (botY + 24));

              if (hitTopBody || hitTopLip || hitBotLip || hitBotBody) {
                if (e.shields > 0 && e.bird.inv <= 0) {
                  loseShield();
                } else if (e.bird.inv <= 0) {
                  die();
                  break;
                }
              }

              if (pp.x + pp.w < -60) {
                e.pipes.splice(i, 1);
              }
            }

            // Spawn next pipe with balanced spacing
            const lastPipe = e.pipes[e.pipes.length - 1];
            if (!lastPipe || e.BW - lastPipe.x >= getPipeSpacing(e.passed, e.currentDiff)) {
              spawnPipe(e.BW + 30);
            }

            // Stars collection
            for (let i = e.stars.length - 1; i >= 0; i--) {
              const st = e.stars[i];
              st.x = st.pipe.x + st.pipe.w * 0.5;
              st.y = st.pipe.y + st.off;
              st.spin += dt * 3.5;

              if (!st.got) {
                const dx = e.bird.x - st.x;
                const dy = e.bird.y - st.y;
                if (dx * dx + dy * dy < (BIRD_R + 16) * (BIRD_R + 16)) {
                  st.got = true;
                  e.starCount++;
                  e.score += 12;
                  e.shields = Math.min(2, e.shields + 1);
                  setHudStars(e.starCount);
                  setHudShields(e.shields);
                  setHudScore(e.score);
                  SoundFX.star(e.muted);
                  addFloatText(st.x, st.y - 20, '⭐ +12 (방패+1)', '#ffd85e', 22);
                  burstParticles(
                    st.x,
                    st.y,
                    18,
                    ['#ffd85e', '#ffffff', '#ffaa00', '#bfe9ff'],
                    200,
                    0.7
                  );
                }
              }

              if (st.x < -40 || st.got) {
                e.stars.splice(i, 1);
              }
            }
          }
        }
      }

      // RENDER PHASE
      const cv = canvasRef.current;
      if (cv) {
        const ctx = cv.getContext('2d');
        if (ctx) {
          const dpr = Math.min(window.devicePixelRatio || 1, 3);
          ctx.setTransform(1, 0, 0, 1, 0, 0);
          ctx.clearRect(0, 0, cv.width, cv.height);

          ctx.setTransform(dpr * e.S, 0, 0, dpr * e.S, 0, 0);
          ctx.save();

          if (e.shake > 0) {
            const sx = (Math.random() * 2 - 1) * (e.shake / e.S);
            const sy = (Math.random() * 2 - 1) * (e.shake / e.S);
            ctx.translate(sx, sy);
          }

          const tf = THEMES[e.themeFrom];
          const tt = THEMES[e.themeTo];
          const m = e.themeMix;

          const cHill = lerpColor(tf.hill, tt.hill, m);
          const cHill2 = lerpColor(tf.hill2, tt.hill2, m);
          const cPipe = lerpColor(tf.pipe, tt.pipe, m);
          const cPipeDark = lerpColor(tf.pipeDark, tt.pipeDark, m);
          const cGround = lerpColor(tf.ground, tt.ground, m);
          const cGroundDark = lerpColor(tf.groundDark, tt.groundDark, m);
          const isNight = lerp(tf.night, tt.night, m);

          // 1. SKY BACKDROP (Generated Asset Image with dynamic daytime/sunset/night filter)
          if (e.assets && e.assets.loaded && e.assets.bgImg.complete) {
            ctx.drawImage(e.assets.bgImg, 0, 0, e.BW, BH - GROUND_H);

            if (isNight > 0.05) {
              ctx.fillStyle = `rgba(10, 18, 48, ${isNight * 0.78})`;
              ctx.fillRect(0, 0, e.BW, BH - GROUND_H);
            } else if (e.themeTo === 1 || e.themeFrom === 1) {
              ctx.fillStyle = `rgba(235, 120, 50, ${m * 0.28})`;
              ctx.fillRect(0, 0, e.BW, BH - GROUND_H);
            }
          } else {
            // Fallback gradient
            const cSkyTop = lerpColor(tf.skyTop, tt.skyTop, m);
            const cSkyBot = lerpColor(tf.skyBot, tt.skyBot, m);
            const skyGrad = ctx.createLinearGradient(0, 0, 0, BH - GROUND_H);
            skyGrad.addColorStop(0, rgb(cSkyTop));
            skyGrad.addColorStop(1, rgb(cSkyBot));
            ctx.fillStyle = skyGrad;
            ctx.fillRect(0, 0, e.BW, BH);
          }

          // Night Stars twinkle
          if (isNight > 0.05) {
            ctx.save();
            ctx.fillStyle = '#ffffff';
            for (let ns = 0; ns < e.nightStars.length; ns++) {
              const nst = e.nightStars[ns];
              const alpha = 0.3 + 0.7 * Math.sin(e.nowSec * 3 + nst.tw);
              ctx.globalAlpha = isNight * alpha;
              ctx.beginPath();
              ctx.arc(nst.x * e.BW, nst.y * (BH - GROUND_H), nst.r, 0, Math.PI * 2);
              ctx.fill();
            }
            ctx.restore();
          }

          // Clouds
          ctx.fillStyle = 'rgba(255, 255, 255, 0.75)';
          for (let cl = 0; cl < e.clouds.length; cl++) {
            const cld = e.clouds[cl];
            ctx.beginPath();
            ctx.arc(cld.x, cld.y, 22 * cld.s, 0, Math.PI * 2);
            ctx.arc(cld.x + 16 * cld.s, cld.y - 12 * cld.s, 18 * cld.s, 0, Math.PI * 2);
            ctx.arc(cld.x + 32 * cld.s, cld.y, 20 * cld.s, 0, Math.PI * 2);
            ctx.fill();
          }

          // Hills
          ctx.fillStyle = rgb(cHill2);
          ctx.beginPath();
          ctx.moveTo(0, BH - GROUND_H);
          for (let hx = 0; hx <= e.BW + 20; hx += 20) {
            ctx.lineTo(hx, BH - GROUND_H - 45 - Math.sin(hx * 0.012) * 20);
          }
          ctx.lineTo(e.BW + 20, BH - GROUND_H);
          ctx.closePath();
          ctx.fill();

          ctx.fillStyle = rgb(cHill);
          ctx.beginPath();
          ctx.moveTo(0, BH - GROUND_H);
          for (let hx2 = 0; hx2 <= e.BW + 20; hx2 += 20) {
            ctx.lineTo(hx2, BH - GROUND_H - 25 - Math.sin(hx2 * 0.02 + 1) * 15);
          }
          ctx.lineTo(e.BW + 20, BH - GROUND_H);
          ctx.closePath();
          ctx.fill();

          // 2. PIPES
          const groundY = BH - GROUND_H;
          for (let pi = 0; pi < e.pipes.length; pi++) {
            const p = e.pipes[pi];
            const topH = p.y - p.gap / 2;
            const botY = p.y + p.gap / 2;

            const pipeGrad = ctx.createLinearGradient(p.x, 0, p.x + p.w, 0);
            pipeGrad.addColorStop(0, rgb(cPipeDark));
            pipeGrad.addColorStop(0.35, rgb(cPipe));
            pipeGrad.addColorStop(0.8, rgb(cPipe));
            pipeGrad.addColorStop(1, rgb(cPipeDark));

            // Top Pipe
            ctx.fillStyle = pipeGrad;
            ctx.fillRect(p.x, 0, p.w, topH);
            ctx.fillRect(p.x - 4, topH - 24, p.w + 8, 24);

            ctx.fillStyle = 'rgba(255, 255, 255, 0.3)';
            ctx.fillRect(p.x + 8, 0, 6, topH - 24);
            ctx.fillRect(p.x + 6, topH - 22, 6, 20);

            // Bottom Pipe
            ctx.fillStyle = pipeGrad;
            ctx.fillRect(p.x, botY, p.w, groundY - botY);
            ctx.fillRect(p.x - 4, botY, p.w + 8, 24);

            ctx.fillStyle = 'rgba(255, 255, 255, 0.3)';
            ctx.fillRect(p.x + 8, botY + 24, 6, groundY - botY - 24);
            ctx.fillRect(p.x + 6, botY + 2, 6, 20);
          }

          // 3. STARS (Generated Star Item Asset directly inserted)
          for (let si = 0; si < e.stars.length; si++) {
            const st = e.stars[si];
            if (st.got) continue;
            ctx.save();
            ctx.translate(st.x, st.y);
            ctx.rotate(st.spin);

            if (e.assets && e.assets.loaded && e.assets.starImg.complete) {
              const starSize = 28;
              ctx.shadowColor = '#ffe27a';
              ctx.shadowBlur = 10;
              ctx.beginPath();
              ctx.arc(0, 0, starSize / 2, 0, Math.PI * 2);
              ctx.clip();
              ctx.drawImage(e.assets.starImg, -starSize / 2, -starSize / 2, starSize, starSize);
            } else {
              ctx.shadowColor = '#ffe27a';
              ctx.shadowBlur = 12;
              ctx.fillStyle = '#ffd85e';
              drawStarShape(ctx, 0, 0, 5, 14, 7);
              ctx.fill();

              ctx.fillStyle = '#ffffff';
              drawStarShape(ctx, 0, 0, 5, 8, 4);
              ctx.fill();
            }
            ctx.restore();
          }

          // 4. GROUND
          ctx.fillStyle = rgb(cGround);
          ctx.fillRect(0, groundY, e.BW, GROUND_H);

          ctx.fillStyle = rgb(cGroundDark);
          ctx.fillRect(0, groundY, e.BW, 14);

          ctx.fillStyle = 'rgba(0, 0, 0, 0.08)';
          const stripW = 20;
          const offsetX = e.groundX % (stripW * 2);
          for (let gx = -stripW * 2; gx < e.BW + stripW * 2; gx += stripW * 2) {
            ctx.beginPath();
            ctx.moveTo(gx + offsetX, groundY + 14);
            ctx.lineTo(gx + stripW + offsetX, groundY + 14);
            ctx.lineTo(gx + offsetX - 10, BH);
            ctx.lineTo(gx - stripW + offsetX - 10, BH);
            ctx.closePath();
            ctx.fill();
          }

          // 5. PARTICLES
          for (let pt = 0; pt < e.parts.length; pt++) {
            const pr = e.parts[pt];
            ctx.fillStyle = pr.c;
            ctx.globalAlpha = Math.max(0, pr.life / pr.max);
            ctx.beginPath();
            ctx.arc(pr.x, pr.y, pr.r, 0, Math.PI * 2);
            ctx.fill();
          }
          ctx.globalAlpha = 1;

          // 6. FLOATING TEXT
          for (let fl = 0; fl < e.floats.length; fl++) {
            const ft = e.floats[fl];
            ctx.save();
            ctx.font = `900 ${ft.s}px sans-serif`;
            ctx.fillStyle = ft.c;
            ctx.globalAlpha = Math.max(0, ft.life / ft.max);
            ctx.textAlign = 'center';
            ctx.shadowColor = 'rgba(0,0,0,0.55)';
            ctx.shadowBlur = 4;
            ctx.fillText(ft.t, ft.x, ft.y);
            ctx.restore();
          }

          // 7. CHICK CHARACTER & SHIELD (Generated Chick Asset directly inserted)
          ctx.save();
          ctx.translate(e.bird.x, e.bird.y);
          ctx.rotate(e.bird.rot);
          ctx.scale(e.bird.pop * e.bird.stretch, e.bird.pop / e.bird.stretch);

          if (e.bird.inv > 0 && Math.floor(e.nowSec * 20) % 2 === 0) {
            ctx.globalAlpha = 0.45;
          }

          // Shield Barrier Power-up
          if (e.shields > 0) {
            ctx.save();
            const shieldRadius = BIRD_R + 9 + Math.sin(e.nowSec * 6) * 2;
            ctx.beginPath();
            ctx.arc(0, 0, shieldRadius, 0, Math.PI * 2);
            ctx.fillStyle = 'rgba(6, 182, 212, 0.28)';
            ctx.strokeStyle = 'rgba(165, 243, 252, 0.9)';
            ctx.lineWidth = 3;
            ctx.shadowColor = '#06b6d4';
            ctx.shadowBlur = 12;
            ctx.fill();
            ctx.stroke();

            // Insert Shield asset icon on the bubble
            if (e.assets && e.assets.loaded && e.assets.shieldImg.complete) {
              const sz = shieldRadius * 1.8;
              ctx.globalAlpha = 0.35 + Math.sin(e.nowSec * 5) * 0.15;
              ctx.clip();
              ctx.drawImage(e.assets.shieldImg, -sz / 2, -sz / 2, sz, sz);
            }
            ctx.restore();
          }

          // Render Chick Sprite Asset
          if (e.assets && e.assets.loaded && e.assets.chickImg.complete) {
            ctx.save();
            ctx.shadowColor = 'rgba(0,0,0,0.3)';
            ctx.shadowBlur = 8;
            ctx.beginPath();
            ctx.arc(0, 0, BIRD_R, 0, Math.PI * 2);
            ctx.clip();
            ctx.drawImage(e.assets.chickImg, -BIRD_R, -BIRD_R, BIRD_R * 2, BIRD_R * 2);
            ctx.restore();

            // Crisp golden boundary ring
            ctx.beginPath();
            ctx.arc(0, 0, BIRD_R, 0, Math.PI * 2);
            ctx.strokeStyle = '#f59e0b';
            ctx.lineWidth = 2.5;
            ctx.stroke();
          } else {
            // Fallback Vector Chick
            ctx.shadowColor = 'rgba(0,0,0,0.2)';
            ctx.shadowBlur = 6;
            ctx.fillStyle = '#ffd85e';
            ctx.beginPath();
            ctx.arc(0, 0, BIRD_R, 0, Math.PI * 2);
            ctx.fill();

            ctx.fillStyle = '#ff7b25';
            ctx.beginPath();
            ctx.moveTo(11, -1);
            ctx.lineTo(19, 2);
            ctx.lineTo(11, 6);
            ctx.closePath();
            ctx.fill();
          }

          ctx.restore();

          // Ready State Prompt
          if (e.state === GameState.READY) {
            ctx.save();
            ctx.textAlign = 'center';
            ctx.font = '900 20px sans-serif';
            ctx.fillStyle = '#ffffff';
            ctx.shadowColor = 'rgba(0,0,0,0.6)';
            ctx.shadowBlur = 6;
            ctx.fillText('화면을 톡 치면 출발!', e.BW * 0.5, BH * 0.28);

            const tapY = BH * 0.28 + 28 + Math.sin(e.nowSec * 5) * 6;
            ctx.font = '28px sans-serif';
            ctx.fillText('👆', e.BW * 0.5, tapY);
            ctx.restore();
          }

          // White Flash FX
          if (e.flashWhite > 0) {
            ctx.fillStyle = `rgba(255, 255, 255, ${Math.min(1, e.flashWhite)})`;
            ctx.fillRect(0, 0, e.BW, BH);
          }

          ctx.restore();
        }
      }

      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', handleResize);
      if (ro) ro.disconnect();
    };
  }, [handleResize, showGameOver, die, loseShield, getPipeSpeed, getPipeSpacing, spawnPipe, burstParticles, addFloatText, showToast]);

  // Global Keyboard listener
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space' || e.key === ' ' || e.key === 'ArrowUp') {
        e.preventDefault();
        flap();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [flap]);

  // Visibility change
  useEffect(() => {
    const onVisibilityChange = () => {
      if (document.hidden && engineRef.current.state === GameState.PLAY) {
        engineRef.current.state = GameState.PAUSE;
        setGameState(GameState.PAUSE);
      }
    };
    document.addEventListener('visibilitychange', onVisibilityChange);
    return () => document.removeEventListener('visibilitychange', onVisibilityChange);
  }, []);

  return (
    <div className="relative w-full h-full flex flex-col items-center justify-center select-none overflow-hidden touch-manipulation">
      {/* Game Stage Screen */}
      <div
        id="stage"
        ref={containerRef}
        className="relative w-full max-w-[380px] h-[min(88vh,580px)] rounded-3xl overflow-hidden bg-[#7ec8e3] shadow-[0_16px_40px_rgba(0,0,0,0.5),0_0_0_3px_rgba(255,255,255,0.2)_inset] cursor-pointer"
        onPointerDown={(e) => {
          const target = e.target as HTMLElement;
          if (target.tagName === 'BUTTON' || target.closest('button')) return;
          e.preventDefault();
          flap();
        }}
      >
        <canvas id="cv" ref={canvasRef} className="block w-full h-full" />

        {/* HUD */}
        <GameHUD
          score={hudScore}
          best={bestScore}
          timeSec={hudTime}
          starCount={hudStars}
          shields={hudShields}
          currentDiff={currentDiff}
          muted={muted}
          onToggleMute={handleToggleMute}
        />

        {/* Toast Notification */}
        {toastMessage && (
          <div
            id="toast"
            className="absolute left-1/2 top-[12%] -translate-x-1/2 bg-slate-950/85 border-2 border-amber-300 text-white font-black text-xs py-1.5 px-3.5 rounded-full shadow-lg z-30 pointer-events-none whitespace-nowrap animate-in fade-in zoom-in duration-200"
          >
            {toastMessage}
          </div>
        )}

        {/* Title Screen Overlay */}
        {gameState === GameState.TITLE && (
          <TitleOverlay
            currentDiff={currentDiff}
            onChangeDiff={handleDiffChange}
            onStart={startGame}
          />
        )}

        {/* Game Over Overlay */}
        {gameState === GameState.OVER && (
          <GameOverOverlay
            score={hudScore}
            best={bestScore}
            isNewRecord={isNewRecord}
            passedPipes={passedCount}
            starCount={hudStars}
            maxCombo={maxCombo}
            currentDiff={currentDiff}
            onChangeDiff={handleDiffChange}
            onRestart={startGame}
            onHome={handleHome}
          />
        )}

        {/* Pause Overlay */}
        {gameState === GameState.PAUSE && (
          <div
            className="absolute inset-0 flex flex-col items-center justify-center bg-black/60 z-20 backdrop-blur-sm cursor-pointer"
            onClick={() => {
              engineRef.current.state = GameState.PLAY;
              setGameState(GameState.PLAY);
            }}
          >
            <div className="bg-white/95 rounded-2xl p-4 text-center text-slate-800 shadow-2xl border-2 border-amber-300 max-w-[220px]">
              <div className="text-3xl mb-1">⏸</div>
              <div className="text-sm font-black mb-1">일시정지</div>
              <p className="text-xs text-slate-500 font-semibold mb-3">
                화면을 터치하면 비행을 계속합니다!
              </p>
              <button
                type="button"
                className="w-full py-1.5 px-3 rounded-xl bg-amber-400 font-extrabold text-xs text-amber-950 shadow cursor-pointer"
              >
                계속하기
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Control Help Below Stage for Desktop/Tablet */}
      <div className="hidden sm:flex items-center gap-3 mt-3 text-[11px] font-semibold text-slate-300/80 bg-slate-900/50 backdrop-blur-sm px-3.5 py-1.5 rounded-full border border-white/10 shadow">
        <span>⌨️ [스페이스바] / [↑ 화살표]</span>
        <span>·</span>
        <span>🖱 마우스 클릭 / 터치</span>
        <span>·</span>
        <span className="text-amber-300 font-bold">⭐ 별을 먹으면 방패 충전!</span>
      </div>
    </div>
  );
};
