import chickSrc from '../assets/images/chick_character_1789882000578.jpg';
import starSrc from '../assets/images/golden_star_item_1789882013033.jpg';
import shieldSrc from '../assets/images/shield_bubble_icon_1789882024715.jpg';
import bgSrc from '../assets/images/flappy_sky_bg_1789882035049.jpg';

export interface GameAssets {
  chickImg: HTMLImageElement;
  starImg: HTMLImageElement;
  shieldImg: HTMLImageElement;
  bgImg: HTMLImageElement;
  loaded: boolean;
}

export const ASSET_URLS = {
  chick: chickSrc,
  star: starSrc,
  shield: shieldSrc,
  bg: bgSrc,
};

let cachedAssets: GameAssets | null = null;

export function loadGameAssets(onLoaded?: () => void): GameAssets {
  if (cachedAssets) {
    if (cachedAssets.loaded && onLoaded) onLoaded();
    return cachedAssets;
  }

  const chickImg = new Image();
  const starImg = new Image();
  const shieldImg = new Image();
  const bgImg = new Image();

  chickImg.crossOrigin = 'anonymous';
  starImg.crossOrigin = 'anonymous';
  shieldImg.crossOrigin = 'anonymous';
  bgImg.crossOrigin = 'anonymous';

  const assets: GameAssets = {
    chickImg,
    starImg,
    shieldImg,
    bgImg,
    loaded: false,
  };

  cachedAssets = assets;

  let loadedCount = 0;
  const total = 4;
  const checkDone = () => {
    loadedCount++;
    if (loadedCount >= total) {
      assets.loaded = true;
      if (onLoaded) onLoaded();
    }
  };

  chickImg.onload = checkDone;
  starImg.onload = checkDone;
  shieldImg.onload = checkDone;
  bgImg.onload = checkDone;

  chickImg.onerror = checkDone;
  starImg.onerror = checkDone;
  shieldImg.onerror = checkDone;
  bgImg.onerror = checkDone;

  chickImg.src = chickSrc;
  starImg.src = starSrc;
  shieldImg.src = shieldSrc;
  bgImg.src = bgSrc;

  return assets;
}
