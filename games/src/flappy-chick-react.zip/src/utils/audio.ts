/**
 * Web Audio sound synthesizer for Flappy Chick game
 */

let audioCtx: AudioContext | null = null;
let masterGain: GainNode | null = null;
let noiseBuffer: AudioBuffer | null = null;

export function initAudio(): boolean {
  if (!audioCtx) {
    const AudioCtxClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtxClass) return false;
    try {
      audioCtx = new AudioCtxClass();
      masterGain = audioCtx.createGain();
      masterGain.gain.value = 0.45;
      masterGain.connect(audioCtx.destination);
    } catch {
      audioCtx = null;
      return false;
    }
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume().catch(() => {});
  }
  return true;
}

function tone(
  freq: number,
  duration: number,
  type: OscillatorType = 'square',
  volume = 0.15,
  delay = 0,
  targetFreq?: number
) {
  if (!audioCtx || !masterGain) return;
  try {
    const t0 = audioCtx.currentTime + delay;
    const d = duration;
    const osc = audioCtx.createOscillator();
    const g = audioCtx.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(freq, t0);
    if (targetFreq) {
      osc.frequency.exponentialRampToValueAtTime(Math.max(20, targetFreq), t0 + d);
    }

    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(Math.max(0.001, volume), t0 + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + d);

    osc.connect(g);
    g.connect(masterGain);

    osc.start(t0);
    osc.stop(t0 + d + 0.05);
  } catch {
    // Ignore audio playback errors
  }
}

function noise(duration = 0.2, volume = 0.2, delay = 0, cutoff = 1400) {
  if (!audioCtx || !masterGain) return;
  try {
    if (!noiseBuffer) {
      const len = Math.floor(audioCtx.sampleRate * 0.5);
      noiseBuffer = audioCtx.createBuffer(1, len, audioCtx.sampleRate);
      const data = noiseBuffer.getChannelData(0);
      for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
    }

    const t0 = audioCtx.currentTime + delay;
    const d = duration;
    const src = audioCtx.createBufferSource();
    src.buffer = noiseBuffer;

    const filter = audioCtx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(cutoff, t0);
    filter.frequency.exponentialRampToValueAtTime(180, t0 + d);

    const g = audioCtx.createGain();
    g.gain.setValueAtTime(volume, t0);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + d);

    src.connect(filter);
    filter.connect(g);
    g.connect(masterGain);

    src.start(t0);
    src.stop(t0 + d + 0.05);
  } catch {
    // Ignore noise errors
  }
}

const SCALE_NOTES = [523.25, 587.33, 659.25, 698.46, 783.99, 880.0, 987.77, 1046.5, 1174.7, 1318.5];

export const SoundFX = {
  flap(muted: boolean) {
    if (muted || !initAudio()) return;
    tone(660, 0.09, 'triangle', 0.18, 0, 300);
    noise(0.08, 0.06, 0, 900);
  },
  score(combo: number, muted: boolean) {
    if (muted || !initAudio()) return;
    const note = SCALE_NOTES[Math.min(combo, SCALE_NOTES.length - 1)];
    tone(note, 0.11, 'square', 0.16);
    tone(note * 2, 0.09, 'triangle', 0.08, 0.02);
  },
  perfect(combo: number, muted: boolean) {
    if (muted || !initAudio()) return;
    const note = SCALE_NOTES[Math.min(combo, SCALE_NOTES.length - 1)];
    tone(note, 0.09, 'square', 0.16);
    tone(note * 1.5, 0.1, 'square', 0.13, 0.07);
    tone(note * 2, 0.14, 'triangle', 0.12, 0.14);
  },
  star(muted: boolean) {
    if (muted || !initAudio()) return;
    tone(880, 0.07, 'triangle', 0.18);
    tone(1318, 0.07, 'triangle', 0.16, 0.06);
    tone(1760, 0.15, 'triangle', 0.14, 0.12);
  },
  shieldBreak(muted: boolean) {
    if (muted || !initAudio()) return;
    tone(240, 0.18, 'sawtooth', 0.18, 0, 90);
    tone(880, 0.22, 'sine', 0.14, 0.02, 300);
    noise(0.22, 0.18, 0, 2400);
  },
  hit(muted: boolean) {
    if (muted || !initAudio()) return;
    noise(0.28, 0.32, 0, 2200);
    tone(180, 0.22, 'square', 0.24, 0, 60);
  },
  fall(muted: boolean) {
    if (muted || !initAudio()) return;
    tone(420, 0.55, 'sawtooth', 0.16, 0.1, 70);
  },
  start(muted: boolean) {
    if (muted || !initAudio()) return;
    tone(523, 0.1, 'square', 0.15, 0.0);
    tone(659, 0.1, 'square', 0.15, 0.09);
    tone(784, 0.1, 'square', 0.15, 0.18);
    tone(1046, 0.2, 'square', 0.15, 0.27);
  },
  event(muted: boolean) {
    if (muted || !initAudio()) return;
    tone(659, 0.1, 'triangle', 0.16);
    tone(988, 0.16, 'triangle', 0.12, 0.08);
  },
  medal(muted: boolean) {
    if (muted || !initAudio()) return;
    tone(523, 0.12, 'square', 0.15, 0.0);
    tone(659, 0.12, 'square', 0.15, 0.12);
    tone(784, 0.12, 'square', 0.15, 0.24);
    tone(1046, 0.32, 'square', 0.18, 0.36);
  },
};
