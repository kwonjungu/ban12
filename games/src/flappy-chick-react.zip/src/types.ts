export type GameDifficulty = 0 | 1 | 2; // 0: Easy, 1: Normal, 2: Hard

export enum GameState {
  TITLE = 'TITLE',
  READY = 'READY',
  PLAY = 'PLAY',
  DYING = 'DYING',
  OVER = 'OVER',
  PAUSE = 'PAUSE',
}

export interface Bird {
  x: number;
  y: number;
  vy: number;
  rot: number;
  pop: number;
  stretch: number;
  wing: number;
  alive: boolean;
  inv: number; // invulnerability countdown
}

export interface Pipe {
  x: number;
  y: number;
  baseY: number;
  gap: number;
  w: number;
  scored: boolean;
  amp: number;
  phase: number;
}

export interface StarItem {
  pipe: Pipe;
  off: number;
  spin: number;
  got: boolean;
  x: number;
  y: number;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  g: number;
  r: number;
  c: string;
  life: number;
  max: number;
}

export interface FloatText {
  x: number;
  y: number;
  vy: number;
  t: string;
  c: string;
  s: number;
  life: number;
  max: number;
}

export interface Cloud {
  x: number;
  y: number;
  s: number;
  sp: number;
}

export interface ThemeColors {
  skyTop: [number, number, number];
  skyBot: [number, number, number];
  hill: [number, number, number];
  hill2: [number, number, number];
  pipe: [number, number, number];
  pipeDark: [number, number, number];
  ground: [number, number, number];
  groundDark: [number, number, number];
  night: number;
}

export interface MedalInfo {
  icon: string;
  name: string;
  desc: string;
}
