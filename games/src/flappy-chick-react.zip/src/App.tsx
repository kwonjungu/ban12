/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { FlappyGame } from './components/FlappyGame';

export default function App() {
  return (
    <main
      id="app-root"
      className="w-screen h-screen overflow-hidden flex flex-col items-center justify-center bg-radial from-[#1e4976] via-[#102747] to-[#081324] text-white p-2"
    >
      <FlappyGame />
    </main>
  );
}
