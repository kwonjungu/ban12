// Web Audio API Synthesizer (No external audio files required)

class SoundEngine {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private noiseBuf: AudioBuffer | null = null;
  public enabled: boolean = true;

  constructor() {
    // Lazy initialization on first user gesture
  }

  public init() {
    if (this.ctx) return;
    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return;
      this.ctx = new AudioCtx();
      this.master = this.ctx.createGain();
      this.master.gain.value = 0.22;
      this.master.connect(this.ctx.destination);

      const len = Math.floor(this.ctx.sampleRate * 0.5);
      this.noiseBuf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
      const d = this.noiseBuf.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    } catch {
      this.ctx = null;
    }
  }

  public resume() {
    if (this.ctx && this.ctx.state === 'suspended') {
      try {
        this.ctx.resume();
      } catch {
        // ignore
      }
    }
  }

  public tone(freq: number, dur: number, type: OscillatorType = 'square', vol: number = 0.16, when: number = 0, slideTo?: number) {
    if (!this.ctx || !this.enabled || !this.master) return;
    try {
      const t = this.ctx.currentTime + (when || 0);
      const o = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      o.type = type;
      o.frequency.setValueAtTime(freq, t);
      if (slideTo) o.frequency.exponentialRampToValueAtTime(Math.max(30, slideTo), t + dur);
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(vol || 0.16, t + 0.008);
      g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      o.connect(g);
      g.connect(this.master);
      o.start(t);
      o.stop(t + dur + 0.03);
    } catch {
      // ignore
    }
  }

  public noise(dur: number, vol: number = 0.2, freq: number = 900, when: number = 0) {
    if (!this.ctx || !this.enabled || !this.noiseBuf || !this.master) return;
    try {
      const t = this.ctx.currentTime + (when || 0);
      const s = this.ctx.createBufferSource();
      s.buffer = this.noiseBuf;
      const f = this.ctx.createBiquadFilter();
      f.type = 'bandpass';
      f.frequency.value = freq;
      f.Q.value = 1.1;
      const g = this.ctx.createGain();
      g.gain.setValueAtTime(vol || 0.2, t);
      g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      s.connect(f);
      f.connect(g);
      g.connect(this.master);
      s.start(t);
      s.stop(t + dur + 0.02);
    } catch {
      // ignore
    }
  }

  private static SCALE = [0, 2, 4, 5, 7, 9, 11, 12, 14, 16, 17, 19, 21, 23, 24, 26, 28, 29, 31, 33, 36];
  private lastBrickTime = 0;
  private lastBreakTime = 0;

  public sfxBrick(combo: number) {
    const now = performance.now();
    if (now - this.lastBrickTime < 28) return;
    this.lastBrickTime = now;
    const i = Math.max(0, Math.min(combo - 1, SoundEngine.SCALE.length - 1));
    const f = 262 * Math.pow(2, SoundEngine.SCALE[i] / 12);
    this.tone(f, 0.09, 'square', 0.12);
    this.tone(f * 2, 0.05, 'triangle', 0.05, 0.01);
  }

  public sfxBreak(combo: number) {
    const now = performance.now();
    if (now - this.lastBreakTime < 32) return;
    this.lastBreakTime = now;
    const i = Math.max(0, Math.min(combo - 1, SoundEngine.SCALE.length - 1));
    const f = 262 * Math.pow(2, SoundEngine.SCALE[i] / 12);
    this.tone(f, 0.11, 'square', 0.14);
    this.tone(f * 1.5, 0.08, 'triangle', 0.08, 0.02);
    this.noise(0.05, 0.07, 1600);
  }

  public sfxPaddle() {
    this.tone(160, 0.07, 'square', 0.14, 0, 240);
  }

  public sfxWall() {
    this.tone(440, 0.035, 'triangle', 0.06);
  }

  public sfxGold() {
    this.tone(880, 0.08, 'triangle', 0.15, 0);
    this.tone(1175, 0.08, 'triangle', 0.15, 0.06);
    this.tone(1568, 0.14, 'triangle', 0.15, 0.12);
    this.noise(0.10, 0.09, 3200, 0.02);
  }

  public sfxPower() {
    this.tone(523, 0.07, 'square', 0.14, 0);
    this.tone(659, 0.07, 'square', 0.14, 0.06);
    this.tone(784, 0.07, 'square', 0.14, 0.12);
    this.tone(1047, 0.12, 'square', 0.14, 0.18);
  }

  public sfxLose() {
    this.tone(392, 0.16, 'sawtooth', 0.14, 0, 196);
    this.tone(262, 0.24, 'sawtooth', 0.13, 0.14, 98);
    this.noise(0.25, 0.11, 300, 0.1);
  }

  public sfxClear() {
    const n = [523, 659, 784, 1047, 1319];
    for (let i = 0; i < n.length; i++) this.tone(n[i], 0.15, 'square', 0.14, i * 0.075);
    this.tone(2093, 0.28, 'triangle', 0.09, 0.4);
  }

  public sfxStart() {
    const n = [262, 330, 392, 523];
    for (let i = 0; i < n.length; i++) this.tone(n[i], 0.10, 'square', 0.14, i * 0.06);
  }

  public sfxLaser() {
    this.tone(820, 0.04, 'sawtooth', 0.07);
  }

  public sfxEvent() {
    this.tone(180, 0.22, 'sawtooth', 0.15, 0, 600);
    this.tone(900, 0.14, 'square', 0.09, 0.12);
  }

  public sfxOver() {
    const n = [523, 415, 330, 262, 196];
    for (let i = 0; i < n.length; i++) this.tone(n[i], 0.20, 'triangle', 0.14, i * 0.13);
  }
}

export const sound = new SoundEngine();
