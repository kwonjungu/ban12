import React, { useEffect, useRef, useState, useCallback } from 'react';
import { Volume2, VolumeX, Trophy, Play, RotateCcw, Heart, Sparkles } from 'lucide-react';
import { sound } from './audio';
import { Brick, Ball, Power, Drop, Particle, PopText, Banner, Bullet, Star } from './types';

// Asset Images
import bgImgUrl from './assets/images/cosmic_nebula_bg_1789882468312.jpg';
import ballImgUrl from './assets/images/master_energy_ball_1789882481379.jpg';
import paddleImgUrl from './assets/images/scifi_energy_paddle_1789882495383.jpg';

const COLS = 10;
const PADX = 8;
const GAP = 3;
const TOPY = 20;

const HP_COLOR: Record<number, { a: string; b: string }> = {
  1: { a: '#5fd8ff', b: '#1f9fd6' },
  2: { a: '#ffe066', b: '#e0a316' },
  3: { a: '#ff7aa8', b: '#d43064' }
};

const GOLD = { a: '#fff3a8', b: '#e8a800' };

const PATTERNS = [
  [
    "..11..11..",
    ".11111111.",
    "1111111111",
    ".11111111.",
    "..111111..",
    "...1111...",
    "....11...."
  ],
  [
    "1.2.11.2.1",
    "1121111211",
    "3333333333",
    "1112221111",
    "1.GG..GG.1",
    "1111111111"
  ],
  [
    "1111111111",
    "2222222222",
    "3333333333",
    "1111111111",
    "2222222222",
    "G.G.GG.G.G",
    "1111111111"
  ],
  [
    "..333333..",
    ".33333333.",
    "33..33..33",
    "3333333333",
    "..22..22..",
    ".2..22..2.",
    "G........G"
  ],
  [
    "....11....",
    "...2222...",
    "..333333..",
    ".11GGGG11.",
    "..333333..",
    "...2222...",
    "....11...."
  ],
  [
    "3333333333",
    "1.2.GG.2.1",
    "2222222222",
    "11.3333.11",
    "3333333333",
    "1111111111",
    ".G..GG..G."
  ],
  [
    "3131313131",
    "1313131313",
    "2222GG2222",
    "1313131313",
    "3131313131",
    "2.3.GG.3.2"
  ],
  [
    "11......11",
    "2211..1122",
    "3322112233",
    "GG332233GG",
    "3322112233",
    "2211..1122",
    "11......11"
  ]
];

const POWERS: Power[] = [
  { id: 'wide', emoji: '🟩', col: '#7bf59a', name: '넓은 패들' },
  { id: 'multi', emoji: '🔵', col: '#8ecbff', name: '멀티볼 x3' },
  { id: 'pierce', emoji: '🔴', col: '#ff8f8f', name: '관통탄' },
  { id: 'laser', emoji: '🔫', col: '#ffd36b', name: '레이저 발사' },
  { id: 'life', emoji: '💖', col: '#ff9ec4', name: '목숨 +1' }
];

function clamp(v: number, a: number, b: number): number {
  return v < a ? a : (v > b ? b : v);
}
function rnd(a: number, b: number): number {
  return a + Math.random() * (b - a);
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const wrapRef = useRef<HTMLDivElement | null>(null);

  // Asset image refs
  const bgImgRef = useRef<HTMLImageElement | null>(null);
  const ballImgRef = useRef<HTMLImageElement | null>(null);
  const paddleImgRef = useRef<HTMLImageElement | null>(null);

  // React UI States
  const [screenMode, setScreenMode] = useState<'title' | 'play' | 'over'>('title');
  const [score, setScore] = useState<number>(0);
  const [stage, setStage] = useState<number>(1);
  const [lives, setLives] = useState<number>(3);
  const [time, setTime] = useState<number>(0);
  const [combo, setCombo] = useState<number>(0);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [ballCount, setBallCount] = useState<number>(100);
  const [activePowers, setActivePowers] = useState<{ wide: number; pierce: number; laser: number }>({
    wide: 0,
    pierce: 0,
    laser: 0
  });

  const [bestScore, setBestScore] = useState<number>(() => {
    try {
      const v = parseInt(localStorage.getItem('bb_best_v1') || '0', 10);
      return isFinite(v) ? v : 0;
    } catch {
      return 0;
    }
  });

  // Game loop internal refs
  const stateRef = useRef({
    screenMode: 'title' as 'title' | 'play' | 'over',
    W: 360,
    H: 560,
    bw: 32,
    bh: 16,
    score: 0,
    lives: 3,
    stage: 1,
    elapsed: 0,
    combo: 0,
    bestCombo: 0,
    perfect: true,
    eventTimer: 0,
    eventCount: 0,
    speedMul: 1,
    stageClearT: 0,
    shake: 0,
    hitStop: 0,
    flash: 0,
    overLock: 0,
    hitsThisTrip: 0,
    noHitT: 0,
    shotCd: 0,
    isLosingLife: false,
    readyToLaunch: true,
    launchQueue: 0,
    launchTimer: 0,
    aimAngle: 0,
    stuckBallCount: 100,
    keys: { left: false, right: false },
    pointerX: null as number | null,
    pointerActive: false,
    paddle: { x: 180, y: 520, w: 88, baseW: 88, h: 14, pop: 0, glow: 0 },
    timers: { wide: 0, pierce: 0, laser: 0 },
    bricks: [] as Brick[],
    balls: [] as Ball[],
    drops: [] as Drop[],
    parts: [] as Particle[],
    pops: [] as PopText[],
    banners: [] as Banner[],
    bullets: [] as Bullet[],
    stars: [] as Star[]
  });

  // Target Speed Calculation
  const getTargetSpeed = useCallback(() => {
    const s = stateRef.current;
    const base = 330 * clamp(s.H / 620, 0.86, 1.32);
    const speed = base * (1 + 0.08 * (s.stage - 1)) * s.speedMul;
    return Math.min(speed, 850);
  }, []);

  const createBall = useCallback((stuck: boolean, x?: number, y?: number): Ball => {
    const s = stateRef.current;
    return {
      x: x !== undefined ? x : s.paddle.x,
      y: y !== undefined ? y : s.paddle.y - 14,
      r: clamp(s.W * 0.022, 6.5, 9.5),
      vx: 0,
      vy: 0,
      stuck: !!stuck,
      angle: 0,
      trail: []
    };
  }, []);

  const layoutBricks = useCallback(() => {
    const s = stateRef.current;
    s.bw = (s.W - PADX * 2 - GAP * (COLS - 1)) / COLS;
    s.bh = clamp(s.bw * 0.48, 12, 22);
    for (let i = 0; i < s.bricks.length; i++) {
      const b = s.bricks[i];
      b.x = PADX + b.col * (s.bw + GAP);
      b.y = TOPY + b.row * (s.bh + GAP);
      b.w = s.bw;
      b.h = s.bh;
    }
  }, []);

  const buildStage = useCallback((n: number) => {
    const s = stateRef.current;
    s.bricks = [];
    const pat = PATTERNS[(n - 1) % PATTERNS.length];
    const cycle = Math.floor((n - 1) / PATTERNS.length);
    for (let r = 0; r < pat.length; r++) {
      const line = pat[r];
      for (let c = 0; c < COLS; c++) {
        const ch = line.charAt(c);
        if (ch === '.' || ch === '') continue;
        const gold = ch === 'G';
        let hp = gold ? 1 : parseInt(ch, 10);
        if (!gold) hp = clamp(hp + Math.min(cycle, 2), 1, 3);
        s.bricks.push({
          col: c,
          row: r,
          x: 0,
          y: 0,
          w: s.bw,
          h: s.bh,
          hp: hp,
          max: hp,
          gold: gold,
          pop: 0,
          alive: true,
          shine: Math.random() * 6
        });
      }
    }
    layoutBricks();
  }, [layoutBricks]);

  const popText = useCallback((x: number, y: number, txt: string, col: string = '#fff', sz: number = 16) => {
    stateRef.current.pops.push({ x, y, txt, col, life: 0.85, max: 0.85, sz, vy: -62 });
  }, []);

  const banner = useCallback((txt: string, col: string = '#fff') => {
    stateRef.current.banners.push({ txt, col, life: 1.25, max: 1.25 });
  }, []);

  const burst = useCallback((x: number, y: number, n: number, col: string, spd: number) => {
    const s = stateRef.current;
    for (let i = 0; i < n; i++) {
      const a = rnd(0, Math.PI * 2);
      const sp = rnd(spd * 0.3, spd);
      s.parts.push({
        x,
        y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp - 30,
        life: rnd(0.3, 0.68),
        max: 0.68,
        col,
        sz: rnd(2.5, 5.5)
      });
    }
  }, []);

  const resetBallOnPaddle = useCallback(() => {
    const s = stateRef.current;
    s.balls = [];
    s.launchQueue = 0;
    s.launchTimer = 0;
    s.readyToLaunch = true;
    s.aimAngle = 0;
    s.stuckBallCount = 100;
    s.drops = [];
    s.bullets = [];
    s.hitsThisTrip = 0;
    s.isLosingLife = false;
    setBallCount(100);
  }, []);

  const newGame = useCallback(() => {
    const s = stateRef.current;
    s.score = 0;
    s.lives = 3;
    s.stage = 1;
    s.elapsed = 0;
    s.combo = 0;
    s.bestCombo = 0;
    s.perfect = true;
    s.eventTimer = 0;
    s.eventCount = 0;
    s.speedMul = 1;
    s.stageClearT = 0;
    s.shake = 0;
    s.hitStop = 0;
    s.flash = 0;
    s.overLock = 0;
    s.timers.wide = 0;
    s.timers.pierce = 0;
    s.timers.laser = 0;
    s.hitsThisTrip = 0;
    s.noHitT = 0;
    s.shotCd = 0;
    s.isLosingLife = false;

    s.paddle.baseW = clamp(s.W * 0.25, 72, 110);
    s.paddle.w = s.paddle.baseW;
    s.paddle.x = s.W / 2;
    s.paddle.y = s.H - 46;
    s.paddle.pop = 0;
    s.paddle.glow = 0;

    s.parts = [];
    s.pops = [];
    s.banners = [];
    s.drops = [];
    s.bullets = [];

    buildStage(1);
    resetBallOnPaddle();

    s.screenMode = 'play';
    setScreenMode('play');
    setScore(0);
    setStage(1);
    setLives(3);
    setTime(0);
    setCombo(0);
    setActivePowers({ wide: 0, pierce: 0, laser: 0 });

    banner('1단계 시작!', '#ffd34d');
    sound.sfxStart();
  }, [buildStage, resetBallOnPaddle, banner]);

  const nextStage = useCallback(() => {
    const s = stateRef.current;
    s.stage++;
    s.combo = 0;
    s.timers.wide = 0;
    s.timers.pierce = 0;
    s.timers.laser = 0;
    s.hitsThisTrip = 0;
    s.noHitT = 0;
    s.shotCd = 0;
    s.paddle.w = s.paddle.baseW;
    buildStage(s.stage);
    resetBallOnPaddle();

    setStage(s.stage);
    setCombo(0);
    setActivePowers({ wide: 0, pierce: 0, laser: 0 });
    banner(`${s.stage}단계!`, '#8dffcf');
  }, [buildStage, resetBallOnPaddle, banner]);

  const showGameOver = useCallback(() => {
    const s = stateRef.current;
    s.screenMode = 'over';
    s.overLock = 0.5;
    setScreenMode('over');

    setBestScore(prevBest => {
      const current = s.score;
      if (current > prevBest) {
        try {
          localStorage.setItem('bb_best_v1', String(current));
        } catch {
          // ignore
        }
        return current;
      }
      return prevBest;
    });

    sound.sfxOver();
  }, []);

  const loseLife = useCallback(() => {
    const s = stateRef.current;
    if (s.isLosingLife) return;
    s.isLosingLife = true;
    s.lives--;
    s.perfect = false;
    s.combo = 0;
    s.timers.wide = 0;
    s.timers.pierce = 0;
    s.timers.laser = 0;
    s.paddle.w = s.paddle.baseW;
    s.drops = [];
    s.shake = Math.min(s.shake + 18, 22);
    s.flash = 0.7;
    s.hitStop = Math.max(s.hitStop, 0.08);

    sound.sfxLose();
    setLives(s.lives);
    setCombo(0);
    setActivePowers({ wide: 0, pierce: 0, laser: 0 });

    if (s.lives <= 0) {
      showGameOver();
    } else {
      banner(`앗! 남은 목숨: ${s.lives}개`, '#ff9ec4');
      resetBallOnPaddle();
    }
  }, [banner, resetBallOnPaddle, showGameOver]);

  const triggerAction = useCallback(() => {
    sound.init();
    sound.resume();
    const s = stateRef.current;

    if (s.screenMode === 'title') {
      newGame();
      return;
    }
    if (s.screenMode === 'over') {
      if (s.overLock <= 0) newGame();
      return;
    }

    // Launch 100-ball barrage if waiting to launch
    if (s.readyToLaunch) {
      s.readyToLaunch = false;
      s.launchQueue = 100;
      s.launchTimer = 0;
      s.paddle.pop = 1;
      sound.sfxPaddle();
      return;
    }

    // Launch stuck balls (if any)
    let launched = false;
    for (let i = 0; i < s.balls.length; i++) {
      const b = s.balls[i];
      if (b.stuck) {
        b.stuck = false;
        const sp = getTargetSpeed();
        const ang = rnd(-0.55, 0.55);
        b.vx = Math.sin(ang) * sp;
        b.vy = -Math.cos(ang) * sp;
        launched = true;
      }
    }
    if (launched) {
      sound.sfxPaddle();
      s.paddle.pop = 1;
    }
  }, [newGame, getTargetSpeed]);

  const rollPower = useCallback((): Power => {
    const r = Math.random();
    if (r < 0.06) return POWERS[4]; // 목숨 6%
    if (r < 0.32) return POWERS[0]; // 넓은 패들 26%
    if (r < 0.60) return POWERS[1]; // 멀티볼 28%
    if (r < 0.82) return POWERS[2]; // 관통탄 22%
    return POWERS[3]; // 레이저 18%
  }, []);

  const spawnDrop = useCallback((x: number, y: number, force?: Power) => {
    const p = force || rollPower();
    stateRef.current.drops.push({ x, y, vy: 170, p, t: 0 });
  }, [rollPower]);

  const applyPower = useCallback((p: Power) => {
    const s = stateRef.current;
    sound.sfxPower();
    s.shake = Math.min(s.shake + 6, 22);
    s.hitStop = Math.max(s.hitStop, 0.05);
    s.flash = 0.35;

    if (p.id === 'wide') {
      s.timers.wide = 12;
      s.paddle.w = s.paddle.baseW * 1.55;
      s.paddle.pop = 1;
    } else if (p.id === 'pierce') {
      s.timers.pierce = 9;
    } else if (p.id === 'laser') {
      s.timers.laser = 8;
      s.shotCd = 0;
      banner('🔫 레이저 연속 발사!', '#ffd36b');
    } else if (p.id === 'life') {
      s.lives = Math.min(s.lives + 1, 3);
      setLives(s.lives);
    } else if (p.id === 'multi') {
      s.launchQueue += 50;
      banner('🔵 추가 공 +50개 연속 발사!', '#8ecbff');
    }

    popText(s.paddle.x, s.paddle.y - 26, `${p.emoji} ${p.name}`, p.col, 17);
    burst(s.paddle.x, s.paddle.y - 6, 16, p.col, 200);

    setActivePowers({
      wide: Math.ceil(s.timers.wide),
      pierce: Math.ceil(s.timers.pierce),
      laser: Math.ceil(s.timers.laser)
    });
  }, [banner, createBall, getTargetSpeed, popText, burst]);

  const addScore = useCallback((base: number, x: number, y: number, col: string = '#fff', big: boolean = false) => {
    const s = stateRef.current;
    const gained = Math.round(base * (1 + Math.min(s.combo, 20) * 0.13));
    s.score += gained;
    setScore(s.score);
    popText(x, y, `+${gained}`, col, big ? 21 : 15);
  }, [popText]);

  const hitBrick = useCallback((b: Brick, fromBullet: boolean = false) => {
    const s = stateRef.current;
    if (!fromBullet) {
      s.combo++;
      s.hitsThisTrip++;
      if (s.combo > s.bestCombo) s.bestCombo = s.combo;
      setCombo(s.combo);
    }
    s.noHitT = 0;
    b.pop = 1;
    const cx = b.x + b.w / 2;
    const cy = b.y + b.h / 2;

    if (b.gold) {
      b.alive = false;
      b.hp = 0;
      addScore(120, cx, cy, '#ffe066', true);
      burst(cx, cy, 26, '#ffd34d', 320);
      s.shake = Math.min(s.shake + 11, 22);
      s.hitStop = Math.max(s.hitStop, 0.075);
      s.flash = 0.5;
      sound.sfxGold();
      spawnDrop(cx, cy);
      banner(`황금 벽돌! +${Math.round(120 * (1 + Math.min(s.combo, 20) * 0.13))}`, '#ffd34d');
      return;
    }

    b.hp--;
    if (b.hp <= 0) {
      b.alive = false;
      addScore(10 + 8 * (b.max - 1), cx, cy, HP_COLOR[b.max].a, b.max >= 3);
      burst(cx, cy, 12 + b.max * 3, HP_COLOR[b.max].a, 220);
      s.shake = Math.min(s.shake + (3.4 + b.max) * (s.combo >= 3 ? 1.5 : 1), 22);
      s.hitStop = Math.max(s.hitStop, 0.065);
      sound.sfxBreak(s.combo);
      let chance = 0.18 + (b.max - 1) * 0.07;
      if (s.stage === 1 && s.score < 90) chance = 0.5;
      if (Math.random() < chance) spawnDrop(cx, cy);
    } else {
      s.score += 3;
      setScore(s.score);
      burst(cx, cy, 5, HP_COLOR[b.hp].a, 140);
      s.shake = Math.min(s.shake + 2, 22);
      s.hitStop = Math.max(s.hitStop, 0.028);
      sound.sfxBrick(s.combo);
    }

    if (s.combo === 6) banner('🔥 6콤보!', '#ffb04d');
    if (s.combo === 12) banner('🔥🔥 12콤보!', '#ff7aa8');
    if (s.combo === 20) banner('🔥🔥🔥 20콤보 달성!', '#ffd34d');
  }, [addScore, burst, banner, spawnDrop]);

  const stepBall = useCallback((ball: Ball, dt: number): boolean => {
    const s = stateRef.current;
    if (ball.stuck) {
      ball.x = s.paddle.x;
      ball.y = s.paddle.y - ball.r - 6;
      return true;
    }

    const sp = Math.sqrt(ball.vx * ball.vx + ball.vy * ball.vy) || 1;
    const want = getTargetSpeed();
    ball.vx = (ball.vx / sp) * want;
    ball.vy = (ball.vy / sp) * want;

    // Rotate ball texture according to movement
    ball.angle = (ball.angle || 0) + (ball.vx * 0.006);

    const steps = Math.max(1, Math.ceil((want * dt) / (ball.r * 0.8)));
    const sdt = dt / steps;

    for (let st = 0; st < steps; st++) {
      ball.x += ball.vx * sdt;
      ball.y += ball.vy * sdt;

      // Left & Right walls
      if (ball.x - ball.r < 0) {
        ball.x = ball.r;
        ball.vx = Math.abs(ball.vx);
        sound.sfxWall();
        burst(0, ball.y, 3, '#9fd8ff', 120);
        s.shake = Math.min(s.shake + 1.6, 22);
      } else if (ball.x + ball.r > s.W) {
        ball.x = s.W - ball.r;
        ball.vx = -Math.abs(ball.vx);
        sound.sfxWall();
        burst(s.W, ball.y, 3, '#9fd8ff', 120);
        s.shake = Math.min(s.shake + 1.6, 22);
      }

      // Top wall
      if (ball.y - ball.r < 0) {
        ball.y = ball.r;
        ball.vy = Math.abs(ball.vy);
        sound.sfxWall();
        burst(ball.x, 0, 3, '#9fd8ff', 120);
        s.shake = Math.min(s.shake + 1.6, 22);
      }

      // Paddle bounce
      const pl = s.paddle.x - s.paddle.w / 2;
      const pr = s.paddle.x + s.paddle.w / 2;
      if (
        ball.vy > 0 &&
        ball.y + ball.r >= s.paddle.y &&
        ball.y - ball.r <= s.paddle.y + s.paddle.h + 6 &&
        ball.x >= pl - ball.r &&
        ball.x <= pr + ball.r
      ) {
        ball.y = s.paddle.y - ball.r - 0.5;
        const rel = clamp((ball.x - s.paddle.x) / (s.paddle.w / 2), -1, 1);
        const ang = rel * 1.05;
        const spd = getTargetSpeed();
        ball.vx = Math.sin(ang) * spd;
        ball.vy = -Math.cos(ang) * spd;
        s.paddle.pop = 1;
        s.paddle.glow = 1;
        s.shake = Math.min(s.shake + 2.6, 22);
        sound.sfxPaddle();
        if (s.combo >= 4) popText(s.paddle.x, s.paddle.y - 30, `${s.combo} 콤보!`, '#ffd34d', 14);
        s.combo = 0;
        setCombo(0);
        burst(ball.x, s.paddle.y, 6, '#ffd34d', 150);
      }

      // Brick collisions
      const maxBrickY = TOPY + 8 * (s.bh + GAP);
      if (ball.y - ball.r <= maxBrickY) {
        for (let i = 0; i < s.bricks.length; i++) {
          const b = s.bricks[i];
          if (!b.alive) continue;
          const nx = clamp(ball.x, b.x, b.x + b.w);
          const ny = clamp(ball.y, b.y, b.y + b.h);
          const dx = ball.x - nx;
          const dy = ball.y - ny;
          if (dx * dx + dy * dy > ball.r * ball.r) continue;

          if (s.timers.pierce <= 0) {
            const bcx = b.x + b.w / 2;
            const bcy = b.y + b.h / 2;
            const ox = b.w / 2 + ball.r - Math.abs(ball.x - bcx);
            const oy = b.h / 2 + ball.r - Math.abs(ball.y - bcy);
            if (ox < oy) {
              ball.vx = ball.x < bcx ? -Math.abs(ball.vx) : Math.abs(ball.vx);
              ball.x += ball.x < bcx ? -ox : ox;
            } else {
              ball.vy = ball.y < bcy ? -Math.abs(ball.vy) : Math.abs(ball.vy);
              ball.y += ball.y < bcy ? -oy : oy;
            }
          }
          hitBrick(b, false);
          if (s.timers.pierce <= 0) break;
        }
      }

      // Prevent too flat bounce
      const vsp = Math.sqrt(ball.vx * ball.vx + ball.vy * ball.vy) || 1;
      if (Math.abs(ball.vy) < vsp * 0.22) {
        ball.vy = (ball.vy < 0 ? -1 : 1) * vsp * 0.24;
        const need = Math.sqrt(Math.max(0, vsp * vsp - ball.vy * ball.vy));
        ball.vx = (ball.vx < 0 ? -1 : 1) * need;
      }

      // Drop below screen bottom
      if (ball.y - ball.r > s.H) return false;
    }

    ball.trail.push({ x: ball.x, y: ball.y });
    if (ball.trail.length > 7) ball.trail.shift();
    return true;
  }, [getTargetSpeed, burst, popText, hitBrick]);

  const fireEvent = useCallback(() => {
    const s = stateRef.current;
    s.eventCount++;
    sound.sfxEvent();
    s.shake = Math.min(s.shake + 10, 22);
    s.flash = 0.45;
    if (s.eventCount % 2 === 1) {
      s.speedMul = Math.min(s.speedMul * 1.12, 1.85);
      banner('⚡ 공 속도가 증가합니다!', '#8ecbff');
    } else {
      const alive = s.bricks.filter(b => b.alive && !b.gold);
      if (alive.length > 0) {
        const count = Math.min(2, alive.length);
        for (let k = 0; k < count; k++) {
          const idx = Math.floor(Math.random() * alive.length);
          const target = alive.splice(idx, 1)[0];
          if (target) {
            target.gold = true;
            target.hp = 1;
            burst(target.x + target.w / 2, target.y + target.h / 2, 12, '#ffd34d', 160);
          }
        }
        banner('✨ 황금 벽돌 등장!', '#ffd34d');
      }
    }
  }, [banner, burst]);

  // Load Asset Images
  useEffect(() => {
    const bg = new Image();
    bg.src = bgImgUrl;
    bg.onload = () => { bgImgRef.current = bg; };

    const ball = new Image();
    ball.src = ballImgUrl;
    ball.onload = () => { ballImgRef.current = ball; };

    const paddle = new Image();
    paddle.src = paddleImgUrl;
    paddle.onload = () => { paddleImgRef.current = paddle; };
  }, []);

  // Window Resize & Canvas Dimensions Handler
  useEffect(() => {
    const handleResize = () => {
      if (!wrapRef.current || !canvasRef.current) return;
      const rect = wrapRef.current.getBoundingClientRect();
      const aw = Math.max(260, Math.floor(rect.width - 12));
      const ah = Math.max(320, Math.floor(rect.height - 6));
      const s = stateRef.current;
      const oldW = s.W;

      s.W = Math.min(aw, 480);
      s.H = Math.min(ah, Math.round(s.W * 1.65));
      if (s.H < ah * 0.72) s.H = Math.min(ah, Math.round(s.W * 1.85));

      const dpr = Math.min(window.devicePixelRatio || 1, 2.5);
      const cv = canvasRef.current;
      cv.width = Math.round(s.W * dpr);
      cv.height = Math.round(s.H * dpr);
      cv.style.width = `${s.W}px`;
      cv.style.height = `${s.H}px`;

      const k = s.W / (oldW || s.W);
      layoutBricks();
      s.paddle.y = s.H - 46;
      s.paddle.x = clamp(s.paddle.x * k, s.paddle.w / 2, s.W - s.paddle.w / 2);

      for (let i = 0; i < s.balls.length; i++) {
        s.balls[i].x = clamp(s.balls[i].x * k, 8, s.W - 8);
        s.balls[i].y = clamp(s.balls[i].y, 8, s.H - 60);
      }
      for (let j = 0; j < s.drops.length; j++) {
        s.drops[j].x = clamp(s.drops[j].x * k, 12, s.W - 12);
      }

      // Generate background stars
      s.stars = [];
      for (let i = 0; i < 40; i++) {
        s.stars.push({
          x: Math.random() * s.W,
          y: Math.random() * s.H,
          r: Math.random() * 1.4 + 0.6,
          alpha: Math.random() * 0.7 + 0.3,
          speed: Math.random() * 10 + 4
        });
      }
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    window.addEventListener('orientationchange', handleResize);
    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('orientationchange', handleResize);
    };
  }, [layoutBricks]);

  // Keyboard controls
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const k = e.key;
      if ([' ', 'Spacebar', 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Enter'].includes(k)) {
        e.preventDefault();
      }
      if (k === 'ArrowLeft' || k === 'a' || k === 'A') {
        stateRef.current.keys.left = true;
        stateRef.current.pointerX = null;
      }
      if (k === 'ArrowRight' || k === 'd' || k === 'D') {
        stateRef.current.keys.right = true;
        stateRef.current.pointerX = null;
      }
      if (k === ' ' || k === 'Spacebar' || k === 'Enter' || k === 'ArrowUp') {
        triggerAction();
      }
      if (k === 'm' || k === 'M') {
        setSoundEnabled(prev => {
          const next = !prev;
          sound.enabled = next;
          return next;
        });
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      const k = e.key;
      if (k === 'ArrowLeft' || k === 'a' || k === 'A') stateRef.current.keys.left = false;
      if (k === 'ArrowRight' || k === 'd' || k === 'D') stateRef.current.keys.right = false;
    };

    window.addEventListener('keydown', handleKeyDown, { passive: false });
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [triggerAction]);

  // Main Loop
  useEffect(() => {
    let animId: number;
    let lastTime = 0;

    const loop = (timestamp: number) => {
      if (!lastTime) lastTime = timestamp;
      const dt = Math.min((timestamp - lastTime) / 1000, 0.05);
      lastTime = timestamp;

      const s = stateRef.current;
      const cv = canvasRef.current;
      if (!cv) {
        animId = requestAnimationFrame(loop);
        return;
      }
      const ctx = cv.getContext('2d');
      if (!ctx) {
        animId = requestAnimationFrame(loop);
        return;
      }

      // Update Phase
      if (s.overLock > 0) s.overLock -= dt;

      if (s.screenMode === 'play') {
        s.elapsed += dt;
        setTime(Math.floor(s.elapsed));

        s.eventTimer += dt;
        if (s.eventTimer >= 28) {
          s.eventTimer = 0;
          fireEvent();
        }

        // Active Power Timers
        let updatedPowers = false;
        if (s.timers.wide > 0) {
          s.timers.wide -= dt;
          if (s.timers.wide <= 0) {
            s.paddle.w = s.paddle.baseW;
          }
          updatedPowers = true;
        }
        if (s.timers.pierce > 0) {
          s.timers.pierce -= dt;
          updatedPowers = true;
        }
        if (s.timers.laser > 0) {
          s.timers.laser -= dt;
          updatedPowers = true;
        }
        if (updatedPowers) {
          setActivePowers({
            wide: Math.max(0, Math.ceil(s.timers.wide)),
            pierce: Math.max(0, Math.ceil(s.timers.pierce)),
            laser: Math.max(0, Math.ceil(s.timers.laser))
          });
        }

        // Laser shots
        if (s.timers.laser > 0) {
          s.shotCd -= dt;
          if (s.shotCd <= 0) {
            s.shotCd = 0.22;
            s.bullets.push({ x: s.paddle.x - s.paddle.w * 0.38, y: s.paddle.y - 6, vy: -680 });
            s.bullets.push({ x: s.paddle.x + s.paddle.w * 0.38, y: s.paddle.y - 6, vy: -680 });
            sound.sfxLaser();
          }
        }

        // Paddle Movement
        const pSpeed = 540;
        if (s.keys.left) s.paddle.x -= pSpeed * dt;
        if (s.keys.right) s.paddle.x += pSpeed * dt;
        if (s.pointerX !== null) s.paddle.x = s.pointerX;
        s.paddle.x = clamp(s.paddle.x, s.paddle.w / 2, s.W - s.paddle.w / 2);

        if (s.paddle.pop > 0) s.paddle.pop = Math.max(0, s.paddle.pop - dt * 6);
        if (s.paddle.glow > 0) s.paddle.glow = Math.max(0, s.paddle.glow - dt * 4);

        // Bullets
        for (let bi = s.bullets.length - 1; bi >= 0; bi--) {
          const bul = s.bullets[bi];
          bul.y += bul.vy * dt;
          if (bul.y < -10) {
            s.bullets.splice(bi, 1);
            continue;
          }
          let hit = false;
          for (let bj = 0; bj < s.bricks.length; bj++) {
            const br = s.bricks[bj];
            if (!br.alive) continue;
            if (bul.x >= br.x && bul.x <= br.x + br.w && bul.y >= br.y && bul.y <= br.y + br.h) {
              hitBrick(br, true);
              hit = true;
              burst(bul.x, bul.y, 6, '#ffd36b', 140);
              break;
            }
          }
          if (hit) s.bullets.splice(bi, 1);
        }

        // 100-Ball Volley Stream Dispatcher
        if (s.launchQueue > 0) {
          s.launchTimer -= dt;
          if (s.launchTimer <= 0) {
            const batch = Math.min(s.launchQueue, 3);
            const sp = getTargetSpeed();
            for (let bq = 0; bq < batch; bq++) {
              const nb = createBall(false, s.paddle.x, s.paddle.y - 12);
              const dispersion = rnd(-0.16, 0.16);
              const ang = clamp(s.aimAngle + dispersion, -1.15, 1.15);
              nb.vx = Math.sin(ang) * sp;
              nb.vy = -Math.cos(ang) * sp;
              s.balls.push(nb);
            }
            s.launchQueue -= batch;
            s.launchTimer = 0.022;
            if (s.launchQueue % 9 === 0) {
              sound.tone(520 + (100 - s.launchQueue) * 4, 0.03, 'square', 0.05);
            }
          }
        }

        // Balls update & collision
        for (let i = s.balls.length - 1; i >= 0; i--) {
          const alive = stepBall(s.balls[i], dt);
          if (!alive) s.balls.splice(i, 1);
        }

        // Update real-time ball count for HUD
        const currentBallCount = s.readyToLaunch ? s.stuckBallCount : (s.balls.length + s.launchQueue);
        setBallCount(currentBallCount);

        // Life lost only when all 100 balls have been fired and lost
        if (s.balls.length === 0 && s.launchQueue === 0 && !s.readyToLaunch) {
          loseLife();
        }

        // Drops
        for (let d = s.drops.length - 1; d >= 0; d--) {
          const drop = s.drops[d];
          drop.y += drop.vy * dt;
          drop.t += dt;
          const pl = s.paddle.x - s.paddle.w / 2;
          const pr = s.paddle.x + s.paddle.w / 2;
          if (
            drop.y >= s.paddle.y - 14 &&
            drop.y <= s.paddle.y + s.paddle.h + 8 &&
            drop.x >= pl - 14 &&
            drop.x <= pr + 14
          ) {
            applyPower(drop.p);
            s.drops.splice(d, 1);
          } else if (drop.y > s.H + 20) {
            s.drops.splice(d, 1);
          }
        }

        // Stuck ball trajectory rescue
        s.noHitT += dt;
        if (s.noHitT > 10 && s.bricks.some(b => b.alive)) {
          for (let sb = 0; sb < s.balls.length; sb++) {
            if (!s.balls[sb].stuck) {
              s.balls[sb].vy += s.balls[sb].vy < 0 ? -120 : 120;
              s.balls[sb].vx += rnd(-90, 90);
            }
          }
          popText(s.W / 2, s.H * 0.4, '🌀 궤도 자동 수정!', '#8dffcf', 15);
          s.noHitT = 0;
        }

        // Stage Clear
        const aliveBricks = s.bricks.filter(b => b.alive).length;
        if (aliveBricks === 0) {
          if (s.stageClearT === 0) {
            s.stageClearT = 1.2;
            sound.sfxClear();
            banner('🎉 단계 클리어!', '#8dffcf');
            if (s.perfect) addScore(400, s.W / 2, s.H / 2, '#ffd34d', true);
          } else {
            s.stageClearT -= dt;
            if (s.stageClearT <= 0) {
              s.stageClearT = 0;
              nextStage();
            }
          }
        }

        // Particles & Pops & Banners
        for (let p = s.parts.length - 1; p >= 0; p--) {
          const pt = s.parts[p];
          pt.x += pt.vx * dt;
          pt.y += pt.vy * dt;
          pt.vy += 220 * dt;
          pt.life -= dt;
          if (pt.life <= 0) s.parts.splice(p, 1);
        }
        for (let po = s.pops.length - 1; po >= 0; po--) {
          const pop = s.pops[po];
          pop.y += pop.vy * dt;
          pop.life -= dt;
          if (pop.life <= 0) s.pops.splice(po, 1);
        }
        for (let bn = s.banners.length - 1; bn >= 0; bn--) {
          const bnr = s.banners[bn];
          bnr.life -= dt;
          if (bnr.life <= 0) s.banners.splice(bn, 1);
        }
      }

      // Render Phase
      const dpr = Math.min(window.devicePixelRatio || 1, 2.5);
      ctx.save();
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, s.W, s.H);

      // Screen Shake
      if (s.shake > 0) {
        const sx = rnd(-s.shake, s.shake);
        const sy = rnd(-s.shake, s.shake);
        ctx.translate(sx, sy);
        s.shake = Math.max(0, s.shake - 45 * 0.016);
      }

      // 1. Draw Background: Cosmic Nebula Asset Image with Canvas Fallback
      if (bgImgRef.current && bgImgRef.current.complete) {
        ctx.drawImage(bgImgRef.current, 0, 0, s.W, s.H);
        // Subtle dark gradient vignette overlay for optimal brick contrast
        ctx.fillStyle = 'rgba(8, 5, 26, 0.42)';
        ctx.fillRect(0, 0, s.W, s.H);
      } else {
        const bgGrad = ctx.createLinearGradient(0, 0, 0, s.H);
        bgGrad.addColorStop(0, '#160f3b');
        bgGrad.addColorStop(0.6, '#0b0824');
        bgGrad.addColorStop(1, '#0a0620');
        ctx.fillStyle = bgGrad;
        ctx.fillRect(0, 0, s.W, s.H);
      }

      // Background floating stars for celestial depth
      for (let si = 0; si < s.stars.length; si++) {
        const st = s.stars[si];
        st.y += st.speed * 0.016;
        if (st.y > s.H) st.y = 0;
        ctx.fillStyle = `rgba(255, 255, 255, ${st.alpha})`;
        ctx.beginPath();
        ctx.arc(st.x, st.y, st.r, 0, Math.PI * 2);
        ctx.fill();
      }

      // 2. Draw Bricks
      for (let i = 0; i < s.bricks.length; i++) {
        const b = s.bricks[i];
        if (!b.alive) continue;

        if (b.pop > 0) b.pop = Math.max(0, b.pop - 0.016 * 8);
        const scale = 1 + b.pop * 0.12;
        const bx = b.x - ((b.w * scale - b.w) / 2);
        const by = b.y - ((b.h * scale - b.h) / 2);
        const bw_ = b.w * scale;
        const bh_ = b.h * scale;

        const grad = ctx.createLinearGradient(bx, by, bx, by + bh_);
        if (b.gold) {
          grad.addColorStop(0, GOLD.a);
          grad.addColorStop(1, GOLD.b);
        } else {
          const cols = HP_COLOR[b.hp] || HP_COLOR[1];
          grad.addColorStop(0, cols.a);
          grad.addColorStop(1, cols.b);
        }

        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.roundRect(bx, by, bw_, bh_, 5);
        ctx.fill();

        // Top glossy highlight
        ctx.fillStyle = 'rgba(255, 255, 255, 0.35)';
        ctx.fillRect(bx + 2, by + 1, bw_ - 4, 2);

        // HP Number for multi-hit bricks
        if (b.max > 1 && !b.gold) {
          ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
          ctx.font = '900 11px -apple-system, sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(String(b.hp), bx + bw_ / 2, by + bh_ / 2 + 1);
        }
      }

      // 3. Draw Paddle: High-Tech Sci-Fi Asset Image with Canvas Fallback
      const pw = s.paddle.w * (1 + s.paddle.pop * 0.1);
      const px = s.paddle.x - pw / 2;
      const py = s.paddle.y;
      const ph = s.paddle.h;

      if (paddleImgRef.current && paddleImgRef.current.complete) {
        // Paddle image with subtle glow
        ctx.save();
        ctx.shadowColor = s.paddle.glow > 0 ? '#ffe27a' : '#5fd8ff';
        ctx.shadowBlur = s.paddle.glow > 0 ? 16 : 8;
        ctx.drawImage(paddleImgRef.current, px, py - 2, pw, ph + 4);
        ctx.restore();
      } else {
        const pGrad = ctx.createLinearGradient(px, py, px, py + ph);
        pGrad.addColorStop(0, '#ffffff');
        pGrad.addColorStop(0.5, '#ffd34d');
        pGrad.addColorStop(1, '#ff9500');
        ctx.fillStyle = pGrad;
        ctx.beginPath();
        ctx.roundRect(px, py, pw, ph, 7);
        ctx.fill();
      }

      // Laser cannons on paddle if power active
      if (s.timers.laser > 0) {
        ctx.fillStyle = '#ffd36b';
        ctx.fillRect(px + 4, py - 6, 6, 6);
        ctx.fillRect(px + pw - 10, py - 6, 6, 6);
      }

      // 4. Laser Bullets
      ctx.fillStyle = '#ffe27a';
      for (let bi = 0; bi < s.bullets.length; bi++) {
        const bul = s.bullets[bi];
        ctx.fillRect(bul.x - 2, bul.y, 4, 12);
      }

      // 5. Item Drops
      for (let d = 0; d < s.drops.length; d++) {
        const drop = s.drops[d];
        const dy = drop.y + Math.sin(drop.t * 8) * 3;
        ctx.fillStyle = drop.p.col;
        ctx.beginPath();
        ctx.arc(drop.x, dy, 13, 0, Math.PI * 2);
        ctx.fill();
        ctx.font = '14px sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(drop.p.emoji, drop.x, dy);
      }

      // 6. Draw Balls: Master Ball Asset Sprite with Energy Aura
      for (let bIdx = 0; bIdx < s.balls.length; bIdx++) {
        const ball = s.balls[bIdx];

        // Ball Motion Trail
        const trailLen = s.balls.length > 20 ? 2 : ball.trail.length;
        for (let t = 0; t < trailLen; t++) {
          const tr = ball.trail[t];
          const trAlpha = ((t + 1) / (trailLen || 1)) * 0.45;
          const trailCol = s.timers.pierce > 0 ? 'rgba(255, 80, 80, ' : 'rgba(180, 90, 255, ';
          ctx.fillStyle = trailCol + trAlpha + ')';
          ctx.beginPath();
          ctx.arc(tr.x, tr.y, ball.r * (0.4 + 0.6 * (t / (trailLen || 1))), 0, Math.PI * 2);
          ctx.fill();
        }

        // Master Ball Body
        ctx.save();
        if (s.balls.length < 20) {
          ctx.shadowColor = s.timers.pierce > 0 ? '#ff0055' : '#c850ff';
          ctx.shadowBlur = 10;
        }

        if (ballImgRef.current && ballImgRef.current.complete) {
          // Circular clip for clean spherical rendering
          ctx.beginPath();
          ctx.arc(ball.x, ball.y, ball.r, 0, Math.PI * 2);
          ctx.clip();

          ctx.translate(ball.x, ball.y);
          ctx.rotate(ball.angle || 0);
          ctx.drawImage(
            ballImgRef.current,
            -ball.r,
            -ball.r,
            ball.r * 2,
            ball.r * 2
          );
        } else {
          // Fallback procedural sphere
          const ballGrad = ctx.createRadialGradient(
            ball.x - ball.r * 0.3,
            ball.y - ball.r * 0.3,
            ball.r * 0.1,
            ball.x,
            ball.y,
            ball.r
          );
          ballGrad.addColorStop(0, '#d16eff');
          ballGrad.addColorStop(0.7, '#8018c4');
          ballGrad.addColorStop(1, '#410967');
          ctx.fillStyle = ballGrad;
          ctx.beginPath();
          ctx.arc(ball.x, ball.y, ball.r, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();

        // Outer Energy Ring (Red for Pierce, Violet for Normal)
        ctx.strokeStyle = s.timers.pierce > 0 ? '#ff3366' : 'rgba(200, 120, 255, 0.75)';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.arc(ball.x, ball.y, ball.r, 0, Math.PI * 2);
        ctx.stroke();
      }

      // Ready to Launch 100-Ball Cannon Preview & Aiming Line
      if (s.readyToLaunch && s.screenMode === 'play') {
        const startX = s.paddle.x;
        const startY = s.paddle.y - 14;
        const lineLen = 170;
        const step = 14;
        const dirX = Math.sin(s.aimAngle);
        const dirY = -Math.cos(s.aimAngle);

        // Aiming dashed beam
        for (let d = 16; d < lineLen; d += step) {
          const px = startX + dirX * d;
          const py = startY + dirY * d;
          const alpha = (1 - d / lineLen) * 0.85;
          ctx.fillStyle = `rgba(192, 132, 252, ${alpha})`;
          ctx.beginPath();
          ctx.arc(px, py, 2.5, 0, Math.PI * 2);
          ctx.fill();
        }

        // Ready 100-Ball Badge above paddle
        ctx.save();
        ctx.fillStyle = 'rgba(15, 10, 35, 0.85)';
        ctx.strokeStyle = '#c084fc';
        ctx.lineWidth = 1.5;
        const badgeW = 86;
        const badgeH = 22;
        const badgeX = startX - badgeW / 2;
        const badgeY = startY - 38;
        ctx.beginPath();
        ctx.roundRect(badgeX, badgeY, badgeW, badgeH, 11);
        ctx.fill();
        ctx.stroke();

        ctx.fillStyle = '#fde047';
        ctx.font = '900 11px -apple-system, sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('⚡ 100 BALLS', startX, badgeY + badgeH / 2);
        ctx.restore();

        // Draw preview master ball on paddle
        const pr = clamp(s.W * 0.024, 7, 10);
        ctx.save();
        ctx.shadowColor = '#c084fc';
        ctx.shadowBlur = 12;
        if (ballImgRef.current && ballImgRef.current.complete) {
          ctx.beginPath();
          ctx.arc(startX, startY, pr, 0, Math.PI * 2);
          ctx.clip();
          ctx.drawImage(ballImgRef.current, startX - pr, startY - pr, pr * 2, pr * 2);
        } else {
          ctx.fillStyle = '#d16eff';
          ctx.beginPath();
          ctx.arc(startX, startY, pr, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();

        // Pulsing outer ring
        ctx.strokeStyle = 'rgba(253, 224, 71, 0.85)';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(startX, startY, pr + 2 + Math.sin(Date.now() * 0.008) * 1.5, 0, Math.PI * 2);
        ctx.stroke();
      }

      // 7. Particles
      for (let p = 0; p < s.parts.length; p++) {
        const pt = s.parts[p];
        const pAlpha = pt.life / pt.max;
        ctx.fillStyle = pt.col;
        ctx.globalAlpha = clamp(pAlpha, 0, 1);
        ctx.beginPath();
        ctx.arc(pt.x, pt.y, pt.sz, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1.0;

      // 8. Pop Text
      for (let po = 0; po < s.pops.length; po++) {
        const pop = s.pops[po];
        ctx.fillStyle = pop.col;
        ctx.font = `900 ${pop.sz}px -apple-system, sans-serif`;
        ctx.textAlign = 'center';
        ctx.globalAlpha = clamp(pop.life / pop.max, 0, 1);
        ctx.fillText(pop.txt, pop.x, pop.y);
      }
      ctx.globalAlpha = 1.0;

      // 9. Banner Notifications
      if (s.banners.length > 0) {
        const bnr = s.banners[s.banners.length - 1];
        ctx.fillStyle = bnr.col;
        ctx.font = '900 20px -apple-system, sans-serif';
        ctx.textAlign = 'center';
        ctx.shadowColor = 'rgba(0,0,0,0.85)';
        ctx.shadowBlur = 8;
        ctx.fillText(bnr.txt, s.W / 2, s.H * 0.42);
        ctx.shadowBlur = 0;
      }

      // 10. Screen Flash Effect
      if (s.flash > 0) {
        ctx.fillStyle = `rgba(255, 255, 255, ${s.flash})`;
        ctx.fillRect(0, 0, s.W, s.H);
        s.flash = Math.max(0, s.flash - 0.016 * 4);
      }

      ctx.restore();

      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [fireEvent, hitBrick, stepBall, loseLife, applyPower, addScore, nextStage]);

  // Pointer Event Handlers
  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const cv = canvasRef.current;
    if (!cv) return;
    const r = cv.getBoundingClientRect();
    stateRef.current.pointerActive = true;
    stateRef.current.pointerX = clamp(e.clientX - r.left, 0, stateRef.current.W);
    try {
      cv.setPointerCapture(e.pointerId);
    } catch {
      // ignore
    }
    triggerAction();
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (stateRef.current.pointerActive || e.pointerType === 'mouse') {
      const cv = canvasRef.current;
      if (!cv) return;
      const r = cv.getBoundingClientRect();
      const s = stateRef.current;
      const px = clamp(e.clientX - r.left, 0, s.W);
      s.pointerX = px;
      if (s.readyToLaunch) {
        const dx = px - s.paddle.x;
        s.aimAngle = clamp(dx * 0.012, -0.95, 0.95);
      }
    }
  };

  const handlePointerUp = () => {
    stateRef.current.pointerActive = false;
  };

  return (
    <div
      id="brick-breaker-app"
      className="relative w-full h-screen max-w-[540px] mx-auto flex flex-col select-none overflow-hidden touch-none"
      style={{
        background: 'radial-gradient(120% 90% at 50% 0%, #23134f 0%, #0e0a2a 55%, #05030f 100%)',
        color: '#fff'
      }}
    >
      {/* Top HUD */}
      <header id="game-hud" className="shrink-0 px-3 pt-2.5 pb-1 flex flex-col gap-1.5 z-10">
        <div className="flex items-center gap-2">
          {/* Score Chip */}
          <div
            id="score-chip"
            className="flex items-center gap-1.5 px-3 py-1 bg-white/10 border border-white/15 rounded-full text-xs font-bold shadow-md whitespace-nowrap"
          >
            <Trophy className="w-3.5 h-3.5 text-amber-400" />
            <b className="text-sm text-amber-300 tabular-nums">{score}</b>
          </div>

          {/* Stage Chip */}
          <div
            id="stage-chip"
            className="flex items-center gap-1 px-3 py-1 bg-white/10 border border-white/15 rounded-full text-xs font-bold shadow-md whitespace-nowrap"
          >
            <span>🧱</span>
            <b className="text-sm text-sky-300 tabular-nums">{stage}</b>
            <span className="text-[11px] text-white/70">단계</span>
          </div>

          {/* 100 Balls Count Chip */}
          <div
            id="balls-count-chip"
            className="flex items-center gap-1.5 px-2.5 py-1 bg-purple-500/25 border border-purple-400/40 rounded-full text-xs font-bold shadow-md whitespace-nowrap"
          >
            <span className="text-purple-300">⚽</span>
            <b className="text-sm text-purple-200 tabular-nums">{ballCount}</b>
            <span className="text-[11px] text-purple-300/80">개</span>
          </div>

          {/* Time Chip */}
          <div
            id="time-chip"
            className="hidden sm:flex items-center gap-1 px-2.5 py-1 bg-white/10 border border-white/15 rounded-full text-xs font-bold shadow-md whitespace-nowrap"
          >
            <span>⏱</span>
            <b className="text-sm tabular-nums">{time}</b>s
          </div>

          <div className="flex-1" />

          {/* Hearts Life Display */}
          <div
            id="hearts-chip"
            className="flex items-center gap-1 px-2.5 py-1 bg-white/10 border border-white/15 rounded-full shadow-md"
          >
            {[0, 1, 2].map(idx => (
              <Heart
                key={idx}
                className={`w-4 h-4 transition-all duration-300 ${
                  idx < lives ? 'text-rose-500 fill-rose-500 scale-100' : 'text-white/20 scale-75'
                }`}
              />
            ))}
          </div>

          {/* Sound Toggle Button */}
          <button
            id="sound-toggle-btn"
            onClick={() => {
              sound.init();
              sound.resume();
              setSoundEnabled(prev => {
                const next = !prev;
                sound.enabled = next;
                return next;
              });
            }}
            aria-label="소리 켜기/끄기"
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 active:scale-95 border border-white/20 flex items-center justify-center transition-transform"
          >
            {soundEnabled ? (
              <Volume2 className="w-4 h-4 text-emerald-400" />
            ) : (
              <VolumeX className="w-4 h-4 text-rose-400" />
            )}
          </button>
        </div>

        {/* Combo & Active Powerups Row */}
        <div className="flex items-center gap-2 min-h-[26px]">
          {combo >= 2 && (
            <div
              id="combo-chip"
              className="flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-black shadow-lg bg-gradient-to-r from-amber-500 to-yellow-400 text-amber-950 animate-bounce"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>{combo} 콤보!</span>
            </div>
          )}

          <div id="powerups-active-bar" className="flex items-center gap-1.5 flex-wrap text-[11px] font-bold">
            {activePowers.wide > 0 && (
              <span className="px-2 py-0.5 rounded-full bg-emerald-400 text-emerald-950 shadow-sm animate-pulse">
                🟩 넓은 패들 {activePowers.wide}s
              </span>
            )}
            {activePowers.pierce > 0 && (
              <span className="px-2 py-0.5 rounded-full bg-rose-400 text-rose-950 shadow-sm animate-pulse">
                🔴 관통탄 {activePowers.pierce}s
              </span>
            )}
            {activePowers.laser > 0 && (
              <span className="px-2 py-0.5 rounded-full bg-amber-400 text-amber-950 shadow-sm animate-pulse">
                🔫 레이저 {activePowers.laser}s
              </span>
            )}
          </div>
        </div>
      </header>

      {/* Main Game Stage */}
      <main id="game-stage-wrap" ref={wrapRef} className="flex-1 relative min-h-0 flex items-center justify-center p-2">
        <canvas
          id="game-canvas"
          ref={canvasRef}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerCancel={handlePointerUp}
          className="block rounded-2xl shadow-2xl cursor-pointer border border-white/15"
        />

        {/* Title Screen Modal */}
        {screenMode === 'title' && (
          <div
            id="title-overlay"
            className="absolute inset-0 z-20 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
          >
            <div
              id="title-card"
              className="w-full max-w-sm p-6 rounded-3xl text-center bg-gradient-to-b from-[#261856]/95 to-[#0e0928]/98 border-2 border-white/20 shadow-2xl animate-in fade-in zoom-in duration-200"
            >
              <div className="flex items-center justify-center gap-2 mb-1">
                <img
                  src={ballImgUrl}
                  alt="마스터볼"
                  className="w-10 h-10 rounded-full object-cover shadow-lg border border-purple-400"
                />
                <h1 className="text-3xl font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-b from-white to-amber-300">
                  벽돌깨기
                </h1>
              </div>
              <p className="text-xs font-bold tracking-widest text-indigo-300 uppercase mb-4">
                COSMIC BRICK BREAKER
              </p>

              {/* Decorative Bricks */}
              <div className="flex justify-center gap-1.5 my-3">
                <span className="w-8 h-3 rounded bg-sky-400 shadow-sm animate-pulse" />
                <span className="w-8 h-3 rounded bg-amber-400 shadow-sm animate-pulse delay-75" />
                <span className="w-8 h-3 rounded bg-rose-400 shadow-sm animate-pulse delay-150" />
                <span className="w-8 h-3 rounded bg-yellow-300 shadow-sm animate-pulse delay-200" />
              </div>

              {/* Game Rules Box */}
              <div className="p-3 my-3 text-xs leading-relaxed text-indigo-100 bg-black/40 rounded-xl border border-white/10 text-left font-medium">
                <p><span className="text-amber-400 font-bold">① 조준 및 이동:</span> 마우스/터치 드래그로 각도 조준 및 패들 이동</p>
                <p><span className="text-amber-400 font-bold">② 100개 발사:</span> [클릭/스페이스] 시 마스터볼 100개 연속 집중 포화!</p>
                <p><span className="text-amber-400 font-bold">③ 파워업:</span> 멀티볼 아이템으로 +50개 추가 발사 & 레이저!</p>
                <p><span className="text-amber-400 font-bold">④ 생명:</span> 100개의 공이 모두 바닥에 떨어지기 전 패들로 받아치세요 ❤️</p>
              </div>

              {/* Play Button */}
              <button
                id="start-game-btn"
                onClick={triggerAction}
                className="w-full py-3.5 px-4 rounded-xl font-black text-lg text-amber-950 bg-gradient-to-b from-amber-300 to-amber-500 hover:from-amber-200 hover:to-amber-400 active:translate-y-1 shadow-lg shadow-amber-500/30 flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <Play className="w-5 h-5 fill-current" />
                게임 시작!
              </button>

              {bestScore > 0 && (
                <p className="mt-3 text-xs font-semibold text-indigo-300">
                  🏆 최고 기록: <span className="text-amber-300 font-black">{bestScore}점</span>
                </p>
              )}
            </div>
          </div>
        )}

        {/* Game Over Screen Modal */}
        {screenMode === 'over' && (
          <div
            id="gameover-overlay"
            className="absolute inset-0 z-20 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm"
          >
            <div
              id="gameover-card"
              className="w-full max-w-sm p-6 rounded-3xl text-center bg-gradient-to-b from-[#2a133d]/95 to-[#12071f]/98 border-2 border-white/20 shadow-2xl animate-in fade-in zoom-in duration-200"
            >
              <div className="text-xs font-bold text-indigo-300 uppercase tracking-widest mb-1">
                GAME OVER
              </div>
              <div className="text-5xl font-black text-amber-300 tabular-nums mb-3">
                {score}
              </div>

              <div
                className={`py-2 px-3 rounded-xl text-xs font-bold mb-4 ${
                  score >= bestScore
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                    : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                }`}
              >
                {score >= bestScore
                  ? '🎉 축하합니다! 새로운 최고 기록 달성!'
                  : `💪 최고 기록까지 ${bestScore - score}점 남았습니다!`}
              </div>

              {/* Stats Grid */}
              <div className="grid grid-cols-3 gap-2 mb-4">
                <div className="p-2 bg-white/5 rounded-xl border border-white/10">
                  <div className="text-[11px] text-indigo-300 font-semibold">도달 단계</div>
                  <div className="text-base font-black text-white">{stage}</div>
                </div>
                <div className="p-2 bg-white/5 rounded-xl border border-white/10">
                  <div className="text-[11px] text-indigo-300 font-semibold">최고 콤보</div>
                  <div className="text-base font-black text-white">{stateRef.current.bestCombo}</div>
                </div>
                <div className="p-2 bg-white/5 rounded-xl border border-white/10">
                  <div className="text-[11px] text-indigo-300 font-semibold">생존 시간</div>
                  <div className="text-base font-black text-white">{time}초</div>
                </div>
              </div>

              {/* Restart Button */}
              <button
                id="restart-game-btn"
                onClick={triggerAction}
                className="w-full py-3.5 px-4 rounded-xl font-black text-lg text-amber-950 bg-gradient-to-b from-amber-300 to-amber-500 hover:from-amber-200 hover:to-amber-400 active:translate-y-1 shadow-lg shadow-amber-500/30 flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <RotateCcw className="w-5 h-5" />
                다시 도전하기!
              </button>
            </div>
          </div>
        )}
      </main>

      {/* Bottom Hint Footer */}
      <footer id="game-footer-hint" className="shrink-0 px-3 py-1.5 text-center text-[11px] text-indigo-300/80 font-medium">
        키보드 [←][→] 또는 마우스/터치 드래그 &nbsp;|&nbsp; [스페이스/클릭] 발사
      </footer>
    </div>
  );
}
