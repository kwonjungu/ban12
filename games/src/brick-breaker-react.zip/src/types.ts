export interface Brick {
  col: number;
  row: number;
  x: number;
  y: number;
  w: number;
  h: number;
  hp: number;
  max: number;
  gold: boolean;
  pop: number;
  alive: boolean;
  shine: number;
}

export interface Ball {
  x: number;
  y: number;
  r: number;
  vx: number;
  vy: number;
  stuck: boolean;
  angle?: number;
  trail: { x: number; y: number }[];
}

export interface Power {
  id: 'wide' | 'multi' | 'pierce' | 'laser' | 'life';
  emoji: string;
  col: string;
  name: string;
}

export interface Drop {
  x: number;
  y: number;
  vy: number;
  p: Power;
  t: number;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  col: string;
  sz: number;
}

export interface PopText {
  x: number;
  y: number;
  txt: string;
  col: string;
  life: number;
  max: number;
  sz: number;
  vy: number;
}

export interface Banner {
  txt: string;
  col: string;
  life: number;
  max: number;
}

export interface Bullet {
  x: number;
  y: number;
  vy: number;
}

export interface Star {
  x: number;
  y: number;
  r: number;
  alpha: number;
  speed: number;
}
