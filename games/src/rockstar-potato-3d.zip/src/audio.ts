/**
 * Synthesizer & Sound Effects for Rockstar Potato 3D
 */

const PENTATONIC_NOTES = [
  164.81, 196.0, 220.0, 246.94, 293.66, 329.63, 392.0, 440.0, 523.25, 587.33,
  659.25, 783.99,
];

class SoundEngine {
  private ac: AudioContext | null = null;
  private master: GainNode | null = null;
  public muted: boolean = false;

  constructor() {
    try {
      const saved = localStorage.getItem('rockstar-potato-mute');
      this.muted = saved === '1';
    } catch {
      this.muted = false;
    }
  }

  public init() {
    if (!this.ac) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext })
          .webkitAudioContext;
      if (AudioCtx) {
        this.ac = new AudioCtx();
        this.master = this.ac.createGain();
        this.master.gain.value = 0.4;
        this.master.connect(this.ac.destination);
      }
    }
    if (this.ac && this.ac.state === 'suspended') {
      this.ac.resume().catch(() => {});
    }
  }

  public toggleMute(): boolean {
    this.muted = !this.muted;
    try {
      localStorage.setItem('rockstar-potato-mute', this.muted ? '1' : '0');
    } catch {}
    if (!this.muted) {
      this.init();
      this.playSynthSound(440, 0.2, 'triangle', 0.2);
    }
    return this.muted;
  }

  private playSynthSound(
    freq: number,
    dur = 0.4,
    type: OscillatorType = 'sawtooth',
    vol = 0.3,
    delay = 0
  ) {
    if (this.muted || !this.ac || !this.master) return;
    try {
      const t0 = this.ac.currentTime + delay;
      const osc = this.ac.createOscillator();
      const filter = this.ac.createBiquadFilter();
      const g = this.ac.createGain();

      osc.type = type;
      osc.frequency.setValueAtTime(freq, t0);

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(freq * 4.5, t0);
      filter.frequency.exponentialRampToValueAtTime(freq * 1.2, t0 + dur);

      g.gain.setValueAtTime(0.0001, t0);
      g.gain.exponentialRampToValueAtTime(vol, t0 + 0.015);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);

      osc.connect(filter);
      filter.connect(g);
      g.connect(this.master);

      osc.start(t0);
      osc.stop(t0 + dur + 0.05);
    } catch {}
  }

  public playRockChord(idx: number) {
    const baseIdx = idx % (PENTATONIC_NOTES.length - 3);
    this.playSynthSound(PENTATONIC_NOTES[baseIdx], 0.5, 'sawtooth', 0.25, 0);
    this.playSynthSound(
      PENTATONIC_NOTES[baseIdx + 2],
      0.45,
      'triangle',
      0.22,
      0.03
    );
    this.playSynthSound(
      PENTATONIC_NOTES[baseIdx + 3],
      0.4,
      'sawtooth',
      0.2,
      0.06
    );
  }

  public sndJump() {
    this.playSynthSound(280, 0.16, 'square', 0.2, 0);
    this.playSynthSound(420, 0.2, 'sawtooth', 0.18, 0.02);
  }

  public sndPotatoPop() {
    this.playSynthSound(160, 0.15, 'sawtooth', 0.28, 0);
    this.playSynthSound(360, 0.2, 'triangle', 0.25, 0.04);
    this.playSynthSound(620, 0.3, 'sine', 0.22, 0.08);
  }

  public sndShieldActivate() {
    this.playSynthSound(440, 0.35, 'sine', 0.28, 0);
    this.playSynthSound(880, 0.45, 'triangle', 0.32, 0.08);
    this.playSynthSound(1320, 0.55, 'sine', 0.24, 0.16);
  }

  public sndShieldBreak() {
    this.playSynthSound(120, 0.4, 'sawtooth', 0.35, 0);
    this.playSynthSound(90, 0.4, 'square', 0.3, 0.05);
  }

  public sndHit() {
    this.playSynthSound(85, 0.55, 'sawtooth', 0.4, 0);
    this.playSynthSound(60, 0.55, 'square', 0.35, 0.04);
  }

  public sndStart() {
    this.playSynthSound(220, 0.3, 'sawtooth', 0.2, 0.0);
    this.playSynthSound(329, 0.3, 'sawtooth', 0.2, 0.08);
    this.playSynthSound(440, 0.4, 'triangle', 0.25, 0.16);
  }
}

export const sounds = new SoundEngine();
