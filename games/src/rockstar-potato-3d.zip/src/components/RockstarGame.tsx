import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { Volume2, VolumeX, Shield, Trophy, Flame, Play, RotateCcw } from 'lucide-react';
import { sounds } from '../audio';
import { IMAGES } from '../assets';
import { GameState, GameStats } from '../types';

const STORE_BEST = 'rockstar-potato-3d-best';
const GROUND_Y = -10.5;
const PIPE_SPAWN_X = 18;
const PIPE_GAP = 7.6;

export default function RockstarGame() {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const [gameState, setGameState] = useState<GameState>('title');
  const [isMuted, setIsMuted] = useState(sounds.muted);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const [stats, setStats] = useState<GameStats>(() => {
    let savedBest = 0;
    try {
      const v = localStorage.getItem(STORE_BEST);
      if (v) savedBest = parseInt(v, 10) || 0;
    } catch {}
    return {
      score: 0,
      best: savedBest,
      runTime: 0,
      starCount: 0,
      shields: 0,
      activeShieldTimer: 0,
      combo: 0,
      bestCombo: 0,
      passed: 0,
      newRecord: false,
    };
  });

  // Game loop internal refs
  const gameRef = useRef({
    state: 'title' as GameState,
    potatoBox: { x: -4, y: 0, vy: 0, rot: 0, alive: true },
    score: 0,
    best: 0,
    combo: 0,
    bestCombo: 0,
    starCount: 0,
    shields: 0,
    passed: 0,
    activeShieldTimer: 0,
    runTime: 0,
    nowSec: 0,
    cameraShake: 0,
    spawnedTotal: 0,
    speedBonus: 0,
    newRecord: false,
    overWait: 0,
    lastStartAt: 0,
    pipes3D: [] as Array<{
      group: THREE.Group;
      x: number;
      gapY: number;
      scored: boolean;
    }>,
    poppingPotatoes3D: [] as Array<{
      mesh: THREE.Group;
      x: number;
      y: number;
      targetY: number;
      popped: boolean;
      got: boolean;
      phase: number;
    }>,
    dirtParticles3D: [] as Array<{
      mesh: THREE.Mesh;
      vx: number;
      vy: number;
      life: number;
    }>,
    musicNotes3D: [] as Array<{
      sprite: THREE.Sprite;
      vx: number;
      vy: number;
      life: number;
    }>,
  });

  const toastTimerRef = useRef<number | null>(null);
  const showToast = useCallback((msg: string) => {
    setToastMsg(msg);
    if (toastTimerRef.current) clearTimeout(toastTimerRef.current);
    toastTimerRef.current = window.setTimeout(() => {
      setToastMsg(null);
    }, 2200);
  }, []);

  // Three.js instances ref
  const threeRef = useRef<{
    scene: THREE.Scene;
    camera: THREE.PerspectiveCamera;
    renderer: THREE.WebGLRenderer;
    potatoGroup: THREE.Group;
    shieldSphereMesh: THREE.Mesh;
    groundGroup: THREE.Group;
    stageSpotLight: THREE.PointLight;
    stageSpotLight2: THREE.PointLight;
    backdropMesh?: THREE.Mesh;
    reqId?: number;
  } | null>(null);

  // Sync state ref
  useEffect(() => {
    gameRef.current.state = gameState;
  }, [gameState]);

  useEffect(() => {
    gameRef.current.best = stats.best;
  }, [stats.best]);

  // Three.js Scene Setup
  useEffect(() => {
    const container = containerRef.current;
    const canvas = canvasRef.current;
    if (!container || !canvas) return;

    const width = container.clientWidth || 480;
    const height = container.clientHeight || 720;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0c0916);
    scene.fog = new THREE.FogExp2(0x0c0916, 0.015);

    const camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 1000);
    camera.position.set(0, 0, 24);

    const renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      powerPreference: 'high-performance',
      alpha: true,
    });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.setSize(width, height);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    // Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.9);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xfff5dd, 1.4);
    dirLight.position.set(12, 22, 16);
    dirLight.castShadow = true;
    scene.add(dirLight);

    const stageSpotLight = new THREE.PointLight(0xff007f, 3.0, 50);
    stageSpotLight.position.set(-6, 10, 10);
    scene.add(stageSpotLight);

    const stageSpotLight2 = new THREE.PointLight(0x00d2ff, 3.0, 50);
    stageSpotLight2.position.set(10, -5, 10);
    scene.add(stageSpotLight2);

    // [Asset 1 Integration] 록 콘서트 무대 배경 텍스처 평면 (Backdrop)
    const textureLoader = new THREE.TextureLoader();
    let backdropMesh: THREE.Mesh | undefined;
    textureLoader.load(
      IMAGES.backdrop,
      (texture) => {
        texture.colorSpace = THREE.SRGBColorSpace;
        const bgGeo = new THREE.PlaneGeometry(60, 40);
        const bgMat = new THREE.MeshBasicMaterial({
          map: texture,
          transparent: true,
          opacity: 0.65,
          depthWrite: false,
        });
        backdropMesh = new THREE.Mesh(bgGeo, bgMat);
        backdropMesh.position.set(0, 0, -10);
        scene.add(backdropMesh);
      },
      undefined,
      () => {
        // Fallback if texture fails
      }
    );

    // Ground Group
    const groundGroup = new THREE.Group();
    scene.add(groundGroup);

    // Soil Floor
    const groundGeo = new THREE.BoxGeometry(100, 6, 14);
    const groundMat = new THREE.MeshStandardMaterial({
      color: 0x4a2e1b,
      roughness: 0.9,
      metalness: 0.1,
    });
    const groundMesh = new THREE.Mesh(groundGeo, groundMat);
    groundMesh.position.set(0, GROUND_Y - 3, 0);
    groundGroup.add(groundMesh);

    // Grass
    const grassGeo = new THREE.BoxGeometry(100, 0.8, 14.2);
    const grassMat = new THREE.MeshStandardMaterial({
      color: 0x2ed573,
      roughness: 0.6,
      metalness: 0.1,
    });
    const grassMesh = new THREE.Mesh(grassGeo, grassMat);
    grassMesh.position.set(0, GROUND_Y, 0);
    groundGroup.add(grassMesh);

    // Stage Footlights
    for (let gx = -40; gx <= 40; gx += 8) {
      const lampGeo = new THREE.CylinderGeometry(0.35, 0.55, 0.45, 16);
      const lampMat = new THREE.MeshStandardMaterial({
        color: 0xffbe28,
        emissive: 0xff9f1c,
        emissiveIntensity: 0.8,
      });
      const lamp = new THREE.Mesh(lampGeo, lampMat);
      lamp.position.set(gx, GROUND_Y + 0.5, 1.8);
      groundGroup.add(lamp);
    }

    // 3D Potato Character Hero
    const potatoGroup = new THREE.Group();
    scene.add(potatoGroup);

    // 1. Potato Body
    const bodyGeo = new THREE.SphereGeometry(1.3, 32, 24);
    bodyGeo.scale(1.1, 1.35, 0.95);
    const bodyMat = new THREE.MeshStandardMaterial({
      color: 0xd49b6a,
      roughness: 0.7,
      metalness: 0.15,
    });
    const potatoBody = new THREE.Mesh(bodyGeo, bodyMat);
    potatoBody.castShadow = true;
    potatoGroup.add(potatoBody);

    // Spots
    for (let p = 0; p < 8; p++) {
      const spotGeo = new THREE.SphereGeometry(0.12, 8, 8);
      const spotMat = new THREE.MeshStandardMaterial({
        color: 0x8a5832,
        roughness: 0.9,
      });
      const spot = new THREE.Mesh(spotGeo, spotMat);
      const ang = (p / 8) * Math.PI * 2;
      spot.position.set(Math.cos(ang) * 1.1, Math.sin(ang) * 1.2, 0.7);
      spot.scale.set(1, 0.6, 0.4);
      potatoGroup.add(spot);
    }

    // 2. Headband
    const bandGeo = new THREE.CylinderGeometry(1.22, 1.22, 0.35, 32);
    const bandMat = new THREE.MeshStandardMaterial({
      color: 0xff2e63,
      roughness: 0.3,
      emissive: 0x770022,
    });
    const headband = new THREE.Mesh(bandGeo, bandMat);
    headband.position.set(0, 0.85, 0);
    headband.rotation.x = 0.15;
    potatoGroup.add(headband);

    const knotGeo = new THREE.BoxGeometry(0.2, 0.8, 0.1);
    const knot = new THREE.Mesh(knotGeo, bandMat);
    knot.position.set(-1.1, 0.6, -0.4);
    knot.rotation.z = 0.5;
    potatoGroup.add(knot);

    // 3. Rockstar Sunglasses
    const glassGeo = new THREE.BoxGeometry(1.4, 0.45, 0.25);
    const glassMat = new THREE.MeshStandardMaterial({
      color: 0x0a0a0a,
      roughness: 0.1,
      metalness: 0.9,
    });
    const glasses = new THREE.Mesh(glassGeo, glassMat);
    glasses.position.set(0, 0.45, 0.85);
    potatoGroup.add(glasses);

    const glassRimGeo = new THREE.BoxGeometry(1.48, 0.52, 0.08);
    const glassRimMat = new THREE.MeshStandardMaterial({
      color: 0xffd700,
      metalness: 0.9,
      roughness: 0.2,
    });
    const glassRim = new THREE.Mesh(glassRimGeo, glassRimMat);
    glassRim.position.set(0, 0.45, 0.88);
    potatoGroup.add(glassRim);

    // 4. Rockstar Arms
    const armGeo = new THREE.SphereGeometry(0.26, 12, 12);
    const armMat = new THREE.MeshStandardMaterial({ color: 0xbd8554 });
    const leftArm = new THREE.Mesh(armGeo, armMat);
    leftArm.position.set(-1.25, -0.2, 0.3);
    potatoGroup.add(leftArm);

    const rightArm = new THREE.Mesh(armGeo, armMat);
    rightArm.position.set(1.25, -0.2, 0.3);
    potatoGroup.add(rightArm);

    // 5. Shield Energy Sphere
    const shieldGeo = new THREE.SphereGeometry(2.1, 24, 24);
    const shieldMat = new THREE.MeshStandardMaterial({
      color: 0x00d2ff,
      transparent: true,
      opacity: 0.5,
      roughness: 0.1,
      metalness: 0.8,
      emissive: 0x0088cc,
    });
    const shieldSphereMesh = new THREE.Mesh(shieldGeo, shieldMat);
    shieldSphereMesh.visible = false;
    potatoGroup.add(shieldSphereMesh);

    potatoGroup.scale.set(0.9, 0.9, 0.9);

    threeRef.current = {
      scene,
      camera,
      renderer,
      potatoGroup,
      shieldSphereMesh,
      groundGroup,
      stageSpotLight,
      stageSpotLight2,
      backdropMesh,
    };

    // Resize Observer
    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const w = entry.contentRect.width;
        const h = entry.contentRect.height;
        if (w > 0 && h > 0) {
          camera.aspect = w / h;
          camera.updateProjectionMatrix();
          renderer.setSize(w, h);
        }
      }
    });
    resizeObserver.observe(container);

    return () => {
      resizeObserver.disconnect();
      renderer.dispose();
    };
  }, []);

  // Helpers for 3D meshes
  const createPipeMesh = useCallback(() => {
    const group = new THREE.Group();
    const matPipe = new THREE.MeshStandardMaterial({
      color: 0x8e44ad,
      metalness: 0.65,
      roughness: 0.25,
      emissive: 0x24112c,
    });
    const matRim = new THREE.MeshStandardMaterial({
      color: 0xf39c12,
      metalness: 0.9,
      roughness: 0.15,
      emissive: 0x664400,
    });

    const pipeGeo = new THREE.CylinderGeometry(1.2, 1.2, 20, 24);
    const rimGeo = new THREE.CylinderGeometry(1.4, 1.4, 1.2, 24);

    const topPipe = new THREE.Mesh(pipeGeo, matPipe);
    topPipe.castShadow = true;
    const topRim = new THREE.Mesh(rimGeo, matRim);
    topRim.position.y = -10;
    topPipe.add(topRim);

    const botPipe = new THREE.Mesh(pipeGeo, matPipe);
    botPipe.castShadow = true;
    const botRim = new THREE.Mesh(rimGeo, matRim);
    botRim.position.y = 10;
    botPipe.add(botRim);

    group.add(topPipe);
    group.add(botPipe);

    return { group, topPipe, botPipe };
  }, []);

  const createCollectiblePotatoMesh = useCallback(() => {
    const group = new THREE.Group();
    const geo = new THREE.SphereGeometry(0.85, 16, 16);
    geo.scale(1.1, 1.3, 0.9);

    const mat = new THREE.MeshStandardMaterial({
      color: 0xffd700,
      metalness: 0.85,
      roughness: 0.2,
      emissive: 0xb58000,
      emissiveIntensity: 0.5,
    });
    const pMesh = new THREE.Mesh(geo, mat);
    group.add(pMesh);

    // Sprout Leaves
    const leafGeo = new THREE.BoxGeometry(0.12, 0.6, 0.35);
    const leafMat = new THREE.MeshStandardMaterial({
      color: 0x2ed573,
      emissive: 0x0f6630,
    });
    const leaf1 = new THREE.Mesh(leafGeo, leafMat);
    leaf1.position.set(0.12, 0.9, 0);
    leaf1.rotation.z = -0.4;
    group.add(leaf1);

    const leaf2 = new THREE.Mesh(leafGeo, leafMat);
    leaf2.position.set(-0.12, 0.9, 0);
    leaf2.rotation.z = 0.4;
    group.add(leaf2);

    // Aura ring
    const ringGeo = new THREE.TorusGeometry(1.2, 0.08, 8, 24);
    const ringMat = new THREE.MeshBasicMaterial({ color: 0xffea00 });
    const ringMesh = new THREE.Mesh(ringGeo, ringMat);
    ringMesh.rotation.x = Math.PI / 2;
    group.add(ringMesh);

    const pLight = new THREE.PointLight(0xffbe28, 2.0, 7);
    group.add(pLight);

    return group;
  }, []);

  const spawnDirtExplosion = useCallback((x: number, y: number) => {
    if (!threeRef.current) return;
    const { scene } = threeRef.current;
    const g = gameRef.current;

    for (let i = 0; i < 10; i++) {
      const pGeo = new THREE.DodecahedronGeometry(0.18 + Math.random() * 0.15);
      const pMat = new THREE.MeshStandardMaterial({
        color: 0x6e4a2f,
        roughness: 0.9,
      });
      const pMesh = new THREE.Mesh(pGeo, pMat);
      pMesh.position.set(
        x + (Math.random() - 0.5) * 0.8,
        y,
        (Math.random() - 0.5) * 0.8
      );
      scene.add(pMesh);
      g.dirtParticles3D.push({
        mesh: pMesh,
        vx: (Math.random() - 0.5) * 4,
        vy: 3.5 + Math.random() * 4,
        life: 0.8,
      });
    }
  }, []);

  const spawnNoteFX = useCallback((x: number, y: number, z: number) => {
    if (!threeRef.current) return;
    const { scene } = threeRef.current;
    const g = gameRef.current;

    const canvas = document.createElement('canvas');
    canvas.width = 128;
    canvas.height = 128;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.font = '80px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    const symbols = ['🥔', '🎵', '🎸', '✨', '🛡️'];
    ctx.fillText(symbols[(Math.random() * symbols.length) | 0], 64, 64);

    const tex = new THREE.CanvasTexture(canvas);
    const mat = new THREE.SpriteMaterial({
      map: tex,
      transparent: true,
      opacity: 1.0,
    });
    const sprite = new THREE.Sprite(mat);
    sprite.scale.set(1.8, 1.8, 1.8);
    sprite.position.set(x, y, z);
    scene.add(sprite);

    g.musicNotes3D.push({
      sprite,
      vy: 2.5 + Math.random() * 2.0,
      vx: (Math.random() - 0.5) * 1.5,
      life: 1.0,
    });
  }, []);

  const spawnPipe3D = useCallback(
    (x: number, forceY?: number) => {
      if (!threeRef.current) return;
      const { scene } = threeRef.current;
      const g = gameRef.current;

      const pData = createPipeMesh();
      const gapY =
        typeof forceY === 'number' ? forceY : Math.random() * 5.6 - 2.8;

      pData.topPipe.position.set(0, gapY + PIPE_GAP / 2 + 10, 0);
      pData.botPipe.position.set(0, gapY - PIPE_GAP / 2 - 10, 0);
      pData.group.position.x = x;
      scene.add(pData.group);

      g.pipes3D.push({
        group: pData.group,
        x,
        gapY,
        scored: false,
      });
      g.spawnedTotal++;

      // Popping potato item spawn
      if (g.spawnedTotal > 1 && Math.random() < 0.85) {
        const pMesh = createCollectiblePotatoMesh();
        const spawnX = x - 4.8;
        const targetY = Math.max(
          -4.5,
          Math.min(5.5, gapY + (Math.random() * 2.0 - 1.0))
        );
        pMesh.position.set(spawnX, GROUND_Y + 0.5, 0);
        scene.add(pMesh);

        g.poppingPotatoes3D.push({
          mesh: pMesh,
          x: spawnX,
          y: GROUND_Y + 0.5,
          targetY,
          popped: false,
          got: false,
          phase: Math.random() * Math.PI * 2,
        });
      }
    },
    [createPipeMesh, createCollectiblePotatoMesh]
  );

  const resetRun = useCallback(() => {
    if (!threeRef.current) return;
    const { scene, potatoGroup } = threeRef.current;
    const g = gameRef.current;

    for (const p of g.pipes3D) scene.remove(p.group);
    for (const pop of g.poppingPotatoes3D) scene.remove(pop.mesh);
    for (const n of g.musicNotes3D) scene.remove(n.sprite);
    for (const d of g.dirtParticles3D) scene.remove(d.mesh);

    g.pipes3D = [];
    g.poppingPotatoes3D = [];
    g.musicNotes3D = [];
    g.dirtParticles3D = [];

    g.potatoBox = { x: -4, y: 0, vy: 0, rot: 0, alive: true };
    potatoGroup.position.set(g.potatoBox.x, g.potatoBox.y, 0);
    potatoGroup.rotation.z = 0;

    g.score = 0;
    g.combo = 0;
    g.bestCombo = 0;
    g.starCount = 0;
    g.shields = 0;
    g.passed = 0;
    g.activeShieldTimer = 0;
    g.runTime = 0;
    g.cameraShake = 0;
    g.spawnedTotal = 0;
    g.speedBonus = 0;
    g.newRecord = false;

    spawnPipe3D(8, 0);

    setStats((prev) => ({
      ...prev,
      score: 0,
      runTime: 0,
      starCount: 0,
      shields: 0,
      activeShieldTimer: 0,
      combo: 0,
      bestCombo: 0,
      passed: 0,
      newRecord: false,
    }));
  }, [spawnPipe3D]);

  const flap = useCallback(() => {
    const g = gameRef.current;
    g.potatoBox.vy = 10.8;
    sounds.sndJump();
    spawnNoteFX(g.potatoBox.x - 0.5, g.potatoBox.y, 0);
  }, [spawnNoteFX]);

  const activateShield = useCallback(() => {
    const g = gameRef.current;
    if (g.state !== 'play' && g.state !== 'ready') return;
    if (g.shields <= 0 && g.activeShieldTimer <= 0) {
      showToast('🛡️ 방패 충전량이 없어요! 땅 속 감자를 획득하세요!');
      return;
    }

    if (g.shields > 0) {
      g.shields--;
      g.activeShieldTimer = Math.max(g.activeShieldTimer + 4.0, 4.0);
      sounds.sndShieldActivate();
      showToast('🛡️ 무적 에너지가 4초간 발동되었습니다!');
      setStats((prev) => ({
        ...prev,
        shields: g.shields,
        activeShieldTimer: g.activeShieldTimer,
      }));
    }
  }, [showToast]);

  const startGame = useCallback(() => {
    const g = gameRef.current;
    if (g.nowSec - g.lastStartAt < 0.3) return;
    g.lastStartAt = g.nowSec;
    sounds.init();
    resetRun();
    setGameState('ready');
    sounds.sndStart();
    showToast('준비! 점프하여 감자를 날려보세요! 🥔');
  }, [resetRun, showToast]);

  const handlePressAction = useCallback(() => {
    sounds.init();
    const g = gameRef.current;
    if (g.state === 'title') {
      startGame();
      return;
    }
    if (g.state === 'ready') {
      setGameState('play');
      flap();
      return;
    }
    if (g.state === 'play') {
      flap();
      return;
    }
    if (g.state === 'over') {
      if (g.overWait <= 0) startGame();
      return;
    }
  }, [startGame, flap]);

  const die = useCallback(() => {
    const g = gameRef.current;
    if (!g.potatoBox.alive) return;
    g.potatoBox.alive = false;
    setGameState('dying');
    g.cameraShake = 0.8;
    sounds.sndHit();
    showToast('💥 부딪혔어요!');
  }, [showToast]);

  const showOver = useCallback(() => {
    const g = gameRef.current;
    setGameState('over');
    g.overWait = 0.25;

    let isNewBest = false;
    if (g.score > g.best) {
      g.best = g.score;
      try {
        localStorage.setItem(STORE_BEST, String(g.best));
      } catch {}
      isNewBest = true;
      g.newRecord = true;
    }

    setStats((prev) => ({
      ...prev,
      score: g.score,
      best: g.best,
      passed: g.passed,
      starCount: g.starCount,
      newRecord: isNewBest,
    }));
  }, []);

  // Main animation and physics loop
  useEffect(() => {
    let lastTime = 0;
    let reqId = 0;

    const animate = (timestamp: number) => {
      reqId = requestAnimationFrame(animate);
      if (!threeRef.current) return;
      const {
        scene,
        camera,
        renderer,
        potatoGroup,
        shieldSphereMesh,
        groundGroup,
        stageSpotLight,
        stageSpotLight2,
        backdropMesh,
      } = threeRef.current;
      const g = gameRef.current;

      if (!lastTime) lastTime = timestamp;
      let dt = (timestamp - lastTime) / 1000;
      if (dt > 0.08) dt = 0.08;
      lastTime = timestamp;
      g.nowSec = timestamp / 1000;

      // Pipe Speed calculation
      const spd = 8.0 + Math.min(g.passed, 50) * 0.12 + g.speedBonus;

      // Dynamic Stage Spotlights
      stageSpotLight.position.x = Math.sin(g.nowSec * 2) * 12;
      stageSpotLight2.position.x = Math.cos(g.nowSec * 2.5) * 12;

      if (backdropMesh) {
        // Subtle backdrop breath
        backdropMesh.position.x = Math.sin(g.nowSec * 0.5) * 1.5;
      }

      // Shield Timer & Visual
      if (g.activeShieldTimer > 0) {
        g.activeShieldTimer -= dt;
        if (g.activeShieldTimer <= 0) {
          g.activeShieldTimer = 0;
          showToast('🛡️ 방패 보호막이 해제되었습니다.');
        }
        shieldSphereMesh.visible = true;
        shieldSphereMesh.rotation.y += dt * 4;
        shieldSphereMesh.rotation.z += dt * 2;
      } else {
        shieldSphereMesh.visible = false;
      }

      // Dirt particles update
      for (let dp = g.dirtParticles3D.length - 1; dp >= 0; dp--) {
        const dirt = g.dirtParticles3D[dp];
        dirt.life -= dt * 1.5;
        if (dirt.life <= 0) {
          scene.remove(dirt.mesh);
          g.dirtParticles3D.splice(dp, 1);
          continue;
        }
        dirt.vy -= 22 * dt;
        dirt.mesh.position.x += dirt.vx * dt;
        dirt.mesh.position.y += dirt.vy * dt;
        dirt.mesh.scale.setScalar(dirt.life);
      }

      // Music notes update
      for (let n = g.musicNotes3D.length - 1; n >= 0; n--) {
        const note = g.musicNotes3D[n];
        note.life -= dt * 1.2;
        if (note.life <= 0) {
          scene.remove(note.sprite);
          g.musicNotes3D.splice(n, 1);
          continue;
        }
        note.sprite.position.y += note.vy * dt;
        note.sprite.position.x += note.vx * dt;
        (note.sprite.material as THREE.SpriteMaterial).opacity = note.life;
      }

      // Ground scroll
      groundGroup.position.x = -(g.runTime * spd) % 8;

      // State handling
      if (g.state === 'title') {
        potatoGroup.position.y = Math.sin(g.nowSec * 2.5) * 0.5;
        potatoGroup.rotation.z = Math.sin(g.nowSec * 2) * 0.1;
      } else if (g.state === 'ready') {
        potatoGroup.position.y = Math.sin(g.nowSec * 3) * 0.3;
        potatoGroup.rotation.z = Math.sin(g.nowSec * 2) * 0.05;
      } else if (g.state === 'over') {
        if (g.overWait > 0) g.overWait -= dt;
      } else if (g.state === 'dying') {
        g.potatoBox.vy -= 28 * dt;
        g.potatoBox.y += g.potatoBox.vy * dt;
        potatoGroup.position.y = g.potatoBox.y;
        potatoGroup.rotation.z += dt * 8;
        if (g.potatoBox.y < GROUND_Y + 1) {
          showOver();
        }
      } else if (g.state === 'play') {
        g.runTime += dt;
        g.potatoBox.vy -= 26 * dt; // Gravity
        g.potatoBox.y += g.potatoBox.vy * dt;

        // Ceiling and floor checks
        if (g.potatoBox.y > 11) {
          g.potatoBox.y = 11;
          g.potatoBox.vy = 0;
        }
        if (g.potatoBox.y < GROUND_Y + 1.2) {
          die();
          return;
        }

        potatoGroup.position.y = g.potatoBox.y;
        potatoGroup.rotation.z = Math.max(
          -0.6,
          Math.min(0.5, g.potatoBox.vy * 0.04)
        );

        // Popping Potatoes items
        for (let pk = g.poppingPotatoes3D.length - 1; pk >= 0; pk--) {
          const popP = g.poppingPotatoes3D[pk];
          popP.x -= spd * dt;

          if (!popP.popped && popP.x < 15) {
            popP.popped = true;
            sounds.sndPotatoPop();
            spawnDirtExplosion(popP.x, GROUND_Y + 0.5);
          }

          if (popP.popped) {
            popP.y += (popP.targetY - popP.y) * Math.min(1.0, dt * 7.5);
            if (Math.abs(popP.y - popP.targetY) < 0.6) {
              popP.y = popP.targetY + Math.sin(g.nowSec * 5 + popP.phase) * 0.45;
            }
          }

          popP.mesh.position.set(popP.x, popP.y, 0);
          popP.mesh.rotation.y += dt * 4;

          // Magnet effect towards potato
          const distToPotato = Math.hypot(
            popP.x - g.potatoBox.x,
            popP.y - g.potatoBox.y
          );
          if (distToPotato < 3.8 && !popP.got) {
            popP.x += (g.potatoBox.x - popP.x) * dt * 7.0;
            popP.y += (g.potatoBox.y - popP.y) * dt * 7.0;
          }

          // Collection
          if (!popP.got && distToPotato < 2.2) {
            popP.got = true;
            g.starCount++;
            g.score += 3;
            g.shields = Math.min(5, g.shields + 1);

            sounds.sndPotatoPop();
            spawnNoteFX(popP.x, popP.y, 0);
            showToast('🥔 아이템 감자 획득! +3점 & 🛡️방패 충전!');
            scene.remove(popP.mesh);
            g.poppingPotatoes3D.splice(pk, 1);
            setStats((prev) => ({
              ...prev,
              score: g.score,
              starCount: g.starCount,
              shields: g.shields,
            }));
            continue;
          }

          if (popP.x < -18) {
            scene.remove(popP.mesh);
            g.poppingPotatoes3D.splice(pk, 1);
          }
        }

        // Pipe Obstacles
        for (let i = g.pipes3D.length - 1; i >= 0; i--) {
          const p = g.pipes3D[i];
          p.x -= spd * dt;
          p.group.position.x = p.x;

          // Score scoring
          if (!p.scored && p.x < g.potatoBox.x) {
            p.scored = true;
            g.passed++;
            g.score += 1;
            g.combo++;
            if (g.combo > g.bestCombo) g.bestCombo = g.combo;

            sounds.playRockChord(g.passed);
            spawnNoteFX(g.potatoBox.x + 0.8, g.potatoBox.y, 0);

            setStats((prev) => ({
              ...prev,
              score: g.score,
              combo: g.combo,
              passed: g.passed,
            }));
          }

          // Collision Check
          if (Math.abs(p.x - g.potatoBox.x) < 0.95) {
            const topLimit = p.gapY + PIPE_GAP / 2 - 0.35;
            const botLimit = p.gapY - PIPE_GAP / 2 + 0.35;

            if (g.potatoBox.y > topLimit || g.potatoBox.y < botLimit) {
              if (g.activeShieldTimer > 0) {
                p.scored = true;
                sounds.sndShieldBreak();
                showToast('🛡️ 방패가 장애물을 튕겨냈습니다!');
                g.potatoBox.vy = 8;
                spawnNoteFX(g.potatoBox.x, g.potatoBox.y, 0);
              } else if (g.shields > 0) {
                g.shields--;
                g.activeShieldTimer = 2.0;
                p.scored = true;
                sounds.sndShieldBreak();
                showToast('🛡️ 방패가 즉시 발동하여 충격을 막았습니다!');
                g.potatoBox.vy = 8;
                setStats((prev) => ({
                  ...prev,
                  shields: g.shields,
                  activeShieldTimer: g.activeShieldTimer,
                }));
              } else {
                die();
                return;
              }
            }
          }

          if (p.x < -18) {
            scene.remove(p.group);
            g.pipes3D.splice(i, 1);
          }
        }

        // Spawn next pipe
        const lastPipe = g.pipes3D[g.pipes3D.length - 1];
        if (!lastPipe || PIPE_SPAWN_X - lastPipe.x >= 9.5) {
          spawnPipe3D(PIPE_SPAWN_X);
        }

        // Sync runtime and shield state periodically
        setStats((prev) => ({
          ...prev,
          runTime: g.runTime,
          activeShieldTimer: g.activeShieldTimer,
        }));
      }

      // Camera Shake
      if (g.cameraShake > 0) {
        g.cameraShake = Math.max(0, g.cameraShake - dt * 2.5);
        camera.position.x = (Math.random() - 0.5) * g.cameraShake * 1.5;
        camera.position.y = (Math.random() - 0.5) * g.cameraShake * 1.5;
      } else {
        camera.position.set(0, 0, 24);
      }

      renderer.render(scene, camera);
    };

    reqId = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(reqId);
  }, [die, showOver, showToast, spawnDirtExplosion, spawnNoteFX, spawnPipe3D]);

  // Keyboard controls
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const k = e.key;
      if (k === ' ' || k === 'ArrowUp' || k === 'w' || k === 'W') {
        e.preventDefault();
        handlePressAction();
      }
      if (k === 's' || k === 'S' || k === 'Shift') {
        e.preventDefault();
        sounds.init();
        activateShield();
      }
      if (k === 'm' || k === 'M') {
        const muted = sounds.toggleMute();
        setIsMuted(muted);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handlePressAction, activateShield]);

  const toggleMute = (e: React.MouseEvent) => {
    e.stopPropagation();
    const muted = sounds.toggleMute();
    setIsMuted(muted);
  };

  const getRankBadge = (score: number) => {
    if (score >= 35) return { name: '전설의 록스타 골든 감자', tier: 'legend' };
    if (score >= 20) return { name: '플래티넘 록 밴드 리더', tier: 'master' };
    if (score >= 10) return { name: '슈퍼루키 감자 기타리스트', tier: 'rookie' };
    return { name: '새싹 버스킹 감자', tier: 'beginner' };
  };

  const rank = getRankBadge(stats.score);

  return (
    <div
      ref={containerRef}
      id="stage-container"
      className="relative w-full h-screen max-w-[600px] max-h-[900px] mx-auto overflow-hidden bg-[#070611] text-white rounded-2xl shadow-2xl select-none touch-manipulation flex flex-col justify-center items-center border border-purple-500/20"
      onPointerDown={(e) => {
        // Prevent click if clicking direct UI buttons
        if ((e.target as HTMLElement).closest('button')) return;
        e.preventDefault();
        handlePressAction();
      }}
    >
      {/* 3D Canvas */}
      <canvas
        ref={canvasRef}
        id="three-canvas"
        className="block w-full h-full cursor-pointer"
      />

      {/* HUD Header */}
      <header
        id="hud-header"
        className="absolute top-0 left-0 right-0 z-10 flex flex-wrap items-center gap-2 p-3 text-xs md:text-sm font-extrabold pointer-events-none drop-shadow-md"
      >
        <span
          id="chip-score"
          className="bg-black/60 backdrop-blur-md border border-amber-400/40 rounded-full px-3 py-1.5 flex items-center gap-1.5 shadow"
        >
          <Flame className="w-4 h-4 text-amber-400 fill-amber-400" />
          {stats.score}점
        </span>

        <span
          id="chip-time"
          className="bg-black/60 backdrop-blur-md border border-white/20 rounded-full px-3 py-1.5 flex items-center gap-1 shadow text-slate-200"
        >
          ⏱ {Math.floor(stats.runTime)}초
        </span>

        {/* [Asset 3 Integration] Golden Potato Medal icon in HUD */}
        <span
          id="chip-potatoes"
          className="bg-black/60 backdrop-blur-md border border-yellow-400/40 rounded-full px-3 py-1.5 flex items-center gap-1.5 shadow text-yellow-300"
        >
          <img
            src={IMAGES.medal}
            alt="감자"
            className="w-4 h-4 rounded-full object-cover"
            referrerPolicy="no-referrer"
          />
          {stats.starCount}개
        </span>

        <span
          id="chip-shield"
          className={`rounded-full px-3 py-1.5 flex items-center gap-1.5 transition-all shadow ${
            stats.activeShieldTimer > 0
              ? 'bg-cyan-500/80 border-2 border-cyan-200 shadow-[0_0_15px_rgba(0,210,255,0.8)] animate-pulse text-white'
              : stats.shields > 0
              ? 'bg-cyan-950/70 border border-cyan-400/60 text-cyan-300'
              : 'bg-black/60 border border-white/10 text-slate-400'
          }`}
        >
          <Shield className="w-4 h-4 text-cyan-400" />
          {stats.activeShieldTimer > 0
            ? `${stats.shields} (작동 ${Math.ceil(stats.activeShieldTimer)}s)`
            : `${stats.shields}`}
        </span>

        <div className="flex-1" />

        <span
          id="chip-best"
          className="bg-black/60 backdrop-blur-md border border-yellow-500/30 rounded-full px-3 py-1.5 flex items-center gap-1.5 shadow text-yellow-400"
        >
          <Trophy className="w-4 h-4 text-yellow-400" />
          {stats.best}
        </span>

        <button
          id="mute-button"
          type="button"
          onClick={toggleMute}
          className="pointer-events-auto bg-black/60 hover:bg-black/80 backdrop-blur-md border border-white/20 text-white rounded-full p-2 transition cursor-pointer active:scale-95"
          aria-label="음소거 토글"
        >
          {isMuted ? (
            <VolumeX className="w-4 h-4 text-rose-400" />
          ) : (
            <Volume2 className="w-4 h-4 text-emerald-400" />
          )}
        </button>
      </header>

      {/* Manual Shield Activate Button */}
      <button
        id="shield-activate-button"
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          activateShield();
        }}
        disabled={stats.shields === 0 && stats.activeShieldTimer === 0}
        className={`absolute bottom-6 right-5 z-20 flex items-center gap-2 px-5 py-3 rounded-full font-black text-sm md:text-base cursor-pointer shadow-xl transition-all ${
          stats.shields > 0 || stats.activeShieldTimer > 0
            ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white border-2 border-cyan-200 shadow-cyan-500/50 hover:scale-105 active:scale-95'
            : 'bg-slate-800/80 text-slate-500 border border-slate-700 cursor-not-allowed opacity-40'
        }`}
      >
        <Shield className="w-5 h-5" />
        방패 가동 (S키)
      </button>

      {/* Floating Toast Notification */}
      {toastMsg && (
        <div
          id="toast-notification"
          className="absolute top-20 left-1/2 -translate-x-1/2 z-30 bg-slate-950/90 border border-amber-400/80 text-amber-200 font-extrabold px-5 py-2.5 rounded-full text-sm shadow-xl animate-in fade-in zoom-in-95 pointer-events-none whitespace-nowrap"
        >
          {toastMsg}
        </div>
      )}

      {/* [Asset 2 Integration] Title Screen Overlay with Hero Character Card */}
      {gameState === 'title' && (
        <div
          id="title-screen-overlay"
          className="absolute inset-0 z-40 flex flex-col items-center justify-center p-6 text-center bg-radial from-purple-950/80 via-[#070611]/95 to-black/98 backdrop-blur-md"
        >
          {/* Character Asset Card */}
          <div
            id="hero-asset-card"
            className="relative mb-3 group"
          >
            <div className="absolute -inset-1.5 bg-gradient-to-r from-amber-400 via-rose-500 to-cyan-400 rounded-full blur-md opacity-75 animate-pulse" />
            <img
              src={IMAGES.hero}
              alt="록스타 감자 히어로"
              className="relative w-36 h-36 md:w-44 md:h-44 rounded-full object-cover border-4 border-amber-300 shadow-2xl"
              referrerPolicy="no-referrer"
            />
          </div>

          <h1
            id="game-main-title"
            className="text-3xl md:text-4xl font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-b from-amber-200 via-amber-400 to-orange-500 drop-shadow-[0_4px_12px_rgba(245,158,11,0.5)]"
          >
            록스타 감자 3D 🥔
          </h1>
          <p
            id="game-subtitle"
            className="text-xs md:text-sm font-bold text-slate-300 mb-4"
          >
            열정의 무대를 향해 날아오르는 3D 록스타 감자!
          </p>

          <div
            id="title-instructions-card"
            className="bg-slate-900/90 border border-amber-400/30 rounded-2xl p-4 max-w-sm w-full text-left text-xs md:text-sm text-slate-200 space-y-1.5 shadow-xl mb-4"
          >
            <p>👆 <b>화면을 탭하거나 클릭</b>하여 감자 점프 비행!</p>
            <p>⌨️ <b>스페이스바 / 방향키 위</b>로도 편리하게 점프!</p>
            <p className="text-amber-300">
              🌱 <b>땅 속에서 튀어나오는 감자</b> 획득 시 <b>+3점 & 방패 충전!</b>
            </p>
            <p className="text-cyan-300">
              🛡️ <b>[방패 가동] 버튼이나 S키</b>로 무적 방패를 켜면 파이프 충돌 방어!
            </p>
          </div>

          <button
            id="btn-start-game"
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              startGame();
            }}
            className="bg-gradient-to-b from-amber-300 to-amber-500 hover:from-amber-200 hover:to-amber-400 text-slate-950 font-black text-lg px-8 py-3.5 rounded-xl border-b-4 border-amber-700 shadow-lg shadow-amber-500/40 active:translate-y-1 active:border-b transition-all flex items-center gap-2 cursor-pointer"
          >
            <Play className="w-5 h-5 fill-slate-950" />
            록스타 감자 출발!
          </button>

          <p className="mt-3 text-xs font-bold text-amber-200/80 animate-pulse">
            화면 아무 곳이나 탭하면 무대가 열립니다!
          </p>
        </div>
      )}

      {/* Ready Prompt Overlay */}
      {gameState === 'ready' && (
        <div
          id="ready-screen-overlay"
          className="absolute inset-0 z-30 flex flex-col items-center justify-center p-6 text-center pointer-events-none bg-black/20"
        >
          <div
            id="ready-card"
            className="bg-black/75 backdrop-blur-md border border-amber-400/50 rounded-2xl p-6 shadow-2xl animate-bounce"
          >
            <h2 className="text-2xl font-black text-amber-300">점프하여 출발!</h2>
            <p className="text-sm font-semibold text-slate-300 mt-1">
              화면을 탭하거나 스페이스바를 누르세요!
            </p>
          </div>
        </div>
      )}

      {/* [Asset 3 Integration] Game Over Screen Overlay with Golden Potato Trophy Badge */}
      {gameState === 'over' && (
        <div
          id="game-over-overlay"
          className="absolute inset-0 z-40 flex flex-col items-center justify-center p-6 text-center bg-radial from-rose-950/80 via-[#0a0512]/95 to-black/98 backdrop-blur-md"
        >
          <h2
            id="over-title"
            className="text-3xl md:text-4xl font-black text-transparent bg-clip-text bg-gradient-to-b from-amber-200 via-rose-300 to-orange-400 mb-2"
          >
            {stats.newRecord ? '🎉 신기록 달성!' : '공연 종료!'}
          </h2>

          <div
            id="over-result-card"
            className="bg-slate-900/95 border-2 border-amber-400/40 rounded-3xl p-6 max-w-sm w-full shadow-2xl flex flex-col items-center"
          >
            {/* Golden Medal Image Asset */}
            <div className="relative mb-3">
              <div className="absolute -inset-2 bg-amber-400/30 rounded-full blur-md" />
              <img
                src={IMAGES.medal}
                alt="골든 감자 메달"
                className="relative w-28 h-28 object-cover rounded-full border-2 border-amber-300 shadow-xl"
                referrerPolicy="no-referrer"
              />
            </div>

            <div
              id="over-medal-name"
              className="text-base font-black text-amber-400"
            >
              {rank.name}
            </div>

            <div
              id="over-score-display"
              className="text-5xl md:text-6xl font-black text-amber-300 my-2 tracking-tight drop-shadow-[0_4px_16px_rgba(251,191,36,0.6)]"
            >
              {stats.score}점
            </div>

            <div
              id="over-stats-breakdown"
              className="text-xs md:text-sm font-bold text-slate-400 mb-2"
            >
              통과 파이프 {stats.passed}개 · 수집 감자 {stats.starCount}개 · 최고 {stats.best}점
            </div>

            <p
              id="over-cheer-message"
              className={`text-sm font-bold mt-1 ${
                stats.newRecord ? 'text-emerald-400' : 'text-rose-400'
              }`}
            >
              {stats.newRecord
                ? '최고의 록스타 감자로서 새 역사를 썼습니다!'
                : '감자가 한 번 더 앵콜 무대에 서고 싶어해요!'}
            </p>
          </div>

          <button
            id="btn-restart-game"
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              startGame();
            }}
            className="mt-5 bg-gradient-to-b from-amber-300 to-amber-500 hover:from-amber-200 hover:to-amber-400 text-slate-950 font-black text-lg px-8 py-3.5 rounded-xl border-b-4 border-amber-700 shadow-lg shadow-amber-500/40 active:translate-y-1 active:border-b transition-all flex items-center gap-2 cursor-pointer"
          >
            <RotateCcw className="w-5 h-5" />
            다시 날아오르기 🥔
          </button>

          <p className="mt-3 text-xs font-bold text-slate-400 animate-pulse">
            스페이스바나 화면 탭으로 바로 재시작!
          </p>
        </div>
      )}
    </div>
  );
}
