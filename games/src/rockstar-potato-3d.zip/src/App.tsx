/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import RockstarGame from './components/RockstarGame';

export default function App() {
  return (
    <main className="w-screen h-screen bg-[#05040a] flex items-center justify-center overflow-hidden">
      <RockstarGame />
    </main>
  );
}

