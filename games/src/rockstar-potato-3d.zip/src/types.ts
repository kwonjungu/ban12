export type GameState = 'title' | 'ready' | 'play' | 'dying' | 'over';

export interface GameStats {
  score: number;
  best: number;
  runTime: number;
  starCount: number;
  shields: number;
  activeShieldTimer: number;
  combo: number;
  bestCombo: number;
  passed: number;
  newRecord: boolean;
}
