// Asset paths for generated images
// 문자열 경로('/src/assets/...')는 개발 서버에서만 통하고 빌드하면 404 가 된다.
// Vite 가 번들에 포함시키도록 import 로 가져온다.
import heroImg from './assets/images/rockstar_potato_hero_1789882064428.jpg';
import backdropImg from './assets/images/rock_stage_backdrop_1789882076048.jpg';
import medalImg from './assets/images/golden_potato_medal_1789882086316.jpg';

export const IMAGES = {
  hero: heroImg,
  backdrop: backdropImg,
  medal: medalImg,
};
