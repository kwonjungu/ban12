import { DifficultyConfig, SkinConfig } from './types';

export const GAME_WIDTH = 800;
export const GAME_HEIGHT = 450;
export const GROUND_Y = 375;

export const DIFFICULTIES: Record<'easy' | 'medium' | 'hard', DifficultyConfig> = {
  easy: {
    key: 'easy',
    name: '쉬움',
    speedMult: 0.85,
    scoreMult: 1.0,
    badgeClass: 'bg-emerald-500/90 text-white border-emerald-400/50',
  },
  medium: {
    key: 'medium',
    name: '보통',
    speedMult: 1.05,
    scoreMult: 1.5,
    badgeClass: 'bg-blue-500/90 text-white border-blue-400/50',
  },
  hard: {
    key: 'hard',
    name: '어려움',
    speedMult: 1.3,
    scoreMult: 2.5,
    badgeClass: 'bg-rose-500/90 text-white border-rose-400/50',
  },
};

export const SKINS: SkinConfig[] = [
  {
    id: 'classic',
    name: '클래식 크롬 티렉스',
    desc: '오리지널 흑백 감성의 크롬 공룡',
    mainColor: '#535353',
    bellyColor: '#888888',
    accentColor: '#ffffff',
    emoji: '🦖',
  },
  {
    id: 'dragon',
    name: '드래곤 파이어',
    desc: '불꽃 스파크와 붉은 비늘의 화염룡',
    mainColor: '#dc2626',
    bellyColor: '#fde047',
    accentColor: '#f97316',
    emoji: '🐉',
  },
  {
    id: 'cyber',
    name: '사이버 네온',
    desc: '미래형 바이저와 푸른 네온 회로',
    mainColor: '#0284c7',
    bellyColor: '#38bdf8',
    accentColor: '#22d3ee',
    emoji: '🤖',
  },
  {
    id: 'cute',
    name: '아기 공룡 피치',
    desc: '초록빛 피부와 사랑스러운 핑크 볼터치',
    mainColor: '#10b981',
    bellyColor: '#a7f3d0',
    accentColor: '#f43f5e',
    emoji: '🐣',
  },
];

// Pixel-perfect representation of classic Chrome Dino
export const DINO_SPRITE_RUN1 = [
  "            █████████",
  "            ██ ██████",
  "            █████████",
  "            █████████",
  "            ████████ ",
  "            █████    ",
  "█           ███████  ",
  "█          ██████    ",
  "██        ████████   ",
  "███      █████████   ",
  "████    ██████████   ",
  "█████  ███████████   ",
  "██████████████████   ",
  " █████████████████   ",
  "  ████████████████   ",
  "   ██████████████    ",
  "    ████████████     ",
  "     █████  ████     ",
  "     ██      ██      ",
  "     ██      █       ",
  "     ██      ██      "
];

export const DINO_SPRITE_RUN2 = [
  "            █████████",
  "            ██ ██████",
  "            █████████",
  "            █████████",
  "            ████████ ",
  "            █████    ",
  "█           ███████  ",
  "█          ██████    ",
  "██        ████████   ",
  "███      █████████   ",
  "████    ██████████   ",
  "█████  ███████████   ",
  "██████████████████   ",
  " █████████████████   ",
  "  ████████████████   ",
  "   ██████████████    ",
  "    ████████████     ",
  "     ████   █████    ",
  "      ██      ██     ",
  "      █       ██     ",
  "      ██      ██     "
];

export const DINO_SPRITE_DUCK1 = [
  "                     ",
  "                     ",
  "                     ",
  "                     ",
  "                     ",
  "                     ",
  "                     ",
  "                     ",
  "            ████████████████████",
  "█          █████████████████████",
  "██        ████████████ █████████",
  "███      ███████████████████████",
  "████████████████████████        ",
  " ███████████████████████        ",
  "  ████████████████████          ",
  "   ██████████████████           ",
  "    █████   ████                ",
  "    ██       ██                 ",
  "    ██       █                  "
];

export const DINO_SPRITE_DUCK2 = [
  "                     ",
  "                     ",
  "                     ",
  "                     ",
  "                     ",
  "                     ",
  "                     ",
  "                     ",
  "            ████████████████████",
  "█          █████████████████████",
  "██        ████████████ █████████",
  "███      ███████████████████████",
  "████████████████████████        ",
  " ███████████████████████        ",
  "  ████████████████████          ",
  "   ██████████████████           ",
  "    ████    █████               ",
  "     ██       ██                ",
  "     █        ██                "
];

export const DINO_SPRITE_CRASH = [
  "            █████████",
  "            ██ █  ███",
  "            ██   ████",
  "            ██ █  ███",
  "            ████████ ",
  "            █████    ",
  "█           ███████  ",
  "█          ██████    ",
  "██        ████████   ",
  "███      █████████   ",
  "████    ██████████   ",
  "█████  ███████████   ",
  "██████████████████   ",
  " █████████████████   ",
  "  ████████████████   ",
  "   ██████████████    ",
  "    ████████████     ",
  "     █████  ████     ",
  "     ██      ██      ",
  "     ██      ██      ",
  "     ██      ██      "
];
