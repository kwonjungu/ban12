import bgUrl from '../assets/images/dino_runner_bg_1789886407166.jpg';
import eggUrl from '../assets/images/golden_dino_egg_1789886425026.jpg';
import pteroUrl from '../assets/images/flying_ptero_asset_1789886441730.jpg';
import cactusUrl from '../assets/images/pixel_cactus_asset_1789886454540.jpg';

export interface GameAssetImages {
  background: HTMLImageElement;
  goldenEgg: HTMLImageElement;
  pterodactyl: HTMLImageElement;
  cactus: HTMLImageElement;
  isLoaded: boolean;
}

export const assetUrls = {
  background: bgUrl,
  goldenEgg: eggUrl,
  pterodactyl: pteroUrl,
  cactus: cactusUrl,
};

let loadedAssets: GameAssetImages | null = null;

export function loadGameAssets(): GameAssetImages {
  if (loadedAssets) return loadedAssets;

  const bgImg = new Image();
  bgImg.src = bgUrl;

  const eggImg = new Image();
  eggImg.src = eggUrl;

  const pteroImg = new Image();
  pteroImg.src = pteroUrl;

  const cactusImg = new Image();
  cactusImg.src = cactusUrl;

  const assets: GameAssetImages = {
    background: bgImg,
    goldenEgg: eggImg,
    pterodactyl: pteroImg,
    cactus: cactusImg,
    isLoaded: false,
  };

  let loadedCount = 0;
  const total = 4;
  const onLoad = () => {
    loadedCount++;
    if (loadedCount >= total) {
      assets.isLoaded = true;
    }
  };

  bgImg.onload = onLoad;
  eggImg.onload = onLoad;
  pteroImg.onload = onLoad;
  cactusImg.onload = onLoad;

  loadedAssets = assets;
  return assets;
}
