import { useState, useEffect, useRef, useCallback } from 'react';
import { DifficultyKey, DinoState } from './types';
import { DIFFICULTIES, GROUND_Y, SKINS } from './data';
import { soundManager } from './utils/sound';
import GameHUD from './components/GameHUD';
import GameCanvas from './components/GameCanvas';
import StartOverlay from './components/StartOverlay';
import GameOverOverlay from './components/GameOverOverlay';
import SkinModal from './components/SkinModal';
import TouchControls from './components/TouchControls';

export default function App() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isGameOver, setIsGameOver] = useState(false);
  const [score, setScore] = useState(0);
  const [comboCount, setComboCount] = useState(0);
  const [highScore, setHighScore] = useState(() => {
    try {
      const saved = localStorage.getItem('dino_runner_hi');
      return saved ? parseInt(saved, 10) || 0 : 0;
    } catch {
      return 0;
    }
  });
  const [isNewHigh, setIsNewHigh] = useState(false);
  const [difficultyKey, setDifficultyKey] = useState<DifficultyKey>('easy');
  const [selectedSkinIndex, setSelectedSkinIndex] = useState(0);
  const [isSkinModalOpen, setIsSkinModalOpen] = useState(false);
  const [soundMuted, setSoundMuted] = useState(false);

  const currentDiff = DIFFICULTIES[difficultyKey];
  const selectedSkin = SKINS[selectedSkinIndex];

  // Persistent Dino mutable state for high-frequency physics
  const dinoRef = useRef<DinoState>({
    x: 80,
    y: GROUND_Y,
    width: 50,
    height: 54,
    normalHeight: 54,
    duckHeight: 34,
    vy: 0,
    gravity: 0.82,
    jumpForce: -14.8,
    isGrounded: true,
    isDucking: false,
    hasDoubleJumped: false,
    hasShield: false,
    doubleJumpLevel: 0,
    slowMotionTimer: 0,
    magnetTimer: 0,
    legCycle: 0,
    tailWag: 0,
  });

  const resetDino = useCallback(() => {
    const dino = dinoRef.current;
    dino.y = GROUND_Y;
    dino.vy = 0;
    dino.width = 50;
    dino.height = dino.normalHeight;
    dino.isGrounded = true;
    dino.isDucking = false;
    dino.hasDoubleJumped = false;
    dino.hasShield = false;
    dino.doubleJumpLevel = 0;
    dino.slowMotionTimer = 0;
    dino.magnetTimer = 0;
    dino.legCycle = 0;
    dino.tailWag = 0;
  }, []);

  const handleJump = useCallback(() => {
    const dino = dinoRef.current;
    const jumpBoost = dino.doubleJumpLevel >= 2 ? 1.28 : 1.0;

    if (dino.isGrounded) {
      dino.vy = dino.jumpForce * jumpBoost;
      dino.isGrounded = false;
      dino.hasDoubleJumped = false;
      soundManager.playJump();
    } else if (dino.doubleJumpLevel > 0 && !dino.hasDoubleJumped) {
      dino.vy = dino.jumpForce * 0.88 * jumpBoost;
      dino.hasDoubleJumped = true;
      soundManager.playJump();
    }
  }, []);

  const handleDuck = useCallback((enable: boolean) => {
    const dino = dinoRef.current;
    if (enable && dino.isGrounded) {
      dino.isDucking = true;
      dino.height = dino.duckHeight;
      dino.width = 64;
    } else {
      dino.isDucking = false;
      dino.height = dino.normalHeight;
      dino.width = 50;
    }
  }, []);

  const startGame = useCallback(() => {
    resetDino();
    setScore(0);
    setComboCount(0);
    setIsNewHigh(false);
    setIsPlaying(true);
    setIsGameOver(false);
  }, [resetDino]);

  const handleGameOver = useCallback(
    (finalScoreVal: number) => {
      setIsPlaying(false);
      setIsGameOver(true);

      const rounded = Math.floor(finalScoreVal);
      setScore(rounded);

      if (rounded > highScore) {
        setHighScore(rounded);
        setIsNewHigh(true);
        try {
          localStorage.setItem('dino_runner_hi', String(rounded));
        } catch {
          // localStorage error handling
        }
      }
    },
    [highScore]
  );

  const toggleSound = useCallback(() => {
    soundManager.muted = !soundManager.muted;
    setSoundMuted(soundManager.muted);
  }, []);

  // Global Keyboard listener
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      // Prevent browser from scrolling on arrow keys or space
      if (['Space', 'ArrowUp', 'ArrowDown'].includes(e.code)) {
        e.preventDefault();
      }

      if (e.code === 'Space' || e.code === 'ArrowUp' || e.code === 'KeyW') {
        if (!isPlaying && !isGameOver) {
          startGame();
        } else if (isGameOver) {
          startGame();
        } else {
          handleJump();
        }
      } else if (e.code === 'ArrowDown' || e.code === 'KeyS') {
        if (isPlaying && !isGameOver) {
          handleDuck(true);
        }
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      if (e.code === 'ArrowDown' || e.code === 'KeyS') {
        handleDuck(false);
      }
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);

    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
    };
  }, [isPlaying, isGameOver, startGame, handleJump, handleDuck]);

  return (
    <main className="min-h-screen w-full bg-slate-950 text-slate-100 flex items-center justify-center p-2 sm:p-4 overflow-hidden">
      {/* Game Stage Container: Fixed 16:9 Aspect ratio card matching desktop & mobile viewport */}
      <section
        id="dino-game-wrapper"
        className="relative w-full max-w-4xl aspect-[16/9] max-h-[88vh] bg-slate-900 rounded-2xl shadow-2xl overflow-hidden border border-slate-800 flex flex-col"
      >
        {/* HUD Overlay */}
        <GameHUD
          score={score}
          highScore={highScore}
          comboCount={comboCount}
          difficulty={currentDiff}
          dino={dinoRef.current}
          soundMuted={soundMuted}
          onToggleSound={toggleSound}
          onOpenSkinModal={() => setIsSkinModalOpen(true)}
          isPlaying={isPlaying}
        />

        {/* Canvas Area */}
        <div className="relative flex-1 w-full h-full overflow-hidden">
          <GameCanvas
            isPlaying={isPlaying}
            isGameOver={isGameOver}
            difficulty={currentDiff}
            selectedSkin={selectedSkin}
            score={score}
            onScoreUpdate={setScore}
            comboCount={comboCount}
            onComboUpdate={setComboCount}
            onGameOver={handleGameOver}
            dinoStateRef={dinoRef}
          />

          {/* Start Screen */}
          {!isPlaying && !isGameOver && (
            <StartOverlay
              onStartGame={startGame}
              currentDiffKey={difficultyKey}
              onSelectDifficulty={setDifficultyKey}
              selectedSkin={selectedSkin}
              onOpenSkinModal={() => setIsSkinModalOpen(true)}
            />
          )}

          {/* Game Over Screen */}
          {isGameOver && (
            <GameOverOverlay
              score={score}
              highScore={highScore}
              isNewHigh={isNewHigh}
              onRestart={startGame}
              currentDiffKey={difficultyKey}
              onSelectDifficulty={setDifficultyKey}
            />
          )}

          {/* Character Skin Selection Modal */}
          {isSkinModalOpen && (
            <SkinModal
              selectedSkinIndex={selectedSkinIndex}
              onSelectSkin={(idx) => setSelectedSkinIndex(idx)}
              onClose={() => setIsSkinModalOpen(false)}
            />
          )}
        </div>

        {/* Mobile Touch Controls */}
        <TouchControls
          onJump={!isPlaying || isGameOver ? startGame : handleJump}
          onDuckStart={() => handleDuck(true)}
          onDuckEnd={() => handleDuck(false)}
        />
      </section>
    </main>
  );
}
