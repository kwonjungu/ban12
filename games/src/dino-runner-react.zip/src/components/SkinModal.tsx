import { Check, X } from 'lucide-react';
import { SkinConfig } from '../types';
import { SKINS } from '../data';

interface SkinModalProps {
  selectedSkinIndex: number;
  onSelectSkin: (index: number) => void;
  onClose: () => void;
}

export default function SkinModal({
  selectedSkinIndex,
  onSelectSkin,
  onClose,
}: SkinModalProps) {
  return (
    <div
      id="skin-modal-backdrop"
      className="absolute inset-0 bg-slate-950/90 backdrop-blur-md flex flex-col items-center justify-center p-4 z-30 animate-fade-in"
    >
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 max-w-lg w-full shadow-2xl relative">
        <button
          type="button"
          id="close-skin-modal-btn"
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-slate-200 p-1.5 rounded-lg hover:bg-slate-800 transition cursor-pointer"
          aria-label="닫기"
        >
          <X className="w-5 h-5" />
        </button>

        <h3 className="text-xl font-bold text-white mb-1 flex items-center gap-2">
          <span>🦖</span>
          <span>공룡 캐릭터 스킨 선택</span>
        </h3>
        <p className="text-xs text-slate-400 mb-4">
          원하는 스타일의 공룡 캐릭터를 선택하세요! 게임 내에서 고유 색상과 이펙트가 적용됩니다.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 mb-5">
          {SKINS.map((skin: SkinConfig, index: number) => {
            const isSelected = selectedSkinIndex === index;
            return (
              <button
                key={skin.id}
                type="button"
                id={`skin-option-${skin.id}`}
                onClick={() => onSelectSkin(index)}
                className={`p-3 rounded-xl border-2 transition text-left flex items-center gap-3 cursor-pointer ${
                  isSelected
                    ? 'border-amber-400 bg-amber-500/10 shadow-md'
                    : 'border-slate-800 bg-slate-800/60 hover:bg-slate-800 hover:border-slate-700'
                }`}
              >
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl shadow-inner border border-white/10 shrink-0"
                  style={{ backgroundColor: `${skin.mainColor}25` }}
                >
                  {skin.emoji}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <div
                      className={`text-sm font-bold truncate ${
                        isSelected ? 'text-amber-300' : 'text-slate-200'
                      }`}
                    >
                      {skin.name}
                    </div>
                    {isSelected && <Check className="w-4 h-4 text-amber-400 shrink-0" />}
                  </div>
                  <div className="text-[11px] text-slate-400 truncate mt-0.5">{skin.desc}</div>
                  <div className="flex items-center gap-1 mt-1.5">
                    <span
                      className="w-2.5 h-2.5 rounded-full border border-black/30"
                      style={{ backgroundColor: skin.mainColor }}
                    />
                    <span
                      className="w-2.5 h-2.5 rounded-full border border-black/30"
                      style={{ backgroundColor: skin.bellyColor }}
                    />
                    <span
                      className="w-2.5 h-2.5 rounded-full border border-black/30"
                      style={{ backgroundColor: skin.accentColor }}
                    />
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        <button
          type="button"
          id="confirm-skin-btn"
          onClick={onClose}
          className="w-full bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 active:scale-98 text-slate-950 font-bold py-2.5 rounded-xl text-sm shadow-lg transition cursor-pointer"
        >
          선택 완료
        </button>
      </div>
    </div>
  );
}
