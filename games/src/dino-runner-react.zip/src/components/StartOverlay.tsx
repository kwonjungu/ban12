import { Play, Palette, Keyboard, Smartphone, Sparkles } from 'lucide-react';
import { DifficultyConfig, DifficultyKey, SkinConfig } from '../types';
import { DIFFICULTIES } from '../data';
import { assetUrls } from '../utils/assets';

interface StartOverlayProps {
  onStartGame: () => void;
  currentDiffKey: DifficultyKey;
  onSelectDifficulty: (key: DifficultyKey) => void;
  selectedSkin: SkinConfig;
  onOpenSkinModal: () => void;
}

export default function StartOverlay({
  onStartGame,
  currentDiffKey,
  onSelectDifficulty,
  selectedSkin,
  onOpenSkinModal,
}: StartOverlayProps) {
  return (
    <div
      id="start-overlay"
      className="absolute inset-0 bg-slate-950/85 backdrop-blur-md flex flex-col items-center justify-center p-4 sm:p-6 text-center z-20 overflow-y-auto"
    >
      <div className="max-w-xl w-full flex flex-col items-center">
        {/* Title */}
        <div className="flex items-center gap-3 text-3xl sm:text-5xl font-black text-amber-400 mb-2 pixel-font tracking-tight drop-shadow-md">
          <span className="text-4xl sm:text-5xl">{selectedSkin.emoji}</span>
          <span>DINO RUNNER</span>
        </div>
        <p className="text-slate-300 text-xs sm:text-sm mb-4 max-w-md">
          크롬 공룡 아케이드 스타일의 질주! 장애물을 뛰어넘고 황금알과 파워업을 수집해 최고 기록에 도전하세요.
        </p>

        {/* Feature Badges with Generated Assets Showcase */}
        <div className="flex items-center justify-center gap-3 sm:gap-4 mb-5 p-2 rounded-2xl bg-slate-900/70 border border-slate-800 shadow-inner">
          <div className="flex items-center gap-1.5 text-xs text-amber-300 font-semibold px-2 py-1 bg-amber-500/10 rounded-lg border border-amber-500/20">
            <img
              src={assetUrls.goldenEgg}
              alt="황금 공룡 알"
              referrerPolicy="no-referrer"
              className="w-5 h-5 rounded object-cover shadow-sm"
            />
            <span>황금알 보너스</span>
          </div>

          <div className="flex items-center gap-1.5 text-xs text-purple-300 font-semibold px-2 py-1 bg-purple-500/10 rounded-lg border border-purple-500/20">
            <img
              src={assetUrls.pterodactyl}
              alt="익룡 장애물"
              referrerPolicy="no-referrer"
              className="w-5 h-5 rounded object-cover shadow-sm"
            />
            <span>익룡 &amp; 선인장</span>
          </div>

          <div className="flex items-center gap-1.5 text-xs text-blue-300 font-semibold px-2 py-1 bg-blue-500/10 rounded-lg border border-blue-500/20">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            <span>2단점프 &amp; 실드</span>
          </div>
        </div>

        {/* Difficulty Selection */}
        <div className="mb-4 w-full max-w-md">
          <div className="text-[11px] text-slate-400 mb-2 font-bold uppercase tracking-widest text-left sm:text-center">
            난이도 선택
          </div>
          <div className="grid grid-cols-3 gap-2 sm:gap-3">
            {(Object.keys(DIFFICULTIES) as DifficultyKey[]).map((key) => {
              const diff: DifficultyConfig = DIFFICULTIES[key];
              const isSelected = currentDiffKey === key;
              return (
                <button
                  key={key}
                  type="button"
                  id={`start-diff-${key}`}
                  onClick={() => onSelectDifficulty(key)}
                  className={`py-2 px-1 rounded-xl border-2 transition font-bold text-xs sm:text-sm cursor-pointer ${
                    isSelected
                      ? 'border-amber-400 bg-amber-500/20 text-amber-300 shadow-md scale-102'
                      : 'border-slate-700 bg-slate-900/80 text-slate-400 hover:border-slate-600 hover:text-slate-200'
                  }`}
                >
                  <div>{diff.name}</div>
                  <div className="text-[10px] font-normal opacity-80 mt-0.5">
                    속도 {diff.speedMult}x / 점수 {diff.scoreMult}x
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Skin Preview Button & Controls Info */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 w-full max-w-md mb-5 p-3 rounded-xl bg-slate-900/60 border border-slate-800 text-xs text-slate-300">
          <button
            type="button"
            id="skin-preview-btn"
            onClick={onOpenSkinModal}
            className="flex items-center gap-2 hover:bg-slate-800 p-1.5 rounded-lg transition text-left cursor-pointer group"
          >
            <span className="text-2xl group-hover:scale-110 transition-transform">{selectedSkin.emoji}</span>
            <div>
              <div className="font-bold text-amber-300 flex items-center gap-1">
                <span>{selectedSkin.name}</span>
                <Palette className="w-3 h-3 opacity-70" />
              </div>
              <div className="text-[10px] text-slate-400">클릭하여 스킨 변경</div>
            </div>
          </button>

          <div className="text-[11px] text-slate-400 flex flex-col items-start sm:items-end gap-1">
            <div className="flex items-center gap-1.5">
              <Keyboard className="w-3.5 h-3.5 text-amber-400" />
              <span>Space / ↑ 점프 | ↓ 엎드리기</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Smartphone className="w-3.5 h-3.5 text-blue-400" />
              <span>화면 하단 터치 버튼 지원</span>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-3">
          <button
            type="button"
            id="start-game-btn"
            onClick={onStartGame}
            className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 active:scale-95 text-slate-950 font-black px-8 py-3 rounded-xl text-base sm:text-lg shadow-lg shadow-orange-500/20 transition-all flex items-center gap-2 cursor-pointer"
          >
            <Play className="w-5 h-5 fill-slate-950" />
            <span>게임 시작</span>
          </button>

          <button
            type="button"
            id="skin-modal-btn"
            onClick={onOpenSkinModal}
            className="bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-200 font-bold px-4 py-3 rounded-xl text-sm border border-slate-700 shadow transition flex items-center gap-1.5 cursor-pointer"
          >
            <Palette className="w-4 h-4 text-amber-400" />
            <span>스킨</span>
          </button>
        </div>
      </div>
    </div>
  );
}
