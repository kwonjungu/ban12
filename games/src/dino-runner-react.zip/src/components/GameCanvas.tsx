import { useEffect, useRef } from 'react';
import {
  DifficultyConfig,
  DinoState,
  FloatingTextEntity,
  ItemSubType,
  ObstacleEntity,
  ParticleEntity,
  SkinConfig,
} from '../types';
import {
  GAME_HEIGHT,
  GAME_WIDTH,
  GROUND_Y,
  DINO_SPRITE_CRASH,
  DINO_SPRITE_DUCK1,
  DINO_SPRITE_DUCK2,
  DINO_SPRITE_RUN1,
  DINO_SPRITE_RUN2,
} from '../data';
import { soundManager } from '../utils/sound';
import { loadGameAssets } from '../utils/assets';

interface GameCanvasProps {
  isPlaying: boolean;
  isGameOver: boolean;
  difficulty: DifficultyConfig;
  selectedSkin: SkinConfig;
  score: number;
  onScoreUpdate: (newScore: number) => void;
  comboCount: number;
  onComboUpdate: (newCombo: number) => void;
  onGameOver: (finalScore: number) => void;
  dinoStateRef: React.MutableRefObject<DinoState>;
}

export default function GameCanvas({
  isPlaying,
  isGameOver,
  difficulty,
  selectedSkin,
  score,
  onScoreUpdate,
  comboCount,
  onComboUpdate,
  onGameOver,
  dinoStateRef,
}: GameCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Mutable game loop state
  const stateRef = useRef({
    score: 0,
    combo: 0,
    gameSpeed: 6,
    frameCount: 0,
    bgScrollX: 0,
    dayNightTimer: 0,
    nightProgress: 0,
    screenShake: 0,
    lastMilestone: 0,
    obstacles: [] as ObstacleEntity[],
    particles: [] as ParticleEntity[],
    floatingTexts: [] as FloatingTextEntity[],
    nextObstacleFrame: 60,
    nextItemFrame: 100,
  });

  // Sync incoming score/combo on start
  useEffect(() => {
    if (!isPlaying) {
      stateRef.current.score = 0;
      stateRef.current.combo = 0;
      stateRef.current.frameCount = 0;
      stateRef.current.bgScrollX = 0;
      stateRef.current.dayNightTimer = 0;
      stateRef.current.nightProgress = 0;
      stateRef.current.obstacles = [];
      stateRef.current.particles = [];
      stateRef.current.floatingTexts = [];
      stateRef.current.lastMilestone = 0;
      stateRef.current.nextObstacleFrame = 50;
      stateRef.current.nextItemFrame = 90;
    }
  }, [isPlaying]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const assets = loadGameAssets();
    let animationId: number;

    const spawnObstacle = () => {
      const s = stateRef.current;
      const currentScore = s.score;
      const canSpawnPtero = currentScore >= 80 && Math.random() < 0.45;

      if (!canSpawnPtero) {
        // Cactus cluster (1, 2, or 3)
        const count = Math.min(3, Math.floor(Math.random() * (currentScore > 200 ? 3 : 2)) + 1);
        const cactusWidth = 26 * count + (count - 1) * 4;
        const cactusHeight = 46 + Math.random() * 12;

        s.obstacles.push({
          type: 'cactus',
          x: GAME_WIDTH + 30,
          y: GROUND_Y,
          width: cactusWidth,
          height: cactusHeight,
          count: count,
        });
      } else {
        // Pterodactyl flying heights
        const heights = [GROUND_Y - 24, GROUND_Y - 60, GROUND_Y - 95];
        const flyY = heights[Math.floor(Math.random() * heights.length)];

        s.obstacles.push({
          type: 'ptero',
          x: GAME_WIDTH + 30,
          y: flyY,
          width: 46,
          height: 34,
          wingState: 0,
        });
      }
    };

    const spawnItem = () => {
      const s = stateRef.current;
      const rand = Math.random();
      let subType: ItemSubType = 'coin';

      if (rand < 0.25) {
        subType = 'golden_egg'; // High value rare collectible
      } else if (rand < 0.5) {
        subType = 'coin';
      } else {
        const buffs: ItemSubType[] = ['shield', 'doubleJump', 'slowMo', 'magnet'];
        subType = buffs[Math.floor(Math.random() * buffs.length)];
      }

      s.obstacles.push({
        type: 'item',
        subType: subType,
        x: GAME_WIDTH + 30,
        y: GROUND_Y - 45 - Math.random() * 70,
        width: subType === 'golden_egg' ? 40 : 34,
        height: subType === 'golden_egg' ? 40 : 34,
      });
    };

    const addDust = (x: number, y: number) => {
      for (let i = 0; i < 5; i++) {
        stateRef.current.particles.push({
          x: x,
          y: y,
          vx: (Math.random() - 0.5) * 3,
          vy: -Math.random() * 2,
          radius: Math.random() * 2.5 + 1.5,
          color: '#94a3b8',
          alpha: 0.8,
          life: 18,
        });
      }
    };

    const addFloatingText = (x: number, y: number, text: string, color = '#f59e0b') => {
      stateRef.current.floatingTexts.push({
        x,
        y,
        text,
        color,
        alpha: 1.0,
        vy: -1.6,
      });
    };

    // Main Game Loop
    const loop = () => {
      const s = stateRef.current;
      const dino = dinoStateRef.current;

      if (isPlaying && !isGameOver) {
        s.frameCount++;
        s.dayNightTimer = (s.dayNightTimer + 1) % 2000;
        const isNight = s.dayNightTimer > 1000;

        if (isNight) {
          s.nightProgress = Math.min(1, s.nightProgress + 0.015);
        } else {
          s.nightProgress = Math.max(0, s.nightProgress - 0.015);
        }

        // Base speed scale
        const baseSpeed = (6.2 + Math.floor(s.score / 120) * 0.7) * difficulty.speedMult;
        s.gameSpeed = dino.slowMotionTimer > 0 ? baseSpeed * 0.55 : baseSpeed;

        // Background scroll
        s.bgScrollX = (s.bgScrollX + s.gameSpeed * 0.35) % GAME_WIDTH;

        // Score tick
        s.score += 0.15 * difficulty.scoreMult;
        onScoreUpdate(s.score);

        // 100-point milestone chime
        const currentMilestone = Math.floor(s.score / 100);
        if (currentMilestone > s.lastMilestone) {
          s.lastMilestone = currentMilestone;
          soundManager.playMilestone();
          s.screenShake = 4;
          addFloatingText(dino.x + 20, dino.y - 65, `${currentMilestone * 100} PTS!`, '#fbbf24');
        }

        // Update Dino Physics
        dino.vy += dino.gravity;
        dino.y += dino.vy;

        if (dino.y >= GROUND_Y) {
          if (!dino.isGrounded) {
            addDust(dino.x + dino.width / 2, GROUND_Y);
          }
          dino.y = GROUND_Y;
          dino.vy = 0;
          dino.isGrounded = true;
        }

        if (dino.isGrounded) {
          dino.legCycle = (dino.legCycle + 0.28) % (Math.PI * 2);
          dino.tailWag = Math.sin(s.frameCount * 0.22) * 3;
        } else {
          dino.tailWag = -4;
        }

        // Timers
        if (dino.slowMotionTimer > 0) dino.slowMotionTimer--;
        if (dino.magnetTimer > 0) dino.magnetTimer--;

        // Skin particle trails
        if (selectedSkin.id === 'dragon' && Math.random() < 0.4) {
          s.particles.push({
            x: dino.x + 4,
            y: dino.y - dino.height / 2 + (Math.random() - 0.5) * 12,
            vx: -s.gameSpeed * 0.35 - Math.random() * 2,
            vy: (Math.random() - 0.5) * 1.5,
            radius: Math.random() * 3 + 1,
            color: Math.random() < 0.5 ? '#f97316' : '#fde047',
            alpha: 0.9,
            life: 14,
          });
        } else if (selectedSkin.id === 'cyber' && Math.random() < 0.35) {
          s.particles.push({
            x: dino.x + 8,
            y: dino.y - dino.height / 2,
            vx: -s.gameSpeed * 0.4,
            vy: (Math.random() - 0.5) * 1.5,
            radius: Math.random() * 2.5 + 1,
            color: '#38bdf8',
            alpha: 0.85,
            life: 12,
          });
        }

        // Obstacle Spawner
        if (s.frameCount >= s.nextObstacleFrame) {
          spawnObstacle();
          const minGap = Math.max(38, 85 - Math.floor(s.score / 60));
          s.nextObstacleFrame = s.frameCount + minGap + Math.floor(Math.random() * 35);
        }

        // Item Spawner
        if (s.frameCount >= s.nextItemFrame) {
          spawnItem();
          s.nextItemFrame = s.frameCount + 130 + Math.floor(Math.random() * 110);
        }

        // Obstacles & Items Processing
        for (let i = s.obstacles.length - 1; i >= 0; i--) {
          const obs = s.obstacles[i];

          // Magnet suction for coins and golden eggs
          if (
            dino.magnetTimer > 0 &&
            obs.type === 'item' &&
            (obs.subType === 'coin' || obs.subType === 'golden_egg')
          ) {
            const dx = dino.x + dino.width / 2 - (obs.x + obs.width / 2);
            const dy = dino.y - dino.height / 2 - (obs.y - obs.height / 2);
            const dist = Math.hypot(dx, dy);
            if (dist < 280) {
              obs.x += (dx / dist) * 13;
              obs.y += (dy / dist) * 13;
            } else {
              obs.x -= s.gameSpeed;
            }
          } else {
            obs.x -= s.gameSpeed;
          }

          if (obs.type === 'ptero' && obs.wingState !== undefined) {
            obs.wingState = (obs.wingState + 0.18) % (Math.PI * 2);
          }

          // AABB Hitbox Calculation
          const dinoLeft = dino.x + 8;
          const dinoRight = dino.x + dino.width - 8;
          const dinoTop = dino.y - dino.height + 4;
          const dinoBottom = dino.y - 2;

          let obsLeft = obs.x + 5;
          let obsRight = obs.x + obs.width - 5;
          let obsTop = obs.y - obs.height + 4;
          let obsBottom = obs.y;

          if (obs.type === 'item') {
            obsLeft = obs.x;
            obsRight = obs.x + obs.width;
            obsTop = obs.y - obs.height;
            obsBottom = obs.y;
          }

          const hasCollision = !(
            dinoRight < obsLeft ||
            dinoLeft > obsRight ||
            dinoBottom < obsTop ||
            dinoTop > obsBottom
          );

          if (hasCollision) {
            if (obs.type === 'item') {
              // Collected Item
              if (obs.subType === 'golden_egg') {
                s.combo += 2;
                onComboUpdate(s.combo);
                const comboMult = Math.min(5, 1 + Math.floor(s.combo / 3));
                const pts = Math.round(150 * comboMult * difficulty.scoreMult);
                s.score += pts;
                soundManager.playPowerup();
                addFloatingText(obs.x, obs.y, `🥚 황금알 +${pts}!`, '#fbbf24');
              } else if (obs.subType === 'coin') {
                s.combo++;
                onComboUpdate(s.combo);
                const comboMult = Math.min(5, 1 + Math.floor(s.combo / 3));
                const pts = Math.round(40 * comboMult * difficulty.scoreMult);
                s.score += pts;
                soundManager.playCoin();
                addFloatingText(obs.x, obs.y, `+${pts}`, '#f59e0b');
              } else if (obs.subType === 'shield') {
                dino.hasShield = true;
                soundManager.playPowerup();
                addFloatingText(obs.x, obs.y, '🛡️ 실드 활성화!', '#3b82f6');
              } else if (obs.subType === 'doubleJump') {
                dino.doubleJumpLevel = Math.min(2, dino.doubleJumpLevel + 1);
                soundManager.playPowerup();
                if (dino.doubleJumpLevel >= 2) {
                  addFloatingText(obs.x, obs.y, '🔥 슈퍼점프 Lv.2!', '#f59e0b');
                } else {
                  addFloatingText(obs.x, obs.y, '⚡ 2단 점프 획득!', '#a855f7');
                }
              } else if (obs.subType === 'slowMo') {
                dino.slowMotionTimer = 320;
                soundManager.playPowerup();
                addFloatingText(obs.x, obs.y, '⏳ 슬로우 타임!', '#10b981');
              } else if (obs.subType === 'magnet') {
                dino.magnetTimer = 380;
                soundManager.playPowerup();
                addFloatingText(obs.x, obs.y, '🧲 코인 자석!', '#ef4444');
              }
              s.obstacles.splice(i, 1);
            } else {
              // Hit obstacle (cactus or pterodactyl)
              if (dino.hasShield) {
                dino.hasShield = false;
                soundManager.playHit();
                s.screenShake = 10;
                addFloatingText(dino.x, dino.y - 45, '실드 파괴 방어!', '#ef4444');
                s.obstacles.splice(i, 1);
              } else {
                // Game Over Trigger
                soundManager.playHit();
                s.screenShake = 12;
                onGameOver(s.score);
                return;
              }
            }
          }

          // Off-screen cleanup
          if (obs.x + obs.width < -40) {
            s.obstacles.splice(i, 1);
          }
        }

        // Particle updates
        for (let i = s.particles.length - 1; i >= 0; i--) {
          const p = s.particles[i];
          p.x += p.vx;
          p.y += p.vy;
          p.alpha -= 0.045;
          p.life--;
          if (p.life <= 0 || p.alpha <= 0) s.particles.splice(i, 1);
        }

        // Floating texts
        for (let i = s.floatingTexts.length - 1; i >= 0; i--) {
          const ft = s.floatingTexts[i];
          ft.y += ft.vy;
          ft.alpha -= 0.022;
          if (ft.alpha <= 0) s.floatingTexts.splice(i, 1);
        }
      }

      // ================= DRAWING SECTION =================
      ctx.save();

      // Screen Shake
      if (s.screenShake > 0) {
        const shakeX = (Math.random() - 0.5) * s.screenShake;
        const shakeY = (Math.random() - 0.5) * s.screenShake;
        ctx.translate(shakeX, shakeY);
        s.screenShake--;
      }

      // Sky Background interpolation
      const dayR = 248, dayG = 250, dayB = 252;
      const nightR = 15, nightG = 23, nightB = 42;
      const bgR = Math.round(dayR + (nightR - dayR) * s.nightProgress);
      const bgG = Math.round(dayG + (nightG - dayG) * s.nightProgress);
      const bgB = Math.round(dayB + (nightB - dayB) * s.nightProgress);

      ctx.fillStyle = `rgb(${bgR}, ${bgG}, ${bgB})`;
      ctx.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT);

      // Parallax Desert Horizon using Generated Image
      if (assets.background.complete && assets.background.naturalWidth > 0) {
        ctx.save();
        ctx.globalAlpha = 0.45 + (1 - s.nightProgress) * 0.45;

        // Render tiled panorama
        const bgWidth = GAME_WIDTH;
        const bgHeight = 220;
        const bgY = GROUND_Y - bgHeight + 20;

        const offsetX = s.bgScrollX;
        ctx.drawImage(assets.background, -offsetX, bgY, bgWidth, bgHeight);
        ctx.drawImage(assets.background, bgWidth - offsetX, bgY, bgWidth, bgHeight);
        ctx.restore();
      }

      // Night Celestial Bodies (Moon & Stars)
      if (s.nightProgress > 0.15) {
        ctx.save();
        ctx.globalAlpha = s.nightProgress;
        ctx.fillStyle = '#fef08a';
        ctx.beginPath();
        ctx.arc(710, 65, 18, 0, Math.PI * 2);
        ctx.fill();

        // Moon crescent cutout
        ctx.fillStyle = `rgb(${bgR}, ${bgG}, ${bgB})`;
        ctx.beginPath();
        ctx.arc(703, 62, 16, 0, Math.PI * 2);
        ctx.fill();

        // Stars
        ctx.fillStyle = '#ffffff';
        const starPoints = [
          [120, 50], [240, 80], [380, 45], [510, 75], [630, 35], [760, 95]
        ];
        starPoints.forEach(([sx, sy]) => {
          ctx.fillRect(sx, sy, 2, 2);
        });
        ctx.restore();
      }

      // Retro Ground Line & Pebbles
      ctx.strokeStyle = s.nightProgress > 0.5 ? '#475569' : '#cbd5e1';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.moveTo(0, GROUND_Y);
      ctx.lineTo(GAME_WIDTH, GROUND_Y);
      ctx.stroke();

      // Ground bumps & speckles
      ctx.fillStyle = s.nightProgress > 0.5 ? '#334155' : '#94a3b8';
      for (let x = 10; x < GAME_WIDTH; x += 45) {
        const offset = (x - s.bgScrollX * 1.5 + GAME_WIDTH * 10) % GAME_WIDTH;
        ctx.fillRect(offset, GROUND_Y + 4, 3, 2);
        if (x % 90 === 0) {
          ctx.fillRect(offset + 12, GROUND_Y + 7, 5, 2);
        }
      }

      // Render Obstacles
      for (const obs of s.obstacles) {
        if (obs.type === 'cactus') {
          // Draw cactus sprite if loaded or pixel cactus
          if (assets.cactus.complete && assets.cactus.naturalWidth > 0 && obs.count === 1) {
            ctx.drawImage(assets.cactus, obs.x, GROUND_Y - obs.height, obs.width, obs.height);
          } else {
            // Retro multi-cactus cluster
            const count = obs.count || 1;
            const col = s.nightProgress > 0.5 ? '#059669' : '#10b981';
            ctx.fillStyle = col;

            for (let c = 0; c < count; c++) {
              const cx = obs.x + c * 26;
              const h = obs.height - (c % 2) * 6;
              // Main trunk
              ctx.fillRect(cx + 6, GROUND_Y - h, 14, h);
              // Left arm
              ctx.fillRect(cx, GROUND_Y - h * 0.72, 8, 6);
              ctx.fillRect(cx, GROUND_Y - h * 0.72 - 10, 6, 10);
              // Right arm
              ctx.fillRect(cx + 18, GROUND_Y - h * 0.58, 8, 6);
              ctx.fillRect(cx + 20, GROUND_Y - h * 0.58 - 10, 6, 10);
            }
          }
        } else if (obs.type === 'ptero') {
          // Pterodactyl flying dinosaur
          if (assets.pterodactyl.complete && assets.pterodactyl.naturalWidth > 0) {
            ctx.save();
            const wingOffset = Math.sin(obs.wingState || 0) * 4;
            ctx.drawImage(
              assets.pterodactyl,
              obs.x,
              obs.y - obs.height + wingOffset,
              obs.width,
              obs.height
            );
            ctx.restore();
          } else {
            ctx.save();
            ctx.fillStyle = s.nightProgress > 0.5 ? '#c084fc' : '#9333ea';
            const wingOffset = Math.sin(obs.wingState || 0) * 8;
            // Body
            ctx.fillRect(obs.x + 10, obs.y - 14, 24, 12);
            // Beak / Head
            ctx.fillRect(obs.x + 32, obs.y - 18, 14, 8);
            // Flapping Wings
            ctx.fillRect(obs.x + 14, obs.y - 14 - wingOffset, 12, wingOffset);
            ctx.restore();
          }
        } else if (obs.type === 'item') {
          // Item Collectibles
          ctx.save();
          const floatY = Math.sin(s.frameCount * 0.15 + obs.x * 0.05) * 3;

          if (obs.subType === 'golden_egg') {
            // Golden Dino Egg Collectible with glowing aura
            ctx.shadowColor = '#fbbf24';
            ctx.shadowBlur = 10;
            if (assets.goldenEgg.complete && assets.goldenEgg.naturalWidth > 0) {
              ctx.drawImage(
                assets.goldenEgg,
                obs.x,
                obs.y - obs.height + floatY,
                obs.width,
                obs.height
              );
            } else {
              // Fallback shiny egg
              ctx.fillStyle = '#f59e0b';
              ctx.beginPath();
              ctx.ellipse(
                obs.x + obs.width / 2,
                obs.y - obs.height / 2 + floatY,
                14,
                18,
                0,
                0,
                Math.PI * 2
              );
              ctx.fill();
            }
          } else if (obs.subType === 'coin') {
            // Gold Coin
            ctx.fillStyle = '#f59e0b';
            ctx.beginPath();
            ctx.arc(
              obs.x + obs.width / 2,
              obs.y - obs.height / 2 + floatY,
              14,
              0,
              Math.PI * 2
            );
            ctx.fill();

            ctx.fillStyle = '#fef08a';
            ctx.beginPath();
            ctx.arc(
              obs.x + obs.width / 2,
              obs.y - obs.height / 2 + floatY,
              9,
              0,
              Math.PI * 2
            );
            ctx.fill();
          } else {
            // Powerup badges
            const powerIcons: Record<string, { bg: string; text: string }> = {
              shield: { bg: '#3b82f6', text: '🛡️' },
              doubleJump: { bg: '#a855f7', text: '⚡' },
              slowMo: { bg: '#10b981', text: '⏳' },
              magnet: { bg: '#ef4444', text: '🧲' },
            };
            const itemConf = powerIcons[obs.subType || 'shield'] || { bg: '#f59e0b', text: '⭐' };

            ctx.fillStyle = itemConf.bg;
            ctx.beginPath();
            ctx.arc(
              obs.x + obs.width / 2,
              obs.y - obs.height / 2 + floatY,
              15,
              0,
              Math.PI * 2
            );
            ctx.fill();

            ctx.font = '16px sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(itemConf.text, obs.x + obs.width / 2, obs.y - obs.height / 2 + floatY);
          }
          ctx.restore();
        }
      }

      // Draw Dino Character
      ctx.save();
      ctx.translate(dino.x, dino.y - dino.height);

      // Determine Sprite Matrix
      let spriteMatrix = DINO_SPRITE_RUN1;
      const isAltFrame = Math.floor(s.frameCount / 6) % 2 === 0;

      if (isGameOver) {
        spriteMatrix = DINO_SPRITE_CRASH;
      } else if (dino.isDucking) {
        spriteMatrix = isAltFrame ? DINO_SPRITE_DUCK1 : DINO_SPRITE_DUCK2;
      } else if (!dino.isGrounded) {
        spriteMatrix = DINO_SPRITE_RUN1;
      } else {
        spriteMatrix = isAltFrame ? DINO_SPRITE_RUN1 : DINO_SPRITE_RUN2;
      }

      const rows = spriteMatrix.length;
      const cols = spriteMatrix[0].length;
      const pixelSize = Math.min(dino.width / cols, dino.height / rows);

      for (let r = 0; r < rows; r++) {
        const rowStr = spriteMatrix[r];
        for (let c = 0; c < rowStr.length; c++) {
          if (rowStr[c] === '█') {
            ctx.fillStyle = selectedSkin.mainColor;
            ctx.fillRect(
              c * pixelSize,
              r * pixelSize,
              Math.ceil(pixelSize),
              Math.ceil(pixelSize)
            );
          }
        }
      }

      // Active Buff Visual Glows on Dino
      if (dino.hasShield) {
        ctx.strokeStyle = '#3b82f6';
        ctx.lineWidth = 3.5;
        ctx.beginPath();
        ctx.arc(dino.width / 2, dino.height / 2, dino.height * 0.65, 0, Math.PI * 2);
        ctx.stroke();
      }

      if (dino.doubleJumpLevel >= 2) {
        ctx.strokeStyle = '#f59e0b';
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.arc(dino.width / 2, dino.height / 2, dino.height * 0.72, 0, Math.PI * 2);
        ctx.stroke();
      }

      if (dino.magnetTimer > 0) {
        ctx.strokeStyle = '#ef4444';
        ctx.lineWidth = 2;
        ctx.setLineDash([4, 4]);
        ctx.beginPath();
        ctx.arc(dino.width / 2, dino.height / 2, dino.height * 0.8, 0, Math.PI * 2);
        ctx.stroke();
        ctx.setLineDash([]);
      }

      ctx.restore();

      // Draw Particles
      for (const p of s.particles) {
        ctx.fillStyle = p.color;
        ctx.globalAlpha = Math.max(0, p.alpha);
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1.0;

      // Draw Floating Texts
      for (const ft of s.floatingTexts) {
        ctx.fillStyle = ft.color;
        ctx.globalAlpha = Math.max(0, ft.alpha);
        ctx.font = 'bold 14px Pretendard, sans-serif';
        ctx.fillText(ft.text, ft.x, ft.y);
      }
      ctx.globalAlpha = 1.0;

      ctx.restore();

      animationId = requestAnimationFrame(loop);
    };

    animationId = requestAnimationFrame(loop);

    return () => {
      cancelAnimationFrame(animationId);
    };
  }, [isPlaying, isGameOver, difficulty, selectedSkin, onScoreUpdate, onComboUpdate, onGameOver, dinoStateRef]);

  // Keep internal canvas coordinate resolution fixed at 800x450
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.width = GAME_WIDTH;
    canvas.height = GAME_HEIGHT;
  }, []);

  return (
    <div ref={containerRef} className="relative w-full h-full flex items-center justify-center">
      <canvas
        id="dino-game-canvas"
        ref={canvasRef}
        className="w-full h-full object-contain block rounded-2xl"
        style={{ imageRendering: 'pixelated' }}
      />
    </div>
  );
}
