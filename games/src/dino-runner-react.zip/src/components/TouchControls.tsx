import { ArrowDown, ArrowUp } from 'lucide-react';

interface TouchControlsProps {
  onJump: () => void;
  onDuckStart: () => void;
  onDuckEnd: () => void;
}

export default function TouchControls({
  onJump,
  onDuckStart,
  onDuckEnd,
}: TouchControlsProps) {
  return (
    <div
      id="touch-controls-bar"
      className="flex sm:hidden h-16 bg-slate-900 border-t border-slate-800 text-slate-300 select-none z-10 shrink-0"
    >
      <button
        type="button"
        id="touch-duck-btn"
        onTouchStart={(e) => {
          e.preventDefault();
          onDuckStart();
        }}
        onTouchEnd={(e) => {
          e.preventDefault();
          onDuckEnd();
        }}
        onMouseDown={onDuckStart}
        onMouseUp={onDuckEnd}
        className="flex-1 bg-slate-800/90 active:bg-slate-700 flex items-center justify-center font-bold text-sm gap-2 border-r border-slate-700 transition cursor-pointer select-none"
      >
        <ArrowDown className="w-5 h-5 text-amber-400" />
        <span>엎드리기 (Duck)</span>
      </button>

      <button
        type="button"
        id="touch-jump-btn"
        onTouchStart={(e) => {
          e.preventDefault();
          onJump();
        }}
        onClick={onJump}
        className="flex-1 bg-amber-500/20 active:bg-amber-500/40 text-amber-300 flex items-center justify-center font-bold text-sm gap-2 transition cursor-pointer select-none"
      >
        <ArrowUp className="w-5 h-5 text-amber-400" />
        <span>점프 (Jump)</span>
      </button>
    </div>
  );
}
