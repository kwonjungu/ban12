import { Volume2, VolumeX, Flame, Shield, Zap, Hourglass, Magnet, Palette } from 'lucide-react';
import { DifficultyConfig, DinoState } from '../types';

interface GameHUDProps {
  score: number;
  highScore: number;
  comboCount: number;
  difficulty: DifficultyConfig;
  dino: DinoState;
  soundMuted: boolean;
  onToggleSound: () => void;
  onOpenSkinModal: () => void;
  isPlaying: boolean;
}

export default function GameHUD({
  score,
  highScore,
  comboCount,
  difficulty,
  dino,
  soundMuted,
  onToggleSound,
  onOpenSkinModal,
  isPlaying,
}: GameHUDProps) {
  const roundedScore = Math.floor(score);
  const formattedScore = String(roundedScore).padStart(5, '0');
  const formattedHighScore = String(highScore).padStart(5, '0');
  const comboMultiplier = Math.min(5, 1 + Math.floor(comboCount / 3));

  return (
    <header className="absolute top-0 left-0 w-full p-3 sm:p-4 flex justify-between items-center z-10 pointer-events-none">
      {/* Left side: Difficulty & Active Powerups */}
      <div className="flex items-center gap-2 pointer-events-auto">
        <span
          className={`px-2.5 py-1 rounded-full text-xs font-bold shadow-md uppercase tracking-wider border ${difficulty.badgeClass}`}
        >
          {difficulty.name} (x{difficulty.scoreMult.toFixed(1)})
        </span>

        {/* Buff tags */}
        <div className="flex items-center gap-1.5 flex-wrap">
          {dino.hasShield && (
            <span className="flex items-center gap-1 bg-blue-500/80 text-white text-[11px] px-2 py-0.5 rounded-md border border-blue-400/50 shadow-sm animate-pulse">
              <Shield className="w-3 h-3" />
              <span>실드</span>
            </span>
          )}
          {dino.doubleJumpLevel === 1 && (
            <span className="flex items-center gap-1 bg-purple-500/80 text-white text-[11px] px-2 py-0.5 rounded-md border border-purple-400/50 shadow-sm">
              <Zap className="w-3 h-3" />
              <span>2단점프</span>
            </span>
          )}
          {dino.doubleJumpLevel >= 2 && (
            <span className="flex items-center gap-1 bg-amber-500/90 text-slate-950 font-bold text-[11px] px-2 py-0.5 rounded-md border border-amber-300/80 shadow-md animate-bounce">
              <Zap className="w-3 h-3" />
              <span>슈퍼점프 Lv.2</span>
            </span>
          )}
          {dino.slowMotionTimer > 0 && (
            <span className="flex items-center gap-1 bg-emerald-500/80 text-white text-[11px] px-2 py-0.5 rounded-md border border-emerald-400/50 shadow-sm">
              <Hourglass className="w-3 h-3 animate-spin" style={{ animationDuration: '4s' }} />
              <span>슬로우</span>
            </span>
          )}
          {dino.magnetTimer > 0 && (
            <span className="flex items-center gap-1 bg-rose-500/80 text-white text-[11px] px-2 py-0.5 rounded-md border border-rose-400/50 shadow-sm">
              <Magnet className="w-3 h-3 animate-pulse" />
              <span>자석</span>
            </span>
          )}
        </div>
      </div>

      {/* Right side: Combo, Score & Control Buttons */}
      <div className="flex items-center gap-2 sm:gap-3 pointer-events-auto">
        {comboCount > 1 && (
          <div className="flex items-center gap-1 bg-amber-500/20 border border-amber-500/50 text-amber-300 px-2 sm:px-2.5 py-0.5 rounded-lg text-xs font-bold animate-pulse shadow-sm">
            <Flame className="w-3.5 h-3.5 text-amber-400" />
            <span>x{comboMultiplier} 콤보</span>
          </div>
        )}

        <div className="text-right">
          <div className="text-[11px] font-mono tracking-widest text-slate-400 dark:text-slate-400">
            HI <span className="font-semibold">{formattedHighScore}</span>
          </div>
          <div className="text-lg sm:text-xl font-bold pixel-font tracking-widest text-amber-400 drop-shadow">
            {formattedScore}
          </div>
        </div>

        <div className="flex items-center gap-1">
          <button
            type="button"
            id="sound-toggle-btn"
            onClick={onToggleSound}
            className="p-1.5 sm:p-2 bg-slate-800/80 hover:bg-slate-700 active:scale-95 border border-slate-700 text-slate-200 rounded-lg shadow transition cursor-pointer"
            title={soundMuted ? '음소거 해제' : '음소거'}
            aria-label="Sound Toggle"
          >
            {soundMuted ? (
              <VolumeX className="w-4 h-4 text-rose-400" />
            ) : (
              <Volume2 className="w-4 h-4 text-emerald-400" />
            )}
          </button>

          {!isPlaying && (
            <button
              type="button"
              id="skin-toggle-btn"
              onClick={onOpenSkinModal}
              className="p-1.5 sm:p-2 bg-slate-800/80 hover:bg-slate-700 active:scale-95 border border-slate-700 text-amber-400 rounded-lg shadow transition cursor-pointer"
              title="공룡 스킨 선택"
              aria-label="Skin Selector"
            >
              <Palette className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </header>
  );
}
