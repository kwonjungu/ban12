import { RotateCcw, Trophy } from 'lucide-react';
import { DifficultyConfig, DifficultyKey } from '../types';
import { DIFFICULTIES } from '../data';

interface GameOverOverlayProps {
  score: number;
  highScore: number;
  isNewHigh: boolean;
  onRestart: () => void;
  currentDiffKey: DifficultyKey;
  onSelectDifficulty: (key: DifficultyKey) => void;
}

export default function GameOverOverlay({
  score,
  highScore,
  isNewHigh,
  onRestart,
  currentDiffKey,
  onSelectDifficulty,
}: GameOverOverlayProps) {
  const roundedScore = Math.floor(score);

  return (
    <div
      id="game-over-overlay"
      className="absolute inset-0 bg-slate-950/85 backdrop-blur-md flex flex-col items-center justify-center p-4 sm:p-6 text-center z-20 animate-fade-in"
    >
      <div className="max-w-md w-full flex flex-col items-center">
        <div className="text-red-500 text-3xl sm:text-4xl font-black mb-2 pixel-font tracking-tight drop-shadow">
          GAME OVER
        </div>

        {isNewHigh && (
          <div className="flex items-center gap-1.5 bg-amber-500/20 border border-amber-500 text-amber-300 px-3 py-1 rounded-full text-xs font-bold mb-3 animate-bounce">
            <Trophy className="w-4 h-4 text-amber-400" />
            <span>🎉 새로운 최고 기록 달성!</span>
          </div>
        )}

        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 w-full mb-4 shadow-xl">
          <div className="text-xs text-slate-400 uppercase tracking-wider mb-1">최종 점수</div>
          <div className="text-amber-400 text-3xl sm:text-4xl font-black pixel-font tracking-wider mb-2">
            {roundedScore}
          </div>
          <div className="text-xs text-slate-400 font-mono">
            최고 기록: <span className="text-slate-200 font-bold">{highScore}</span>
          </div>
        </div>

        {/* Difficulty Selection for Next Run */}
        <div className="mb-5 w-full">
          <div className="text-[11px] text-slate-400 mb-2 font-bold uppercase tracking-widest">
            다음 판 난이도
          </div>
          <div className="grid grid-cols-3 gap-2">
            {(Object.keys(DIFFICULTIES) as DifficultyKey[]).map((key) => {
              const diff: DifficultyConfig = DIFFICULTIES[key];
              const isSelected = currentDiffKey === key;
              return (
                <button
                  key={key}
                  type="button"
                  id={`go-diff-${key}`}
                  onClick={() => onSelectDifficulty(key)}
                  className={`py-1.5 px-1 rounded-xl border-2 transition font-bold text-xs cursor-pointer ${
                    isSelected
                      ? 'border-amber-400 bg-amber-500/20 text-amber-300 shadow'
                      : 'border-slate-700 bg-slate-800 text-slate-400 hover:border-slate-600 hover:text-slate-200'
                  }`}
                >
                  {diff.name}
                </button>
              );
            })}
          </div>
        </div>

        <button
          type="button"
          id="restart-game-btn"
          onClick={onRestart}
          className="bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 font-black px-8 py-3 rounded-xl text-base shadow-lg shadow-amber-500/20 transition-all flex items-center gap-2 cursor-pointer"
        >
          <RotateCcw className="w-5 h-5" />
          <span>다시 하기 (Space)</span>
        </button>
      </div>
    </div>
  );
}
