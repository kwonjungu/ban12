export type DifficultyKey = 'easy' | 'medium' | 'hard';

export interface DifficultyConfig {
  key: DifficultyKey;
  name: string;
  speedMult: number;
  scoreMult: number;
  badgeClass: string;
}

export interface SkinConfig {
  id: string;
  name: string;
  desc: string;
  mainColor: string;
  bellyColor: string;
  accentColor: string;
  emoji: string;
}

export type ObstacleType = 'cactus' | 'ptero' | 'item';
export type ItemSubType = 'coin' | 'golden_egg' | 'shield' | 'doubleJump' | 'slowMo' | 'magnet';

export interface BaseEntity {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface ObstacleEntity extends BaseEntity {
  type: ObstacleType;
  subType?: ItemSubType;
  count?: number; // for cactus cluster
  wingState?: number; // for pterodactyl flapping
  collected?: boolean;
}

export interface ParticleEntity {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  color: string;
  alpha: number;
  life: number;
}

export interface FloatingTextEntity {
  x: number;
  y: number;
  text: string;
  color: string;
  alpha: number;
  vy: number;
}

export interface DinoState {
  x: number;
  y: number;
  width: number;
  height: number;
  normalHeight: number;
  duckHeight: number;
  vy: number;
  gravity: number;
  jumpForce: number;
  isGrounded: boolean;
  isDucking: boolean;
  hasDoubleJumped: boolean;
  
  // Powerups & timers
  hasShield: boolean;
  doubleJumpLevel: number; // 0, 1, 2
  slowMotionTimer: number;
  magnetTimer: number;
  legCycle: number;
  tailWag: number;
}
