import { LeaderboardEntry } from '../types';

const STORAGE_KEY = 'squid_3d_leaderboard_v1';

const DEFAULT_SCORES: LeaderboardEntry[] = [
  { id: '1', name: '대왕오징어마스터', score: 68, stars: 22, date: '2026.03.18', timestamp: 1773800000000 },
  { id: '2', name: '심해헤엄이🦑', score: 45, stars: 15, date: '2026.03.19', timestamp: 1773880000000 },
  { id: '3', name: '파닥파닥오징어', score: 32, stars: 10, date: '2026.03.20', timestamp: 1773950000000 },
  { id: '4', name: '산호초탐험대', score: 24, stars: 7, date: '2026.03.20', timestamp: 1773960000000 },
  { id: '5', name: '별모으는오징어', score: 18, stars: 9, date: '2026.03.20', timestamp: 1773970000000 },
];

export function getLeaderboard(): LeaderboardEntry[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_SCORES));
      return DEFAULT_SCORES;
    }
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length > 0) {
      return parsed.sort((a, b) => b.score - a.score);
    }
    return DEFAULT_SCORES;
  } catch {
    return DEFAULT_SCORES;
  }
}

export function saveScore(name: string, score: number, stars: number): LeaderboardEntry[] {
  const current = getLeaderboard();
  const newEntry: LeaderboardEntry = {
    id: Date.now().toString() + '-' + Math.random().toString(36).substring(2, 6),
    name: name.trim() || '익명의 오징어',
    score,
    stars,
    date: new Date().toLocaleDateString('ko-KR', { year: 'numeric', month: '2-digit', day: '2-digit' }),
    timestamp: Date.now(),
  };

  const updated = [...current, newEntry].sort((a, b) => b.score - a.score).slice(0, 20);
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  } catch {}
  return updated;
}
