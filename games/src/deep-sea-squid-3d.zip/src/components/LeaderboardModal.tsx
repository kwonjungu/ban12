import React from 'react';
import { LeaderboardEntry } from '../types';
import trophyImg from '../assets/images/squid_gold_trophy_1789882242166.jpg';
import { Trophy, X, RotateCcw, Star } from 'lucide-react';

interface LeaderboardModalProps {
  isOpen: boolean;
  onClose: () => void;
  entries: LeaderboardEntry[];
  onRefresh: () => void;
}

export const LeaderboardModal: React.FC<LeaderboardModalProps> = ({
  isOpen,
  onClose,
  entries,
  onRefresh,
}) => {
  if (!isOpen) return null;

  return (
    <div
      id="leaderboard-modal-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        id="leaderboard-card"
        className="relative w-full max-w-md max-h-[85vh] flex flex-col bg-slate-900 border-2 border-amber-400/60 rounded-3xl p-5 shadow-2xl text-slate-100 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header with Trophy Asset */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-700/80">
          <div className="flex items-center gap-3">
            <img
              src={trophyImg}
              alt="오징어 챔피언 트로피"
              referrerPolicy="no-referrer"
              className="w-11 h-11 rounded-2xl border-2 border-amber-400 shadow-md object-cover"
            />
            <div>
              <h2 className="text-xl font-black text-amber-300 flex items-center gap-1.5">
                전설의 오징어 명예의 전당
              </h2>
              <p className="text-xs text-slate-400">심해의 최고 기록을 달성한 헤엄이들</p>
            </div>
          </div>
          <button
            id="btn-close-leaderboard"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-full hover:bg-slate-800 transition"
            aria-label="닫기"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Scrollable list */}
        <div className="flex-1 overflow-y-auto py-3 space-y-2 pr-1 my-1 min-h-[260px] max-h-[50vh]">
          {entries.length === 0 ? (
            <div className="py-12 text-center text-slate-400 text-sm">
              아직 등록된 기록이 없습니다.<br />
              첫 번째 전설이 되어보세요! 🦑
            </div>
          ) : (
            entries.slice(0, 15).map((entry, idx) => {
              let rankBadge = (
                <span className="w-7 h-7 rounded-full bg-slate-800 text-slate-300 font-black text-xs flex items-center justify-center border border-slate-700">
                  {idx + 1}
                </span>
              );
              let cardStyle = 'bg-slate-800/60 border-slate-700/60';

              if (idx === 0) {
                rankBadge = <span className="text-2xl leading-none">🥇</span>;
                cardStyle = 'bg-amber-500/15 border-amber-400/60 shadow-lg shadow-amber-500/10';
              } else if (idx === 1) {
                rankBadge = <span className="text-2xl leading-none">🥈</span>;
                cardStyle = 'bg-slate-700/50 border-slate-400/50';
              } else if (idx === 2) {
                rankBadge = <span className="text-2xl leading-none">🥉</span>;
                cardStyle = 'bg-amber-700/20 border-amber-600/40';
              }

              return (
                <div
                  key={entry.id || idx}
                  className={`flex items-center justify-between p-3 rounded-2xl border ${cardStyle} transition-transform hover:scale-[1.01]`}
                >
                  <div className="flex items-center gap-3 overflow-hidden">
                    <div className="flex-shrink-0">{rankBadge}</div>
                    <div className="text-left truncate">
                      <div className="font-extrabold text-sm text-white truncate">
                        {entry.name || '익명의 오징어'}
                      </div>
                      <div className="text-[11px] font-medium text-slate-400 flex items-center gap-2">
                        <span className="flex items-center gap-0.5 text-amber-300 font-bold">
                          <Star className="w-3 h-3 fill-amber-300" /> {entry.stars || 0}
                        </span>
                        <span>•</span>
                        <span>{entry.date || '최근'}</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right flex-shrink-0 pl-2">
                    <span className="text-lg font-black text-amber-400">{entry.score || 0}</span>
                    <span className="text-xs font-semibold text-slate-400 ml-0.5">점</span>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-slate-700/80 flex items-center justify-between text-xs text-slate-400 font-medium">
          <span className="flex items-center gap-1">
            <Trophy className="w-3.5 h-3.5 text-amber-400" />
            상위 15명 기록 표시
          </span>
          <button
            id="btn-refresh-leaderboard"
            onClick={onRefresh}
            className="flex items-center gap-1 text-amber-300 hover:text-amber-200 transition font-bold"
          >
            <RotateCcw className="w-3.5 h-3.5" /> 새로고침
          </button>
        </div>
      </div>
    </div>
  );
};
