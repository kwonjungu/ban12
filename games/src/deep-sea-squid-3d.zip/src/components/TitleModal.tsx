import React from 'react';
import heroImg from '../assets/images/squid_hero_title_1789882217935.jpg';
import mascotImg from '../assets/images/squid_mascot_avatar_1789882230711.jpg';
import shieldImg from '../assets/images/squid_shield_bubble_1789882251763.jpg';
import { Play, Trophy, Shield, Star } from 'lucide-react';

interface TitleModalProps {
  isOpen: boolean;
  onStart: () => void;
  onOpenLeaderboard: () => void;
}

export const TitleModal: React.FC<TitleModalProps> = ({
  isOpen,
  onStart,
  onOpenLeaderboard,
}) => {
  if (!isOpen) return null;

  return (
    <div
      id="title-screen-overlay"
      className="fixed inset-0 z-40 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-300"
    >
      <div
        id="title-card"
        className="relative w-full max-w-sm bg-slate-900/95 border-2 border-amber-400/70 rounded-3xl p-4 text-center text-white shadow-2xl flex flex-col items-center overflow-hidden"
      >
        {/* Hero Artwork Image with Mascot Overlay */}
        <div className="relative w-full h-36 rounded-2xl overflow-hidden mb-3 border border-amber-400/40 shadow-lg">
          <img
            src={heroImg}
            alt="3D 심해 오징어 파닥파닥"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover transform hover:scale-105 transition-transform duration-700"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent" />
          
          {/* Mascot Avatar badge */}
          <div className="absolute bottom-2 left-3 flex items-center gap-2">
            <img
              src={mascotImg}
              alt="오징어 마스코트"
              referrerPolicy="no-referrer"
              className="w-10 h-10 rounded-full border-2 border-amber-300 shadow-md object-cover bg-slate-900"
            />
            <div className="text-left">
              <span className="text-[10px] font-bold text-amber-300 uppercase tracking-widest block">3D ACTION GAME</span>
              <span className="text-sm font-black text-white drop-shadow">심해의 귀여운 오징어</span>
            </div>
          </div>
        </div>

        {/* Title */}
        <h1 className="text-2xl font-black text-amber-400 drop-shadow-md tracking-tight">
          3D 심해 오징어 파닥파닥 🦑
        </h1>
        <p className="text-xs text-slate-300 font-semibold mt-1">
          신비로운 심해 속 산호초를 헤엄쳐 통과하세요!
        </p>

        {/* Game Rules Card */}
        <div className="w-full my-3 p-3 bg-slate-800/80 rounded-2xl border border-slate-700/60 text-left space-y-2 text-xs font-medium text-slate-200">
          <div className="flex items-center gap-2.5">
            <span className="w-7 h-7 rounded-xl bg-amber-400/20 text-amber-300 flex items-center justify-center font-bold text-sm">
              👆
            </span>
            <div>
              <b className="text-amber-300">화면 터치/클릭</b> 또는 <b className="text-amber-300">스페이스바</b>로 위로 헤엄!
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <span className="w-7 h-7 rounded-xl bg-rose-500/20 text-rose-300 flex items-center justify-center font-bold text-sm">
              🪸
            </span>
            <div>
              형형색색 <b className="text-rose-300">산호초</b> 사이를 무사히 통과 (<b className="text-amber-300">+1점</b>)
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-xl overflow-hidden border border-sky-400/50 flex-shrink-0">
              <img
                src={shieldImg}
                alt="방패 아이템"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </div>
            <div>
              황금별 획득 시 <b className="text-amber-300">+3점</b> & 3개마다 <b className="text-sky-300">물방울 방패 🛡️</b> 획득!
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="w-full flex gap-2 mt-1">
          <button
            id="btn-start-game"
            onClick={onStart}
            className="flex-1 py-3 px-4 bg-gradient-to-b from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 active:scale-95 text-slate-950 font-black text-sm rounded-2xl shadow-lg border-b-4 border-amber-700 flex items-center justify-center gap-1.5 transition cursor-pointer"
          >
            <Play className="w-4 h-4 fill-slate-950" /> 잠수 시작
          </button>
          <button
            id="btn-open-leaderboard-from-title"
            onClick={onOpenLeaderboard}
            className="py-3 px-4 bg-gradient-to-b from-sky-500 to-sky-600 hover:from-sky-400 hover:to-sky-500 active:scale-95 text-white font-black text-sm rounded-2xl shadow-lg border-b-4 border-sky-800 flex items-center justify-center gap-1.5 transition cursor-pointer"
          >
            <Trophy className="w-4 h-4" /> 점수판
          </button>
        </div>

        <div className="text-[11px] font-bold text-amber-300/80 animate-pulse mt-3">
          화면을 클릭하거나 스페이스바를 누르면 출발! 🌊
        </div>
      </div>
    </div>
  );
};
