import React, { useState } from 'react';
import trophyImg from '../assets/images/squid_gold_trophy_1789882242166.jpg';
import mascotImg from '../assets/images/squid_mascot_avatar_1789882230711.jpg';
import confetti from 'canvas-confetti';
import { RotateCcw, Trophy, CheckCircle, Award } from 'lucide-react';

interface GameOverModalProps {
  isOpen: boolean;
  score: number;
  coralsPassed: number;
  starCount: number;
  timeSurvived: number;
  onRestart: () => void;
  onOpenLeaderboard: () => void;
  onSubmitScore: (name: string) => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  isOpen,
  score,
  coralsPassed,
  starCount,
  timeSurvived,
  onRestart,
  onOpenLeaderboard,
  onSubmitScore,
}) => {
  const [nickname, setNickname] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  if (!isOpen) return null;

  // Medal determination
  let medalTitle = '아기 오징어';
  let medalEmoji = '🦑';
  let medalDesc = '더 깊은 심해로 헤엄쳐보세요!';

  if (score >= 50) {
    medalTitle = '전설의 대왕 오징어';
    medalEmoji = '💎';
    medalDesc = '심해를 정복한 불멸의 전설!';
  } else if (score >= 30) {
    medalTitle = '황금 심해 오징어';
    medalEmoji = '🥇';
    medalDesc = '찬란한 빛을 발하는 심해의 강자!';
  } else if (score >= 15) {
    medalTitle = '은빛 산호 오징어';
    medalEmoji = '🥈';
    medalDesc = '산호초를 능숙하게 헤엄치는 실력자!';
  } else if (score >= 5) {
    medalTitle = '동빛 꼬마 오징어';
    medalEmoji = '🥉';
    medalDesc = '바닷속 탐험을 본격적으로 시작했어요!';
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nickname.trim() || isSubmitted) return;
    onSubmitScore(nickname.trim());
    setIsSubmitted(true);
    try {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.6 },
      });
    } catch {}
  };

  return (
    <div
      id="game-over-overlay"
      className="fixed inset-0 z-40 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-300"
    >
      <div
        id="game-over-card"
        className="relative w-full max-w-sm bg-slate-900/95 border-2 border-rose-500/50 rounded-3xl p-5 text-center text-white shadow-2xl flex flex-col items-center"
      >
        {/* Top Floating Badge with Asset */}
        <div className="relative -mt-12 mb-2 flex items-center justify-center">
          <div className="relative p-1 bg-gradient-to-b from-amber-300 to-amber-600 rounded-2xl shadow-xl shadow-amber-500/20">
            <img
              src={score >= 15 ? trophyImg : mascotImg}
              alt="오징어 결과 엠블럼"
              referrerPolicy="no-referrer"
              className="w-16 h-16 rounded-xl object-cover"
            />
          </div>
        </div>

        <h2 className="text-2xl font-black text-rose-400 tracking-wide">산호에 걸렸다!</h2>
        <div className="flex items-center gap-1.5 mt-1 text-sm font-bold text-amber-300">
          <span className="text-lg">{medalEmoji}</span>
          <span>{medalTitle}</span>
        </div>
        <p className="text-xs text-slate-400 mt-0.5">{medalDesc}</p>

        {/* Score Display Card */}
        <div className="w-full my-3 p-3.5 bg-slate-800/80 rounded-2xl border border-slate-700/60 shadow-inner">
          <div className="text-4xl font-black text-amber-400 tracking-tight">
            {score}
            <span className="text-lg font-bold text-slate-300 ml-1">점</span>
          </div>
          <div className="grid grid-cols-3 gap-2 mt-2 pt-2 border-t border-slate-700/50 text-[11px] font-bold text-slate-300">
            <div className="bg-slate-900/60 py-1 px-1.5 rounded-lg">
              <span className="block text-slate-400 text-[10px]">통과 산호</span>
              <span className="text-rose-400">{coralsPassed}개</span>
            </div>
            <div className="bg-slate-900/60 py-1 px-1.5 rounded-lg">
              <span className="block text-slate-400 text-[10px]">획득 별</span>
              <span className="text-amber-400">{starCount}개</span>
            </div>
            <div className="bg-slate-900/60 py-1 px-1.5 rounded-lg">
              <span className="block text-slate-400 text-[10px]">생존 시간</span>
              <span className="text-sky-400">{Math.floor(timeSurvived)}초</span>
            </div>
          </div>
        </div>

        {/* Score Submission Form */}
        {!isSubmitted ? (
          <form onSubmit={handleSubmit} className="w-full mb-3 text-left">
            <label htmlFor="player-nickname-input" className="block text-xs font-bold text-slate-300 mb-1 flex items-center gap-1">
              <Award className="w-3.5 h-3.5 text-amber-400" /> 점수판에 내 기록 남기기
            </label>
            <div className="flex gap-2">
              <input
                id="player-nickname-input"
                type="text"
                maxLength={10}
                placeholder="닉네임 (최대 10자)"
                value={nickname}
                onChange={(e) => setNickname(e.target.value)}
                className="flex-1 px-3 py-2 bg-slate-950 border-2 border-amber-400/50 rounded-xl text-xs font-bold text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
              />
              <button
                type="submit"
                className="px-3.5 py-2 bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 font-black text-xs rounded-xl shadow transition whitespace-nowrap cursor-pointer"
              >
                등록
              </button>
            </div>
          </form>
        ) : (
          <div className="w-full py-2 mb-3 bg-emerald-950/60 border border-emerald-500/40 rounded-xl text-emerald-300 text-xs font-bold flex items-center justify-center gap-1.5">
            <CheckCircle className="w-4 h-4 text-emerald-400" />
            점수판에 등록 완료되었습니다! 🎉
          </div>
        )}

        {/* Buttons */}
        <div className="w-full flex gap-2">
          <button
            id="btn-restart-game"
            onClick={onRestart}
            className="flex-1 py-3 px-4 bg-gradient-to-b from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 active:scale-95 text-slate-950 font-black text-sm rounded-2xl shadow-lg border-b-4 border-amber-700 flex items-center justify-center gap-1.5 transition cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" /> 다시 하기
          </button>
          <button
            id="btn-open-leaderboard-from-over"
            onClick={onOpenLeaderboard}
            className="py-3 px-4 bg-gradient-to-b from-sky-500 to-sky-600 hover:from-sky-400 hover:to-sky-500 active:scale-95 text-white font-black text-sm rounded-2xl shadow-lg border-b-4 border-sky-800 flex items-center justify-center gap-1.5 transition cursor-pointer"
          >
            <Trophy className="w-4 h-4" /> 점수판
          </button>
        </div>
      </div>
    </div>
  );
};
