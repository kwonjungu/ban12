import React from 'react';
import mascotImg from '../assets/images/squid_mascot_avatar_1789882230711.jpg';
import shieldImg from '../assets/images/squid_shield_bubble_1789882251763.jpg';
import trophyImg from '../assets/images/squid_gold_trophy_1789882242166.jpg';
import { Volume2, VolumeX, Star, Clock } from 'lucide-react';

interface HudProps {
  score: number;
  stars: number;
  shields: number;
  timeSeconds: number;
  toastMsg: string | null;
  isMuted: boolean;
  onToggleMute: () => void;
  onOpenLeaderboard: () => void;
}

export const Hud: React.FC<HudProps> = ({
  score,
  stars,
  shields,
  timeSeconds,
  toastMsg,
  isMuted,
  onToggleMute,
  onOpenLeaderboard,
}) => {
  return (
    <>
      {/* Toast Notification */}
      {toastMsg && (
        <div
          id="hud-toast"
          className="fixed top-20 left-1/2 -translate-x-1/2 z-30 px-5 py-2.5 bg-slate-900/90 border-2 border-amber-400 text-amber-300 font-extrabold text-sm rounded-2xl shadow-2xl backdrop-blur-md pointer-events-none animate-bounce"
        >
          {toastMsg}
        </div>
      )}

      {/* Main HUD Bar */}
      <header
        id="game-hud-bar"
        className="fixed top-3 left-3 right-3 z-20 flex justify-between items-center pointer-events-none"
      >
        {/* Left: Mascot & Stats */}
        <div className="flex items-center gap-2 pointer-events-auto">
          {/* Mascot Tag */}
          <div className="flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-900/80 backdrop-blur-md border border-slate-700/80 rounded-full shadow-lg">
            <img
              src={mascotImg}
              alt="플레이어 오징어"
              referrerPolicy="no-referrer"
              className="w-6 h-6 rounded-full border border-amber-400 object-cover"
            />
            <span className="text-xs font-black text-slate-100 hidden sm:inline">오징어</span>
          </div>

          {/* Time Chip */}
          <div className="flex items-center gap-1 px-3 py-1.5 bg-slate-900/80 backdrop-blur-md border border-slate-700/80 rounded-full text-xs font-black text-slate-200 shadow-lg">
            <Clock className="w-3.5 h-3.5 text-sky-400" />
            <span>{Math.floor(timeSeconds)}초</span>
          </div>

          {/* Stars Chip */}
          <div className="flex items-center gap-1 px-3 py-1.5 bg-slate-900/80 backdrop-blur-md border border-slate-700/80 rounded-full text-xs font-black text-amber-300 shadow-lg">
            <Star className="w-3.5 h-3.5 fill-amber-300 text-amber-300" />
            <span>{stars}</span>
          </div>

          {/* Shield Chip with Asset Thumbnail */}
          <div
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-black transition-all shadow-lg ${
              shields > 0
                ? 'bg-sky-600/90 border-2 border-sky-300 text-white ring-2 ring-sky-400/50 shadow-sky-500/40 animate-pulse'
                : 'bg-slate-900/80 border border-slate-700/80 text-slate-400'
            }`}
          >
            <div className="w-4 h-4 rounded-full overflow-hidden border border-white/50 flex-shrink-0">
              <img
                src={shieldImg}
                alt="방패 아이템"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </div>
            <span>{shields}</span>
          </div>
        </div>

        {/* Right: Score & Actions */}
        <div className="flex items-center gap-2 pointer-events-auto">
          {/* Big Score Chip */}
          <div className="flex items-center gap-1 px-4 py-1.5 bg-slate-900/85 backdrop-blur-md border-2 border-amber-400 rounded-full text-base font-black text-amber-300 shadow-xl shadow-amber-500/10">
            <span className="text-xs text-amber-400/80">SCORE</span>
            <span>{score}</span>
          </div>

          {/* Mute Button */}
          <button
            id="btn-toggle-sound"
            onClick={onToggleMute}
            className="p-2 bg-slate-900/80 hover:bg-slate-800 backdrop-blur-md border border-slate-700/80 rounded-full text-slate-200 hover:text-white transition shadow-lg cursor-pointer"
            aria-label={isMuted ? '음소거 해제' : '음소거'}
          >
            {isMuted ? (
              <VolumeX className="w-4 h-4 text-rose-400" />
            ) : (
              <Volume2 className="w-4 h-4 text-emerald-400" />
            )}
          </button>

          {/* Leaderboard Button with Trophy Asset */}
          <button
            id="btn-hud-leaderboard"
            onClick={onOpenLeaderboard}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 active:scale-95 text-slate-950 rounded-full text-xs font-black shadow-lg transition cursor-pointer border border-amber-300"
          >
            <img
              src={trophyImg}
              alt="트로피"
              referrerPolicy="no-referrer"
              className="w-4 h-4 rounded-full object-cover"
            />
            <span className="hidden sm:inline">점수판</span>
          </button>
        </div>
      </header>
    </>
  );
};
