import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { GameState, PipeObstacle, StarCollectible, Particle, LeaderboardEntry } from './types';
import {
  initAudio,
  playFlapSnd,
  playScoreSnd,
  playStarSnd,
  playShieldSnd,
  playHitSnd,
  playStartSnd,
  setMuted,
  getIsMuted,
} from './utils/audio';
import { getLeaderboard, saveScore } from './utils/leaderboard';
import { Hud } from './components/Hud';
import { TitleModal } from './components/TitleModal';
import { GameOverModal } from './components/GameOverModal';
import { LeaderboardModal } from './components/LeaderboardModal';

export default function App() {
  const containerRef = useRef<HTMLDivElement>(null);

  // React states for UI
  const [gameState, setGameState] = useState<GameState>('TITLE');
  const [score, setScore] = useState<number>(0);
  const [starCount, setStarCount] = useState<number>(0);
  const [coralsPassed, setCoralsPassed] = useState<number>(0);
  const [shields, setShields] = useState<number>(0);
  const [runTime, setRunTime] = useState<number>(0);
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const [isMutedState, setIsMutedState] = useState<boolean>(false);
  const [isLeaderboardOpen, setIsLeaderboardOpen] = useState<boolean>(false);
  const [leaderboardEntries, setLeaderboardEntries] = useState<LeaderboardEntry[]>([]);

  // Refs for Game Loop access
  const stateRef = useRef<GameState>('TITLE');
  stateRef.current = gameState;

  const scoreRef = useRef(0);
  const starCountRef = useRef(0);
  const coralsPassedRef = useRef(0);
  const shieldsRef = useRef(0);
  const runTimeRef = useRef(0);
  const invTimeRef = useRef(0);
  const toastTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Three.js object references
  const threeRef = useRef<{
    scene: THREE.Scene;
    camera: THREE.PerspectiveCamera;
    renderer: THREE.WebGLRenderer;
    squidGroup: THREE.Group;
    tentacles: THREE.Mesh[];
    shieldMesh: THREE.Mesh;
    ambientBubbles: THREE.Mesh[];
    seaweedList: THREE.Mesh[];
    pipes: PipeObstacle[];
    starItems: StarCollectible[];
    particles: Particle[];
    birdY: number;
    birdVY: number;
    clock: THREE.Clock;
    animId: number | null;
  } | null>(null);

  const showToast = useCallback((msg: string) => {
    setToastMsg(msg);
    if (toastTimeoutRef.current) clearTimeout(toastTimeoutRef.current);
    toastTimeoutRef.current = setTimeout(() => {
      setToastMsg(null);
    }, 1600);
  }, []);

  // Helper to create 3D star mesh
  const createStarMesh = useCallback((): THREE.Mesh => {
    const shape = new THREE.Shape();
    const points = 5;
    for (let i = 0; i < points * 2; i++) {
      const r = i % 2 === 0 ? 0.6 : 0.28;
      const a = (i / (points * 2)) * Math.PI * 2;
      const x = Math.cos(a) * r;
      const y = Math.sin(a) * r;
      if (i === 0) shape.moveTo(x, y);
      else shape.lineTo(x, y);
    }
    shape.closePath();

    const starGeo = new THREE.ExtrudeGeometry(shape, {
      depth: 0.2,
      bevelEnabled: true,
      bevelSegments: 2,
      steps: 1,
      bevelSize: 0.05,
      bevelThickness: 0.05,
    });
    starGeo.center();

    const starMat = new THREE.MeshStandardMaterial({
      color: 0xfacc15,
      metalness: 0.3,
      roughness: 0.2,
      emissive: 0xca8a04,
      emissiveIntensity: 0.5,
    });
    const mesh = new THREE.Mesh(starGeo, starMat);
    mesh.castShadow = true;
    return mesh;
  }, []);

  // Helper to create colorful coral branches
  const createCoralPillar = useCallback((height: number, colorHex: number): THREE.Group => {
    const group = new THREE.Group();
    const coralMat = new THREE.MeshToonMaterial({ color: colorHex });

    const trunkGeo = new THREE.CylinderGeometry(0.95, 1.25, height, 16);
    const trunk = new THREE.Mesh(trunkGeo, coralMat);
    trunk.castShadow = true;
    trunk.receiveShadow = true;
    group.add(trunk);

    const rimGeo = new THREE.CylinderGeometry(1.25, 1.05, 0.6, 16);
    const rim = new THREE.Mesh(rimGeo, coralMat);
    rim.position.y = height / 2 - 0.3;
    rim.castShadow = true;
    group.add(rim);

    // Decorative small coral polyp knobs
    for (let i = 0; i < 4; i++) {
      const knob = new THREE.Mesh(new THREE.SphereGeometry(0.25, 8, 8), coralMat);
      const angle = (i / 4) * Math.PI * 2;
      knob.position.set(Math.cos(angle) * 1.05, (i - 1.5) * 1.8, Math.sin(angle) * 1.05);
      group.add(knob);
    }

    return group;
  }, []);

  // Spawn coral obstacles
  const coralColors = [0xec4899, 0xf97316, 0xa855f7, 0x06b6d4, 0xef4444, 0x10b981];

  const spawnPipeGroup = useCallback((xPos: number) => {
    const t = threeRef.current;
    if (!t) return;

    const gap = Math.max(4.2, 5.5 - Math.min(coralsPassedRef.current * 0.05, 1.3));
    const minY = -2.2, maxY = 3.2;
    const centerY = minY + Math.random() * (maxY - minY);

    const group = new THREE.Group();
    group.position.set(xPos, centerY, 0);

    const color = coralColors[Math.floor(Math.random() * coralColors.length)];

    const topCoral = createCoralPillar(16, color);
    topCoral.position.y = gap / 2 + 8;
    group.add(topCoral);

    const botCoral = createCoralPillar(16, color);
    botCoral.position.y = -gap / 2 - 8;
    group.add(botCoral);

    t.scene.add(group);
    t.pipes.push({ group, x: xPos, y: centerY, gap, scored: false });

    // Spawn 3D Star Collectible
    if (Math.random() < 0.6) {
      const starMesh = createStarMesh();
      const starOffY = (Math.random() < 0.5 ? 1 : -1) * (gap * 0.3);
      starMesh.position.set(xPos, centerY + starOffY, 0);
      t.scene.add(starMesh);
      t.starItems.push({ mesh: starMesh, x: xPos, y: centerY + starOffY, got: false });
    }
  }, [createCoralPillar, createStarMesh]);

  // Burst Particles (bubbles / sparkles)
  const createBurstParticles = useCallback((x: number, y: number, colorHex: number, count: number) => {
    const t = threeRef.current;
    if (!t) return;

    const pGeo = new THREE.SphereGeometry(0.14, 8, 8);
    const pMat = new THREE.MeshPhongMaterial({ color: colorHex, transparent: true, opacity: 0.85 });

    for (let i = 0; i < count; i++) {
      const p = new THREE.Mesh(pGeo, pMat);
      p.position.set(x, y, 0);
      t.scene.add(p);
      t.particles.push({
        mesh: p,
        vx: (Math.random() - 0.5) * 6,
        vy: (Math.random() - 0.2) * 5 + 2,
        vz: (Math.random() - 0.5) * 3,
        life: 0.8,
      });
    }
  }, []);

  // Reset Game for new round
  const resetGame = useCallback(() => {
    const t = threeRef.current;
    if (!t) return;

    // Remove existing obstacles & collectibles
    t.pipes.forEach((p) => t.scene.remove(p.group));
    t.starItems.forEach((s) => t.scene.remove(s.mesh));
    t.particles.forEach((pt) => t.scene.remove(pt.mesh));

    t.pipes = [];
    t.starItems = [];
    t.particles = [];

    t.birdY = 0;
    t.birdVY = 0;
    t.squidGroup.position.set(-3.2, 0, 0);
    t.squidGroup.rotation.set(0, 0, 0);

    scoreRef.current = 0;
    starCountRef.current = 0;
    coralsPassedRef.current = 0;
    shieldsRef.current = 0;
    runTimeRef.current = 0;
    invTimeRef.current = 0;

    setScore(0);
    setStarCount(0);
    setCoralsPassed(0);
    setShields(0);
    setRunTime(0);

    spawnPipeGroup(10);
    spawnPipeGroup(17.5);
  }, [spawnPipeGroup]);

  // Flap action
  const flap = useCallback(() => {
    const t = threeRef.current;
    if (!t) return;

    initAudio();
    t.birdVY = 8.2;
    playFlapSnd();
    createBurstParticles(t.squidGroup.position.x - 0.8, t.squidGroup.position.y, 0xe0f2fe, 8);
  }, [createBurstParticles]);

  const handleStartGame = useCallback(() => {
    initAudio();
    resetGame();
    setGameState('PLAYING');
    playStartSnd();
    showToast('바닷속으로 오징어 헤엄 출발! 🦑');
    flap();
  }, [resetGame, flap, showToast]);

  const handleRestartGame = useCallback(() => {
    initAudio();
    resetGame();
    setGameState('PLAYING');
    playStartSnd();
    flap();
  }, [resetGame, flap]);

  const handleSubmitScore = useCallback((name: string) => {
    const updated = saveScore(name, scoreRef.current, starCountRef.current);
    setLeaderboardEntries(updated);
    showToast('점수판에 등록되었습니다! 🏆');
  }, [showToast]);

  const toggleMute = useCallback(() => {
    const next = !getIsMuted();
    setMuted(next);
    setIsMutedState(next);
    showToast(next ? '소리가 꺼졌습니다 🔇' : '소리가 켜졌습니다 🔊');
  }, [showToast]);

  // Setup Three.js Scene
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // Scene & Fog
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0c1a2f);
    scene.fog = new THREE.FogExp2(0x0c1a2f, 0.025);

    // Camera
    const camera = new THREE.PerspectiveCamera(
      60,
      container.clientWidth / container.clientHeight,
      0.1,
      1000
    );
    camera.position.set(0, 0, 12);

    // Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'high-performance' });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.appendChild(renderer.domElement);

    // Lighting
    const ambientLight = new THREE.AmbientLight(0x38bdf8, 0.8);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xffffff, 0.95);
    dirLight.position.set(10, 20, 15);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 1024;
    dirLight.shadow.mapSize.height = 1024;
    scene.add(dirLight);

    // Deep Ocean Water Rim Light
    const rimLight = new THREE.PointLight(0x38bdf8, 1.2, 50);
    rimLight.position.set(-10, 5, 5);
    scene.add(rimLight);

    // Build 3D Cute Squid Group
    const squidGroup = new THREE.Group();
    squidGroup.position.set(-3.2, 0, 0);
    scene.add(squidGroup);

    // 1. Squid Body Mantle (Cone pointing forward to +X)
    const bodyGeo = new THREE.ConeGeometry(0.85, 2.0, 24);
    const squidMat = new THREE.MeshToonMaterial({ color: 0xf43f5e });
    const bodyMesh = new THREE.Mesh(bodyGeo, squidMat);
    bodyMesh.rotation.z = -Math.PI / 2; // Cone tip points towards +X
    bodyMesh.castShadow = true;
    squidGroup.add(bodyMesh);

    // 2. Triangular Fin on apex of Mantle (+X front or apex)
    const finGeo = new THREE.ConeGeometry(0.85, 1.1, 3);
    const finMat = new THREE.MeshToonMaterial({ color: 0xe11d48 });
    const finMesh = new THREE.Mesh(finGeo, finMat);
    finMesh.rotation.z = -Math.PI / 2;
    finMesh.rotation.x = Math.PI / 2;
    finMesh.scale.set(1.4, 0.25, 1.2);
    finMesh.position.set(0.9, 0, 0);
    squidGroup.add(finMesh);

    // 3. Cute Squid Big Eyes
    const eyeGeo = new THREE.SphereGeometry(0.24, 16, 16);
    const eyeWhiteMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const pupilMat = new THREE.MeshBasicMaterial({ color: 0x0f172a });
    const glintMat = new THREE.MeshBasicMaterial({ color: 0xffffff });

    const leftEyeGroup = new THREE.Group();
    const leftEyeWhite = new THREE.Mesh(eyeGeo, eyeWhiteMat);
    const leftPupil = new THREE.Mesh(new THREE.SphereGeometry(0.13, 16, 16), pupilMat);
    leftPupil.position.set(0.12, 0, 0.12);
    const leftGlint = new THREE.Mesh(new THREE.SphereGeometry(0.04, 8, 8), glintMat);
    leftGlint.position.set(0.18, 0.05, 0.16);

    leftEyeGroup.add(leftEyeWhite);
    leftEyeGroup.add(leftPupil);
    leftEyeGroup.add(leftGlint);
    leftEyeGroup.position.set(-0.2, 0.2, 0.55);

    const rightEyeGroup = leftEyeGroup.clone();
    rightEyeGroup.position.set(-0.2, 0.2, -0.55);

    squidGroup.add(leftEyeGroup);
    squidGroup.add(rightEyeGroup);

    // Cute blush cheeks
    const cheekMat = new THREE.MeshBasicMaterial({ color: 0xfb7185, transparent: true, opacity: 0.6 });
    const leftCheek = new THREE.Mesh(new THREE.SphereGeometry(0.1, 8, 8), cheekMat);
    leftCheek.position.set(-0.15, -0.05, 0.65);
    leftCheek.scale.set(1.5, 0.8, 0.5);
    const rightCheek = leftCheek.clone();
    rightCheek.position.set(-0.15, -0.05, -0.65);
    squidGroup.add(leftCheek);
    squidGroup.add(rightCheek);

    // 4. Squid Tentacles (Trailing behind the mantle to -X)
    const tentacles: THREE.Mesh[] = [];
    const tentacleGeo = new THREE.CylinderGeometry(0.06, 0.02, 1.4, 8);
    const tentacleMat = new THREE.MeshToonMaterial({ color: 0xf43f5e });

    for (let t = 0; t < 10; t++) {
      const tentacle = new THREE.Mesh(tentacleGeo, tentacleMat);
      const angle = (t / 10) * Math.PI * 2;
      const radius = 0.35;
      if (t === 0 || t === 5) {
        tentacle.scale.set(1.2, 1.7, 1.2);
      }
      tentacle.position.set(-0.95, Math.cos(angle) * radius, Math.sin(angle) * radius);
      tentacle.rotation.z = Math.PI / 2; // Points backwards (-X)
      tentacles.push(tentacle);
      squidGroup.add(tentacle);
    }

    // 5. Shield Bubble Sphere around squid
    const shieldGeo = new THREE.SphereGeometry(1.5, 32, 32);
    const shieldMat = new THREE.MeshPhongMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.45,
      shininess: 90,
    });
    const shieldMesh = new THREE.Mesh(shieldGeo, shieldMat);
    shieldMesh.visible = false;
    squidGroup.add(shieldMesh);

    // 6. Sandy Seabed & Ocean Floor
    const groundGeo = new THREE.BoxGeometry(100, 4, 12);
    const groundMat = new THREE.MeshToonMaterial({ color: 0xfacc15 });
    const groundMesh = new THREE.Mesh(groundGeo, groundMat);
    groundMesh.position.set(0, -9, 0);
    groundMesh.receiveShadow = true;
    scene.add(groundMesh);

    const dirtGeo = new THREE.BoxGeometry(100, 10, 12);
    const dirtMat = new THREE.MeshToonMaterial({ color: 0xd97706 });
    const dirtMesh = new THREE.Mesh(dirtGeo, dirtMat);
    dirtMesh.position.set(0, -16, 0);
    scene.add(dirtMesh);

    // 7. Seaweed Fronds
    const seaweedList: THREE.Mesh[] = [];
    const seaweedMat = new THREE.MeshToonMaterial({ color: 0x10b981 });
    for (let sw = -40; sw <= 40; sw += 8) {
      const swGeo = new THREE.CylinderGeometry(0.12, 0.28, 5 + Math.random() * 4, 8);
      const seaweed = new THREE.Mesh(swGeo, seaweedMat);
      seaweed.position.set(sw, -5, -8 - Math.random() * 4);
      seaweed.rotation.z = (Math.random() - 0.5) * 0.2;
      scene.add(seaweed);
      seaweedList.push(seaweed);
    }

    // 8. Ambient Bubbles Rising
    const ambientBubbles: THREE.Mesh[] = [];
    const bubbleMat = new THREE.MeshPhongMaterial({
      color: 0xe0f2fe,
      transparent: true,
      opacity: 0.65,
      shininess: 90,
    });
    for (let b = 0; b < 25; b++) {
      const bMesh = new THREE.Mesh(
        new THREE.SphereGeometry(0.15 + Math.random() * 0.25, 16, 16),
        bubbleMat
      );
      bMesh.position.set(
        -25 + Math.random() * 50,
        -8 + Math.random() * 18,
        -5 + Math.random() * 6
      );
      scene.add(bMesh);
      ambientBubbles.push(bMesh);
    }

    // Save references
    const threeData = {
      scene,
      camera,
      renderer,
      squidGroup,
      tentacles,
      shieldMesh,
      ambientBubbles,
      seaweedList,
      pipes: [] as PipeObstacle[],
      starItems: [] as StarCollectible[],
      particles: [] as Particle[],
      birdY: 0,
      birdVY: 0,
      clock: new THREE.Clock(),
      animId: null as number | null,
    };
    threeRef.current = threeData;

    // Load initial leaderboard
    setLeaderboardEntries(getLeaderboard());

    // Resize Handler with ResizeObserver
    const handleResize = () => {
      if (!container) return;
      const width = container.clientWidth;
      const height = container.clientHeight;
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    };

    window.addEventListener('resize', handleResize);

    // ==========================================
    // Main Game Animation Loop
    // ==========================================
    const animate = () => {
      threeData.animId = requestAnimationFrame(animate);

      let dt = threeData.clock.getDelta();
      if (dt > 0.1) dt = 0.1;
      const elapsed = threeData.clock.getElapsedTime();

      // Tentacles Gentle Wriggle Animation
      for (let t = 0; t < tentacles.length; t++) {
        tentacles[t].rotation.y = Math.sin(elapsed * 8 + t) * 0.2;
        tentacles[t].rotation.z = Math.PI / 2 + Math.cos(elapsed * 6 + t) * 0.18;
      }

      // Seaweed Gentle Wave
      for (let sw = 0; sw < seaweedList.length; sw++) {
        seaweedList[sw].rotation.z = Math.sin(elapsed * 2 + sw) * 0.15;
      }

      // Ambient Bubbles Floating Upwards
      for (let b = 0; b < ambientBubbles.length; b++) {
        ambientBubbles[b].position.y += dt * 2.2;
        ambientBubbles[b].position.x += Math.sin(elapsed * 2 + b) * dt * 0.4;
        if (ambientBubbles[b].position.y > 10) {
          ambientBubbles[b].position.y = -8.5;
          ambientBubbles[b].position.x = -25 + Math.random() * 50;
        }
      }

      // Particle Updates
      for (let p = threeData.particles.length - 1; p >= 0; p--) {
        const pt = threeData.particles[p];
        pt.life -= dt;
        if (pt.life <= 0) {
          scene.remove(pt.mesh);
          threeData.particles.splice(p, 1);
        } else {
          pt.mesh.position.x += pt.vx * dt;
          pt.mesh.position.y += pt.vy * dt;
          pt.mesh.position.z += pt.vz * dt;
        }
      }

      // Shield Bubble Update on Squid
      if (shieldsRef.current > 0) {
        shieldMesh.visible = true;
        const pulse = 1 + Math.sin(elapsed * 6) * 0.05;
        shieldMesh.scale.set(pulse, pulse, pulse);
      } else {
        shieldMesh.visible = false;
      }

      // STATE LOGIC
      if (stateRef.current === 'TITLE') {
        // Idle gentle floating
        squidGroup.position.y = Math.sin(elapsed * 3) * 0.4;
        squidGroup.rotation.z = Math.sin(elapsed * 2) * 0.08;
      } else if (stateRef.current === 'PLAYING') {
        runTimeRef.current += dt;
        setRunTime(runTimeRef.current);

        if (invTimeRef.current > 0) {
          invTimeRef.current -= dt;
        }

        // Squid Gravity & Physics
        threeData.birdVY -= 21 * dt;
        threeData.birdY += threeData.birdVY * dt;
        squidGroup.position.y = threeData.birdY;
        squidGroup.rotation.z = Math.max(-0.5, Math.min(0.5, threeData.birdVY * 0.07));

        const scrollSpeed = 5.8 + Math.min(coralsPassedRef.current * 0.15, 3.8);

        // Pipe Obstacles Logic
        for (let i = threeData.pipes.length - 1; i >= 0; i--) {
          const pipeObj = threeData.pipes[i];
          pipeObj.x -= scrollSpeed * dt;
          pipeObj.group.position.x = pipeObj.x;

          // Check if passed squid for scoring
          if (!pipeObj.scored && pipeObj.x < squidGroup.position.x) {
            pipeObj.scored = true;
            coralsPassedRef.current += 1;
            setCoralsPassed(coralsPassedRef.current);

            scoreRef.current += 1;
            setScore(scoreRef.current);

            playScoreSnd();
            showToast('+1점! 🪸');
          }

          // Remove off-screen pipes
          if (pipeObj.x < -16) {
            scene.remove(pipeObj.group);
            threeData.pipes.splice(i, 1);
          }
        }

        // Spawn next pipe obstacle
        const lastPipeX = threeData.pipes.length > 0 ? threeData.pipes[threeData.pipes.length - 1].x : 0;
        if (lastPipeX < 11) {
          spawnPipeGroup(lastPipeX + 7.5);
        }

        // Star Collectibles Logic
        for (let s = threeData.starItems.length - 1; s >= 0; s--) {
          const starObj = threeData.starItems[s];
          starObj.x -= scrollSpeed * dt;
          starObj.mesh.position.x = starObj.x;
          starObj.mesh.rotation.y += dt * 3.5;

          // Collision with squid
          if (
            !starObj.got &&
            Math.abs(starObj.x - squidGroup.position.x) < 1.15 &&
            Math.abs(starObj.y - threeData.birdY) < 1.2
          ) {
            starObj.got = true;
            starCountRef.current += 1;
            setStarCount(starCountRef.current);

            scoreRef.current += 3;
            setScore(scoreRef.current);

            playStarSnd();
            createBurstParticles(starObj.x, starObj.y, 0xfacc15, 14);
            scene.remove(starObj.mesh);

            // Shield powerup reward every 3 stars!
            if (starCountRef.current % 3 === 0 && shieldsRef.current < 2) {
              shieldsRef.current += 1;
              setShields(shieldsRef.current);
              playShieldSnd();
              showToast('물방울 방패 획득! 🛡️');
            } else {
              showToast('+3점 별 획득! ⭐');
            }
          }

          if (starObj.x < -16) {
            scene.remove(starObj.mesh);
            threeData.starItems.splice(s, 1);
          }
        }

        // Collision Checks
        let hit = false;
        const squidX = squidGroup.position.x;

        // Ground / Ceiling Collision
        if (threeData.birdY < -5.6 || threeData.birdY > 7.6) {
          hit = true;
        }

        // Coral Obstacle Collision
        for (let cIdx = 0; cIdx < threeData.pipes.length; cIdx++) {
          const pipe = threeData.pipes[cIdx];
          if (Math.abs(pipe.x - squidX) < 1.15) {
            const topLimit = pipe.y + pipe.gap / 2 - 0.4;
            const botLimit = pipe.y - pipe.gap / 2 + 0.4;
            if (threeData.birdY > topLimit || threeData.birdY < botLimit) {
              hit = true;
              break;
            }
          }
        }

        if (hit && invTimeRef.current <= 0) {
          if (shieldsRef.current > 0) {
            shieldsRef.current -= 1;
            setShields(shieldsRef.current);
            invTimeRef.current = 1.2;
            threeData.birdVY = 6.5;
            playHitSnd();
            createBurstParticles(squidX, threeData.birdY, 0x38bdf8, 16);
            showToast('방패가 충격을 흡수했습니다! 🛡️');
          } else {
            // Game Over
            setGameState('GAMEOVER');
            playHitSnd();
            createBurstParticles(squidX, threeData.birdY, 0xef4444, 22);
          }
        }
      }

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      window.removeEventListener('resize', handleResize);
      if (threeData.animId) cancelAnimationFrame(threeData.animId);
      renderer.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [createBurstParticles, showToast, spawnPipeGroup]);

  // Global Pointer & Keyboard Event Handlers
  const handlePointerDown = (e: React.PointerEvent) => {
    // Only trigger flap if clicking on the background canvas, not on cards or buttons
    const target = e.target as HTMLElement;
    if (
      target.closest('#title-card') ||
      target.closest('#game-over-card') ||
      target.closest('#leaderboard-card') ||
      target.closest('#game-hud-bar') ||
      target.tagName === 'BUTTON' ||
      target.tagName === 'INPUT'
    ) {
      return;
    }

    if (gameState === 'PLAYING') {
      flap();
    } else if (gameState === 'TITLE' && !isLeaderboardOpen) {
      handleStartGame();
    }
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement).tagName === 'INPUT') return;

      if (e.code === 'Space' || e.key === 'ArrowUp' || e.key === 'w' || e.key === 'W') {
        e.preventDefault();
        if (stateRef.current === 'PLAYING') {
          flap();
        } else if (stateRef.current === 'TITLE' && !isLeaderboardOpen) {
          handleStartGame();
        } else if (stateRef.current === 'GAMEOVER' && !isLeaderboardOpen) {
          handleRestartGame();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [flap, handleStartGame, handleRestartGame, isLeaderboardOpen]);

  return (
    <main
      id="app-root"
      className="relative w-screen h-screen overflow-hidden select-none bg-slate-950 font-sans"
      onPointerDown={handlePointerDown}
    >
      {/* Three.js Canvas Container */}
      <div
        id="three-canvas-container"
        ref={containerRef}
        className="absolute inset-0 w-full h-full cursor-pointer touch-none"
      />

      {/* Top HUD Bar */}
      <Hud
        score={score}
        stars={starCount}
        shields={shields}
        timeSeconds={runTime}
        toastMsg={toastMsg}
        isMuted={isMutedState}
        onToggleMute={toggleMute}
        onOpenLeaderboard={() => setIsLeaderboardOpen(true)}
      />

      {/* Title / Start Modal */}
      <TitleModal
        isOpen={gameState === 'TITLE'}
        onStart={handleStartGame}
        onOpenLeaderboard={() => setIsLeaderboardOpen(true)}
      />

      {/* Game Over Modal */}
      <GameOverModal
        isOpen={gameState === 'GAMEOVER'}
        score={score}
        coralsPassed={coralsPassed}
        starCount={starCount}
        timeSurvived={runTime}
        onRestart={handleRestartGame}
        onOpenLeaderboard={() => setIsLeaderboardOpen(true)}
        onSubmitScore={handleSubmitScore}
      />

      {/* Leaderboard Modal */}
      <LeaderboardModal
        isOpen={isLeaderboardOpen}
        onClose={() => setIsLeaderboardOpen(false)}
        entries={leaderboardEntries}
        onRefresh={() => setLeaderboardEntries(getLeaderboard())}
      />
    </main>
  );
}
