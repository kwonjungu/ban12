import * as THREE from 'three';

export interface LeaderboardEntry {
  id: string;
  name: string;
  score: number;
  stars: number;
  date: string;
  timestamp: number;
}

export type GameState = 'TITLE' | 'PLAYING' | 'GAMEOVER';

export interface Particle {
  mesh: THREE.Mesh;
  vx: number;
  vy: number;
  vz: number;
  life: number;
}

export interface PipeObstacle {
  group: THREE.Group;
  x: number;
  y: number;
  gap: number;
  scored: boolean;
}

export interface StarCollectible {
  mesh: THREE.Mesh;
  x: number;
  y: number;
  got: boolean;
}
