import sueChefImg from './assets/images/sue_chef_1789885327487.jpg';
import sueRamenBowlImg from './assets/images/sue_ramen_bowl_1789885341780.jpg';
import sueSuccessImg from './assets/images/sue_success_1789885353868.jpg';
import sueGameOverImg from './assets/images/sue_gameover_1789885365426.jpg';
import vintageKettleImg from './assets/images/vintage_kettle_1789885376843.jpg';

export const GAME_ASSETS = {
  sueChef: sueChefImg,
  sueRamenBowl: sueRamenBowlImg,
  sueSuccess: sueSuccessImg,
  sueGameOver: sueGameOverImg,
  vintageKettle: vintageKettleImg,
};
