import React from 'react';
import { IngredientTool } from '../types';
import { GAME_ASSETS } from '../assets';
import { Sparkles } from 'lucide-react';

interface IngredientsShelfProps {
  activeTool: IngredientTool | null;
  onSelectTool: (tool: IngredientTool) => void;
}

interface ToolItem {
  id: IngredientTool;
  label: string;
  subLabel: string;
  keyNumber: string;
  badgeBg: string;
  badgeText: string;
  image?: string;
  iconFallback?: string;
}

const TOOLS: ToolItem[] = [
  {
    id: 'water',
    label: '양은 주전자',
    subLabel: '물 붓기',
    keyNumber: '1',
    badgeBg: 'bg-blue-100',
    badgeText: 'text-blue-700',
    image: GAME_ASSETS.vintageKettle,
  },
  {
    id: 'noodle',
    label: '라면 사리',
    subLabel: '면 넣기',
    keyNumber: '2',
    badgeBg: 'bg-amber-100',
    badgeText: 'text-amber-800',
    iconFallback: '🍜',
  },
  {
    id: 'soup',
    label: '분말 스프',
    subLabel: '스프 톡톡',
    keyNumber: '3',
    badgeBg: 'bg-red-100',
    badgeText: 'text-red-700',
    iconFallback: '🌶️',
  },
  {
    id: 'egg',
    label: '신선한 계란',
    subLabel: '계란 톡',
    keyNumber: '4',
    badgeBg: 'bg-yellow-100',
    badgeText: 'text-yellow-800',
    iconFallback: '🥚',
  },
  {
    id: 'onion',
    label: '송송 대파',
    subLabel: '파 고명',
    keyNumber: '5',
    badgeBg: 'bg-emerald-100',
    badgeText: 'text-emerald-700',
    iconFallback: '🧅',
  },
];

export const IngredientsShelf: React.FC<IngredientsShelfProps> = ({
  activeTool,
  onSelectTool,
}) => {
  const currentToolData = TOOLS.find((t) => t.id === activeTool);

  return (
    <div className="bg-white/95 rounded-2xl shadow-md border-2 border-pink-200 p-3 sm:p-4">
      {/* Active Tool Banner */}
      <div className="flex flex-wrap items-center justify-between gap-2 mb-3 pb-2 border-b border-pink-100">
        <div className="flex items-center gap-2">
          <span className="text-xs sm:text-sm font-black text-pink-700">손에 든 조리도구:</span>
          {currentToolData ? (
            <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-pink-100 border-2 border-pink-400 rounded-full text-pink-800 font-bold text-xs sm:text-sm shadow-xs animate-pulse">
              <Sparkles className="w-3.5 h-3.5 text-pink-600" />
              {currentToolData.label} ({currentToolData.subLabel})
            </span>
          ) : (
            <span className="px-3 py-1 bg-slate-100 border border-slate-300 rounded-full text-slate-500 font-bold text-xs sm:text-sm">
              👉 아래 재료를 클릭하여 집으세요
            </span>
          )}
        </div>
        <div className="text-[11px] sm:text-xs text-slate-500 flex items-center gap-1">
          <span className="hidden sm:inline">⌨️ 키보드 숫자키 [1~5] 로 빠른 재료 전환 가능!</span>
        </div>
      </div>

      {/* Ingredient Selection Grid */}
      <div className="grid grid-cols-5 gap-2 sm:gap-3">
        {TOOLS.map((tool) => {
          const isSelected = activeTool === tool.id;
          return (
            <button
              key={tool.id}
              onClick={() => onSelectTool(tool.id)}
              className={`relative flex flex-col items-center justify-center p-2 rounded-2xl border-2 transition-all duration-150 cursor-pointer ${
                isSelected
                  ? 'border-pink-500 ring-3 ring-pink-300 bg-pink-50 scale-105 shadow-md -translate-y-0.5'
                  : 'border-slate-200 hover:border-pink-300 bg-gradient-to-b from-slate-50 to-white hover:bg-pink-50/40 shadow-xs'
              }`}
            >
              {/* Hotkey Badge */}
              <span className="absolute top-1 left-1.5 text-[10px] sm:text-xs font-black px-1.5 py-0.2 rounded-md bg-slate-800/80 text-white">
                {tool.keyNumber}
              </span>

              {/* Icon or Generated Image */}
              <div className="w-11 h-11 sm:w-14 sm:h-14 flex items-center justify-center my-1">
                {tool.image ? (
                  <img
                    src={tool.image}
                    alt={tool.label}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-contain rounded-lg drop-shadow-sm transition-transform group-hover:scale-105"
                  />
                ) : (
                  <span className="text-3xl sm:text-4xl filter drop-shadow-sm select-none">
                    {tool.iconFallback}
                  </span>
                )}
              </div>

              {/* Labels */}
              <span className="text-xs sm:text-sm font-black text-slate-800 whitespace-nowrap text-center">
                {tool.label}
              </span>
              <span className={`text-[10px] sm:text-xs font-bold ${tool.badgeText} mt-0.5 whitespace-nowrap`}>
                {tool.subLabel}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
