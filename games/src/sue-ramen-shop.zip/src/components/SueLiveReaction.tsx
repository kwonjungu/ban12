import React from 'react';
import { GAME_ASSETS } from '../assets';

interface SueLiveReactionProps {
  message: string;
  floatingFeedback: string | null;
}

export const SueLiveReaction: React.FC<SueLiveReactionProps> = ({
  message,
  floatingFeedback,
}) => {
  return (
    <div className="relative w-full flex items-center justify-between gap-3 bg-pink-100/90 border-2 border-pink-300 p-2.5 sm:p-3 rounded-2xl shadow-sm">
      {/* Floating score feedback banner */}
      {floatingFeedback && (
        <div className="absolute -top-10 left-1/2 -translate-x-1/2 bg-slate-900/95 text-yellow-300 px-4 py-1.5 rounded-full border-2 border-yellow-400 text-xs sm:text-sm font-black shadow-2xl animate-bounce z-30 whitespace-nowrap">
          {floatingFeedback}
        </div>
      )}

      {/* Sue Mini Avatar & Speech Bubble */}
      <div className="flex items-center gap-2.5">
        <div className="relative shrink-0">
          <img
            src={GAME_ASSETS.sueChef}
            alt="슈의 한마디"
            referrerPolicy="no-referrer"
            className="w-10 h-10 sm:w-12 sm:h-12 rounded-full border-2 border-pink-400 object-cover bg-white shadow-xs"
          />
        </div>
        <div className="flex flex-col">
          <span className="text-[10px] sm:text-xs font-black text-pink-700">슈의 조리 조언:</span>
          <p className="text-xs sm:text-sm font-gamja text-slate-800 font-bold leading-tight">
            {message}
          </p>
        </div>
      </div>

      <div className="text-[11px] sm:text-xs text-pink-600 font-bold bg-white/70 px-2.5 py-1 rounded-xl border border-pink-200 shrink-0 hidden md:block">
        💡 냄비 4개를 골고루 순환시키세요!
      </div>
    </div>
  );
};
