import React from 'react';
import { GameMode } from '../types';
import { GAME_ASSETS } from '../assets';
import { Volume2, VolumeX, Flame, Clock } from 'lucide-react';

interface HeaderProps {
  currentMoney: number;
  targetMoney: number;
  timeRemaining: number;
  totalTime: number;
  mode: GameMode;
  audioEnabled: boolean;
  onToggleAudio: () => void;
  onOpenRules: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentMoney,
  targetMoney,
  timeRemaining,
  totalTime,
  mode,
  audioEnabled,
  onToggleAudio,
  onOpenRules,
}) => {
  const timePercent = Math.max(0, Math.min(100, (timeRemaining / totalTime) * 100));
  const isTimeCritical = timeRemaining <= 15;

  return (
    <header className="bg-pink-500 p-3 sm:p-4 text-white shadow-lg relative z-20 border-b-4 border-pink-600 rounded-t-3xl">
      <div className="flex flex-wrap justify-between items-center gap-3">
        {/* Logo & Sue Avatar */}
        <div className="flex items-center gap-3">
          <div className="relative">
            <img
              src={GAME_ASSETS.sueChef}
              alt="요리사 슈"
              referrerPolicy="no-referrer"
              className="w-12 h-12 sm:w-14 sm:h-14 rounded-full border-2 border-yellow-300 shadow-md object-cover bg-white"
            />
            <span className="absolute -bottom-1 -right-1 text-xs bg-yellow-400 text-pink-900 font-bold px-1.5 py-0.2 rounded-full border border-pink-700 shadow">
              슈
            </span>
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-black tracking-wide drop-shadow-md text-white font-jua">
                슈의 라면가게
              </h1>
              {mode === 'hard' ? (
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 text-xs bg-red-600 text-yellow-200 font-bold rounded-full animate-bounce shadow">
                  <Flame className="w-3.5 h-3.5" /> 매운맛 모드
                </span>
              ) : (
                <span className="inline-block px-2.5 py-0.5 text-xs bg-blue-500 text-white font-bold rounded-full shadow">
                  😀 보통 모드
                </span>
              )}
            </div>
            <p className="text-xs text-pink-100 font-gamja hidden sm:block">
              추억의 플래시 라면 타이쿤 게임
            </p>
          </div>
        </div>

        {/* Stats Bar */}
        <div className="flex items-center gap-3 sm:gap-6 bg-pink-600/80 backdrop-blur-xs px-3.5 py-1.5 rounded-2xl border-2 border-pink-400 shadow-inner">
          <div className="text-center">
            <div className="text-[11px] text-pink-200 font-bold">현재 판매액</div>
            <div className="font-black text-yellow-300 text-lg sm:text-2xl tracking-tight">
              {currentMoney.toLocaleString()}원
            </div>
          </div>
          <div className="w-px h-8 bg-pink-400"></div>
          <div className="text-center">
            <div className="text-[11px] text-pink-200 font-bold">목표 금액</div>
            <div className="font-black text-white text-base sm:text-xl tracking-tight">
              {targetMoney.toLocaleString()}원
            </div>
          </div>
        </div>

        {/* Timer & Controls */}
        <div className="flex items-center gap-2 sm:gap-3 w-full sm:w-auto justify-between sm:justify-end">
          <div className="flex flex-col items-start sm:items-end flex-1 sm:flex-initial">
            <div className="flex items-center gap-1.5 font-bold text-sm sm:text-base">
              <Clock className={`w-4 h-4 ${isTimeCritical ? 'text-red-300 animate-spin' : 'text-yellow-300'}`} />
              <span className="text-pink-100 text-xs sm:text-sm">남은 시간:</span>
              <span
                className={`text-xl sm:text-2xl font-black ${
                  isTimeCritical ? 'text-red-300 animate-pulse' : 'text-yellow-300'
                }`}
              >
                {Math.ceil(timeRemaining)}
              </span>
              <span className="text-xs">초</span>
            </div>
            <div className="w-full sm:w-36 bg-pink-800/60 h-3 rounded-full overflow-hidden border border-pink-400 mt-1 shadow-inner">
              <div
                className={`h-full transition-all duration-200 ${
                  isTimeCritical ? 'bg-red-400' : 'bg-yellow-400'
                }`}
                style={{ width: `${timePercent}%` }}
              ></div>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={onToggleAudio}
              className="p-2 rounded-xl bg-pink-600 hover:bg-pink-700 active:scale-95 border border-pink-400 text-white transition shadow-sm"
              title={audioEnabled ? '소리 끄기' : '소리 켜기'}
              aria-label="음향 토글"
            >
              {audioEnabled ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5 text-pink-300" />}
            </button>
            <button
              onClick={onOpenRules}
              className="px-2.5 py-1.5 rounded-xl bg-pink-700 hover:bg-pink-800 active:scale-95 border border-pink-400 text-xs font-bold text-yellow-200 transition shadow-sm"
            >
              📖 비법
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
