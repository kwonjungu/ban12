import React from 'react';
import { PotState } from '../types';
import { Trash2, Send } from 'lucide-react';

interface CookingPotProps {
  pot: PotState;
  potIndex: number;
  burnLimit: number;
  onPotClick: (id: number) => void;
  onServe: (id: number) => void;
  onClear: (id: number) => void;
}

export const CookingPot: React.FC<CookingPotProps> = ({
  pot,
  potIndex,
  burnLimit,
  onPotClick,
  onServe,
  onClear,
}) => {
  const isBoiling = pot.water > 0 && pot.cookTime > 2.0 && !pot.burned;
  const isGoldenTime = pot.water > 0 && pot.cookTime >= 6.5 && pot.cookTime <= 10.5 && !pot.burned;
  const isOvercooking = pot.water > 0 && pot.cookTime > 10.5 && !pot.burned;

  // Water level optimal indicator (70% - 90%)
  const isWaterOptimal = pot.water >= 70 && pot.water <= 90;
  const isWaterLow = pot.water > 0 && pot.water < 70;
  const isWaterHigh = pot.water > 90;

  let statusText = '대기 중 (물 붓기)';
  let statusBadgeClass = 'bg-slate-700 text-slate-300';

  if (pot.burned) {
    statusText = '💀 타버렸어요! (비우기)';
    statusBadgeClass = 'bg-red-700 text-white animate-pulse font-black';
  } else if (isGoldenTime) {
    statusText = '⚡ 황금 골든타임! (서빙!)';
    statusBadgeClass = 'bg-yellow-400 text-slate-900 font-black animate-bounce shadow-md';
  } else if (isOvercooking) {
    statusText = '⚠️ 곧 탑니다! 서두르세요!';
    statusBadgeClass = 'bg-orange-500 text-white font-black animate-pulse';
  } else if (isBoiling) {
    statusText = '🔥 보글보글 끓는 중!';
    statusBadgeClass = 'bg-amber-500 text-white font-bold';
  } else if (pot.water > 0) {
    statusText = '💧 물 끓이는 중...';
    statusBadgeClass = 'bg-blue-600 text-blue-100';
  }

  return (
    <div
      className={`relative bg-gradient-to-b from-slate-900 to-slate-800 rounded-3xl p-3 sm:p-4 border-4 transition-all duration-200 shadow-xl flex flex-col items-center justify-between ${
        pot.burned
          ? 'border-red-600 ring-2 ring-red-500/50'
          : isGoldenTime
          ? 'border-yellow-400 ring-4 ring-yellow-400/70 scale-[1.02]'
          : 'border-slate-700 hover:border-pink-400/80'
      }`}
    >
      {/* Top Header */}
      <div className="w-full flex items-center justify-between mb-1 px-1">
        <span className="text-xs font-black text-amber-300 bg-slate-800 px-2 py-0.5 rounded-md border border-slate-700">
          화구 #{potIndex + 1}
        </span>
        <span className={`text-[10px] sm:text-xs px-2 py-0.5 rounded-full font-bold shadow-xs ${statusBadgeClass}`}>
          {statusText}
        </span>
      </div>

      {/* Main Interactive Cooking Pot Visual */}
      <div
        onClick={() => onPotClick(pot.id)}
        className="w-full flex items-center justify-center my-1.5 cursor-pointer select-none group"
      >
        <div className="relative w-36 h-36 sm:w-40 sm:h-40 flex items-center justify-center">
          {/* Pot Handles (Left & Right typical Korean 양은냄비 귀) */}
          <div className="absolute -left-3.5 top-1/2 -translate-y-1/2 w-5 h-7 rounded-l-lg bg-gradient-to-r from-amber-700 to-amber-600 border-2 border-amber-900 shadow-md"></div>
          <div className="absolute -right-3.5 top-1/2 -translate-y-1/2 w-5 h-7 rounded-r-lg bg-gradient-to-l from-amber-700 to-amber-600 border-2 border-amber-900 shadow-md"></div>

          {/* Golden Pot Body */}
          <div
            className={`w-full h-full rounded-full border-6 border-amber-800 bg-gradient-to-b from-amber-200 via-amber-300 to-yellow-600 shadow-2xl relative overflow-hidden flex items-center justify-center transition-transform active:scale-95 ${
              pot.burned
                ? 'animate-pot-burning'
                : isGoldenTime
                ? 'animate-golden-time'
                : isBoiling
                ? 'animate-pot-boil'
                : 'group-hover:scale-[1.02]'
            }`}
          >
            {/* Inner Pot Rim & Depth */}
            <div className="absolute inset-1.5 rounded-full border-2 border-amber-900/30 overflow-hidden bg-amber-900/10">
              {/* Water / Broth Layer */}
              <div
                className={`absolute bottom-0 left-0 right-0 transition-all duration-200 ${
                  pot.soup
                    ? 'bg-gradient-to-t from-red-700 via-red-600 to-orange-500 opacity-95'
                    : 'bg-gradient-to-t from-amber-400 to-yellow-300 opacity-90'
                }`}
                style={{ height: `${pot.water}%` }}
              >
                {/* Boiling bubbles */}
                {isBoiling && (
                  <div className="absolute inset-0 overflow-hidden pointer-events-none opacity-80">
                    <div className="absolute w-3 h-3 bg-white/40 rounded-full top-2 left-6 animate-ping"></div>
                    <div className="absolute w-2 h-2 bg-white/50 rounded-full top-5 right-8 animate-pulse"></div>
                    <div className="absolute w-2.5 h-2.5 bg-yellow-100/60 rounded-full bottom-3 left-10 animate-bounce"></div>
                  </div>
                )}
              </div>

              {/* Floating Ingredients inside Pot */}
              <div className="absolute inset-0 flex items-center justify-center p-2 z-10 pointer-events-none">
                {pot.water === 0 ? (
                  <div className="text-center opacity-40">
                    <span className="text-3xl filter drop-shadow">🍲</span>
                    <p className="text-[10px] text-amber-900 font-bold mt-0.5">빈 냄비</p>
                  </div>
                ) : (
                  <div className="relative w-full h-full flex flex-wrap items-center justify-center gap-1">
                    {/* Noodle Visual */}
                    {pot.noodle && (
                      <div className="absolute inset-2 flex items-center justify-center">
                        <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full border-2 border-amber-400 bg-amber-300/80 flex items-center justify-center shadow-inner overflow-hidden">
                          <span className="text-2xl sm:text-3xl select-none filter drop-shadow">🍜</span>
                        </div>
                      </div>
                    )}

                    {/* Soup powder particles */}
                    {pot.soup && (
                      <div className="absolute top-3 right-4 text-xs select-none filter drop-shadow">
                        🌶️
                      </div>
                    )}

                    {/* Egg Yolk */}
                    {pot.egg && (
                      <div className="absolute bottom-4 left-4 w-7 h-7 bg-yellow-400 rounded-full border-2 border-amber-600 flex items-center justify-center shadow-md select-none">
                        <div className="w-2 h-2 bg-white/70 rounded-full absolute top-1 left-1"></div>
                      </div>
                    )}

                    {/* Green Onions */}
                    {pot.onion && (
                      <div className="absolute top-4 left-5 flex gap-1 select-none">
                        <span className="text-sm transform rotate-12">🧅</span>
                        <span className="text-xs transform -rotate-12">🌱</span>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Burnt Charcoal Overlay */}
              {pot.burned && (
                <div className="absolute inset-0 bg-black/90 flex flex-col items-center justify-center z-20">
                  <span className="text-3xl sm:text-4xl animate-bounce">💀</span>
                  <span className="text-red-500 font-black text-xs sm:text-sm mt-1 tracking-wider drop-shadow">
                    새까맣게 탄 라면!
                  </span>
                  <span className="text-[10px] text-slate-300">비우기 필수</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Water Level Gauge Bar with Optimal Zone */}
      <div className="w-full my-2 bg-slate-950 p-1.5 rounded-xl border border-slate-700">
        <div className="flex justify-between items-center text-[10px] text-slate-400 mb-1 px-1">
          <span>물 수위: {pot.water}%</span>
          {pot.water > 0 && (
            <span
              className={`font-bold ${
                isWaterOptimal ? 'text-emerald-400' : isWaterLow ? 'text-blue-300' : 'text-orange-400'
              }`}
            >
              {isWaterOptimal ? '✅ 적정 수위' : isWaterLow ? '💧 물 부족' : '⚠️ 물 넘침'}
            </span>
          )}
        </div>
        <div className="relative w-full bg-slate-800 h-2.5 rounded-full overflow-hidden border border-slate-700">
          {/* Ideal zone indicator stripe (70% - 90%) */}
          <div className="absolute top-0 bottom-0 left-[70%] right-[10%] bg-emerald-500/30 z-0"></div>
          {/* Fill Bar */}
          <div
            className={`h-full transition-all duration-150 relative z-10 ${
              isWaterOptimal ? 'bg-emerald-400' : pot.soup ? 'bg-red-500' : 'bg-blue-400'
            }`}
            style={{ width: `${pot.water}%` }}
          ></div>
        </div>
      </div>

      {/* Action Buttons: 손님 전달 (Serve) and 버리기 (Trash) */}
      <div className="w-full flex gap-1.5 mt-1">
        <button
          onClick={(e) => {
            e.stopPropagation();
            onServe(pot.id);
          }}
          disabled={pot.water === 0 && !pot.burned}
          className={`flex-1 py-2 px-2 rounded-xl text-xs sm:text-sm font-black flex items-center justify-center gap-1 transition-all active:scale-95 shadow-md ${
            isGoldenTime
              ? 'bg-gradient-to-r from-amber-400 to-yellow-400 hover:from-amber-300 hover:to-yellow-300 text-slate-900 ring-2 ring-yellow-200 animate-pulse'
              : pot.water > 0
              ? 'bg-emerald-500 hover:bg-emerald-600 text-white'
              : 'bg-slate-700 text-slate-400 cursor-not-allowed opacity-50'
          }`}
        >
          <Send className="w-3.5 h-3.5" />
          손님 전달
        </button>

        <button
          onClick={(e) => {
            e.stopPropagation();
            onClear(pot.id);
          }}
          className="bg-slate-700 hover:bg-red-600 text-slate-200 hover:text-white p-2 rounded-xl transition-all active:scale-95 shadow-md flex items-center justify-center"
          title="냄비 비우기"
          aria-label="냄비 비우기"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
