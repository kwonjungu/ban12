import React from 'react';
import { GameMode } from '../types';
import { GAME_ASSETS } from '../assets';
import { Flame, Play, Sparkles, ChefHat } from 'lucide-react';

interface StartModalProps {
  onStart: (mode: GameMode) => void;
}

export const StartModal: React.FC<StartModalProps> = ({ onStart }) => {
  return (
    <div className="fixed inset-0 bg-pink-950/85 backdrop-blur-sm z-50 flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl p-5 sm:p-7 max-w-lg w-full shadow-2xl border-4 border-pink-400 text-center flex flex-col items-center my-auto">
        {/* Visual Showcase: Sue & Ramen Bowl */}
        <div className="flex items-center justify-center gap-3 sm:gap-4 mb-3">
          <div className="relative">
            <img
              src={GAME_ASSETS.sueChef}
              alt="요리사 슈"
              referrerPolicy="no-referrer"
              className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl border-3 border-pink-300 shadow-lg object-cover bg-pink-50"
            />
            <span className="absolute -bottom-2 -left-1 text-[10px] bg-pink-600 text-white font-black px-2 py-0.5 rounded-full shadow">
              주방장 슈
            </span>
          </div>

          <div className="text-3xl text-pink-400 font-bold">❤️</div>

          <div className="relative">
            <img
              src={GAME_ASSETS.sueRamenBowl}
              alt="황금빛 얼큰 라면"
              referrerPolicy="no-referrer"
              className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl border-3 border-amber-300 shadow-lg object-cover bg-amber-50"
            />
            <span className="absolute -bottom-2 -right-1 text-[10px] bg-amber-600 text-white font-black px-2 py-0.5 rounded-full shadow">
              황금 1,000원
            </span>
          </div>
        </div>

        {/* Title */}
        <h2 className="text-2xl sm:text-3xl font-black text-pink-600 font-jua tracking-wide flex items-center gap-1.5 justify-center">
          <ChefHat className="w-7 h-7 text-pink-500" />
          슈의 라면가게
        </h2>
        <p className="text-xs sm:text-sm text-slate-600 mt-1 font-gamja">
          "어서오세요! 손님들이 기다리는 얼큰하고 맛있는 라면을 끓여주세요!"
        </p>

        {/* Difficulty Selection Buttons */}
        <div className="my-4 w-full space-y-2.5 text-left">
          <div className="text-xs font-black text-pink-600 uppercase tracking-widest text-center">
            🎮 난이도를 선택하면 바로 시작됩니다!
          </div>

          {/* Hard Mode (Recommended Spicy Challenge) */}
          <button
            onClick={() => onStart('hard')}
            className="w-full p-3 sm:p-3.5 rounded-2xl border-2 border-red-400 bg-gradient-to-r from-red-50 to-orange-50 hover:from-red-100 hover:to-orange-100 flex items-center justify-between transition group shadow-md active:scale-98 cursor-pointer ring-2 ring-red-300/60"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-red-600 text-yellow-300 flex items-center justify-center font-black text-xl shadow-xs">
                🔥
              </div>
              <div>
                <div className="font-black text-red-700 text-sm sm:text-base flex items-center gap-1.5">
                  매운맛 모드 (원작 챌린지)
                  <span className="text-[10px] bg-red-600 text-white font-bold px-1.5 py-0.2 rounded shadow-xs">
                    인기
                  </span>
                </div>
                <div className="text-xs text-slate-600">
                  제한시간 80초 | 목표 12,000원 | 빠른 끓기 & 러시타임 발동!
                </div>
              </div>
            </div>
            <div className="w-8 h-8 rounded-full bg-red-200 group-hover:bg-red-300 flex items-center justify-center text-red-800 transition">
              <Play className="w-4 h-4 fill-current ml-0.5" />
            </div>
          </button>

          {/* Normal Mode */}
          <button
            onClick={() => onStart('normal')}
            className="w-full p-3 sm:p-3.5 rounded-2xl border-2 border-pink-300 bg-pink-50/70 hover:bg-pink-100 flex items-center justify-between transition group shadow-xs active:scale-98 cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-500 text-white flex items-center justify-center font-black text-xl shadow-xs">
                😀
              </div>
              <div>
                <div className="font-black text-pink-800 text-sm sm:text-base">
                  보통 모드 (연습용)
                </div>
                <div className="text-xs text-slate-500">
                  제한시간 100초 | 목표 10,000원 | 표준 조리 속도
                </div>
              </div>
            </div>
            <div className="w-8 h-8 rounded-full bg-pink-200 group-hover:bg-pink-300 flex items-center justify-center text-pink-700 transition">
              <Play className="w-4 h-4 fill-current ml-0.5" />
            </div>
          </button>
        </div>

        {/* Recipe Cheat Sheet */}
        <div className="bg-amber-50/90 p-3 sm:p-3.5 rounded-2xl border border-amber-200 text-xs text-amber-900 text-left w-full space-y-1.5">
          <div className="font-black flex items-center gap-1 text-amber-900">
            <Sparkles className="w-3.5 h-3.5 text-amber-600" />
            완벽한 라면 공략법 (한 그릇당 1,000원):
          </div>
          <ol className="list-decimal list-inside space-y-0.5 text-[11px] sm:text-xs text-amber-800">
            <li><b>물 맞추기:</b> 주전자로 냄비에 물을 붓습니다 (녹색 적정선 70~90%).</li>
            <li><b>재료 투하:</b> 물이 끓기 시작하면 <b>면 + 분말 스프 + 계란 + 대파</b>를 모두 넣으세요!</li>
            <li><b>골든타임 서빙:</b> 냄비가 노랗게 번쩍일 때 즉시 <b>[손님 전달]</b> 버튼 터치!</li>
            <li><b>주의:</b> 골든타임을 넘기면 새까맣게 타버립니다. (키보드 1~5번 키 활용)</li>
          </ol>
        </div>
      </div>
    </div>
  );
};
