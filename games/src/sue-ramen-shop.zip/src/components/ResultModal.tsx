import React from 'react';
import { GameMode } from '../types';
import { GAME_ASSETS } from '../assets';
import { RotateCcw, Trophy, Award, Frown } from 'lucide-react';

interface ResultModalProps {
  isSuccess: boolean;
  currentMoney: number;
  targetMoney: number;
  ramenServedCount: number;
  perfectCount: number;
  burnedCount: number;
  mode: GameMode;
  onRestart: () => void;
}

export const ResultModal: React.FC<ResultModalProps> = ({
  isSuccess,
  currentMoney,
  targetMoney,
  ramenServedCount,
  perfectCount,
  burnedCount,
  mode,
  onRestart,
}) => {
  return (
    <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md z-50 flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl p-5 sm:p-7 max-w-md w-full shadow-2xl border-4 border-pink-400 text-center flex flex-col items-center my-auto animate-in fade-in zoom-in duration-200">
        {/* Character Reaction Image */}
        <div className="relative mb-3">
          <img
            src={isSuccess ? GAME_ASSETS.sueSuccess : GAME_ASSETS.sueGameOver}
            alt={isSuccess ? '승리의 슈' : '눈물 흘리는 슈'}
            referrerPolicy="no-referrer"
            className="w-32 h-32 sm:w-36 sm:h-36 rounded-2xl border-4 border-pink-300 shadow-xl object-cover bg-pink-50"
          />
          <div className="absolute -bottom-2 -right-2 p-1.5 rounded-full bg-white shadow-md border-2 border-pink-400">
            {isSuccess ? (
              <Trophy className="w-6 h-6 text-yellow-500 fill-yellow-400" />
            ) : (
              <Frown className="w-6 h-6 text-red-500" />
            )}
          </div>
        </div>

        {/* Title & Status */}
        <h2
          className={`text-2xl sm:text-3xl font-black font-jua tracking-wide ${
            isSuccess ? 'text-emerald-600' : 'text-red-600'
          }`}
        >
          {isSuccess ? '🎉 성공! 전설의 라면 달인 슈!' : '😭 아쉬워요! 시간 초과!'}
        </h2>
        <p className="text-slate-600 text-xs sm:text-sm mt-1 font-gamja">
          {isSuccess
            ? '손님들이 슈의 얼큰하고 쫄깃한 라면에 대만족했어요!'
            : '목표 판매액을 채우지 못해 가게 문을 닫아야 해요...'}
        </p>

        {/* Scorecard */}
        <div className="my-4 bg-pink-50/80 p-3.5 sm:p-4 rounded-2xl border border-pink-200 w-full space-y-2 text-xs sm:text-sm">
          <div className="flex justify-between items-center">
            <span className="text-slate-600 font-bold">최종 판매 수익:</span>
            <span
              className={`font-black text-base sm:text-lg ${
                isSuccess ? 'text-emerald-600' : 'text-pink-600'
              }`}
            >
              {currentMoney.toLocaleString()}원
            </span>
          </div>

          <div className="flex justify-between items-center">
            <span className="text-slate-600">목표 금액:</span>
            <span className="font-bold text-slate-800">{targetMoney.toLocaleString()}원</span>
          </div>

          <div className="border-t border-pink-200 pt-2 flex justify-between items-center">
            <span className="text-slate-600">서빙한 총 라면:</span>
            <span className="font-bold text-blue-600">{ramenServedCount}그릇</span>
          </div>

          <div className="flex justify-between items-center">
            <span className="text-slate-600 flex items-center gap-1">
              <Award className="w-3.5 h-3.5 text-yellow-600" /> 황금 완벽 라면:
            </span>
            <span className="font-bold text-amber-600">{perfectCount}그릇</span>
          </div>

          {burnedCount > 0 && (
            <div className="flex justify-between items-center text-red-500">
              <span>태워버린 냄비:</span>
              <span className="font-bold">{burnedCount}개</span>
            </div>
          )}
        </div>

        {/* Sue's Commentary Message */}
        <div className="text-xs sm:text-sm font-gamja text-pink-900 bg-pink-100/90 p-3 rounded-2xl border border-pink-300 w-full mb-4 leading-relaxed">
          {isSuccess ? (
            mode === 'hard' ? (
              <span>
                "와아아! 매운맛 모드의 그 엄청난 러시타임까지 정복하다니! 당신은 진정한 슈의 라면 명장이에요! ✨"
              </span>
            ) : (
              <span>
                "맛있게 끓여주신 덕분에 오늘 하루 목표를 달성했어요! 다음엔 매운맛 모드도 도전해볼래요? 😊"
              </span>
            )
          ) : (
            <span>
              "너무 아쉬워요! 물 양을 알맞게 맞추고, 4개의 화구를 부지런히 순환시키면 다음엔 꼭 성공할 수 있어요! 힘내요! 🍜"
            </span>
          )}
        </div>

        {/* Restart Button */}
        <button
          onClick={onRestart}
          className="w-full py-3 sm:py-3.5 bg-pink-500 hover:bg-pink-600 active:scale-95 text-white font-black text-base sm:text-lg rounded-2xl shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer"
        >
          <RotateCcw className="w-5 h-5" />
          다시 도전하기
        </button>
      </div>
    </div>
  );
};
