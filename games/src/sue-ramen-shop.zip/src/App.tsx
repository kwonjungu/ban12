/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GameMode, IngredientTool, PotState, GameConfig } from './types';
import { sound } from './utils/audio';
import { Header } from './components/Header';
import { IngredientsShelf } from './components/IngredientsShelf';
import { CookingPot } from './components/CookingPot';
import { StartModal } from './components/StartModal';
import { ResultModal } from './components/ResultModal';
import { SueLiveReaction } from './components/SueLiveReaction';

const CONFIG: Record<GameMode, GameConfig> = {
  normal: {
    totalTime: 100,
    targetMoney: 10000,
    waterSpeed: 20,
    boilSpeed: 1.0,
    burnTimeLimit: 5.0,
    rushHour: false,
  },
  hard: {
    totalTime: 80,
    targetMoney: 12000,
    waterSpeed: 25,
    boilSpeed: 1.35,
    burnTimeLimit: 2.8,
    rushHour: true,
  },
};

const INITIAL_POTS: PotState[] = [
  { id: 0, water: 0, noodle: false, soup: false, egg: false, onion: false, cookTime: 0, burned: false },
  { id: 1, water: 0, noodle: false, soup: false, egg: false, onion: false, cookTime: 0, burned: false },
  { id: 2, water: 0, noodle: false, soup: false, egg: false, onion: false, cookTime: 0, burned: false },
  { id: 3, water: 0, noodle: false, soup: false, egg: false, onion: false, cookTime: 0, burned: false },
];

export default function App() {
  const [gameActive, setGameActive] = useState(false);
  const [showStartModal, setShowStartModal] = useState(true);
  const [showResultModal, setShowResultModal] = useState(false);

  const [mode, setMode] = useState<GameMode>('hard');
  const [activeTool, setActiveTool] = useState<IngredientTool | null>('water');
  const [currentMoney, setCurrentMoney] = useState(0);
  const [timeRemaining, setTimeRemaining] = useState(80);
  const [pots, setPots] = useState<PotState[]>(INITIAL_POTS);

  const [isRushActive, setIsRushActive] = useState(false);
  const [ramenServedCount, setRamenServedCount] = useState(0);
  const [perfectCount, setPerfectCount] = useState(0);
  const [burnedCount, setBurnedCount] = useState(0);

  const [audioEnabled, setAudioEnabled] = useState(true);
  const [sueMessage, setSueMessage] = useState<string>('어서오세요! 주전자로 물을 먼저 부어주세요~');
  const [floatingFeedback, setFloatingFeedback] = useState<string | null>(null);

  const timerRef = useRef<number | null>(null);
  const feedbackTimeoutRef = useRef<number | null>(null);

  // Show floating score feedback
  const triggerFeedback = useCallback((text: string) => {
    setFloatingFeedback(text);
    if (feedbackTimeoutRef.current) clearTimeout(feedbackTimeoutRef.current);
    feedbackTimeoutRef.current = window.setTimeout(() => {
      setFloatingFeedback(null);
    }, 1800);
  }, []);

  // Clear pot helper
  const clearPot = useCallback((id: number, notify = true) => {
    setPots((prev) =>
      prev.map((p) =>
        p.id === id
          ? {
              id,
              water: 0,
              noodle: false,
              soup: false,
              egg: false,
              onion: false,
              cookTime: 0,
              burned: false,
            }
          : p
      )
    );
    if (notify) {
      triggerFeedback('🗑️ 냄비를 비웠습니다');
      setSueMessage('깨끗해진 냄비에 다시 물을 채워볼까요?');
    }
  }, [triggerFeedback]);

  // Start game handler
  const handleStartGame = useCallback((selectedMode: GameMode) => {
    const cfg = CONFIG[selectedMode];
    setMode(selectedMode);
    setCurrentMoney(0);
    setRamenServedCount(0);
    setPerfectCount(0);
    setBurnedCount(0);
    setTimeRemaining(cfg.totalTime);
    setIsRushActive(false);
    setPots(INITIAL_POTS.map((p) => ({ ...p })));
    setActiveTool('water');
    setShowStartModal(false);
    setShowResultModal(false);
    setGameActive(true);
    setSueMessage('주전자(1번)를 들고 냄비를 클릭해 물을 부어주세요!');
    sound.playClick();
  }, []);

  // End game handler
  const handleEndGame = useCallback(() => {
    setGameActive(false);
    setIsRushActive(false);
    if (timerRef.current) clearInterval(timerRef.current);
    setShowResultModal(true);
  }, []);

  // Pot Interaction (Clicking on a pot with active tool)
  const handlePotInteraction = useCallback(
    (potId: number) => {
      if (!gameActive) return;

      setPots((prevPots) => {
        const pot = prevPots[potId];
        if (!pot) return prevPots;

        if (pot.burned) {
          triggerFeedback('❌ 탄 라면은 비워야 합니다!');
          setSueMessage('탄 라면은 버리고 새로 끓여야 해요!');
          return prevPots;
        }

        if (!activeTool) {
          triggerFeedback('💡 위에서 재료를 먼저 선택하세요!');
          return prevPots;
        }

        // Apply water
        if (activeTool === 'water') {
          if (pot.water >= 100) {
            triggerFeedback('💧 물이 가득 찼습니다!');
            return prevPots;
          }
          sound.playPouring();
          const newWater = Math.min(100, pot.water + CONFIG[mode].waterSpeed);
          setSueMessage('물이 끓으면 면과 스프를 퐁당 넣어주세요!');
          return prevPots.map((p) => (p.id === potId ? { ...p, water: newWater } : p));
        }

        // Apply Ingredients (Require water first)
        if (pot.water === 0) {
          triggerFeedback('⚠️ 주전자로 물부터 먼저 부어주세요!');
          setSueMessage('빈 냄비에는 재료를 넣을 수 없어요! 물 먼저~');
          return prevPots;
        }

        let updated = false;
        const newPot = { ...pot };

        if (activeTool === 'noodle' && !newPot.noodle) {
          newPot.noodle = true;
          updated = true;
        } else if (activeTool === 'soup' && !newPot.soup) {
          newPot.soup = true;
          updated = true;
        } else if (activeTool === 'egg' && !newPot.egg) {
          newPot.egg = true;
          updated = true;
        } else if (activeTool === 'onion' && !newPot.onion) {
          newPot.onion = true;
          updated = true;
        }

        if (updated) {
          sound.playIngredient();
          if (newPot.noodle && newPot.soup && newPot.egg && newPot.onion) {
            setSueMessage('모든 재료 투하 완료! 골든타임에 손님에게 드려요!');
          }
          return prevPots.map((p) => (p.id === potId ? newPot : p));
        }

        return prevPots;
      });
    },
    [activeTool, gameActive, mode, triggerFeedback]
  );

  // Serve Ramen to customer
  const handleServeRamen = useCallback(
    (potId: number) => {
      if (!gameActive) return;

      const pot = pots[potId];
      if (!pot) return;

      if (pot.burned) {
        triggerFeedback('💀 탄 라면은 손님께 드릴 수 없어요!');
        sound.playBurn();
        setSueMessage('탄 라면을 드리면 큰일나요! 휴지통으로 버려주세요!');
        return;
      }

      if (pot.water === 0 || (!pot.noodle && !pot.soup)) {
        triggerFeedback('⚠️ 라면 모양새가 갖춰지지 않았습니다!');
        setSueMessage('면과 스프는 기본으로 꼭 들어가야 해요!');
        return;
      }

      // Quality evaluation
      let waterQuality: 'good' | 'too_little' | 'too_much' = 'good';
      if (pot.water < 60) waterQuality = 'too_little';
      else if (pot.water > 95) waterQuality = 'too_much';

      let cookQuality: 'raw' | 'perfect' | 'overcooked' = 'raw';
      if (pot.cookTime >= 6.5 && pot.cookTime <= 10.5) cookQuality = 'perfect';
      else if (pot.cookTime > 10.5) cookQuality = 'overcooked';

      let earnings = 0;
      let feedback = '';
      let isPerfect = false;

      if (pot.noodle && pot.soup && pot.egg && pot.onion && waterQuality === 'good' && cookQuality === 'perfect') {
        earnings = 1000;
        feedback = '✨ 완벽한 황금 라면! +1,000원';
        isPerfect = true;
        setSueMessage('대박! 완벽한 황금비율 라면이에요! 손님이 대만족! 💖');
      } else if (pot.noodle && pot.soup && cookQuality === 'perfect') {
        earnings = 700;
        feedback = '👍 맛있는 라면! +700원';
        setSueMessage('맛있게 잘 끓였어요! 파와 계란까지 넣으면 1,000원!');
      } else if (waterQuality === 'too_much') {
        earnings = 400;
        feedback = '💧 물이 많아 싱거운 라면... +400원';
        setSueMessage('물이 한강이에요~ 다음엔 녹색 적정선에 맞춰보세요!');
      } else if (waterQuality === 'too_little') {
        earnings = 300;
        feedback = '🔥 물이 없어 짜고 졸아든 라면... +300원';
        setSueMessage('물이 너무 적어서 짜요! 물을 더 채워주세요~');
      } else if (cookQuality === 'raw') {
        earnings = 300;
        feedback = '🧊 면이 덜 익은 안끓인 라면... +300원';
        setSueMessage('면이 과자처럼 딱딱해요! 보글보글 끓여주세요!');
      } else {
        earnings = 500;
        feedback = '🍲 평범한 라면! +500원';
        setSueMessage('나쁘지 않지만 조금 더 완벽한 타이밍을 노려봐요!');
      }

      setCurrentMoney((prev) => prev + earnings);
      setRamenServedCount((prev) => prev + 1);
      if (isPerfect) setPerfectCount((prev) => prev + 1);

      sound.playSuccess();
      triggerFeedback(feedback);
      clearPot(potId, false);
    },
    [clearPot, gameActive, pots, triggerFeedback]
  );

  // Keyboard Shortcuts (1-5 for ingredient tools)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!gameActive) return;
      if (e.key === '1') setActiveTool('water');
      else if (e.key === '2') setActiveTool('noodle');
      else if (e.key === '3') setActiveTool('soup');
      else if (e.key === '4') setActiveTool('egg');
      else if (e.key === '5') setActiveTool('onion');
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [gameActive]);

  // Main Game Loop Tick (200ms)
  useEffect(() => {
    if (!gameActive) return;

    const interval = window.setInterval(() => {
      setTimeRemaining((prevTime) => {
        const nextTime = Math.max(0, prevTime - 0.2);
        if (nextTime <= 0) {
          handleEndGame();
          return 0;
        }

        // Check Rush Hour trigger in hard mode (between 40s and 25s)
        if (CONFIG[mode].rushHour) {
          if (nextTime <= 40 && nextTime > 25 && !isRushActive) {
            setIsRushActive(true);
            sound.playRushAlert();
            triggerFeedback('🚨 [러시 타임!] 손님 폭주! 1.5배 빨리 끓습니다!');
            setSueMessage('손님들이 우르르 몰려와요! 냄비가 엄청 빨리 끓어요!');
          } else if (nextTime <= 25 && isRushActive) {
            setIsRushActive(false);
            setSueMessage('휴우~ 한바탕 러시타임이 지나갔어요! 마지막 스퍼트!');
          }
        }

        return nextTime;
      });

      // Update pots cooking progression
      const currentBoilSpeed = CONFIG[mode].boilSpeed * (isRushActive ? 1.5 : 1.0);
      const burnLimit = 8.0 + CONFIG[mode].burnTimeLimit;

      setPots((prevPots) =>
        prevPots.map((pot) => {
          if (pot.water > 0 && !pot.burned) {
            const nextCook = pot.cookTime + 0.2 * currentBoilSpeed;

            // Boil sound
            if (nextCook > 2.0 && Math.random() < 0.12) {
              sound.playBoilBubble();
            }

            // Burn check
            if (nextCook >= burnLimit) {
              sound.playBurn();
              setBurnedCount((c) => c + 1);
              triggerFeedback(`💀 화구 #${pot.id + 1} 라면이 타버렸습니다!`);
              setSueMessage('앗! 냄비를 깜빡해서 타버렸어요! 얼른 비워주세요!');
              return { ...pot, cookTime: nextCook, burned: true };
            }

            return { ...pot, cookTime: nextCook };
          }
          return pot;
        })
      );
    }, 200);

    timerRef.current = interval;
    return () => clearInterval(interval);
  }, [gameActive, handleEndGame, isRushActive, mode, triggerFeedback]);

  const targetMoney = CONFIG[mode].targetMoney;
  const isSuccess = currentMoney >= targetMoney;

  return (
    <div className="min-h-screen bg-pink-100 flex flex-col items-center justify-center p-2 sm:p-4 text-slate-800 font-jua">
      {/* Main Game Shell Card */}
      <main
        className={`w-full max-w-5xl bg-white rounded-3xl shadow-2xl border-4 border-pink-300 overflow-hidden flex flex-col relative transition-all duration-300 ${
          isRushActive ? 'animate-rush-glow ring-4 ring-orange-500' : ''
        }`}
      >
        {/* Header HUD */}
        <Header
          currentMoney={currentMoney}
          targetMoney={targetMoney}
          timeRemaining={timeRemaining}
          totalTime={CONFIG[mode].totalTime}
          mode={mode}
          audioEnabled={audioEnabled}
          onToggleAudio={() => {
            const next = !audioEnabled;
            setAudioEnabled(next);
            sound.enabled = next;
          }}
          onOpenRules={() => setShowStartModal(true)}
        />

        {/* Rush Hour Warning Banner */}
        {isRushActive && (
          <div className="bg-gradient-to-r from-red-600 via-orange-500 to-red-600 text-white font-black text-center py-2 px-4 text-xs sm:text-base tracking-widest uppercase shadow-inner animate-pulse flex items-center justify-center gap-2">
            <span>🚨</span>
            <span>[러시 타임 발동!] 손님 폭주! 냄비가 1.5배 빠르게 끓습니다!</span>
            <span>🚨</span>
          </div>
        )}

        {/* Main Cooking Playfield */}
        <div className="p-3 sm:p-5 bg-gradient-to-b from-amber-50/60 to-pink-50/30 flex flex-col gap-4 flex-1">
          {/* Ingredients Shelf (Tools Selector) */}
          <IngredientsShelf
            activeTool={activeTool}
            onSelectTool={(tool) => {
              setActiveTool(tool);
              sound.playClick();
            }}
          />

          {/* 4 Cooking Pots Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
            {pots.map((pot, idx) => (
              <CookingPot
                key={pot.id}
                pot={pot}
                potIndex={idx}
                burnLimit={8.0 + CONFIG[mode].burnTimeLimit}
                onPotClick={handlePotInteraction}
                onServe={handleServeRamen}
                onClear={clearPot}
              />
            ))}
          </div>

          {/* Sue Live Reaction & Dialogue Bar */}
          <SueLiveReaction message={sueMessage} floatingFeedback={floatingFeedback} />
        </div>
      </main>

      {/* Start Modal (Difficulty Select & Rules) */}
      {showStartModal && <StartModal onStart={handleStartGame} />}

      {/* Result Modal (Victory or Game Over) */}
      {showResultModal && (
        <ResultModal
          isSuccess={isSuccess}
          currentMoney={currentMoney}
          targetMoney={targetMoney}
          ramenServedCount={ramenServedCount}
          perfectCount={perfectCount}
          burnedCount={burnedCount}
          mode={mode}
          onRestart={() => {
            setShowResultModal(false);
            setShowStartModal(true);
          }}
        />
      )}
    </div>
  );
}
