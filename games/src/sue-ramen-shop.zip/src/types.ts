export type GameMode = 'normal' | 'hard';

export type IngredientTool = 'water' | 'noodle' | 'soup' | 'egg' | 'onion';

export interface PotState {
  id: number;
  water: number; // 0 to 100
  noodle: boolean;
  soup: boolean;
  egg: boolean;
  onion: boolean;
  cookTime: number; // in seconds
  burned: boolean;
}

export interface GameConfig {
  totalTime: number;
  targetMoney: number;
  waterSpeed: number; // % added per pour click
  boilSpeed: number; // multiplier
  burnTimeLimit: number; // seconds after golden time before burning
  rushHour: boolean;
}

export interface ServeResult {
  earnings: number;
  message: string;
  isPerfect: boolean;
  potId: number;
}
