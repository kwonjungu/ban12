import React, { useEffect, useRef, useState, useCallback } from 'react';
import { Volume2, VolumeX, Shield, Sparkles, Sword, Flame, RotateCcw, Play, ArrowLeft, Home } from 'lucide-react';
import { Note, FloatingText, Particle, Judgement } from './types.ts';
import {
  BOSS_LIST,
  DIFF_SETTINGS,
  SECTIONS,
  LANE_ICONS,
  LANE_LABELS,
  LANE_COLORS,
  LANE_SHADOWS,
  LANE_KEYS,
  KEY_CODE_MAP,
  arenaBg,
} from './data/bossData.ts';
import { audio } from './utils/audio.ts';
import { BossThreeScene } from './components/BossThreeScene.ts';

const LEAD_IN = 2.5;
const BASE_BOSS_HP = 2400;

export default function App() {
  const [selectedDiff, setSelectedDiff] = useState<string>('boss3');
  const [gameState, setGameState] = useState<'start' | 'play' | 'result'>('start');
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [bossHp, setBossHp] = useState<number>(BASE_BOSS_HP);
  const [maxBossHp, setMaxBossHp] = useState<number>(BASE_BOSS_HP);
  const [playerHp, setPlayerHp] = useState<number>(3);
  const [maxHearts, setMaxHearts] = useState<number>(3);
  const [score, setScore] = useState<number>(0);
  const [combo, setCombo] = useState<number>(0);
  const [maxCombo, setMaxCombo] = useState<number>(0);
  const [bossPhase, setBossPhase] = useState<number>(1);
  const [bossQuote, setBossQuote] = useState<string>('');
  const [showQuote, setShowQuote] = useState<boolean>(false);
  const [activePads, setActivePads] = useState<boolean[]>([false, false, false, false]);

  // Results
  const [results, setResults] = useState<{
    victory: boolean;
    perfect: number;
    good: number;
    miss: number;
    score: number;
    maxCombo: number;
    grade: string;
    gradeColor: string;
  }>({
    victory: false,
    perfect: 0,
    good: 0,
    miss: 0,
    score: 0,
    maxCombo: 0,
    grade: 'S',
    gradeColor: '#00f5d4',
  });

  const [bestScore, setBestScore] = useState<number>(() => {
    try {
      return parseInt(localStorage.getItem('rhythm_boss_highscore') || '0', 10);
    } catch {
      return 0;
    }
  });

  // DOM Refs
  const fieldRef = useRef<HTMLDivElement>(null);
  const threeCanvasRef = useRef<HTMLCanvasElement>(null);
  const canvas2dRef = useRef<HTMLCanvasElement>(null);
  const threeSceneRef = useRef<BossThreeScene | null>(null);

  // Runtime Game Engine Refs
  const gameLoopRef = useRef<number | null>(null);
  const notesRef = useRef<Note[]>([]);
  const beatsRef = useRef<Array<{ t: number; num: number }>>([]);
  const beatIdxRef = useRef<number>(0);
  const songTimeRef = useRef<number>(0);
  const songEndRef = useRef<number>(0);
  const bossHpRef = useRef<number>(BASE_BOSS_HP);
  const playerHpRef = useRef<number>(3);
  const scoreRef = useRef<number>(0);
  const comboRef = useRef<number>(0);
  const maxComboRef = useRef<number>(0);
  const bossPhaseRef = useRef<number>(1);
  const cPerfectRef = useRef<number>(0);
  const cGoodRef = useRef<number>(0);
  const cMissRef = useRef<number>(0);
  const bossHurtTimerRef = useRef<number>(0);
  const screenShakeRef = useRef<number>(0);
  const floatTextsRef = useRef<FloatingText[]>([]);
  const particlesRef = useRef<Particle[]>([]);
  const laneGlowRef = useRef<number[]>([0, 0, 0, 0]);
  const judgeTextRef = useRef<Judgement | null>(null);
  const textIdCounter = useRef<number>(0);
  const currentBpmRef = useRef<number>(120);
  const enragedTriggeredRef = useRef<boolean>(false);

  const currentBoss = BOSS_LIST[bossPhase] || BOSS_LIST[0];

  // Speech bubble helper
  const triggerBossQuote = useCallback((msg: string) => {
    setBossQuote(msg);
    setShowQuote(true);
    setTimeout(() => {
      setShowQuote(false);
    }, 2200);
  }, []);

  // Build song pattern & beats for specific boss
  const buildSong = useCallback((bossIdx: number, speedMult: number) => {
    const sec = SECTIONS[bossIdx] || SECTIONS[0];
    const bpm = sec.bpm;
    currentBpmRef.current = bpm;
    const beatDur = 60 / bpm;
    const slot = beatDur / 2;
    const approach = (beatDur * 2.2) / speedMult;

    const patternList: Note[] = [];
    const beatsList: Array<{ t: number; num: number }> = [];

    let t = LEAD_IN;
    let bCount = 0;

    const loopCount = bossIdx >= 4 ? 4 : (bossIdx >= 2 ? 3 : 2);

    for (let loop = 0; loop < loopCount; loop++) {
      for (let b = 0; b < sec.bars.length; b++) {
        const bar = sec.bars[b];
        for (let beat = 0; beat < 4; beat++) {
          beatsList.push({ t: t + beat * beatDur, num: bCount++ });
        }
        for (let i = 0; i < 8; i++) {
          const ch = bar.charAt(i);
          if (ch >= '1' && ch <= '4') {
            const lane = ch.charCodeAt(0) - 49;
            patternList.push({
              t: t + i * slot,
              lane,
              approach,
              icon: LANE_ICONS[lane],
              judged: false,
            });
          }
        }
        t += beatDur * 4;
      }
    }

    patternList.sort((a, b) => a.t - b.t);
    songEndRef.current = t + 2.0;
    notesRef.current = patternList;
    beatsRef.current = beatsList;
  }, []);

  // Set active boss visuals for the selected boss
  const applyBossPhase = useCallback(
    (bossIdx: number) => {
      const b = BOSS_LIST[bossIdx];
      if (!b) return;
      bossPhaseRef.current = bossIdx;
      setBossPhase(bossIdx);

      if (threeSceneRef.current) {
        threeSceneRef.current.switchBossModel(bossIdx, b.color);
        threeSceneRef.current.setHoloImage(b.image);
      }
      triggerBossQuote(b.quote);
    },
    [triggerBossQuote]
  );

  // Check boss low-HP enrage (maintains the exact same boss, does NOT change boss!)
  const checkEnragedState = useCallback(() => {
    if (!enragedTriggeredRef.current && bossHpRef.current / maxBossHp <= 0.5) {
      enragedTriggeredRef.current = true;
      audio.sndRoar();
      screenShakeRef.current = 0.6;
      const b = BOSS_LIST[bossPhaseRef.current];
      triggerBossQuote(`${b.name}: 크윽... 진정한 힘을 보여주마! 💢`);
    }
  }, [maxBossHp, triggerBossQuote]);

  // End Game
  const endRaid = useCallback(
    (victory: boolean) => {
      setGameState('result');
      const cfg = DIFF_SETTINGS[selectedDiff] || DIFF_SETTINGS.boss3;

      let grade = 'FAILED';
      let gradeColor = '#ff3b70';

      if (victory) {
        audio.sndWin();
        if (playerHpRef.current === cfg.hearts) {
          grade = 'PERFECT';
          gradeColor = '#00f5d4';
        } else if (playerHpRef.current >= cfg.hearts - 1) {
          grade = 'GOOD';
          gradeColor = '#ffee38';
        } else {
          grade = 'CLEAR';
          gradeColor = '#ff7700';
        }
      } else {
        audio.sndRoar();
      }

      setResults({
        victory,
        perfect: cPerfectRef.current,
        good: cGoodRef.current,
        miss: cMissRef.current,
        score: scoreRef.current,
        maxCombo: maxComboRef.current,
        grade,
        gradeColor,
      });

      if (scoreRef.current > bestScore) {
        setBestScore(scoreRef.current);
        try {
          localStorage.setItem('rhythm_boss_highscore', scoreRef.current.toString());
        } catch {
          // storage fallback
        }
      }
    },
    [selectedDiff, bestScore]
  );

  // Miss note
  const missNote = useCallback(() => {
    cMissRef.current++;
    comboRef.current = 0;
    setCombo(0);

    playerHpRef.current = Math.max(0, playerHpRef.current - 1);
    setPlayerHp(playerHpRef.current);

    judgeTextRef.current = { text: 'MISS!', color: '#ff3b70', life: 0.5 };
    screenShakeRef.current = 0.35;
    audio.sndMiss();

    if (playerHpRef.current <= 0) {
      endRaid(false);
    }
  }, [endRaid]);

  // Lane input hit
  const hitLane = useCallback(
    (lane: number) => {
      if (gameState !== 'play') return;
      laneGlowRef.current[lane] = 1;

      const songTime = songTimeRef.current;
      const notes = notesRef.current;

      let best: Note | null = null;
      let bestD = 999;

      for (let i = 0; i < notes.length; i++) {
        const n = notes[i];
        if (n.judged || n.lane !== lane) continue;
        const d = Math.abs(n.t - songTime);
        if (d < bestD) {
          bestD = d;
          best = n;
        }
      }

      if (!best || bestD > 0.22) return;

      best.judged = true;
      const isCrit = comboRef.current > 10;
      let dmg = 0;

      const field = fieldRef.current;
      const W = field ? field.clientWidth : 320;
      const H = field ? field.clientHeight : 400;

      const cfg = DIFF_SETTINGS[selectedDiff] || DIFF_SETTINGS.boss3;
      const diffPower = 1 + (cfg.hpMult >= 30 ? 5.5 : (cfg.hpMult >= 10 ? 3.2 : (cfg.hpMult >= 5 ? 1.8 : (cfg.hpMult >= 2 ? 1.2 : 0))));

      if (bestD <= 0.1) {
        cPerfectRef.current++;
        comboRef.current++;
        const comboBonus = Math.min(comboRef.current, 50) * 3;
        dmg = Math.round((45 + comboBonus) * diffPower);
        if (isCrit) dmg = Math.round(dmg * 1.6);

        bossHpRef.current = Math.max(0, bossHpRef.current - dmg);
        setBossHp(bossHpRef.current);

        scoreRef.current += Math.round(150 * (1 + comboRef.current / 50));
        setScore(scoreRef.current);
        setCombo(comboRef.current);

        judgeTextRef.current = { text: 'PERFECT!', color: '#00f5d4', life: 0.5 };

        // Floating damage text
        textIdCounter.current++;
        floatTextsRef.current.push({
          id: textIdCounter.current,
          x: W / 2 + (Math.random() - 0.5) * 70,
          y: H * 0.22 + (Math.random() - 0.5) * 20,
          txt: `-${dmg.toLocaleString()}${isCrit ? ' CRITICAL!' : ''}`,
          color: isCrit ? '#ffee38' : '#00f5d4',
          life: 1.0,
          vy: -60 - Math.random() * 25,
          scale: isCrit ? 1.4 : 1.0,
        });

        // Lane audio
        if (lane === 0) audio.sndSlash();
        else if (lane === 1) audio.sndMagic();
        else if (lane === 2) audio.sndShield();
        else audio.sndBlast();

        audio.sndBossHit();
        bossHurtTimerRef.current = 0.2;

        // Particle explosion
        for (let i = 0; i < 14; i++) {
          const angle = Math.random() * Math.PI * 2;
          const speed = 90 + Math.random() * 120;
          particlesRef.current.push({
            x: W / 2,
            y: H * 0.22,
            vx: Math.cos(angle) * speed,
            vy: Math.sin(angle) * speed,
            life: 0.6,
            color: LANE_COLORS[lane],
            size: 3 + Math.random() * 4,
          });
        }
      } else {
        cGoodRef.current++;
        comboRef.current++;
        dmg = Math.round(22 * diffPower);
        bossHpRef.current = Math.max(0, bossHpRef.current - dmg);
        setBossHp(bossHpRef.current);

        scoreRef.current += 70;
        setScore(scoreRef.current);
        setCombo(comboRef.current);

        judgeTextRef.current = { text: 'GOOD', color: '#ffee38', life: 0.5 };

        textIdCounter.current++;
        floatTextsRef.current.push({
          id: textIdCounter.current,
          x: W / 2 + (Math.random() - 0.5) * 60,
          y: H * 0.22 + (Math.random() - 0.5) * 20,
          txt: `-${dmg.toLocaleString()}`,
          color: '#ffffff',
          life: 1.0,
          vy: -50 - Math.random() * 20,
          scale: 1.0,
        });

        audio.sndSlash();
      }

      if (comboRef.current > maxComboRef.current) {
        maxComboRef.current = comboRef.current;
        setMaxCombo(comboRef.current);
      }

      // Check boss low-HP enrage without changing to a different boss
      checkEnragedState();

      if (bossHpRef.current <= 0) {
        endRaid(true);
      }
    },
    [gameState, selectedDiff, checkEnragedState, endRaid]
  );

  // Start Raid
  const startRaid = useCallback(() => {
    audio.init();

    const cfg = DIFF_SETTINGS[selectedDiff] || DIFF_SETTINGS.boss3;
    const initialBossHp = cfg.hp || Math.round(BASE_BOSS_HP * cfg.hpMult);

    bossHpRef.current = initialBossHp;
    setMaxBossHp(initialBossHp);
    setBossHp(initialBossHp);

    playerHpRef.current = cfg.hearts;
    setMaxHearts(cfg.hearts);
    setPlayerHp(cfg.hearts);

    scoreRef.current = 0;
    setScore(0);
    comboRef.current = 0;
    setCombo(0);
    maxComboRef.current = 0;
    setMaxCombo(0);

    cPerfectRef.current = 0;
    cGoodRef.current = 0;
    cMissRef.current = 0;
    songTimeRef.current = 0;
    beatIdxRef.current = 0;
    bossHurtTimerRef.current = 0;
    screenShakeRef.current = 0;
    enragedTriggeredRef.current = false;

    floatTextsRef.current = [];
    particlesRef.current = [];
    judgeTextRef.current = null;
    laneGlowRef.current = [0, 0, 0, 0];

    // Lock strictly to the selected difficulty's boss
    buildSong(cfg.bossIdx, cfg.speedMult);
    applyBossPhase(cfg.bossIdx);

    setGameState('play');
  }, [selectedDiff, buildSong, applyBossPhase]);

  // Initialize Three.js Scene
  useEffect(() => {
    if (!threeCanvasRef.current || !fieldRef.current) return;
    const rect = fieldRef.current.getBoundingClientRect();
    const w = Math.max(120, rect.width);
    const h = Math.max(160, rect.height);

    const scene = new BossThreeScene(threeCanvasRef.current, w, h);
    threeSceneRef.current = scene;

    const initialBoss = BOSS_LIST[bossPhaseRef.current] || BOSS_LIST[0];
    scene.switchBossModel(bossPhaseRef.current, initialBoss.color);
    scene.setHoloImage(initialBoss.image);

    const handleResize = () => {
      if (!fieldRef.current || !canvas2dRef.current || !threeSceneRef.current) return;
      const r = fieldRef.current.getBoundingClientRect();
      const nw = Math.max(120, r.width);
      const nh = Math.max(160, r.height);
      const dpr = Math.min(window.devicePixelRatio || 1, 2);

      const cv = canvas2dRef.current;
      cv.width = Math.round(nw * dpr);
      cv.height = Math.round(nh * dpr);
      const ctx = cv.getContext('2d');
      if (ctx) ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

      threeSceneRef.current.resize(nw, nh);
    };

    window.addEventListener('resize', handleResize);
    handleResize();

    return () => {
      window.removeEventListener('resize', handleResize);
      scene.destroy();
      threeSceneRef.current = null;
    };
  }, []);

  // Main Loop
  useEffect(() => {
    let lastTime = performance.now();

    const loop = (now: number) => {
      const dt = Math.min((now - lastTime) / 1000, 0.1);
      lastTime = now;

      screenShakeRef.current = Math.max(0, screenShakeRef.current - dt * 3);
      bossHurtTimerRef.current = Math.max(0, bossHurtTimerRef.current - dt);
      for (let i = 0; i < 4; i++) {
        laneGlowRef.current[i] = Math.max(0, laneGlowRef.current[i] - dt * 4);
      }

      // Render 3D Scene
      if (threeSceneRef.current) {
        threeSceneRef.current.render(bossPhaseRef.current, bossHurtTimerRef.current);
      }

      // Floating text update
      for (let f = floatTextsRef.current.length - 1; f >= 0; f--) {
        const ft = floatTextsRef.current[f];
        ft.y += ft.vy * dt;
        ft.life -= dt * 1.5;
        if (ft.life <= 0) floatTextsRef.current.splice(f, 1);
      }

      // Particles update
      for (let p = particlesRef.current.length - 1; p >= 0; p--) {
        const pt = particlesRef.current[p];
        pt.x += pt.vx * dt;
        pt.y += pt.vy * dt;
        pt.life -= dt * 2;
        if (pt.life <= 0) particlesRef.current.splice(p, 1);
      }

      // Judgement text update
      if (judgeTextRef.current) {
        judgeTextRef.current.life -= dt;
        if (judgeTextRef.current.life <= 0) judgeTextRef.current = null;
      }

      // Gameplay updates
      if (gameState === 'play') {
        songTimeRef.current += dt;
        const sTime = songTimeRef.current;

        // Metronome / drum beats (BGM synthesis)
        const beats = beatsRef.current;
        while (beatIdxRef.current < beats.length && sTime >= beats[beatIdxRef.current].t) {
          audio.playDrumBeat(beats[beatIdxRef.current].num, currentBpmRef.current);
          beatIdxRef.current++;
        }

        // Check miss notes
        const notes = notesRef.current;
        for (let n = 0; n < notes.length; n++) {
          const no = notes[n];
          if (!no.judged && sTime > no.t + 0.22) {
            no.judged = true;
            missNote();
          }
        }

        // Song end check
        if (sTime >= songEndRef.current && bossHpRef.current > 0) {
          endRaid(false);
        }
      }

      // 2D Canvas Render
      const cv = canvas2dRef.current;
      const field = fieldRef.current;
      if (cv && field) {
        const ctx = cv.getContext('2d');
        if (ctx) {
          const W = field.clientWidth;
          const H = field.clientHeight;
          const judgeY = H - 54;

          ctx.clearRect(0, 0, W, H);
          ctx.save();

          if (screenShakeRef.current > 0) {
            ctx.translate(
              (Math.random() - 0.5) * 12 * screenShakeRef.current,
              (Math.random() - 0.5) * 12 * screenShakeRef.current
            );
          }

          // 4 Lanes
          const lw = W / 4;
          for (let i = 0; i < 4; i++) {
            const x = i * lw;
            ctx.strokeStyle = 'rgba(255,255,255,0.08)';
            ctx.lineWidth = 1;
            ctx.strokeRect(x, 0, lw, H);

            if (laneGlowRef.current[i] > 0) {
              ctx.fillStyle = LANE_COLORS[i];
              ctx.globalAlpha = laneGlowRef.current[i] * 0.25;
              ctx.fillRect(x, 0, lw, H);
              ctx.globalAlpha = 1.0;
            }
          }

          // Judgement Line
          ctx.strokeStyle = 'rgba(255, 255, 255, 0.85)';
          ctx.lineWidth = 3;
          ctx.beginPath();
          ctx.moveTo(0, judgeY);
          ctx.lineTo(W, judgeY);
          ctx.stroke();

          // Target Hit Rings
          for (let j = 0; j < 4; j++) {
            const cx = (j + 0.5) * lw;
            ctx.strokeStyle = LANE_COLORS[j];
            ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.arc(cx, judgeY, 24, 0, Math.PI * 2);
            ctx.stroke();

            // Inner subtle pulse
            ctx.fillStyle = LANE_COLORS[j];
            ctx.globalAlpha = 0.15;
            ctx.beginPath();
            ctx.arc(cx, judgeY, 20, 0, Math.PI * 2);
            ctx.fill();
            ctx.globalAlpha = 1.0;
          }

          // Falling Rhythm Notes
          if (gameState === 'play') {
            const notes = notesRef.current;
            const sTime = songTimeRef.current;

            for (let k = 0; k < notes.length; k++) {
              const n = notes[k];
              if (n.judged) continue;
              const left = n.t - sTime;
              const p = left / n.approach; // 1 = top spawn, 0 = judge line
              if (p > 1.1 || p < -0.3) continue;

              const ny = judgeY - p * (judgeY - H * 0.35);
              const nx = (n.lane + 0.5) * lw;

              ctx.save();
              ctx.font = '38px -apple-system, sans-serif';
              ctx.textAlign = 'center';
              ctx.textBaseline = 'middle';
              ctx.shadowColor = LANE_COLORS[n.lane];
              ctx.shadowBlur = 18;
              ctx.fillText(n.icon, nx, ny);
              ctx.restore();
            }
          }

          // Particles
          const particles = particlesRef.current;
          for (let pt = 0; pt < particles.length; pt++) {
            const pObj = particles[pt];
            ctx.fillStyle = pObj.color;
            ctx.beginPath();
            ctx.arc(pObj.x, pObj.y, pObj.size, 0, Math.PI * 2);
            ctx.fill();
          }

          // Floating damage numbers
          const floatTexts = floatTextsRef.current;
          for (let ft = 0; ft < floatTexts.length; ft++) {
            const fObj = floatTexts[ft];
            ctx.save();
            ctx.font = `900 ${Math.round(20 * fObj.scale)}px sans-serif`;
            ctx.fillStyle = fObj.color;
            ctx.shadowColor = '#000000';
            ctx.shadowBlur = 4;
            ctx.globalAlpha = Math.max(0, fObj.life);
            ctx.fillText(fObj.txt, fObj.x, fObj.y);
            ctx.restore();
          }

          // Judgement Text (PERFECT!, GOOD, MISS!)
          const jText = judgeTextRef.current;
          if (jText) {
            ctx.save();
            ctx.font = '900 30px sans-serif';
            ctx.fillStyle = jText.color;
            ctx.textAlign = 'center';
            ctx.shadowColor = jText.color;
            ctx.shadowBlur = 15;
            ctx.globalAlpha = Math.min(1, jText.life * 2);
            ctx.fillText(jText.text, W / 2, judgeY - 50);
            ctx.restore();
          }

          ctx.restore();
        }
      }

      gameLoopRef.current = requestAnimationFrame(loop);
    };

    gameLoopRef.current = requestAnimationFrame(loop);
    return () => {
      if (gameLoopRef.current) cancelAnimationFrame(gameLoopRef.current);
    };
  }, [gameState, missNote, endRaid]);

  // Keyboard controls
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.repeat) return;
      if (e.code === 'Space' || e.code === 'Enter') {
        if (gameState !== 'play') {
          e.preventDefault();
          startRaid();
        }
        return;
      }

      if (Object.prototype.hasOwnProperty.call(KEY_CODE_MAP, e.code)) {
        e.preventDefault();
        const lane = KEY_CODE_MAP[e.code];
        setActivePads((prev) => {
          const next = [...prev];
          next[lane] = true;
          return next;
        });
        hitLane(lane);
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (Object.prototype.hasOwnProperty.call(KEY_CODE_MAP, e.code)) {
        const lane = KEY_CODE_MAP[e.code];
        setActivePads((prev) => {
          const next = [...prev];
          next[lane] = false;
          return next;
        });
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [gameState, hitLane, startRaid]);

  // Mouse / Touch camera parallax tilt
  useEffect(() => {
    let isDown = false;
    let startX = 0;
    let startY = 0;

    const onMouseDown = (e: MouseEvent) => {
      isDown = true;
      startX = e.clientX;
      startY = e.clientY;
    };
    const onMouseUp = () => {
      isDown = false;
    };
    const onMouseMove = (e: MouseEvent) => {
      if (!isDown || !threeSceneRef.current) return;
      threeSceneRef.current.targetCamRotY += (e.clientX - startX) * 0.003;
      threeSceneRef.current.targetCamRotX += (e.clientY - startY) * 0.003;
      startX = e.clientX;
      startY = e.clientY;
    };

    const onTouchMove = (e: TouchEvent) => {
      if (e.touches.length > 0 && threeSceneRef.current) {
        const t = e.touches[0];
        threeSceneRef.current.targetCamRotY = (t.clientX / window.innerWidth - 0.5) * 0.6;
        threeSceneRef.current.targetCamRotX = (t.clientY / window.innerHeight - 0.5) * 0.4;
      }
    };

    window.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mouseup', onMouseUp);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('touchmove', onTouchMove, { passive: true });

    return () => {
      window.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mouseup', onMouseUp);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('touchmove', onTouchMove);
    };
  }, []);

  // Sound Toggle
  const toggleSound = () => {
    const next = audio.toggleSound();
    setSoundEnabled(next);
  };

  const hpPercent = Math.max(0, Math.min(100, (bossHp / maxBossHp) * 100));

  return (
    <div className="flex items-center justify-center min-h-screen bg-neutral-950 font-sans p-0 sm:p-2">
      {/* Container simulating arcade screen */}
      <div
        id="app"
        className="relative w-full max-w-[480px] h-[100dvh] flex flex-col overflow-hidden bg-neutral-950 shadow-2xl border-x border-purple-950/40"
        style={{
          boxShadow: '0 0 50px rgba(157, 78, 223, 0.35)',
        }}
      >
        {/* Background Image with dark overlay */}
        <div
          className="absolute inset-0 pointer-events-none z-0 bg-cover bg-center opacity-45 mix-blend-luminosity scale-105 transition-transform duration-1000"
          style={{ backgroundImage: `url(${arenaBg})` }}
        />
        <div className="absolute inset-0 pointer-events-none z-0 bg-gradient-to-b from-[#140526]/90 via-[#0a0316]/80 to-[#05020c]/95" />

        {/* HUD (Boss & Player Status) */}
        <header
          id="hud"
          className="relative z-20 flex-shrink-0 px-3 py-2 bg-gradient-to-b from-[#1e0a32]/95 to-[#0f051c]/80 border-b border-white/15 backdrop-blur-md"
        >
          <div className="flex items-center justify-between mb-1.5 gap-2">
            {/* Back to Menu / Boss Select Button */}
            <button
              id="backBtn"
              type="button"
              onClick={() => {
                setGameState('start');
              }}
              title="메인 메뉴(난이도 선택)로 뒤로 가기"
              aria-label="메인 메뉴로 뒤로 가기"
              className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 border border-white/20 text-zinc-300 hover:text-white flex items-center justify-center transition active:scale-95 flex-shrink-0"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>

            {/* Boss Info with Portrait */}
            <div className="flex items-center gap-2 min-w-0">
              <div
                className="relative w-8 h-8 rounded-full overflow-hidden flex-shrink-0 border-2 shadow-lg"
                style={{
                  borderColor: currentBoss.hex,
                  boxShadow: `0 0 10px ${currentBoss.hex}88`,
                }}
              >
                <img
                  src={currentBoss.image}
                  alt={currentBoss.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="truncate">
                <div className="flex items-center gap-1.5">
                  <span className="text-sm font-black tracking-tight" style={{ color: currentBoss.hex }}>
                    {currentBoss.name}
                  </span>
                  <span className="text-[10px] text-zinc-400 font-bold">LV.{currentBoss.level}</span>
                </div>
                <div className="text-[10px] text-purple-300/80 font-medium truncate">{currentBoss.title}</div>
              </div>
            </div>

            {/* Phase Tag */}
            <div
              className="text-[10px] font-extrabold px-2.5 py-0.5 rounded-full border whitespace-nowrap flex-shrink-0"
              style={{
                backgroundColor: `${currentBoss.hex}22`,
                borderColor: currentBoss.hex,
                color: currentBoss.hex,
                boxShadow: `0 0 8px ${currentBoss.hex}44`,
              }}
            >
              {currentBoss.tag}
            </div>
          </div>

          {/* Boss HP Bar */}
          <div className="relative w-full h-4 bg-black/70 rounded-full overflow-hidden border border-white/20 mb-2">
            <div
              className="h-full transition-all duration-150 rounded-full"
              style={{
                width: `${hpPercent}%`,
                background:
                  bossPhase === 4
                    ? 'linear-gradient(90deg, #ff0055, #9d4edf)'
                    : 'linear-gradient(90deg, #ff0055, #ff5500, #ffaa00)',
                boxShadow: '0 0 12px rgba(255, 85, 0, 0.8)',
              }}
            />
            <div className="absolute inset-0 flex items-center justify-center text-[10px] font-black text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)]">
              {Math.round(hpPercent)}% ({Math.max(0, Math.round(bossHp)).toLocaleString()} / {maxBossHp.toLocaleString()} HP)
            </div>
          </div>

          {/* Player Stats Row */}
          <div className="flex gap-2 items-center justify-between">
            <div className="flex-1 px-2.5 py-1 bg-white/[0.06] rounded-lg border border-white/10 flex items-center justify-between text-xs font-bold">
              <span className="text-zinc-400 text-[11px] flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-amber-400" /> 점수
              </span>
              <span className="text-amber-300 font-black text-sm">{score}</span>
            </div>

            <div className="flex-1 px-2.5 py-1 bg-white/[0.06] rounded-lg border border-white/10 flex items-center justify-between text-xs font-bold">
              <span className="text-zinc-400 text-[11px] flex items-center gap-1">
                <Flame className="w-3 h-3 text-rose-500" /> 콤보
              </span>
              <span className="text-rose-400 font-black text-sm">{combo}</span>
            </div>

            <div className="flex-1 px-2.5 py-1 bg-white/[0.06] rounded-lg border border-white/10 flex items-center justify-between text-xs font-bold">
              <span className="text-zinc-400 text-[11px]">LIFE</span>
              <div className="flex gap-0.5 text-xs select-none">
                {Array.from({ length: maxHearts }).map((_, i) => (
                  <span key={i}>{i < playerHp ? '❤️' : '🖤'}</span>
                ))}
              </div>
            </div>

            <button
              id="soundBtn"
              type="button"
              onClick={toggleSound}
              aria-label="음소거 토글"
              className="w-8 h-8 rounded-lg bg-white/10 hover:bg-white/20 border border-white/20 flex items-center justify-center text-white transition active:scale-95"
            >
              {soundEnabled ? <Volume2 className="w-4 h-4 text-emerald-400" /> : <VolumeX className="w-4 h-4 text-zinc-500" />}
            </button>
          </div>
        </header>

        {/* Stage & Playfield */}
        <main id="stage" className="relative flex-1 flex flex-col min-h-0 z-10">
          {/* Boss Speech Bubble with Mini Avatar */}
          <div
            id="bossBubble"
            className={`absolute top-4 left-1/2 -translate-x-1/2 z-30 flex items-center gap-2 bg-[#0c051a]/95 border-2 rounded-2xl px-3.5 py-1.5 text-xs font-bold shadow-2xl backdrop-blur-md pointer-events-none transition-all duration-300 ${
              showQuote ? 'opacity-100 -translate-y-1' : 'opacity-0 translate-y-2'
            }`}
            style={{
              borderColor: currentBoss.hex,
              boxShadow: `0 0 20px ${currentBoss.hex}66`,
            }}
          >
            <img
              src={currentBoss.image}
              alt=""
              referrerPolicy="no-referrer"
              className="w-5 h-5 rounded-full object-cover border border-white/30"
            />
            <span className="text-white drop-shadow">{bossQuote}</span>
          </div>

          {/* Interactive Playfield Canvas Area */}
          <div id="field" ref={fieldRef} className="relative flex-1 min-h-0 overflow-hidden cursor-crosshair">
            <canvas id="threeCv" ref={threeCanvasRef} className="absolute inset-0 w-full h-full z-1" />
            <canvas id="cv" ref={canvas2dRef} className="absolute inset-0 w-full h-full z-2 pointer-events-none" />
          </div>

          {/* 4 Pads Controls */}
          <div
            id="pads"
            className="flex-shrink-0 grid grid-cols-4 gap-1.5 p-2 pb-3 bg-gradient-to-t from-[#05020c] via-[#0a0414]/90 to-transparent z-20"
          >
            {LANE_KEYS.map((key, index) => {
              const color = LANE_COLORS[index];
              const shadow = LANE_SHADOWS[index];
              const isOn = activePads[index];

              return (
                <button
                  key={key}
                  type="button"
                  id={`pad-button-${key}`}
                  onPointerDown={(e) => {
                    e.preventDefault();
                    setActivePads((prev) => {
                      const next = [...prev];
                      next[index] = true;
                      return next;
                    });
                    hitLane(index);
                  }}
                  onPointerUp={() => {
                    setActivePads((prev) => {
                      const next = [...prev];
                      next[index] = false;
                      return next;
                    });
                  }}
                  onPointerCancel={() => {
                    setActivePads((prev) => {
                      const next = [...prev];
                      next[index] = false;
                      return next;
                    });
                  }}
                  className={`h-20 rounded-2xl border-2 flex flex-col items-center justify-center gap-0.5 cursor-pointer touch-none select-none transition-all duration-75 ${
                    isOn ? 'scale-90 brightness-125' : 'hover:scale-[1.02]'
                  }`}
                  style={{
                    borderColor: color,
                    backgroundColor: isOn ? color : 'rgba(255,255,255,0.04)',
                    boxShadow: isOn ? `0 0 24px ${color}, inset 0 0 12px ${color}` : `0 0 12px ${shadow}`,
                  }}
                >
                  <span
                    className="text-2xl font-black"
                    style={{
                      color: isOn ? '#000000' : color,
                      textShadow: isOn ? 'none' : `0 0 10px ${color}`,
                    }}
                  >
                    {key}
                  </span>
                  <span
                    className="text-[11px] font-extrabold"
                    style={{ color: isOn ? '#000000' : '#ffffff' }}
                  >
                    {LANE_ICONS[index]} {LANE_LABELS[index]}
                  </span>
                </button>
              );
            })}
          </div>

          {/* START SCREEN OVERLAY */}
          {gameState === 'start' && (
            <div
              id="startScreen"
              className="absolute inset-0 z-40 flex flex-col items-center justify-center p-4 text-center bg-gradient-to-b from-[#1b0730]/95 via-[#0c0318]/98 to-[#04010a] backdrop-blur-md overflow-y-auto"
            >
              {/* Header Icon & Title */}
              <div className="relative mb-2">
                <div
                  className="w-16 h-16 rounded-2xl overflow-hidden border-2 shadow-2xl mx-auto mb-1.5 transition-all duration-300"
                  style={{
                    borderColor: currentBoss.hex,
                    boxShadow: `0 0 25px ${currentBoss.hex}88`,
                  }}
                >
                  <img
                    src={currentBoss.image}
                    alt={currentBoss.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div
                  className="inline-block text-[11px] font-black px-3 py-0.5 rounded-full border"
                  style={{
                    borderColor: currentBoss.hex,
                    color: currentBoss.hex,
                    backgroundColor: `${currentBoss.hex}22`,
                  }}
                >
                  {currentBoss.name} (LV.{currentBoss.level})
                </div>
              </div>

              <h1 className="text-3xl font-black tracking-tight bg-gradient-to-r from-rose-500 via-purple-400 to-cyan-300 bg-clip-text text-transparent drop-shadow-[0_0_15px_rgba(255,59,112,0.6)]">
                리듬 보스 레이드
              </h1>
              <p className="text-xs text-purple-200/90 font-medium mt-1 mb-3 leading-relaxed">
                각 난이도별 사천왕 & 마왕과 펼치는 1:1 리듬 레이드!<br />
                박자에 맞춰 <strong className="text-amber-300">스킬 노트를 타격</strong>하여 보스를 격파하세요!
              </p>

              {/* Key guide */}
              <div className="flex gap-1.5 mb-3">
                {LANE_KEYS.map((k, i) => (
                  <div
                    key={k}
                    className="w-14 py-1.5 rounded-xl border bg-white/[0.04] flex flex-col items-center"
                    style={{
                      borderColor: LANE_COLORS[i],
                      boxShadow: `0 0 8px ${LANE_SHADOWS[i]}`,
                    }}
                  >
                    <span className="text-base font-black" style={{ color: LANE_COLORS[i] }}>
                      {k}
                    </span>
                    <span className="text-[10px] font-bold text-zinc-300">
                      {LANE_ICONS[i]} {LANE_LABELS[i]}
                    </span>
                  </div>
                ))}
              </div>

              {/* Difficulty Selection with Boss Portrait Cards */}
              <div className="w-full max-w-sm mb-3">
                <div className="text-xs font-black text-purple-300 mb-1.5 flex items-center justify-center gap-1">
                  <span>🎯 난이도 및 보스 선택 (클릭 시 보스 변경)</span>
                </div>
                <div className="grid grid-cols-5 gap-1">
                  {Object.entries(DIFF_SETTINGS).map(([diffKey, cfg]) => {
                    const boss = BOSS_LIST[cfg.bossIdx];
                    const isActive = selectedDiff === diffKey;

                    return (
                      <button
                        key={diffKey}
                        type="button"
                        onClick={() => {
                          setSelectedDiff(diffKey);
                          applyBossPhase(cfg.bossIdx);
                        }}
                        className={`p-1 rounded-xl border flex flex-col items-center gap-1 transition-all ${
                          isActive
                            ? 'bg-white/20 scale-105 border-white shadow-lg'
                            : 'bg-white/[0.04] border-white/15 opacity-75 hover:opacity-100'
                        }`}
                        style={{
                          borderColor: isActive ? cfg.diffColor : 'rgba(255,255,255,0.15)',
                          boxShadow: isActive ? `0 0 14px ${cfg.diffColor}` : 'none',
                        }}
                      >
                        <img
                          src={boss.image}
                          alt={boss.name}
                          referrerPolicy="no-referrer"
                          className="w-9 h-9 rounded-lg object-cover border border-white/20"
                        />
                        <span className="text-[10px] font-black text-white leading-none whitespace-nowrap">
                          {cfg.badge}
                        </span>
                        <span className="text-[8px] font-extrabold text-amber-300 leading-tight whitespace-nowrap px-1 py-0.5 rounded bg-black/40">
                          {cfg.hpBadge}
                        </span>
                        <span className="text-[8px] text-zinc-300 scale-90 whitespace-nowrap">
                          {cfg.hearts}하트
                        </span>
                      </button>
                    );
                  })}
                </div>

                {/* Selected Boss & HP Info Banner */}
                {DIFF_SETTINGS[selectedDiff] && (
                  <div className="mt-2 py-1.5 px-3 rounded-xl bg-black/50 border border-white/15 text-xs text-zinc-200 flex items-center justify-between shadow-inner">
                    <span className="font-bold text-zinc-300 text-[11px]">난이도별 체력:</span>
                    <div className="flex items-center gap-1.5">
                      <span className="font-black text-amber-300 text-sm">
                        {DIFF_SETTINGS[selectedDiff].hp.toLocaleString()} HP
                      </span>
                      <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-rose-500/30 text-rose-300 border border-rose-500/40 font-black">
                        {DIFF_SETTINGS[selectedDiff].hpBadge}
                      </span>
                    </div>
                  </div>
                )}
              </div>

              <p className="text-[11px] text-purple-300/70 mb-3">
                ⌨️ 키보드 <kbd className="px-1 py-0.5 bg-white/10 rounded font-mono text-white">D</kbd> <kbd className="px-1 py-0.5 bg-white/10 rounded font-mono text-white">F</kbd> <kbd className="px-1 py-0.5 bg-white/10 rounded font-mono text-white">J</kbd> <kbd className="px-1 py-0.5 bg-white/10 rounded font-mono text-white">K</kbd> 또는 하단 패드 터치
              </p>

              {/* Start Button */}
              <button
                id="startBtn"
                type="button"
                onClick={startRaid}
                className="w-full max-w-xs py-3.5 px-6 rounded-full font-black text-base text-neutral-950 bg-gradient-to-r from-rose-500 via-amber-300 to-cyan-400 hover:brightness-110 active:scale-95 shadow-[0_5px_0_#6e1030,0_0_25px_rgba(255,59,112,0.6)] flex items-center justify-center gap-2 transition"
              >
                <Play className="w-5 h-5 fill-neutral-950" /> 레이드 시작 (Space)
              </button>

              {bestScore > 0 && (
                <p className="text-xs text-amber-300/90 font-bold mt-2.5">
                  🏆 최고 기록: {bestScore.toLocaleString()}점
                </p>
              )}
            </div>
          )}

          {/* RESULT SCREEN OVERLAY */}
          {gameState === 'result' && (
            <div
              id="resultScreen"
              className="absolute inset-0 z-40 flex flex-col items-center justify-center p-5 text-center bg-gradient-to-b from-[#1b0730]/98 via-[#0c0318]/98 to-[#04010a] backdrop-blur-md"
            >
              <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-white/30 shadow-2xl mb-1">
                <img
                  src={currentBoss.image}
                  alt={currentBoss.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>

              <div className="text-xs font-bold text-purple-300 mb-1">
                {results.victory ? '🎉 레이드 정복 성공!' : '💀 레이드 실패...'}
              </div>

              <div
                id="grade"
                className="text-5xl font-black my-1"
                style={{
                  color: results.gradeColor,
                  textShadow: `0 0 25px ${results.gradeColor}`,
                }}
              >
                {results.grade}
              </div>

              <h2 className="text-xl font-black text-white mb-4">
                {results.victory
                  ? `${currentBoss.name} 토벌 완료!`
                  : `${currentBoss.name}의 벽을 넘지 못했습니다.`}
              </h2>

              {/* Stats Breakdown Box */}
              <div className="grid grid-cols-3 gap-2 w-full max-w-xs mb-3">
                <div className="p-2.5 bg-white/[0.06] rounded-xl border border-white/10">
                  <div className="text-lg font-black text-cyan-400">{results.perfect}</div>
                  <div className="text-[10px] font-bold text-purple-300">PERFECT</div>
                </div>
                <div className="p-2.5 bg-white/[0.06] rounded-xl border border-white/10">
                  <div className="text-lg font-black text-amber-300">{results.good}</div>
                  <div className="text-[10px] font-bold text-purple-300">GOOD</div>
                </div>
                <div className="p-2.5 bg-white/[0.06] rounded-xl border border-white/10">
                  <div className="text-lg font-black text-rose-500">{results.miss}</div>
                  <div className="text-[10px] font-bold text-purple-300">MISS</div>
                </div>
              </div>

              <div className="text-sm font-bold text-purple-200 mb-4">
                최고 콤보: <strong className="text-amber-300">{results.maxCombo}</strong> | 최종 점수:{' '}
                <strong className="text-cyan-300">{results.score.toLocaleString()}</strong>
              </div>

              <div className="flex gap-2 w-full max-w-xs">
                <button
                  id="backToMenuBtn"
                  type="button"
                  onClick={() => setGameState('start')}
                  className="flex-1 py-3.5 px-4 rounded-full font-black text-sm text-zinc-200 bg-white/10 hover:bg-white/20 border border-white/20 flex items-center justify-center gap-1.5 transition active:scale-95"
                >
                  <Home className="w-4 h-4" /> 뒤로 가기
                </button>
                <button
                  id="retryBtn"
                  type="button"
                  onClick={startRaid}
                  className="flex-1 py-3.5 px-4 rounded-full font-black text-sm text-neutral-950 bg-gradient-to-r from-rose-500 via-amber-300 to-cyan-400 hover:brightness-110 active:scale-95 shadow-[0_5px_0_#6e1030,0_0_20px_rgba(255,59,112,0.6)] flex items-center justify-center gap-1.5 transition"
                >
                  <RotateCcw className="w-4 h-4" /> 다시 도전
                </button>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
