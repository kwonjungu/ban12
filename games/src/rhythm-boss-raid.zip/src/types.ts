export interface Note {
  t: number;
  lane: number;
  approach: number;
  icon: string;
  judged: boolean;
}

export interface BossData {
  id: string;
  name: string;
  title: string;
  tag: string;
  color: number;
  hex: string;
  quote: string;
  image: string;
  level: number;
}

export interface DiffConfig {
  bossIdx: number;
  speedMult: number;
  hearts: number;
  hpMult: number;
  hp: number;
  hpBadge: string;
  name: string;
  badge: string;
  diffColor: string;
}

export interface FloatingText {
  id: number;
  x: number;
  y: number;
  txt: string;
  color: string;
  life: number;
  vy: number;
  scale: number;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  color: string;
  size: number;
}

export interface Judgement {
  text: string;
  color: string;
  life: number;
}
