import * as THREE from 'three';

export class BossThreeScene {
  private renderer: THREE.WebGLRenderer | null = null;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private rootBossGroup: THREE.Group;
  private currentBossModel: THREE.Group | null = null;
  private bossModels: THREE.Group[] = [];

  // Dynamic parts for animation
  private dragonParts: { spine: THREE.Mesh[]; whiskers: THREE.Group; horns: THREE.Group } | null = null;
  private tigerParts: { ears: THREE.Group; fangs: THREE.Group; claws: THREE.Group } | null = null;
  private phoenixParts: { leftWing: THREE.Group; rightWing: THREE.Group; crest: THREE.Group; beak: THREE.Mesh } | null = null;
  private tortoiseParts: { serpentNeck: THREE.Group; shields: THREE.Group } | null = null;
  private demonParts: { horns: THREE.Group; wings: THREE.Group; blades: THREE.Group; core: THREE.Mesh } | null = null;

  private coreLight: THREE.PointLight;
  private holoPlane: THREE.Mesh | null = null;
  private textureLoader = new THREE.TextureLoader();
  private particleSystem: THREE.Points;

  public targetCamRotX = 0;
  public targetCamRotY = 0;

  constructor(canvas: HTMLCanvasElement, width: number, height: number) {
    this.scene = new THREE.Scene();
    this.scene.fog = new THREE.FogExp2(0x0a0518, 0.04);

    this.camera = new THREE.PerspectiveCamera(60, width / height, 0.1, 1000);
    this.camera.position.set(0, 1.2, 5);

    this.renderer = new THREE.WebGLRenderer({
      canvas,
      alpha: true,
      antialias: true,
      powerPreference: 'high-performance',
    });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));

    // Lights
    const ambientLight = new THREE.AmbientLight(0x332244, 1.9);
    this.scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xffffff, 2.2);
    dirLight.position.set(5, 10, 7);
    this.scene.add(dirLight);

    this.coreLight = new THREE.PointLight(0x00f5d4, 4, 12);
    this.coreLight.position.set(0, 0.5, 0);
    this.scene.add(this.coreLight);

    // Root Boss Group
    this.rootBossGroup = new THREE.Group();
    this.rootBossGroup.position.set(0, 0.2, -1);
    this.scene.add(this.rootBossGroup);

    // Background Holographic Portrait
    const planeGeo = new THREE.PlaneGeometry(3.6, 3.6);
    const planeMat = new THREE.MeshBasicMaterial({
      transparent: true,
      opacity: 0.35,
      blending: THREE.AdditiveBlending,
      side: THREE.DoubleSide,
      depthWrite: false,
    });
    this.holoPlane = new THREE.Mesh(planeGeo, planeMat);
    this.holoPlane.position.set(0, 0.6, -1.8);
    this.scene.add(this.holoPlane);

    // Ambient Magic Particles
    const pCount = 180;
    const pGeo = new THREE.BufferGeometry();
    const pPos = new Float32Array(pCount * 3);
    for (let p = 0; p < pCount * 3; p += 3) {
      pPos[p] = (Math.random() - 0.5) * 14;
      pPos[p + 1] = (Math.random() - 0.5) * 9 + 1;
      pPos[p + 2] = (Math.random() - 0.5) * 14;
    }
    pGeo.setAttribute('position', new THREE.BufferAttribute(pPos, 3));
    const pMat = new THREE.PointsMaterial({ size: 0.09, color: 0x9d4edf, transparent: true, opacity: 0.65 });
    this.particleSystem = new THREE.Points(pGeo, pMat);
    this.scene.add(this.particleSystem);

    // Build all 5 Boss Distinct 3D Models
    this.buildAllBossModels();
  }

  /**
   * Builds distinct, high-concept 3D models for all 5 bosses:
   * 0: 청룡 (Dragon)
   * 1: 백호 (Tiger)
   * 2: 주작 (Phoenix)
   * 3: 현무 (Black Tortoise & Serpent)
   * 4: 마왕 (Demon Lord)
   */
  private buildAllBossModels() {
    // 0. 청룡 (Azure Dragon)
    const dragon = new THREE.Group();
    const dHeadGeo = new THREE.ConeGeometry(0.65, 1.6, 6);
    const dHeadMat = new THREE.MeshPhongMaterial({ color: 0x052b36, emissive: 0x004d40, specular: 0x00f5d4, shininess: 70, flatShading: true });
    const dHead = new THREE.Mesh(dHeadGeo, dHeadMat);
    dHead.rotation.x = Math.PI * 0.55;
    dHead.position.set(0, 0.4, 0.3);
    dragon.add(dHead);

    // Dragon Eyes
    const eyeGeo = new THREE.SphereGeometry(0.12, 8, 8);
    const eyeMat = new THREE.MeshBasicMaterial({ color: 0x00f5d4 });
    const dEyeL = new THREE.Mesh(eyeGeo, eyeMat);
    dEyeL.position.set(-0.35, 0.6, 0.6);
    const dEyeR = new THREE.Mesh(eyeGeo, eyeMat);
    dEyeR.position.set(0.35, 0.6, 0.6);
    dragon.add(dEyeL, dEyeR);

    // Dragon Branching Antler Horns
    const dHorns = new THREE.Group();
    const hornMat = new THREE.MeshStandardMaterial({ color: 0x00f5d4, roughness: 0.2, metalness: 0.8 });
    for (let i = -1; i <= 1; i += 2) {
      const hMain = new THREE.Mesh(new THREE.ConeGeometry(0.12, 1.4, 5), hornMat);
      hMain.position.set(i * 0.5, 1.2, -0.1);
      hMain.rotation.z = -i * 0.45;
      hMain.rotation.x = -0.3;
      const hSub = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.7, 4), hornMat);
      hSub.position.set(i * 0.75, 1.0, 0.1);
      hSub.rotation.z = -i * 0.7;
      dHorns.add(hMain, hSub);
    }
    dragon.add(dHorns);

    // Dragon Whiskers
    const dWhiskers = new THREE.Group();
    const whiskerGeo = new THREE.CylinderGeometry(0.02, 0.05, 1.2, 4);
    const whiskerMat = new THREE.MeshBasicMaterial({ color: 0x00f5d4 });
    const wL = new THREE.Mesh(whiskerGeo, whiskerMat);
    wL.position.set(-0.4, 0.1, 0.9);
    wL.rotation.z = 0.6;
    wL.rotation.x = -0.5;
    const wR = new THREE.Mesh(whiskerGeo, whiskerMat);
    wR.position.set(0.4, 0.1, 0.9);
    wR.rotation.z = -0.6;
    wR.rotation.x = -0.5;
    dWhiskers.add(wL, wR);
    dragon.add(dWhiskers);

    // Dragon Spine Segments
    const spineMeshes: THREE.Mesh[] = [];
    for (let s = 0; s < 5; s++) {
      const segGeo = new THREE.DodecahedronGeometry(0.5 - s * 0.06);
      const seg = new THREE.Mesh(segGeo, dHeadMat);
      seg.position.set(0, -0.2 - s * 0.45, -0.2 - s * 0.35);
      dragon.add(seg);
      spineMeshes.push(seg);
    }
    this.dragonParts = { spine: spineMeshes, whiskers: dWhiskers, horns: dHorns };
    this.bossModels.push(dragon);

    // 1. 백호 (White Tiger)
    const tiger = new THREE.Group();
    const tSkullGeo = new THREE.BoxGeometry(1.2, 1.1, 1.1);
    const tMat = new THREE.MeshPhongMaterial({ color: 0xeeeeee, emissive: 0x332500, specular: 0xffee38, shininess: 80, flatShading: true });
    const tHead = new THREE.Mesh(tSkullGeo, tMat);
    tHead.position.set(0, 0.4, 0.2);
    tiger.add(tHead);

    // Tiger Ears
    const tEars = new THREE.Group();
    const earGeo = new THREE.ConeGeometry(0.28, 0.6, 4);
    const earMat = new THREE.MeshPhongMaterial({ color: 0xffee38, flatShading: true });
    const earL = new THREE.Mesh(earGeo, earMat);
    earL.position.set(-0.55, 1.15, 0.2);
    earL.rotation.z = -0.3;
    const earR = new THREE.Mesh(earGeo, earMat);
    earR.position.set(0.55, 1.15, 0.2);
    earR.rotation.z = 0.3;
    tEars.add(earL, earR);
    tiger.add(tEars);

    // Tiger Fangs & Muzzle
    const tFangs = new THREE.Group();
    const fangGeo = new THREE.ConeGeometry(0.1, 0.45, 4);
    const fangMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const f1 = new THREE.Mesh(fangGeo, fangMat);
    f1.position.set(-0.3, -0.25, 0.8);
    f1.rotation.x = Math.PI;
    const f2 = new THREE.Mesh(fangGeo, fangMat);
    f2.position.set(0.3, -0.25, 0.8);
    f2.rotation.x = Math.PI;
    tFangs.add(f1, f2);

    const tEyes = new THREE.Group();
    const tEyeMat = new THREE.MeshBasicMaterial({ color: 0xffee38 });
    const teL = new THREE.Mesh(eyeGeo, tEyeMat);
    teL.position.set(-0.35, 0.55, 0.8);
    const teR = new THREE.Mesh(eyeGeo, tEyeMat);
    teR.position.set(0.35, 0.55, 0.8);
    tEyes.add(teL, teR);
    tiger.add(tFangs, tEyes);

    // Tiger Floating Claws / Chi Blades
    const tClaws = new THREE.Group();
    const clawMat = new THREE.MeshStandardMaterial({ color: 0xffee38, emissive: 0xffaa00, roughness: 0.1 });
    for (let c = 0; c < 3; c++) {
      const cL = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.7, 4), clawMat);
      cL.position.set(-1.2 - c * 0.15, 0.2 - c * 0.1, 0.4);
      cL.rotation.z = -1.2;
      const cR = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.7, 4), clawMat);
      cR.position.set(1.2 + c * 0.15, 0.2 - c * 0.1, 0.4);
      cR.rotation.z = 1.2;
      tClaws.add(cL, cR);
    }
    tiger.add(tClaws);
    this.tigerParts = { ears: tEars, fangs: tFangs, claws: tClaws };
    this.bossModels.push(tiger);

    // 2. 주작 (Vermilion Bird / Phoenix)
    const phoenix = new THREE.Group();
    const pBodyGeo = new THREE.ConeGeometry(0.5, 1.4, 5);
    const pMat = new THREE.MeshPhongMaterial({ color: 0x881100, emissive: 0xff3300, specular: 0xffaa00, shininess: 100, flatShading: true });
    const pBody = new THREE.Mesh(pBodyGeo, pMat);
    pBody.position.set(0, 0.3, 0);
    pBody.rotation.x = -0.2;
    phoenix.add(pBody);

    // Phoenix Sharp Beak
    const beakGeo = new THREE.ConeGeometry(0.18, 0.8, 4);
    const beakMat = new THREE.MeshStandardMaterial({ color: 0xffaa00, roughness: 0.2, metalness: 0.7 });
    const beak = new THREE.Mesh(beakGeo, beakMat);
    beak.position.set(0, 0.65, 0.7);
    beak.rotation.x = Math.PI * 0.55;
    phoenix.add(beak);

    // Phoenix Blazing Crown Crest
    const pCrest = new THREE.Group();
    for (let cr = -1; cr <= 1; cr++) {
      const crestMesh = new THREE.Mesh(new THREE.ConeGeometry(0.1, 0.9 - Math.abs(cr) * 0.2, 4), beakMat);
      crestMesh.position.set(cr * 0.25, 1.25, 0.1);
      crestMesh.rotation.z = -cr * 0.35;
      crestMesh.rotation.x = -0.4;
      pCrest.add(crestMesh);
    }
    phoenix.add(pCrest);

    // Phoenix Flapping Wings
    const pWingMat = new THREE.MeshStandardMaterial({ color: 0xff5500, emissive: 0xff2200, roughness: 0.3, side: THREE.DoubleSide });
    const pLeftWing = new THREE.Group();
    pLeftWing.position.set(-0.5, 0.5, 0);
    for (let w = 0; w < 4; w++) {
      const feather = new THREE.Mesh(new THREE.ConeGeometry(0.18, 1.3 - w * 0.15, 3), pWingMat);
      feather.position.set(-w * 0.45, 0.1 - w * 0.1, 0);
      feather.rotation.z = 1.3 - w * 0.2;
      pLeftWing.add(feather);
    }
    const pRightWing = new THREE.Group();
    pRightWing.position.set(0.5, 0.5, 0);
    for (let w = 0; w < 4; w++) {
      const feather = new THREE.Mesh(new THREE.ConeGeometry(0.18, 1.3 - w * 0.15, 3), pWingMat);
      feather.position.set(w * 0.45, 0.1 - w * 0.1, 0);
      feather.rotation.z = -1.3 + w * 0.2;
      pRightWing.add(feather);
    }
    phoenix.add(pLeftWing, pRightWing);
    this.phoenixParts = { leftWing: pLeftWing, rightWing: pRightWing, crest: pCrest, beak };
    this.bossModels.push(phoenix);

    // 3. 현무 (Black Tortoise & Serpent)
    const tortoise = new THREE.Group();
    // Heavy Hexagonal Dome Shell
    const shellGeo = new THREE.CylinderGeometry(1.3, 1.45, 0.7, 6);
    const shellMat = new THREE.MeshPhongMaterial({ color: 0x180b2a, emissive: 0x4a148c, specular: 0x9d4edf, shininess: 40, flatShading: true });
    const shell = new THREE.Mesh(shellGeo, shellMat);
    shell.position.set(0, 0.1, 0);
    shell.rotation.x = 0.3;
    tortoise.add(shell);

    // Coiling Serpent Head
    const serpentNeck = new THREE.Group();
    serpentNeck.position.set(0, 0.5, -0.4);
    const sMat = new THREE.MeshPhongMaterial({ color: 0x00e676, emissive: 0x004d40, flatShading: true });
    for (let s = 0; s < 4; s++) {
      const sMesh = new THREE.Mesh(new THREE.SphereGeometry(0.26 - s * 0.03, 8, 8), sMat);
      sMesh.position.set(Math.sin(s) * 0.2, s * 0.35, Math.cos(s) * 0.2);
      serpentNeck.add(sMesh);
    }
    // Serpent Crown Head
    const sHead = new THREE.Mesh(new THREE.ConeGeometry(0.24, 0.65, 5), sMat);
    sHead.position.set(0, 1.5, 0.3);
    sHead.rotation.x = Math.PI * 0.6;
    serpentNeck.add(sHead);
    tortoise.add(serpentNeck);

    // Aegis Orbiting Shield Plates
    const tShields = new THREE.Group();
    const shieldPlateMat = new THREE.MeshStandardMaterial({ color: 0x9d4edf, emissive: 0x4a148c, metalness: 0.9, roughness: 0.2 });
    for (let i = 0; i < 4; i++) {
      const angle = (i / 4) * Math.PI * 2;
      const plate = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.7, 0.08), shieldPlateMat);
      plate.position.set(Math.cos(angle) * 1.8, 0.3, Math.sin(angle) * 1.8);
      plate.rotation.y = -angle;
      tShields.add(plate);
    }
    tortoise.add(tShields);
    this.tortoiseParts = { serpentNeck, shields: tShields };
    this.bossModels.push(tortoise);

    // 4. 최종 잔반 마왕 (Demon Lord)
    const demon = new THREE.Group();
    const dSkullGeo = new THREE.IcosahedronGeometry(0.95, 0);
    const dMat = new THREE.MeshPhongMaterial({ color: 0x0d0314, emissive: 0x4a0018, specular: 0xff0055, shininess: 90, flatShading: true });
    const dHeadMesh = new THREE.Mesh(dSkullGeo, dMat);
    dHeadMesh.position.set(0, 0.5, 0);
    demon.add(dHeadMesh);

    // Grand Curved Obsidian Horns
    const dHornsGroup = new THREE.Group();
    const dHornMat = new THREE.MeshPhongMaterial({ color: 0xff0055, emissive: 0x330011, flatShading: true, shininess: 100 });
    for (let side = -1; side <= 1; side += 2) {
      const hornRoot = new THREE.Mesh(new THREE.ConeGeometry(0.28, 1.6, 5), dHornMat);
      hornRoot.position.set(side * 0.85, 1.25, -0.1);
      hornRoot.rotation.z = -side * 0.65;
      hornRoot.rotation.x = -0.3;
      const hornTip = new THREE.Mesh(new THREE.ConeGeometry(0.18, 1.0, 4), dHornMat);
      hornTip.position.set(side * 1.45, 1.75, 0.3);
      hornTip.rotation.z = -side * 1.2;
      dHornsGroup.add(hornRoot, hornTip);
    }
    demon.add(dHornsGroup);

    // Demon Jagged Wings
    const dWings = new THREE.Group();
    const wingMat = new THREE.MeshPhongMaterial({ color: 0x1f0212, emissive: 0x330018, side: THREE.DoubleSide });
    for (let side = -1; side <= 1; side += 2) {
      const wing = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 1.6, 2.4, 3), wingMat);
      wing.position.set(side * 1.8, 0.8, -0.6);
      wing.rotation.z = -side * 0.8;
      wing.rotation.x = 0.3;
      dWings.add(wing);
    }
    demon.add(dWings);

    // Pulsing Dual Heart Doom Core
    const coreGeo = new THREE.OctahedronGeometry(0.55, 2);
    const dCoreMat = new THREE.MeshStandardMaterial({ color: 0xff0055, emissive: 0xff0055, emissiveIntensity: 1.2, roughness: 0.1 });
    const dCore = new THREE.Mesh(coreGeo, dCoreMat);
    dCore.position.set(0, -0.4, 0.3);
    demon.add(dCore);

    // Orbiting Executioner Blades
    const dBlades = new THREE.Group();
    const bladeMat = new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xff0055, metalness: 0.9, roughness: 0.1 });
    for (let i = 0; i < 6; i++) {
      const angle = (i / 6) * Math.PI * 2;
      const blade = new THREE.Mesh(new THREE.ConeGeometry(0.12, 0.8, 4), bladeMat);
      blade.position.set(Math.cos(angle) * 2.0, 0.4, Math.sin(angle) * 2.0);
      blade.rotation.x = Math.PI * 0.5;
      dBlades.add(blade);
    }
    demon.add(dBlades);
    this.demonParts = { horns: dHornsGroup, wings: dWings, blades: dBlades, core: dCore };
    this.bossModels.push(demon);

    // Attach all models to root, hide by default
    this.bossModels.forEach((m) => {
      m.visible = false;
      this.rootBossGroup.add(m);
    });

    // Default activate model 0
    this.switchBossModel(0, 0x00f5d4);
  }

  /**
   * Switch the 3D model according to the active boss
   */
  public switchBossModel(bossPhase: number, colorHex: number) {
    const clampedIdx = Math.max(0, Math.min(this.bossModels.length - 1, bossPhase));
    this.bossModels.forEach((m, idx) => {
      m.visible = idx === clampedIdx;
    });
    this.currentBossModel = this.bossModels[clampedIdx];

    this.coreLight.color.setHex(colorHex);
    this.coreLight.intensity = 3.8 + clampedIdx * 0.8;
  }

  public setHoloImage(url: string) {
    if (!this.holoPlane) return;
    this.textureLoader.load(url, (texture) => {
      if (this.holoPlane) {
        const mat = this.holoPlane.material as THREE.MeshBasicMaterial;
        mat.map = texture;
        mat.needsUpdate = true;
      }
    });
  }

  public updateBossColor(colorHex: number) {
    this.coreLight.color.setHex(colorHex);
  }

  public resize(width: number, height: number) {
    if (!this.renderer) return;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  }

  public render(bossPhase: number, bossHurtTimer: number) {
    if (!this.renderer) return;
    const time = performance.now() * 0.001;

    // Smooth camera rotation
    this.camera.position.x += (Math.sin(this.targetCamRotY) * 4 - this.camera.position.x) * 0.05;
    this.camera.position.y += (1.2 + Math.sin(this.targetCamRotX) * 2 - this.camera.position.y) * 0.05;
    this.camera.lookAt(0, 0.2, -1);

    // Root boss floating & breathing
    this.rootBossGroup.position.y = 0.2 + Math.sin(time * 2) * 0.12;
    this.rootBossGroup.rotation.y = Math.sin(time * 0.8) * 0.18;

    // Boss-Specific Custom Animations!
    if (bossPhase === 0 && this.dragonParts) {
      // Dragon serpentine undulating motion
      this.dragonParts.spine.forEach((seg, i) => {
        seg.position.x = Math.sin(time * 3 + i * 0.8) * 0.25;
        seg.rotation.y = Math.sin(time * 2 + i * 0.5) * 0.2;
      });
      this.dragonParts.whiskers.rotation.z = Math.sin(time * 4) * 0.2;
    } else if (bossPhase === 1 && this.tigerParts) {
      // Tiger aggressive lunging and claw slashing
      this.tigerParts.claws.rotation.z = Math.sin(time * 6) * 0.25;
      this.tigerParts.ears.rotation.z = Math.sin(time * 3) * 0.1;
      this.rootBossGroup.position.z = -1 + Math.sin(time * 4) * 0.15;
    } else if (bossPhase === 2 && this.phoenixParts) {
      // Phoenix flapping wings & crest flare
      const wingFlap = Math.sin(time * 5) * 0.45;
      this.phoenixParts.leftWing.rotation.z = 0.2 + wingFlap;
      this.phoenixParts.rightWing.rotation.z = -0.2 - wingFlap;
      this.phoenixParts.crest.rotation.x = -0.4 + Math.sin(time * 6) * 0.15;
    } else if (bossPhase === 3 && this.tortoiseParts) {
      // Tortoise spinning defense shield & weaving serpent head
      this.tortoiseParts.shields.rotation.y = time * 1.5;
      this.tortoiseParts.serpentNeck.rotation.y = Math.sin(time * 2) * 0.5;
      this.tortoiseParts.serpentNeck.rotation.x = Math.sin(time * 3) * 0.15;
    } else if (bossPhase === 4 && this.demonParts) {
      // Demon lord madness tremor, wing tremor, and orbiting death blades
      this.demonParts.wings.rotation.y = Math.sin(time * 3) * 0.2;
      this.demonParts.blades.rotation.y = time * 3.0;
      const pulse = 1 + Math.sin(time * 10) * 0.22;
      this.demonParts.core.scale.set(pulse, pulse, pulse);
      this.rootBossGroup.rotation.z = Math.sin(time * 8) * 0.08;
    }

    // Boss Hurt shake & recoil
    if (bossHurtTimer > 0) {
      this.rootBossGroup.position.x = (Math.random() - 0.5) * 0.4;
      this.rootBossGroup.position.z = -1 - Math.random() * 0.35;
      this.rootBossGroup.scale.set(1.15, 0.88, 1.15);
    } else {
      this.rootBossGroup.position.x = 0;
      this.rootBossGroup.position.z = -1;
      this.rootBossGroup.scale.set(1, 1, 1);
    }

    // Hologram backdrop floating
    if (this.holoPlane) {
      this.holoPlane.rotation.y = Math.sin(time * 0.5) * 0.12;
      const holoMat = this.holoPlane.material as THREE.MeshBasicMaterial;
      holoMat.opacity = 0.28 + Math.sin(time * 3) * 0.1;
    }

    // Particle rotation
    if (this.particleSystem) {
      this.particleSystem.rotation.y = time * 0.08;
    }

    this.renderer.render(this.scene, this.camera);
  }

  public destroy() {
    if (this.renderer) {
      this.renderer.dispose();
      this.renderer = null;
    }
  }
}
