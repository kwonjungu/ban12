import arenaBg from '../assets/images/raid_arena_bg_1789882084947.jpg';
import dragonBossImg from '../assets/images/azure_dragon_boss_1789882109897.jpg';
import tigerBossImg from '../assets/images/white_tiger_boss_1789882122483.jpg';
import phoenixBossImg from '../assets/images/phoenix_boss_1789882142711.jpg';
import tortoiseBossImg from '../assets/images/tortoise_boss_1789882153629.jpg';
import demonBossImg from '../assets/images/demon_lord_boss_1789882097382.jpg';
import { BossData, DiffConfig } from '../types.ts';

export { arenaBg };

export const BOSS_LIST: BossData[] = [
  {
    id: 'boss4',
    name: '4천왕 - 청룡',
    title: '동방의 뇌전신',
    tag: 'STAGE 1',
    color: 0x00f5d4,
    hex: '#00f5d4',
    quote: '첫 번째 관문, 4천왕 청룡의 뇌전을 넘어봐라!',
    image: dragonBossImg,
    level: 70,
  },
  {
    id: 'boss3',
    name: '3천왕 - 백호',
    title: '서방의 투신',
    tag: 'STAGE 2',
    color: 0xffee38,
    hex: '#ffee38',
    quote: '3천왕 백호의 매서운 정권을 견뎌라!',
    image: tigerBossImg,
    level: 80,
  },
  {
    id: 'boss2',
    name: '2천왕 - 주작',
    title: '남방의 홍련신',
    tag: 'STAGE 3',
    color: 0xff7700,
    hex: '#ff7700',
    quote: '2천왕 주작의 타오르는 화염 속에서 스러져라!',
    image: phoenixBossImg,
    level: 90,
  },
  {
    id: 'boss1',
    name: '1천왕 - 현무',
    title: '북방의 철벽신',
    tag: 'STAGE 4',
    color: 0x9d4edf,
    hex: '#9d4edf',
    quote: '1천왕 현무의 압도적인 방어를 뚫어봐라!',
    image: tortoiseBossImg,
    level: 95,
  },
  {
    id: 'demon',
    name: '최종 마왕 - 잔반 마왕',
    title: '혼돈의 대파멸자',
    tag: 'FINAL STAGE',
    color: 0xff0055,
    hex: '#ff0055',
    quote: '감히 내게 도전하느냐... 진정한 파멸의 리듬을 선사하마!!',
    image: demonBossImg,
    level: 99,
  },
];

export const DIFF_SETTINGS: Record<string, DiffConfig> = {
  boss4: { bossIdx: 0, speedMult: 0.85, hearts: 5, hpMult: 1.0, hp: 1600, hpBadge: '1,600 HP', name: '4천왕 (쉬움)', badge: '🐉 청룡', diffColor: '#00f5d4' },
  boss3: { bossIdx: 1, speedMult: 1.05, hearts: 4, hpMult: 2.25, hp: 3600, hpBadge: '3,600 HP (2.3배↑)', name: '3천왕 (보통)', badge: '🐅 백호', diffColor: '#ffee38' },
  boss2: { bossIdx: 2, speedMult: 1.25, hearts: 3, hpMult: 5.3, hp: 8500, hpBadge: '8,500 HP (2.4배↑)', name: '2천왕 (어려움)', badge: '🦅 주작', diffColor: '#ff7700' },
  boss1: { bossIdx: 3, speedMult: 1.45, hearts: 3, hpMult: 13.1, hp: 21000, hpBadge: '2.1만 HP (2.5배↑)', name: '1천왕 (극악)', badge: '🐢 현무', diffColor: '#9d4edf' },
  demon: { bossIdx: 4, speedMult: 1.70, hearts: 2, hpMult: 34.4, hp: 55000, hpBadge: '5.5만 HP (2.6배↑)', name: '마왕 (지옥)', badge: '👿 마왕', diffColor: '#ff0055' },
};

export const SECTIONS = [
  {
    bpm: 105,
    bars: [
      '1...2...', '3...4...', '1..2..3.', '4...3...',
      '1...1...', '2...3...', '4..3..2.', '1.2.3.4.',
    ],
  },
  {
    bpm: 120,
    bars: [
      '1.2.3.4.', '4.3.2.1.', '12..34..', '1.1.2.2.',
      '3.3.4.4.', '1..3..2.', '4.2.4.2.', '13..24..',
    ],
  },
  {
    bpm: 135,
    bars: [
      '1.2.3.4.', '4.3.2.1.', '12.12.34', '4.4.3.3.',
      '1.3.2.4.', '2.4.1.3.', '12.34.12', '4.1.4.1.',
    ],
  },
  {
    bpm: 150,
    bars: [
      '1.2.3.4.', '4.3.2.1.', '12341234', '43214321',
      '1.3.2.4.', '2.4.1.3.', '11223344', '44332211',
    ],
  },
  {
    bpm: 165,
    bars: [
      '1.2.3.4.', '4.3.2.1.', '12.34.12', '43214321',
      '13241324', '24132413', '12341234', '43214321',
      '1.1.2.2.', '12344321',
    ],
  },
];

export const LANE_ICONS = ['⚔️', '🪄', '🛡️', '💥'];
export const LANE_LABELS = ['검술', '마법', '방어', '필살기'];
export const LANE_COLORS = ['#ff3b70', '#9d4edf', '#00f5d4', '#ffee38'];
export const LANE_SHADOWS = [
  'rgba(255, 59, 112, 0.6)',
  'rgba(157, 78, 223, 0.6)',
  'rgba(0, 245, 212, 0.6)',
  'rgba(255, 238, 56, 0.6)',
];
export const LANE_KEYS = ['D', 'F', 'J', 'K'];
export const KEY_CODE_MAP: Record<string, number> = {
  KeyD: 0,
  KeyF: 1,
  KeyJ: 2,
  KeyK: 3,
};
