/**
 * Web Audio API synthesizer for Rhythm Boss Raid
 */

class SoundEngine {
  private ctx: AudioContext | null = null;
  public enabled: boolean = true;
  private bgmGain: GainNode | null = null;

  public init() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
      this.bgmGain = this.ctx.createGain();
      this.bgmGain.gain.setValueAtTime(0.35, this.ctx.currentTime);
      this.bgmGain.connect(this.ctx.destination);
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
  }

  public toggleSound(): boolean {
    this.enabled = !this.enabled;
    if (this.ctx && this.bgmGain) {
      this.bgmGain.gain.setValueAtTime(this.enabled ? 0.35 : 0, this.ctx.currentTime);
    }
    return this.enabled;
  }

  public playTone(
    startFreq: number,
    endFreq: number,
    duration: number,
    type: OscillatorType = 'sawtooth',
    volume: number = 0.25
  ) {
    if (!this.enabled) return;
    this.init();
    if (!this.ctx) return;

    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = type;
      const now = this.ctx.currentTime;

      osc.frequency.setValueAtTime(Math.max(20, startFreq), now);
      osc.frequency.exponentialRampToValueAtTime(Math.max(20, endFreq), now + duration);

      gain.gain.setValueAtTime(Math.min(1, volume), now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + duration);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(now);
      osc.stop(now + duration + 0.05);
    } catch {
      // AudioContext fallback guard
    }
  }

  // Sound FX
  public sndSlash() {
    this.playTone(850, 140, 0.11, 'sawtooth', 0.35);
  }

  public sndMagic() {
    this.playTone(320, 1300, 0.15, 'sine', 0.3);
  }

  public sndShield() {
    this.playTone(260, 420, 0.09, 'triangle', 0.4);
  }

  public sndBlast() {
    this.playTone(140, 35, 0.28, 'square', 0.45);
  }

  public sndMiss() {
    this.playTone(180, 50, 0.2, 'sawtooth', 0.25);
  }

  public sndBossHit() {
    this.playTone(120, 220, 0.09, 'sawtooth', 0.2);
  }

  public sndRoar() {
    this.playTone(80, 300, 0.6, 'sawtooth', 0.45);
  }

  public sndWin() {
    this.playTone(523.25, 659.25, 0.2, 'triangle', 0.3);
    setTimeout(() => this.playTone(659.25, 783.99, 0.2, 'triangle', 0.3), 150);
    setTimeout(() => this.playTone(783.99, 1046.5, 0.35, 'triangle', 0.35), 300);
  }

  // Rhythmic Beat Synth (Kick, Snare, Bass note)
  public playDrumBeat(beatNum: number, laneBpm: number) {
    if (!this.enabled || !this.ctx) return;
    try {
      const now = this.ctx.currentTime;
      // Kick on 0, 2 (beat 1 & 3)
      if (beatNum % 4 === 0 || beatNum % 4 === 2) {
        const kick = this.ctx.createOscillator();
        const kickGain = this.ctx.createGain();
        kick.frequency.setValueAtTime(140, now);
        kick.frequency.exponentialRampToValueAtTime(35, now + 0.12);
        kickGain.gain.setValueAtTime(0.4, now);
        kickGain.gain.exponentialRampToValueAtTime(0.001, now + 0.13);
        kick.connect(kickGain);
        kickGain.connect(this.ctx.destination);
        kick.start(now);
        kick.stop(now + 0.14);
      }

      // Snare on 1, 3 (beat 2 & 4)
      if (beatNum % 4 === 1 || beatNum % 4 === 3) {
        const snare = this.ctx.createOscillator();
        const snareGain = this.ctx.createGain();
        snare.type = 'triangle';
        snare.frequency.setValueAtTime(220, now);
        snare.frequency.exponentialRampToValueAtTime(90, now + 0.08);
        snareGain.gain.setValueAtTime(0.3, now);
        snareGain.gain.exponentialRampToValueAtTime(0.001, now + 0.09);
        snare.connect(snareGain);
        snareGain.connect(this.ctx.destination);
        snare.start(now);
        snare.stop(now + 0.1);
      }

      // Bass synth note
      const bassNotes = [110, 110, 130.81, 146.83, 98.0];
      const noteFreq = bassNotes[beatNum % bassNotes.length];
      const bass = this.ctx.createOscillator();
      const bassGain = this.ctx.createGain();
      bass.type = 'sawtooth';
      bass.frequency.setValueAtTime(noteFreq, now);
      bassGain.gain.setValueAtTime(0.12, now);
      bassGain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
      bass.connect(bassGain);
      bassGain.connect(this.ctx.destination);
      bass.start(now);
      bass.stop(now + 0.2);
    } catch {
      // Audio safety
    }
  }
}

export const audio = new SoundEngine();
