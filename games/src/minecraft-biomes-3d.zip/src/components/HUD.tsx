import React from 'react';
import { Dimension, BiomeType } from '../types';
import { Compass, Camera, Package, Sparkles, Wand2 } from 'lucide-react';

interface HUDProps {
  health: number;
  maxHealth: number;
  hunger: number;
  maxHunger: number;
  dimension: Dimension;
  biome: BiomeType;
  position: { x: number; y: number; z: number };
  timeStr: string;
  isNight: boolean;
  selectedItemName: string;
  dragonHealth?: number;
  dragonMaxHealth?: number;
  notification?: string | null;
  onToggleCamera: () => void;
  onToggleInventory: () => void;
  onToggleItemPicker: () => void;
  onToggleBiomeMenu: () => void;
  onMobileAttack?: () => void;
  onMobilePlace?: () => void;
  onMobileJump?: () => void;
}

export const HUD: React.FC<HUDProps> = ({
  health,
  maxHealth,
  hunger,
  maxHunger,
  dimension,
  biome,
  position,
  timeStr,
  isNight,
  selectedItemName,
  dragonHealth,
  dragonMaxHealth = 200,
  notification,
  onToggleCamera,
  onToggleInventory,
  onToggleItemPicker,
  onToggleBiomeMenu,
  onMobileAttack,
  onMobilePlace,
  onMobileJump
}) => {
  const getDimensionBadge = () => {
    switch (dimension) {
      case Dimension.NETHER:
        return { label: '🔥 지옥', bg: 'bg-red-900/80 text-red-200 border-red-600' };
      case Dimension.THE_END:
        return { label: '🌌 디 엔드', bg: 'bg-purple-900/80 text-purple-200 border-purple-600' };
      default:
        return { label: '🌍 오버월드', bg: 'bg-emerald-900/80 text-emerald-200 border-emerald-600' };
    }
  };

  const dimInfo = getDimensionBadge();

  return (
    <div className="absolute inset-0 pointer-events-none z-10 flex flex-col justify-between p-2 sm:p-3 select-none">
      {/* Top Header Bar */}
      <div className="flex flex-col gap-1.5 w-full">
        {/* Boss Health Bar if in The End or Dragon active */}
        {dragonHealth !== undefined && dragonHealth > 0 && (
          <div className="w-full max-w-xl mx-auto flex flex-col items-center pointer-events-auto bg-black/80 p-1.5 sm:p-2 rounded border-2 border-purple-600 shadow-lg">
            <div className="flex items-center gap-1.5 text-purple-300 font-bold text-base sm:text-xl drop-shadow mb-0.5">
              <Sparkles className="w-4 h-4 text-purple-400 animate-pulse" />
              <span>엔더 드래곤 (Ender Dragon)</span>
              <span className="text-xs sm:text-sm text-gray-300">[{Math.max(0, Math.round(dragonHealth))} / {dragonMaxHealth}]</span>
            </div>
            <div className="w-full h-3 sm:h-4 bg-gray-900 rounded border border-purple-400 overflow-hidden relative">
              <div
                className="h-full bg-gradient-to-r from-purple-600 via-pink-500 to-fuchsia-400 transition-all duration-150"
                style={{ width: `${Math.max(0, (dragonHealth / dragonMaxHealth) * 100)}%` }}
              />
            </div>
          </div>
        )}

        {/* Top Controls & Status */}
        <div className="flex flex-wrap justify-between items-start gap-2">
          {/* Left: Player Coordinates & Biome */}
          <div className="mc-panel-dark text-white p-1.5 sm:p-2.5 rounded pointer-events-auto flex flex-col gap-0.5 text-xs sm:text-sm border-2 border-gray-600 shadow-md">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className={`px-1.5 py-0.5 rounded text-[11px] font-bold border ${dimInfo.bg}`}>
                {dimInfo.label}
              </span>
              <span className="text-yellow-300 font-bold text-xs sm:text-sm">{biome}</span>
            </div>
            <div className="text-gray-300 text-[11px] sm:text-xs">
              X:<span className="text-cyan-300 font-mono">{position.x}</span> Y:<span className="text-cyan-300 font-mono">{position.y}</span> Z:<span className="text-cyan-300 font-mono">{position.z}</span>
            </div>
            <div className="text-[10px] sm:text-xs text-gray-400">
              시간: <span className={isNight ? 'text-purple-400' : 'text-amber-300'}>{timeStr}</span>
            </div>
          </div>

          {/* Center Notification */}
          {notification && (
            <div className="pointer-events-auto bg-black/90 text-yellow-300 px-3 py-1 sm:px-4 sm:py-2 rounded border-2 border-yellow-500 font-bold text-sm sm:text-lg shadow-xl animate-bounce max-w-xs sm:max-w-md text-center">
              {notification}
            </div>
          )}

          {/* Right: Quick Action Buttons */}
          <div className="flex flex-wrap gap-1 sm:gap-2 pointer-events-auto ml-auto">
            <button
              id="btn-item-picker"
              onClick={onToggleItemPicker}
              className="mc-button px-2 sm:px-3 py-1 sm:py-1.5 rounded flex items-center gap-1 text-xs sm:text-base bg-amber-700 hover:bg-amber-600 cursor-pointer shadow active:scale-95"
              title="아이템 선택기 (B)"
            >
              <Wand2 className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-yellow-300" />
              <span className="font-bold">아이템 (B)</span>
            </button>
            <button
              id="btn-biome-warp"
              onClick={onToggleBiomeMenu}
              className="mc-button px-2 sm:px-3 py-1 sm:py-1.5 rounded flex items-center gap-1 text-xs sm:text-base bg-blue-800 hover:bg-blue-700 cursor-pointer shadow active:scale-95"
              title="바이옴 이동 (T)"
            >
              <Compass className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-cyan-300" />
              <span className="font-bold">워프 (T)</span>
            </button>
            <button
              id="btn-inventory"
              onClick={onToggleInventory}
              className="mc-button px-2 sm:px-3 py-1 sm:py-1.5 rounded flex items-center gap-1 text-xs sm:text-base cursor-pointer shadow active:scale-95"
              title="인벤토리 & 조합창 (E)"
            >
              <Package className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-white" />
              <span className="font-bold">조합 (E)</span>
            </button>
            <button
              id="btn-camera"
              onClick={onToggleCamera}
              className="mc-button px-2 sm:px-2.5 py-1 sm:py-1.5 rounded flex items-center gap-1 text-xs sm:text-base cursor-pointer shadow active:scale-95"
              title="시점 변경 (F5)"
            >
              <Camera className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
              <span className="font-bold">F5</span>
            </button>
          </div>
        </div>
      </div>

      {/* Crosshair */}
      <div className="crosshair" />

      {/* Mobile Touch Action Controls (Left & Right Buttons) */}
      <div className="w-full flex justify-between items-end pointer-events-none px-2 mb-1 sm:mb-2">
        {/* Left Touch: Jump */}
        <div className="pointer-events-auto flex flex-col gap-2">
          {onMobileJump && (
            <button
              id="btn-mobile-jump"
              onClick={onMobileJump}
              onTouchStart={onMobileJump}
              className="mc-button w-12 h-12 sm:w-14 sm:h-14 rounded-full flex flex-col items-center justify-center text-sm font-bold bg-stone-800 hover:bg-stone-700 border-2 border-stone-400 active:scale-90 shadow-lg"
              title="점프 (Space)"
            >
              <span>점프</span>
              <span className="text-[10px] text-gray-300">Space</span>
            </button>
          )}
        </div>

        {/* Right Touch: Attack & Place */}
        <div className="pointer-events-auto flex gap-2">
          {onMobileAttack && (
            <button
              id="btn-mobile-attack"
              onClick={onMobileAttack}
              onTouchStart={onMobileAttack}
              className="mc-button px-3 py-2 rounded font-bold text-xs sm:text-sm bg-red-800 hover:bg-red-700 border-2 border-red-400 active:scale-90 shadow-lg flex flex-col items-center"
              title="공격 / 파괴 (좌클릭)"
            >
              <span>⚔️ 파괴/공격</span>
              <span className="text-[10px] text-red-200">좌클릭</span>
            </button>
          )}
          {onMobilePlace && (
            <button
              id="btn-mobile-place"
              onClick={onMobilePlace}
              onTouchStart={onMobilePlace}
              className="mc-button px-3 py-2 rounded font-bold text-xs sm:text-sm bg-emerald-800 hover:bg-emerald-700 border-2 border-emerald-400 active:scale-90 shadow-lg flex flex-col items-center"
              title="설치 / 사용 (우클릭)"
            >
              <span>🧱 설치/사용</span>
              <span className="text-[10px] text-emerald-200">우클릭</span>
            </button>
          )}
        </div>
      </div>

      {/* Bottom Status Section (Hearts, Hunger, Item Name) */}
      <div className="flex flex-col items-center gap-1 mb-1 pointer-events-none">
        {/* Health & Hunger row */}
        <div className="flex justify-between w-72 sm:w-80 max-w-full px-2">
          {/* Health Bar */}
          <div className="flex gap-0.5">
            {Array.from({ length: maxHealth }).map((_, i) => (
              <span key={i} className={`heart scale-90 sm:scale-100 ${i < health ? 'opacity-100' : 'opacity-20 grayscale'}`} />
            ))}
          </div>

          {/* Hunger Bar */}
          <div className="flex gap-0.5">
            {Array.from({ length: maxHunger }).map((_, i) => (
              <span key={i} className={`hunger scale-90 sm:scale-100 ${i < hunger ? 'opacity-100' : 'opacity-20 grayscale'}`} />
            ))}
          </div>
        </div>

        {/* Selected Item Banner */}
        {selectedItemName && (
          <div className="text-base sm:text-xl text-yellow-300 font-bold drop-shadow-[0_2px_4px_rgba(0,0,0,1)] bg-black/70 px-2.5 py-0.5 rounded border border-gray-600">
            {selectedItemName}
          </div>
        )}
      </div>
    </div>
  );
};
