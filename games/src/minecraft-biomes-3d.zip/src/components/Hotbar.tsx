import React from 'react';
import { InventoryItem, BLOCK_NAMES } from '../types';

interface HotbarProps {
  slots: (InventoryItem | null)[];
  selectedIndex: number;
  onSelectSlot: (index: number) => void;
}

export const Hotbar: React.FC<HotbarProps> = ({
  slots,
  selectedIndex,
  onSelectSlot
}) => {
  return (
    <div className="pointer-events-auto mc-panel p-1 flex gap-1 rounded bg-stone-700/80 shadow-2xl">
      {Array.from({ length: 9 }).map((_, i) => {
        const item = slots[i];
        const isActive = i === selectedIndex;
        const name = item ? (BLOCK_NAMES[item.id] || String(item.id)) : '';

        return (
          <div
            key={i}
            onClick={() => onSelectSlot(i)}
            className={`mc-slot flex items-center justify-center cursor-pointer transition-all ${
              isActive ? 'active ring-2 ring-yellow-400' : 'hover:bg-gray-400'
            }`}
            title={name}
          >
            {/* Slot Number indicator */}
            <span className="absolute top-0.5 left-1 text-[10px] text-gray-400 font-mono">
              {i + 1}
            </span>

            {item && (
              <>
                <span className="text-xs font-bold text-white drop-shadow-[0_1px_2px_rgba(0,0,0,1)] text-center px-1 leading-tight select-none">
                  {name.slice(0, 4)}
                </span>
                <span className="absolute bottom-0 right-1 text-xs font-bold text-yellow-300 drop-shadow-[0_1px_2px_rgba(0,0,0,1)]">
                  {item.count}
                </span>
              </>
            )}
          </div>
        );
      })}
    </div>
  );
};
