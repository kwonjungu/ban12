import React from 'react';
import { BIOME_LOCATIONS, BiomeCoordInfo } from '../world/biomes';
import { Dimension } from '../types';
import { Compass, X, MapPin } from 'lucide-react';
import { soundEngine } from '../audio/soundEngine';

interface BiomeTeleportMenuProps {
  isOpen: boolean;
  onClose: () => void;
  onTeleport: (location: BiomeCoordInfo) => void;
}

export const BiomeTeleportMenu: React.FC<BiomeTeleportMenuProps> = ({
  isOpen,
  onClose,
  onTeleport
}) => {
  if (!isOpen) return null;

  const handleSelect = (loc: BiomeCoordInfo) => {
    soundEngine.playTeleport();
    onTeleport(loc);
    onClose();
  };

  const overworldBiomes = BIOME_LOCATIONS.filter((b) => b.dimension === Dimension.OVERWORLD);
  const netherBiomes = BIOME_LOCATIONS.filter((b) => b.dimension === Dimension.NETHER);
  const endBiomes = BIOME_LOCATIONS.filter((b) => b.dimension === Dimension.THE_END);

  return (
    <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-2 sm:p-4 backdrop-blur-xs">
      <div className="mc-panel max-w-2xl w-full p-3 sm:p-5 rounded-lg flex flex-col max-h-[88vh] text-gray-900 shadow-2xl border-4 border-gray-300">
        <div className="flex justify-between items-center border-b-2 border-gray-600 pb-2 mb-2 sm:mb-3">
          <div className="flex items-center gap-1.5 sm:gap-2">
            <Compass className="w-5 h-5 sm:w-6 sm:h-6 text-blue-700" />
            <h2 className="text-xl sm:text-3xl font-bold text-gray-800 drop-shadow">
              바이옴 & 차원 순간이동 (Biomes)
            </h2>
          </div>
          <button
            onClick={onClose}
            className="mc-button px-2.5 sm:px-3 py-1 font-bold text-base sm:text-xl rounded flex items-center gap-1 cursor-pointer"
          >
            <X className="w-4 h-4 sm:w-5 sm:h-5" /> 닫기 (T)
          </button>
        </div>

        <div className="space-y-3 sm:space-y-4 max-h-[72vh] overflow-y-auto pr-1">
          {/* Overworld Section */}
          <div className="bg-emerald-950/20 p-3 rounded border border-emerald-600">
            <h3 className="text-xl font-bold text-emerald-900 mb-2 flex items-center gap-1">
              🌍 오버월드 바이옴
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {overworldBiomes.map((loc) => (
                <button
                  key={loc.name}
                  onClick={() => handleSelect(loc)}
                  className="mc-button p-2 text-left rounded hover:scale-105 active:scale-95 flex items-center gap-1.5 bg-gray-200 text-gray-900 border-gray-400"
                >
                  <MapPin className="w-4 h-4 text-emerald-700 shrink-0" />
                  <span className="font-bold text-sm">{loc.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Nether Section */}
          <div className="bg-red-950/20 p-3 rounded border border-red-600">
            <h3 className="text-xl font-bold text-red-900 mb-2 flex items-center gap-1">
              🔥 네더 (지옥) 바이옴
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {netherBiomes.map((loc) => (
                <button
                  key={loc.name}
                  onClick={() => handleSelect(loc)}
                  className="mc-button p-2 text-left rounded hover:scale-105 active:scale-95 flex items-center gap-1.5 bg-red-100 text-red-950 border-red-400"
                >
                  <MapPin className="w-4 h-4 text-red-700 shrink-0" />
                  <span className="font-bold text-sm">{loc.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* The End Section */}
          <div className="bg-purple-950/20 p-3 rounded border border-purple-600">
            <h3 className="text-xl font-bold text-purple-900 mb-2 flex items-center gap-1">
              🌌 디 엔드 (보스전)
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {endBiomes.map((loc) => (
                <button
                  key={loc.name}
                  onClick={() => handleSelect(loc)}
                  className="mc-button p-2.5 text-left rounded hover:scale-105 active:scale-95 flex items-center gap-2 bg-purple-100 text-purple-950 border-purple-400"
                >
                  <MapPin className="w-5 h-5 text-purple-700 shrink-0" />
                  <div>
                    <div className="font-bold text-base">{loc.name}</div>
                    <div className="text-xs text-purple-800">엔더 드래곤 서식지 & 흑요석 기둥</div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
