import React, { useState } from 'react';
import { InventoryItem, BLOCK_NAMES, BLOCKS } from '../types';
import { soundEngine } from '../audio/soundEngine';
import { X, Flame, Sparkles } from 'lucide-react';

interface InventoryCraftingModalProps {
  isOpen: boolean;
  onClose: () => void;
  inventory: (InventoryItem | null)[];
  onUpdateInventory: (inventory: (InventoryItem | null)[]) => void;
  onAddItem: (id: string | number, count: number) => void;
}

export const InventoryCraftingModal: React.FC<InventoryCraftingModalProps> = ({
  isOpen,
  onClose,
  inventory,
  onUpdateInventory,
  onAddItem
}) => {
  const [craftGrid, setCraftGrid] = useState<(string | number | null)[]>([null, null, null, null]);
  const [selectedSlotIdx, setSelectedSlotIdx] = useState<number | null>(null);

  if (!isOpen) return null;

  // Recipe evaluation
  const checkRecipe = () => {
    const items = craftGrid.filter(Boolean);

    // Ender Eye Recipe: Ender Pearl + Blaze Powder
    const hasPearl = items.includes('ender_pearl');
    const hasBlazePowder = items.includes('blaze_powder');
    if (hasPearl && hasBlazePowder) {
      return { id: 'ender_eye', count: 1, name: '엔더의 눈 👁️' };
    }

    // Wood to Planks
    if (items.includes(BLOCKS.OAK_WOOD) || items.includes(BLOCKS.JUNGLE_WOOD)) {
      return { id: BLOCKS.PLANKS, count: 4, name: '나무 판자 x4' };
    }

    // Planks (2) to Sticks
    const planksCount = items.filter((x) => x === BLOCKS.PLANKS).length;
    const stickCount = items.filter((x) => x === 'stick').length;
    const ironCount = items.filter((x) => x === 'iron_ingot').length;
    const diamondCount = items.filter((x) => x === 'diamond' || x === BLOCKS.DIAMOND_BLOCK).length;

    if (planksCount >= 2 && stickCount === 0) {
      return { id: 'stick', count: 4, name: '막대기 x4' };
    }

    // Swords
    if (stickCount >= 1 && diamondCount >= 2) {
      return { id: 'diamond_sword', count: 1, name: '다이아 검 💎⚔️' };
    }
    if (stickCount >= 1 && ironCount >= 2) {
      return { id: 'iron_sword', count: 1, name: '철 검 ⚔️' };
    }
    if (stickCount >= 1 && planksCount >= 2) {
      return { id: 'wood_sword', count: 1, name: '나무 검 🗡️' };
    }

    // Bow
    if (stickCount >= 2 && planksCount >= 2) {
      return { id: 'bow', count: 1, name: '활 🏹' };
    }

    // Crafting table
    if (planksCount >= 4) {
      return { id: BLOCKS.CRAFTING_TABLE, count: 1, name: '제작대 🛠️' };
    }

    return null;
  };

  const recipeResult = checkRecipe();

  const handleCraft = () => {
    if (!recipeResult) return;
    soundEngine.playCraft();
    onAddItem(recipeResult.id, recipeResult.count);
    setCraftGrid([null, null, null, null]);
  };

  const handleFurnaceSmelt = () => {
    const ironIdx = inventory.findIndex((item) => item && item.id === BLOCKS.IRON);
    const coalIdx = inventory.findIndex((item) => item && item.id === BLOCKS.COAL);

    if (ironIdx !== -1 && coalIdx !== -1) {
      soundEngine.playCraft();
      const updated = [...inventory];
      updated[ironIdx]!.count--;
      if (updated[ironIdx]!.count <= 0) updated[ironIdx] = null;

      updated[coalIdx]!.count--;
      if (updated[coalIdx]!.count <= 0) updated[coalIdx] = null;

      onUpdateInventory(updated);
      onAddItem('iron_ingot', 1);
    }
  };

  const handleSlotClick = (idx: number) => {
    if (selectedSlotIdx === null) {
      if (inventory[idx]) {
        setSelectedSlotIdx(idx);
      }
    } else {
      const updated = [...inventory];
      const temp = updated[selectedSlotIdx];
      updated[selectedSlotIdx] = updated[idx];
      updated[idx] = temp;
      setSelectedSlotIdx(null);
      onUpdateInventory(updated);
    }
  };

  const handlePutInCraft = (gridIdx: number) => {
    if (selectedSlotIdx !== null && inventory[selectedSlotIdx]) {
      const item = inventory[selectedSlotIdx]!;
      const newGrid = [...craftGrid];
      newGrid[gridIdx] = item.id;
      setCraftGrid(newGrid);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-2 sm:p-4 backdrop-blur-xs">
      <div className="mc-panel max-w-3xl w-full p-3 sm:p-6 rounded-lg text-gray-900 relative shadow-2xl max-h-[92vh] overflow-y-auto">
        <div className="flex justify-between items-center border-b-2 border-gray-600 pb-2 mb-3">
          <h2 className="text-xl sm:text-3xl font-bold text-gray-800 drop-shadow">
            제작대 & 인벤토리
          </h2>
          <button
            onClick={onClose}
            className="mc-button px-2.5 sm:px-3 py-1 text-base sm:text-xl font-bold rounded flex items-center gap-1 cursor-pointer"
          >
            <X className="w-4 h-4 sm:w-5 sm:h-5" /> 닫기 (E)
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-6">
          {/* Crafting Grid */}
          <div className="bg-gray-300 p-4 rounded border-2 border-gray-500 flex flex-col justify-between">
            <div>
              <h3 className="text-xl font-bold mb-3 text-center border-b border-gray-400 pb-1">
                2x2 아이템 조합대
              </h3>
              <div className="flex items-center justify-center gap-4 my-3">
                <div className="grid grid-cols-2 gap-1.5 bg-gray-400 p-2 rounded border-2 border-gray-600">
                  {craftGrid.map((itemId, i) => (
                    <div
                      key={i}
                      onClick={() => handlePutInCraft(i)}
                      className="mc-slot flex items-center justify-center cursor-pointer hover:bg-gray-300"
                    >
                      {itemId && (
                        <span className="text-xs font-bold text-gray-900 text-center px-1">
                          {BLOCK_NAMES[itemId]?.slice(0, 3) || String(itemId)}
                        </span>
                      )}
                    </div>
                  ))}
                </div>

                <div className="text-3xl font-bold text-gray-700">➔</div>

                {/* Result Slot */}
                <div
                  onClick={handleCraft}
                  className={`mc-slot active flex items-center justify-center cursor-pointer ${
                    recipeResult ? 'bg-amber-200 ring-2 ring-yellow-500' : ''
                  }`}
                >
                  {recipeResult && (
                    <div className="text-center">
                      <div className="text-xs font-bold text-blue-900">
                        {recipeResult.name.slice(0, 4)}
                      </div>
                      <div className="text-xs font-bold text-yellow-700">
                        x{recipeResult.count}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <button
                onClick={handleCraft}
                disabled={!recipeResult}
                className="mc-button w-full py-2 font-bold text-lg rounded disabled:opacity-50"
              >
                아이템 조합하기
              </button>
            </div>

            {/* Recipe Tips */}
            <div className="mt-4 bg-gray-200 p-2.5 rounded text-xs text-gray-700 leading-relaxed border border-gray-400">
              <div className="font-bold mb-1 flex items-center gap-1 text-purple-800">
                <Sparkles className="w-3.5 h-3.5" /> 특수 조합 힌트:
              </div>
              <div>• <b>엔더의 눈:</b> 엔더 진주 + 블레이즈 가루</div>
              <div>• <b>다이아 검:</b> 막대기 + 다이아몬드 2개</div>
              <div>• <b>나무 판자:</b> 원목 1개 ➔ 판자 4개</div>
            </div>
          </div>

          {/* Player Inventory & Furnace */}
          <div className="flex flex-col justify-between">
            <div>
              <h3 className="text-xl font-bold mb-2 text-center border-b border-gray-400 pb-1">
                플레이어 보관함 (클릭하여 이동)
              </h3>
              <div className="grid grid-cols-5 gap-1.5 p-2 bg-gray-400 rounded border-2 border-gray-600 max-h-52 overflow-y-auto">
                {inventory.map((item, idx) => {
                  const isSelected = selectedSlotIdx === idx;
                  const name = item ? (BLOCK_NAMES[item.id] || String(item.id)) : '';
                  return (
                    <div
                      key={idx}
                      onClick={() => handleSlotClick(idx)}
                      className={`mc-slot flex items-center justify-center cursor-pointer hover:bg-gray-300 ${
                        isSelected ? 'ring-4 ring-yellow-400 bg-gray-500 scale-105' : ''
                      }`}
                      title={name}
                    >
                      {item && (
                        <>
                          <span className="text-[11px] font-bold text-white drop-shadow text-center p-0.5 leading-tight">
                            {name.slice(0, 3)}
                          </span>
                          <span className="absolute bottom-0 right-1 text-[11px] font-bold text-yellow-300 drop-shadow">
                            {item.count}
                          </span>
                        </>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Furnace Smelting Box */}
            <div className="mt-3 bg-gray-300 p-3 rounded border-2 border-gray-500">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5 font-bold text-sm text-gray-800">
                  <Flame className="w-4 h-4 text-orange-600 animate-pulse" />
                  <span>화로 제련 (철 광석 + 석탄)</span>
                </div>
                <button
                  onClick={handleFurnaceSmelt}
                  className="mc-button px-3 py-1 text-sm font-bold rounded bg-orange-700 hover:bg-orange-600"
                >
                  제련하기 🔥
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
