import React, { useState } from 'react';
import { ITEM_CATALOG, InventoryItem } from '../types';
import { Search, X, Plus, Sparkles, Shield, Box, Egg } from 'lucide-react';
import { soundEngine } from '../audio/soundEngine';

interface ItemPickerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectItem: (item: InventoryItem) => void;
}

export const ItemPickerModal: React.FC<ItemPickerModalProps> = ({
  isOpen,
  onClose,
  onSelectItem
}) => {
  const [activeTab, setActiveTab] = useState<'all' | 'block' | 'weapon' | 'item' | 'spawn'>('all');
  const [searchTerm, setSearchTerm] = useState('');

  if (!isOpen) return null;

  const filteredItems = ITEM_CATALOG.filter((item) => {
    const matchesTab = activeTab === 'all' || item.category === activeTab;
    const matchesSearch =
      item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.desc.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesTab && matchesSearch;
  });

  const handleItemClick = (catalogItem: typeof ITEM_CATALOG[0]) => {
    soundEngine.playPlace();
    onSelectItem({
      id: catalogItem.id,
      count: catalogItem.count,
      name: catalogItem.name,
      category: catalogItem.category
    });
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-2 sm:p-4 backdrop-blur-xs">
      <div className="mc-panel max-w-4xl w-full p-3 sm:p-5 rounded-lg flex flex-col max-h-[92vh] sm:max-h-[85vh] text-gray-900 shadow-2xl border-4 border-gray-300 relative">
        {/* Modal Header */}
        <div className="flex justify-between items-center border-b-2 border-gray-600 pb-2 mb-2 sm:pb-3 sm:mb-3">
          <div className="flex items-center gap-1.5 sm:gap-2">
            <Sparkles className="w-5 h-5 sm:w-6 sm:h-6 text-yellow-600" />
            <h2 className="text-xl sm:text-3xl font-bold text-gray-800 drop-shadow">
              아이템 선택기 (Item Catalog)
            </h2>
          </div>
          <button
            onClick={onClose}
            className="mc-button px-2.5 sm:px-3 py-1 font-bold text-base sm:text-xl rounded flex items-center gap-1 cursor-pointer"
          >
            <X className="w-4 h-4 sm:w-5 sm:h-5" /> 닫기 (B)
          </button>
        </div>

        {/* Category Tabs & Search Bar */}
        <div className="flex flex-col sm:flex-row justify-between gap-2 sm:gap-3 mb-3">
          <div className="flex flex-wrap gap-1">
            {[
              { id: 'all', label: '전체', icon: null },
              { id: 'block', label: '블록', icon: Box },
              { id: 'weapon', label: '무기·도구', icon: Shield },
              { id: 'item', label: '특수·재료', icon: Sparkles },
              { id: 'spawn', label: '소환 알', icon: Egg }
            ].map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as typeof activeTab)}
                  className={`mc-button px-2 sm:px-3 py-1 sm:py-1.5 text-xs sm:text-base font-bold rounded flex items-center gap-1 cursor-pointer ${
                    isActive ? 'bg-amber-600 border-amber-300 text-yellow-100' : ''
                  }`}
                >
                  {Icon && <Icon className="w-3.5 h-3.5 sm:w-4 sm:h-4" />}
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* Search Input */}
          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 absolute left-2.5 top-2.5 text-gray-500" />
            <input
              type="text"
              placeholder="아이템 검색 (예: 옵시디언, 엔더)..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-8 pr-3 py-1 sm:py-1.5 bg-gray-200 border-2 border-gray-600 rounded text-sm sm:text-base text-gray-900 focus:outline-hidden focus:ring-2 focus:ring-amber-500 font-sans"
            />
          </div>
        </div>

        {/* Item Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-2 sm:gap-3 overflow-y-auto p-2 bg-gray-300 rounded border-2 border-gray-500 flex-1 min-h-[200px]">
          {filteredItems.map((item) => (
            <div
              key={String(item.id)}
              onClick={() => handleItemClick(item)}
              className="mc-slot w-full h-auto p-2.5 rounded flex flex-col justify-between items-center cursor-pointer hover:bg-gray-400 active:scale-95 transition group bg-gray-200 shadow"
            >
              <div className="text-center font-bold text-gray-900 group-hover:text-blue-900 text-base leading-snug">
                {item.name}
              </div>
              <div className="text-[12px] text-gray-600 text-center my-1 line-clamp-2">
                {item.desc}
              </div>
              <div className="flex justify-between items-center w-full mt-1 border-t border-gray-400 pt-1 text-xs">
                <span className="text-blue-700 font-bold">x{item.count}</span>
                <span className="mc-button px-1.5 py-0.5 text-[11px] rounded flex items-center gap-0.5">
                  <Plus className="w-3 h-3" /> 가져오기
                </span>
              </div>
            </div>
          ))}

          {filteredItems.length === 0 && (
            <div className="col-span-full py-16 text-center text-gray-600 text-xl font-bold">
              검색된 아이템이 없습니다.
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="mt-3 text-xs text-gray-600 flex justify-between items-center">
          <span>클릭 시 현재 선택된 핫바 슬롯 또는 인벤토리에 아이템이 즉시 지급됩니다.</span>
          <span className="font-bold text-gray-700">총 {filteredItems.length}개 아이템</span>
        </div>
      </div>
    </div>
  );
};
