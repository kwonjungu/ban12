export enum Dimension {
  OVERWORLD = 'OVERWORLD',
  NETHER = 'NETHER',
  THE_END = 'THE_END'
}

export enum BiomeType {
  PLAINS = 'PLAINS',
  FOREST = 'FOREST',
  DESERT = 'DESERT',
  SNOW_MOUNTAIN = 'SNOW_MOUNTAIN',
  OCEAN = 'OCEAN',
  JUNGLE = 'JUNGLE',
  STRONGHOLD = 'STRONGHOLD',
  NETHER_WASTES = 'NETHER_WASTES',
  WARPED_FOREST = 'WARPED_FOREST',
  NETHER_FORTRESS = 'NETHER_FORTRESS',
  THE_END = 'THE_END'
}

export const BLOCKS = {
  AIR: 0,
  GRASS: 1,
  DIRT: 2,
  STONE: 3,
  OAK_WOOD: 4,
  OAK_LEAVES: 5,
  COAL: 6,
  IRON: 7,
  PLANKS: 8,
  DIAMOND_ORE: 9,
  DIAMOND_BLOCK: 10,
  CRAFTING_TABLE: 11,
  FURNACE: 12,
  SAND: 13,
  SNOW: 14,
  ICE: 15,
  CACTUS: 16,
  OBSIDIAN: 17,
  NETHER_PORTAL: 18,
  END_PORTAL_FRAME: 19,
  END_PORTAL_FRAME_EYE: 20,
  END_PORTAL: 21,
  NETHERRACK: 22,
  NETHER_BRICKS: 23,
  WARPED_NYLIUM: 24,
  WARPED_STEM: 25,
  WARPED_WART: 26,
  GLOWSTONE: 27,
  END_STONE: 28,
  PURPUR_BLOCK: 29,
  JUNGLE_WOOD: 30,
  JUNGLE_LEAVES: 31,
  WATER: 32,
  STONE_BRICKS: 33,
  MOSSY_STONE_BRICKS: 34,
  LAVA: 35
} as const;

export type BlockId = typeof BLOCKS[keyof typeof BLOCKS];

export interface InventoryItem {
  id: string | number;
  count: number;
  name?: string;
  category?: 'block' | 'weapon' | 'tool' | 'item' | 'spawn';
}

export const ITEM_CATALOG: { id: string | number; name: string; count: number; category: 'block' | 'weapon' | 'item' | 'spawn'; iconText?: string; desc: string }[] = [
  // Blocks
  { id: BLOCKS.GRASS, name: '잔디 블록', count: 64, category: 'block', desc: '자연의 푸른 잔디' },
  { id: BLOCKS.DIRT, name: '흙 블록', count: 64, category: 'block', desc: '기본 대지 블록' },
  { id: BLOCKS.STONE, name: '돌 블록', count: 64, category: 'block', desc: '단단한 암석' },
  { id: BLOCKS.STONE_BRICKS, name: '석재 벽돌', count: 64, category: 'block', desc: '포탈룸 건축 벽돌' },
  { id: BLOCKS.MOSSY_STONE_BRICKS, name: '이끼 낀 석재 벽돌', count: 64, category: 'block', desc: '고대 유적 벽돌' },
  { id: BLOCKS.OAK_WOOD, name: '참나무 원목', count: 64, category: 'block', desc: '숲과 평원의 나무' },
  { id: BLOCKS.OAK_LEAVES, name: '참나무 잎', count: 64, category: 'block', desc: '나뭇잎' },
  { id: BLOCKS.JUNGLE_WOOD, name: '정글 원목', count: 64, category: 'block', desc: '정글의 거대 나무' },
  { id: BLOCKS.JUNGLE_LEAVES, name: '정글 잎', count: 64, category: 'block', desc: '선명한 열대 잎' },
  { id: BLOCKS.PLANKS, name: '나무 판자', count: 64, category: 'block', desc: '건축 및 조합 기본 재료' },
  { id: BLOCKS.SAND, name: '모래 블록 🏜️', count: 64, category: 'block', desc: '사막의 부드러운 모래' },
  { id: BLOCKS.SNOW, name: '눈 블록 ❄️', count: 64, category: 'block', desc: '눈산의 차가운 눈' },
  { id: BLOCKS.ICE, name: '얼음 블록 🧊', count: 64, category: 'block', desc: '투명하고 미끄러운 얼음' },
  { id: BLOCKS.WATER, name: '바다 물 블록 🌊', count: 64, category: 'block', desc: '푸른 바다' },
  { id: BLOCKS.CACTUS, name: '선인장 🌵', count: 64, category: 'block', desc: '사막의 가시 식물' },
  { id: BLOCKS.OBSIDIAN, name: '옵시디언 🟣', count: 64, category: 'block', desc: '초고밀도 암석, 네더 포탈의 재료' },
  { id: BLOCKS.NETHER_PORTAL, name: '네더 포탈 블록 🌀', count: 64, category: 'block', desc: '지옥으로 통하는 보랏빛 차원문' },
  { id: BLOCKS.END_PORTAL_FRAME, name: '엔더 포탈 프레임 🟩', count: 12, category: 'block', desc: '엔더의 눈을 장착할 수 있는 유적 프레임' },
  { id: BLOCKS.END_PORTAL, name: '엔더 포탈 블록 🌌', count: 12, category: 'block', desc: '우주 별빛의 디 엔드 차원문' },
  { id: BLOCKS.NETHERRACK, name: '네더랙 🌋', count: 64, category: 'block', desc: '지옥의 붉은 불타는 암석' },
  { id: BLOCKS.NETHER_BRICKS, name: '네더 벽돌 🏰', count: 64, category: 'block', desc: '네더 요새의 고풍스러운 벽돌' },
  { id: BLOCKS.WARPED_NYLIUM, name: '워프드 나일륨 🍄', count: 64, category: 'block', desc: '푸른숲의 빛나는 청록 균사체' },
  { id: BLOCKS.WARPED_STEM, name: '워프드 줄기 🪵', count: 64, category: 'block', desc: '푸른숲의 뒤틀린 원목' },
  { id: BLOCKS.GLOWSTONE, name: '발광석 ✨', count: 64, category: 'block', desc: '네더를 밝히는 빛나는 블록' },
  { id: BLOCKS.END_STONE, name: '엔드 스톤 🌕', count: 64, category: 'block', desc: '엔더 월드의 공허 암석' },
  { id: BLOCKS.PURPUR_BLOCK, name: '퍼퍼 블록 🟪', count: 64, category: 'block', desc: '엔드 도시의 보라색 건축석' },
  { id: BLOCKS.DIAMOND_BLOCK, name: '다이아몬드 블록 💎', count: 64, category: 'block', desc: '가장 화려한 보석 블록' },
  { id: BLOCKS.CRAFTING_TABLE, name: '제작대 🛠️', count: 16, category: 'block', desc: '아이템 조합' },
  { id: BLOCKS.FURNACE, name: '화로 🔥', count: 16, category: 'block', desc: '광석 제련' },

  // Weapons & Tools
  { id: 'diamond_sword', name: '다이아몬드 검 💎⚔️', count: 1, category: 'weapon', desc: '공격력 12, 앤더 드래곤 공략용 최강 무기' },
  { id: 'iron_sword', name: '철 검 ⚔️', count: 1, category: 'weapon', desc: '공격력 8, 든든한 금속 검' },
  { id: 'stone_sword', name: '돌 검 🗡️', count: 1, category: 'weapon', desc: '공격력 5' },
  { id: 'wood_sword', name: '나무 검 🗡️', count: 1, category: 'weapon', desc: '공격력 3' },
  { id: 'bow', name: '원거리 활 🏹', count: 1, category: 'weapon', desc: '공격력 10, 블레이즈와 드래곤 원거리 저격' },
  { id: 'arrow', name: '화살 🏹', count: 64, category: 'item', desc: '활의 탄약' },

  // Special Items requested
  { id: 'ender_eye', name: '엔더의 눈 👁️', count: 16, category: 'item', desc: '우클릭: 포탈룸 방향 탐색 & 포탈 프레임 활성화' },
  { id: 'ender_pearl', name: '엔더 진주 🔮', count: 16, category: 'item', desc: '우클릭: 조준한 위치로 순간이동(텔레포트)' },
  { id: 'blaze_powder', name: '블레이즈 가루 💥', count: 32, category: 'item', desc: '블레이즈 처치 시 획득, 엔더의 눈 조합 재료' },
  { id: 'blaze_rod', name: '블레이즈 막대 🥖', count: 16, category: 'item', desc: '불타는 블레이즈 막대' },
  { id: 'diamond', name: '다이아몬드 💎', count: 64, category: 'item', desc: '귀중한 보석' },
  { id: 'iron_ingot', name: '철 주괴 🪙', count: 64, category: 'item', desc: '철 제련 주괴' },
  { id: 'stick', name: '막대기 🥢', count: 64, category: 'item', desc: '도구 손잡이' },
  { id: 'golden_apple', name: '황금 사과 🍎', count: 16, category: 'item', desc: '우클릭: 체력 즉시 완전 회복 & 흡수' },
  { id: 'cooked_pork', name: '구운 돼지고기 🍖', count: 32, category: 'item', desc: '우클릭: 배고픔 및 체력 회복' },
  { id: 'raw_beef', name: '생 소고기 🥩', count: 32, category: 'item', desc: '식량' },

  // Spawn Eggs
  { id: 'spawn_blaze', name: '블레이즈 소환 알 🥚', count: 10, category: 'spawn', desc: '우클릭: 불타는 블레이즈 소환' },
  { id: 'spawn_enderman', name: '엔더맨 소환 알 🥚', count: 10, category: 'spawn', desc: '우클릭: 3블록 키의 엔더맨 소환' },
  { id: 'spawn_ender_dragon', name: '엔더 드래곤 소환 🐉', count: 1, category: 'spawn', desc: '우클릭: 전설의 엔더 드래곤 보스 소환' },
  { id: 'spawn_zombie', name: '좀비 소환 알 🥚', count: 10, category: 'spawn', desc: '우클릭: 좀비 소환' },
  { id: 'spawn_pig', name: '돼지 소환 알 🐷', count: 10, category: 'spawn', desc: '우클릭: 아기자기한 돼지 소환' },
  { id: 'spawn_cow', name: '소 소환 알 🐮', count: 10, category: 'spawn', desc: '우클릭: 소 소환' }
];

export const BLOCK_NAMES: Record<string | number, string> = {
  ...Object.fromEntries(ITEM_CATALOG.map(i => [i.id, i.name])),
  [BLOCKS.COAL]: '석탄 광석 🪨',
  [BLOCKS.IRON]: '철 광석 ⛏️'
};

export const WEAPON_DAMAGE: Record<string, number> = {
  wood_sword: 3,
  stone_sword: 5,
  iron_sword: 8,
  diamond_sword: 14,
  bow: 12
};
