import * as THREE from 'three';
import { createPixelTexture } from '../graphics/textures';
import { soundEngine } from '../audio/soundEngine';

export interface EntityHitTarget {
  takeDamage: (amount: number) => void;
}

export interface Projectile {
  mesh: THREE.Mesh | THREE.Group;
  velocity: THREE.Vector3;
  type: 'arrow' | 'fireball' | 'dragon_breath' | 'ender_pearl' | 'ender_eye';
  lifetime: number;
  owner: 'player' | 'blaze' | 'dragon';
}

export class BlazeMob {
  mesh: THREE.Group;
  pos: THREE.Vector3;
  health = 20;
  maxHealth = 20;
  rods: THREE.Mesh[] = [];
  attackCooldown = 0;
  hoverTimer = 0;
  dead = false;

  constructor(x: number, y: number, z: number, scene: THREE.Scene) {
    this.pos = new THREE.Vector3(x, y, z);
    this.mesh = this.createMesh();
    this.mesh.position.copy(this.pos);
    scene.add(this.mesh);
  }

  private createMesh(): THREE.Group {
    const group = new THREE.Group();

    // Head with glowing eyes
    const headMat = [
      new THREE.MeshBasicMaterial({ color: 0xe65100 }),
      new THREE.MeshBasicMaterial({ color: 0xe65100 }),
      new THREE.MeshBasicMaterial({ color: 0xe65100 }),
      new THREE.MeshBasicMaterial({ color: 0xd84315 }),
      new THREE.MeshBasicMaterial({ map: createPixelTexture('blaze_face') }),
      new THREE.MeshBasicMaterial({ color: 0xe65100 })
    ];
    const head = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.5, 0.5), headMat);
    head.position.y = 0.9;
    group.add(head);

    // Smoky body core
    const coreMat = new THREE.MeshBasicMaterial({ color: 0x221100, transparent: true, opacity: 0.7 });
    const core = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.7, 0.35), coreMat);
    core.position.y = 0.35;
    group.add(core);

    // 12 Rotating Blaze Rods in 3 tiers
    const rodMat = new THREE.MeshBasicMaterial({ color: 0xffb300 });
    const rodGeo = new THREE.BoxGeometry(0.1, 0.45, 0.1);

    for (let tier = 0; tier < 3; tier++) {
      const count = 4;
      const radius = 0.45 + tier * 0.15;
      const yOffset = 0.9 - tier * 0.35;
      for (let i = 0; i < count; i++) {
        const rod = new THREE.Mesh(rodGeo, rodMat);
        rod.position.y = yOffset;
        rod.userData = { angle: (i / count) * Math.PI * 2, radius, tier };
        group.add(rod);
        this.rods.push(rod);
      }
    }

    group.userData = { entity: this };
    return group;
  }

  update(
    delta: number,
    playerPos: THREE.Vector3,
    spawnProjectile: (p: Projectile) => void
  ) {
    if (this.dead) return;

    this.hoverTimer += delta * 2;
    // Rotate floating rods
    this.rods.forEach((rod) => {
      const data = rod.userData;
      data.angle += delta * (data.tier % 2 === 0 ? 3 : -3);
      rod.position.x = Math.cos(data.angle) * data.radius;
      rod.position.z = Math.sin(data.angle) * data.radius;
    });

    // Hover bobbing
    this.pos.y += Math.sin(this.hoverTimer) * 0.015;

    const dist = this.pos.distanceTo(playerPos);
    if (dist < 22) {
      // Look at player
      const dir = new THREE.Vector3().subVectors(playerPos, this.pos).normalize();
      this.mesh.rotation.y = Math.atan2(dir.x, dir.z);

      // Attack player with fireball
      this.attackCooldown -= delta;
      if (this.attackCooldown <= 0) {
        this.attackCooldown = 2.5 + Math.random() * 1.5;
        soundEngine.playBlazeFireball();

        // Spawn fireball
        const fbGeo = new THREE.SphereGeometry(0.2, 8, 8);
        const fbMat = new THREE.MeshBasicMaterial({ color: 0xff5722 });
        const fbMesh = new THREE.Mesh(fbGeo, fbMat);
        fbMesh.position.copy(this.pos).add(new THREE.Vector3(0, 0.9, 0));

        spawnProjectile({
          mesh: fbMesh,
          velocity: dir.multiplyScalar(12),
          type: 'fireball',
          lifetime: 4,
          owner: 'blaze'
        });
      }
    }

    this.mesh.position.copy(this.pos);
  }

  takeDamage(amount: number) {
    this.health -= amount;
    soundEngine.playHurt();
    this.mesh.traverse((child) => {
      if (child instanceof THREE.Mesh && child.material) {
        const mat = child.material;
        if ('color' in mat) {
          (mat.color as THREE.Color).setHex(0xff0000);
          setTimeout(() => {
            if ('color' in mat) (mat.color as THREE.Color).setHex(0xffb300);
          }, 150);
        }
      }
    });
  }

  die(scene: THREE.Scene, addItem: (id: string, count: number) => void) {
    this.dead = true;
    scene.remove(this.mesh);
    addItem('blaze_powder', 2 + Math.floor(Math.random() * 2));
    addItem('blaze_rod', 1);
  }
}

export class EndermanMob {
  mesh: THREE.Group;
  pos: THREE.Vector3;
  health = 40;
  maxHealth = 40;
  dead = false;
  angry = false;
  teleportCooldown = 0;
  attackCooldown = 0;
  jawMesh: THREE.Mesh | null = null;

  constructor(x: number, y: number, z: number, scene: THREE.Scene) {
    this.pos = new THREE.Vector3(x, y, z);
    this.mesh = this.createMesh();
    this.mesh.position.copy(this.pos);
    scene.add(this.mesh);
  }

  private createMesh(): THREE.Group {
    const group = new THREE.Group();
    const blackMat = new THREE.MeshBasicMaterial({ color: 0x08080c });

    // Head with glowing purple eyes
    const headMat = [
      blackMat,
      blackMat,
      blackMat,
      blackMat,
      new THREE.MeshBasicMaterial({ map: createPixelTexture('enderman_face') }),
      blackMat
    ];
    const head = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.4, 0.4), headMat);
    head.position.y = 2.7;
    group.add(head);

    // Slim body
    const body = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.9, 0.18), blackMat);
    body.position.y = 1.95;
    group.add(body);

    // Slender arms
    const armGeo = new THREE.BoxGeometry(0.1, 1.2, 0.1);
    const leftArm = new THREE.Mesh(armGeo, blackMat);
    leftArm.position.set(-0.25, 1.8, 0);
    group.add(leftArm);

    const rightArm = new THREE.Mesh(armGeo, blackMat);
    rightArm.position.set(0.25, 1.8, 0);
    group.add(rightArm);

    // Slender legs
    const legGeo = new THREE.BoxGeometry(0.1, 1.5, 0.1);
    const leftLeg = new THREE.Mesh(legGeo, blackMat);
    leftLeg.position.set(-0.1, 0.75, 0);
    group.add(leftLeg);

    const rightLeg = new THREE.Mesh(legGeo, blackMat);
    rightLeg.position.set(0.1, 0.75, 0);
    group.add(rightLeg);

    group.userData = { entity: this };
    return group;
  }

  update(
    delta: number,
    playerPos: THREE.Vector3,
    onPlayerHit: (dmg: number) => void
  ) {
    if (this.dead) return;

    const dist = this.pos.distanceTo(playerPos);
    this.teleportCooldown -= delta;
    this.attackCooldown -= delta;

    if (this.angry || dist < 8) {
      this.angry = true;
      const dir = new THREE.Vector3().subVectors(playerPos, this.pos);
      dir.y = 0;
      dir.normalize();

      this.mesh.rotation.y = Math.atan2(dir.x, dir.z);

      // Fast chase speed
      this.pos.x += dir.x * 4.5 * delta;
      this.pos.z += dir.z * 4.5 * delta;

      // Teleportation ability if distance is medium or on hit
      if (this.teleportCooldown <= 0 && (dist > 7 || Math.random() < 0.02)) {
        this.teleportBehindPlayer(playerPos);
      }

      if (dist < 1.8 && this.attackCooldown <= 0) {
        this.attackCooldown = 1.2;
        onPlayerHit(4); // 4 damage to player
      }
    }

    this.mesh.position.copy(this.pos);
  }

  teleportBehindPlayer(playerPos: THREE.Vector3) {
    soundEngine.playTeleport();
    this.teleportCooldown = 3.5;
    const angle = Math.random() * Math.PI * 2;
    const offsetDist = 2.5 + Math.random() * 2;
    this.pos.x = playerPos.x + Math.sin(angle) * offsetDist;
    this.pos.z = playerPos.z + Math.cos(angle) * offsetDist;
  }

  takeDamage(amount: number, playerPos?: THREE.Vector3) {
    this.health -= amount;
    this.angry = true;
    soundEngine.playHurt();

    if (playerPos && Math.random() < 0.6) {
      this.teleportBehindPlayer(playerPos);
    }
  }

  die(scene: THREE.Scene, addItem: (id: string, count: number) => void) {
    this.dead = true;
    scene.remove(this.mesh);
    addItem('ender_pearl', 1 + Math.floor(Math.random() * 2));
  }
}

export class EnderDragonBoss {
  mesh: THREE.Group;
  pos = new THREE.Vector3(60, 24, 60);
  health = 200;
  maxHealth = 200;
  dead = false;
  wingAngle = 0;
  flightTimer = 0;
  attackTimer = 0;
  leftWing: THREE.Mesh | null = null;
  rightWing: THREE.Mesh | null = null;

  constructor(scene: THREE.Scene) {
    this.mesh = this.createMesh();
    this.mesh.position.copy(this.pos);
    scene.add(this.mesh);
    soundEngine.playDragonRoar();
  }

  private createMesh(): THREE.Group {
    const group = new THREE.Group();
    const dragonMat = new THREE.MeshLambertMaterial({ color: 0x111116 });
    const underbellyMat = new THREE.MeshLambertMaterial({ color: 0x1e1e28 });

    // Main Body
    const body = new THREE.Mesh(new THREE.BoxGeometry(2.2, 1.6, 4.5), dragonMat);
    body.position.y = 0;
    group.add(body);

    // Neck
    const neck = new THREE.Mesh(new THREE.BoxGeometry(1.0, 1.0, 2.5), dragonMat);
    neck.position.set(0, 0.4, 3.2);
    neck.rotation.x = 0.2;
    group.add(neck);

    // Head with glowing purple eyes
    const headGroup = new THREE.Group();
    headGroup.position.set(0, 0.8, 4.8);

    const headMat = [
      dragonMat,
      dragonMat,
      dragonMat,
      underbellyMat,
      new THREE.MeshBasicMaterial({ color: 0x111116 }),
      new THREE.MeshBasicMaterial({ color: 0x111116 })
    ];
    const head = new THREE.Mesh(new THREE.BoxGeometry(1.4, 1.1, 1.8), headMat);
    headGroup.add(head);

    // Glowing Dragon Eyes
    const eyeMat = new THREE.MeshBasicMaterial({ color: 0xd946ef });
    const eyeGeo = new THREE.BoxGeometry(0.2, 0.15, 0.2);
    const leftEye = new THREE.Mesh(eyeGeo, eyeMat);
    leftEye.position.set(-0.65, 0.2, 0.5);
    headGroup.add(leftEye);

    const rightEye = new THREE.Mesh(eyeGeo, eyeMat);
    rightEye.position.set(0.65, 0.2, 0.5);
    headGroup.add(rightEye);

    // Snout
    const snout = new THREE.Mesh(new THREE.BoxGeometry(1.0, 0.6, 1.2), dragonMat);
    snout.position.set(0, -0.2, 1.3);
    headGroup.add(snout);

    group.add(headGroup);

    // Tail
    const tail = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.8, 4.0), dragonMat);
    tail.position.set(0, 0.1, -4.0);
    group.add(tail);

    // Wings (Massive flapping wings)
    const wingGeo = new THREE.BoxGeometry(4.5, 0.1, 2.2);
    const wingMat = new THREE.MeshLambertMaterial({ color: 0x1e1e28, side: THREE.DoubleSide });

    this.leftWing = new THREE.Mesh(wingGeo, wingMat);
    this.leftWing.position.set(-3.2, 0.4, 0.5);
    group.add(this.leftWing);

    this.rightWing = new THREE.Mesh(wingGeo, wingMat);
    this.rightWing.position.set(3.2, 0.4, 0.5);
    group.add(this.rightWing);

    group.scale.set(1.5, 1.5, 1.5);
    group.userData = { entity: this };
    return group;
  }

  update(
    delta: number,
    playerPos: THREE.Vector3,
    spawnProjectile: (p: Projectile) => void
  ) {
    if (this.dead) return;

    this.flightTimer += delta * 0.8;
    this.wingAngle += delta * 6;

    // Wing flap animation
    if (this.leftWing && this.rightWing) {
      this.leftWing.rotation.z = Math.sin(this.wingAngle) * 0.45;
      this.rightWing.rotation.z = -Math.sin(this.wingAngle) * 0.45;
    }

    // Majestic swooping flight around island center (60, 60)
    const center = new THREE.Vector2(60, 60);
    const radius = 26;
    const targetX = center.x + Math.cos(this.flightTimer) * radius;
    const targetZ = center.y + Math.sin(this.flightTimer) * radius;
    const targetY = 22 + Math.sin(this.flightTimer * 2) * 6;

    const currentPos2D = new THREE.Vector2(this.pos.x, this.pos.z);
    const targetPos2D = new THREE.Vector2(targetX, targetZ);
    const flightAngle = Math.atan2(targetPos2D.x - currentPos2D.x, targetPos2D.y - currentPos2D.y);

    this.pos.x += (targetX - this.pos.x) * delta * 1.5;
    this.pos.y += (targetY - this.pos.y) * delta * 1.5;
    this.pos.z += (targetZ - this.pos.z) * delta * 1.5;

    this.mesh.rotation.y = flightAngle + Math.PI;
    this.mesh.rotation.x = Math.sin(this.flightTimer * 2) * 0.15;
    this.mesh.position.copy(this.pos);

    // Dragon Breath / Fireball attacks
    this.attackTimer += delta;
    if (this.attackTimer >= 4.0) {
      this.attackTimer = 0;
      soundEngine.playDragonRoar();

      const dir = new THREE.Vector3().subVectors(playerPos, this.pos).normalize();
      const fbGeo = new THREE.SphereGeometry(0.45, 8, 8);
      const fbMat = new THREE.MeshBasicMaterial({ color: 0xc084fc });
      const fbMesh = new THREE.Mesh(fbGeo, fbMat);
      fbMesh.position.copy(this.pos).add(new THREE.Vector3(0, 0.8, 0));

      spawnProjectile({
        mesh: fbMesh,
        velocity: dir.multiplyScalar(14),
        type: 'dragon_breath',
        lifetime: 5,
        owner: 'dragon'
      });
    }
  }

  takeDamage(amount: number) {
    this.health -= amount;
    soundEngine.playHurt();
    this.mesh.traverse((child) => {
      if (child instanceof THREE.Mesh && child.material) {
        const mat = child.material;
        if ('color' in mat) {
          (mat.color as THREE.Color).setHex(0xff0055);
          setTimeout(() => {
            if ('color' in mat) (mat.color as THREE.Color).setHex(0x111116);
          }, 150);
        }
      }
    });
  }

  die(scene: THREE.Scene, onVictory: () => void) {
    this.dead = true;
    scene.remove(this.mesh);
    soundEngine.playLevelUp();
    onVictory();
  }
}

export class AnimalMob {
  mesh: THREE.Group;
  pos: THREE.Vector3;
  type: 'pig' | 'cow' | 'sheep';
  health = 6;
  rot = Math.random() * Math.PI * 2;
  moveTimer = 0;
  dead = false;

  constructor(type: 'pig' | 'cow' | 'sheep', x: number, y: number, z: number, scene: THREE.Scene) {
    this.type = type;
    this.pos = new THREE.Vector3(x, y, z);
    this.mesh = this.createMesh();
    this.mesh.position.copy(this.pos);
    scene.add(this.mesh);
  }

  private createMesh(): THREE.Group {
    const group = new THREE.Group();
    let color = 0xffb6c1; // pig pink
    if (this.type === 'cow') color = 0x8b4513; // cow brown
    if (this.type === 'sheep') color = 0xf5f5f5; // sheep wool white

    const bodyMat = new THREE.MeshLambertMaterial({ color });
    const body = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.55, 0.9), bodyMat);
    body.position.y = 0.5;
    group.add(body);

    const headMat = new THREE.MeshLambertMaterial({ color });
    const head = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.45, 0.45), headMat);
    head.position.set(0, 0.7, 0.45);
    group.add(head);

    const legMat = new THREE.MeshLambertMaterial({ color });
    const legGeo = new THREE.BoxGeometry(0.18, 0.4, 0.18);
    [
      [-0.22, 0.2, 0.3],
      [0.22, 0.2, 0.3],
      [-0.22, 0.2, -0.3],
      [0.22, 0.2, -0.3]
    ].forEach(([lx, ly, lz]) => {
      const leg = new THREE.Mesh(legGeo, legMat);
      leg.position.set(lx, ly, lz);
      group.add(leg);
    });

    group.userData = { entity: this };
    return group;
  }

  update(delta: number, getTerrainHeight: (x: number, z: number) => number, worldBound: number) {
    if (this.dead) return;
    this.moveTimer -= delta;
    if (this.moveTimer <= 0) {
      this.moveTimer = 2.5 + Math.random() * 3.5;
      this.rot = Math.random() * Math.PI * 2;
    }

    const speed = 0.6;
    const nx = this.pos.x + Math.sin(this.rot) * speed * delta;
    const nz = this.pos.z + Math.cos(this.rot) * speed * delta;

    if (nx > 4 && nx < worldBound - 4 && nz > 4 && nz < worldBound - 4) {
      this.pos.x = nx;
      this.pos.z = nz;
      this.pos.y = getTerrainHeight(nx, nz) + 1.0;
    }

    this.mesh.rotation.y = this.rot;
    this.mesh.position.copy(this.pos);
  }

  takeDamage(amount: number) {
    this.health -= amount;
    soundEngine.playAnimalOink();
    this.mesh.traverse((child) => {
      if (child instanceof THREE.Mesh && child.material && 'color' in child.material) {
        const origColor = (child.material.color as THREE.Color).getHex();
        (child.material.color as THREE.Color).setHex(0xff2222);
        setTimeout(() => {
          (child.material.color as THREE.Color).setHex(origColor);
        }, 150);
      }
    });
  }

  die(scene: THREE.Scene, dropItem: (id: string, count: number) => void) {
    this.dead = true;
    scene.remove(this.mesh);
    const drop = this.type === 'cow' ? 'raw_beef' : 'raw_pork';
    dropItem(drop, 2);
  }
}

export class ZombieMob {
  mesh: THREE.Group;
  pos: THREE.Vector3;
  health = 12;
  attackCooldown = 0;
  rot = 0;
  dead = false;

  constructor(x: number, y: number, z: number, scene: THREE.Scene) {
    this.pos = new THREE.Vector3(x, y, z);
    this.mesh = this.createMesh();
    this.mesh.position.copy(this.pos);
    scene.add(this.mesh);
  }

  private createMesh(): THREE.Group {
    const group = new THREE.Group();
    const skinMat = new THREE.MeshLambertMaterial({ color: 0x2e7d32 });
    const shirtMat = new THREE.MeshLambertMaterial({ color: 0x00838f });
    const pantsMat = new THREE.MeshLambertMaterial({ color: 0x283593 });

    // Head
    const head = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.5, 0.5), skinMat);
    head.position.y = 1.25;
    group.add(head);

    // Body
    const body = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.75, 0.25), shirtMat);
    body.position.y = 0.625;
    group.add(body);

    // Arms stretched forward
    const armGeo = new THREE.BoxGeometry(0.22, 0.75, 0.22);
    const leftArm = new THREE.Mesh(armGeo, skinMat);
    leftArm.position.set(-0.36, 0.75, 0.3);
    leftArm.rotation.x = -Math.PI / 2;
    group.add(leftArm);

    const rightArm = new THREE.Mesh(armGeo, skinMat);
    rightArm.position.set(0.36, 0.75, 0.3);
    rightArm.rotation.x = -Math.PI / 2;
    group.add(rightArm);

    // Legs
    const legGeo = new THREE.BoxGeometry(0.22, 0.75, 0.22);
    const leftLeg = new THREE.Mesh(legGeo, pantsMat);
    leftLeg.position.set(-0.12, -0.12, 0);
    group.add(leftLeg);

    const rightLeg = new THREE.Mesh(legGeo, pantsMat);
    rightLeg.position.set(0.12, -0.12, 0);
    group.add(rightLeg);

    group.scale.set(1.1, 1.1, 1.1);
    group.userData = { entity: this };
    return group;
  }

  update(
    delta: number,
    playerPos: THREE.Vector3,
    onAttackPlayer: (damage: number) => void,
    getTerrainHeight: (x: number, z: number) => number,
    worldBound: number
  ) {
    if (this.dead) return;
    if (this.attackCooldown > 0) this.attackCooldown -= delta;

    const dist = this.pos.distanceTo(playerPos);
    if (dist < 18) {
      const dir = new THREE.Vector3().subVectors(playerPos, this.pos);
      dir.y = 0;
      dir.normalize();

      this.rot = Math.atan2(-dir.x, -dir.z);
      this.mesh.rotation.y = this.rot;

      const speed = 2.4;
      const nx = this.pos.x + dir.x * speed * delta;
      const nz = this.pos.z + dir.z * speed * delta;

      if (nx > 2 && nx < worldBound - 2 && nz > 2 && nz < worldBound - 2) {
        this.pos.x = nx;
        this.pos.z = nz;
        this.pos.y = getTerrainHeight(nx, nz) + 1.0;
      }

      if (dist < 1.6 && this.attackCooldown <= 0) {
        this.attackCooldown = 1.2;
        onAttackPlayer(2);
      }
    }

    this.mesh.position.copy(this.pos);
  }

  takeDamage(amount: number) {
    this.health -= amount;
    soundEngine.playHurt();
    this.mesh.traverse((child) => {
      if (child instanceof THREE.Mesh && child.material && 'color' in child.material) {
        (child.material.color as THREE.Color).setHex(0xff0000);
        setTimeout(() => {
          if (child.material && 'color' in child.material) {
            (child.material.color as THREE.Color).setHex(0x2e7d32);
          }
        }, 150);
      }
    });
  }

  die(scene: THREE.Scene, dropItem: (id: string, count: number) => void) {
    this.dead = true;
    scene.remove(this.mesh);
    dropItem('iron_ingot', 1);
  }
}

