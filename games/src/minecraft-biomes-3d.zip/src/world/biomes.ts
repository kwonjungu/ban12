import { BLOCKS, BlockId, Dimension, BiomeType } from '../types';

export const WORLD_SIZE = 70;
export const WORLD_HEIGHT = 28;

export interface BiomeCoordInfo {
  dimension: Dimension;
  biome: BiomeType;
  name: string;
  spawnPos: [number, number, number];
}

export const BIOME_LOCATIONS: BiomeCoordInfo[] = [
  // Overworld Biomes
  { dimension: Dimension.OVERWORLD, biome: BiomeType.PLAINS, name: '🌱 평원 (Plains)', spawnPos: [15, 10, 15] },
  { dimension: Dimension.OVERWORLD, biome: BiomeType.FOREST, name: '🌲 숲 (Forest)', spawnPos: [35, 10, 15] },
  { dimension: Dimension.OVERWORLD, biome: BiomeType.DESERT, name: '🏜️ 사막 (Desert)', spawnPos: [52, 10, 15] },
  { dimension: Dimension.OVERWORLD, biome: BiomeType.SNOW_MOUNTAIN, name: '🏔️ 눈산 (Snow Mountain)', spawnPos: [15, 16, 52] },
  { dimension: Dimension.OVERWORLD, biome: BiomeType.OCEAN, name: '🌊 바다 (Ocean)', spawnPos: [35, 7, 35] },
  { dimension: Dimension.OVERWORLD, biome: BiomeType.JUNGLE, name: '🌴 정글 (Jungle)', spawnPos: [52, 11, 52] },
  { dimension: Dimension.OVERWORLD, biome: BiomeType.STRONGHOLD, name: '🏛️ 엔더 포탈룸 (Stronghold)', spawnPos: [35, 6, 52] },

  // Nether Biomes
  { dimension: Dimension.NETHER, biome: BiomeType.NETHER_WASTES, name: '🌋 지옥 네더 평원 (Nether)', spawnPos: [20, 9, 20] },
  { dimension: Dimension.NETHER, biome: BiomeType.WARPED_FOREST, name: '🍄 푸른숲 (Warped Forest)', spawnPos: [50, 9, 20] },
  { dimension: Dimension.NETHER, biome: BiomeType.NETHER_FORTRESS, name: '🏰 네더 요새 (Nether Fortress)', spawnPos: [35, 12, 50] },

  // The End
  { dimension: Dimension.THE_END, biome: BiomeType.THE_END, name: '🌌 디 엔드 (The End)', spawnPos: [35, 10, 35] }
];

export function getBiomeAt(x: number, z: number, dimension: Dimension): BiomeType {
  if (dimension === Dimension.NETHER) {
    if (z > 40) return BiomeType.NETHER_FORTRESS;
    if (x > 35) return BiomeType.WARPED_FOREST;
    return BiomeType.NETHER_WASTES;
  }

  if (dimension === Dimension.THE_END) {
    return BiomeType.THE_END;
  }

  // Overworld Biome Partitioning
  if (z >= 46 && z <= 58 && x >= 28 && x <= 42) {
    return BiomeType.STRONGHOLD;
  }
  if (x >= 24 && x <= 46 && z >= 24 && z <= 44) {
    return BiomeType.OCEAN;
  }
  if (x < 26 && z < 38) return BiomeType.PLAINS;
  if (x >= 26 && x < 46 && z < 24) return BiomeType.FOREST;
  if (x >= 46 && z < 38) return BiomeType.DESERT;
  if (x < 30 && z >= 38) return BiomeType.SNOW_MOUNTAIN;
  if (x >= 46 && z >= 38) return BiomeType.JUNGLE;

  return BiomeType.PLAINS;
}

export function generateDimensionWorld(
  dimension: Dimension,
  setBlock: (x: number, y: number, z: number, type: BlockId) => void
) {
  if (dimension === Dimension.OVERWORLD) {
    generateOverworld(setBlock);
  } else if (dimension === Dimension.NETHER) {
    generateNether(setBlock);
  } else if (dimension === Dimension.THE_END) {
    generateTheEnd(setBlock);
  }
}

function generateOverworld(setBlock: (x: number, y: number, z: number, type: BlockId) => void) {
  for (let x = 0; x < WORLD_SIZE; x++) {
    for (let z = 0; z < WORLD_SIZE; z++) {
      const biome = getBiomeAt(x, z, Dimension.OVERWORLD);
      let height = 8;
      let topBlock: BlockId = BLOCKS.GRASS;
      let subBlock: BlockId = BLOCKS.DIRT;

      switch (biome) {
        case BiomeType.DESERT:
          height = Math.floor(6 + Math.sin(x * 0.12) * 1.5 + Math.cos(z * 0.12) * 1.5);
          topBlock = BLOCKS.SAND;
          subBlock = BLOCKS.SAND;
          break;

        case BiomeType.SNOW_MOUNTAIN:
          // Tall peaks
          const peakNoise = Math.sin(x * 0.18) * 4 + Math.cos(z * 0.18) * 4;
          height = Math.floor(13 + Math.max(0, peakNoise));
          topBlock = BLOCKS.SNOW;
          subBlock = BLOCKS.STONE;
          break;

        case BiomeType.OCEAN:
          height = 3;
          topBlock = BLOCKS.SAND;
          subBlock = BLOCKS.STONE;
          break;

        case BiomeType.JUNGLE:
          height = Math.floor(8 + Math.sin(x * 0.1) * 2 + Math.cos(z * 0.1) * 2);
          topBlock = BLOCKS.GRASS;
          subBlock = BLOCKS.DIRT;
          break;

        case BiomeType.FOREST:
          height = Math.floor(8 + Math.sin(x * 0.15) * 1.8);
          topBlock = BLOCKS.GRASS;
          subBlock = BLOCKS.DIRT;
          break;

        case BiomeType.STRONGHOLD:
          height = 8;
          topBlock = BLOCKS.STONE_BRICKS;
          subBlock = BLOCKS.STONE_BRICKS;
          break;

        case BiomeType.PLAINS:
        default:
          height = Math.floor(7 + Math.sin(x * 0.1) * 1.5 + Math.cos(z * 0.1) * 1.5);
          topBlock = BLOCKS.GRASS;
          subBlock = BLOCKS.DIRT;
          break;
      }

      // Base stone and ore layers
      for (let y = 0; y <= height; y++) {
        if (y === height) {
          setBlock(x, y, z, topBlock);
        } else if (y >= height - 2) {
          setBlock(x, y, z, subBlock);
        } else {
          const rand = Math.random();
          if (y <= 3 && rand < 0.05) {
            setBlock(x, y, z, BLOCKS.DIAMOND_ORE);
          } else if (rand < 0.06) {
            setBlock(x, y, z, BLOCKS.COAL);
          } else if (rand < 0.08) {
            setBlock(x, y, z, BLOCKS.IRON);
          } else {
            setBlock(x, y, z, BLOCKS.STONE);
          }
        }
      }

      // Fill Ocean water up to sea level y=6
      if (biome === BiomeType.OCEAN) {
        for (let y = height + 1; y <= 6; y++) {
          setBlock(x, y, z, BLOCKS.WATER);
        }
      }

      // Snow Mountain Ice lakes
      if (biome === BiomeType.SNOW_MOUNTAIN && height <= 12 && (x + z) % 7 === 0) {
        setBlock(x, height, z, BLOCKS.ICE);
      }

      // Foliage and structures
      if (x > 4 && x < WORLD_SIZE - 4 && z > 4 && z < WORLD_SIZE - 4) {
        // Cacti in Desert
        if (biome === BiomeType.DESERT && Math.random() < 0.015) {
          const cHeight = 2 + Math.floor(Math.random() * 2);
          for (let ch = 1; ch <= cHeight; ch++) {
            setBlock(x, height + ch, z, BLOCKS.CACTUS);
          }
        }

        // Oak Trees in Forest & Plains
        const isTreeSpot = (biome === BiomeType.FOREST && Math.random() < 0.04) ||
                           (biome === BiomeType.PLAINS && Math.random() < 0.01);
        if (isTreeSpot) {
          const trunkH = 4;
          for (let th = 1; th <= trunkH; th++) {
            setBlock(x, height + th, z, BLOCKS.OAK_WOOD);
          }
          for (let lx = -1; lx <= 1; lx++) {
            for (let lz = -1; lz <= 1; lz++) {
              for (let ly = trunkH; ly <= trunkH + 2; ly++) {
                if (lx === 0 && lz === 0 && ly <= trunkH + 1) continue;
                setBlock(x + lx, height + ly, z + lz, BLOCKS.OAK_LEAVES);
              }
            }
          }
        }

        // Giant Jungle Trees in Jungle
        if (biome === BiomeType.JUNGLE && Math.random() < 0.035) {
          const jungleH = 7 + Math.floor(Math.random() * 3);
          for (let th = 1; th <= jungleH; th++) {
            setBlock(x, height + th, z, BLOCKS.JUNGLE_WOOD);
          }
          for (let lx = -2; lx <= 2; lx++) {
            for (let lz = -2; lz <= 2; lz++) {
              for (let ly = jungleH - 1; ly <= jungleH + 2; ly++) {
                if (Math.abs(lx) === 2 && Math.abs(lz) === 2 && ly === jungleH + 2) continue;
                if (lx === 0 && lz === 0 && ly <= jungleH) continue;
                setBlock(x + lx, height + ly, z + lz, BLOCKS.JUNGLE_LEAVES);
              }
            }
          }
        }
      }
    }
  }

  // Generate Stronghold (End Portal Room) at (35, 4, 52)
  buildStrongholdEndPortalRoom(setBlock, 35, 4, 52);

  // Generate a surface Nether Portal in the Overworld at (20, 8, 20)
  buildNetherPortalStructure(setBlock, 20, 8, 20);
}

function buildStrongholdEndPortalRoom(
  setBlock: (x: number, y: number, z: number, type: BlockId) => void,
  cx: number,
  cy: number,
  cz: number
) {
  // 9x9 Stone Brick chamber
  for (let x = cx - 5; x <= cx + 5; x++) {
    for (let z = cz - 5; z <= cz + 5; z++) {
      for (let y = cy; y <= cy + 6; y++) {
        const isWall = x === cx - 5 || x === cx + 5 || z === cz - 5 || z === cz + 5;
        const isFloor = y === cy;
        const isCeil = y === cy + 6;
        if (isFloor || isCeil || isWall) {
          setBlock(x, y, z, Math.random() < 0.25 ? BLOCKS.MOSSY_STONE_BRICKS : BLOCKS.STONE_BRICKS);
        } else {
          setBlock(x, y, z, BLOCKS.AIR);
        }
      }
    }
  }

  // Lava pool beneath the portal
  for (let x = cx - 1; x <= cx + 1; x++) {
    for (let z = cz - 1; z <= cz + 1; z++) {
      setBlock(x, cy + 1, z, BLOCKS.LAVA);
    }
  }

  // 3x3 End Portal Frame Ring at y = cy + 2
  // Top & Bottom rows
  for (let dx = -1; dx <= 1; dx++) {
    // Top side: z = cz - 2
    setBlock(cx + dx, cy + 2, cz - 2, BLOCKS.END_PORTAL_FRAME_EYE);
    // Bottom side: z = cz + 2
    setBlock(cx + dx, cy + 2, cz + 2, BLOCKS.END_PORTAL_FRAME_EYE);
  }
  // Left & Right columns
  for (let dz = -1; dz <= 1; dz++) {
    // Left side: x = cx - 2
    setBlock(cx - 2, cy + 2, cz + dz, BLOCKS.END_PORTAL_FRAME_EYE);
    // Right side: x = cx + 2
    setBlock(cx + 2, cy + 2, cz + dz, BLOCKS.END_PORTAL_FRAME_EYE);
  }

  // Center 3x3 active End Portal block!
  for (let x = cx - 1; x <= cx + 1; x++) {
    for (let z = cz - 1; z <= cz + 1; z++) {
      setBlock(x, cy + 2, z, BLOCKS.END_PORTAL);
    }
  }
}

function buildNetherPortalStructure(
  setBlock: (x: number, y: number, z: number, type: BlockId) => void,
  ox: number,
  oy: number,
  oz: number
) {
  // 4 wide x 5 high obsidian frame
  for (let x = ox; x <= ox + 3; x++) {
    for (let y = oy; y <= oy + 4; y++) {
      const isBorder = x === ox || x === ox + 3 || y === oy || y === oy + 4;
      if (isBorder) {
        setBlock(x, y, oz, BLOCKS.OBSIDIAN);
      } else {
        setBlock(x, y, oz, BLOCKS.NETHER_PORTAL);
      }
    }
  }
}

function generateNether(setBlock: (x: number, y: number, z: number, type: BlockId) => void) {
  for (let x = 0; x < WORLD_SIZE; x++) {
    for (let z = 0; z < WORLD_SIZE; z++) {
      const biome = getBiomeAt(x, z, Dimension.NETHER);
      const isFortress = biome === BiomeType.NETHER_FORTRESS;
      const isWarped = biome === BiomeType.WARPED_FOREST;

      let floorH = Math.floor(6 + Math.sin(x * 0.1) * 2 + Math.cos(z * 0.1) * 2);
      let ceilH = 22;

      // Floor & Ceiling
      for (let y = 0; y <= floorH; y++) {
        if (y === floorH) {
          setBlock(x, y, z, isWarped ? BLOCKS.WARPED_NYLIUM : BLOCKS.NETHERRACK);
        } else {
          setBlock(x, y, z, BLOCKS.NETHERRACK);
        }
      }

      for (let y = ceilH; y <= ceilH + 2; y++) {
        setBlock(x, y, z, BLOCKS.NETHERRACK);
      }

      // Glowstone stalactites from ceiling
      if (Math.random() < 0.015) {
        const dropLen = 2 + Math.floor(Math.random() * 3);
        for (let dy = 0; dy < dropLen; dy++) {
          setBlock(x, ceilH - 1 - dy, z, BLOCKS.GLOWSTONE);
        }
      }

      // Warped Trees in Warped Forest
      if (isWarped && Math.random() < 0.03 && x > 4 && x < WORLD_SIZE - 4 && z > 4 && z < WORLD_SIZE - 4) {
        const treeH = 5 + Math.floor(Math.random() * 3);
        for (let th = 1; th <= treeH; th++) {
          setBlock(x, floorH + th, z, BLOCKS.WARPED_STEM);
        }
        for (let lx = -1; lx <= 1; lx++) {
          for (let lz = -1; lz <= 1; lz++) {
            for (let ly = treeH - 1; ly <= treeH + 1; ly++) {
              if (lx === 0 && lz === 0 && ly <= treeH) continue;
              setBlock(x + lx, floorH + ly, z + lz, BLOCKS.WARPED_WART);
            }
          }
        }
      }
    }
  }

  // Nether Fortress Structure at (35, 10, 50)
  buildNetherFortress(setBlock, 35, 10, 50);

  // Return Nether Portal in Nether at (20, 7, 20)
  buildNetherPortalStructure(setBlock, 20, 7, 20);
}

function buildNetherFortress(
  setBlock: (x: number, y: number, z: number, type: BlockId) => void,
  fx: number,
  fy: number,
  fz: number
) {
  // Long fortress bridge with pillars and corridors
  for (let z = fz - 15; z <= fz + 15; z++) {
    for (let x = fx - 3; x <= fx + 3; x++) {
      // Bridge walkway
      setBlock(x, fy, z, BLOCKS.NETHER_BRICKS);
      // Fences / battlements on edges
      if (x === fx - 3 || x === fx + 3) {
        setBlock(x, fy + 1, z, BLOCKS.NETHER_BRICKS);
      }
    }
    // Support pillars every 8 blocks down to ground
    if (z % 8 === 0) {
      for (let y = fy - 1; y >= 2; y--) {
        setBlock(fx - 2, y, z, BLOCKS.NETHER_BRICKS);
        setBlock(fx + 2, y, z, BLOCKS.NETHER_BRICKS);
      }
    }
  }

  // Fortress central spire and Blaze spawner arena at (fx, fz)
  for (let x = fx - 5; x <= fx + 5; x++) {
    for (let z = fz - 5; z <= fz + 5; z++) {
      setBlock(x, fy, z, BLOCKS.NETHER_BRICKS);
      if (x === fx - 5 || x === fx + 5 || z === fz - 5 || z === fz + 5) {
        setBlock(x, fy + 1, z, BLOCKS.NETHER_BRICKS);
        setBlock(x, fy + 2, z, BLOCKS.NETHER_BRICKS);
      }
    }
  }

  // Corner towers with fire / glowstone
  [
    [-4, -4],
    [4, -4],
    [-4, 4],
    [4, 4]
  ].forEach(([dx, dz]) => {
    for (let y = fy; y <= fy + 5; y++) {
      setBlock(fx + dx, y, fz + dz, BLOCKS.NETHER_BRICKS);
    }
    setBlock(fx + dx, fy + 6, fz + dz, BLOCKS.GLOWSTONE);
  });
}

function generateTheEnd(setBlock: (x: number, y: number, z: number, type: BlockId) => void) {
  const centerX = 35;
  const centerZ = 35;
  const islandRadius = 24;

  // Floating End Stone island in the void
  for (let x = 0; x < WORLD_SIZE; x++) {
    for (let z = 0; z < WORLD_SIZE; z++) {
      const dist = Math.hypot(x - centerX, z - centerZ);
      if (dist < islandRadius) {
        // Curve downwards at edges
        const depth = Math.floor((1 - (dist / islandRadius) ** 2) * 8);
        const topY = 9 + Math.floor(Math.sin(x * 0.15) * 1.2 + Math.cos(z * 0.15) * 1.2);

        for (let y = topY - depth; y <= topY; y++) {
          if (y >= 1) {
            setBlock(x, y, z, BLOCKS.END_STONE);
          }
        }
      }
    }
  }

  // 8 Obsidian Pillars with End Crystals arranged in a circle
  const pillarRadius = 15;
  const pillarAngles = [0, 45, 90, 135, 180, 225, 270, 315];

  pillarAngles.forEach((deg, idx) => {
    const rad = (deg * Math.PI) / 180;
    const px = Math.round(centerX + Math.cos(rad) * pillarRadius);
    const pz = Math.round(centerZ + Math.sin(rad) * pillarRadius);
    const pillarHeight = 15 + (idx % 3) * 3;

    for (let y = 8; y <= pillarHeight; y++) {
      for (let dx = -1; dx <= 1; dx++) {
        for (let dz = -1; dz <= 1; dz++) {
          setBlock(px + dx, y, pz + dz, BLOCKS.OBSIDIAN);
        }
      }
    }

    // End Crystal at top
    setBlock(px, pillarHeight + 1, pz, BLOCKS.GLOWSTONE);
  });

  // Exit Portal Fountain in center
  for (let dx = -2; dx <= 2; dx++) {
    for (let dz = -2; dz <= 2; dz++) {
      const isRim = Math.abs(dx) === 2 || Math.abs(dz) === 2;
      if (isRim) {
        setBlock(centerX + dx, 10, centerZ + dz, BLOCKS.STONE_BRICKS);
      } else {
        setBlock(centerX + dx, 10, centerZ + dz, BLOCKS.END_PORTAL);
      }
    }
  }
  // Center obsidian pillar beacon
  for (let y = 10; y <= 14; y++) {
    setBlock(centerX, y, centerZ, BLOCKS.OBSIDIAN);
  }
  setBlock(centerX, 15, centerZ, BLOCKS.GLOWSTONE);
}
