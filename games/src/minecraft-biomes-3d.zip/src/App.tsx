import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import {
  BLOCKS,
  BlockId,
  Dimension,
  BiomeType,
  InventoryItem,
  BLOCK_NAMES,
  WEAPON_DAMAGE
} from './types';
import { soundEngine } from './audio/soundEngine';
import { createBlockMaterials } from './graphics/textures';
import {
  WORLD_SIZE,
  WORLD_HEIGHT,
  getBiomeAt,
  generateDimensionWorld,
  BiomeCoordInfo
} from './world/biomes';
import {
  BlazeMob,
  EndermanMob,
  EnderDragonBoss,
  Projectile,
  AnimalMob,
  ZombieMob
} from './entities/entityManager';
import { HUD } from './components/HUD';
import { Hotbar } from './components/Hotbar';
import { ItemPickerModal } from './components/ItemPickerModal';
import { BiomeTeleportMenu } from './components/BiomeTeleportMenu';
import { InventoryCraftingModal } from './components/InventoryCraftingModal';

export default function App() {
  const mountRef = useRef<HTMLDivElement>(null);
  const isThirdPersonRef = useRef<boolean>(false);

  // UI States
  const [gameStarted, setGameStarted] = useState(false);
  const [health, setHealth] = useState(10);
  const [hunger, setHunger] = useState(10);
  const [dimension, setDimension] = useState<Dimension>(Dimension.OVERWORLD);
  const [biome, setBiome] = useState<BiomeType>(BiomeType.PLAINS);
  const [playerPosition, setPlayerPosition] = useState({ x: 20, y: 12, z: 20 });
  const [timeStr, setTimeStr] = useState('낮 (12:00) ☀️');
  const [isNight, setIsNight] = useState(false);
  const [selectedSlot, setSelectedSlot] = useState(0);
  const [dragonHealth, setDragonHealth] = useState<number | undefined>(undefined);
  const [notification, setNotification] = useState<string | null>(null);

  // Modals
  const [isItemPickerOpen, setIsItemPickerOpen] = useState(false);
  const [isInventoryOpen, setIsInventoryOpen] = useState(false);
  const [isBiomeMenuOpen, setIsBiomeMenuOpen] = useState(false);
  const [isThirdPerson, setIsThirdPerson] = useState(false);

  // Keep ref synced
  useEffect(() => {
    isThirdPersonRef.current = isThirdPerson;
  }, [isThirdPerson]);

  // Inventory State (20 slots total, first 9 are hotbar)
  const [inventory, setInventory] = useState<(InventoryItem | null)[]>(() => {
    const arr: (InventoryItem | null)[] = Array(20).fill(null);
    arr[0] = { id: BLOCKS.GRASS, count: 64 };
    arr[1] = { id: 'diamond_sword', count: 1 };
    arr[2] = { id: BLOCKS.OAK_WOOD, count: 64 };
    arr[3] = { id: BLOCKS.STONE, count: 64 };
    arr[4] = { id: 'cooked_pork', count: 16 };
    arr[5] = { id: 'bow', count: 1 };
    arr[6] = { id: BLOCKS.CRAFTING_TABLE, count: 4 };
    arr[7] = { id: BLOCKS.FURNACE, count: 4 };
    arr[8] = { id: BLOCKS.OBSIDIAN, count: 16 };
    // Reserve items in pack
    arr[9] = { id: 'ender_eye', count: 12 };
    arr[10] = { id: 'ender_pearl', count: 16 };
    arr[11] = { id: BLOCKS.COAL, count: 32 };
    arr[12] = { id: BLOCKS.IRON, count: 32 };
    arr[13] = { id: BLOCKS.DIAMOND_ORE, count: 16 };
    return arr;
  });

  // Game Engine Ref
  const engineRef = useRef<{
    scene: THREE.Scene;
    camera: THREE.PerspectiveCamera;
    renderer: THREE.WebGLRenderer;
    sunLight: THREE.DirectionalLight;
    ambientLight: THREE.AmbientLight;
    blockMaterials: Record<number, THREE.Material | THREE.Material[]>;
    worldData: Map<string, BlockId>;
    worldMeshes: Map<string, THREE.Mesh>;
    animals: AnimalMob[];
    zombies: ZombieMob[];
    blazes: BlazeMob[];
    endermen: EndermanMob[];
    dragon: EnderDragonBoss | null;
    projectiles: Projectile[];
    keys: Record<string, boolean>;
    player: {
      pos: THREE.Vector3;
      vel: THREE.Vector3;
      rotation: THREE.Vector2;
      onGround: boolean;
      isFalling: boolean;
      fallStartY: number;
    };
    targetedBlock: { breakPos: THREE.Vector3; placePos: THREE.Vector3 } | null;
    currentDimension: Dimension;
    isPointerLocked: boolean;
    portalCooldown: number;
    armMesh: THREE.Mesh | null;
    steveGroup: THREE.Group | null;
    isSwingingArm: boolean;
    swingProgress: number;
    renderBlockMesh: (x: number, y: number, z: number, type: BlockId) => THREE.Mesh;
    buildVisibleMeshes: () => void;
    getTerrainHeight: (x: number, z: number) => number;
  } | null>(null);

  const showNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => {
      setNotification((prev) => (prev === msg ? null : prev));
    }, 3500);
  };

  const selectedItem = inventory[selectedSlot];
  const selectedItemName = selectedItem
    ? (BLOCK_NAMES[selectedItem.id] || String(selectedItem.id))
    : '';

  // Safe pointer lock helper that handles sandboxed iframe restrictions
  const requestSafePointerLock = () => {
    try {
      const el = engineRef.current?.renderer.domElement;
      if (el && typeof el.requestPointerLock === 'function') {
        const p = el.requestPointerLock();
        if (p && typeof (p as Promise<void>).catch === 'function') {
          (p as Promise<void>).catch(() => {
            // Silently ignore sandbox restriction
          });
        }
      }
    } catch {
      // Ignore
    }
  };

  // Initialize Three.js Game World (Only once on mount)
  useEffect(() => {
    if (!mountRef.current) return;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x87ceeb);
    scene.fog = new THREE.FogExp2(0x87ceeb, 0.008);

    const camera = new THREE.PerspectiveCamera(
      75,
      window.innerWidth / window.innerHeight,
      0.1,
      600
    );

    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      powerPreference: 'high-performance'
    });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.05;

    mountRef.current.appendChild(renderer.domElement);

    const ambientLight = new THREE.AmbientLight(0xffffff, 0.75);
    scene.add(ambientLight);

    const sunLight = new THREE.DirectionalLight(0xfffaed, 0.9);
    sunLight.position.set(35, 90, 35);
    scene.add(sunLight);

    const materials = createBlockMaterials();
    const worldData = new Map<string, BlockId>();
    const worldMeshes = new Map<string, THREE.Mesh>();

    const blockBoxGeo = new THREE.BoxGeometry(1, 1, 1);

    // Fast render mesh
    const renderBlockMesh = (x: number, y: number, z: number, type: BlockId) => {
      const key = `${x},${y},${z}`;
      if (worldMeshes.has(key)) {
        scene.remove(worldMeshes.get(key)!);
      }
      const mat = materials[type] || materials[BLOCKS.STONE];
      const mesh = new THREE.Mesh(blockBoxGeo, mat);
      mesh.position.set(x + 0.5, y + 0.5, z + 0.5);
      scene.add(mesh);
      worldMeshes.set(key, mesh);
      return mesh;
    };

    // Voxel face culling check: only render blocks that touch AIR or void
    const isExposed = (x: number, y: number, z: number) => {
      if (y === 0) return true;
      if (!worldData.has(`${x + 1},${y},${z}`)) return true;
      if (!worldData.has(`${x - 1},${y},${z}`)) return true;
      if (!worldData.has(`${x},${y + 1},${z}`)) return true;
      if (!worldData.has(`${x},${y - 1},${z}`)) return true;
      if (!worldData.has(`${x},${y},${z + 1}`)) return true;
      if (!worldData.has(`${x},${y},${z - 1}`)) return true;
      return false;
    };

    // Build meshes only for exposed surface blocks (saves 90% of draw calls!)
    const buildVisibleMeshes = () => {
      worldData.forEach((type, key) => {
        const [x, y, z] = key.split(',').map(Number);
        if (isExposed(x, y, z)) {
          renderBlockMesh(x, y, z, type);
        }
      });
    };

    const getTerrainHeight = (x: number, z: number): number => {
      const ix = Math.floor(x);
      const iz = Math.floor(z);
      for (let y = WORLD_HEIGHT; y >= 0; y--) {
        if (worldData.has(`${ix},${y},${iz}`)) return y;
      }
      return 6;
    };

    // Build Steve Player representation (for 3rd person)
    const steveGroup = new THREE.Group();
    const steveMat = new THREE.MeshLambertMaterial({ color: 0x0099aa });
    const steveSkinMat = new THREE.MeshLambertMaterial({ color: 0xdba27b });
    const stevePantsMat = new THREE.MeshLambertMaterial({ color: 0x223388 });

    const headMesh = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.5, 0.5), steveSkinMat);
    headMesh.position.y = 1.25;
    steveGroup.add(headMesh);

    const bodyMesh = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.75, 0.25), steveMat);
    bodyMesh.position.y = 0.625;
    steveGroup.add(bodyMesh);

    const armGeo = new THREE.BoxGeometry(0.22, 0.75, 0.22);
    const leftArm = new THREE.Mesh(armGeo, steveMat);
    leftArm.position.set(-0.36, 0.625, 0);
    steveGroup.add(leftArm);

    const rightArm = new THREE.Mesh(armGeo, steveMat);
    rightArm.position.set(0.36, 0.625, 0);
    steveGroup.add(rightArm);

    const legGeo = new THREE.BoxGeometry(0.22, 0.75, 0.22);
    const leftLeg = new THREE.Mesh(legGeo, stevePantsMat);
    leftLeg.position.set(-0.12, -0.12, 0);
    steveGroup.add(leftLeg);

    const rightLeg = new THREE.Mesh(legGeo, stevePantsMat);
    rightLeg.position.set(0.12, -0.12, 0);
    steveGroup.add(rightLeg);

    steveGroup.scale.set(1.2, 1.2, 1.2);
    scene.add(steveGroup);

    // Initial World Generation (Overworld)
    generateDimensionWorld(Dimension.OVERWORLD, (x, y, z, type) => {
      if (type === BLOCKS.AIR) {
        worldData.delete(`${x},${y},${z}`);
      } else {
        worldData.set(`${x},${y},${z}`, type);
      }
    });
    buildVisibleMeshes();

    // Find safe spawn on top of the terrain at (20, 20)
    const initialSpawnX = 20;
    const initialSpawnZ = 20;
    const initialSpawnY = getTerrainHeight(initialSpawnX, initialSpawnZ) + 2.0;

    const engine = {
      scene,
      camera,
      renderer,
      sunLight,
      ambientLight,
      blockMaterials: materials,
      worldData,
      worldMeshes,
      animals: [] as AnimalMob[],
      zombies: [] as ZombieMob[],
      blazes: [] as BlazeMob[],
      endermen: [] as EndermanMob[],
      dragon: null as EnderDragonBoss | null,
      projectiles: [] as Projectile[],
      keys: {} as Record<string, boolean>,
      player: {
        pos: new THREE.Vector3(initialSpawnX, initialSpawnY, initialSpawnZ),
        vel: new THREE.Vector3(0, 0, 0),
        rotation: new THREE.Vector2(0, 0),
        onGround: false,
        isFalling: false,
        fallStartY: initialSpawnY
      },
      targetedBlock: null as { breakPos: THREE.Vector3; placePos: THREE.Vector3 } | null,
      currentDimension: Dimension.OVERWORLD,
      isPointerLocked: false,
      portalCooldown: 0,
      armMesh: rightArm,
      steveGroup,
      isSwingingArm: false,
      swingProgress: 0,
      renderBlockMesh,
      buildVisibleMeshes,
      getTerrainHeight
    };

    engineRef.current = engine;

    // Spawn initial peaceful animals in Overworld
    const animalTypes: ('pig' | 'cow' | 'sheep')[] = ['pig', 'cow', 'sheep'];
    for (let i = 0; i < 12; i++) {
      const ax = 10 + Math.random() * (WORLD_SIZE - 20);
      const az = 10 + Math.random() * (WORLD_SIZE - 20);
      const ay = getTerrainHeight(ax, az) + 1.0;
      const type = animalTypes[i % 3];
      engine.animals.push(new AnimalMob(type, ax, ay, az, scene));
    }

    // Window Resize Handler
    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };
    window.addEventListener('resize', handleResize);

    // Keyboard Handler
    const handleKeyDown = (e: KeyboardEvent) => {
      engine.keys[e.code] = true;

      if (e.code === 'KeyE') {
        setIsInventoryOpen((prev) => !prev);
      } else if (e.code === 'KeyB') {
        setIsItemPickerOpen((prev) => !prev);
      } else if (e.code === 'KeyT') {
        setIsBiomeMenuOpen((prev) => !prev);
      } else if (e.code === 'F5') {
        e.preventDefault();
        setIsThirdPerson((prev) => !prev);
      } else if (e.code >= 'Digit1' && e.code <= 'Digit9') {
        setSelectedSlot(parseInt(e.code.replace('Digit', '')) - 1);
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      engine.keys[e.code] = false;
    };

    // Mouse Look & Drag Handler (Works both with pointer lock and without pointer lock!)
    let isMouseDown = false;
    let dragStartX = 0;
    let dragStartY = 0;
    let hasDragged = false;

    const handleCanvasMouseDown = (e: MouseEvent) => {
      isMouseDown = true;
      dragStartX = e.clientX;
      dragStartY = e.clientY;
      hasDragged = false;
    };

    const handleCanvasMouseUp = (e: MouseEvent) => {
      isMouseDown = false;
      if (!hasDragged) {
        if (e.button === 0) {
          handleLeftClick();
        } else if (e.button === 2) {
          handleRightClick();
        }
      }
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (engine.isPointerLocked) {
        engine.player.rotation.x -= e.movementX * 0.0028;
        engine.player.rotation.y -= e.movementY * 0.0028;
        engine.player.rotation.y = Math.max(
          -Math.PI / 2 + 0.1,
          Math.min(Math.PI / 2 - 0.1, engine.player.rotation.y)
        );
      } else if (isMouseDown) {
        const dx = e.clientX - dragStartX;
        const dy = e.clientY - dragStartY;
        if (Math.abs(dx) > 3 || Math.abs(dy) > 3) {
          hasDragged = true;
        }
        dragStartX = e.clientX;
        dragStartY = e.clientY;
        engine.player.rotation.x -= dx * 0.0036;
        engine.player.rotation.y -= dy * 0.0036;
        engine.player.rotation.y = Math.max(
          -Math.PI / 2 + 0.1,
          Math.min(Math.PI / 2 - 0.1, engine.player.rotation.y)
        );
      }
    };

    // Touch Look & Drag for mobile
    let touchStartX = 0;
    let touchStartY = 0;
    let isTouching = false;

    const handleTouchStart = (e: TouchEvent) => {
      if (e.touches.length > 0) {
        touchStartX = e.touches[0].clientX;
        touchStartY = e.touches[0].clientY;
        isTouching = true;
      }
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (isTouching && e.touches.length > 0) {
        const dx = e.touches[0].clientX - touchStartX;
        const dy = e.touches[0].clientY - touchStartY;
        touchStartX = e.touches[0].clientX;
        touchStartY = e.touches[0].clientY;
        engine.player.rotation.x -= dx * 0.0045;
        engine.player.rotation.y -= dy * 0.0045;
        engine.player.rotation.y = Math.max(
          -Math.PI / 2 + 0.1,
          Math.min(Math.PI / 2 - 0.1, engine.player.rotation.y)
        );
      }
    };

    const handleTouchEnd = () => {
      isTouching = false;
    };

    const handleWheel = (e: WheelEvent) => {
      if (e.deltaY > 0) {
        setSelectedSlot((prev) => (prev + 1) % 9);
      } else {
        setSelectedSlot((prev) => (prev - 1 + 9) % 9);
      }
    };

    const handlePointerLockChange = () => {
      engine.isPointerLocked = document.pointerLockElement === renderer.domElement;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('wheel', handleWheel);
    document.addEventListener('pointerlockchange', handlePointerLockChange);

    const domEl = renderer.domElement;
    domEl.addEventListener('mousedown', handleCanvasMouseDown);
    window.addEventListener('mouseup', handleCanvasMouseUp);
    domEl.addEventListener('touchstart', handleTouchStart, { passive: true });
    domEl.addEventListener('touchmove', handleTouchMove, { passive: true });
    domEl.addEventListener('touchend', handleTouchEnd);

    // Animation Loop
    let animationId: number;
    let lastTime = performance.now();
    let dayCycle = 0.25; // Start at bright noon! ☀️
    let hudTimer = 0;
    let zombieSpawnTimer = 0;

    const animate = () => {
      animationId = requestAnimationFrame(animate);

      const now = performance.now();
      const delta = Math.min((now - lastTime) / 1000, 0.1);
      lastTime = now;

      // Update portal cooldown
      if (engine.portalCooldown > 0) {
        engine.portalCooldown -= delta;
      }

      // Swing arm animation
      if (engine.isSwingingArm && engine.armMesh) {
        engine.swingProgress += delta * 16;
        engine.armMesh.rotation.x = -Math.sin(engine.swingProgress) * 1.3;
        if (engine.swingProgress >= Math.PI) {
          engine.isSwingingArm = false;
          engine.armMesh.rotation.x = 0;
        }
      }

      // Day / Night cycle (for Overworld)
      if (engine.currentDimension === Dimension.OVERWORLD) {
        dayCycle += delta * 0.003;
        if (dayCycle > 1) dayCycle = 0;

        const sunAngle = dayCycle * Math.PI * 2;
        sunLight.position.x = engine.player.pos.x + Math.cos(sunAngle) * 60;
        sunLight.position.y = Math.sin(sunAngle) * 60;
        sunLight.position.z = engine.player.pos.z + 30;

        const night = sunLight.position.y < 0;
        if (night) {
          scene.background = new THREE.Color(0x0c1427); // Midnight blue, never black
          scene.fog = new THREE.FogExp2(0x0c1427, 0.008);
          ambientLight.intensity = 0.42; // Clear moonlight visibility
          sunLight.intensity = 0.1;
        } else {
          scene.background = new THREE.Color(0x87ceeb); // Bright daytime sky
          scene.fog = new THREE.FogExp2(0x87ceeb, 0.008);
          ambientLight.intensity = 0.75;
          sunLight.intensity = 0.9;
        }

        // Night time zombie spawner
        if (night) {
          zombieSpawnTimer += delta;
          if (zombieSpawnTimer > 6.0 && engine.zombies.length < 5) {
            zombieSpawnTimer = 0;
            const zx = engine.player.pos.x + (Math.random() - 0.5) * 30;
            const zz = engine.player.pos.z + (Math.random() - 0.5) * 30;
            if (zx > 4 && zx < WORLD_SIZE - 4 && zz > 4 && zz < WORLD_SIZE - 4) {
              const zy = getTerrainHeight(zx, zz) + 1.0;
              engine.zombies.push(new ZombieMob(zx, zy, zz, scene));
            }
          }
        }
      }

      // Update Physics & Player Movement
      const moveSpeed = 6.8;
      const gravity = 22.0;

      engine.player.vel.x *= 0.78;
      engine.player.vel.z *= 0.78;
      engine.player.vel.y -= gravity * delta;

      const moveDir = new THREE.Vector3();
      if (engine.keys['KeyW']) moveDir.z -= 1;
      if (engine.keys['KeyS']) moveDir.z += 1;
      if (engine.keys['KeyA']) moveDir.x -= 1;
      if (engine.keys['KeyD']) moveDir.x += 1;
      moveDir.normalize();

      if (moveDir.length() > 0) {
        const yaw = engine.player.rotation.x;
        const forward = new THREE.Vector3(-Math.sin(yaw), 0, -Math.cos(yaw));
        const right = new THREE.Vector3(Math.cos(yaw), 0, -Math.sin(yaw));
        const finalMove = forward.multiplyScalar(moveDir.z).add(right.multiplyScalar(moveDir.x));

        engine.player.vel.x = finalMove.x * moveSpeed;
        engine.player.vel.z = finalMove.z * moveSpeed;

        if (engine.player.onGround && Math.random() < 0.08) {
          soundEngine.playDig('dirt');
        }
      }

      // Jump
      if (engine.keys['Space'] && engine.player.onGround) {
        engine.player.vel.y = 8.5;
        engine.player.onGround = false;
      }

      // Check Fall damage
      if (!engine.player.onGround && engine.player.vel.y < 0) {
        if (!engine.player.isFalling) {
          engine.player.isFalling = true;
          engine.player.fallStartY = engine.player.pos.y;
        }
      }

      const nextPos = engine.player.pos.clone().add(engine.player.vel.clone().multiplyScalar(delta));

      const getBlockAt = (bx: number, by: number, bz: number) => {
        return engine.worldData.get(`${Math.floor(bx)},${Math.floor(by)},${Math.floor(bz)}`) || BLOCKS.AIR;
      };

      // Ground collision
      if (engine.player.vel.y < 0) {
        if (
          getBlockAt(nextPos.x, nextPos.y, nextPos.z) !== BLOCKS.AIR ||
          getBlockAt(nextPos.x, nextPos.y - 0.1, nextPos.z) !== BLOCKS.AIR
        ) {
          engine.player.vel.y = 0;
          if (engine.player.isFalling) {
            const fallDist = engine.player.fallStartY - nextPos.y;
            if (fallDist > 4.5) {
              setHealth((h) => Math.max(0, h - Math.floor(fallDist - 3)));
              soundEngine.playHurt();
            }
            engine.player.isFalling = false;
          }
          engine.player.onGround = true;
          nextPos.y = Math.ceil(nextPos.y);
        }
      }

      // Wall collision
      if (
        getBlockAt(nextPos.x + 0.3, engine.player.pos.y + 0.5, engine.player.pos.z) !== BLOCKS.AIR ||
        getBlockAt(nextPos.x - 0.3, engine.player.pos.y + 0.5, engine.player.pos.z) !== BLOCKS.AIR
      ) {
        engine.player.vel.x = 0;
        nextPos.x = engine.player.pos.x;
      }
      if (
        getBlockAt(engine.player.pos.x, engine.player.pos.y + 0.5, nextPos.z + 0.3) !== BLOCKS.AIR ||
        getBlockAt(engine.player.pos.x, engine.player.pos.y + 0.5, nextPos.z - 0.3) !== BLOCKS.AIR
      ) {
        engine.player.vel.z = 0;
        nextPos.z = engine.player.pos.z;
      }

      engine.player.pos.copy(nextPos);

      // Check Portal Interactions
      const currentBlockUnder = getBlockAt(engine.player.pos.x, engine.player.pos.y, engine.player.pos.z);
      const currentBlockAt = getBlockAt(engine.player.pos.x, engine.player.pos.y + 0.5, engine.player.pos.z);

      if (engine.portalCooldown <= 0) {
        if (currentBlockUnder === BLOCKS.NETHER_PORTAL || currentBlockAt === BLOCKS.NETHER_PORTAL) {
          engine.portalCooldown = 4.0;
          soundEngine.playPortalWoosh();
          if (engine.currentDimension === Dimension.OVERWORLD) {
            switchDimension(Dimension.NETHER, [20, 9, 20]);
            showNotification('🔥 지옥 (The Nether) 차원에 도달했습니다!');
          } else {
            switchDimension(Dimension.OVERWORLD, [20, 10, 20]);
            showNotification('🌍 오버월드로 무사히 귀환했습니다!');
          }
        } else if (currentBlockUnder === BLOCKS.END_PORTAL || currentBlockAt === BLOCKS.END_PORTAL) {
          engine.portalCooldown = 4.0;
          soundEngine.playPortalWoosh();
          if (engine.currentDimension !== Dimension.THE_END) {
            switchDimension(Dimension.THE_END, [35, 11, 35]);
            showNotification('🌌 디 엔드 (The End) 차원에 진입했습니다! 엔더 드래곤 주의!');
          } else {
            switchDimension(Dimension.OVERWORLD, [35, 10, 52]);
            showNotification('🏆 엔더 월드 탈출 성공! 오버월드로 귀환했습니다!');
          }
        }
      }

      // Update Player & Camera Position
      if (isThirdPersonRef.current) {
        steveGroup.visible = true;
        steveGroup.position.copy(engine.player.pos);
        steveGroup.rotation.y = engine.player.rotation.x;

        const dist = 4.5;
        const cx = engine.player.pos.x + Math.sin(engine.player.rotation.x) * dist;
        const cz = engine.player.pos.z + Math.cos(engine.player.rotation.x) * dist;
        const cy = engine.player.pos.y + 1.8 + Math.sin(engine.player.rotation.y) * dist;
        camera.position.set(cx, cy, cz);
        camera.lookAt(engine.player.pos.x, engine.player.pos.y + 1.2, engine.player.pos.z);
      } else {
        steveGroup.visible = false;
        camera.position.set(engine.player.pos.x, engine.player.pos.y + 1.62, engine.player.pos.z);

        const target = new THREE.Vector3(
          engine.player.pos.x - Math.sin(engine.player.rotation.x) * Math.cos(engine.player.rotation.y),
          engine.player.pos.y + 1.62 + Math.sin(engine.player.rotation.y),
          engine.player.pos.z - Math.cos(engine.player.rotation.x) * Math.cos(engine.player.rotation.y)
        );
        camera.lookAt(target);
      }

      // Ultra-fast Raycast for target block (only check meshes within 6 blocks of player)
      const raycaster = new THREE.Raycaster();
      raycaster.setFromCamera(new THREE.Vector2(0, 0), camera);

      const nearbyMeshes: THREE.Mesh[] = [];
      const px = Math.floor(engine.player.pos.x);
      const py = Math.floor(engine.player.pos.y);
      const pz = Math.floor(engine.player.pos.z);
      for (let dx = -5; dx <= 5; dx++) {
        for (let dy = -5; dy <= 5; dy++) {
          for (let dz = -5; dz <= 5; dz++) {
            const m = engine.worldMeshes.get(`${px + dx},${py + dy},${pz + dz}`);
            if (m) nearbyMeshes.push(m);
          }
        }
      }

      const intersects = raycaster.intersectObjects(nearbyMeshes);
      if (intersects.length > 0 && intersects[0].distance < 6.5) {
        const hit = intersects[0];
        const breakPos = hit.object.position.clone().sub(new THREE.Vector3(0.5, 0.5, 0.5)).round();
        const placePos = breakPos.clone().add(hit.face?.normal || new THREE.Vector3(0, 1, 0));
        engine.targetedBlock = { breakPos, placePos };
      } else {
        engine.targetedBlock = null;
      }

      // Update Projectiles
      for (let i = engine.projectiles.length - 1; i >= 0; i--) {
        const p = engine.projectiles[i];
        p.lifetime -= delta;
        p.mesh.position.addScaledVector(p.velocity, delta);

        if (p.owner !== 'player' && p.mesh.position.distanceTo(engine.player.pos) < 1.5) {
          setHealth((h) => Math.max(0, h - 3));
          soundEngine.playHurt();
          scene.remove(p.mesh);
          engine.projectiles.splice(i, 1);
          continue;
        }

        if (p.type === 'ender_pearl') {
          p.velocity.y -= 12 * delta;
          const blockHit = getBlockAt(p.mesh.position.x, p.mesh.position.y, p.mesh.position.z);
          if (blockHit !== BLOCKS.AIR || p.lifetime <= 0) {
            soundEngine.playTeleport();
            engine.player.pos.copy(p.mesh.position).add(new THREE.Vector3(0, 1, 0));
            setHealth((h) => Math.max(1, h - 1));
            scene.remove(p.mesh);
            engine.projectiles.splice(i, 1);
            continue;
          }
        }

        if (p.type === 'ender_eye') {
          p.velocity.multiplyScalar(0.96);
          if (p.lifetime <= 0) {
            scene.remove(p.mesh);
            engine.projectiles.splice(i, 1);
            showNotification('👁️ 엔더의 눈이 유적(Stronghold) 방향을 가리킨 후 소멸했습니다.');
            continue;
          }
        }

        if (p.lifetime <= 0) {
          scene.remove(p.mesh);
          engine.projectiles.splice(i, 1);
        }
      }

      // Update Mobs
      const spawnProj = (proj: Projectile) => {
        scene.add(proj.mesh);
        engine.projectiles.push(proj);
      };

      // Animals (Pig, Cow, Sheep)
      for (let i = engine.animals.length - 1; i >= 0; i--) {
        const a = engine.animals[i];
        a.update(delta, engine.getTerrainHeight, WORLD_SIZE);
        if (a.health <= 0) {
          a.die(scene, addItem);
          engine.animals.splice(i, 1);
        }
      }

      // Zombies
      for (let i = engine.zombies.length - 1; i >= 0; i--) {
        const z = engine.zombies[i];
        z.update(
          delta,
          engine.player.pos,
          (dmg) => {
            setHealth((h) => Math.max(0, h - dmg));
            soundEngine.playHurt();
          },
          engine.getTerrainHeight,
          WORLD_SIZE
        );
        // Burn in daylight
        if (engine.currentDimension === Dimension.OVERWORLD && sunLight.position.y > 0) {
          z.takeDamage(delta * 2);
        }
        if (z.health <= 0) {
          z.die(scene, addItem);
          engine.zombies.splice(i, 1);
        }
      }

      // Blazes
      for (let i = engine.blazes.length - 1; i >= 0; i--) {
        const b = engine.blazes[i];
        b.update(delta, engine.player.pos, spawnProj);
        if (b.health <= 0) {
          b.die(scene, addItem);
          engine.blazes.splice(i, 1);
        }
      }

      // Endermen
      for (let i = engine.endermen.length - 1; i >= 0; i--) {
        const em = engine.endermen[i];
        em.update(delta, engine.player.pos, (dmg) => {
          setHealth((h) => Math.max(0, h - dmg));
          soundEngine.playHurt();
        });
        if (em.health <= 0) {
          em.die(scene, addItem);
          engine.endermen.splice(i, 1);
        }
      }

      // Ender Dragon Boss
      if (engine.dragon) {
        engine.dragon.update(delta, engine.player.pos, spawnProj);
        setDragonHealth(engine.dragon.health);
        if (engine.dragon.health <= 0) {
          engine.dragon.die(scene, () => {
            showNotification('🎉 축하합니다! 전설의 엔더 드래곤을 격퇴했습니다!');
          });
          engine.dragon = null;
          setDragonHealth(undefined);
        }
      }

      // Throttled HUD update (Runs 6 times a second instead of 60 to prevent React lagging)
      hudTimer += delta;
      if (hudTimer >= 0.16) {
        hudTimer = 0;
        setPlayerPosition({
          x: Math.round(engine.player.pos.x),
          y: Math.round(engine.player.pos.y),
          z: Math.round(engine.player.pos.z)
        });
        setBiome(getBiomeAt(engine.player.pos.x, engine.player.pos.z, engine.currentDimension));
        const isCurrentlyNight = sunLight.position.y < 0;
        setIsNight(isCurrentlyNight);
        setTimeStr(isCurrentlyNight ? '밤 (00:00) 🌙' : '낮 (12:00) ☀️');
      }

      renderer.render(scene, camera);
    };

    animationId = requestAnimationFrame(animate);

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('wheel', handleWheel);
      document.removeEventListener('pointerlockchange', handlePointerLockChange);

      domEl.removeEventListener('mousedown', handleCanvasMouseDown);
      window.removeEventListener('mouseup', handleCanvasMouseUp);
      domEl.removeEventListener('touchstart', handleTouchStart);
      domEl.removeEventListener('touchmove', handleTouchMove);
      domEl.removeEventListener('touchend', handleTouchEnd);

      if (renderer.domElement && mountRef.current) {
        mountRef.current.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, []);

  // Dimension Switcher Handler
  const switchDimension = (targetDim: Dimension, spawnPos: [number, number, number]) => {
    if (!engineRef.current) return;
    const engine = engineRef.current;
    engine.currentDimension = targetDim;
    setDimension(targetDim);

    // Clear previous dimension meshes and entities
    engine.worldMeshes.forEach((mesh) => engine.scene.remove(mesh));
    engine.worldMeshes.clear();
    engine.worldData.clear();

    engine.animals.forEach((a) => engine.scene.remove(a.mesh));
    engine.animals = [];

    engine.zombies.forEach((z) => engine.scene.remove(z.mesh));
    engine.zombies = [];

    engine.blazes.forEach((b) => engine.scene.remove(b.mesh));
    engine.blazes = [];

    engine.endermen.forEach((em) => engine.scene.remove(em.mesh));
    engine.endermen = [];

    if (engine.dragon) {
      engine.scene.remove(engine.dragon.mesh);
      engine.dragon = null;
      setDragonHealth(undefined);
    }

    // Sky & Lighting setup per dimension
    if (targetDim === Dimension.NETHER) {
      engine.scene.background = new THREE.Color(0x380505);
      engine.scene.fog = new THREE.FogExp2(0x380505, 0.015);
      engine.ambientLight.color.setHex(0xff7755);
      engine.ambientLight.intensity = 0.55;
      engine.sunLight.intensity = 0.2;
    } else if (targetDim === Dimension.THE_END) {
      engine.scene.background = new THREE.Color(0x0a0614);
      engine.scene.fog = new THREE.FogExp2(0x0a0614, 0.012);
      engine.ambientLight.color.setHex(0xcc99ff);
      engine.ambientLight.intensity = 0.5;
      engine.sunLight.intensity = 0.2;
    } else {
      engine.scene.background = new THREE.Color(0x87ceeb);
      engine.scene.fog = new THREE.FogExp2(0x87ceeb, 0.008);
      engine.ambientLight.color.setHex(0xffffff);
      engine.ambientLight.intensity = 0.75;
      engine.sunLight.intensity = 0.9;
    }

    // Populate new dimension blocks
    generateDimensionWorld(targetDim, (x, y, z, type) => {
      if (type === BLOCKS.AIR) {
        engine.worldData.delete(`${x},${y},${z}`);
      } else {
        engine.worldData.set(`${x},${y},${z}`, type);
      }
    });
    engine.buildVisibleMeshes();

    // Spawn native dimension mobs
    if (targetDim === Dimension.OVERWORLD) {
      const animalTypes: ('pig' | 'cow' | 'sheep')[] = ['pig', 'cow', 'sheep'];
      for (let i = 0; i < 12; i++) {
        const ax = 10 + Math.random() * (WORLD_SIZE - 20);
        const az = 10 + Math.random() * (WORLD_SIZE - 20);
        const ay = engine.getTerrainHeight(ax, az) + 1.0;
        const type = animalTypes[i % 3];
        engine.animals.push(new AnimalMob(type, ax, ay, az, engine.scene));
      }
    } else if (targetDim === Dimension.NETHER) {
      // Spawn Blazes at Fortress (35, 50)
      for (let i = 0; i < 4; i++) {
        engine.blazes.push(new BlazeMob(32 + i * 2, 12, 48 + (i % 2) * 4, engine.scene));
      }
    } else if (targetDim === Dimension.THE_END) {
      // Spawn Ender Dragon & Endermen
      engine.dragon = new EnderDragonBoss(engine.scene);
      setDragonHealth(200);

      for (let i = 0; i < 5; i++) {
        const rad = Math.random() * Math.PI * 2;
        const dist = 10 + Math.random() * 12;
        engine.endermen.push(
          new EndermanMob(
            35 + Math.sin(rad) * dist,
            11,
            35 + Math.cos(rad) * dist,
            engine.scene
          )
        );
      }
    }

    // Teleport player
    engine.player.pos.set(...spawnPos);
    engine.player.vel.set(0, 0, 0);
  };

  // Add Item to inventory
  const addItem = (id: string | number, count: number) => {
    setInventory((prev) => {
      const updated = [...prev];
      for (let i = 0; i < updated.length; i++) {
        if (updated[i] && updated[i]!.id === id) {
          updated[i] = { ...updated[i]!, count: updated[i]!.count + count };
          return updated;
        }
      }
      if (!updated[selectedSlot]) {
        updated[selectedSlot] = { id, count };
        return updated;
      }
      for (let i = 0; i < updated.length; i++) {
        if (!updated[i]) {
          updated[i] = { id, count };
          return updated;
        }
      }
      return updated;
    });
  };

  // Left-Click Handler: Attack Enemies or Break Block
  const handleLeftClick = () => {
    if (!engineRef.current) return;
    const engine = engineRef.current;
    soundEngine.init();

    engine.isSwingingArm = true;
    engine.swingProgress = 0;

    const currentItem = inventory[selectedSlot];
    const weaponDamage = currentItem && WEAPON_DAMAGE[String(currentItem.id)]
      ? WEAPON_DAMAGE[String(currentItem.id)]
      : 2;

    soundEngine.playSwordSwing();

    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(new THREE.Vector2(0, 0), engine.camera);

    // 1. Dragon hit check
    if (engine.dragon && !engine.dragon.dead) {
      const hits = raycaster.intersectObject(engine.dragon.mesh, true);
      if (hits.length > 0 && hits[0].distance < 14) {
        engine.dragon.takeDamage(weaponDamage * 1.5);
        showNotification(`🗡️ 엔더 드래곤에게 ${weaponDamage * 1.5}의 피해를 입혔습니다!`);
        return;
      }
    }

    // 2. Animals hit check
    for (const a of engine.animals) {
      const hits = raycaster.intersectObject(a.mesh, true);
      if (hits.length > 0 && hits[0].distance < 6) {
        a.takeDamage(weaponDamage);
        return;
      }
    }

    // 3. Zombies hit check
    for (const z of engine.zombies) {
      const hits = raycaster.intersectObject(z.mesh, true);
      if (hits.length > 0 && hits[0].distance < 6) {
        z.takeDamage(weaponDamage);
        return;
      }
    }

    // 4. Blaze hit check
    for (const b of engine.blazes) {
      const hits = raycaster.intersectObject(b.mesh, true);
      if (hits.length > 0 && hits[0].distance < 6) {
        b.takeDamage(weaponDamage);
        return;
      }
    }

    // 5. Enderman hit check
    for (const em of engine.endermen) {
      const hits = raycaster.intersectObject(em.mesh, true);
      if (hits.length > 0 && hits[0].distance < 6) {
        em.takeDamage(weaponDamage, engine.player.pos);
        return;
      }
    }

    // 6. Break Targeted Block
    if (engine.targetedBlock) {
      const { breakPos } = engine.targetedBlock;
      const key = `${breakPos.x},${breakPos.y},${breakPos.z}`;
      const blockId = engine.worldData.get(key);

      if (blockId !== undefined && (blockId as number) !== BLOCKS.AIR) {
        soundEngine.playDig(blockId === BLOCKS.STONE ? 'stone' : 'dirt');
        engine.worldData.delete(key);
        if (engine.worldMeshes.has(key)) {
          engine.scene.remove(engine.worldMeshes.get(key)!);
          engine.worldMeshes.delete(key);
        }

        // Expose surrounding blocks that were previously underground
        const neighbors = [
          [breakPos.x + 1, breakPos.y, breakPos.z],
          [breakPos.x - 1, breakPos.y, breakPos.z],
          [breakPos.x, breakPos.y + 1, breakPos.z],
          [breakPos.x, breakPos.y - 1, breakPos.z],
          [breakPos.x, breakPos.y, breakPos.z + 1],
          [breakPos.x, breakPos.y, breakPos.z - 1]
        ];
        neighbors.forEach(([nx, ny, nz]) => {
          const nKey = `${nx},${ny},${nz}`;
          const nType = engine.worldData.get(nKey);
          if (nType && !engine.worldMeshes.has(nKey)) {
            engine.renderBlockMesh(nx, ny, nz, nType);
          }
        });

        addItem(blockId, 1);
      }
    }
  };

  // Right-Click Handler: Special Item, Eat, Bow, or Place Block
  const handleRightClick = () => {
    if (!engineRef.current) return;
    const engine = engineRef.current;
    soundEngine.init();

    const currentItem = inventory[selectedSlot];
    if (!currentItem) return;

    engine.isSwingingArm = true;
    engine.swingProgress = 0;

    // 1. Food items (Eating restores hunger & health)
    if (['cooked_pork', 'raw_pork', 'raw_beef', 'golden_apple'].includes(String(currentItem.id))) {
      soundEngine.playEat();
      const isGolden = currentItem.id === 'golden_apple';
      const healAmount = isGolden ? 10 : (currentItem.id === 'cooked_pork' ? 5 : 2);
      setHealth((h) => Math.min(10, h + healAmount));
      setHunger((hg) => Math.min(10, hg + 4));
      consumeCurrentItem();
      showNotification(isGolden ? '✨ 황금 사과로 체력이 회복되었습니다!' : '🍖 음식을 맛있게 먹었습니다.');
      return;
    }

    // 2. Ender Pearl (Throw to Teleport)
    if (currentItem.id === 'ender_pearl') {
      soundEngine.playBowShoot();
      const yaw = engine.player.rotation.x;
      const pitch = engine.player.rotation.y;
      const dir = new THREE.Vector3(
        -Math.sin(yaw) * Math.cos(pitch),
        Math.sin(pitch),
        -Math.cos(yaw) * Math.cos(pitch)
      ).normalize();

      const pearlGeo = new THREE.SphereGeometry(0.18, 8, 8);
      const pearlMat = new THREE.MeshBasicMaterial({ color: 0x064e3b });
      const pearlMesh = new THREE.Mesh(pearlGeo, pearlMat);
      pearlMesh.position.copy(engine.player.pos).add(new THREE.Vector3(0, 1.5, 0));
      engine.scene.add(pearlMesh);

      engine.projectiles.push({
        mesh: pearlMesh,
        velocity: dir.multiplyScalar(24),
        type: 'ender_pearl',
        lifetime: 5.0,
        owner: 'player'
      });

      consumeCurrentItem();
      return;
    }

    // 3. Eye of Ender (Throw towards Stronghold at 35, 52)
    if (currentItem.id === 'ender_eye') {
      soundEngine.playBowShoot();
      const strongholdPos = new THREE.Vector3(35, 8, 52);
      const eyeDir = new THREE.Vector3().subVectors(strongholdPos, engine.player.pos).normalize();
      eyeDir.y = 0.25;
      eyeDir.normalize();

      const eyeGeo = new THREE.SphereGeometry(0.2, 8, 8);
      const eyeMat = new THREE.MeshBasicMaterial({ color: 0x10b981 });
      const eyeMesh = new THREE.Mesh(eyeGeo, eyeMat);
      eyeMesh.position.copy(engine.player.pos).add(new THREE.Vector3(0, 1.6, 0));
      engine.scene.add(eyeMesh);

      engine.projectiles.push({
        mesh: eyeMesh,
        velocity: eyeDir.multiplyScalar(14),
        type: 'ender_eye',
        lifetime: 3.5,
        owner: 'player'
      });

      showNotification('👁️ 엔더의 눈이 유적(포탈룸) 방향으로 날아갑니다!');
      consumeCurrentItem();
      return;
    }

    // 4. Bow Shoot
    if (currentItem.id === 'bow') {
      soundEngine.playBowShoot();
      const yaw = engine.player.rotation.x;
      const pitch = engine.player.rotation.y;
      const dir = new THREE.Vector3(
        -Math.sin(yaw) * Math.cos(pitch),
        Math.sin(pitch),
        -Math.cos(yaw) * Math.cos(pitch)
      ).normalize();

      const arrowGeo = new THREE.BoxGeometry(0.08, 0.08, 0.6);
      const arrowMat = new THREE.MeshLambertMaterial({ color: 0xd97706 });
      const arrowMesh = new THREE.Mesh(arrowGeo, arrowMat);
      arrowMesh.position.copy(engine.player.pos).add(new THREE.Vector3(0, 1.5, 0));
      arrowMesh.lookAt(arrowMesh.position.clone().add(dir));
      engine.scene.add(arrowMesh);

      engine.projectiles.push({
        mesh: arrowMesh,
        velocity: dir.multiplyScalar(28),
        type: 'arrow',
        lifetime: 4.0,
        owner: 'player'
      });
      return;
    }

    // 5. Spawn Eggs
    if (String(currentItem.id).startsWith('spawn_')) {
      const spawnPos = engine.player.pos.clone().add(
        new THREE.Vector3(
          -Math.sin(engine.player.rotation.x) * 3,
          0,
          -Math.cos(engine.player.rotation.x) * 3
        )
      );

      soundEngine.playPlace();
      if (currentItem.id === 'spawn_blaze') {
        engine.blazes.push(new BlazeMob(spawnPos.x, spawnPos.y + 1, spawnPos.z, engine.scene));
        showNotification('🔥 불타는 블레이즈를 소환했습니다!');
      } else if (currentItem.id === 'spawn_enderman') {
        engine.endermen.push(new EndermanMob(spawnPos.x, spawnPos.y + 1, spawnPos.z, engine.scene));
        showNotification('🟣 3블록 키의 엔더맨을 소환했습니다!');
      } else if (currentItem.id === 'spawn_ender_dragon') {
        if (engine.dragon) engine.scene.remove(engine.dragon.mesh);
        engine.dragon = new EnderDragonBoss(engine.scene);
        setDragonHealth(200);
        showNotification('🐉 전설의 엔더 드래곤을 소환했습니다!');
      }
      consumeCurrentItem();
      return;
    }

    // 6. Block Placement
    if (typeof currentItem.id === 'number' && engine.targetedBlock) {
      const { placePos } = engine.targetedBlock;
      const key = `${placePos.x},${placePos.y},${placePos.z}`;

      // Prevent placing inside player hitbox
      const p = engine.player.pos;
      if (
        placePos.x >= Math.floor(p.x - 0.3) &&
        placePos.x <= Math.floor(p.x + 0.3) &&
        placePos.y >= Math.floor(p.y) &&
        placePos.y <= Math.floor(p.y + 1.8) &&
        placePos.z >= Math.floor(p.z - 0.3) &&
        placePos.z <= Math.floor(p.z + 0.3)
      ) {
        return;
      }

      soundEngine.playPlace();
      engine.worldData.set(key, currentItem.id as BlockId);
      engine.renderBlockMesh(placePos.x, placePos.y, placePos.z, currentItem.id as BlockId);

      consumeCurrentItem();
    }
  };

  const consumeCurrentItem = () => {
    setInventory((prev) => {
      const updated = [...prev];
      if (updated[selectedSlot]) {
        updated[selectedSlot] = {
          ...updated[selectedSlot]!,
          count: updated[selectedSlot]!.count - 1
        };
        if (updated[selectedSlot]!.count <= 0) {
          updated[selectedSlot] = null;
        }
      }
      return updated;
    });
  };

  const handleJump = () => {
    if (!engineRef.current) return;
    soundEngine.init();
    if (engineRef.current.player.onGround) {
      engineRef.current.player.vel.y = 8.5;
      engineRef.current.player.onGround = false;
    }
  };

  const handleStartGame = (e?: React.SyntheticEvent) => {
    if (e) {
      e.stopPropagation();
    }
    soundEngine.init();
    setGameStarted(true);
    requestSafePointerLock();
  };

  return (
    <div className="relative w-full h-full overflow-hidden select-none font-['VT323',monospace]">
      {/* 3D WebGL Canvas Mount */}
      <div
        ref={mountRef}
        className="w-full h-full cursor-crosshair touch-none"
        onClick={() => {
          if (gameStarted && !isInventoryOpen && !isItemPickerOpen && !isBiomeMenuOpen) {
            requestSafePointerLock();
          }
        }}
        onContextMenu={(e) => e.preventDefault()}
      />

      {/* Start Screen Overlay */}
      {!gameStarted && (
        <div className="absolute inset-0 z-50 overflow-y-auto bg-black/85 text-white p-3 sm:p-6 flex flex-col items-center justify-start sm:justify-center backdrop-blur-xs">
          <div className="w-full max-w-2xl my-auto flex flex-col items-center py-2">
            <h1 className="text-4xl sm:text-6xl md:text-7xl font-bold tracking-wider text-green-400 mb-1 sm:mb-2 drop-shadow-[0_4px_6px_rgba(0,0,0,1)] text-center leading-none">
              MINECRAFT 3D
            </h1>
            <p className="text-base sm:text-xl text-yellow-300 mb-4 font-semibold tracking-wide drop-shadow text-center">
              스티브의 모험 · 전체 바이옴 · 지옥 · 엔더 드래곤 & 조합
            </p>

            {/* Primary Play Button */}
            <button
              id="start-game-button-main"
              type="button"
              onClick={handleStartGame}
              onTouchStart={handleStartGame}
              className="mc-button text-2xl sm:text-3xl py-3 sm:py-4 px-10 sm:px-14 rounded font-bold mb-4 sm:mb-6 cursor-pointer hover:scale-105 active:scale-95 transition bg-green-700 hover:bg-green-600 border-4 border-green-300 shadow-xl"
            >
              ▶ 게임 시작 (Play Now)
            </button>

            {/* Guide Card */}
            <div className="bg-gray-900/90 border-2 border-gray-600 rounded-lg p-3 sm:p-4 text-xs sm:text-sm text-gray-200 w-full mb-3 space-y-2">
              <h2 className="text-green-300 font-bold text-sm sm:text-base border-b border-gray-700 pb-1">
                🎮 게임 조작법 & 꿀팁
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div><b className="text-yellow-400">이동:</b> W, A, S, D / 스페이스바 (점프)</div>
                <div><b className="text-yellow-400">시선 회전:</b> 마우스 드래그 또는 터치 드래그</div>
                <div><b className="text-yellow-400">행동:</b> 좌클릭 (파괴/공격), 우클릭 (설치/먹기/사격)</div>
                <div><b className="text-yellow-400">단축키:</b> E (인벤토리/조합), B (아이템 선택), T (바이옴 이동), F5 (3인칭)</div>
                <div className="sm:col-span-2 text-emerald-300 font-medium">
                  💡 낮에는 평화로운 동물(돼지, 소, 양)을 사냥하고, 밤에는 좀비의 습격을 막아내세요!
                </div>
              </div>
            </div>

            <button
              id="start-game-button-bottom"
              type="button"
              onClick={handleStartGame}
              onTouchStart={handleStartGame}
              className="mc-button text-lg sm:text-xl py-2 px-6 rounded font-bold cursor-pointer hover:scale-105 active:scale-95 transition bg-emerald-800 hover:bg-emerald-700 border-2 border-emerald-300 shadow-md"
            >
              입장하기 (Enter World)
            </button>
          </div>
        </div>
      )}

      {/* Main Minecraft HUD Overlay */}
      {gameStarted && (
        <>
          <HUD
            health={health}
            maxHealth={10}
            hunger={hunger}
            maxHunger={10}
            dimension={dimension}
            biome={biome}
            position={playerPosition}
            timeStr={timeStr}
            isNight={isNight}
            selectedItemName={selectedItemName}
            dragonHealth={dragonHealth}
            notification={notification}
            onToggleCamera={() => setIsThirdPerson((prev) => !prev)}
            onToggleInventory={() => setIsInventoryOpen((prev) => !prev)}
            onToggleItemPicker={() => setIsItemPickerOpen((prev) => !prev)}
            onToggleBiomeMenu={() => setIsBiomeMenuOpen((prev) => !prev)}
            onMobileAttack={handleLeftClick}
            onMobilePlace={handleRightClick}
            onMobileJump={handleJump}
          />

          {/* Bottom Hotbar */}
          <div className="absolute bottom-2 sm:bottom-3 left-1/2 -translate-x-1/2 z-20 pointer-events-auto max-w-[98vw] overflow-x-auto">
            <Hotbar
              slots={inventory.slice(0, 9)}
              selectedIndex={selectedSlot}
              onSelectSlot={(idx) => setSelectedSlot(idx)}
            />
          </div>
        </>
      )}

      {/* Item Picker Modal */}
      <ItemPickerModal
        isOpen={isItemPickerOpen}
        onClose={() => {
          setIsItemPickerOpen(false);
          requestSafePointerLock();
        }}
        onSelectItem={(item) => {
          addItem(item.id, item.count);
          showNotification(`✨ ${item.name} (${item.count}개)를 획득했습니다!`);
        }}
      />

      {/* Biome Teleport Menu */}
      <BiomeTeleportMenu
        isOpen={isBiomeMenuOpen}
        onClose={() => {
          setIsBiomeMenuOpen(false);
          requestSafePointerLock();
        }}
        onTeleport={(loc: BiomeCoordInfo) => {
          switchDimension(loc.dimension, loc.spawnPos);
          showNotification(`🚀 ${loc.name} (으)로 순간이동했습니다!`);
        }}
      />

      {/* Inventory and 2x2 Crafting Modal */}
      <InventoryCraftingModal
        isOpen={isInventoryOpen}
        onClose={() => {
          setIsInventoryOpen(false);
          requestSafePointerLock();
        }}
        inventory={inventory}
        onUpdateInventory={(updated) => setInventory(updated)}
        onAddItem={(id, count) => {
          addItem(id, count);
          showNotification(`🛠️ ${BLOCK_NAMES[id] || id} x${count} 제작 완료!`);
        }}
      />
    </div>
  );
}
