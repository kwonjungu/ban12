import * as THREE from 'three';
import { BLOCKS } from '../types';

export function createPixelTexture(
  type: string,
  width = 32,
  height = 32
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d')!;

  function fillRandomNoise(baseColor: [number, number, number], variation = 20) {
    const [r, g, b] = baseColor;
    for (let x = 0; x < width; x++) {
      for (let y = 0; y < height; y++) {
        const noise = (Math.random() - 0.5) * variation;
        const nr = Math.min(255, Math.max(0, Math.round(r + noise)));
        const ng = Math.min(255, Math.max(0, Math.round(g + noise)));
        const nb = Math.min(255, Math.max(0, Math.round(b + noise)));
        ctx.fillStyle = `rgb(${nr},${ng},${nb})`;
        ctx.fillRect(x, y, 1, 1);
      }
    }
  }

  switch (type) {
    case 'grass_top':
      fillRandomNoise([100, 168, 56], 25);
      // subtle flowers / highlights
      for (let i = 0; i < 6; i++) {
        const rx = Math.floor(Math.random() * width);
        const ry = Math.floor(Math.random() * height);
        ctx.fillStyle = '#bbf255';
        ctx.fillRect(rx, ry, 2, 2);
      }
      break;

    case 'grass_side':
      fillRandomNoise([134, 96, 67], 25);
      // jagged green grass hanging over dirt
      ctx.fillStyle = '#64a838';
      for (let x = 0; x < width; x++) {
        const hang = 6 + Math.floor(Math.sin(x * 0.4) * 3 + (x % 3));
        ctx.fillRect(x, 0, 1, hang);
      }
      break;

    case 'dirt':
      fillRandomNoise([134, 96, 67], 30);
      for (let i = 0; i < 12; i++) {
        ctx.fillStyle = '#5c3e28';
        ctx.fillRect(Math.random() * width, Math.random() * height, 2, 2);
      }
      break;

    case 'stone':
      fillRandomNoise([128, 128, 128], 22);
      for (let i = 0; i < 16; i++) {
        ctx.fillStyle = '#5e5e5e';
        ctx.fillRect(Math.random() * width, Math.random() * height, 2, 2);
      }
      break;

    case 'stone_bricks':
      fillRandomNoise([140, 140, 140], 18);
      ctx.fillStyle = '#444444';
      // brick lines
      for (let y = 0; y < height; y += 8) {
        ctx.fillRect(0, y, width, 1);
      }
      for (let x = 0; x < width; x += 16) {
        ctx.fillRect(x, 0, 1, 8);
        ctx.fillRect((x + 8) % width, 8, 1, 8);
        ctx.fillRect(x, 16, 1, 8);
        ctx.fillRect((x + 8) % width, 24, 1, 8);
      }
      break;

    case 'mossy_stone_bricks':
      fillRandomNoise([130, 138, 125], 20);
      ctx.fillStyle = '#3a3a3a';
      for (let y = 0; y < height; y += 8) {
        ctx.fillRect(0, y, width, 1);
      }
      ctx.fillStyle = '#3f7a28';
      for (let i = 0; i < 24; i++) {
        ctx.fillRect(Math.random() * width, Math.random() * height, 3, 3);
      }
      break;

    case 'sand':
      fillRandomNoise([226, 212, 148], 18);
      for (let i = 0; i < 20; i++) {
        ctx.fillStyle = '#c7b36f';
        ctx.fillRect(Math.random() * width, Math.random() * height, 1, 1);
      }
      break;

    case 'snow_top':
      fillRandomNoise([245, 250, 255], 10);
      for (let i = 0; i < 15; i++) {
        ctx.fillStyle = '#d5e6f8';
        ctx.fillRect(Math.random() * width, Math.random() * height, 2, 2);
      }
      break;

    case 'snow_side':
      fillRandomNoise([134, 96, 67], 25);
      ctx.fillStyle = '#f0f5ff';
      ctx.fillRect(0, 0, width, 10);
      break;

    case 'ice':
      fillRandomNoise([175, 220, 245], 20);
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(4, 4, 8, 2);
      ctx.fillRect(18, 16, 7, 2);
      ctx.fillRect(8, 24, 5, 2);
      break;

    case 'water':
      fillRandomNoise([36, 108, 204], 25);
      ctx.fillStyle = '#5dade2';
      for (let x = 0; x < width; x += 4) {
        ctx.fillRect(x, Math.floor(Math.sin(x) * 3 + 8), 2, 2);
        ctx.fillRect(x, Math.floor(Math.cos(x) * 3 + 20), 2, 2);
      }
      break;

    case 'cactus_side':
      fillRandomNoise([48, 128, 38], 25);
      ctx.fillStyle = '#1c6014';
      ctx.fillRect(6, 0, 3, height);
      ctx.fillRect(22, 0, 3, height);
      ctx.fillStyle = '#11330e';
      for (let y = 3; y < height; y += 6) {
        ctx.fillRect(7, y, 2, 2);
        ctx.fillRect(23, y, 2, 2);
      }
      break;

    case 'cactus_top':
      fillRandomNoise([55, 140, 45], 20);
      ctx.fillStyle = '#225e19';
      ctx.fillRect(14, 14, 4, 4);
      break;

    case 'oak_wood_side':
      fillRandomNoise([140, 105, 70], 25);
      ctx.fillStyle = '#6b4f31';
      for (let x = 0; x < width; x += 6) {
        ctx.fillRect(x, 0, 2, height);
      }
      break;

    case 'oak_wood_top':
      fillRandomNoise([175, 140, 100], 20);
      ctx.fillStyle = '#8a643d';
      ctx.beginPath();
      ctx.arc(16, 16, 10, 0, Math.PI * 2);
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(16, 16, 5, 0, Math.PI * 2);
      ctx.stroke();
      break;

    case 'oak_leaves':
      fillRandomNoise([40, 130, 35], 35);
      for (let i = 0; i < 40; i++) {
        ctx.fillStyle = Math.random() > 0.5 ? '#246b1f' : '#62b53f';
        ctx.fillRect(Math.random() * width, Math.random() * height, 2, 2);
      }
      break;

    case 'jungle_wood_side':
      fillRandomNoise([110, 85, 55], 25);
      ctx.fillStyle = '#483520';
      for (let x = 0; x < width; x += 7) {
        ctx.fillRect(x, 0, 2, height);
      }
      ctx.fillStyle = '#2c7322'; // jungle vines
      for (let y = 0; y < height; y += 4) {
        ctx.fillRect(Math.floor(Math.sin(y) * 4 + 8), y, 2, 3);
      }
      break;

    case 'jungle_leaves':
      fillRandomNoise([30, 155, 45], 40);
      for (let i = 0; i < 35; i++) {
        ctx.fillStyle = '#177a25';
        ctx.fillRect(Math.random() * width, Math.random() * height, 3, 3);
      }
      break;

    case 'planks':
      fillRandomNoise([178, 140, 95], 20);
      ctx.fillStyle = '#7a5a36';
      for (let y = 0; y < height; y += 8) {
        ctx.fillRect(0, y, width, 1);
      }
      break;

    // Obsidian
    case 'obsidian':
      fillRandomNoise([24, 18, 38], 22);
      ctx.fillStyle = '#4f2b82';
      for (let i = 0; i < 24; i++) {
        ctx.fillRect(Math.random() * width, Math.random() * height, 2, 2);
      }
      ctx.fillStyle = '#8347cc';
      for (let i = 0; i < 8; i++) {
        ctx.fillRect(Math.random() * width, Math.random() * height, 1, 1);
      }
      break;

    // Nether Portal (Animated shimmer texture)
    case 'nether_portal':
      fillRandomNoise([80, 20, 140], 40);
      ctx.fillStyle = '#be4cf0';
      for (let i = 0; i < 35; i++) {
        ctx.fillRect(Math.random() * width, Math.random() * height, 3, 3);
      }
      ctx.fillStyle = '#f3b4ff';
      for (let i = 0; i < 15; i++) {
        ctx.fillRect(Math.random() * width, Math.random() * height, 2, 2);
      }
      break;

    // End Portal Frame (Top)
    case 'end_portal_frame_top':
      fillRandomNoise([70, 100, 75], 18);
      ctx.fillStyle = '#2f4f3b';
      ctx.fillRect(4, 4, width - 8, height - 8);
      ctx.fillStyle = '#caa342'; // golden socket
      ctx.fillRect(10, 10, 12, 12);
      break;

    case 'end_portal_frame_eye_top':
      fillRandomNoise([70, 100, 75], 18);
      ctx.fillStyle = '#2f4f3b';
      ctx.fillRect(4, 4, width - 8, height - 8);
      ctx.fillStyle = '#caa342';
      ctx.fillRect(10, 10, 12, 12);
      // Ender eye in center
      ctx.fillStyle = '#0f5242';
      ctx.fillRect(11, 11, 10, 10);
      ctx.fillStyle = '#1de9b6';
      ctx.fillRect(13, 13, 6, 6);
      ctx.fillStyle = '#06261f';
      ctx.fillRect(15, 14, 2, 4);
      break;

    case 'end_portal_frame_side':
      fillRandomNoise([90, 120, 95], 20);
      ctx.fillStyle = '#1e3828';
      ctx.fillRect(0, 0, width, 6);
      ctx.fillStyle = '#d4af37';
      ctx.fillRect(6, 12, width - 12, 8);
      break;

    // End Portal (Cosmic Void)
    case 'end_portal':
      fillRandomNoise([6, 12, 24], 15);
      ctx.fillStyle = '#14b8a6';
      for (let i = 0; i < 30; i++) {
        ctx.fillRect(Math.random() * width, Math.random() * height, 1, 1);
      }
      ctx.fillStyle = '#c084fc';
      for (let i = 0; i < 20; i++) {
        ctx.fillRect(Math.random() * width, Math.random() * height, 2, 2);
      }
      ctx.fillStyle = '#ffffff';
      for (let i = 0; i < 15; i++) {
        ctx.fillRect(Math.random() * width, Math.random() * height, 1, 1);
      }
      break;

    // Nether Biomes
    case 'netherrack':
      fillRandomNoise([110, 24, 24], 30);
      ctx.fillStyle = '#551111';
      for (let i = 0; i < 25; i++) {
        ctx.fillRect(Math.random() * width, Math.random() * height, 3, 3);
      }
      ctx.fillStyle = '#e53935';
      for (let i = 0; i < 15; i++) {
        ctx.fillRect(Math.random() * width, Math.random() * height, 2, 2);
      }
      break;

    case 'nether_bricks':
      fillRandomNoise([60, 18, 24], 20);
      ctx.fillStyle = '#2b090e';
      for (let y = 0; y < height; y += 8) {
        ctx.fillRect(0, y, width, 1);
      }
      for (let x = 0; x < width; x += 16) {
        ctx.fillRect(x, 0, 1, 8);
        ctx.fillRect((x + 8) % width, 8, 1, 8);
        ctx.fillRect(x, 16, 1, 8);
        ctx.fillRect((x + 8) % width, 24, 1, 8);
      }
      break;

    case 'warped_nylium_top':
      fillRandomNoise([20, 120, 115], 30);
      ctx.fillStyle = '#155e58';
      for (let i = 0; i < 25; i++) {
        ctx.fillRect(Math.random() * width, Math.random() * height, 2, 2);
      }
      ctx.fillStyle = '#5eead4';
      for (let i = 0; i < 18; i++) {
        ctx.fillRect(Math.random() * width, Math.random() * height, 2, 2);
      }
      break;

    case 'warped_stem_side':
      fillRandomNoise([30, 95, 95], 25);
      ctx.fillStyle = '#134e4a';
      for (let x = 0; x < width; x += 6) {
        ctx.fillRect(x, 0, 2, height);
      }
      ctx.fillStyle = '#2dd4bf';
      for (let y = 0; y < height; y += 8) {
        ctx.fillRect(Math.floor(Math.random() * width), y, 2, 4);
      }
      break;

    case 'warped_wart':
      fillRandomNoise([15, 110, 100], 35);
      ctx.fillStyle = '#14b8a6';
      for (let i = 0; i < 35; i++) {
        ctx.fillRect(Math.random() * width, Math.random() * height, 2, 2);
      }
      break;

    case 'glowstone':
      fillRandomNoise([215, 175, 90], 35);
      ctx.fillStyle = '#ffe082';
      for (let i = 0; i < 30; i++) {
        ctx.fillRect(Math.random() * width, Math.random() * height, 3, 3);
      }
      ctx.fillStyle = '#fff8e1';
      for (let i = 0; i < 15; i++) {
        ctx.fillRect(Math.random() * width, Math.random() * height, 2, 2);
      }
      break;

    // The End
    case 'end_stone':
      fillRandomNoise([225, 230, 170], 25);
      ctx.fillStyle = '#b5ba80';
      for (let i = 0; i < 30; i++) {
        ctx.fillRect(Math.random() * width, Math.random() * height, 2, 2);
      }
      break;

    case 'purpur_block':
      fillRandomNoise([170, 125, 170], 20);
      ctx.fillStyle = '#7a4b7a';
      ctx.strokeRect(2, 2, width - 4, height - 4);
      break;

    case 'diamond_ore':
      fillRandomNoise([128, 128, 128], 22);
      ctx.fillStyle = '#22d3ee';
      for (let i = 0; i < 6; i++) {
        const rx = 4 + Math.floor(Math.random() * (width - 8));
        const ry = 4 + Math.floor(Math.random() * (height - 8));
        ctx.fillRect(rx, ry, 4, 3);
      }
      break;

    case 'diamond_block':
      fillRandomNoise([70, 215, 235], 20);
      ctx.strokeStyle = '#06b6d4';
      ctx.strokeRect(1, 1, width - 2, height - 2);
      ctx.fillStyle = '#cffafe';
      ctx.fillRect(6, 6, 8, 8);
      break;

    case 'crafting_table_top':
      fillRandomNoise([180, 140, 95], 20);
      ctx.strokeStyle = '#5a3f25';
      ctx.strokeRect(4, 4, 11, 11);
      ctx.strokeRect(17, 4, 11, 11);
      ctx.strokeRect(4, 17, 11, 11);
      ctx.strokeRect(17, 17, 11, 11);
      break;

    case 'crafting_table_side':
      fillRandomNoise([140, 105, 70], 20);
      ctx.fillStyle = '#3a2512';
      ctx.fillRect(6, 8, 8, 16);
      ctx.fillRect(18, 12, 8, 12);
      break;

    case 'furnace_front':
      fillRandomNoise([120, 120, 120], 20);
      ctx.fillStyle = '#222222';
      ctx.fillRect(6, 12, 20, 14);
      ctx.fillStyle = '#f97316';
      ctx.fillRect(10, 18, 12, 6);
      break;

    case 'enderman_face':
      fillRandomNoise([10, 10, 14], 10);
      // Glowing purple eyes
      ctx.fillStyle = '#c084fc';
      ctx.fillRect(4, 14, 8, 3);
      ctx.fillRect(20, 14, 8, 3);
      ctx.fillStyle = '#f3e8ff';
      ctx.fillRect(6, 15, 3, 2);
      ctx.fillRect(22, 15, 3, 2);
      break;

    case 'blaze_face':
      fillRandomNoise([234, 88, 12], 25);
      // Glowing yellow/white eyes
      ctx.fillStyle = '#fef08a';
      ctx.fillRect(6, 12, 6, 3);
      ctx.fillRect(20, 12, 6, 3);
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(8, 13, 2, 2);
      ctx.fillRect(22, 13, 2, 2);
      break;

    case 'steve_face':
      fillRandomNoise([219, 162, 123], 15);
      ctx.fillStyle = '#4a2c11';
      ctx.fillRect(0, 0, width, 8); // hair
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(4, 14, 6, 3);
      ctx.fillRect(22, 14, 6, 3);
      ctx.fillStyle = '#2563eb'; // blue eyes
      ctx.fillRect(6, 14, 4, 3);
      ctx.fillRect(22, 14, 4, 3);
      ctx.fillStyle = '#8b5a36'; // beard/mouth
      ctx.fillRect(10, 22, 12, 3);
      break;

    default:
      fillRandomNoise([180, 180, 180], 15);
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.magFilter = THREE.NearestFilter;
  texture.minFilter = THREE.NearestFilter;
  return texture;
}

export function createBlockMaterials(): Record<number, THREE.Material | THREE.Material[]> {
  const t = {
    grass_top: createPixelTexture('grass_top'),
    grass_side: createPixelTexture('grass_side'),
    dirt: createPixelTexture('dirt'),
    stone: createPixelTexture('stone'),
    stone_bricks: createPixelTexture('stone_bricks'),
    mossy_stone_bricks: createPixelTexture('mossy_stone_bricks'),
    sand: createPixelTexture('sand'),
    snow_top: createPixelTexture('snow_top'),
    snow_side: createPixelTexture('snow_side'),
    ice: createPixelTexture('ice'),
    water: createPixelTexture('water'),
    cactus_side: createPixelTexture('cactus_side'),
    cactus_top: createPixelTexture('cactus_top'),
    oak_wood_side: createPixelTexture('oak_wood_side'),
    oak_wood_top: createPixelTexture('oak_wood_top'),
    oak_leaves: createPixelTexture('oak_leaves'),
    jungle_wood_side: createPixelTexture('jungle_wood_side'),
    jungle_leaves: createPixelTexture('jungle_leaves'),
    planks: createPixelTexture('planks'),
    obsidian: createPixelTexture('obsidian'),
    nether_portal: createPixelTexture('nether_portal'),
    end_portal_frame_top: createPixelTexture('end_portal_frame_top'),
    end_portal_frame_eye_top: createPixelTexture('end_portal_frame_eye_top'),
    end_portal_frame_side: createPixelTexture('end_portal_frame_side'),
    end_portal: createPixelTexture('end_portal'),
    netherrack: createPixelTexture('netherrack'),
    nether_bricks: createPixelTexture('nether_bricks'),
    warped_nylium_top: createPixelTexture('warped_nylium_top'),
    warped_stem_side: createPixelTexture('warped_stem_side'),
    warped_wart: createPixelTexture('warped_wart'),
    glowstone: createPixelTexture('glowstone'),
    end_stone: createPixelTexture('end_stone'),
    purpur_block: createPixelTexture('purpur_block'),
    diamond_ore: createPixelTexture('diamond_ore'),
    diamond_block: createPixelTexture('diamond_block'),
    crafting_table_top: createPixelTexture('crafting_table_top'),
    crafting_table_side: createPixelTexture('crafting_table_side'),
    furnace_front: createPixelTexture('furnace_front')
  };

  return {
    [BLOCKS.GRASS]: [
      new THREE.MeshLambertMaterial({ map: t.grass_side }),
      new THREE.MeshLambertMaterial({ map: t.grass_side }),
      new THREE.MeshLambertMaterial({ map: t.grass_top }),
      new THREE.MeshLambertMaterial({ map: t.dirt }),
      new THREE.MeshLambertMaterial({ map: t.grass_side }),
      new THREE.MeshLambertMaterial({ map: t.grass_side })
    ],
    [BLOCKS.DIRT]: new THREE.MeshLambertMaterial({ map: t.dirt }),
    [BLOCKS.STONE]: new THREE.MeshLambertMaterial({ map: t.stone }),
    [BLOCKS.STONE_BRICKS]: new THREE.MeshLambertMaterial({ map: t.stone_bricks }),
    [BLOCKS.MOSSY_STONE_BRICKS]: new THREE.MeshLambertMaterial({ map: t.mossy_stone_bricks }),
    [BLOCKS.SAND]: new THREE.MeshLambertMaterial({ map: t.sand }),
    [BLOCKS.SNOW]: [
      new THREE.MeshLambertMaterial({ map: t.snow_side }),
      new THREE.MeshLambertMaterial({ map: t.snow_side }),
      new THREE.MeshLambertMaterial({ map: t.snow_top }),
      new THREE.MeshLambertMaterial({ map: t.dirt }),
      new THREE.MeshLambertMaterial({ map: t.snow_side }),
      new THREE.MeshLambertMaterial({ map: t.snow_side })
    ],
    [BLOCKS.ICE]: new THREE.MeshLambertMaterial({
      map: t.ice,
      transparent: true,
      opacity: 0.8
    }),
    [BLOCKS.WATER]: new THREE.MeshLambertMaterial({
      map: t.water,
      transparent: true,
      opacity: 0.7
    }),
    [BLOCKS.CACTUS]: [
      new THREE.MeshLambertMaterial({ map: t.cactus_side }),
      new THREE.MeshLambertMaterial({ map: t.cactus_side }),
      new THREE.MeshLambertMaterial({ map: t.cactus_top }),
      new THREE.MeshLambertMaterial({ map: t.cactus_top }),
      new THREE.MeshLambertMaterial({ map: t.cactus_side }),
      new THREE.MeshLambertMaterial({ map: t.cactus_side })
    ],
    [BLOCKS.OAK_WOOD]: [
      new THREE.MeshLambertMaterial({ map: t.oak_wood_side }),
      new THREE.MeshLambertMaterial({ map: t.oak_wood_side }),
      new THREE.MeshLambertMaterial({ map: t.oak_wood_top }),
      new THREE.MeshLambertMaterial({ map: t.oak_wood_top }),
      new THREE.MeshLambertMaterial({ map: t.oak_wood_side }),
      new THREE.MeshLambertMaterial({ map: t.oak_wood_side })
    ],
    [BLOCKS.OAK_LEAVES]: new THREE.MeshLambertMaterial({
      map: t.oak_leaves,
      transparent: true,
      opacity: 0.92
    }),
    [BLOCKS.JUNGLE_WOOD]: [
      new THREE.MeshLambertMaterial({ map: t.jungle_wood_side }),
      new THREE.MeshLambertMaterial({ map: t.jungle_wood_side }),
      new THREE.MeshLambertMaterial({ map: t.oak_wood_top }),
      new THREE.MeshLambertMaterial({ map: t.oak_wood_top }),
      new THREE.MeshLambertMaterial({ map: t.jungle_wood_side }),
      new THREE.MeshLambertMaterial({ map: t.jungle_wood_side })
    ],
    [BLOCKS.JUNGLE_LEAVES]: new THREE.MeshLambertMaterial({
      map: t.jungle_leaves,
      transparent: true,
      opacity: 0.92
    }),
    [BLOCKS.PLANKS]: new THREE.MeshLambertMaterial({ map: t.planks }),
    [BLOCKS.COAL]: new THREE.MeshLambertMaterial({ map: t.stone }),
    [BLOCKS.IRON]: new THREE.MeshLambertMaterial({ map: t.stone }),
    [BLOCKS.DIAMOND_ORE]: new THREE.MeshLambertMaterial({ map: t.diamond_ore }),
    [BLOCKS.DIAMOND_BLOCK]: new THREE.MeshLambertMaterial({ map: t.diamond_block }),
    [BLOCKS.OBSIDIAN]: new THREE.MeshLambertMaterial({
      map: t.obsidian,
      roughness: 0.3
    } as THREE.MeshLambertMaterialParameters),
    [BLOCKS.NETHER_PORTAL]: new THREE.MeshBasicMaterial({
      map: t.nether_portal,
      transparent: true,
      opacity: 0.85
    }),
    [BLOCKS.END_PORTAL_FRAME]: [
      new THREE.MeshLambertMaterial({ map: t.end_portal_frame_side }),
      new THREE.MeshLambertMaterial({ map: t.end_portal_frame_side }),
      new THREE.MeshLambertMaterial({ map: t.end_portal_frame_top }),
      new THREE.MeshLambertMaterial({ map: t.end_stone }),
      new THREE.MeshLambertMaterial({ map: t.end_portal_frame_side }),
      new THREE.MeshLambertMaterial({ map: t.end_portal_frame_side })
    ],
    [BLOCKS.END_PORTAL_FRAME_EYE]: [
      new THREE.MeshLambertMaterial({ map: t.end_portal_frame_side }),
      new THREE.MeshLambertMaterial({ map: t.end_portal_frame_side }),
      new THREE.MeshLambertMaterial({ map: t.end_portal_frame_eye_top }),
      new THREE.MeshLambertMaterial({ map: t.end_stone }),
      new THREE.MeshLambertMaterial({ map: t.end_portal_frame_side }),
      new THREE.MeshLambertMaterial({ map: t.end_portal_frame_side })
    ],
    [BLOCKS.END_PORTAL]: new THREE.MeshBasicMaterial({
      map: t.end_portal,
      transparent: true,
      opacity: 0.95
    }),
    [BLOCKS.NETHERRACK]: new THREE.MeshLambertMaterial({ map: t.netherrack }),
    [BLOCKS.NETHER_BRICKS]: new THREE.MeshLambertMaterial({ map: t.nether_bricks }),
    [BLOCKS.WARPED_NYLIUM]: [
      new THREE.MeshLambertMaterial({ map: t.netherrack }),
      new THREE.MeshLambertMaterial({ map: t.netherrack }),
      new THREE.MeshLambertMaterial({ map: t.warped_nylium_top }),
      new THREE.MeshLambertMaterial({ map: t.netherrack }),
      new THREE.MeshLambertMaterial({ map: t.netherrack }),
      new THREE.MeshLambertMaterial({ map: t.netherrack })
    ],
    [BLOCKS.WARPED_STEM]: [
      new THREE.MeshLambertMaterial({ map: t.warped_stem_side }),
      new THREE.MeshLambertMaterial({ map: t.warped_stem_side }),
      new THREE.MeshLambertMaterial({ map: t.oak_wood_top }),
      new THREE.MeshLambertMaterial({ map: t.oak_wood_top }),
      new THREE.MeshLambertMaterial({ map: t.warped_stem_side }),
      new THREE.MeshLambertMaterial({ map: t.warped_stem_side })
    ],
    [BLOCKS.WARPED_WART]: new THREE.MeshLambertMaterial({
      map: t.warped_wart,
      transparent: true,
      opacity: 0.92
    }),
    [BLOCKS.GLOWSTONE]: new THREE.MeshBasicMaterial({
      map: t.glowstone
    }),
    [BLOCKS.END_STONE]: new THREE.MeshLambertMaterial({ map: t.end_stone }),
    [BLOCKS.PURPUR_BLOCK]: new THREE.MeshLambertMaterial({ map: t.purpur_block }),
    [BLOCKS.CRAFTING_TABLE]: [
      new THREE.MeshLambertMaterial({ map: t.crafting_table_side }),
      new THREE.MeshLambertMaterial({ map: t.crafting_table_side }),
      new THREE.MeshLambertMaterial({ map: t.crafting_table_top }),
      new THREE.MeshLambertMaterial({ map: t.planks }),
      new THREE.MeshLambertMaterial({ map: t.crafting_table_side }),
      new THREE.MeshLambertMaterial({ map: t.crafting_table_side })
    ],
    [BLOCKS.FURNACE]: [
      new THREE.MeshLambertMaterial({ map: t.stone }),
      new THREE.MeshLambertMaterial({ map: t.stone }),
      new THREE.MeshLambertMaterial({ map: t.stone }),
      new THREE.MeshLambertMaterial({ map: t.stone }),
      new THREE.MeshLambertMaterial({ map: t.furnace_front }),
      new THREE.MeshLambertMaterial({ map: t.stone })
    ]
  };
}
