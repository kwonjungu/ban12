import type { ZoneConfig } from './types';

export const STORAGE_KEY_BEST = 'infinite_stairs_best_score_v1';
export const STORAGE_KEY_MUTE = 'infinite_stairs_muted_v1';

export const STEP_WIDTH = 78;
export const STEP_HEIGHT = 40;

export const ZONES: ZoneConfig[] = [
  {
    id: 'day',
    minFloor: 0,
    label: '맑은 낮',
    rangeText: '0–49F',
    scrimTint: 'rgba(14, 116, 144, 0.14)',
  },
  {
    id: 'sunset',
    minFloor: 50,
    label: '황혼의 노을',
    rangeText: '50–119F',
    scrimTint: 'rgba(124, 45, 18, 0.18)',
  },
  {
    id: 'night',
    minFloor: 120,
    label: '깊은 밤',
    rangeText: '120–219F',
    scrimTint: 'rgba(15, 23, 42, 0.25)',
  },
  {
    id: 'space',
    minFloor: 220,
    label: '은하수 우주',
    rangeText: '220F+',
    scrimTint: 'rgba(2, 6, 23, 0.28)',
  },
];

export function getZoneState(score: number): {
  current: ZoneConfig;
  next: ZoneConfig;
  blend: number;
} {
  let idx = 0;
  for (let i = ZONES.length - 1; i >= 0; i--) {
    if (score >= ZONES[i].minFloor) {
      idx = i;
      break;
    }
  }
  const current = ZONES[idx];
  const next = ZONES[Math.min(idx + 1, ZONES.length - 1)];

  let blend = 0;
  if (idx < ZONES.length - 1) {
    const span = next.minFloor - current.minFloor;
    const progress = score - current.minFloor;
    if (progress > span - 25) {
      blend = Math.min(1, Math.max(0, (progress - (span - 25)) / 25));
    }
  }

  return { current, next, blend };
}
