import bgDayUrl from '../assets/images/bg_zone_day_1794636307981.jpg';
import bgSunsetUrl from '../assets/images/bg_zone_sunset_1794636308806.jpg';
import bgNightUrl from '../assets/images/bg_zone_night_1794636309175.jpg';
import bgSpaceUrl from '../assets/images/bg_zone_space_1794636309872.jpg';
import stairNormalUrl from '../assets/images/stair_block_platform_1794636310364.jpg';
import stairMilestoneUrl from '../assets/images/stair_block_milestone_1794636310372.jpg';
import boxerGuardUrl from '../assets/images/boxer_sprite_guard_1794636310048.jpg';
import boxerPunchUrl from '../assets/images/boxer_sprite_punch_1794636311791.jpg';
import boxerKoUrl from '../assets/images/boxer_sprite_ko_1794636311533.jpg';
import fxBurstUrl from '../assets/images/fx_punch_burst_1794636312912.jpg';

export interface ProcessedSprite {
  canvas: HTMLCanvasElement;
  width: number;
  height: number;
  anchorX: number;
  dataUrl: string;
}

export interface GameAssets {
  backgrounds: {
    day: HTMLImageElement;
    sunset: HTMLImageElement;
    night: HTMLImageElement;
    space: HTMLImageElement;
  };
  stairs: {
    normal: ProcessedSprite;
    milestone: ProcessedSprite;
  };
  boxer: {
    guard: ProcessedSprite;
    punch: ProcessedSprite;
    ko: ProcessedSprite;
  };
  fx: {
    burst: ProcessedSprite;
  };
}

export const RAW_ASSET_URLS = {
  bgDayUrl,
  bgSunsetUrl,
  bgNightUrl,
  bgSpaceUrl,
  stairNormalUrl,
  stairMilestoneUrl,
  boxerGuardUrl,
  boxerPunchUrl,
  boxerKoUrl,
  fxBurstUrl,
};

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = (err) => reject(err);
    img.src = src;
  });
}

/**
 * Edge-seeded BFS flood-fill removes only the outer pure/near-white backdrop
 * while preserving bright interior highlights (white wrist tape, shoe soles, eyes).
 */
function extractCutoutSprite(img: HTMLImageElement, targetMaxDim: number): ProcessedSprite {
  const scale = Math.min(1, targetMaxDim / Math.max(img.naturalWidth, img.naturalHeight));
  const w = Math.max(1, Math.round(img.naturalWidth * scale));
  const h = Math.max(1, Math.round(img.naturalHeight * scale));

  const work = document.createElement('canvas');
  work.width = w;
  work.height = h;
  const ctx = work.getContext('2d', { willReadFrequently: true });
  if (!ctx) {
    return { canvas: work, width: w, height: h, anchorX: 0.5, dataUrl: '' };
  }

  ctx.drawImage(img, 0, 0, w, h);
  const imgData = ctx.getImageData(0, 0, w, h);
  const data = imgData.data;

  const total = w * h;
  const visited = new Uint8Array(total);
  const isBg = new Uint8Array(total);
  const queue = new Int32Array(total);
  let head = 0;
  let tail = 0;

  const isNearWhite = (idx: number): boolean => {
    const o = idx * 4;
    const r = data[o];
    const g = data[o + 1];
    const b = data[o + 2];
    const maxC = Math.max(r, g, b);
    const minC = Math.min(r, g, b);
    return minC >= 218 && maxC - minC <= 28;
  };

  const enqueue = (idx: number) => {
    if (!visited[idx] && isNearWhite(idx)) {
      visited[idx] = 1;
      isBg[idx] = 1;
      queue[tail++] = idx;
    }
  };

  for (let x = 0; x < w; x++) {
    enqueue(x);
    enqueue((h - 1) * w + x);
  }
  for (let y = 1; y < h - 1; y++) {
    enqueue(y * w);
    enqueue(y * w + (w - 1));
  }

  while (head < tail) {
    const cur = queue[head++];
    const cx = cur % w;
    const cy = (cur - cx) / w;

    if (cx > 0) enqueue(cur - 1);
    if (cx < w - 1) enqueue(cur + 1);
    if (cy > 0) enqueue(cur - w);
    if (cy < h - 1) enqueue(cur + w);
  }

  // Clear connected outer white pixels and softly defringe 1px edge halo
  for (let i = 0; i < total; i++) {
    if (isBg[i]) {
      data[i * 4 + 3] = 0;
    }
  }

  for (let y = 1; y < h - 1; y++) {
    for (let x = 1; x < w - 1; x++) {
      const idx = y * w + x;
      if (isBg[idx]) continue;

      const hasBgNeighbor =
        isBg[idx - 1] || isBg[idx + 1] || isBg[idx - w] || isBg[idx + w];

      if (hasBgNeighbor) {
        const o = idx * 4;
        const r = data[o];
        const g = data[o + 1];
        const b = data[o + 2];
        const lum = 0.299 * r + 0.587 * g + 0.114 * b;
        const sat = Math.max(r, g, b) - Math.min(r, g, b);
        if (lum > 185 && sat < 35) {
          const factor = Math.max(0, (245 - lum) / 60);
          data[o + 3] = Math.round(data[o + 3] * factor);
        }
      }
    }
  }

  ctx.putImageData(imgData, 0, 0);

  // Auto-trim transparent margins so foot/surface alignment is pixel-exact
  let minX = w;
  let minY = h;
  let maxX = -1;
  let maxY = -1;

  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const a = data[(y * w + x) * 4 + 3];
      if (a > 24) {
        if (x < minX) minX = x;
        if (x > maxX) maxX = x;
        if (y < minY) minY = y;
        if (y > maxY) maxY = y;
      }
    }
  }

  if (maxX < minX || maxY < minY) {
    return {
      canvas: work,
      width: w,
      height: h,
      anchorX: 0.5,
      dataUrl: work.toDataURL('image/png'),
    };
  }

  const pad = 2;
  const cropX = Math.max(0, minX - pad);
  const cropY = Math.max(0, minY - pad);
  const cropW = Math.min(w - cropX, maxX - minX + 1 + pad * 2);
  const cropH = Math.min(h - cropY, maxY - minY + 1 + pad * 2);

  // Compute torso/hip horizontal centroid (48%-72% of trimmed height) for stable stance anchoring
  const bandTop = cropY + Math.floor(cropH * 0.48);
  const bandBot = cropY + Math.floor(cropH * 0.72);
  let sumX = 0;
  let count = 0;
  for (let y = bandTop; y <= bandBot; y++) {
    for (let x = cropX; x < cropX + cropW; x++) {
      if (data[(y * w + x) * 4 + 3] > 60) {
        sumX += x - cropX;
        count++;
      }
    }
  }
  const anchorX = count > 0 ? sumX / count / cropW : 0.5;

  const trimmed = document.createElement('canvas');
  trimmed.width = cropW;
  trimmed.height = cropH;
  const tCtx = trimmed.getContext('2d');
  if (tCtx) {
    tCtx.drawImage(work, cropX, cropY, cropW, cropH, 0, 0, cropW, cropH);
  }

  return {
    canvas: trimmed,
    width: cropW,
    height: cropH,
    anchorX,
    dataUrl: trimmed.toDataURL('image/png'),
  };
}

/**
 * Extracts luminance-keyed burst graphics from pure pitch-black #000000 background.
 */
function extractBlackKeySprite(img: HTMLImageElement, targetMaxDim: number): ProcessedSprite {
  const scale = Math.min(1, targetMaxDim / Math.max(img.naturalWidth, img.naturalHeight));
  const w = Math.max(1, Math.round(img.naturalWidth * scale));
  const h = Math.max(1, Math.round(img.naturalHeight * scale));

  const work = document.createElement('canvas');
  work.width = w;
  work.height = h;
  const ctx = work.getContext('2d', { willReadFrequently: true });
  if (!ctx) {
    return { canvas: work, width: w, height: h, anchorX: 0.5, dataUrl: '' };
  }

  ctx.drawImage(img, 0, 0, w, h);
  const imgData = ctx.getImageData(0, 0, w, h);
  const data = imgData.data;

  for (let i = 0; i < data.length; i += 4) {
    const r = data[i];
    const g = data[i + 1];
    const b = data[i + 2];
    const peak = Math.max(r, g, b);
    if (peak < 18) {
      data[i + 3] = 0;
    } else {
      data[i + 3] = Math.min(255, Math.round(((peak - 18) / 210) * 255));
    }
  }

  ctx.putImageData(imgData, 0, 0);

  return {
    canvas: work,
    width: w,
    height: h,
    anchorX: 0.5,
    dataUrl: work.toDataURL('image/png'),
  };
}

let cachedAssetsPromise: Promise<GameAssets> | null = null;

export function loadGameAssets(): Promise<GameAssets> {
  if (cachedAssetsPromise) return cachedAssetsPromise;

  cachedAssetsPromise = Promise.all([
    loadImage(bgDayUrl),
    loadImage(bgSunsetUrl),
    loadImage(bgNightUrl),
    loadImage(bgSpaceUrl),
    loadImage(stairNormalUrl),
    loadImage(stairMilestoneUrl),
    loadImage(boxerGuardUrl),
    loadImage(boxerPunchUrl),
    loadImage(boxerKoUrl),
    loadImage(fxBurstUrl),
  ]).then(
    ([
      day,
      sunset,
      night,
      space,
      stairNormal,
      stairMilestone,
      boxerGuard,
      boxerPunch,
      boxerKo,
      fxBurst,
    ]) => ({
      backgrounds: { day, sunset, night, space },
      stairs: {
        normal: extractCutoutSprite(stairNormal, 320),
        milestone: extractCutoutSprite(stairMilestone, 320),
      },
      boxer: {
        guard: extractCutoutSprite(boxerGuard, 420),
        punch: extractCutoutSprite(boxerPunch, 420),
        ko: extractCutoutSprite(boxerKo, 420),
      },
      fx: {
        burst: extractBlackKeySprite(fxBurst, 320),
      },
    })
  );

  return cachedAssetsPromise;
}
