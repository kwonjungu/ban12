export type GameState = 'TITLE_MENU' | 'PLAYING' | 'PAUSED' | 'FALLING' | 'GAME_OVER';

export type ActionType = 'CLIMB' | 'TURN';

export type ZoneId = 'day' | 'sunset' | 'night' | 'space';

export interface ZoneConfig {
  id: ZoneId;
  minFloor: number;
  label: string;
  rangeText: string;
  scrimTint: string;
}

export interface Stair {
  index: number;
  x: number;
  y: number;
  dirFromPrev: 1 | -1;
  nextDir: 1 | -1;
  highlight: number;
  isMilestone: boolean;
}

export interface PlayerState {
  stepIndex: number;
  x: number;
  y: number;
  dir: 1 | -1;
  bounce: number;
  scaleX: number;
  scaleY: number;
  vy: number;
  rotation: number;
  punchProgress: number;
  punchHand: 1 | -1;
}

export interface CameraState {
  x: number;
  y: number;
  shake: number;
}

export interface SpriteBurst {
  x: number;
  y: number;
  scale: number;
  maxScale: number;
  rotation: number;
  alpha: number;
  tint: 'gold' | 'cyan';
}

export interface StepDustParticle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  alpha: number;
  rotation: number;
  vRot: number;
}

export interface FloatingText {
  x: number;
  y: number;
  vy: number;
  alpha: number;
  text: string;
  color: string;
  size: number;
}
