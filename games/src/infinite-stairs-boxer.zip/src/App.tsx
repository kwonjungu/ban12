/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { GameStage } from './components/GameStage';

export default function App() {
  return <GameStage />;
}
