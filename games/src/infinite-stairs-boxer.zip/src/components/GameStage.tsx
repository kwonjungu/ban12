import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  ArrowLeftRight,
  ArrowUp,
  Crown,
  Pause,
  Play,
  RotateCcw,
  Trophy,
  Volume2,
  VolumeX,
  Zap,
} from 'lucide-react';
import { loadGameAssets, type GameAssets, type ProcessedSprite } from '../game/assets';
import { getZoneState, STEP_HEIGHT, STEP_WIDTH, STORAGE_KEY_BEST } from '../game/constants';
import { SoundEffects } from '../game/sound';
import type {
  ActionType,
  CameraState,
  FloatingText,
  GameState,
  PlayerState,
  SpriteBurst,
  Stair,
  StepDustParticle,
  ZoneConfig,
} from '../game/types';

interface EngineState {
  gameState: GameState;
  stairs: Stair[];
  score: number;
  bestScore: number;
  energy: number;
  player: PlayerState;
  camera: CameraState;
  bursts: SpriteBurst[];
  dust: StepDustParticle[];
  floatingTexts: FloatingText[];
  gameoverReason: string;
  isNewRecord: boolean;
}

interface UiSnapshot {
  gameState: GameState;
  score: number;
  bestScore: number;
  zone: ZoneConfig;
  isLowEnergy: boolean;
  isSpeedBoost: boolean;
  gameoverReason: string;
  isNewRecord: boolean;
}

function readStoredBest(): number {
  try {
    const val = parseInt(localStorage.getItem(STORAGE_KEY_BEST) || '0', 10);
    return Number.isFinite(val) && val > 0 ? val : 0;
  } catch {
    return 0;
  }
}

function saveStoredBest(val: number): void {
  try {
    localStorage.setItem(STORAGE_KEY_BEST, String(val));
  } catch {
    // Ignore storage quota errors
  }
}

function createInitialStairs(): Stair[] {
  const list: Stair[] = [
    {
      index: 0,
      x: 0,
      y: 0,
      dirFromPrev: 1,
      nextDir: 1,
      highlight: 0,
      isMilestone: true,
    },
  ];
  for (let i = 0; i < 42; i++) {
    appendNextStair(list);
  }
  return list;
}

function appendNextStair(list: Stair[]): void {
  const last = list[list.length - 1];
  let nextDir: 1 | -1 = last.nextDir;
  if (list.length > 2 && Math.random() < 0.34) {
    nextDir = (nextDir * -1) as 1 | -1;
  }
  const index = last.index + 1;
  list.push({
    index,
    x: last.x + nextDir * STEP_WIDTH,
    y: last.y - STEP_HEIGHT,
    dirFromPrev: nextDir,
    nextDir,
    highlight: 0,
    isMilestone: index % 10 === 0,
  });
}

function createFreshEngine(bestScore: number, gameState: GameState): EngineState {
  const stairs = createInitialStairs();
  const firstStepDir = stairs[1].dirFromPrev;
  return {
    gameState,
    stairs,
    score: 0,
    bestScore,
    energy: 100,
    player: {
      stepIndex: 0,
      x: 0,
      y: 0,
      dir: firstStepDir,
      bounce: 0,
      scaleX: 1,
      scaleY: 1,
      vy: 0,
      rotation: 0,
      punchProgress: 0,
      punchHand: 1,
    },
    camera: {
      x: 0,
      y: -55,
      shake: 0,
    },
    bursts: [],
    dust: [],
    floatingTexts: [],
    gameoverReason: '',
    isNewRecord: false,
  };
}

function drawCoverImage(
  ctx: CanvasRenderingContext2D,
  img: HTMLImageElement,
  w: number,
  h: number,
  camX: number,
  camY: number,
  alpha: number
): void {
  if (!img.complete || img.naturalWidth === 0 || alpha <= 0) return;

  const overscan = 1.14;
  const imgRatio = img.naturalWidth / img.naturalHeight;
  const viewRatio = w / h;

  let drawW: number;
  let drawH: number;

  if (viewRatio > imgRatio) {
    drawW = w * overscan;
    drawH = drawW / imgRatio;
  } else {
    drawH = h * overscan;
    drawW = drawH * imgRatio;
  }

  const maxShiftX = Math.max(0, (drawW - w) * 0.45);
  const maxShiftY = Math.max(0, (drawH - h) * 0.45);
  const offsetX = Math.max(-maxShiftX, Math.min(maxShiftX, -camX * 0.035));
  const offsetY = Math.max(-maxShiftY, Math.min(maxShiftY, -camY * 0.025));

  const x = (w - drawW) / 2 + offsetX;
  const y = (h - drawH) / 2 + offsetY;

  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.drawImage(img, x, y, drawW, drawH);
  ctx.restore();
}

export const GameStage: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const energyFillRef = useRef<HTMLDivElement | null>(null);
  const energyPctRef = useRef<HTMLSpanElement | null>(null);
  const turnBtnRef = useRef<HTMLButtonElement | null>(null);
  const climbBtnRef = useRef<HTMLButtonElement | null>(null);

  const soundRef = useRef<SoundEffects | null>(null);
  if (!soundRef.current) {
    soundRef.current = new SoundEffects();
  }

  const assetsRef = useRef<GameAssets | null>(null);
  const engineRef = useRef<EngineState>(createFreshEngine(readStoredBest(), 'TITLE_MENU'));
  const gameoverTimerRef = useRef<number | null>(null);

  const [assets, setAssets] = useState<GameAssets | null>(null);
  const [isMuted, setIsMuted] = useState<boolean>(() => soundRef.current?.isMuted() ?? false);
  const [spriteFallbackError, setSpriteFallbackError] = useState<boolean>(false);
  const [ui, setUi] = useState<UiSnapshot>(() => ({
    gameState: 'TITLE_MENU',
    score: 0,
    bestScore: engineRef.current.bestScore,
    zone: getZoneState(0).current,
    isLowEnergy: false,
    isSpeedBoost: false,
    gameoverReason: '',
    isNewRecord: false,
  }));

  const syncUiFromEngine = useCallback(() => {
    const eng = engineRef.current;
    const zoneState = getZoneState(eng.score);
    setUi({
      gameState: eng.gameState,
      score: eng.score,
      bestScore: eng.bestScore,
      zone: zoneState.current,
      isLowEnergy: eng.energy < 30,
      isSpeedBoost: eng.score > 0 && eng.score % 50 < 4,
      gameoverReason: eng.gameoverReason,
      isNewRecord: eng.isNewRecord,
    });
  }, []);

  const syncEnergyDom = useCallback((energy: number) => {
    const clamped = Math.max(0, Math.min(100, energy));
    if (energyFillRef.current) {
      energyFillRef.current.style.width = `${clamped.toFixed(1)}%`;
    }
    if (energyPctRef.current) {
      energyPctRef.current.textContent = `${Math.ceil(clamped)}%`;
    }
  }, []);

  const flashButton = useCallback((btn: HTMLButtonElement | null) => {
    if (!btn) return;
    btn.classList.add('is-pressed');
    window.setTimeout(() => {
      btn.classList.remove('is-pressed');
    }, 90);
  }, []);

  const startGame = useCallback(() => {
    if (gameoverTimerRef.current !== null) {
      window.clearTimeout(gameoverTimerRef.current);
      gameoverTimerRef.current = null;
    }
    soundRef.current?.init();
    const currentBest = Math.max(engineRef.current.bestScore, readStoredBest());
    engineRef.current = createFreshEngine(currentBest, 'PLAYING');
    syncEnergyDom(100);
    syncUiFromEngine();
  }, [syncEnergyDom, syncUiFromEngine]);

  const togglePause = useCallback(() => {
    const eng = engineRef.current;
    if (eng.gameState === 'PLAYING') {
      eng.gameState = 'PAUSED';
      syncUiFromEngine();
    } else if (eng.gameState === 'PAUSED') {
      eng.gameState = 'PLAYING';
      syncUiFromEngine();
    }
  }, [syncUiFromEngine]);

  const triggerGameOver = useCallback(
    (reason: string) => {
      const eng = engineRef.current;
      if (eng.gameState === 'FALLING' || eng.gameState === 'GAME_OVER') return;
      eng.gameState = 'FALLING';
      eng.gameoverReason = reason;
      eng.isNewRecord = eng.score > 0 && eng.score >= eng.bestScore;
      eng.camera.shake = 14;
      soundRef.current?.playGameOver();
      syncUiFromEngine();

      if (gameoverTimerRef.current !== null) {
        window.clearTimeout(gameoverTimerRef.current);
      }
      gameoverTimerRef.current = window.setTimeout(() => {
        gameoverTimerRef.current = null;
        engineRef.current.gameState = 'GAME_OVER';
        syncUiFromEngine();
      }, 580);
    },
    [syncUiFromEngine]
  );

  const handleAction = useCallback(
    (action: ActionType) => {
      const eng = engineRef.current;
      if (eng.gameState !== 'PLAYING') return;

      if (action === 'TURN') {
        eng.player.dir = (eng.player.dir * -1) as 1 | -1;
      }

      const nextIndex = eng.player.stepIndex + 1;
      const targetStair = eng.stairs[nextIndex];
      const targetX = eng.player.x + eng.player.dir * STEP_WIDTH;
      const targetY = eng.player.y - STEP_HEIGHT;

      if (targetStair && Math.abs(targetStair.x - targetX) < 1) {
        eng.player.stepIndex = nextIndex;
        eng.player.x = targetStair.x;
        eng.player.y = targetStair.y;
        eng.player.bounce = 15;
        eng.player.scaleX = 1.16;
        eng.player.scaleY = 0.86;
        eng.player.punchProgress = 1;
        eng.player.punchHand = (eng.player.punchHand * -1) as 1 | -1;
        targetStair.highlight = 1;

        eng.score += 1;
        const recover = Math.max(9.5, 16 - Math.floor(eng.score / 40));
        eng.energy = Math.min(100, eng.energy + recover);
        syncEnergyDom(eng.energy);

        // Spawn punch starburst FX using generated fx_punch_burst asset
        eng.bursts.push({
          x: eng.player.x + eng.player.dir * 38,
          y: eng.player.y - 54,
          scale: 0.28,
          maxScale: eng.score % 50 === 0 ? 1.55 : 0.72,
          rotation: Math.random() * Math.PI * 2,
          alpha: 1,
          tint: eng.score % 50 === 0 ? 'gold' : 'cyan',
        });

        // Footwork dash sparks
        for (let i = 0; i < 4; i++) {
          eng.dust.push({
            x: eng.player.x + (Math.random() - 0.5) * 24,
            y: eng.player.y - 2,
            vx: -eng.player.dir * (Math.random() * 2.2 + 0.6) + (Math.random() - 0.5) * 1.2,
            vy: -Math.random() * 2.1 - 0.4,
            size: Math.random() * 10 + 7,
            alpha: 0.85,
            rotation: Math.random() * Math.PI * 2,
            vRot: (Math.random() - 0.5) * 0.28,
          });
        }

        if (eng.score % 50 === 0) {
          soundRef.current?.playMilestone();
          eng.camera.shake = 7;
          eng.floatingTexts.push({
            x: eng.player.x,
            y: eng.player.y - 102,
            vy: -1.4,
            alpha: 1,
            text: `${eng.score}F CHAMPION!`,
            color: '#fde047',
            size: 24,
          });
        } else {
          if (action === 'TURN') {
            soundRef.current?.playTurn();
          } else {
            soundRef.current?.playClimb();
          }

          if (eng.score % 10 === 0) {
            eng.floatingTexts.push({
              x: eng.player.x,
              y: eng.player.y - 96,
              vy: -1.5,
              alpha: 1,
              text: `${eng.score}F`,
              color: '#67e8f9',
              size: 19,
            });
          } else {
            const label =
              action === 'TURN'
                ? 'HOOK!'
                : eng.player.punchHand === 1
                  ? 'JAB!'
                  : 'STRAIGHT!';
            eng.floatingTexts.push({
              x: eng.player.x + eng.player.dir * 14,
              y: eng.player.y - 90,
              vy: -1.6,
              alpha: 1,
              text: label,
              color: '#fef08a',
              size: 14,
            });
          }
        }

        while (eng.stairs.length - eng.player.stepIndex < 36) {
          appendNextStair(eng.stairs);
        }

        if (eng.score > eng.bestScore) {
          eng.bestScore = eng.score;
          saveStoredBest(eng.bestScore);
        }

        syncUiFromEngine();
      } else {
        eng.player.x = targetX;
        eng.player.y = targetY;
        eng.player.vy = -4.5;
        triggerGameOver('발을 헛디뎠습니다!');
      }
    },
    [syncEnergyDom, syncUiFromEngine, triggerGameOver]
  );

  // Load generated image assets once
  useEffect(() => {
    let mounted = true;
    loadGameAssets()
      .then((loaded) => {
        if (!mounted) return;
        assetsRef.current = loaded;
        setAssets(loaded);
      })
      .catch(() => {
        // Fallback handled gracefully by canvas & img handlers
      });
    return () => {
      mounted = false;
    };
  }, []);

  // Auto-pause if user switches tabs mid-run
  useEffect(() => {
    const handleVisibility = () => {
      if (document.hidden && engineRef.current.gameState === 'PLAYING' && engineRef.current.score > 0) {
        engineRef.current.gameState = 'PAUSED';
        syncUiFromEngine();
      }
    };
    document.addEventListener('visibilitychange', handleVisibility);
    return () => document.removeEventListener('visibilitychange', handleVisibility);
  }, [syncUiFromEngine]);

  // Keyboard controls
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.repeat) return;

      const state = engineRef.current.gameState;

      if (state === 'TITLE_MENU' || state === 'GAME_OVER') {
        if (e.code === 'Space' || e.code === 'Enter') {
          e.preventDefault();
          startGame();
        }
        return;
      }

      if (state === 'PAUSED') {
        if (e.code === 'Space' || e.code === 'Enter' || e.code === 'Escape' || e.code === 'KeyP') {
          e.preventDefault();
          togglePause();
        }
        return;
      }

      if (state === 'PLAYING') {
        if (e.code === 'Escape' || e.code === 'KeyP') {
          e.preventDefault();
          togglePause();
          return;
        }
        if (
          e.code === 'Space' ||
          e.code === 'ArrowUp' ||
          e.code === 'KeyW' ||
          e.code === 'KeyX'
        ) {
          e.preventDefault();
          flashButton(climbBtnRef.current);
          handleAction('CLIMB');
          return;
        }
        if (
          e.code === 'ArrowLeft' ||
          e.code === 'ArrowRight' ||
          e.code === 'KeyZ' ||
          e.code === 'ShiftLeft' ||
          e.code === 'ShiftRight' ||
          e.code === 'KeyA' ||
          e.code === 'KeyD'
        ) {
          e.preventDefault();
          flashButton(turnBtnRef.current);
          handleAction('TURN');
        }
      }
    };

    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [flashButton, handleAction, startGame, togglePause]);

  // Main 60fps Canvas Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId = 0;
    let lastTs = 0;
    let lastLowState = false;

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2.5);
      canvas.width = Math.floor(window.innerWidth * dpr);
      canvas.height = Math.floor(window.innerHeight * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    resize();
    window.addEventListener('resize', resize);

    const drawStairSprite = (
      sprite: ProcessedSprite,
      st: Stair
    ) => {
      const targetW = STEP_WIDTH + 20;
      const ratio = sprite.height / sprite.width;
      const targetH = targetW * ratio;
      const pulse = st.highlight > 0 ? 1 + st.highlight * 0.06 : 1;
      const w = targetW * pulse;
      const h = targetH * pulse;

      const x = st.x - w / 2;
      // Anchor middle of top stone/gold slab at st.y so boxer boots stand squarely on surface
      const y = st.y - h * 0.22 - (h - targetH) / 2;

      if (st.highlight > 0.05) {
        ctx.save();
        ctx.globalCompositeOperation = 'lighter';
        ctx.globalAlpha = st.highlight * 0.35;
        ctx.drawImage(sprite.canvas, x - 3, y - 3, w + 6, h + 6);
        ctx.restore();
      }

      ctx.drawImage(sprite.canvas, x, y, w, h);

      if (st.index > 0 && st.isMilestone) {
        ctx.save();
        ctx.font = '800 11px "JetBrains Mono", monospace';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.lineWidth = 3;
        ctx.strokeStyle = 'rgba(2, 6, 23, 0.85)';
        const labelY = y + h * 0.68;
        ctx.strokeText(`${st.index}F`, st.x, labelY);
        ctx.fillStyle = '#fef08a';
        ctx.fillText(`${st.index}F`, st.x, labelY);
        ctx.restore();
      }
    };

    const drawBoxerSprite = (
      loadedAssets: GameAssets | null,
      eng: EngineState,
      nowMs: number
    ) => {
      const { player, gameState } = eng;
      const idleBob =
        gameState === 'PLAYING' || gameState === 'TITLE_MENU'
          ? Math.abs(Math.sin(nowMs * 0.009)) * 2.5
          : 0;

      ctx.save();
      ctx.translate(player.x, player.y - player.bounce - idleBob);
      ctx.rotate(player.rotation);
      ctx.scale(player.dir * player.scaleX, player.scaleY);

      if (player.bounce < 12 && gameState !== 'FALLING' && gameState !== 'GAME_OVER') {
        ctx.fillStyle = 'rgba(2, 6, 23, 0.32)';
        ctx.beginPath();
        ctx.ellipse(0, player.bounce + idleBob + 2, 22, 5.5, 0, 0, Math.PI * 2);
        ctx.fill();
      }

      if (loadedAssets) {
        let sprite = loadedAssets.boxer.guard;
        if (gameState === 'FALLING' || gameState === 'GAME_OVER') {
          sprite = loadedAssets.boxer.ko;
        } else if (player.punchProgress > 0.12) {
          sprite = loadedAssets.boxer.punch;
        }

        const targetH = 104;
        const targetW = (sprite.width / sprite.height) * targetH;
        // Align torso/stance centroid with stair center and boot soles cleanly onto slab surface
        ctx.drawImage(sprite.canvas, -targetW * sprite.anchorX, -targetH + 5, targetW, targetH);
      } else {
        // Brief loading placeholder silhouette while images decode
        ctx.fillStyle = 'rgba(248, 250, 252, 0.7)';
        ctx.beginPath();
        ctx.roundRect(-14, -64, 28, 64, 8);
        ctx.fill();
      }

      ctx.restore();
    };

    const frame = (ts: number) => {
      if (!lastTs) lastTs = ts;
      const dt = Math.min(0.05, (ts - lastTs) / 1000);
      lastTs = ts;

      const eng = engineRef.current;

      // Update simulation when not paused
      if (eng.gameState !== 'PAUSED') {
        if (eng.gameState === 'PLAYING' && eng.score > 0) {
          const drainRate = 15 + Math.min(34, eng.score * 0.14);
          eng.energy -= drainRate * dt;

          if (eng.energy <= 0) {
            eng.energy = 0;
            eng.player.vy = -2;
            syncEnergyDom(0);
            triggerGameOver('시간이 초과되었습니다!');
          } else {
            syncEnergyDom(eng.energy);
            const nowLow = eng.energy < 30;
            if (nowLow !== lastLowState) {
              lastLowState = nowLow;
              syncUiFromEngine();
            }
          }
        } else {
          lastLowState = false;
        }

        if (eng.gameState === 'PLAYING' || eng.gameState === 'TITLE_MENU') {
          eng.player.bounce *= Math.pow(0.001, dt);
          eng.player.scaleX += (1 - eng.player.scaleX) * Math.min(1, dt * 18);
          eng.player.scaleY += (1 - eng.player.scaleY) * Math.min(1, dt * 18);
          eng.player.punchProgress = Math.max(0, eng.player.punchProgress - dt * 6.5);
        } else if (eng.gameState === 'FALLING') {
          eng.player.vy += 34 * dt;
          eng.player.y += eng.player.vy;
          eng.player.rotation += eng.player.dir * 7.5 * dt;
        }

        if (eng.gameState !== 'FALLING' && eng.gameState !== 'GAME_OVER') {
          const targetCamX = eng.player.x;
          const targetCamY = eng.player.y - 52;
          eng.camera.x += (targetCamX - eng.camera.x) * Math.min(1, dt * 12);
          eng.camera.y += (targetCamY - eng.camera.y) * Math.min(1, dt * 12);
        }

        if (eng.camera.shake > 0) {
          eng.camera.shake *= Math.pow(0.001, dt);
          if (eng.camera.shake < 0.2) eng.camera.shake = 0;
        }

        for (let i = Math.max(0, eng.player.stepIndex - 12); i < eng.stairs.length; i++) {
          if (eng.stairs[i].highlight > 0) {
            eng.stairs[i].highlight = Math.max(0, eng.stairs[i].highlight - dt * 3.5);
          }
        }

        for (let i = eng.bursts.length - 1; i >= 0; i--) {
          const b = eng.bursts[i];
          b.scale += (b.maxScale - b.scale) * Math.min(1, dt * 18);
          b.alpha -= dt * 4.4;
          if (b.alpha <= 0) eng.bursts.splice(i, 1);
        }

        for (let i = eng.dust.length - 1; i >= 0; i--) {
          const d = eng.dust[i];
          d.x += d.vx;
          d.y += d.vy;
          d.vy += 0.14;
          d.rotation += d.vRot;
          d.alpha -= dt * 3.4;
          if (d.alpha <= 0) eng.dust.splice(i, 1);
        }

        for (let i = eng.floatingTexts.length - 1; i >= 0; i--) {
          const ft = eng.floatingTexts[i];
          ft.y += ft.vy;
          ft.alpha -= dt * 1.65;
          if (ft.alpha <= 0) eng.floatingTexts.splice(i, 1);
        }
      }

      // Render frame
      const w = window.innerWidth;
      const h = window.innerHeight;
      const loadedAssets = assetsRef.current;
      const zoneState = getZoneState(eng.score);

      ctx.clearRect(0, 0, w, h);

      // 1. Generated Parallax Zone Backdrops with crossfade transition
      if (loadedAssets) {
        const currentBg = loadedAssets.backgrounds[zoneState.current.id];
        const nextBg = loadedAssets.backgrounds[zoneState.next.id];
        drawCoverImage(ctx, currentBg, w, h, eng.camera.x, eng.camera.y, 1);
        if (zoneState.blend > 0 && zoneState.next.id !== zoneState.current.id) {
          drawCoverImage(ctx, nextBg, w, h, eng.camera.x, eng.camera.y, zoneState.blend);
        }
      } else {
        const grad = ctx.createLinearGradient(0, 0, 0, h);
        grad.addColorStop(0, '#0f172a');
        grad.addColorStop(1, '#1e293b');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, w, h);
      }

      // Measured atmospheric scrim for HUD/stair legibility across bright & dark zones
      const topScrim = ctx.createLinearGradient(0, 0, 0, h * 0.34);
      topScrim.addColorStop(0, 'rgba(2, 6, 23, 0.62)');
      topScrim.addColorStop(1, 'rgba(2, 6, 23, 0)');
      ctx.fillStyle = topScrim;
      ctx.fillRect(0, 0, w, h * 0.34);

      const bottomScrim = ctx.createLinearGradient(0, h * 0.68, 0, h);
      bottomScrim.addColorStop(0, 'rgba(2, 6, 23, 0)');
      bottomScrim.addColorStop(1, 'rgba(2, 6, 23, 0.68)');
      ctx.fillStyle = bottomScrim;
      ctx.fillRect(0, h * 0.68, w, h * 0.32);

      // 2. Responsive world camera transform
      const worldScale = Math.max(0.84, Math.min(1.25, Math.min(w / 440, h / 740)));
      const shakeX = eng.camera.shake > 0 ? (Math.random() - 0.5) * eng.camera.shake : 0;
      const shakeY = eng.camera.shake > 0 ? (Math.random() - 0.5) * eng.camera.shake : 0;

      ctx.save();
      ctx.translate(w / 2 + shakeX, h * 0.61 + shakeY);
      ctx.scale(worldScale, worldScale);
      ctx.translate(-eng.camera.x, -eng.camera.y);

      // 3. Generated Stair Platform Sprites
      const startIdx = Math.max(0, eng.player.stepIndex - 14);
      const endIdx = Math.min(eng.stairs.length - 1, eng.player.stepIndex + 24);

      for (let i = startIdx; i <= endIdx; i++) {
        const st = eng.stairs[i];
        if (loadedAssets) {
          const sprite =
            st.index === 0 || st.isMilestone
              ? loadedAssets.stairs.milestone
              : loadedAssets.stairs.normal;
          drawStairSprite(sprite, st);
        } else {
          ctx.fillStyle = '#e2e8f0';
          ctx.beginPath();
          ctx.roundRect(st.x - STEP_WIDTH / 2, st.y, STEP_WIDTH, 16, 4);
          ctx.fill();
        }
      }

      // 4. Generated Boxer Character Sprite
      drawBoxerSprite(loadedAssets, eng, ts);

      // 5. Generated Impact Burst & Footwork Spark FX
      if (loadedAssets) {
        for (const b of eng.bursts) {
          ctx.save();
          ctx.globalCompositeOperation = 'lighter';
          ctx.globalAlpha = Math.max(0, b.alpha);
          ctx.translate(b.x, b.y);
          ctx.rotate(b.rotation);
          const size = 90 * b.scale;
          ctx.drawImage(loadedAssets.fx.burst.canvas, -size / 2, -size / 2, size, size);
          ctx.restore();
        }

        for (const d of eng.dust) {
          ctx.save();
          ctx.globalCompositeOperation = 'lighter';
          ctx.globalAlpha = Math.max(0, d.alpha * 0.72);
          ctx.translate(d.x, d.y);
          ctx.rotate(d.rotation);
          ctx.drawImage(loadedAssets.fx.burst.canvas, -d.size / 2, -d.size / 2, d.size, d.size);
          ctx.restore();
        }
      }

      // 6. Floating Combat/Milestone Callouts
      for (const ft of eng.floatingTexts) {
        ctx.save();
        ctx.globalAlpha = Math.max(0, ft.alpha);
        ctx.font = `800 ${ft.size}px "Do Hyeon", "Plus Jakarta Sans", sans-serif`;
        ctx.textAlign = 'center';
        ctx.lineWidth = 4;
        ctx.strokeStyle = 'rgba(2, 6, 23, 0.85)';
        ctx.strokeText(ft.text, ft.x, ft.y);
        ctx.fillStyle = ft.color;
        ctx.fillText(ft.text, ft.x, ft.y);
        ctx.restore();
      }

      ctx.restore();

      animId = window.requestAnimationFrame(frame);
    };

    animId = window.requestAnimationFrame(frame);
    return () => {
      window.cancelAnimationFrame(animId);
      window.removeEventListener('resize', resize);
      if (gameoverTimerRef.current !== null) {
        window.clearTimeout(gameoverTimerRef.current);
      }
    };
  }, [syncEnergyDom, syncUiFromEngine, triggerGameOver]);

  const handleToggleMute = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.currentTarget.blur();
    if (!soundRef.current) return;
    const nextMuted = soundRef.current.toggleMute();
    setIsMuted(nextMuted);
  };

  const titleHeroSrc = assets?.boxer.guard.dataUrl || '';
  const gameoverHeroSrc = ui.isNewRecord
    ? assets?.boxer.punch.dataUrl || ''
    : assets?.boxer.ko.dataUrl || '';
  const burstSrc = assets?.fx.burst.dataUrl || '';

  return (
    <div className="relative w-screen h-dvh overflow-hidden bg-slate-950 select-none flex flex-col justify-between">
      {/* Fullscreen High-DPI Game Canvas */}
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full block z-0" />

      {/* Top HUD Bar */}
      <header className="relative z-10 w-full max-w-3xl mx-auto px-4 pt-3 sm:pt-5 pointer-events-none flex flex-col items-center">
        <div className="w-full flex items-center justify-between gap-4">
          {/* Left: Best Score (Zero-pill clean typography) */}
          <div className="flex items-center gap-2 text-white drop-shadow-[0_2px_6px_rgba(0,0,0,0.75)]">
            <Crown className="w-4 h-4 sm:w-5 sm:h-5 text-amber-400 shrink-0" aria-hidden="true" />
            <span className="text-xs sm:text-sm font-semibold text-slate-200 whitespace-nowrap">
              최고 기록
            </span>
            <span className="font-mono-num text-base sm:text-lg font-extrabold text-amber-300 whitespace-nowrap">
              {ui.bestScore}F
            </span>
          </div>

          {/* Center: Current Atmosphere Zone (Unboxed metadata with · separator) */}
          <div className="hidden sm:flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-slate-100/95 drop-shadow-[0_2px_6px_rgba(0,0,0,0.8)] whitespace-nowrap">
            <span>{ui.zone.label}</span>
            <span aria-hidden="true" className="text-slate-400">
              ·
            </span>
            <span className="font-mono-num text-sky-200">{ui.zone.rangeText}</span>
          </div>

          {/* Right: Pause & Sound Controls */}
          <div className="flex items-center gap-2 pointer-events-auto shrink-0">
            {(ui.gameState === 'PLAYING' || ui.gameState === 'PAUSED') && (
              <button
                type="button"
                onClick={(e) => {
                  e.currentTarget.blur();
                  togglePause();
                }}
                className="w-11 h-11 sm:w-10 sm:h-10 rounded-xl bg-slate-900/65 hover:bg-slate-900/85 border border-white/20 text-white flex items-center justify-center backdrop-blur-md transition-transform active:scale-95 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400 cursor-pointer"
                aria-label={ui.gameState === 'PAUSED' ? '게임 계속하기' : '일시정지'}
              >
                {ui.gameState === 'PAUSED' ? (
                  <Play className="w-5 h-5" />
                ) : (
                  <Pause className="w-5 h-5" />
                )}
              </button>
            )}
            <button
              type="button"
              onClick={handleToggleMute}
              className="w-11 h-11 sm:w-10 sm:h-10 rounded-xl bg-slate-900/65 hover:bg-slate-900/85 border border-white/20 text-white flex items-center justify-center backdrop-blur-md transition-transform active:scale-95 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400 cursor-pointer"
              aria-label={isMuted ? '소리 켜기' : '소리 끄기'}
            >
              {isMuted ? (
                <VolumeX className="w-5 h-5 text-rose-300" />
              ) : (
                <Volume2 className="w-5 h-5 text-sky-200" />
              )}
            </button>
          </div>
        </div>

        {/* Central Elevation Counter */}
        <div className="mt-1 sm:mt-2 flex flex-col items-center">
          <div
            className="font-display font-mono-num text-5xl sm:text-6xl font-extrabold text-white tracking-tight drop-shadow-[0_4px_10px_rgba(2,6,23,0.85)] leading-none"
            aria-live="polite"
          >
            {ui.score}
          </div>
          <div className="h-5 mt-1 flex items-center justify-center">
            {ui.isSpeedBoost ? (
              <span className="text-xs sm:text-sm font-bold text-amber-300 drop-shadow-[0_2px_4px_rgba(0,0,0,0.85)] tracking-wide">
                스피드 업 · 페이스 상승
              </span>
            ) : (
              <span className="sm:hidden text-xs font-semibold text-slate-200/90 drop-shadow">
                {ui.zone.label} · {ui.zone.rangeText}
              </span>
            )}
          </div>
        </div>

        {/* Stamina Gauge with Non-Hue-Only State Label & Numeric Percentage */}
        <div className="w-full max-w-xs sm:max-w-sm mt-1">
          <div className="flex items-center justify-between text-xs font-bold mb-1 px-0.5 drop-shadow-[0_1px_4px_rgba(0,0,0,0.9)]">
            <span className="flex items-center gap-1 text-slate-100">
              <Zap
                className={`w-3.5 h-3.5 ${ui.isLowEnergy ? 'text-rose-400' : 'text-emerald-300'}`}
                aria-hidden="true"
              />
              <span>{ui.isLowEnergy ? '체력 위험' : '스태미나'}</span>
            </span>
            <span
              ref={energyPctRef}
              className={`font-mono-num ${ui.isLowEnergy ? 'text-rose-300' : 'text-slate-100'}`}
            >
              100%
            </span>
          </div>
          <div className="w-full h-4 sm:h-5 bg-slate-950/70 rounded-full p-0.5 border border-white/30 shadow-inner overflow-hidden backdrop-blur-sm">
            <div
              ref={energyFillRef}
              className={`h-full rounded-full transition-colors duration-150 ${
                ui.isLowEnergy
                  ? 'bg-gradient-to-r from-rose-600 to-orange-400'
                  : 'bg-gradient-to-r from-emerald-400 via-lime-400 to-amber-300'
              }`}
              style={{ width: '100%' }}
            />
          </div>
        </div>
      </header>

      {/* Bottom Arcade Controls */}
      <footer className="relative z-10 w-full max-w-xl mx-auto px-4 pt-2 pb-[max(1.25rem,env(safe-area-inset-bottom))] sm:pb-8 flex gap-3.5 sm:gap-6 justify-center items-end">
        <button
          ref={turnBtnRef}
          type="button"
          onPointerDown={(e) => {
            e.preventDefault();
            flashButton(turnBtnRef.current);
            handleAction('TURN');
          }}
          className="arcade-btn flex-1 max-w-[220px] h-20 sm:h-24 rounded-2xl bg-gradient-to-b from-amber-400 to-orange-600 border-2 border-amber-200/80 text-white flex flex-col items-center justify-center cursor-pointer focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-amber-300"
        >
          <div className="flex items-center gap-2 text-xl sm:text-2xl font-extrabold tracking-tight drop-shadow whitespace-nowrap">
            <ArrowLeftRight className="w-6 h-6 sm:w-7 sm:h-7 shrink-0" aria-hidden="true" />
            <span>방향전환</span>
          </div>
          <span className="font-mono-num text-[11px] sm:text-xs font-semibold text-amber-100/95 mt-1 whitespace-nowrap">
            ← / → / Z
          </span>
        </button>

        <button
          ref={climbBtnRef}
          type="button"
          onPointerDown={(e) => {
            e.preventDefault();
            flashButton(climbBtnRef.current);
            handleAction('CLIMB');
          }}
          className="arcade-btn flex-1 max-w-[220px] h-20 sm:h-24 rounded-2xl bg-gradient-to-b from-sky-400 to-blue-600 border-2 border-sky-200/80 text-white flex flex-col items-center justify-center cursor-pointer focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-sky-300"
        >
          <div className="flex items-center gap-2 text-xl sm:text-2xl font-extrabold tracking-tight drop-shadow whitespace-nowrap">
            <ArrowUp className="w-6 h-6 sm:w-7 sm:h-7 shrink-0" aria-hidden="true" />
            <span>오르기</span>
          </div>
          <span className="font-mono-num text-[11px] sm:text-xs font-semibold text-sky-100/95 mt-1 whitespace-nowrap">
            Space / ↑
          </span>
        </button>
      </footer>

      {/* Title Screen Modal */}
      {ui.gameState === 'TITLE_MENU' && (
        <div
          className="absolute inset-0 z-20 bg-slate-950/70 backdrop-blur-md flex items-center justify-center p-4 sm:p-6"
          role="dialog"
          aria-modal="true"
          aria-labelledby="title-heading"
        >
          <div className="w-full max-w-md max-h-[92dvh] overflow-y-auto bg-slate-900/90 border border-white/15 rounded-3xl p-5 sm:p-8 shadow-2xl text-center">
            <p className="text-xs font-bold tracking-widest text-amber-400 uppercase mb-2">
              Champion Boxer Edition
            </p>
            <h1
              id="title-heading"
              className="font-display text-5xl sm:text-6xl text-white tracking-wide drop-shadow-[0_4px_0_rgba(2,6,23,0.9)] text-balance"
            >
              무한의 계단
            </h1>
            <p className="text-sm sm:text-base text-slate-300 mt-2 mb-4 text-balance">
              챔피언 복서와 함께 리듬에 맞춰 끝없이 계단을 오르세요.
            </p>

            {/* Generated Character Key Visual Showcase */}
            <div className="relative h-36 sm:h-40 flex items-center justify-center mb-4">
              {!spriteFallbackError && titleHeroSrc ? (
                <>
                  {burstSrc && (
                    <img
                      src={burstSrc}
                      alt=""
                      aria-hidden="true"
                      referrerPolicy="no-referrer"
                      className="absolute w-36 h-36 object-contain opacity-45 mix-blend-screen pointer-events-none"
                    />
                  )}
                  <img
                    src={titleHeroSrc}
                    alt="챔피언 복서 캐릭터"
                    referrerPolicy="no-referrer"
                    onError={() => setSpriteFallbackError(true)}
                    className="relative h-36 sm:h-40 w-auto object-contain animate-float-slow drop-shadow-[0_12px_18px_rgba(2,6,23,0.85)]"
                  />
                </>
              ) : (
                <div className="w-28 h-28 rounded-2xl bg-slate-800/80 border border-white/10 flex items-center justify-center">
                  <Trophy className="w-12 h-12 text-amber-400" />
                </div>
              )}
            </div>

            {/* Best Score Summary */}
            <div className="flex items-center justify-between py-3 px-4 mb-5 border-y border-white/10">
              <span className="text-sm sm:text-base font-semibold text-slate-300 flex items-center gap-2">
                <Crown className="w-4 h-4 text-amber-400" aria-hidden="true" />
                챔피언 최고 기록
              </span>
              <span className="font-mono-num text-xl sm:text-2xl font-extrabold text-amber-300">
                {ui.bestScore}층
              </span>
            </div>

            {/* Control Instructions */}
            <div className="grid grid-cols-2 gap-3 mb-6 text-left">
              <div className="bg-slate-800/75 border border-amber-400/25 rounded-2xl p-3">
                <div className="text-amber-300 font-bold text-sm sm:text-base mb-1 flex items-center gap-1.5">
                  <ArrowLeftRight className="w-4 h-4 shrink-0" aria-hidden="true" />
                  <span>방향전환</span>
                </div>
                <p className="text-slate-300 text-xs leading-relaxed">
                  계단이 꺾일 때 방향을 바꾸며 한 칸 오릅니다.
                </p>
              </div>
              <div className="bg-slate-800/75 border border-sky-400/25 rounded-2xl p-3">
                <div className="text-sky-300 font-bold text-sm sm:text-base mb-1 flex items-center gap-1.5">
                  <ArrowUp className="w-4 h-4 shrink-0" aria-hidden="true" />
                  <span>오르기</span>
                </div>
                <p className="text-slate-300 text-xs leading-relaxed">
                  바라보는 방향으로 한 칸 위로 올라갑니다.
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={(e) => {
                e.currentTarget.blur();
                startGame();
              }}
              className="arcade-btn w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-emerald-400 to-teal-500 hover:from-emerald-300 hover:to-teal-400 border-2 border-emerald-200 text-slate-950 text-xl sm:text-2xl font-extrabold tracking-wide cursor-pointer whitespace-nowrap focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-emerald-300"
            >
              도전 시작
            </button>
          </div>
        </div>
      )}

      {/* Pause Modal */}
      {ui.gameState === 'PAUSED' && (
        <div
          className="absolute inset-0 z-30 bg-slate-950/75 backdrop-blur-md flex items-center justify-center p-4 sm:p-6"
          role="dialog"
          aria-modal="true"
          aria-labelledby="pause-heading"
        >
          <div className="w-full max-w-sm max-h-[92dvh] overflow-y-auto bg-slate-900/95 border border-white/15 rounded-3xl p-6 sm:p-8 shadow-2xl text-center">
            <h2 id="pause-heading" className="font-display text-3xl sm:text-4xl text-white mb-2">
              일시정지
            </h2>
            <p className="text-sm text-slate-300 mb-6">
              현재 도달 층수{' '}
              <span className="font-mono-num font-bold text-amber-300">{ui.score}층</span>
            </p>
            <div className="space-y-3">
              <button
                type="button"
                onClick={(e) => {
                  e.currentTarget.blur();
                  togglePause();
                }}
                className="arcade-btn w-full py-3.5 px-6 rounded-2xl bg-gradient-to-b from-sky-400 to-blue-600 border-2 border-sky-200 text-white text-lg font-extrabold cursor-pointer whitespace-nowrap focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-sky-300"
              >
                계속하기
              </button>
              <button
                type="button"
                onClick={(e) => {
                  e.currentTarget.blur();
                  startGame();
                }}
                className="w-full py-3 px-6 rounded-2xl bg-slate-800 hover:bg-slate-700 border border-white/15 text-slate-200 text-base font-bold cursor-pointer flex items-center justify-center gap-2 transition-colors whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"
              >
                <RotateCcw className="w-4 h-4" aria-hidden="true" />
                <span>처음부터 다시</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Game Over Modal */}
      {ui.gameState === 'GAME_OVER' && (
        <div
          className="absolute inset-0 z-30 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 sm:p-6"
          role="dialog"
          aria-modal="true"
          aria-labelledby="gameover-heading"
        >
          <div className="w-full max-w-sm max-h-[92dvh] overflow-y-auto bg-slate-900/95 border border-white/15 rounded-3xl p-6 sm:p-8 shadow-2xl text-center">
            <p className="text-sm font-bold text-rose-400 mb-1">{ui.gameoverReason}</p>
            <h2
              id="gameover-heading"
              className="font-display text-4xl sm:text-5xl text-white tracking-wide mb-3"
            >
              K.O. 게임 오버
            </h2>

            {ui.isNewRecord && (
              <div className="mb-3 text-sm font-extrabold text-amber-300 tracking-wide">
                신기록 달성 · NEW CHAMPION
              </div>
            )}

            {/* Generated Sprite Showcase for K.O. or New Record */}
            <div className="relative h-28 flex items-center justify-center mb-4">
              {!spriteFallbackError && gameoverHeroSrc ? (
                <>
                  {ui.isNewRecord && burstSrc && (
                    <img
                      src={burstSrc}
                      alt=""
                      aria-hidden="true"
                      referrerPolicy="no-referrer"
                      className="absolute w-32 h-32 object-contain opacity-60 mix-blend-screen pointer-events-none"
                    />
                  )}
                  <img
                    src={gameoverHeroSrc}
                    alt={ui.isNewRecord ? '신기록 달성 복서' : '녹다운 복서'}
                    referrerPolicy="no-referrer"
                    onError={() => setSpriteFallbackError(true)}
                    className="relative h-28 w-auto object-contain drop-shadow-[0_10px_14px_rgba(2,6,23,0.9)]"
                  />
                </>
              ) : (
                <Trophy className="w-12 h-12 text-amber-400" />
              )}
            </div>

            {/* Score Summary */}
            <div className="border-y border-white/10 py-3.5 mb-6 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-sm sm:text-base text-slate-400">도달 층수</span>
                <span className="font-mono-num text-3xl font-extrabold text-white">
                  {ui.score}층
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm sm:text-base text-slate-400">최고 기록</span>
                <span className="font-mono-num text-xl font-bold text-amber-300">
                  {ui.bestScore}층
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={(e) => {
                e.currentTarget.blur();
                startGame();
              }}
              className="arcade-btn w-full py-4 px-6 rounded-2xl bg-gradient-to-b from-rose-500 to-red-600 hover:from-rose-400 hover:to-red-500 border-2 border-rose-300/80 text-white text-xl sm:text-2xl font-extrabold tracking-wide cursor-pointer whitespace-nowrap focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-rose-300"
            >
              다시 하기
            </button>
            <p className="text-xs text-slate-400 mt-3">Space 또는 Enter 키로 바로 재시작</p>
          </div>
        </div>
      )}
    </div>
  );
};
