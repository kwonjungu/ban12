/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useCallback, useEffect, useRef, useState } from 'react';
import { FlightHud } from './components/FlightHud';
import {
  GameOverModal,
  PauseModal,
  StartOverlay,
  WorldTeleportModal,
} from './components/GameModals';
import { TouchControls } from './components/TouchControls';
import { ASSET_URLS } from './game/assets';
import { droneAudio } from './game/audio';
import { DroneEngine } from './game/DroneEngine';
import {
  CameraMode,
  GameMode,
  GamePhase,
  GameResult,
  HudTelemetry,
  INITIAL_TIME,
  ThemeId,
} from './game/types';

const BEST_SCORE_STORAGE_KEY = 'sky_drone_fpv_best_score_v1';

const INITIAL_TELEMETRY: HudTelemetry = {
  score: 0,
  ringsPassed: 0,
  timeLeft: INITIAL_TIME,
  speedKmh: 0,
  altitudeM: 25,
  boostEnergy: 100,
  targetDistanceM: 55,
  relativeTargetX: 0,
  relativeTargetZ: -55,
  isBoosting: false,
};

function readBestScore(): number {
  try {
    const raw = window.localStorage.getItem(BEST_SCORE_STORAGE_KEY);
    const parsed = raw ? Number.parseInt(raw, 10) : 0;
    return Number.isFinite(parsed) && parsed > 0 ? parsed : 0;
  } catch {
    return 0;
  }
}

export default function App() {
  const canvasMountRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<DroneEngine | null>(null);
  const toastTimerRef = useRef<number | null>(null);

  const [phase, setPhase] = useState<GamePhase>('start');
  const [mode, setMode] = useState<GameMode>('race');
  const [theme, setTheme] = useState<ThemeId>('cyber');
  const [cameraMode, setCameraMode] = useState<CameraMode>('third');
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [telemetry, setTelemetry] = useState<HudTelemetry>(INITIAL_TELEMETRY);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [gameResult, setGameResult] = useState<GameResult | null>(null);
  const [bestScore, setBestScore] = useState<number>(() => readBestScore());
  const [showTouchControls, setShowTouchControls] = useState<boolean>(false);
  const [webglLost, setWebglLost] = useState<boolean>(false);

  const phaseRef = useRef<GamePhase>(phase);
  const cameraModeRef = useRef<CameraMode>(cameraMode);
  const bestScoreRef = useRef<number>(bestScore);

  useEffect(() => {
    phaseRef.current = phase;
  }, [phase]);

  useEffect(() => {
    cameraModeRef.current = cameraMode;
  }, [cameraMode]);

  useEffect(() => {
    bestScoreRef.current = bestScore;
  }, [bestScore]);

  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    if (toastTimerRef.current !== null) {
      window.clearTimeout(toastTimerRef.current);
    }
    toastTimerRef.current = window.setTimeout(() => {
      setToastMessage(null);
    }, 1800);
  }, []);

  // Detect responsive mobile/touch viewport
  useEffect(() => {
    const evaluateTouch = () => {
      const hasTouch =
        'ontouchstart' in window || navigator.maxTouchPoints > 0;
      setShowTouchControls(hasTouch || window.innerWidth < 768);
    };
    evaluateTouch();
    window.addEventListener('resize', evaluateTouch);
    return () => window.removeEventListener('resize', evaluateTouch);
  }, []);

  // Initialize Three.js DroneEngine once inside isolated mount ref
  useEffect(() => {
    const mount = canvasMountRef.current;
    if (!mount) return;

    const engine = new DroneEngine(mount, {
      onTelemetry: (nextTelemetry) => {
        setTelemetry(nextTelemetry);
      },
      onToast: showToast,
      onGameOver: (result) => {
        const isNewBest = result.finalScore > bestScoreRef.current;
        if (isNewBest) {
          setBestScore(result.finalScore);
          try {
            window.localStorage.setItem(
              BEST_SCORE_STORAGE_KEY,
              String(result.finalScore),
            );
          } catch {
            // Ignore storage errors in restricted environments
          }
        }
        setGameResult({ ...result, isNewBest });
        setPhase('gameover');
      },
      onWebGLContextLost: (lost) => {
        setWebglLost(lost);
      },
    });

    engineRef.current = engine;

    return () => {
      if (toastTimerRef.current !== null) {
        window.clearTimeout(toastTimerRef.current);
      }
      engine.dispose();
      droneAudio.dispose();
      engineRef.current = null;
    };
  }, [showToast]);

  const handleStartGame = useCallback(async () => {
    await droneAudio.init();
    setGameResult(null);
    setPhase('playing');
    engineRef.current?.startNewGame(mode, theme);
  }, [mode, theme]);

  const handleSelectStartTheme = useCallback((nextTheme: ThemeId) => {
    setTheme(nextTheme);
    engineRef.current?.setTheme(nextTheme, false);
  }, []);

  const handleToggleCamera = useCallback(() => {
    const next: CameraMode = cameraModeRef.current === 'third' ? 'fpv' : 'third';
    setCameraMode(next);
    engineRef.current?.setCameraMode(next);
  }, []);

  const handleToggleSound = useCallback(() => {
    setSoundEnabled((prev) => {
      const next = !prev;
      droneAudio.setEnabled(next);
      return next;
    });
  }, []);

  const handleTogglePause = useCallback(() => {
    if (phaseRef.current === 'playing') {
      setPhase('paused');
      engineRef.current?.setPaused(true);
    } else if (phaseRef.current === 'paused') {
      setPhase('playing');
      engineRef.current?.setPaused(false);
    }
  }, []);

  const handleToggleThemeMenu = useCallback(() => {
    if (phaseRef.current === 'playing' || phaseRef.current === 'paused') {
      setPhase('theme');
      engineRef.current?.setPaused(true);
    } else if (phaseRef.current === 'theme') {
      setPhase('playing');
      engineRef.current?.setPaused(false);
    }
  }, []);

  const handleTeleportTheme = useCallback((nextTheme: ThemeId) => {
    setTheme(nextTheme);
    engineRef.current?.setTheme(nextTheme, true);
    setPhase('playing');
    engineRef.current?.setPaused(false);
  }, []);

  const handleBackToMenu = useCallback(() => {
    engineRef.current?.stopToMenu();
    setGameResult(null);
    setPhase('start');
  }, []);

  // Global keyboard flight & shortcut controls
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (
        e.code === 'Space' ||
        e.code === 'ArrowUp' ||
        e.code === 'ArrowDown' ||
        e.code === 'ArrowLeft' ||
        e.code === 'ArrowRight'
      ) {
        if (phaseRef.current === 'playing') {
          e.preventDefault();
        }
      }

      engineRef.current?.setKeyState(e.code, true);

      if (e.repeat) return;

      if (
        e.code === 'KeyT' &&
        (phaseRef.current === 'playing' ||
          phaseRef.current === 'paused' ||
          phaseRef.current === 'theme')
      ) {
        handleToggleThemeMenu();
        return;
      }

      if (e.code === 'KeyV' && phaseRef.current === 'playing') {
        engineRef.current?.triggerTrick();
        return;
      }

      if (e.code === 'KeyC' && phaseRef.current === 'playing') {
        handleToggleCamera();
        return;
      }

      if (e.code === 'KeyP' || e.code === 'Escape') {
        if (phaseRef.current === 'theme') {
          handleToggleThemeMenu();
        } else if (
          phaseRef.current === 'playing' ||
          phaseRef.current === 'paused'
        ) {
          handleTogglePause();
        }
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      engineRef.current?.setKeyState(e.code, false);
    };

    const onBlur = () => {
      [
        'KeyW',
        'KeyS',
        'KeyA',
        'KeyD',
        'ArrowUp',
        'ArrowDown',
        'ArrowLeft',
        'ArrowRight',
        'Space',
      ].forEach((k) => engineRef.current?.setKeyState(k, false));
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('blur', onBlur);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('blur', onBlur);
    };
  }, [handleToggleCamera, handleTogglePause, handleToggleThemeMenu]);

  return (
    <div className="relative w-full h-full overflow-hidden bg-[#060913]">
      {/* Isolated WebGL Mount Container */}
      <div
        ref={canvasMountRef}
        className="absolute inset-0 w-full h-full"
        aria-label="3D 스카이 드론 비행 뷰포트"
      />

      {/* WebGL Context Lost Fallback */}
      {webglLost && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/95 p-6">
          <div className="hud-panel-elevated max-w-md w-full rounded-2xl overflow-hidden text-center">
            <img
              src={ASSET_URLS.heroDroneArt}
              alt="Sky Drone Racing"
              referrerPolicy="no-referrer"
              className="w-full h-44 object-cover"
            />
            <div className="p-6">
              <h2 className="font-display text-xl font-bold text-white mb-2">
                그래픽 컨텍스트를 복구하는 중입니다
              </h2>
              <p className="text-sm text-slate-300">
                잠시 후 3D 화면이 자동으로 복원됩니다.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Active Flight HUD */}
      {(phase === 'playing' || phase === 'paused' || phase === 'theme') && (
        <FlightHud
          mode={mode}
          cameraMode={cameraMode}
          soundEnabled={soundEnabled}
          telemetry={telemetry}
          toastMessage={toastMessage}
          onOpenThemeMenu={handleToggleThemeMenu}
          onToggleCamera={handleToggleCamera}
          onToggleSound={handleToggleSound}
          onTogglePause={handleTogglePause}
        />
      )}

      {/* Mobile / Touch Dual Joysticks */}
      {phase === 'playing' && showTouchControls && (
        <TouchControls
          onLeftStick={(nx, ny) => engineRef.current?.setLeftJoystick(nx, ny)}
          onRightStick={(nx, ny) => engineRef.current?.setRightJoystick(nx, ny)}
          onBoostChange={(active) => engineRef.current?.setTouchBoost(active)}
          onTrick={() => engineRef.current?.triggerTrick()}
        />
      )}

      {/* Launch / Start Screen */}
      {phase === 'start' && (
        <StartOverlay
          mode={mode}
          selectedTheme={theme}
          bestScore={bestScore}
          onSelectMode={(nextMode) => {
            setMode(nextMode);
            engineRef.current?.setMode(nextMode);
          }}
          onSelectTheme={handleSelectStartTheme}
          onStart={handleStartGame}
        />
      )}

      {/* World Teleport Modal */}
      {phase === 'theme' && (
        <WorldTeleportModal
          currentTheme={theme}
          onSelectTheme={handleTeleportTheme}
          onClose={handleToggleThemeMenu}
        />
      )}

      {/* Pause Modal */}
      {phase === 'paused' && (
        <PauseModal
          onResume={handleTogglePause}
          onOpenThemeMenu={handleToggleThemeMenu}
          onRestart={handleStartGame}
        />
      )}

      {/* Mission Result Modal */}
      {phase === 'gameover' && gameResult && (
        <GameOverModal
          result={gameResult}
          onPlayAgain={handleStartGame}
          onBackToMenu={handleBackToMenu}
        />
      )}
    </div>
  );
}
