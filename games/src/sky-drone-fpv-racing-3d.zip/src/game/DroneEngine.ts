import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { ASSET_URLS, WORLD_THEMES } from './assets';
import { droneAudio } from './audio';
import {
  CameraMode,
  GameMode,
  GameResult,
  HudTelemetry,
  INITIAL_TIME,
  RING_TIME_BONUS,
  TOTAL_RINGS,
  ThemeId,
} from './types';

interface BuildingBounds {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
  maxY: number;
}

interface RingNode {
  mesh: THREE.Group;
  outerMat: THREE.MeshStandardMaterial;
  innerMat: THREE.MeshBasicMaterial;
  position: THREE.Vector3;
  passed: boolean;
}

interface BurstParticle {
  mesh: THREE.Mesh;
  vel: THREE.Vector3;
  life: number;
}

export interface EngineCallbacks {
  onTelemetry: (telemetry: HudTelemetry) => void;
  onToast: (message: string) => void;
  onGameOver: (result: GameResult) => void;
  onWebGLContextLost: (lost: boolean) => void;
}

const COURSE_WAYPOINTS: ReadonlyArray<readonly [number, number, number]> = [
  [0, 28, -55],
  [38, 36, -115],
  [90, 48, -165],
  [145, 34, -120],
  [175, 55, -45],
  [150, 72, 35],
  [95, 50, 95],
  [25, 32, 130],
  [-48, 46, 115],
  [-110, 68, 65],
  [-145, 42, -10],
  [-125, 30, -85],
  [-75, 58, -145],
  [-25, 76, -185],
  [0, 45, -245],
];

// Reusable math objects to avoid per-frame GC allocations
const _forwardDir = new THREE.Vector3();
const _rightDir = new THREE.Vector3();
const _accel = new THREE.Vector3();
const _prevPos = new THREE.Vector3();
const _fpvOffset = new THREE.Vector3();
const _lookForward = new THREE.Vector3();
const _chaseOffset = new THREE.Vector3();
const _desiredPos = new THREE.Vector3();
const _forwardTarget = new THREE.Vector3();
const _desiredLook = new THREE.Vector3();
const _yAxis = new THREE.Vector3(0, 1, 0);

function detectSoftwareWebGL(): boolean {
  try {
    const probeCanvas = document.createElement('canvas');
    const gl = probeCanvas.getContext('webgl2');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param));
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return true;
  }
}

export class DroneEngine {
  private container: HTMLElement;
  private callbacks: EngineCallbacks;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private isSoftwareGl: boolean;
  private textureLoader: THREE.TextureLoader;
  private textureCache = new Map<string, THREE.Texture>();
  private maxAnisotropy = 1;

  private hemiLight: THREE.HemisphereLight;
  private dirLight: THREE.DirectionalLight;
  private rimLight: THREE.DirectionalLight;
  private skyDome: THREE.Mesh;
  private skyDomeMat: THREE.MeshBasicMaterial;
  private envGroup = new THREE.Group();
  private droneGroup = new THREE.Group();
  private propellers: THREE.Group[] = [];
  private navArrow: THREE.Group | null = null;
  private boostFlameLeft: THREE.Mesh | null = null;
  private boostFlameRight: THREE.Mesh | null = null;

  private buildings: BuildingBounds[] = [];
  private rings: RingNode[] = [];
  private particles: BurstParticle[] = [];
  private particleGeo = new THREE.OctahedronGeometry(0.45, 0);
  private particleMaterials = new Map<number, THREE.MeshBasicMaterial>();

  private frameId = 0;
  private disposed = false;
  private lastTime = 0;
  private lastHudEmit = 0;

  // Game state
  private mode: GameMode = 'race';
  private theme: ThemeId = 'cyber';
  private cameraMode: CameraMode = 'third';
  private isPlaying = false;
  private isPaused = false;
  private score = 0;
  private ringsPassed = 0;
  private timeLeft = INITIAL_TIME;
  private boostEnergy = 100;

  // Physics state
  private position = new THREE.Vector3(0, 25, 0);
  private velocity = new THREE.Vector3(0, 0, 0);
  private yaw = 0;
  private pitch = 0;
  private roll = 0;
  private yawVelocity = 0;
  private isTricking = false;
  private trickType: 'roll' | 'flip' = 'roll';
  private trickDir = 1;
  private trickProgress = 0;

  private smoothCamPos = new THREE.Vector3(0, 30, 15);
  private smoothLookAt = new THREE.Vector3(0, 25, -20);

  // Inputs
  private keys: Record<string, boolean> = {};
  private joyThrottle = 0;
  private joyYaw = 0;
  private joyPitch = 0;
  private joyRoll = 0;
  private touchBoost = false;

  constructor(container: HTMLElement, callbacks: EngineCallbacks) {
    this.container = container;
    this.callbacks = callbacks;
    this.isSoftwareGl = detectSoftwareWebGL();

    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.08;
    this.renderer.setPixelRatio(
      this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio || 1, 2),
    );
    this.renderer.setSize(container.clientWidth || window.innerWidth, container.clientHeight || window.innerHeight);
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.domElement.style.display = 'block';
    this.renderer.domElement.style.width = '100%';
    this.renderer.domElement.style.height = '100%';

    container.appendChild(this.renderer.domElement);
    this.maxAnisotropy = Math.min(this.renderer.capabilities.getMaxAnisotropy(), 8);

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(WORLD_THEMES.cyber.fogColor);
    this.scene.fog = new THREE.FogExp2(WORLD_THEMES.cyber.fogColor, WORLD_THEMES.cyber.fogDensity);

    const aspect = (container.clientWidth || window.innerWidth) / (container.clientHeight || window.innerHeight);
    this.camera = new THREE.PerspectiveCamera(68, aspect, 0.1, 1400);

    // Studio reflection environment for carbon fiber, anodized aluminum & optical glass
    const pmremGenerator = new THREE.PMREMGenerator(this.renderer);
    const envTex = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    this.scene.environment = envTex;
    pmremGenerator.dispose();

    // 3-Point Sky & Key Lighting
    this.hemiLight = new THREE.HemisphereLight(0x7dd3fc, 0x1e293b, 1.05);
    this.scene.add(this.hemiLight);

    this.dirLight = new THREE.DirectionalLight(0xfde68a, 1.35);
    this.dirLight.position.set(120, 220, 100);
    this.dirLight.castShadow = !this.isSoftwareGl;
    this.dirLight.shadow.mapSize.width = 2048;
    this.dirLight.shadow.mapSize.height = 2048;
    this.dirLight.shadow.camera.near = 10;
    this.dirLight.shadow.camera.far = 600;
    this.dirLight.shadow.bias = -0.0005;
    this.dirLight.shadow.normalBias = 0.02;
    const d = 180;
    this.dirLight.shadow.camera.left = -d;
    this.dirLight.shadow.camera.right = d;
    this.dirLight.shadow.camera.top = d;
    this.dirLight.shadow.camera.bottom = -d;
    this.scene.add(this.dirLight);

    this.rimLight = new THREE.DirectionalLight(0x38bdf8, 0.45);
    this.rimLight.position.set(-140, 90, -160);
    this.scene.add(this.rimLight);

    // Panoramic Sky Dome (populated with generated skybox art)
    this.textureLoader = new THREE.TextureLoader();
    const skyGeo = new THREE.SphereGeometry(680, 48, 32, 0, Math.PI * 2, 0, Math.PI * 0.58);
    this.skyDomeMat = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      side: THREE.BackSide,
      fog: false,
      depthWrite: false,
    });
    this.skyDome = new THREE.Mesh(skyGeo, this.skyDomeMat);
    this.skyDome.position.set(0, -45, 0);
    this.skyDome.renderOrder = -10;
    this.scene.add(this.skyDome);

    this.scene.add(this.envGroup);

    // Preload all generated textures & build initial world + drone + rings
    this.preloadAssets();
    this.buildEnvironment('cyber');
    this.buildDrone();
    this.buildRings();

    if (!this.isSoftwareGl) {
      this.renderer.compile(this.scene, this.camera);
    }

    this.renderer.domElement.addEventListener('webglcontextlost', this.handleContextLost);
    this.renderer.domElement.addEventListener('webglcontextrestored', this.handleContextRestored);
    window.addEventListener('resize', this.handleResize);

    this.lastTime = performance.now();
    this.scheduleNextFrame();
  }

  private getTexture(url: string, repeatX = 1, repeatY = 1, mirrored = false): THREE.Texture {
    const cacheKey = `${url}|${repeatX}|${repeatY}|${mirrored ? 'm' : 'r'}`;
    const existing = this.textureCache.get(cacheKey);
    if (existing) return existing;

    const tex = this.textureLoader.load(url);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = this.maxAnisotropy;
    tex.wrapS = mirrored ? THREE.MirroredRepeatWrapping : THREE.RepeatWrapping;
    tex.wrapT = mirrored ? THREE.ClampToEdgeWrapping : THREE.RepeatWrapping;
    tex.repeat.set(repeatX, repeatY);
    tex.needsUpdate = true;
    this.textureCache.set(cacheKey, tex);
    return tex;
  }

  private preloadAssets() {
    Object.values(WORLD_THEMES).forEach((cfg) => {
      this.getTexture(cfg.skyImage, 2, 1, true);
      this.getTexture(cfg.surfaceTexture, 1, 1);
      this.getTexture(cfg.groundTexture, 24, 24);
    });
    this.getTexture(ASSET_URLS.droneCarbon, 3, 3);
    this.getTexture(ASSET_URLS.checkpointRing, 6, 1);
  }

  private handleContextLost = (e: Event) => {
    e.preventDefault();
    this.callbacks.onWebGLContextLost(true);
  };

  private handleContextRestored = () => {
    this.callbacks.onWebGLContextLost(false);
  };

  private handleResize = () => {
    const width = this.container.clientWidth || window.innerWidth;
    const height = this.container.clientHeight || window.innerHeight;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  };

  // ==========================================
  // Public Control API
  // ==========================================
  public setMode(mode: GameMode) {
    this.mode = mode;
  }

  public setTheme(themeId: ThemeId, isTeleport = false) {
    this.buildEnvironment(themeId);
    if (isTeleport) {
      if (this.position.y < 36) {
        this.position.y = 40;
      }
      this.velocity.multiplyScalar(0.3);
      droneAudio.playTeleport();
      this.spawnBurstParticles(this.position, WORLD_THEMES[themeId].accentHex);
      this.callbacks.onToast(`장소 이동 완료 · ${WORLD_THEMES[themeId].name}`);
    }
  }

  public getTheme(): ThemeId {
    return this.theme;
  }

  public startNewGame(mode: GameMode, themeId: ThemeId) {
    this.mode = mode;
    if (this.theme !== themeId) {
      this.buildEnvironment(themeId);
    }
    this.score = 0;
    this.ringsPassed = 0;
    this.timeLeft = INITIAL_TIME;
    this.boostEnergy = 100;
    this.isPaused = false;
    this.isPlaying = true;

    this.position.set(0, 25, 0);
    this.velocity.set(0, 0, 0);
    this.yaw = 0;
    this.pitch = 0;
    this.roll = 0;
    this.yawVelocity = 0;
    this.isTricking = false;
    this.trickProgress = 0;

    this.smoothCamPos.set(0, 30, 12);
    this.smoothLookAt.set(0, 25, -20);

    this.buildRings();
    this.emitTelemetry(true);
  }

  public setPaused(paused: boolean) {
    this.isPaused = paused;
    if (paused) {
      droneAudio.silenceMotor();
    } else {
      this.lastTime = performance.now();
    }
  }

  public stopToMenu() {
    this.isPlaying = false;
    this.isPaused = false;
    droneAudio.silenceMotor();
  }

  public setCameraMode(mode: CameraMode) {
    this.cameraMode = mode;
    this.callbacks.onToast(
      mode === 'fpv' ? 'FPV 1인칭 고글 시점 전환' : '3인칭 체이스 시점 전환',
    );
  }

  public setKeyState(code: string, down: boolean) {
    this.keys[code] = down;
  }

  public setLeftJoystick(nx: number, ny: number) {
    this.joyYaw = -nx;
    this.joyThrottle = -ny;
  }

  public setRightJoystick(nx: number, ny: number) {
    this.joyRoll = nx;
    this.joyPitch = -ny;
  }

  public setTouchBoost(active: boolean) {
    this.touchBoost = active;
  }

  public triggerTrick() {
    if (!this.isPlaying || this.isPaused || this.isTricking) return;

    this.isTricking = true;
    this.trickProgress = 0;

    const pitchInput = this.getPitchInput();
    const rollInput = this.getRollInput();

    if (Math.abs(pitchInput) > Math.abs(rollInput) && pitchInput !== 0) {
      this.trickType = 'flip';
      this.trickDir = pitchInput > 0 ? -1 : 1;
    } else {
      this.trickType = 'roll';
      this.trickDir =
        rollInput !== 0 ? -Math.sign(rollInput) : Math.random() > 0.5 ? 1 : -1;
    }

    this.velocity.y += 14;
    const trickBonus = 50;
    this.score += trickBonus;

    droneAudio.playTrick();
    this.spawnBurstParticles(this.position, 0xc084fc);
    const trickName = this.trickType === 'flip' ? '360° FLIP!' : 'BARREL ROLL!';
    this.callbacks.onToast(`${trickName} +${trickBonus} PTS`);
  }

  // ==========================================
  // World Environment Builder (100% Image-Textured)
  // ==========================================
  private clearEnvironment() {
    while (this.envGroup.children.length > 0) {
      const obj = this.envGroup.children[0];
      this.envGroup.remove(obj);
      obj.traverse((child) => {
        if ((child as THREE.Mesh).isMesh) {
          const mesh = child as THREE.Mesh;
          mesh.geometry.dispose();
          if (Array.isArray(mesh.material)) {
            mesh.material.forEach((m) => m.dispose());
          } else {
            mesh.material.dispose();
          }
        }
      });
    }
    this.buildings.length = 0;
  }

  private buildEnvironment(themeKey: ThemeId) {
    this.theme = themeKey;
    const cfg = WORLD_THEMES[themeKey];

    this.clearEnvironment();

    // Update sky dome texture & matching horizon fog / lighting
    const skyTex = this.getTexture(cfg.skyImage, 2, 1, true);
    this.skyDomeMat.map = skyTex;
    this.skyDomeMat.needsUpdate = true;

    this.scene.background = new THREE.Color(cfg.fogColor);
    this.scene.fog = new THREE.FogExp2(cfg.fogColor, cfg.fogDensity);
    this.hemiLight.color.setHex(cfg.hemiSky);
    this.hemiLight.groundColor.setHex(cfg.hemiGround);
    this.dirLight.color.setHex(cfg.dirColor);
    this.rimLight.color.setHex(cfg.accentHex);

    // Textured Ground Plane
    const groundTex = this.getTexture(cfg.groundTexture, 24, 24);
    const groundGeo = new THREE.PlaneGeometry(1600, 1600);
    const groundMat = new THREE.MeshStandardMaterial({
      map: groundTex,
      color: cfg.groundTint,
      roughness: themeKey === 'aurora' ? 0.25 : 0.85,
      metalness: themeKey === 'cyber' ? 0.25 : 0.08,
    });
    const ground = new THREE.Mesh(groundGeo, groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    this.envGroup.add(ground);

    const surfaceTex = this.getTexture(cfg.surfaceTexture, 1, 2);

    if (themeKey === 'cyber') {
      const facadeMat = new THREE.MeshStandardMaterial({
        map: surfaceTex,
        emissiveMap: surfaceTex,
        emissive: new THREE.Color(0x67e8f9),
        emissiveIntensity: 0.55,
        roughness: 0.28,
        metalness: 0.65,
      });
      const accentColors = [0x38bdf8, 0xf59e0b, 0x10b981, 0x818cf8];
      const boxGeo = new THREE.BoxGeometry(1, 1, 1);

      for (let i = 0; i < 140; i++) {
        const angle = i * 2.39996;
        const radius = 58 + i * 3.7;
        const bx = Math.cos(angle) * radius;
        const bz = Math.sin(angle) * radius;
        const bw = 14 + (i % 5) * 4;
        const bd = 14 + ((i * 3) % 5) * 4;
        const bh = 28 + ((i * 7) % 13) * 9;

        const mesh = new THREE.Mesh(boxGeo, facadeMat);
        mesh.position.set(bx, bh / 2, bz);
        mesh.scale.set(bw, bh, bd);
        mesh.castShadow = true;
        mesh.receiveShadow = true;
        this.envGroup.add(mesh);

        const crown = new THREE.Mesh(
          new THREE.BoxGeometry(bw + 0.7, 1.4, bd + 0.7),
          new THREE.MeshStandardMaterial({
            color: accentColors[i % accentColors.length],
            emissive: accentColors[i % accentColors.length],
            emissiveIntensity: 0.9,
            roughness: 0.2,
          }),
        );
        crown.position.set(bx, bh + 0.5, bz);
        this.envGroup.add(crown);

        this.buildings.push({
          minX: bx - bw / 2,
          maxX: bx + bw / 2,
          minZ: bz - bd / 2,
          maxZ: bz + bd / 2,
          maxY: bh + 1.2,
        });
      }
    } else if (themeKey === 'canyon') {
      const rockTex = this.getTexture(cfg.surfaceTexture, 2, 2);
      const mesaMat = new THREE.MeshStandardMaterial({
        map: rockTex,
        color: 0xffedd5,
        roughness: 0.9,
        metalness: 0.04,
      });
      const capMat = new THREE.MeshStandardMaterial({
        map: rockTex,
        color: 0xfdba74,
        roughness: 0.85,
        metalness: 0.05,
      });
      const boxGeo = new THREE.BoxGeometry(1, 1, 1);

      for (let i = 0; i < 135; i++) {
        const angle = i * 2.39996;
        const radius = 60 + i * 3.7;
        const bx = Math.cos(angle) * radius;
        const bz = Math.sin(angle) * radius;
        const bw = 18 + (i % 5) * 5;
        const bd = 18 + ((i * 3) % 5) * 5;
        const bh = 25 + ((i * 7) % 13) * 8.5;

        const baseMesh = new THREE.Mesh(boxGeo, mesaMat);
        baseMesh.position.set(bx, bh * 0.3, bz);
        baseMesh.scale.set(bw, bh * 0.6, bd);
        baseMesh.castShadow = true;
        baseMesh.receiveShadow = true;
        this.envGroup.add(baseMesh);

        const topMesh = new THREE.Mesh(boxGeo, capMat);
        topMesh.position.set(bx, bh * 0.8, bz);
        topMesh.scale.set(bw * 0.68, bh * 0.4, bd * 0.68);
        topMesh.castShadow = true;
        this.envGroup.add(topMesh);

        this.buildings.push({
          minX: bx - bw / 2,
          maxX: bx + bw / 2,
          minZ: bz - bd / 2,
          maxZ: bz + bd / 2,
          maxY: bh,
        });
      }
    } else if (themeKey === 'alpine') {
      const rockSnowTex = this.getTexture(cfg.surfaceTexture, 2, 2);
      const peakMat = new THREE.MeshStandardMaterial({
        map: rockSnowTex,
        roughness: 0.72,
        metalness: 0.08,
      });
      const snowMat = new THREE.MeshStandardMaterial({
        map: rockSnowTex,
        color: 0xffffff,
        roughness: 0.42,
      });
      const foliageMat = new THREE.MeshStandardMaterial({
        color: 0x065f46,
        roughness: 0.82,
      });

      for (let i = 0; i < 140; i++) {
        const angle = i * 2.39996;
        const radius = 60 + i * 3.7;
        const bx = Math.cos(angle) * radius;
        const bz = Math.sin(angle) * radius;

        if (i % 3 === 0) {
          const baseR = 16 + (i % 5) * 4;
          const bh = 46 + ((i * 7) % 12) * 9;

          const mountain = new THREE.Mesh(new THREE.ConeGeometry(baseR, bh, 7), peakMat);
          mountain.position.set(bx, bh / 2, bz);
          mountain.castShadow = true;
          this.envGroup.add(mountain);

          const snowCap = new THREE.Mesh(
            new THREE.ConeGeometry(baseR * 0.48, bh * 0.45, 7),
            snowMat,
          );
          snowCap.position.set(bx, bh * 0.77, bz);
          this.envGroup.add(snowCap);

          this.buildings.push({
            minX: bx - baseR * 0.65,
            maxX: bx + baseR * 0.65,
            minZ: bz - baseR * 0.65,
            maxZ: bz + baseR * 0.65,
            maxY: bh * 0.85,
          });
        } else {
          const th = 16 + (i % 6) * 4;
          const tr = 4.5 + (i % 3) * 1.5;
          const tree = new THREE.Mesh(new THREE.ConeGeometry(tr, th, 7), foliageMat);
          tree.position.set(bx, th / 2, bz);
          tree.castShadow = true;
          this.envGroup.add(tree);

          this.buildings.push({
            minX: bx - tr * 0.7,
            maxX: bx + tr * 0.7,
            minZ: bz - tr * 0.7,
            maxZ: bz + tr * 0.7,
            maxY: th,
          });
        }
      }
    } else if (themeKey === 'aurora') {
      const iceTex = this.getTexture(cfg.surfaceTexture, 1, 2);
      const iceMat = new THREE.MeshPhysicalMaterial({
        map: iceTex,
        emissiveMap: iceTex,
        emissive: new THREE.Color(0x0ea5e9),
        emissiveIntensity: 0.35,
        roughness: 0.14,
        metalness: 0.35,
        clearcoat: 0.9,
        clearcoatRoughness: 0.12,
      });

      for (let i = 0; i < 135; i++) {
        const angle = i * 2.39996;
        const radius = 60 + i * 3.7;
        const bx = Math.cos(angle) * radius;
        const bz = Math.sin(angle) * radius;
        const bw = 12 + (i % 5) * 3.5;
        const bh = 28 + ((i * 7) % 13) * 8.5;

        const glacier = new THREE.Mesh(new THREE.OctahedronGeometry(bw * 0.75, 0), iceMat);
        glacier.position.set(bx, bh * 0.45, bz);
        glacier.scale.set(1, bh / (bw * 1.1), 1);
        this.envGroup.add(glacier);

        this.buildings.push({
          minX: bx - bw * 0.55,
          maxX: bx + bw * 0.55,
          minZ: bz - bw * 0.55,
          maxZ: bz + bw * 0.55,
          maxY: bh * 0.9,
        });
      }
    }
  }

  // ==========================================
  // Composite 10-Part Carbon FPV Racing Drone
  // ==========================================
  private buildDrone() {
    const carbonTex = this.getTexture(ASSET_URLS.droneCarbon, 3, 3);
    const carbonMat = new THREE.MeshPhysicalMaterial({
      map: carbonTex,
      color: 0xdbeafe,
      metalness: 0.45,
      roughness: 0.32,
      clearcoat: 0.65,
      clearcoatRoughness: 0.2,
    });

    const aluRedMat = new THREE.MeshStandardMaterial({
      color: 0xe11d48,
      metalness: 0.85,
      roughness: 0.2,
    });

    // 1. Carbon plates
    const bottomPlate = new THREE.Mesh(new THREE.BoxGeometry(1.15, 0.08, 2.35), carbonMat);
    bottomPlate.position.y = -0.14;
    bottomPlate.castShadow = true;
    this.droneGroup.add(bottomPlate);

    const topPlate = new THREE.Mesh(new THREE.BoxGeometry(1.05, 0.07, 2.15), carbonMat);
    topPlate.position.y = 0.22;
    topPlate.castShadow = true;
    this.droneGroup.add(topPlate);

    // 2. FC/ESC Electronics Stack
    const stackMesh = new THREE.Mesh(
      new THREE.BoxGeometry(0.75, 0.26, 0.85),
      new THREE.MeshStandardMaterial({ color: 0x065f46, roughness: 0.45, metalness: 0.2 }),
    );
    stackMesh.position.set(0, 0.04, 0.05);
    this.droneGroup.add(stackMesh);

    // 3. Standoff Columns
    const standoffGeo = new THREE.CylinderGeometry(0.045, 0.045, 0.34, 8);
    const standoffCoords: [number, number][] = [
      [-0.42, -0.85],
      [0.42, -0.85],
      [-0.44, 0.0],
      [0.44, 0.0],
      [-0.42, 0.85],
      [0.42, 0.85],
    ];
    standoffCoords.forEach(([sx, sz]) => {
      const post = new THREE.Mesh(standoffGeo, aluRedMat);
      post.position.set(sx, 0.04, sz);
      this.droneGroup.add(post);
    });

    // 4. Front FPV Camera Cage & Optical Lens
    const cageLeft = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.36, 0.38), aluRedMat);
    cageLeft.position.set(-0.36, 0.05, -1.02);
    const cageRight = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.36, 0.38), aluRedMat);
    cageRight.position.set(0.36, 0.05, -1.02);
    this.droneGroup.add(cageLeft, cageRight);

    const fpvCamGroup = new THREE.Group();
    fpvCamGroup.position.set(0, 0.06, -1.02);
    fpvCamGroup.rotation.x = 0.42;

    const camBody = new THREE.Mesh(new THREE.BoxGeometry(0.54, 0.42, 0.42), carbonMat);
    const lensBarrel = new THREE.Mesh(
      new THREE.CylinderGeometry(0.18, 0.2, 0.28, 16),
      new THREE.MeshStandardMaterial({ color: 0x0f172a, metalness: 0.9, roughness: 0.12 }),
    );
    lensBarrel.rotation.x = Math.PI / 2;
    lensBarrel.position.z = -0.24;

    const lensGlass = new THREE.Mesh(
      new THREE.CircleGeometry(0.15, 16),
      new THREE.MeshPhysicalMaterial({
        color: 0x38bdf8,
        metalness: 0.1,
        roughness: 0.05,
        clearcoat: 1.0,
      }),
    );
    lensGlass.rotation.y = Math.PI;
    lensGlass.position.z = -0.385;

    fpvCamGroup.add(camBody, lensBarrel, lensGlass);
    this.droneGroup.add(fpvCamGroup);

    // 5. Action Cam & 6S LiPo Battery
    const goproGroup = new THREE.Group();
    goproGroup.position.set(0, 0.48, -0.62);
    goproGroup.rotation.x = 0.45;

    const goproMount = new THREE.Mesh(
      new THREE.BoxGeometry(0.65, 0.16, 0.45),
      new THREE.MeshStandardMaterial({ color: 0x0284c7, roughness: 0.55 }),
    );
    goproMount.position.y = -0.14;

    const goproBody = new THREE.Mesh(
      new THREE.BoxGeometry(0.76, 0.54, 0.36),
      new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.35, metalness: 0.4 }),
    );
    const goproLens = new THREE.Mesh(
      new THREE.BoxGeometry(0.28, 0.28, 0.12),
      new THREE.MeshStandardMaterial({ color: 0x090d16, metalness: 0.9, roughness: 0.1 }),
    );
    goproLens.position.set(-0.18, 0.05, -0.2);

    const recLed = new THREE.Mesh(
      new THREE.SphereGeometry(0.04, 8, 8),
      new THREE.MeshBasicMaterial({ color: 0xff2a55 }),
    );
    recLed.position.set(0.24, 0.16, -0.19);
    goproGroup.add(goproMount, goproBody, goproLens, recLed);
    this.droneGroup.add(goproGroup);

    const lipoPack = new THREE.Mesh(
      new THREE.BoxGeometry(0.78, 0.44, 1.05),
      new THREE.MeshStandardMaterial({ color: 0x2563eb, roughness: 0.45 }),
    );
    lipoPack.position.set(0, 0.47, 0.38);
    lipoPack.castShadow = true;

    const batteryStrap = new THREE.Mesh(
      new THREE.BoxGeometry(0.84, 0.48, 0.22),
      new THREE.MeshStandardMaterial({ color: 0xfbbf24, roughness: 0.7 }),
    );
    batteryStrap.position.set(0, 0.47, 0.38);
    this.droneGroup.add(lipoPack, batteryStrap);

    // 6. Dual VTX Lollipop Antennas
    const antStemMat = new THREE.MeshStandardMaterial({ color: 0x334155 });
    const antCapMat = new THREE.MeshStandardMaterial({ color: 0xe11d48, roughness: 0.3 });
    [-0.24, 0.24].forEach((ax, idx) => {
      const antGroup = new THREE.Group();
      antGroup.position.set(ax, 0.25, 1.05);
      antGroup.rotation.x = -0.55;
      antGroup.rotation.z = idx === 0 ? 0.28 : -0.28;

      const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.03, 0.65, 8), antStemMat);
      stem.position.y = 0.32;
      const lollipopCap = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.14, 0.18, 14), antCapMat);
      lollipopCap.position.y = 0.68;

      antGroup.add(stem, lollipopCap);
      this.droneGroup.add(antGroup);
    });

    // 7. Rear Thruster Exhaust Plumes
    const flameGeo = new THREE.ConeGeometry(0.18, 1.1, 8);
    flameGeo.rotateX(Math.PI / 2);
    const flameMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.85,
    });
    this.boostFlameLeft = new THREE.Mesh(flameGeo, flameMat);
    this.boostFlameLeft.position.set(-0.32, 0.05, 1.55);
    this.boostFlameLeft.visible = false;
    this.droneGroup.add(this.boostFlameLeft);

    this.boostFlameRight = new THREE.Mesh(flameGeo, flameMat);
    this.boostFlameRight.position.set(0.32, 0.05, 1.55);
    this.boostFlameRight.visible = false;
    this.droneGroup.add(this.boostFlameRight);

    // 8. Carbon Arms, Brushless Motors & Tri-Blade Propellers
    const armPositions = [
      { x: -1.42, z: -1.32, color: 0x38bdf8 },
      { x: 1.42, z: -1.32, color: 0x38bdf8 },
      { x: -1.42, z: 1.32, color: 0xf43f5e },
      { x: 1.42, z: 1.32, color: 0xf43f5e },
    ];
    const armGeo = new THREE.BoxGeometry(0.24, 0.09, 1.95);
    const motorBellMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      metalness: 0.9,
      roughness: 0.15,
    });
    const motorAccentMat = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      metalness: 0.85,
      roughness: 0.2,
    });

    armPositions.forEach((pos, idx) => {
      const arm = new THREE.Mesh(armGeo, carbonMat);
      arm.position.set(pos.x * 0.5, -0.08, pos.z * 0.5);
      arm.lookAt(pos.x, -0.08, pos.z);
      arm.castShadow = true;
      this.droneGroup.add(arm);

      const motorBase = new THREE.Mesh(
        new THREE.CylinderGeometry(0.22, 0.25, 0.1, 16),
        motorAccentMat,
      );
      motorBase.position.set(pos.x, -0.01, pos.z);
      const motorBell = new THREE.Mesh(
        new THREE.CylinderGeometry(0.24, 0.24, 0.22, 16),
        motorBellMat,
      );
      motorBell.position.set(pos.x, 0.14, pos.z);
      this.droneGroup.add(motorBase, motorBell);

      const led = new THREE.Mesh(
        new THREE.BoxGeometry(0.22, 0.06, 0.22),
        new THREE.MeshBasicMaterial({ color: pos.color }),
      );
      led.position.set(pos.x, -0.14, pos.z);
      this.droneGroup.add(led);

      const propGroup = new THREE.Group();
      propGroup.position.set(pos.x, 0.28, pos.z);

      const hub = new THREE.Mesh(new THREE.ConeGeometry(0.09, 0.14, 12), aluRedMat);
      hub.position.y = 0.04;
      propGroup.add(hub);

      const bladeMat = new THREE.MeshBasicMaterial({
        color: idx < 2 ? 0x38bdf8 : 0xfb7185,
        transparent: true,
        opacity: 0.82,
      });

      for (let b = 0; b < 3; b++) {
        const bladePivot = new THREE.Group();
        bladePivot.rotation.y = (b * Math.PI * 2) / 3;

        const blade = new THREE.Mesh(new THREE.BoxGeometry(0.82, 0.02, 0.15), bladeMat);
        blade.position.set(0.42, 0, 0);
        blade.rotation.x = idx % 2 === 0 ? 0.18 : -0.18;

        bladePivot.add(blade);
        propGroup.add(bladePivot);
      }

      this.droneGroup.add(propGroup);
      this.propellers.push(propGroup);
    });

    // 9. Navigation Pointer Chevron
    const arrowGroup = new THREE.Group();
    const coneGeo = new THREE.ConeGeometry(0.26, 0.65, 12);
    coneGeo.rotateX(-Math.PI / 2);
    const arrowMat = new THREE.MeshBasicMaterial({ color: 0xfbbf24 });
    const arrowCone = new THREE.Mesh(coneGeo, arrowMat);
    arrowGroup.add(arrowCone);
    arrowGroup.position.set(0, 1.35, 0);
    this.droneGroup.add(arrowGroup);
    this.navArrow = arrowGroup;

    this.droneGroup.position.copy(this.position);
    this.scene.add(this.droneGroup);
  }

  // ==========================================
  // Textured Checkpoint Rings & Particles
  // ==========================================
  private buildRings() {
    this.rings.forEach((r) => {
      this.scene.remove(r.mesh);
      r.mesh.traverse((c) => {
        if ((c as THREE.Mesh).isMesh) {
          const m = c as THREE.Mesh;
          m.geometry.dispose();
          if (Array.isArray(m.material)) m.material.forEach((mat) => mat.dispose());
          else m.material.dispose();
        }
      });
    });
    this.rings.length = 0;

    const ringTex = this.getTexture(ASSET_URLS.checkpointRing, 6, 1);
    const torusGeo = new THREE.TorusGeometry(9.5, 0.68, 16, 48);
    const innerHaloGeo = new THREE.TorusGeometry(8.55, 0.18, 12, 48);

    COURSE_WAYPOINTS.forEach((coords, idx) => {
      const pos = new THREE.Vector3(coords[0], coords[1], coords[2]);
      const ringGroup = new THREE.Group();
      ringGroup.position.copy(pos);

      if (idx < COURSE_WAYPOINTS.length - 1) {
        const next = COURSE_WAYPOINTS[idx + 1];
        ringGroup.lookAt(next[0], next[1], next[2]);
      } else {
        ringGroup.lookAt(0, 45, -320);
      }

      const outerMat = new THREE.MeshStandardMaterial({
        map: ringTex,
        emissiveMap: ringTex,
        color: idx === 0 ? 0xfbbf24 : 0x38bdf8,
        emissive: idx === 0 ? 0xd97706 : 0x0284c7,
        emissiveIntensity: 0.75,
        roughness: 0.25,
        metalness: 0.65,
      });
      const outerMesh = new THREE.Mesh(torusGeo, outerMat);

      const innerMat = new THREE.MeshBasicMaterial({
        color: idx === 0 ? 0xfef08a : 0x7dd3fc,
        transparent: true,
        opacity: 0.7,
      });
      const innerMesh = new THREE.Mesh(innerHaloGeo, innerMat);

      ringGroup.add(outerMesh, innerMesh);
      this.scene.add(ringGroup);

      this.rings.push({
        mesh: ringGroup,
        outerMat,
        innerMat,
        position: pos,
        passed: false,
      });
    });

    this.updateActiveRingVisuals();
  }

  private updateActiveRingVisuals() {
    if (this.rings.length === 0) return;
    const activeIndex = this.ringsPassed % this.rings.length;
    this.rings.forEach((r, idx) => {
      if (this.mode === 'race' && r.passed) {
        r.outerMat.color.setHex(0x10b981);
        r.outerMat.emissive.setHex(0x059669);
        r.innerMat.color.setHex(0x6ee7b7);
        r.mesh.scale.setScalar(0.85);
      } else if (idx === activeIndex) {
        r.outerMat.color.setHex(0xfbbf24);
        r.outerMat.emissive.setHex(0xf59e0b);
        r.innerMat.color.setHex(0xfef08a);
        r.mesh.scale.setScalar(1.12);
      } else {
        r.outerMat.color.setHex(0x38bdf8);
        r.outerMat.emissive.setHex(0x0284c7);
        r.innerMat.color.setHex(0x7dd3fc);
        r.mesh.scale.setScalar(1.0);
      }
    });
  }

  private spawnBurstParticles(origin: THREE.Vector3, colorHex = 0xfbbf24) {
    let mat = this.particleMaterials.get(colorHex);
    if (!mat) {
      mat = new THREE.MeshBasicMaterial({ color: colorHex });
      this.particleMaterials.set(colorHex, mat);
    }
    for (let i = 0; i < 20; i++) {
      const p = new THREE.Mesh(this.particleGeo, mat);
      p.position.copy(origin);
      const vel = new THREE.Vector3(
        (Math.random() - 0.5) * 28,
        (Math.random() - 0.5) * 28,
        (Math.random() - 0.5) * 28,
      );
      this.scene.add(p);
      this.particles.push({ mesh: p, vel, life: 1.0 });
    }
  }

  private updateParticles(dt: number) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life -= dt * 1.6;
      if (p.life <= 0) {
        this.scene.remove(p.mesh);
        this.particles.splice(i, 1);
      } else {
        p.mesh.position.addScaledVector(p.vel, dt);
        p.mesh.scale.setScalar(p.life);
        p.mesh.rotation.x += dt * 5;
        p.mesh.rotation.y += dt * 5;
      }
    }
  }

  // ==========================================
  // Flight Physics & Collision Loop
  // ==========================================
  private getThrottleInput(): number {
    const keyThrottle = (this.keys['KeyW'] ? 1 : 0) - (this.keys['KeyS'] ? 1 : 0);
    return THREE.MathUtils.clamp(keyThrottle + this.joyThrottle, -1, 1);
  }

  private getYawInput(): number {
    const keyYaw = (this.keys['KeyA'] ? 1 : 0) - (this.keys['KeyD'] ? 1 : 0);
    return THREE.MathUtils.clamp(keyYaw + this.joyYaw, -1, 1);
  }

  private getPitchInput(): number {
    const keyPitch = (this.keys['ArrowUp'] ? 1 : 0) - (this.keys['ArrowDown'] ? 1 : 0);
    return THREE.MathUtils.clamp(keyPitch + this.joyPitch, -1, 1);
  }

  private getRollInput(): number {
    const keyRoll = (this.keys['ArrowRight'] ? 1 : 0) - (this.keys['ArrowLeft'] ? 1 : 0);
    return THREE.MathUtils.clamp(keyRoll + this.joyRoll, -1, 1);
  }

  private updateDronePhysics(dt: number): boolean {
    const throttle = this.getThrottleInput();
    const yawIn = this.getYawInput();
    const pitchIn = this.getPitchInput();
    const rollIn = this.getRollInput();

    const wantsBoost = Boolean(this.keys['Space']) || this.touchBoost;
    let isBoosting = false;

    if (wantsBoost && this.boostEnergy > 2) {
      isBoosting = true;
      this.boostEnergy = Math.max(0, this.boostEnergy - dt * 38);
    } else {
      this.boostEnergy = Math.min(100, this.boostEnergy + dt * 20);
    }

    if (this.boostFlameLeft && this.boostFlameRight) {
      this.boostFlameLeft.visible = isBoosting;
      this.boostFlameRight.visible = isBoosting;
      if (isBoosting) {
        const flicker = 0.8 + Math.random() * 0.6;
        this.boostFlameLeft.scale.set(1, 1, flicker);
        this.boostFlameRight.scale.set(1, 1, flicker);
      }
    }

    // Smooth camera FOV kick on boost
    const targetFov = isBoosting ? 78 : 68;
    if (Math.abs(this.camera.fov - targetFov) > 0.05) {
      this.camera.fov = THREE.MathUtils.lerp(this.camera.fov, targetFov, dt * 8);
      this.camera.updateProjectionMatrix();
    }

    const targetYawVel = yawIn * 2.3;
    this.yawVelocity = THREE.MathUtils.lerp(this.yawVelocity, targetYawVel, dt * 10);
    this.yaw += this.yawVelocity * dt;

    _forwardDir.set(-Math.sin(this.yaw), 0, -Math.cos(this.yaw));
    _rightDir.set(Math.cos(this.yaw), 0, -Math.sin(this.yaw));

    const accelPower = isBoosting ? 120 : 75;
    const verticalPower = 55;

    _accel.set(0, 0, 0);
    _accel.addScaledVector(_forwardDir, pitchIn * accelPower);
    _accel.addScaledVector(_rightDir, rollIn * accelPower * 0.85);
    _accel.y += throttle * verticalPower;

    if (isBoosting && pitchIn >= 0) {
      _accel.addScaledVector(_forwardDir, 50);
    }

    this.velocity.addScaledVector(_accel, dt);
    const damping = Math.exp(-2.1 * dt);
    this.velocity.multiplyScalar(damping);

    _prevPos.copy(this.position);
    this.position.addScaledVector(this.velocity, dt);

    const targetPitch = -pitchIn * 0.45 - (isBoosting ? 0.22 : 0);
    const targetRoll = -rollIn * 0.5 - this.yawVelocity * 0.18;
    this.pitch = THREE.MathUtils.lerp(this.pitch, targetPitch, dt * 12);
    this.roll = THREE.MathUtils.lerp(this.roll, targetRoll, dt * 12);

    let trickPitchOffset = 0;
    let trickRollOffset = 0;
    if (this.isTricking) {
      this.trickProgress += dt * 2.4;
      if (this.trickProgress >= 1) {
        this.isTricking = false;
        this.trickProgress = 0;
      } else {
        const ease = 0.5 - 0.5 * Math.cos(Math.PI * this.trickProgress);
        const angle = ease * Math.PI * 2 * this.trickDir;
        if (this.trickType === 'flip') trickPitchOffset = angle;
        else trickRollOffset = angle;
      }
    }

    this.droneGroup.position.copy(this.position);
    this.droneGroup.rotation.order = 'YXZ';
    this.droneGroup.rotation.y = this.yaw;
    this.droneGroup.rotation.x = this.pitch + trickPitchOffset;
    this.droneGroup.rotation.z = this.roll + trickRollOffset;

    const speedMag = this.velocity.length();
    const propSpin = (28 + speedMag * 0.8 + (isBoosting ? 25 : 0)) * dt;
    this.propellers.forEach((p, idx) => {
      p.rotation.y += (idx % 2 === 0 ? 1 : -1) * propSpin;
    });

    this.handleCollisions(_prevPos);
    this.checkRingPass();
    this.updateNavigationArrow();
    droneAudio.updateMotor(Math.min(speedMag / 45, 1), isBoosting, true);
    return isBoosting;
  }

  private handleCollisions(prevPos: THREE.Vector3) {
    const r = 1.4;

    if (this.position.y < r) {
      this.position.y = r;
      if (this.velocity.y < -8) droneAudio.playCrash();
      this.velocity.y = Math.max(0, this.velocity.y * -0.3);
    }

    if (this.position.y > 220) {
      this.position.y = 220;
      this.velocity.y = Math.min(0, this.velocity.y);
    }

    const bound = 480;
    this.position.x = THREE.MathUtils.clamp(this.position.x, -bound, bound);
    this.position.z = THREE.MathUtils.clamp(this.position.z, -bound, bound);

    for (let i = 0; i < this.buildings.length; i++) {
      const b = this.buildings[i];
      if (
        this.position.x + r > b.minX &&
        this.position.x - r < b.maxX &&
        this.position.z + r > b.minZ &&
        this.position.z - r < b.maxZ &&
        this.position.y - r < b.maxY
      ) {
        if (prevPos.y - r >= b.maxY) {
          this.position.y = b.maxY + r;
          this.velocity.y = Math.abs(this.velocity.y) * 0.4;
        } else {
          this.position.x = prevPos.x;
          this.position.z = prevPos.z;
          this.velocity.x *= -0.5;
          this.velocity.z *= -0.5;
          droneAudio.playCrash();
        }
        break;
      }
    }
  }

  private checkRingPass() {
    if (this.rings.length === 0) return;
    const activeIndex = this.ringsPassed % this.rings.length;
    const targetRing = this.rings[activeIndex];
    const dist = this.position.distanceTo(targetRing.position);

    if (dist < 10.2) {
      targetRing.passed = true;
      this.ringsPassed++;
      const timeBonus = this.mode === 'race' ? RING_TIME_BONUS : 0;
      const points = 100 + Math.round(this.velocity.length() * 2);
      this.score += points;

      if (this.mode === 'race') {
        this.timeLeft += timeBonus;
      }

      droneAudio.playRingPass(this.ringsPassed);
      this.spawnBurstParticles(targetRing.position, 0xfbbf24);
      this.updateActiveRingVisuals();

      const bonusMsg = this.mode === 'race' ? ` (+${timeBonus.toFixed(1)}s)` : '';
      this.callbacks.onToast(`RING #${this.ringsPassed} CLEARED · +${points} PTS${bonusMsg}`);

      if (this.mode === 'race' && this.ringsPassed >= TOTAL_RINGS) {
        this.finishGame(true);
      }
    }
  }

  private updateNavigationArrow() {
    if (!this.navArrow || this.rings.length === 0) return;
    const activeIndex = this.ringsPassed % this.rings.length;
    const targetPos = this.rings[activeIndex].position;
    this.navArrow.visible = this.cameraMode === 'third';
    this.navArrow.lookAt(targetPos);
  }

  private updateCamera(dt: number) {
    if (this.cameraMode === 'fpv') {
      _fpvOffset.set(0, 0.25, -1.25).applyEuler(this.droneGroup.rotation);
      this.camera.position.copy(this.position).add(_fpvOffset);

      _lookForward.set(0, 0.15, -25).applyEuler(this.droneGroup.rotation);
      _desiredLook.copy(this.position).add(_lookForward);
      this.camera.lookAt(_desiredLook);
    } else {
      _chaseOffset.set(0, 3.6, 9.5).applyAxisAngle(_yAxis, this.yaw);
      _desiredPos.copy(this.position).add(_chaseOffset);

      this.smoothCamPos.lerp(_desiredPos, 1 - Math.exp(-8 * dt));
      this.camera.position.copy(this.smoothCamPos);

      _forwardTarget.set(0, 0.8, -14).applyAxisAngle(_yAxis, this.yaw);
      _desiredLook.copy(this.position).add(_forwardTarget);

      this.smoothLookAt.lerp(_desiredLook, 1 - Math.exp(-12 * dt));
      this.camera.lookAt(this.smoothLookAt);
    }

    // Keep panoramic sky dome centered horizontally on camera so horizon never clips
    this.skyDome.position.x = this.camera.position.x;
    this.skyDome.position.z = this.camera.position.z;
  }

  private finishGame(isVictory: boolean) {
    this.isPlaying = false;
    droneAudio.silenceMotor();
    if (isVictory) {
      this.score += Math.round(this.timeLeft * 25);
      droneAudio.playVictory();
    }
    this.emitTelemetry(true);
    this.callbacks.onGameOver({
      isVictory,
      finalScore: this.score,
      ringsPassed: this.ringsPassed,
      timeLeft: Math.max(0, this.timeLeft),
      isNewBest: false,
    });
  }

  private emitTelemetry(force = false, isBoosting = false) {
    const now = performance.now();
    if (!force && now - this.lastHudEmit < 50) return;
    this.lastHudEmit = now;

    let dist2D = 0;
    let rx = 0;
    let rz = 0;

    if (this.rings.length > 0) {
      const target = this.rings[this.ringsPassed % this.rings.length].position;
      const dx = target.x - this.position.x;
      const dz = target.z - this.position.z;
      dist2D = Math.hypot(dx, dz);
      const cosY = Math.cos(-this.yaw);
      const sinY = Math.sin(-this.yaw);
      rx = dx * cosY - dz * sinY;
      rz = dx * sinY + dz * cosY;
    }

    this.callbacks.onTelemetry({
      score: this.score,
      ringsPassed: this.ringsPassed,
      timeLeft: Math.max(0, this.timeLeft),
      speedKmh: Math.round(this.velocity.length() * 3.2),
      altitudeM: Math.max(0, Math.round(this.position.y)),
      boostEnergy: this.boostEnergy,
      targetDistanceM: Math.round(dist2D),
      relativeTargetX: rx,
      relativeTargetZ: rz,
      isBoosting,
    });
  }

  // ==========================================
  // Animation Loop (GPU rAF vs Software WebGL afterDraw)
  // ==========================================
  private afterDraw(cb: () => void) {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    if (!gl || typeof gl.fenceSync !== 'function') {
      this.frameId = window.setTimeout(cb, 80);
      return;
    }
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      if (this.disposed) {
        if (sync) gl.deleteSync(sync);
        return;
      }
      const status = sync ? gl.getSyncParameter(sync, gl.SYNC_STATUS) : gl.SIGNALED;
      if (status === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 80);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }

  private scheduleNextFrame() {
    if (this.disposed) return;
    if (this.isSoftwareGl) {
      this.afterDraw(this.tick);
    } else {
      this.frameId = requestAnimationFrame(this.tick);
    }
  }

  private tick = () => {
    if (this.disposed) return;
    const now = performance.now();
    const rawDt = (now - this.lastTime) / 1000;
    this.lastTime = now;
    const dt = Math.min(rawDt || 0.016, 0.05);

    if (this.isPlaying && !this.isPaused) {
      if (this.mode === 'race') {
        this.timeLeft -= dt;
        if (this.timeLeft <= 0) {
          this.timeLeft = 0;
          this.finishGame(false);
          this.renderer.render(this.scene, this.camera);
          this.scheduleNextFrame();
          return;
        }
      }

      const isBoosting = this.updateDronePhysics(dt);
      this.updateCamera(dt);
      this.updateParticles(dt);
      this.emitTelemetry(false, isBoosting);
    } else if (!this.isPlaying) {
      // Cinematic orbit camera around the course while on start/menu screen
      const t = now * 0.00022;
      this.camera.position.set(Math.cos(t) * 85, 58, Math.sin(t) * 85);
      this.camera.lookAt(0, 32, -40);
      this.skyDome.position.x = this.camera.position.x;
      this.skyDome.position.z = this.camera.position.z;

      this.rings.forEach((r) => {
        if (r.mesh.children[1]) {
          r.mesh.children[1].rotation.z += dt * 1.2;
        }
      });
    }

    if (this.rings.length > 0) {
      const activeRing = this.rings[this.ringsPassed % this.rings.length];
      if (activeRing && activeRing.mesh.children[1]) {
        activeRing.mesh.children[1].rotation.z += dt * 2.5;
      }
    }

    this.renderer.render(this.scene, this.camera);
    this.scheduleNextFrame();
  };

  public dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.frameId);
    window.clearTimeout(this.frameId);

    this.renderer.domElement.removeEventListener('webglcontextlost', this.handleContextLost);
    this.renderer.domElement.removeEventListener('webglcontextrestored', this.handleContextRestored);
    window.removeEventListener('resize', this.handleResize);

    this.clearEnvironment();
    this.rings.forEach((r) => this.scene.remove(r.mesh));
    this.particles.forEach((p) => this.scene.remove(p.mesh));
    this.particleGeo.dispose();
    this.particleMaterials.forEach((m) => m.dispose());
    this.particleMaterials.clear();

    this.textureCache.forEach((t) => t.dispose());
    this.textureCache.clear();
    this.skyDome.geometry.dispose();
    this.skyDomeMat.dispose();
    this.scene.environment?.dispose();

    this.renderer.dispose();
    if (this.renderer.domElement.parentElement === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
