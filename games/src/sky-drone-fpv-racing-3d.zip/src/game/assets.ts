import skyCyberCity from '../assets/images/sky_cyber_city_1794636348320.jpg';
import skyGrandCanyon from '../assets/images/sky_grand_canyon_1794636349426.jpg';
import skyAlpinePeaks from '../assets/images/sky_alpine_peaks_1794636349040.jpg';
import skyArcticAurora from '../assets/images/sky_arctic_aurora_1794636350061.jpg';

import texCyberFacade from '../assets/images/tex_cyber_facade_1794636349710.jpg';
import texCanyonSandstone from '../assets/images/tex_canyon_sandstone_1794636350517.jpg';
import texAlpineSnowRock from '../assets/images/tex_alpine_snow_rock_1794636351106.jpg';
import texArcticGlacier from '../assets/images/tex_arctic_glacier_1794636350947.jpg';

import texDroneCarbon from '../assets/images/tex_drone_carbon_1794636351677.jpg';
import texGroundCity from '../assets/images/tex_ground_city_1794636365893.jpg';
import texCheckpointRing from '../assets/images/tex_checkpoint_ring_1794636367104.jpg';
import heroDroneArt from '../assets/images/hero_drone_art_1794636366228.jpg';

import type { ThemeId, WorldThemeConfig } from './types';

export const ASSET_URLS = {
  droneCarbon: texDroneCarbon,
  checkpointRing: texCheckpointRing,
  heroDroneArt,
};

export const WORLD_THEMES: Record<ThemeId, WorldThemeConfig> = {
  cyber: {
    id: 'cyber',
    name: '네온 사이버 시티',
    subtitle: '황혼빛 마천루와 조명 그리드 스카이라인',
    skyImage: skyCyberCity,
    surfaceTexture: texCyberFacade,
    groundTexture: texGroundCity,
    fogColor: 0x101c38,
    fogDensity: 0.0017,
    hemiSky: 0x7dd3fc,
    hemiGround: 0x1e293b,
    dirColor: 0xfde68a,
    accentHex: 0x38bdf8,
    accentColor: '#38bdf8',
    groundTint: 0xdbeafe,
  },
  canyon: {
    id: 'canyon',
    name: '그랜드 캐니언 협곡',
    subtitle: '석양빛 붉은 사암 지층과 거대 메사 협곡',
    skyImage: skyGrandCanyon,
    surfaceTexture: texCanyonSandstone,
    groundTexture: texCanyonSandstone,
    fogColor: 0xc26d2a,
    fogDensity: 0.0015,
    hemiSky: 0xfef3c7,
    hemiGround: 0x78350f,
    dirColor: 0xfffbeb,
    accentHex: 0xf59e0b,
    accentColor: '#f59e0b',
    groundTint: 0xfed7aa,
  },
  alpine: {
    id: 'alpine',
    name: '알프스 설산 봉우리',
    subtitle: '만년설 화강암 봉우리와 침엽수 계곡',
    skyImage: skyAlpinePeaks,
    surfaceTexture: texAlpineSnowRock,
    groundTexture: texAlpineSnowRock,
    fogColor: 0x93c5fd,
    fogDensity: 0.0014,
    hemiSky: 0xf0f9ff,
    hemiGround: 0x334155,
    dirColor: 0xffffff,
    accentHex: 0x10b981,
    accentColor: '#10b981',
    groundTint: 0xf8fafc,
  },
  aurora: {
    id: 'aurora',
    name: '북극 오로라 야경',
    subtitle: '에메랄드빛 오로라 밤하늘과 빙하 결정 지대',
    skyImage: skyArcticAurora,
    surfaceTexture: texArcticGlacier,
    groundTexture: texArcticGlacier,
    fogColor: 0x052e2b,
    fogDensity: 0.0016,
    hemiSky: 0x34d399,
    hemiGround: 0x0f172a,
    dirColor: 0xa7f3d0,
    accentHex: 0x2dd4bf,
    accentColor: '#2dd4bf',
    groundTint: 0xa5f3fc,
  },
};

export const WORLD_THEME_LIST: WorldThemeConfig[] = [
  WORLD_THEMES.cyber,
  WORLD_THEMES.canyon,
  WORLD_THEMES.alpine,
  WORLD_THEMES.aurora,
];
