import * as Tone from 'tone';

class DroneAudioEngine {
  private motorOsc: Tone.Oscillator | null = null;
  private motorGain: Tone.Gain | null = null;
  private motorFilter: Tone.Filter | null = null;
  private sfxSynth: Tone.PolySynth | null = null;
  private initialized = false;
  private enabled = true;

  public setEnabled(enabled: boolean) {
    this.enabled = enabled;
    if (!enabled) {
      this.silenceMotor();
    }
  }

  public async init(): Promise<void> {
    if (this.initialized) {
      if (Tone.getContext().state !== 'running') {
        await Tone.start().catch(() => {});
      }
      return;
    }

    try {
      await Tone.start();
      this.motorFilter = new Tone.Filter(180, 'lowpass').toDestination();
      this.motorGain = new Tone.Gain(0).connect(this.motorFilter);
      this.motorOsc = new Tone.Oscillator({
        type: 'sawtooth',
        frequency: 75,
      }).connect(this.motorGain);
      this.motorOsc.start();

      this.sfxSynth = new Tone.PolySynth(Tone.Synth, {
        oscillator: { type: 'triangle' },
        envelope: { attack: 0.01, decay: 0.2, sustain: 0.1, release: 0.35 },
      }).toDestination();
      this.sfxSynth.volume.value = -6;

      this.initialized = true;
    } catch {
      // Audio remains gracefully disabled if blocked by browser autoplay policy
    }
  }

  public updateMotor(speedRatio: number, isBoosting: boolean, active: boolean) {
    if (!this.initialized || !this.motorOsc || !this.motorGain || !this.motorFilter) {
      return;
    }

    if (!this.enabled || !active) {
      this.motorGain.gain.rampTo(0, 0.1);
      return;
    }

    const targetFreq = 70 + speedRatio * 95 + (isBoosting ? 45 : 0);
    const targetVol = 0.04 + speedRatio * 0.05 + (isBoosting ? 0.04 : 0);
    this.motorOsc.frequency.rampTo(targetFreq, 0.08);
    this.motorFilter.frequency.rampTo(160 + speedRatio * 300, 0.08);
    this.motorGain.gain.rampTo(targetVol, 0.08);
  }

  public silenceMotor() {
    if (this.initialized && this.motorGain) {
      this.motorGain.gain.rampTo(0, 0.08);
    }
  }

  public playRingPass(combo: number) {
    if (!this.sfxSynth || !this.enabled) return;
    const notes = ['C5', 'E5', 'G5', 'B5', 'C6'];
    const note = notes[Math.min(combo % notes.length, notes.length - 1)];
    this.sfxSynth.triggerAttackRelease([note, 'G6'], '8n');
  }

  public playCrash() {
    if (!this.sfxSynth || !this.enabled) return;
    this.sfxSynth.triggerAttackRelease(['C2', 'F#2', 'A2'], '4n');
  }

  public playTrick() {
    if (!this.sfxSynth || !this.enabled) return;
    this.sfxSynth.triggerAttackRelease(['E5', 'G#5', 'B5', 'E6'], '16n');
  }

  public playTeleport() {
    if (!this.sfxSynth || !this.enabled) return;
    this.sfxSynth.triggerAttackRelease(['C4', 'G4', 'C5', 'E5'], '8n');
  }

  public playVictory() {
    if (!this.sfxSynth || !this.enabled) return;
    this.sfxSynth.triggerAttackRelease(['C5', 'E5', 'G5', 'C6'], '4n');
  }

  public dispose() {
    this.silenceMotor();
    try {
      this.motorOsc?.stop();
      this.motorOsc?.dispose();
      this.motorFilter?.dispose();
      this.motorGain?.dispose();
      this.sfxSynth?.dispose();
    } catch {
      // Ignore cleanup errors
    }
    this.motorOsc = null;
    this.motorFilter = null;
    this.motorGain = null;
    this.sfxSynth = null;
    this.initialized = false;
  }
}

export const droneAudio = new DroneAudioEngine();
