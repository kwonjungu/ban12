export type GameMode = 'race' | 'free';
export type ThemeId = 'cyber' | 'canyon' | 'alpine' | 'aurora';
export type CameraMode = 'third' | 'fpv';
export type GamePhase = 'start' | 'playing' | 'paused' | 'theme' | 'gameover';

export const TOTAL_RINGS = 15;
export const INITIAL_TIME = 45.0;
export const RING_TIME_BONUS = 6.5;

export interface HudTelemetry {
  score: number;
  ringsPassed: number;
  timeLeft: number;
  speedKmh: number;
  altitudeM: number;
  boostEnergy: number;
  targetDistanceM: number;
  relativeTargetX: number;
  relativeTargetZ: number;
  isBoosting: boolean;
}

export interface GameResult {
  isVictory: boolean;
  finalScore: number;
  ringsPassed: number;
  timeLeft: number;
  isNewBest: boolean;
}

export interface WorldThemeConfig {
  id: ThemeId;
  name: string;
  subtitle: string;
  skyImage: string;
  surfaceTexture: string;
  groundTexture: string;
  fogColor: number;
  fogDensity: number;
  hemiSky: number;
  hemiGround: number;
  dirColor: number;
  accentHex: number;
  accentColor: string;
  groundTint: number;
}
