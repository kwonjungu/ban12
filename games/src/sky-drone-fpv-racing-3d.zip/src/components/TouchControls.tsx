import { useEffect, useRef, useState } from 'react';
import { RotateCw, Zap } from 'lucide-react';

interface TouchControlsProps {
  onLeftStick: (nx: number, ny: number) => void;
  onRightStick: (nx: number, ny: number) => void;
  onBoostChange: (active: boolean) => void;
  onTrick: () => void;
}

interface StickProps {
  label: string;
  onMove: (nx: number, ny: number) => void;
}

function VirtualJoystick({ label, onMove }: StickProps) {
  const zoneRef = useRef<HTMLDivElement | null>(null);
  const [knobOffset, setKnobOffset] = useState({ x: 0, y: 0 });
  const activeTouchId = useRef<number | null>(null);
  const isMouseDragging = useRef(false);
  const maxRadius = 34;

  const updateFromClient = (clientX: number, clientY: number) => {
    const zone = zoneRef.current;
    if (!zone) return;
    const rect = zone.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    let dx = clientX - cx;
    let dy = clientY - cy;
    const dist = Math.hypot(dx, dy);
    if (dist > maxRadius) {
      dx = (dx / dist) * maxRadius;
      dy = (dy / dist) * maxRadius;
    }
    setKnobOffset({ x: dx, y: dy });
    onMove(dx / maxRadius, dy / maxRadius);
  };

  const resetStick = () => {
    activeTouchId.current = null;
    isMouseDragging.current = false;
    setKnobOffset({ x: 0, y: 0 });
    onMove(0, 0);
  };

  useEffect(() => {
    const zone = zoneRef.current;
    if (!zone) return;

    const handleTouchStart = (e: TouchEvent) => {
      e.preventDefault();
      if (activeTouchId.current === null && e.changedTouches.length > 0) {
        const t = e.changedTouches[0];
        activeTouchId.current = t.identifier;
        updateFromClient(t.clientX, t.clientY);
      }
    };

    const handleTouchMove = (e: TouchEvent) => {
      e.preventDefault();
      for (let i = 0; i < e.changedTouches.length; i++) {
        const t = e.changedTouches[i];
        if (t.identifier === activeTouchId.current) {
          updateFromClient(t.clientX, t.clientY);
          break;
        }
      }
    };

    const handleTouchEnd = (e: TouchEvent) => {
      for (let i = 0; i < e.changedTouches.length; i++) {
        if (e.changedTouches[i].identifier === activeTouchId.current) {
          resetStick();
          break;
        }
      }
    };

    zone.addEventListener('touchstart', handleTouchStart, { passive: false });
    zone.addEventListener('touchmove', handleTouchMove, { passive: false });
    zone.addEventListener('touchend', handleTouchEnd);
    zone.addEventListener('touchcancel', resetStick);

    return () => {
      zone.removeEventListener('touchstart', handleTouchStart);
      zone.removeEventListener('touchmove', handleTouchMove);
      zone.removeEventListener('touchend', handleTouchEnd);
      zone.removeEventListener('touchcancel', resetStick);
    };
  });

  return (
    <div className="flex flex-col items-center pointer-events-auto">
      <span className="text-[11px] font-medium text-sky-200/90 mb-1.5 tracking-wide">
        {label}
      </span>
      <div
        ref={zoneRef}
        onMouseDown={(e) => {
          isMouseDragging.current = true;
          updateFromClient(e.clientX, e.clientY);
        }}
        onMouseMove={(e) => {
          if (isMouseDragging.current) updateFromClient(e.clientX, e.clientY);
        }}
        onMouseUp={resetStick}
        onMouseLeave={() => {
          if (isMouseDragging.current) resetStick();
        }}
        className="relative w-28 h-28 rounded-full bg-slate-950/75 border-2 border-sky-400/40 flex items-center justify-center shadow-lg"
      >
        <div
          style={{
            transform: `translate(${knobOffset.x}px, ${knobOffset.y}px)`,
          }}
          className="w-11 h-11 rounded-full bg-gradient-to-br from-sky-400 to-blue-600 border-2 border-sky-100 shadow-[0_0_12px_rgba(56,189,248,0.65)] transition-transform duration-75"
        />
      </div>
    </div>
  );
}

export function TouchControls({
  onLeftStick,
  onRightStick,
  onBoostChange,
  onTrick,
}: TouchControlsProps) {
  return (
    <div className="pointer-events-none fixed bottom-4 left-3 right-3 sm:left-5 sm:right-5 flex justify-between items-end z-20">
      <VirtualJoystick label="고도 · 회전" onMove={onLeftStick} />

      <div className="pointer-events-auto mb-2 flex items-center gap-2.5">
        <button
          type="button"
          onTouchStart={(e) => {
            e.preventDefault();
            onTrick();
          }}
          onClick={onTrick}
          className="w-14 h-14 rounded-2xl bg-slate-950/85 active:bg-purple-600/80 border border-purple-400/60 text-purple-200 font-display font-bold text-[11px] shadow-lg flex flex-col items-center justify-center gap-0.5"
          aria-label="360도 공중 트릭"
        >
          <RotateCw className="w-4 h-4" />
          <span>TRICK</span>
        </button>

        <button
          type="button"
          onTouchStart={(e) => {
            e.preventDefault();
            onBoostChange(true);
          }}
          onTouchEnd={() => onBoostChange(false)}
          onTouchCancel={() => onBoostChange(false)}
          onMouseDown={() => onBoostChange(true)}
          onMouseUp={() => onBoostChange(false)}
          onMouseLeave={() => onBoostChange(false)}
          className="w-16 h-16 rounded-2xl bg-slate-950/85 active:bg-amber-500/80 border-2 border-amber-400/75 text-amber-300 font-display font-bold text-xs shadow-lg flex flex-col items-center justify-center gap-0.5"
          aria-label="부스터 가속"
        >
          <Zap className="w-5 h-5" />
          <span>BOOST</span>
        </button>
      </div>

      <VirtualJoystick label="전후 · 좌우" onMove={onRightStick} />
    </div>
  );
}
