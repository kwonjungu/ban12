import { useEffect, useRef } from 'react';

interface RadarDisplayProps {
  relativeTargetX: number;
  relativeTargetZ: number;
  targetDistanceM: number;
}

export function RadarDisplay({
  relativeTargetX,
  relativeTargetZ,
  targetDistanceM,
}: RadarDisplayProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;
    const cx = w / 2;
    const cy = h / 2;
    const radius = w / 2 - 4;

    ctx.clearRect(0, 0, w, h);

    // Outer & inner range rings
    ctx.strokeStyle = 'rgba(56, 189, 248, 0.28)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(cx, cy, radius, 0, Math.PI * 2);
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(cx, cy, radius * 0.5, 0, Math.PI * 2);
    ctx.stroke();

    // Crosshair axes
    ctx.strokeStyle = 'rgba(148, 163, 184, 0.16)';
    ctx.beginPath();
    ctx.moveTo(cx - radius, cy);
    ctx.lineTo(cx + radius, cy);
    ctx.moveTo(cx, cy - radius);
    ctx.lineTo(cx, cy + radius);
    ctx.stroke();

    // Player heading chevron
    ctx.fillStyle = '#38bdf8';
    ctx.beginPath();
    ctx.moveTo(cx, cy - 5);
    ctx.lineTo(cx - 4, cy + 4);
    ctx.lineTo(cx + 4, cy + 4);
    ctx.closePath();
    ctx.fill();

    // Active checkpoint blip
    const maxRange = 160;
    const clampedDist = Math.min(targetDistanceM, maxRange);
    const angle = Math.atan2(relativeTargetZ, relativeTargetX);
    const px = cx + Math.cos(angle) * (clampedDist / maxRange) * (radius - 4);
    const py = cy + Math.sin(angle) * (clampedDist / maxRange) * (radius - 4);

    ctx.fillStyle = '#fbbf24';
    ctx.beginPath();
    ctx.arc(px, py, 4, 0, Math.PI * 2);
    ctx.fill();
  }, [relativeTargetX, relativeTargetZ, targetDistanceM]);

  return (
    <div className="hud-panel rounded-xl p-1.5 flex flex-col items-center">
      <canvas ref={canvasRef} width={72} height={72} className="block" />
      <span className="font-telemetry text-[11px] font-bold text-amber-300 leading-none mt-1">
        {targetDistanceM}m
      </span>
    </div>
  );
}
