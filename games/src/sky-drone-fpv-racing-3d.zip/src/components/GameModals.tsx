import { useState } from 'react';
import {
  Compass,
  Map,
  Play,
  RotateCcw,
  Timer,
  Trophy,
  X,
} from 'lucide-react';
import { ASSET_URLS, WORLD_THEME_LIST } from '../game/assets';
import {
  GameMode,
  GameResult,
  TOTAL_RINGS,
  ThemeId,
  WorldThemeConfig,
} from '../game/types';

function ResilientImage({
  src,
  alt,
  className,
  fallbackTitle,
}: {
  src: string;
  alt: string;
  className?: string;
  fallbackTitle: string;
}) {
  const [failed, setFailed] = useState(false);

  if (failed) {
    return (
      <div
        className={`bg-gradient-to-br from-slate-800 via-slate-900 to-sky-950 flex flex-col items-center justify-center text-slate-300 p-3 ${className ?? ''}`}
      >
        <Compass className="w-6 h-6 text-sky-400 mb-1" />
        <span className="text-xs font-medium text-center">{fallbackTitle}</span>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setFailed(true)}
      className={className}
    />
  );
}

interface StartOverlayProps {
  mode: GameMode;
  selectedTheme: ThemeId;
  bestScore: number;
  onSelectMode: (mode: GameMode) => void;
  onSelectTheme: (theme: ThemeId) => void;
  onStart: () => void;
}

export function StartOverlay({
  mode,
  selectedTheme,
  bestScore,
  onSelectMode,
  onSelectTheme,
  onStart,
}: StartOverlayProps) {
  return (
    <div className="fixed inset-0 z-40 overflow-y-auto bg-slate-950/70 p-3 sm:p-6">
      <div className="min-h-full flex items-center justify-center">
        <div className="hud-panel-elevated max-w-4xl w-full rounded-2xl overflow-hidden grid grid-cols-1 lg:grid-cols-12">
          {/* Left Visual Showcase Panel */}
          <div className="relative lg:col-span-5 h-52 sm:h-60 lg:h-auto lg:min-h-[460px] overflow-hidden">
            <ResilientImage
              src={ASSET_URLS.heroDroneArt}
              alt="FPV 레이싱 드론이 네온 스카이 체크포인트 링을 통과하는 모습"
              fallbackTitle="Sky Drone Racing"
              className="w-full h-full lg:absolute lg:inset-0 object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/35 to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-5 sm:p-6">
              <div className="text-xs font-medium text-sky-300 mb-1">
                3D FPV Flight Simulator · 4 Worlds
              </div>
              <h1 className="font-display text-2xl sm:text-3xl font-bold text-white tracking-tight text-balance">
                SKY DRONE RACING
              </h1>
              <p className="text-slate-300 text-xs sm:text-sm mt-1.5 leading-relaxed">
                체크포인트 링을 돌파하고 360° 공중 트릭과 부스터로 최고 기록을 세우세요.
              </p>
              {bestScore > 0 && (
                <div className="mt-3 pt-3 border-t border-white/15 flex items-center justify-between text-xs">
                  <span className="text-slate-300 flex items-center gap-1.5">
                    <Trophy className="w-3.5 h-3.5 text-amber-400" />
                    최고 기록
                  </span>
                  <span className="font-telemetry font-bold text-amber-300">
                    {bestScore.toLocaleString()} PTS
                  </span>
                </div>
              )}
            </div>
          </div>

        {/* Right Configuration & Launch Panel */}
        <div className="lg:col-span-7 p-5 sm:p-7 flex flex-col justify-between gap-5">
          <div className="space-y-5">
            {/* Mode Selector */}
            <div>
              <div className="text-xs font-semibold text-slate-300 mb-2">
                비행 모드 선택
              </div>
              <div className="grid grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={() => onSelectMode('race')}
                  className={`p-3.5 rounded-xl border text-left transition ${
                    mode === 'race'
                      ? 'border-sky-400 bg-sky-500/15 text-white'
                      : 'border-slate-700 bg-slate-900/60 text-slate-300 hover:border-slate-500'
                  }`}
                >
                  <div className="flex items-center gap-2 font-display font-bold text-sm text-sky-300">
                    <Timer className="w-4 h-4 shrink-0" />
                    <span>타임 어택</span>
                  </div>
                  <div className="text-xs text-slate-400 mt-1">
                    15개 링 제한 시간 완주
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => onSelectMode('free')}
                  className={`p-3.5 rounded-xl border text-left transition ${
                    mode === 'free'
                      ? 'border-amber-400 bg-amber-500/15 text-white'
                      : 'border-slate-700 bg-slate-900/60 text-slate-300 hover:border-slate-500'
                  }`}
                >
                  <div className="flex items-center gap-2 font-display font-bold text-sm text-amber-300">
                    <Compass className="w-4 h-4 shrink-0" />
                    <span>자유 비행</span>
                  </div>
                  <div className="text-xs text-slate-400 mt-1">
                    시간 제한 없이 상공 탐험
                  </div>
                </button>
              </div>
            </div>

            {/* Starting World Selector with Generated Art Thumbnails */}
            <div>
              <div className="text-xs font-semibold text-slate-300 mb-2">
                출발 장소 선택 (비행 중 T 키로 즉시 이동 가능)
              </div>
              <div className="grid grid-cols-2 gap-2.5">
                {WORLD_THEME_LIST.map((theme: WorldThemeConfig) => {
                  const active = selectedTheme === theme.id;
                  return (
                    <button
                      key={theme.id}
                      type="button"
                      onClick={() => onSelectTheme(theme.id)}
                      className={`group relative rounded-xl overflow-hidden border text-left transition h-20 ${
                        active
                          ? 'border-amber-400 ring-1 ring-amber-400/60'
                          : 'border-slate-700 hover:border-slate-500'
                      }`}
                    >
                      <ResilientImage
                        src={theme.skyImage}
                        alt={theme.name}
                        fallbackTitle={theme.name}
                        className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/40 to-transparent" />
                      <div className="absolute bottom-2 left-2.5 right-2.5">
                        <div className="font-display font-bold text-xs text-white truncate">
                          {theme.name}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Concise Controls Summary */}
            <div className="rounded-xl bg-slate-900/80 border border-slate-800 p-3.5 text-xs text-slate-300 space-y-1">
              <div className="font-semibold text-sky-300 mb-1">조종 안내</div>
              <div>
                PC: WASD(고도·회전) + 방향키(전후좌우) + Space(부스터) + V(트릭) + C(시점)
              </div>
              <div>
                모바일·태블릿: 듀얼 가상 조이스틱 + 중앙 TRICK / BOOST 터치 버튼
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={onStart}
            className="w-full min-h-[48px] py-3.5 px-6 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 active:scale-[0.99] text-white font-display font-bold text-base tracking-wide shadow-lg transition flex items-center justify-center gap-2 whitespace-nowrap"
          >
            <Play className="w-4 h-4 fill-current" />
            <span>비행 시작</span>
          </button>
        </div>
        </div>
      </div>
    </div>
  );
}

interface WorldTeleportModalProps {
  currentTheme: ThemeId;
  onSelectTheme: (theme: ThemeId) => void;
  onClose: () => void;
}

export function WorldTeleportModal({
  currentTheme,
  onSelectTheme,
  onClose,
}: WorldTeleportModalProps) {
  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 p-3 sm:p-6">
      <div className="min-h-full flex items-center justify-center">
        <div className="hud-panel-elevated max-w-2xl w-full rounded-2xl p-5 sm:p-7">
          <div className="flex items-start justify-between gap-4 mb-5">
            <div>
              <div className="text-xs font-medium text-amber-300 mb-1">
                일시정지 · 월드 텔레포트
              </div>
              <h2 className="font-display text-2xl font-bold text-white">
                비행 장소 선택
              </h2>
            </div>
            <button
              type="button"
              onClick={onClose}
              className="min-h-[40px] min-w-[40px] p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition flex items-center justify-center shrink-0"
              aria-label="닫기"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-5">
            {WORLD_THEME_LIST.map((theme) => {
              const active = currentTheme === theme.id;
              return (
                <button
                  key={theme.id}
                  type="button"
                  onClick={() => onSelectTheme(theme.id)}
                  className={`group relative rounded-xl overflow-hidden border text-left transition h-32 sm:h-36 ${
                    active
                      ? 'border-2 border-amber-400'
                      : 'border-slate-700 hover:border-sky-400'
                  }`}
                >
                  <ResilientImage
                    src={theme.skyImage}
                    alt={theme.name}
                    fallbackTitle={theme.name}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/45 to-transparent" />
                  <div className="absolute bottom-3 left-3.5 right-3.5">
                    <div className="font-display font-bold text-base text-white">
                      {theme.name}
                    </div>
                    <div className="text-xs text-slate-300 mt-0.5 line-clamp-1">
                      {theme.subtitle}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-full min-h-[44px] py-3 px-6 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-display font-bold text-sm tracking-wide transition whitespace-nowrap"
          >
            비행 계속하기 (T / ESC)
          </button>
        </div>
      </div>
    </div>
  );
}

interface PauseModalProps {
  onResume: () => void;
  onOpenThemeMenu: () => void;
  onRestart: () => void;
}

export function PauseModal({
  onResume,
  onOpenThemeMenu,
  onRestart,
}: PauseModalProps) {
  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-slate-950/75 p-4">
      <div className="hud-panel-elevated max-w-sm w-full rounded-2xl p-6 text-center">
        <h2 className="font-display text-2xl font-bold text-sky-300 mb-1">
          일시 정지
        </h2>
        <p className="text-slate-300 text-sm mb-6">
          비행이 잠시 멈췄습니다.
        </p>

        <div className="space-y-2.5">
          <button
            type="button"
            onClick={onResume}
            className="w-full min-h-[44px] py-3 px-5 rounded-xl bg-sky-600 hover:bg-sky-500 font-display font-bold text-sm text-white transition flex items-center justify-center gap-2 whitespace-nowrap"
          >
            <Play className="w-4 h-4 fill-current" />
            <span>계속 비행하기</span>
          </button>

          <button
            type="button"
            onClick={onOpenThemeMenu}
            className="w-full min-h-[44px] py-3 px-5 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-400/50 font-display font-bold text-sm text-amber-300 transition flex items-center justify-center gap-2 whitespace-nowrap"
          >
            <Map className="w-4 h-4" />
            <span>비행 장소 변경 (T)</span>
          </button>

          <button
            type="button"
            onClick={onRestart}
            className="w-full min-h-[44px] py-3 px-5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 font-display font-bold text-sm text-slate-200 transition flex items-center justify-center gap-2 whitespace-nowrap"
          >
            <RotateCcw className="w-4 h-4" />
            <span>처음부터 다시 시작</span>
          </button>
        </div>
      </div>
    </div>
  );
}

interface GameOverModalProps {
  result: GameResult;
  onPlayAgain: () => void;
  onBackToMenu: () => void;
}

export function GameOverModal({
  result,
  onPlayAgain,
  onBackToMenu,
}: GameOverModalProps) {
  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-slate-950/80 p-4">
      <div className="hud-panel-elevated max-w-md w-full rounded-2xl p-6 sm:p-7 text-center">
        <div
          className={`text-xs font-semibold mb-1.5 ${
            result.isVictory ? 'text-emerald-400' : 'text-rose-400'
          }`}
        >
          {result.isVictory ? '코스 완주 성공' : '제한 시간 종료'}
          {result.isNewBest ? ' · 신기록 달성' : ''}
        </div>

        <h2 className="font-display text-2xl sm:text-3xl font-bold text-white mb-2">
          {result.isVictory ? '모든 링을 돌파했습니다' : '시간이 종료되었습니다'}
        </h2>
        <p className="text-slate-300 text-sm mb-6">
          {result.isVictory
            ? '정교한 코너링과 부스터 제어로 코스를 완주했습니다.'
            : '부스터(Space)와 360° 트릭(V)을 활용해 기록을 단축해 보세요.'}
        </p>

        <div className="rounded-xl bg-slate-900/90 border border-slate-800 p-4 mb-6 grid grid-cols-3 gap-2">
          <div>
            <div className="text-xs text-slate-400 mb-1">최종 점수</div>
            <div className="font-telemetry text-xl font-bold text-sky-400">
              {result.finalScore.toLocaleString()}
            </div>
          </div>
          <div>
            <div className="text-xs text-slate-400 mb-1">통과 링</div>
            <div className="font-telemetry text-xl font-bold text-amber-400">
              {result.ringsPassed}/{TOTAL_RINGS}
            </div>
          </div>
          <div>
            <div className="text-xs text-slate-400 mb-1">남은 시간</div>
            <div className="font-telemetry text-xl font-bold text-emerald-400">
              {result.timeLeft.toFixed(1)}s
            </div>
          </div>
        </div>

        <div className="space-y-2.5">
          <button
            type="button"
            onClick={onPlayAgain}
            className="w-full min-h-[46px] py-3.5 px-6 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 font-display font-bold text-sm tracking-wide text-white transition flex items-center justify-center gap-2 whitespace-nowrap"
          >
            <RotateCcw className="w-4 h-4" />
            <span>다시 도전하기</span>
          </button>
          <button
            type="button"
            onClick={onBackToMenu}
            className="w-full min-h-[42px] py-2.5 px-6 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 font-display font-bold text-sm text-slate-200 transition whitespace-nowrap"
          >
            모드 · 장소 선택 화면으로
          </button>
        </div>
      </div>
    </div>
  );
}
