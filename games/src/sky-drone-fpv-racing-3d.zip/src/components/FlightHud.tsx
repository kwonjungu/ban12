import { Camera, Map, Pause, Volume2, VolumeX } from 'lucide-react';
import { CameraMode, GameMode, HudTelemetry, TOTAL_RINGS } from '../game/types';
import { RadarDisplay } from './RadarDisplay';

interface FlightHudProps {
  mode: GameMode;
  cameraMode: CameraMode;
  soundEnabled: boolean;
  telemetry: HudTelemetry;
  toastMessage: string | null;
  onOpenThemeMenu: () => void;
  onToggleCamera: () => void;
  onToggleSound: () => void;
  onTogglePause: () => void;
}

export function FlightHud({
  mode,
  cameraMode,
  soundEnabled,
  telemetry,
  toastMessage,
  onOpenThemeMenu,
  onToggleCamera,
  onToggleSound,
  onTogglePause,
}: FlightHudProps) {
  return (
    <>
      {/* FPV Goggle Crosshair */}
      {cameraMode === 'fpv' && (
        <div className="pointer-events-none fixed inset-0 flex items-center justify-center z-10">
          <div className="relative w-16 h-16 flex items-center justify-center">
            <div className="w-10 h-10 rounded-full border border-sky-400/60" />
            <div className="absolute w-1.5 h-1.5 rounded-full bg-amber-400" />
            <div className="absolute left-0 w-2.5 h-0.5 bg-sky-400/80" />
            <div className="absolute right-0 w-2.5 h-0.5 bg-sky-400/80" />
            <div className="absolute top-0 h-2.5 w-0.5 bg-sky-400/80" />
            <div className="absolute bottom-0 h-2.5 w-0.5 bg-sky-400/80" />
          </div>
        </div>
      )}

      {/* Event Toast Notification */}
      {toastMessage && (
        <div className="pointer-events-none fixed top-20 left-1/2 -translate-x-1/2 z-30">
          <div className="hud-panel px-4 py-1.5 rounded-lg text-amber-300 font-display font-bold text-sm tracking-wide whitespace-nowrap">
            {toastMessage}
          </div>
        </div>
      )}

      {/* Top Floating Telemetry & Controls */}
      <div className="pointer-events-none fixed top-0 left-0 right-0 p-2.5 sm:p-4 flex justify-between items-start gap-2 z-20">
        {/* Top-Left: Score, Rings, Timer & Flight Telemetry */}
        <div className="flex flex-col gap-1.5 sm:gap-2 min-w-0">
          <div className="hud-panel rounded-xl px-2.5 py-1.5 sm:px-3.5 sm:py-2 flex items-center gap-2.5 sm:gap-5">
            <div>
              <div className="text-[10px] sm:text-[11px] font-medium text-sky-300/90 leading-none mb-1">
                점수
              </div>
              <div className="font-telemetry text-sm sm:text-2xl font-bold text-white leading-none">
                {telemetry.score.toLocaleString()}
              </div>
            </div>
            <div className="h-6 sm:h-7 w-px bg-slate-700" />
            <div>
              <div className="text-[10px] sm:text-[11px] font-medium text-amber-300/90 leading-none mb-1">
                링
              </div>
              <div className="font-telemetry text-sm sm:text-2xl font-bold text-amber-400 leading-none whitespace-nowrap">
                {mode === 'race'
                  ? `${telemetry.ringsPassed}/${TOTAL_RINGS}`
                  : `${telemetry.ringsPassed}`}
              </div>
            </div>
            <div className="h-6 sm:h-7 w-px bg-slate-700" />
            <div>
              <div className="text-[10px] sm:text-[11px] font-medium text-emerald-300/90 leading-none mb-1">
                시간
              </div>
              <div
                className={`font-telemetry text-sm sm:text-2xl font-bold leading-none whitespace-nowrap ${
                  mode === 'race' && telemetry.timeLeft < 10
                    ? 'text-rose-400'
                    : 'text-emerald-400'
                }`}
              >
                {mode === 'race' ? `${telemetry.timeLeft.toFixed(1)}s` : '자유'}
              </div>
            </div>
          </div>

          <div className="hud-panel rounded-lg px-2.5 py-1 sm:px-3 sm:py-1.5 flex items-center gap-2 sm:gap-3 text-[11px] sm:text-xs">
            <div className="flex items-baseline gap-1 whitespace-nowrap">
              <span className="text-slate-400">속도</span>
              <span className="font-telemetry font-bold text-sky-300">
                {telemetry.speedKmh}
              </span>
              <span className="text-[10px] text-slate-400 hidden sm:inline">km/h</span>
            </div>
            <div className="flex items-baseline gap-1 whitespace-nowrap">
              <span className="text-slate-400">고도</span>
              <span className="font-telemetry font-bold text-sky-300">
                {telemetry.altitudeM}
              </span>
              <span className="text-[10px] text-slate-400 hidden sm:inline">m</span>
            </div>
            <div className="flex items-center gap-1.5 flex-1 min-w-[52px]">
              <span className="text-amber-400 font-semibold text-[10px] sm:text-[11px] whitespace-nowrap">
                부스트
              </span>
              <div className="w-12 sm:w-24 h-2 bg-slate-800 rounded-sm overflow-hidden border border-slate-700">
                <div
                  className="h-full bg-gradient-to-r from-amber-500 to-yellow-300 transition-[width] duration-75"
                  style={{ width: `${telemetry.boostEnergy}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Top-Right: Controls & Checkpoint Radar */}
        <div className="flex flex-col items-end gap-1.5 sm:gap-2 shrink-0">
          <div className="pointer-events-auto flex items-center gap-1 sm:gap-1.5">
            <button
              type="button"
              onClick={onOpenThemeMenu}
              className="hud-panel hover:bg-slate-800/90 active:scale-95 min-h-[40px] min-w-[40px] px-2.5 sm:px-3 py-2 rounded-lg text-xs sm:text-sm font-semibold text-amber-300 transition flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0"
              title="장소 변경 (T)"
              aria-label="장소 변경"
            >
              <Map className="w-4 h-4 shrink-0" />
              <span className="hidden sm:inline">장소 변경</span>
            </button>

            <button
              type="button"
              onClick={onToggleCamera}
              className="hud-panel hover:bg-slate-800/90 active:scale-95 min-h-[40px] min-w-[40px] px-2.5 sm:px-3 py-2 rounded-lg text-xs sm:text-sm font-semibold text-sky-200 transition flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0"
              title="시점 전환 (C)"
              aria-label="시점 전환"
            >
              <Camera className="w-4 h-4 shrink-0" />
              <span className="hidden sm:inline">
                {cameraMode === 'fpv' ? 'FPV 1인칭' : '3인칭'}
              </span>
            </button>

            <button
              type="button"
              onClick={onToggleSound}
              className="hud-panel hover:bg-slate-800/90 active:scale-95 min-h-[40px] min-w-[40px] p-2 rounded-lg text-sky-200 transition flex items-center justify-center shrink-0"
              title="사운드 켜기/끄기"
              aria-label={soundEnabled ? '사운드 끄기' : '사운드 켜기'}
            >
              {soundEnabled ? (
                <Volume2 className="w-4 h-4" />
              ) : (
                <VolumeX className="w-4 h-4 text-slate-400" />
              )}
            </button>

            <button
              type="button"
              onClick={onTogglePause}
              className="hud-panel hover:bg-slate-800/90 active:scale-95 min-h-[40px] min-w-[40px] p-2 rounded-lg text-sky-200 transition flex items-center justify-center shrink-0"
              title="일시정지 (P)"
              aria-label="일시정지"
            >
              <Pause className="w-4 h-4" />
            </button>
          </div>

          <RadarDisplay
            relativeTargetX={telemetry.relativeTargetX}
            relativeTargetZ={telemetry.relativeTargetZ}
            targetDistanceM={telemetry.targetDistanceM}
          />
        </div>
      </div>

      {/* Desktop Bottom Key Guide Strip */}
      <div className="pointer-events-none fixed bottom-3 left-1/2 -translate-x-1/2 z-20 hidden md:flex items-center gap-2.5 hud-panel px-4 py-1.5 rounded-lg text-xs text-slate-300 whitespace-nowrap">
        <span>
          <strong className="text-sky-400">W/S</strong> 상승·하강
        </span>
        <span aria-hidden="true" className="text-slate-600">
          ·
        </span>
        <span>
          <strong className="text-sky-400">A/D</strong> 좌우회전
        </span>
        <span aria-hidden="true" className="text-slate-600">
          ·
        </span>
        <span>
          <strong className="text-sky-400">방향키</strong> 전후좌우
        </span>
        <span aria-hidden="true" className="text-slate-600">
          ·
        </span>
        <span>
          <strong className="text-amber-400">Space</strong> 부스터
        </span>
        <span aria-hidden="true" className="text-slate-600">
          ·
        </span>
        <span>
          <strong className="text-purple-400">V</strong> 360° 트릭
        </span>
        <span aria-hidden="true" className="text-slate-600">
          ·
        </span>
        <span>
          <strong className="text-emerald-400">C</strong> 시점
        </span>
        <span aria-hidden="true" className="text-slate-600">
          ·
        </span>
        <span>
          <strong className="text-amber-300">T</strong> 장소변경
        </span>
      </div>
    </>
  );
}
