import React, { useEffect, useRef, useState, useCallback } from 'react';
import { GameState, TowerBlock, ActiveBlock, DebrisBlock, Particle } from './types';
import { STAGES, BLOCK_HEIGHT, BASE_WIDTH, MAX_LIVES, ASSET_IMAGES } from './constants';
import { sounds } from './audio';
import { GameHUD } from './components/GameHUD';
import { StartModal } from './components/StartModal';
import { StageClearModal } from './components/StageClearModal';
import { GameOverModal } from './components/GameOverModal';

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Backdrop image asset loaded in memory for canvas parallax rendering
  const backdropImgRef = useRef<HTMLImageElement | null>(null);
  const [backdropLoaded, setBackdropLoaded] = useState(false);

  // React State for UI
  const [gameState, setGameState] = useState<GameState>('menu');
  const [stageIdx, setStageIdx] = useState(0);
  const [floors, setFloors] = useState(0);
  const [stageFloors, setStageFloors] = useState(0);
  const [score, setScore] = useState(0);
  const [lives, setLives] = useState(MAX_LIVES);
  const [combo, setCombo] = useState(0);
  const [maxCombo, setMaxCombo] = useState(0);
  const [bestFloor, setBestFloor] = useState(0);
  const [bestScore, setBestScore] = useState(0);
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const [isMuted, setIsMuted] = useState(sounds.isMuted());

  // Game Engine Mutable Refs (to avoid re-renders during high-frequency 60fps loop)
  const engineRef = useRef({
    state: 'menu' as GameState,
    stageIdx: 0,
    stageFloors: 0,
    score: 0,
    lives: MAX_LIVES,
    combo: 0,
    maxCombo: 0,
    tower: [] as TowerBlock[],
    activeBlock: null as ActiveBlock | null,
    debris: [] as DebrisBlock[],
    particles: [] as Particle[],
    camY: 0,
    targetCamY: 0,
    width: window.innerWidth,
    height: window.innerHeight,
    dpr: window.devicePixelRatio || 1,
    toastTimer: null as ReturnType<typeof setTimeout> | null,
  });

  // Load High Scores from localStorage
  useEffect(() => {
    try {
      const savedFloor = localStorage.getItem('stack2d_best_floor');
      const savedScore = localStorage.getItem('stack2d_best_score');
      if (savedFloor) setBestFloor(parseInt(savedFloor, 10));
      if (savedScore) setBestScore(parseInt(savedScore, 10));
    } catch {
      // ignore
    }

    // Preload Backdrop Image
    const img = new Image();
    img.src = ASSET_IMAGES.backdrop;
    img.onload = () => {
      backdropImgRef.current = img;
      setBackdropLoaded(true);
    };
  }, []);

  const triggerToast = useCallback((msg: string) => {
    setToastMsg(msg);
    if (engineRef.current.toastTimer) clearTimeout(engineRef.current.toastTimer);
    engineRef.current.toastTimer = setTimeout(() => {
      setToastMsg(null);
    }, 1800);
  }, []);

  const currentStage = STAGES[Math.min(stageIdx, STAGES.length - 1)];

  // Helper: Calculate responsive speed (consistent screen travel duration across mobile and desktop)
  const getBlockSpeed = useCallback((stageBaseSpeed: number, levelInStage: number) => {
    const { width } = engineRef.current;
    // Across any device, moving across screen should take between 1.6 to 2.4 seconds based on speed
    const baseTravelDuration = 2.4 / (stageBaseSpeed / 3.0);
    const speedPerSecond = width / Math.max(0.8, baseTravelDuration);
    const speedPerFrame = (speedPerSecond / 60) * (1 + (levelInStage % 15) * 0.02);
    return Math.max(3.5, speedPerFrame);
  }, []);

  // Helper: Spawn next moving block
  const spawnNextBlock = useCallback(() => {
    const eng = engineRef.current;
    if (eng.tower.length === 0) return;

    const top = eng.tower[eng.tower.length - 1];
    const stg = STAGES[Math.min(eng.stageIdx, STAGES.length - 1)];
    const level = eng.tower.length;

    const hue = (stg.bgHue + level * 8) % 360;
    const speed = getBlockSpeed(stg.baseSpeed, eng.stageFloors);
    const y = top.y - BLOCK_HEIGHT;

    eng.activeBlock = {
      x: 0,
      y,
      w: top.w,
      dir: 1,
      speed,
      hue,
    };
  }, [getBlockSpeed]);

  // Helper: Reset Game State
  const resetGame = useCallback((resetAllStages = true) => {
    const eng = engineRef.current;
    if (resetAllStages) {
      eng.stageIdx = 0;
      setStageIdx(0);
      eng.score = 0;
      setScore(0);
    }
    eng.stageFloors = 0;
    setStageFloors(0);
    eng.combo = 0;
    setCombo(0);
    eng.maxCombo = 0;
    setMaxCombo(0);
    eng.lives = MAX_LIVES;
    setLives(MAX_LIVES);

    eng.tower = [];
    eng.debris = [];
    eng.particles = [];

    const stg = STAGES[Math.min(eng.stageIdx, STAGES.length - 1)];
    const baseY = eng.height - 130;
    const baseX = (eng.width - BASE_WIDTH) / 2;

    eng.tower.push({
      x: baseX,
      y: baseY,
      w: BASE_WIDTH,
      hue: stg.bgHue,
    });

    eng.camY = 0;
    eng.targetCamY = 0;

    setFloors(0);
    spawnNextBlock();
  }, [spawnNextBlock]);

  // Handle Game Over
  const handleGameOver = useCallback(() => {
    const eng = engineRef.current;
    eng.state = 'over';
    setGameState('over');
    sounds.sndOver();

    const totalFloors = Math.max(0, eng.tower.length - 1);
    setFloors(totalFloors);

    try {
      const curBestFloor = parseInt(localStorage.getItem('stack2d_best_floor') || '0', 10);
      const curBestScore = parseInt(localStorage.getItem('stack2d_best_score') || '0', 10);
      if (totalFloors > curBestFloor) {
        localStorage.setItem('stack2d_best_floor', String(totalFloors));
        setBestFloor(totalFloors);
      }
      if (eng.score > curBestScore) {
        localStorage.setItem('stack2d_best_score', String(eng.score));
        setBestScore(eng.score);
      }
    } catch {
      // ignore
    }
  }, []);

  // Handle Stage Clear
  const handleStageClear = useCallback(() => {
    const eng = engineRef.current;
    eng.state = 'stage_clear';
    setGameState('stage_clear');
    sounds.sndStageClear();

    const bonus = (eng.stageIdx + 1) * 1000;
    eng.score += bonus;
    setScore(eng.score);
  }, []);

  // Helper: Particle Spawner
  const spawnParticles = (x: number, y: number, hue: number) => {
    const eng = engineRef.current;
    for (let i = 0; i < 20; i++) {
      const angle = Math.random() * Math.PI * 2;
      const spd = 2 + Math.random() * 4.5;
      eng.particles.push({
        x,
        y,
        vx: Math.cos(angle) * spd,
        vy: Math.sin(angle) * spd,
        hue,
        life: 1.0,
        size: 3 + Math.random() * 3,
      });
    }
  };

  // Helper: Debris Spawner
  const createDebris = (x: number, y: number, w: number, hue: number, vx: number) => {
    const eng = engineRef.current;
    eng.debris.push({
      x,
      y,
      w,
      hue,
      vx,
      vy: -2.5,
      rot: 0,
      vRot: (Math.random() - 0.5) * 0.12,
    });
  };

  // Drop Active Moving Block
  const dropBlock = useCallback(() => {
    const eng = engineRef.current;
    if (eng.state !== 'playing' || !eng.activeBlock || eng.tower.length === 0) return;

    const top = eng.tower[eng.tower.length - 1];
    const curX = eng.activeBlock.x;
    const curW = eng.activeBlock.w;
    const delta = curX - top.x;
    const absDelta = Math.abs(delta);
    const perfEps = 5; // Perfect threshold (px)

    if (absDelta <= perfEps) {
      // --- PERFECT PLACEMENT ---
      eng.combo++;
      if (eng.combo > eng.maxCombo) eng.maxCombo = eng.combo;
      setCombo(eng.combo);
      setMaxCombo(eng.maxCombo);

      // Block slight growth bonus on combo
      const grow = Math.min(eng.combo * 4, 16);
      const newW = Math.min(BASE_WIDTH, top.w + grow);
      const newX = top.x - (newW - top.w) / 2;

      const gain = 60 + eng.combo * 30;
      eng.score += gain;
      eng.stageFloors++;

      setScore(eng.score);
      setStageFloors(eng.stageFloors);
      setFloors(eng.tower.length);

      eng.tower.push({
        x: newX,
        y: eng.activeBlock.y,
        w: newW,
        hue: eng.activeBlock.hue,
      });

      spawnParticles(newX + newW / 2, eng.activeBlock.y + BLOCK_HEIGHT / 2, eng.activeBlock.hue);
      sounds.sndPerfect(eng.combo - 1);
    } else if (absDelta >= curW) {
      // --- COMPLETE MISS ---
      createDebris(curX, eng.activeBlock.y, curW, eng.activeBlock.hue, delta > 0 ? 4 : -4);
      eng.activeBlock = null;

      eng.lives--;
      eng.combo = 0;
      setLives(eng.lives);
      setCombo(0);

      sounds.sndLifeLost();
      triggerToast(`💔 목숨 -1! (남은 목숨: ${eng.lives})`);

      if (eng.lives <= 0) {
        handleGameOver();
        return;
      } else {
        spawnNextBlock();
        return;
      }
    } else {
      // --- SLICE BLOCK ---
      eng.combo = 0;
      setCombo(0);

      const newW = curW - absDelta;
      const newX = delta > 0 ? curX : top.x;

      const debrisW = absDelta;
      const debrisX = delta > 0 ? curX + newW : curX;
      createDebris(debrisX, eng.activeBlock.y, debrisW, eng.activeBlock.hue, delta > 0 ? 3 : -3);

      eng.score += 20;
      eng.stageFloors++;
      setScore(eng.score);
      setStageFloors(eng.stageFloors);
      setFloors(eng.tower.length);

      eng.tower.push({
        x: newX,
        y: eng.activeBlock.y,
        w: newW,
        hue: eng.activeBlock.hue,
      });

      sounds.sndPlace();
      sounds.sndCut();
    }

    eng.activeBlock = null;

    // Smooth camera follow target
    if (eng.tower.length > 7) {
      eng.targetCamY = (eng.tower.length - 7) * BLOCK_HEIGHT;
    }

    const stg = STAGES[Math.min(eng.stageIdx, STAGES.length - 1)];
    if (eng.stageFloors >= stg.targetFloors && eng.stageIdx < STAGES.length - 1) {
      handleStageClear();
      return;
    }

    spawnNextBlock();
  }, [handleGameOver, handleStageClear, spawnNextBlock, triggerToast]);

  // Safe Rounded Rectangle Drawer
  const drawRoundedRect = (
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    w: number,
    h: number,
    r: number
  ) => {
    if (typeof ctx.roundRect === 'function') {
      ctx.beginPath();
      ctx.roundRect(x, y, w, h, [r, r, 0, 0]);
      ctx.fill();
    } else {
      ctx.beginPath();
      ctx.moveTo(x + r, y);
      ctx.lineTo(x + w - r, y);
      ctx.quadraticCurveTo(x + w, y, x + w, y + r);
      ctx.lineTo(x + w, y + h);
      ctx.lineTo(x, y + h);
      ctx.lineTo(x, y + r);
      ctx.quadraticCurveTo(x, y, x + r, y);
      ctx.closePath();
      ctx.fill();
    }
  };

  // Main 60fps Canvas Render Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;

    const handleResize = () => {
      const w = window.innerWidth;
      const h = window.innerHeight;
      const dpr = window.devicePixelRatio || 1;

      engineRef.current.width = w;
      engineRef.current.height = h;
      engineRef.current.dpr = dpr;

      canvas.width = Math.floor(w * dpr);
      canvas.height = Math.floor(h * dpr);
      canvas.style.width = `${w}px`;
      canvas.style.height = `${h}px`;
    };

    window.addEventListener('resize', handleResize);
    handleResize();

    const render = () => {
      const eng = engineRef.current;
      const { width, height, dpr } = eng;

      // Reset transform cleanly each frame to prevent accumulation bug!
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, width, height);

      // --- 1. BACKDROP & PARALLAX RENDERING ---
      const stg = STAGES[Math.min(eng.stageIdx, STAGES.length - 1)];

      if (backdropImgRef.current && backdropImgRef.current.complete) {
        // Draw Generated Backdrop with smooth parallax scrolling
        const img = backdropImgRef.current;
        // Parallax offset based on camY
        const parallaxSpeed = 0.25;
        const scrollOffset = (eng.camY * parallaxSpeed) % height;

        // Draw image covering screen
        ctx.globalAlpha = 0.85;
        ctx.drawImage(img, 0, -scrollOffset, width, height * 1.5);
        ctx.globalAlpha = 1.0;

        // Stage atmospheric tint gradient overlay
        const tintGrad = ctx.createLinearGradient(0, 0, 0, height);
        tintGrad.addColorStop(0, `hsla(${stg.bgHue}, 60%, 8%, 0.7)`);
        tintGrad.addColorStop(0.6, `hsla(${stg.bgHue + 15}, 50%, 12%, 0.5)`);
        tintGrad.addColorStop(1, `hsla(${stg.bgHue + 30}, 60%, 6%, 0.85)`);
        ctx.fillStyle = tintGrad;
        ctx.fillRect(0, 0, width, height);
      } else {
        // Fallback smooth gradient
        const bgGrad = ctx.createLinearGradient(0, 0, 0, height);
        bgGrad.addColorStop(0, `hsl(${stg.bgHue}, 45%, 8%)`);
        bgGrad.addColorStop(1, `hsl(${stg.bgHue + 30}, 55%, 14%)`);
        ctx.fillStyle = bgGrad;
        ctx.fillRect(0, 0, width, height);
      }

      // Smooth Camera follow lerp
      eng.camY += (eng.targetCamY - eng.camY) * 0.1;

      ctx.save();
      ctx.translate(0, eng.camY);

      // --- 2. TOWER BLOCKS ---
      for (let i = 0; i < eng.tower.length; i++) {
        const b = eng.tower[i];

        // Block Face Gradient
        const bGrad = ctx.createLinearGradient(b.x, b.y, b.x, b.y + BLOCK_HEIGHT);
        bGrad.addColorStop(0, `hsl(${b.hue}, 85%, 68%)`);
        bGrad.addColorStop(1, `hsl(${b.hue}, 75%, 48%)`);

        ctx.fillStyle = bGrad;
        drawRoundedRect(ctx, b.x, b.y, b.w, BLOCK_HEIGHT, 4);

        // Top glossy highlight reflection
        ctx.fillStyle = 'rgba(255, 255, 255, 0.45)';
        ctx.fillRect(b.x + 2, b.y + 1, Math.max(0, b.w - 4), 3);

        // Bottom 3D shadow line
        ctx.fillStyle = 'rgba(0, 0, 0, 0.25)';
        ctx.fillRect(b.x, b.y + BLOCK_HEIGHT - 3, b.w, 3);
      }

      // --- 3. ACTIVE MOVING BLOCK ---
      if (eng.state === 'playing' && eng.activeBlock) {
        const ab = eng.activeBlock;
        ab.x += ab.dir * ab.speed;

        // Bounce back smoothly on wall collision
        if (ab.x + ab.w > width) {
          ab.x = width - ab.w;
          ab.dir = -1;
        } else if (ab.x < 0) {
          ab.x = 0;
          ab.dir = 1;
        }

        const aGrad = ctx.createLinearGradient(ab.x, ab.y, ab.x, ab.y + BLOCK_HEIGHT);
        aGrad.addColorStop(0, `hsl(${ab.hue}, 95%, 72%)`);
        aGrad.addColorStop(1, `hsl(${ab.hue}, 85%, 52%)`);

        ctx.fillStyle = aGrad;
        drawRoundedRect(ctx, ab.x, ab.y, ab.w, BLOCK_HEIGHT, 4);

        // Active block highlight & glow
        ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
        ctx.fillRect(ab.x + 2, ab.y + 1, Math.max(0, ab.w - 4), 3);
      }

      // --- 4. FALLING DEBRIS ---
      for (let d = eng.debris.length - 1; d >= 0; d--) {
        const deb = eng.debris[d];
        deb.vy += 0.45; // Gravity
        deb.x += deb.vx;
        deb.y += deb.vy;
        deb.rot += deb.vRot;

        ctx.save();
        ctx.translate(deb.x + deb.w / 2, deb.y + BLOCK_HEIGHT / 2);
        ctx.rotate(deb.rot);

        ctx.fillStyle = `hsl(${deb.hue}, 65%, 45%)`;
        ctx.fillRect(-deb.w / 2, -BLOCK_HEIGHT / 2, deb.w, BLOCK_HEIGHT);

        ctx.restore();

        // Cull debris below screen
        if (deb.y > height + eng.camY + 150) {
          eng.debris.splice(d, 1);
        }
      }

      // --- 5. PARTICLES ---
      for (let p = eng.particles.length - 1; p >= 0; p--) {
        const pt = eng.particles[p];
        pt.x += pt.vx;
        pt.y += pt.vy;
        pt.life -= 0.03;

        if (pt.life <= 0) {
          eng.particles.splice(p, 1);
          continue;
        }

        const rad = Math.max(0, pt.size * pt.life);
        ctx.fillStyle = `hsla(${pt.hue}, 100%, 75%, ${pt.life})`;
        ctx.beginPath();
        ctx.arc(pt.x, pt.y, rad, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.restore();

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animId);
    };
  }, []);

  // Keyboard Spacebar Drop
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space') {
        e.preventDefault();
        sounds.init();
        if (engineRef.current.state === 'playing') {
          dropBlock();
        }
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [dropBlock]);

  // Pointer Click on Canvas
  const handlePointerDown = (e: React.PointerEvent) => {
    // Only trigger drop when playing and not clicking modal buttons
    sounds.init();
    if (engineRef.current.state === 'playing') {
      dropBlock();
    }
  };

  // Start Game Button Handler
  const handleStartGame = () => {
    sounds.init();
    engineRef.current.state = 'playing';
    setGameState('playing');
    resetGame(true);
    sounds.sndStart();
  };

  // Next Stage Button Handler
  const handleNextStage = () => {
    sounds.init();
    const nextIdx = engineRef.current.stageIdx + 1;
    engineRef.current.stageIdx = nextIdx;
    engineRef.current.stageFloors = 0;
    engineRef.current.state = 'playing';

    setStageIdx(nextIdx);
    setStageFloors(0);
    setGameState('playing');

    sounds.sndStart();
    triggerToast(`${STAGES[nextIdx].name} 진입! 🚀`);
    spawnNextBlock();
  };

  // Retry Stage Button Handler
  const handleRetryStage = () => {
    sounds.init();
    engineRef.current.state = 'playing';
    setGameState('playing');
    resetGame(false);
    sounds.sndStart();
  };

  // Restart from Stage 1 Handler
  const handleRestartAll = () => {
    sounds.init();
    engineRef.current.state = 'playing';
    setGameState('playing');
    resetGame(true);
    sounds.sndStart();
  };

  // Sound Toggle Handler
  const handleToggleMute = () => {
    sounds.init();
    const muted = sounds.toggleMute();
    setIsMuted(muted);
    triggerToast(muted ? '🔇 음소거 설정' : '🔊 사운드 켜짐');
  };

  const nextStage = STAGES[Math.min(stageIdx + 1, STAGES.length - 1)];

  return (
    <div
      id="stack-tower-container"
      className="relative w-screen h-screen overflow-hidden bg-slate-950 font-sans select-none"
      onPointerDown={handlePointerDown}
    >
      {/* Game Canvas */}
      <canvas
        id="gameCanvas"
        ref={canvasRef}
        className="block w-full h-full absolute inset-0 z-[1] cursor-pointer"
      />

      {/* In-Game HUD Overlay */}
      <GameHUD
        currentStage={currentStage}
        stageIdx={stageIdx}
        totalStages={STAGES.length}
        floors={floors}
        score={score}
        lives={lives}
        maxLives={MAX_LIVES}
        bestFloor={bestFloor}
        stageFloors={stageFloors}
        combo={combo}
        toastMsg={toastMsg}
        isMuted={isMuted}
        onToggleMute={handleToggleMute}
      />

      {/* Modals with Asset Integrations */}
      {gameState === 'menu' && (
        <StartModal
          bestFloor={bestFloor}
          bestScore={bestScore}
          onStartGame={handleStartGame}
        />
      )}

      {gameState === 'stage_clear' && (
        <StageClearModal
          completedStage={currentStage}
          nextStage={nextStage}
          stageIdx={stageIdx}
          bonus={(stageIdx + 1) * 1000}
          onNextStage={handleNextStage}
        />
      )}

      {gameState === 'over' && (
        <GameOverModal
          floors={floors}
          score={score}
          bestFloor={bestFloor}
          maxCombo={maxCombo}
          currentStageName={currentStage.name}
          onRetryStage={handleRetryStage}
          onRestartAll={handleRestartAll}
        />
      )}
    </div>
  );
}
