class SoundManager {
  private ac: AudioContext | null = null;
  private muted: boolean = false;

  constructor() {
    try {
      const saved = localStorage.getItem('stack2d_muted');
      if (saved === '1') this.muted = true;
    } catch {
      // ignore
    }
  }

  public init() {
    if (!this.ac) {
      const Ctor = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (Ctor) {
        this.ac = new Ctor();
      }
    }
    if (this.ac && this.ac.state === 'suspended') {
      this.ac.resume().catch(() => {});
    }
  }

  public isMuted(): boolean {
    return this.muted;
  }

  public toggleMute(): boolean {
    this.muted = !this.muted;
    try {
      localStorage.setItem('stack2d_muted', this.muted ? '1' : '0');
    } catch {
      // ignore
    }
    return this.muted;
  }

  private tone(freq: number, dur: number, type: OscillatorType, vol: number, delay = 0, slideTo?: number) {
    if (!this.ac || this.muted) return;
    try {
      const t0 = this.ac.currentTime + delay;
      const o = this.ac.createOscillator();
      const g = this.ac.createGain();

      o.type = type;
      o.frequency.setValueAtTime(freq, t0);
      if (slideTo) {
        o.frequency.exponentialRampToValueAtTime(Math.max(30, slideTo), t0 + dur);
      }

      g.gain.setValueAtTime(0.0001, t0);
      g.gain.exponentialRampToValueAtTime(Math.max(0.001, vol), t0 + 0.01);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);

      o.connect(g);
      g.connect(this.ac.destination);

      o.start(t0);
      o.stop(t0 + dur + 0.05);
    } catch {
      // audio error handling
    }
  }

  public sndPerfect(comboIdx: number) {
    const scale = [0, 2, 4, 5, 7, 9, 11, 12, 14, 16, 17, 19, 21, 24];
    const st = scale[Math.min(comboIdx, scale.length - 1)];
    const baseFreq = 523.25; // C5
    const f = baseFreq * Math.pow(2, st / 12);
    this.tone(f, 0.22, 'triangle', 0.24, 0);
    this.tone(f * 2, 0.18, 'sine', 0.12, 0.02);
  }

  public sndPlace() {
    this.tone(280, 0.09, 'square', 0.12, 0, 150);
  }

  public sndCut() {
    this.tone(170, 0.13, 'sawtooth', 0.15, 0, 80);
  }

  public sndStart() {
    this.tone(440, 0.1, 'triangle', 0.2, 0);
    this.tone(660, 0.15, 'triangle', 0.22, 0.08);
  }

  public sndStageClear() {
    this.tone(523.25, 0.12, 'triangle', 0.25, 0);
    this.tone(659.25, 0.12, 'triangle', 0.25, 0.1);
    this.tone(783.99, 0.14, 'triangle', 0.25, 0.2);
    this.tone(1046.5, 0.38, 'sine', 0.3, 0.32);
  }

  public sndOver() {
    this.tone(300, 0.45, 'sawtooth', 0.22, 0, 60);
  }

  public sndLifeLost() {
    this.tone(220, 0.25, 'sawtooth', 0.2, 0, 90);
  }
}

export const sounds = new SoundManager();
