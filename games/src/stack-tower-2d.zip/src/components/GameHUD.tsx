import React from 'react';
import { Volume2, VolumeX, Crown, Sparkles } from 'lucide-react';
import { Stage } from '../types';

interface GameHUDProps {
  currentStage: Stage;
  stageIdx: number;
  totalStages: number;
  floors: number;
  score: number;
  lives: number;
  maxLives: number;
  bestFloor: number;
  stageFloors: number;
  combo: number;
  toastMsg: string | null;
  isMuted: boolean;
  onToggleMute: () => void;
}

export const GameHUD: React.FC<GameHUDProps> = ({
  currentStage,
  stageIdx,
  totalStages,
  floors,
  score,
  lives,
  maxLives,
  bestFloor,
  stageFloors,
  combo,
  toastMsg,
  isMuted,
  onToggleMute,
}) => {
  const isInfinite = currentStage.targetFloors >= 999;
  const progressPct = isInfinite
    ? 100
    : Math.min(100, (stageFloors / currentStage.targetFloors) * 100);

  return (
    <div id="game-hud-root" className="absolute inset-0 z-10 pointer-events-none flex flex-col justify-between p-3.5 sm:p-5">
      {/* Top Header Bar */}
      <div className="flex items-start justify-between w-full max-w-xl mx-auto gap-2">
        {/* Left: Stage, Score & Lives */}
        <div className="flex flex-col gap-1.5">
          <div className="bg-slate-900/75 backdrop-blur-md border border-white/15 px-3 py-1 rounded-full flex items-center gap-2 w-fit shadow-lg shadow-black/20">
            <span className="text-xs font-black text-cyan-400">
              {stageIdx + 1}/{totalStages}
            </span>
            <span className="text-xs font-bold text-white tracking-tight">
              {currentStage.name}
            </span>
          </div>

          <div className="flex items-baseline gap-2.5">
            <span className="text-3xl sm:text-4xl font-black text-white drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)] tracking-tight">
              {floors}
              <span className="text-lg font-bold text-slate-300 ml-0.5">층</span>
            </span>
            <span className="text-sm sm:text-base font-extrabold text-amber-400 drop-shadow">
              {score.toLocaleString()}점
            </span>
          </div>

          {/* 5 Lives Hearts Display */}
          <div className="flex items-center gap-1">
            {Array.from({ length: maxLives }).map((_, i) => (
              <span
                key={i}
                className={`text-base sm:text-lg transition-transform duration-200 ${
                  i < lives
                    ? 'scale-100 filter drop-shadow-[0_0_6px_rgba(239,68,68,0.7)]'
                    : 'opacity-30 grayscale scale-90'
                }`}
              >
                ❤️
              </span>
            ))}
          </div>
        </div>

        {/* Right: Sound Control & Best Record */}
        <div className="flex flex-col items-end gap-2">
          <button
            id="btn-hud-mute"
            onClick={onToggleMute}
            className="pointer-events-auto bg-slate-900/75 hover:bg-slate-800/90 text-white backdrop-blur-md border border-white/15 w-9 h-9 sm:w-10 sm:h-10 rounded-full flex items-center justify-center shadow-lg transition active:scale-95 cursor-pointer"
            aria-label={isMuted ? '음소거 해제' : '음소거'}
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-slate-400" /> : <Volume2 className="w-4 h-4 text-cyan-300" />}
          </button>

          <div className="bg-slate-900/75 backdrop-blur-md border border-white/15 px-3 py-1 rounded-full text-right shadow-lg flex items-center gap-1.5">
            <Crown className="w-3.5 h-3.5 text-amber-400" />
            <div>
              <div className="text-[9px] text-slate-400 font-semibold leading-tight">최고 기록</div>
              <div className="text-xs font-black text-amber-300 leading-tight">{bestFloor}층</div>
            </div>
          </div>
        </div>
      </div>

      {/* Stage Progress Bar (Center Top) */}
      {!isInfinite && (
        <div className="w-full max-w-xs mx-auto flex flex-col items-center gap-1 my-1">
          <div className="w-full h-2 bg-slate-900/80 rounded-full overflow-hidden border border-white/15 shadow-inner">
            <div
              className="h-full bg-gradient-to-r from-cyan-400 via-sky-400 to-amber-300 transition-all duration-300 rounded-full"
              style={{ width: `${progressPct}%` }}
            />
          </div>
          <span className="text-[11px] font-bold text-slate-300 drop-shadow flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-cyan-300" />
            목표 {stageFloors}/{currentStage.targetFloors}층
          </span>
        </div>
      )}

      {/* Combo & Toast Center Popups */}
      <div className="flex flex-col items-center justify-center gap-2 my-auto">
        {combo >= 2 && (
          <div className="text-2xl sm:text-4xl font-black text-amber-300 drop-shadow-[0_0_20px_rgba(251,191,36,0.8)] animate-bounce tracking-tight bg-slate-950/60 backdrop-blur-md px-5 py-2 rounded-2xl border border-amber-400/40">
            🔥 PERFECT x{combo}
          </div>
        )}

        {toastMsg && (
          <div className="bg-slate-900/90 text-white backdrop-blur-md border border-white/20 px-4 py-2 rounded-full text-xs sm:text-sm font-bold shadow-2xl transition-all animate-pulse">
            {toastMsg}
          </div>
        )}
      </div>

      {/* Bottom Control Hint */}
      <div className="text-center text-[11px] sm:text-xs text-slate-300 font-medium mb-1 drop-shadow bg-slate-950/40 backdrop-blur-sm py-1.5 px-3 rounded-full mx-auto border border-white/10">
        화면 탭 또는 Space 키로 블록 쌓기
      </div>
    </div>
  );
};
