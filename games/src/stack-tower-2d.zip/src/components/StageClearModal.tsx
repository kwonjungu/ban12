import React from 'react';
import { ArrowRight, Sparkles, CheckCircle2 } from 'lucide-react';
import { Stage } from '../types';
import { ASSET_IMAGES, STAGES } from '../constants';

interface StageClearModalProps {
  completedStage: Stage;
  nextStage: Stage;
  stageIdx: number;
  bonus: number;
  onNextStage: () => void;
}

export const StageClearModal: React.FC<StageClearModalProps> = ({
  completedStage,
  nextStage,
  stageIdx,
  bonus,
  onNextStage,
}) => {
  return (
    <div className="absolute inset-0 z-20 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
      <div className="w-full max-w-sm rounded-3xl bg-slate-900/90 border border-amber-500/30 p-6 flex flex-col items-center text-center shadow-2xl shadow-amber-950/40">
        {/* Trophy Asset Image */}
        <div className="relative mb-2">
          <div className="absolute -inset-1 bg-gradient-to-r from-amber-400 to-orange-500 rounded-full blur-md opacity-60"></div>
          <img
            src={ASSET_IMAGES.trophy}
            alt="클리어 트로피"
            referrerPolicy="no-referrer"
            className="relative w-20 h-20 rounded-full object-cover border-2 border-amber-300 shadow-xl"
          />
        </div>

        <h2 className="text-2xl font-black text-amber-300 mb-0.5 tracking-tight">
          {completedStage.name} 클리어!
        </h2>
        <p className="text-xs font-black text-emerald-400 mb-4 flex items-center gap-1">
          <Sparkles className="w-3.5 h-3.5" />
          클리어 보너스 +{bonus.toLocaleString()}점!
        </p>

        {/* 5-Stage Roadmap Progress Nodes */}
        <div className="w-full flex items-center justify-between mb-5 px-2">
          {STAGES.map((s, idx) => {
            const isCompleted = idx <= stageIdx;
            const isNext = idx === stageIdx + 1;
            return (
              <div key={s.stage} className="flex flex-col items-center gap-1">
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center font-black text-xs transition-all ${
                    isCompleted
                      ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/30 ring-2 ring-emerald-400'
                      : isNext
                      ? 'bg-amber-400 text-slate-950 font-black animate-bounce ring-2 ring-amber-300'
                      : 'bg-slate-800 text-slate-500'
                  }`}
                >
                  {isCompleted ? <CheckCircle2 className="w-4 h-4" /> : idx + 1}
                </div>
                <span
                  className={`text-[10px] font-bold ${
                    isCompleted || isNext ? 'text-white' : 'text-slate-500'
                  }`}
                >
                  {idx + 1}단계
                </span>
              </div>
            );
          })}
        </div>

        {/* Next Stage Info Card */}
        <div className="w-full bg-slate-950/70 border border-white/10 rounded-2xl p-4 mb-5 text-left space-y-1">
          <div className="text-xs font-black text-cyan-300 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5" />
            다음: {nextStage.name}
          </div>
          <div className="text-[11px] text-slate-300 leading-relaxed">
            {nextStage.desc}
          </div>
        </div>

        {/* Next Stage Button */}
        <button
          id="btn-next-stage"
          onClick={onNextStage}
          className="w-full py-4 rounded-2xl bg-gradient-to-r from-amber-400 via-amber-500 to-orange-500 text-slate-950 font-black text-lg shadow-xl shadow-amber-500/30 hover:brightness-110 active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-2"
        >
          다음 단계 도전
          <ArrowRight className="w-5 h-5 stroke-[2.5]" />
        </button>
      </div>
    </div>
  );
};
