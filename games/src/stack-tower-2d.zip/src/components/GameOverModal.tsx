import React from 'react';
import { RotateCcw, Play, Trophy, Flame } from 'lucide-react';
import { ASSET_IMAGES } from '../constants';

interface GameOverModalProps {
  floors: number;
  score: number;
  bestFloor: number;
  maxCombo: number;
  currentStageName: string;
  onRetryStage: () => void;
  onRestartAll: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  floors,
  score,
  bestFloor,
  maxCombo,
  currentStageName,
  onRetryStage,
  onRestartAll,
}) => {
  const isNewRecord = floors > 0 && floors >= bestFloor;

  return (
    <div className="absolute inset-0 z-20 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
      <div className="w-full max-w-sm rounded-3xl bg-slate-900/90 border border-rose-500/30 p-6 flex flex-col items-center text-center shadow-2xl shadow-rose-950/40">
        <div className="text-4xl mb-1 drop-shadow animate-pulse">💥</div>
        <h2 className="text-2xl font-black text-rose-400 mb-0.5 tracking-tight">
          타워 붕괴!
        </h2>
        <p className="text-xs font-semibold text-slate-400 mb-4">
          모든 목숨(5개)을 소진하였습니다.
        </p>

        {isNewRecord && (
          <div className="w-full bg-gradient-to-r from-amber-500/20 to-orange-500/20 border border-amber-400/40 rounded-2xl p-2.5 mb-3 flex items-center justify-center gap-2">
            <img
              src={ASSET_IMAGES.trophy}
              alt="새 기록 트로피"
              referrerPolicy="no-referrer"
              className="w-7 h-7 rounded-full object-cover"
            />
            <span className="text-xs font-black text-amber-300">
              🎉 최고 층수 신기록 달성!
            </span>
          </div>
        )}

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-2.5 w-full mb-3">
          <div className="bg-slate-950/70 border border-white/10 rounded-2xl p-3 text-center">
            <div className="text-[10px] font-bold text-slate-400">도달 층수</div>
            <div className="text-2xl font-black text-white">{floors}층</div>
          </div>
          <div className="bg-slate-950/70 border border-white/10 rounded-2xl p-3 text-center">
            <div className="text-[10px] font-bold text-slate-400">최종 점수</div>
            <div className="text-2xl font-black text-amber-300">
              {score.toLocaleString()}점
            </div>
          </div>
        </div>

        {/* Secondary Info Pill */}
        <div className="w-full bg-slate-950/60 border border-white/10 rounded-xl p-2.5 mb-5 text-xs font-bold text-slate-300 flex justify-between items-center">
          <span className="flex items-center gap-1">
            <Trophy className="w-3.5 h-3.5 text-amber-400" />
            최고 기록: <b className="text-amber-300">{bestFloor}층</b>
          </span>
          <span className="flex items-center gap-1 text-amber-400">
            <Flame className="w-3.5 h-3.5" />
            최대 콤보: {maxCombo}회
          </span>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col gap-2.5 w-full">
          <button
            id="btn-retry-stage"
            onClick={onRetryStage}
            className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-cyan-500 via-sky-500 to-blue-600 text-white font-black text-base shadow-lg shadow-cyan-500/20 hover:brightness-110 active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            <RotateCcw className="w-4 h-4" />
            {currentStageName} 다시 도전
          </button>
          <button
            id="btn-restart-from-start"
            onClick={onRestartAll}
            className="w-full py-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 text-slate-300 font-bold text-xs transition cursor-pointer flex items-center justify-center gap-1.5"
          >
            <Play className="w-3 h-3" />
            1단계부터 처음부터 시작
          </button>
        </div>
      </div>
    </div>
  );
};
