import React from 'react';
import { Trophy, Play, ShieldAlert, Sparkles } from 'lucide-react';
import { ASSET_IMAGES } from '../constants';

interface StartModalProps {
  bestFloor: number;
  bestScore: number;
  onStartGame: () => void;
}

export const StartModal: React.FC<StartModalProps> = ({
  bestFloor,
  bestScore,
  onStartGame,
}) => {
  return (
    <div className="absolute inset-0 z-20 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-md">
      <div className="w-full max-w-sm rounded-3xl bg-slate-900/85 border border-cyan-500/30 p-6 flex flex-col items-center text-center shadow-2xl shadow-cyan-950/50">
        {/* Game Generated Asset Logo */}
        <div className="relative mb-3 group">
          <div className="absolute -inset-1 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-3xl blur-md opacity-70 group-hover:opacity-100 transition duration-300"></div>
          <img
            src={ASSET_IMAGES.logo}
            alt="2D 스택 타워 로고"
            referrerPolicy="no-referrer"
            className="relative w-24 h-24 sm:w-28 sm:h-28 rounded-2xl object-cover border-2 border-white/20 shadow-xl"
          />
        </div>

        <h1 className="text-3xl font-black text-white tracking-tight mb-1">
          2D 스택 타워
        </h1>
        <p className="text-xs font-bold text-cyan-400 uppercase tracking-widest mb-5 flex items-center gap-1">
          <Sparkles className="w-3.5 h-3.5" />
          5단계 챌린지 & 5개의 목숨
        </p>

        {/* Record Cards */}
        <div className="w-full bg-slate-950/60 border border-white/10 rounded-2xl p-4 mb-5 text-left space-y-2.5">
          <div className="flex justify-between items-center text-xs">
            <span className="text-slate-400 font-semibold flex items-center gap-1.5">
              <Trophy className="w-4 h-4 text-amber-400" />
              최고 도달 층수
            </span>
            <span className="font-black text-amber-300 text-sm">{bestFloor}층</span>
          </div>

          <div className="flex justify-between items-center text-xs">
            <span className="text-slate-400 font-semibold flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              최고 스코어
            </span>
            <span className="font-extrabold text-white text-sm">
              {bestScore.toLocaleString()}점
            </span>
          </div>

          <div className="pt-2.5 border-t border-white/10 text-slate-300 text-[11px] leading-relaxed space-y-1">
            <div className="flex items-start gap-1.5">
              <span className="text-cyan-400 font-bold">•</span>
              <span>좌우로 움직이는 블록을 기존 타워에 맞춰 쌓아 올리세요.</span>
            </div>
            <div className="flex items-start gap-1.5">
              <span className="text-rose-400 font-bold">•</span>
              <span>
                완전히 빗나가면 목숨 <b>❤️ 1개</b>가 차감됩니다 (총 5개).
              </span>
            </div>
            <div className="flex items-start gap-1.5">
              <span className="text-amber-400 font-bold">•</span>
              <span>정확히 맞추면 <b>PERFECT 콤보</b>와 블록 확장 보너스!</span>
            </div>
          </div>
        </div>

        {/* Start Game Action Button */}
        <button
          id="btn-start-game"
          onClick={onStartGame}
          className="w-full py-4 rounded-2xl bg-gradient-to-r from-cyan-500 via-sky-500 to-blue-600 text-white font-black text-lg shadow-xl shadow-cyan-500/30 hover:brightness-110 active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-2"
        >
          <Play className="w-5 h-5 fill-current" />
          게임 시작
        </button>
      </div>
    </div>
  );
};
