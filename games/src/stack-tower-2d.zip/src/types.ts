export interface Stage {
  stage: number;
  name: string;
  targetFloors: number;
  baseSpeed: number;
  bgHue: number;
  desc: string;
}

export interface TowerBlock {
  x: number;
  y: number;
  w: number;
  hue: number;
}

export interface ActiveBlock {
  x: number;
  y: number;
  w: number;
  dir: 1 | -1;
  speed: number;
  hue: number;
}

export interface DebrisBlock {
  x: number;
  y: number;
  w: number;
  hue: number;
  vx: number;
  vy: number;
  rot: number;
  vRot: number;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  hue: number;
  life: number;
  size: number;
}

export type GameState = 'menu' | 'playing' | 'stage_clear' | 'over';
