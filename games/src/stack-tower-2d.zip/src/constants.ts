import { Stage } from './types';
import logoImg from './assets/images/tower_app_logo_1789882091287.jpg';
import backdropImg from './assets/images/tower_sky_backdrop_1789882102587.jpg';
import trophyImg from './assets/images/golden_trophy_badge_1789882114559.jpg';

export const ASSET_IMAGES = {
  logo: logoImg,
  backdrop: backdropImg,
  trophy: trophyImg,
};

export const BLOCK_HEIGHT = 24;
export const BASE_WIDTH = 200;
export const MAX_LIVES = 5;

export const STAGES: Stage[] = [
  {
    stage: 1,
    name: '1단계: 입문 타워',
    targetFloors: 10,
    baseSpeed: 3.2,
    bgHue: 215,
    desc: '기초 감각을 익히세요! 10층을 쌓으면 2단계로 진입합니다.',
  },
  {
    stage: 2,
    name: '2단계: 강풍의 언덕',
    targetFloors: 15,
    baseSpeed: 4.4,
    bgHue: 270,
    desc: '바람이 불어 속도가 빨라집니다! 15층을 쌓고 3단계로 이동하세요.',
  },
  {
    stage: 3,
    name: '3단계: 밤하늘 정원',
    targetFloors: 20,
    baseSpeed: 5.6,
    bgHue: 320,
    desc: '신비로운 보랏빛 밤하늘! 20층을 정밀하게 쌓아 올리세요.',
  },
  {
    stage: 4,
    name: '4단계: 네온 네뷸라',
    targetFloors: 25,
    baseSpeed: 6.8,
    bgHue: 170,
    desc: '초고속 사이버 네온 타워! 25층을 돌파해 전설의 신전에 도달하세요.',
  },
  {
    stage: 5,
    name: '5단계: 무한의 신전',
    targetFloors: 999,
    baseSpeed: 8.0,
    bgHue: 45,
    desc: '최종 마스터 단계! 우주 끝까지 당신만의 최고 층수 기록을 세워보세요.',
  },
];
