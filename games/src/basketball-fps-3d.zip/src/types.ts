export type GameMode = 'title' | 'play' | 'over';

export interface GameState {
  mode: GameMode;
  score: number;
  combo: number;
  bestCombo: number;
  balls: number;
  goals: number;
  shots: number;
  swishes: number;
  level: number;
  time: number;
  windOn: boolean;
  windX: number;
  layupUnlocked: boolean;
  isLayupActive: boolean;
}

export interface ShotResultBanner {
  text: string;
  id: number;
}
