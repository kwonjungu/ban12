/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useRef, useCallback, useEffect } from 'react';
import BasketballScene from './components/BasketballScene';
import HUDOverlay from './components/HUDOverlay';
import StartModal from './components/StartModal';
import GameOverModal from './components/GameOverModal';
import { GameMode } from './types';
import { ensureAudio, sfxStart, sfxOver } from './utils/audio';

export default function App() {
  const [mode, setMode] = useState<GameMode>('title');
  const [score, setScore] = useState(0);
  const [combo, setCombo] = useState(0);
  const [bestCombo, setBestCombo] = useState(0);
  const [balls, setBalls] = useState(5);
  const [goals, setGoals] = useState(0);
  const [swishes, setSwishes] = useState(0);
  const [level, setLevel] = useState(1);
  const [windOn, setWindOn] = useState(false);
  const [windX, setWindX] = useState(0);
  const [layupUnlocked, setLayupUnlocked] = useState(false);
  const [isLayupTriggered, setIsLayupTriggered] = useState(false);
  const [bannerText, setBannerText] = useState<string | null>(null);

  const [bestScore, setBestScore] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('3d_basketball_best');
      return saved ? parseInt(saved, 10) || 0 : 0;
    } catch {
      return 0;
    }
  });

  const bannerTimerRef = useRef<NodeJS.Timeout | null>(null);

  const showBanner = useCallback((msg: string) => {
    setBannerText(msg);
    if (bannerTimerRef.current) clearTimeout(bannerTimerRef.current);
    bannerTimerRef.current = setTimeout(() => {
      setBannerText(null);
    }, 1400);
  }, []);

  const updateWind = useCallback((currentLevel: number) => {
    if (currentLevel >= 2) {
      setWindOn(true);
      const wx = (Math.random() - 0.5) * (1.5 + currentLevel * 0.8);
      setWindX(wx);
    } else {
      setWindOn(false);
      setWindX(0);
    }
  }, []);

  const handleStartGame = useCallback(() => {
    ensureAudio();
    sfxStart();

    setScore(0);
    setCombo(0);
    setBestCombo(0);
    setBalls(5);
    setGoals(0);
    setSwishes(0);
    setLevel(1);
    setLayupUnlocked(false);
    setIsLayupTriggered(false);
    updateWind(1);

    setMode('play');
    showBanner('🏀 게임 시작! 공을 던지세요');
  }, [showBanner, updateWind]);

  const handleGameOver = useCallback(() => {
    sfxOver();
    setMode('over');
  }, []);

  const handleScore = useCallback(
    (pts: number, isSwish: boolean, starHit: boolean) => {
      setGoals((prevGoals) => {
        const nextGoals = prevGoals + 1;
        if (nextGoals >= 3) {
          setLayupUnlocked(true);
        }
        return nextGoals;
      });

      setCombo((prevCombo) => {
        const nextCombo = prevCombo + 1;
        setBestCombo((prevBest) => Math.max(prevBest, nextCombo));

        const comboBonus = nextCombo > 1 ? (nextCombo - 1) * 50 : 0;
        const totalPts = pts + comboBonus;

        setScore((prevScore) => {
          const nextScore = prevScore + totalPts;
          if (nextScore > bestScore) {
            setBestScore(nextScore);
            try {
              localStorage.setItem('3d_basketball_best', String(nextScore));
            } catch {
              // Ignore local storage error
            }
          }

          const nextLevel = Math.floor(nextScore / 500) + 1;
          setLevel((prevLv) => {
            if (nextLevel > prevLv) {
              updateWind(nextLevel);
            }
            return nextLevel;
          });

          return nextScore;
        });

        if (isSwish) {
          setSwishes((s) => s + 1);
          showBanner(`✨ SWISH!! +${totalPts}`);
        } else if (starHit) {
          showBanner(`⭐ STAR BONUS! +${totalPts}`);
        } else {
          showBanner(`GOAL!! +${totalPts}`);
        }

        return nextCombo;
      });
    },
    [bestScore, showBanner, updateWind]
  );

  const handleMiss = useCallback(() => {
    setCombo(0);
    showBanner('MISS!');
    setBalls((prev) => {
      const next = prev - 1;
      if (next <= 0) {
        setTimeout(handleGameOver, 900);
      }
      return Math.max(0, next);
    });
  }, [handleGameOver, showBanner]);

  const handleTriggerLayup = useCallback(() => {
    if (mode !== 'play') return;
    setIsLayupTriggered(true);
    showBanner('💥 드라이브 인 레이업!!');
  }, [mode, showBanner]);

  useEffect(() => {
    return () => {
      if (bannerTimerRef.current) clearTimeout(bannerTimerRef.current);
    };
  }, []);

  return (
    <main className="relative w-screen h-screen overflow-hidden bg-slate-950 font-sans select-none">
      {/* 3D WebGL Basketball Scene */}
      <BasketballScene
        isPlaying={mode === 'play'}
        level={level}
        windOn={windOn}
        windX={windX}
        onScore={handleScore}
        onMiss={handleMiss}
        onPowerChange={() => {}}
        onLayupStateChange={() => {}}
        isLayupTriggered={isLayupTriggered}
        onLayupHandled={() => setIsLayupTriggered(false)}
      />

      {/* Modern HUD Overlay */}
      {mode === 'play' && (
        <HUDOverlay
          score={score}
          level={level}
          balls={balls}
          combo={combo}
          windOn={windOn}
          windX={windX}
          bannerText={bannerText}
          layupUnlocked={layupUnlocked}
          onTriggerLayup={handleTriggerLayup}
        />
      )}

      {/* Title & Start Screen Modal */}
      {mode === 'title' && (
        <StartModal bestScore={bestScore} onStart={handleStartGame} />
      )}

      {/* Game Over Screen Modal */}
      {mode === 'over' && (
        <GameOverModal
          score={score}
          bestScore={bestScore}
          bestCombo={bestCombo}
          swishes={swishes}
          onRetry={handleStartGame}
        />
      )}
    </main>
  );
}
