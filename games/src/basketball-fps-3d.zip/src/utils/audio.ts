/**
 * Web Audio API Sound Synthesizer for Basketball Game
 */

let audioCtx: AudioContext | null = null;
let soundEnabled = true;

export function toggleSound(): boolean {
  soundEnabled = !soundEnabled;
  return soundEnabled;
}

export function isSoundEnabled(): boolean {
  return soundEnabled;
}

export function ensureAudio() {
  if (!soundEnabled) return;
  try {
    if (!audioCtx) {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      audioCtx = new AudioContextClass();
    }
    if (audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
  } catch {
    // Audio might not be allowed yet until user interaction
  }
}

function tone(freq: number, duration: number, type: OscillatorType = 'sine', vol = 0.2, delay = 0) {
  if (!soundEnabled) return;
  ensureAudio();
  if (!audioCtx) return;

  setTimeout(() => {
    try {
      if (!audioCtx) return;
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
      gain.gain.setValueAtTime(vol, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + duration);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + duration);
    } catch {
      // Ignore audio synthesis errors
    }
  }, delay * 1000);
}

export function sfxShoot(power: number) {
  tone(180 + power * 120, 0.1, 'sine', 0.25, 0);
  tone(120, 0.15, 'triangle', 0.2, 0.02);
}

export function sfxBounce(isHard: boolean) {
  tone(isHard ? 220 : 130, 0.08, 'triangle', isHard ? 0.35 : 0.2, 0);
}

export function sfxSwish() {
  tone(520, 0.12, 'sine', 0.2, 0);
  tone(780, 0.16, 'triangle', 0.3, 0.05);
  tone(1040, 0.22, 'sine', 0.25, 0.1);
}

export function sfxGoal() {
  tone(440, 0.12, 'sine', 0.2, 0);
  tone(554.37, 0.12, 'sine', 0.2, 0.08);
  tone(659.25, 0.2, 'sine', 0.25, 0.16);
}

export function sfxStar() {
  tone(587.33, 0.1, 'sine', 0.2, 0);
  tone(880, 0.25, 'sine', 0.25, 0.08);
}

export function sfxStart() {
  tone(392, 0.12, 'triangle', 0.15, 0);
  tone(523, 0.12, 'triangle', 0.15, 0.08);
  tone(784, 0.28, 'triangle', 0.18, 0.16);
}

export function sfxLayup() {
  tone(440, 0.1, 'sine', 0.2, 0);
  tone(554, 0.1, 'sine', 0.2, 0.08);
  tone(659, 0.12, 'triangle', 0.25, 0.16);
  tone(880, 0.25, 'sine', 0.3, 0.24);
}

export function sfxOver() {
  tone(523, 0.18, 'sawtooth', 0.14, 0);
  tone(440, 0.18, 'sawtooth', 0.14, 0.12);
  tone(349, 0.35, 'sawtooth', 0.18, 0.24);
}
