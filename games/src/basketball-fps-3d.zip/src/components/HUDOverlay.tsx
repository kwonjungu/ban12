import { Volume2, VolumeX, Flame, Wind, Eye } from 'lucide-react';
import { isSoundEnabled, toggleSound } from '../utils/audio';
import { useState } from 'react';

interface HUDOverlayProps {
  score: number;
  level: number;
  balls: number;
  combo: number;
  windOn: boolean;
  windX: number;
  powerPct?: number;
  bannerText: string | null;
  layupUnlocked: boolean;
  onTriggerLayup: () => void;
}

export default function HUDOverlay({
  score,
  level,
  balls,
  combo,
  windOn,
  windX,
  bannerText,
  layupUnlocked,
  onTriggerLayup,
}: HUDOverlayProps) {
  const [soundOn, setSoundOn] = useState(isSoundEnabled());

  const handleToggleSound = () => {
    const next = toggleSound();
    setSoundOn(next);
  };

  const ballIcons = Array.from({ length: Math.max(0, balls) }, (_, i) => (
    <span key={i} className="text-base inline-block transform hover:scale-110 transition-transform">
      🏀
    </span>
  ));

  return (
    <div id="uiOverlay" className="absolute inset-0 pointer-events-none z-10 flex flex-col justify-between p-4 sm:p-6 select-none">
      {/* Top Status Bar */}
      <div className="w-full flex justify-between items-start gap-4">
        {/* Score, Level, and Balls Left Card */}
        <div
          id="hudCardScore"
          className="pointer-events-auto bg-slate-900/80 backdrop-blur-md border border-slate-700/60 shadow-2xl rounded-2xl p-3 sm:px-4 sm:py-3 flex items-center gap-3 sm:gap-5"
        >
          <div>
            <div className="text-[10px] sm:text-xs font-bold tracking-wider text-slate-400">SCORE</div>
            <div id="scoreVal" className="text-2xl sm:text-3xl font-black text-amber-400 tabular-nums">
              {score}
            </div>
          </div>

          <div className="w-px h-8 bg-slate-700/80" />

          <div>
            <div className="text-[10px] sm:text-xs font-bold tracking-wider text-slate-400">LEVEL</div>
            <div id="levelVal" className="text-lg sm:text-xl font-extrabold text-white">
              {level}
            </div>
          </div>

          <div className="w-px h-8 bg-slate-700/80" />

          <div>
            <div className="text-[10px] sm:text-xs font-bold tracking-wider text-slate-400">남은 공</div>
            <div id="ballsVal" className="flex items-center gap-0.5 mt-0.5 min-w-[70px]">
              {balls > 0 ? ballIcons : <span className="text-xs text-rose-400 font-bold">마지막 공!</span>}
            </div>
          </div>
        </div>

        {/* Combo, Wind & Audio Controls */}
        <div className="flex flex-col items-end gap-2 pointer-events-auto">
          <button
            id="soundToggleBtn"
            onClick={handleToggleSound}
            aria-label="소리 켜기/끄기"
            className="bg-slate-900/80 backdrop-blur-md border border-slate-700/60 hover:border-slate-500 text-slate-300 hover:text-white p-2 rounded-xl transition-all shadow-lg"
          >
            {soundOn ? <Volume2 className="w-4 h-4 text-emerald-400" /> : <VolumeX className="w-4 h-4 text-slate-400" />}
          </button>

          {combo > 1 && (
            <div
              id="comboChip"
              className="animate-bounce bg-amber-500/20 backdrop-blur-md border border-amber-400/60 rounded-xl px-3 py-1 text-xs sm:text-sm font-black text-amber-300 shadow-[0_0_15px_rgba(245,158,11,0.5)] flex items-center gap-1.5"
            >
              <Flame className="w-4 h-4 text-amber-400 fill-amber-400" />
              <span>{combo}연속 콤보!</span>
            </div>
          )}

          {windOn && (
            <div
              id="windChip"
              className="bg-sky-950/70 backdrop-blur-md border border-sky-400/40 rounded-xl px-3 py-1 text-xs font-bold text-sky-300 shadow-md flex items-center gap-1"
            >
              <Wind className="w-3.5 h-3.5 text-sky-400" />
              <span>바람 {windX > 0 ? `→ ${Math.abs(windX).toFixed(1)}` : `← ${Math.abs(windX).toFixed(1)}`}</span>
            </div>
          )}
        </div>
      </div>

      {/* 1st-Person Perspective Badge */}
      <div className="self-start mt-2">
        <div
          id="viewBadge"
          className="inline-flex items-center gap-1.5 bg-slate-950/70 backdrop-blur-sm border border-slate-800 text-sky-300 text-[11px] font-semibold px-3 py-1 rounded-full pointer-events-none"
        >
          <Eye className="w-3 h-3 text-sky-400" />
          <span>주인공 1인칭 시점 & 3D 플레이어 팔</span>
        </div>
      </div>

      {/* Big Center Action Banner */}
      <div className="flex-1 flex items-center justify-center pointer-events-none">
        {bannerText && (
          <div
            id="banner"
            className="animate-in fade-in zoom-in-95 duration-200 bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 font-black text-xl sm:text-2xl px-6 py-2.5 rounded-full shadow-[0_10px_35px_rgba(245,158,11,0.6)] border-2 border-white/80"
          >
            {bannerText}
          </div>
        )}
      </div>

      {/* Bottom Controls Area */}
      <div className="w-full flex flex-col items-center gap-3">
        {/* Layup Action Button (Unlocked at 3 goals) */}
        {layupUnlocked && (
          <div className="w-full max-w-md flex justify-end">
            <button
              id="layupBtn"
              onClick={onTriggerLayup}
              className="pointer-events-auto animate-pulse hover:animate-none active:scale-95 transition-all bg-gradient-to-r from-rose-500 via-orange-500 to-amber-500 text-white font-black text-sm px-5 py-2.5 rounded-full border-2 border-white shadow-[0_0_20px_rgba(244,63,94,0.6)] cursor-pointer"
            >
              🏀 드라이브 인 레이업 (CLICK!)
            </button>
          </div>
        )}

        {/* Power Gauge Box */}
        <div
          id="gaugeWrap"
          className="pointer-events-auto w-full max-w-lg bg-slate-900/90 backdrop-blur-md border-2 border-slate-700/80 hover:border-slate-600 rounded-2xl p-3 sm:px-4 sm:py-3 shadow-2xl transition-colors cursor-pointer select-none"
        >
          <div id="gaugeHeader" className="flex justify-between items-center text-xs sm:text-sm font-bold text-slate-200 mb-2">
            <span id="powerLabel" className="flex items-center gap-1.5">
              <span>💪 팔힘 게이지</span>
              <span id="gaugeStatus" className="text-slate-400 text-xs font-normal">
                (화면/게이지 터치 or 스페이스바 유지)
              </span>
            </span>
            <div className="flex items-center gap-2">
              <span
                id="gaugeZoneBadge"
                className="text-[10px] font-black px-2 py-0.5 rounded-md bg-slate-800 text-slate-400"
              >
                대기 중
              </span>
              <span id="powerVal" className="text-amber-400 font-mono font-black text-sm min-w-[36px] text-right">
                0%
              </span>
            </div>
          </div>

          <div
            id="gaugeTrack"
            className="relative w-full h-6 bg-slate-950 rounded-full overflow-hidden border border-slate-700/80 shadow-inner"
          >
            {/* Green Optimal Success Zone (67% ~ 77%) */}
            <div
              id="gaugeOptimalZone"
              className="absolute top-0 bottom-0 left-[67%] w-[10%] bg-emerald-500/90 border-x-2 border-dashed border-white shadow-[0_0_14px_rgba(16,185,129,0.8)] z-10 flex items-center justify-center pointer-events-none"
            >
              <span className="text-[9px] font-black text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.8)] whitespace-nowrap">
                🎯 72%
              </span>
            </div>

            {/* Dynamic Power Bar Fill - Real-time zero-lag update */}
            <div
              id="gaugeFill"
              style={{ width: '0%' }}
              className="absolute top-0 left-0 bottom-0 bg-gradient-to-r from-blue-500 via-amber-400 to-rose-500 will-change-[width] pointer-events-none"
            />

            {/* Shot Release Point Marker */}
            <div
              id="gaugeReleaseMarker"
              style={{ display: 'none', left: '0%' }}
              className="absolute top-0 bottom-0 w-1.5 -ml-[3px] bg-white shadow-[0_0_8px_#ffffff] z-20 pointer-events-none"
            />
          </div>

          <div className="flex justify-between items-center text-[10px] text-slate-400 mt-1.5 px-1 font-semibold">
            <span>0% (약함)</span>
            <span className="text-emerald-400 font-bold">🎯 완벽 성공 존 (67%~77%)</span>
            <span>100% (강함)</span>
          </div>
        </div>
      </div>
    </div>
  );
}
