import heroBannerUrl from '../assets/images/basketball_hero_banner_1789882147270.jpg';
import basketballTextureUrl from '../assets/images/basketball_texture_1789882110898.jpg';
import courtFloorTextureUrl from '../assets/images/court_wood_floor_1789882123234.jpg';
import { Play, Sparkles, Crosshair, Award } from 'lucide-react';

interface StartModalProps {
  bestScore: number;
  onStart: () => void;
}

export default function StartModal({ bestScore, onStart }: StartModalProps) {
  return (
    <div
      id="titleScreen"
      className="absolute inset-0 bg-slate-950/85 backdrop-blur-md z-30 flex items-center justify-center p-4 overflow-y-auto"
    >
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col my-auto">
        {/* Hero Banner Asset Image */}
        <div className="relative w-full h-44 sm:h-48 overflow-hidden bg-slate-950">
          <img
            src={heroBannerUrl}
            alt="3D First Person Basketball Hero Banner"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/30 to-transparent" />
          <div className="absolute bottom-3 left-4 right-4 flex justify-between items-end">
            <div>
              <span className="inline-block px-2.5 py-0.5 rounded-full bg-orange-500/80 text-[10px] font-black tracking-wide text-white mb-1 uppercase">
                First-Person 3D Action
              </span>
              <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight drop-shadow-md">
                1인칭 3D 농구 슛
              </h1>
            </div>
            <div className="text-3xl">🏀</div>
          </div>
        </div>

        {/* Modal Content */}
        <div className="p-5 sm:p-6 space-y-4">
          <p className="text-slate-300 text-xs sm:text-sm leading-relaxed">
            주인공의 시점에서 공을 직접 조준하고 던지세요!
            하단 게이지를 🎯 <strong className="text-emerald-400">성공 구역(67%~77%)</strong>에 맞춰 손을 떼면
            완벽한 클린 스위시 골인이 보장됩니다.
          </p>

          {/* Asset Preview Badges */}
          <div className="flex items-center gap-2 py-1 px-2.5 bg-slate-950/60 rounded-xl border border-slate-800/80">
            <span className="text-[11px] text-slate-400 font-medium">적용된 3D 텍스처 에셋:</span>
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1">
                <img
                  src={basketballTextureUrl}
                  alt="Basketball Leather Texture"
                  referrerPolicy="no-referrer"
                  className="w-5 h-5 rounded-full object-cover border border-amber-500/60"
                  title="공 가죽 텍스처"
                />
                <span className="text-[10px] text-amber-300 font-semibold">농구공</span>
              </div>
              <div className="flex items-center gap-1">
                <img
                  src={courtFloorTextureUrl}
                  alt="Court Wood Parquet Texture"
                  referrerPolicy="no-referrer"
                  className="w-5 h-5 rounded object-cover border border-amber-500/60"
                  title="코트 원목 마루 텍스처"
                />
                <span className="text-[10px] text-amber-300 font-semibold">코트 마루</span>
              </div>
            </div>
          </div>

          {/* Controls Guide */}
          <div className="bg-slate-950/70 p-3.5 rounded-2xl text-left text-xs text-slate-300 space-y-2 border border-slate-800">
            <div className="flex items-start gap-2">
              <Crosshair className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-white">파워 조절:</strong> 화면 터치 유지 / 스페이스바 꾹 눌러 파워 충전 후 놓기
              </div>
            </div>
            <div className="flex items-start gap-2">
              <Sparkles className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-white">방향 조절:</strong> 마우스/터치 드래그 또는 키보드 [A / D], [← / →]
              </div>
            </div>
            <div className="flex items-start gap-2">
              <Award className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-white">레이업 해금:</strong> 3골 이상 성공 시 화려한 드라이브 인 레이업 스킬 사용 가능!
              </div>
            </div>
          </div>

          {/* Action Button */}
          <button
            id="startBtn"
            onClick={onStart}
            className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-orange-500 via-amber-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white font-black text-lg py-3.5 px-6 rounded-full shadow-[0_8px_25px_rgba(249,115,22,0.4)] active:scale-95 transition-all cursor-pointer"
          >
            <Play className="w-5 h-5 fill-white" />
            <span>게임 시작하기</span>
          </button>

          {/* Best Score */}
          <div className="text-center text-xs font-bold text-slate-400">
            역대 최고 기록: <span id="bestTitle" className="text-amber-400 font-mono text-sm">{bestScore}</span>점
          </div>
        </div>
      </div>
    </div>
  );
}
