import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import basketballTextureUrl from '../assets/images/basketball_texture_1789882110898.jpg';
import courtFloorTextureUrl from '../assets/images/court_wood_floor_1789882123234.jpg';
import arenaBackdropTextureUrl from '../assets/images/arena_stadium_lights_1789882134565.jpg';
import {
  ensureAudio,
  sfxShoot,
  sfxBounce,
  sfxSwish,
  sfxGoal,
  sfxStar,
  sfxLayup,
} from '../utils/audio';

function clamp(val: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, val));
}

function rand(min: number, max: number): number {
  return Math.random() * (max - min) + min;
}

interface BasketballSceneProps {
  isPlaying: boolean;
  level: number;
  windOn: boolean;
  windX: number;
  onScore: (pts: number, isSwish: boolean, starHit: boolean) => void;
  onMiss: () => void;
  onPowerChange: (powerPct: number) => void;
  onLayupStateChange: (isLayup: boolean) => void;
  isLayupTriggered: boolean;
  onLayupHandled: () => void;
}

export default function BasketballScene({
  isPlaying,
  level,
  windOn,
  windX,
  onScore,
  onMiss,
  onPowerChange,
  onLayupStateChange,
  isLayupTriggered,
  onLayupHandled,
}: BasketballSceneProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Store refs to mutable game state for animation loop
  const stateRef = useRef({
    isPlaying,
    level,
    windOn,
    windX,
    isLayupTriggered,
    isLayupActive: false,
    layupTime: 0,
    shake: 0,
    shakeMag: 0,
    time: 0,
  });

  // Keep stateRef updated
  stateRef.current.isPlaying = isPlaying;
  stateRef.current.level = level;
  stateRef.current.windOn = windOn;
  stateRef.current.windX = windX;
  stateRef.current.isLayupTriggered = isLayupTriggered;

  const callbacksRef = useRef({
    onScore,
    onMiss,
    onPowerChange,
    onLayupStateChange,
    onLayupHandled,
  });
  callbacksRef.current = {
    onScore,
    onMiss,
    onPowerChange,
    onLayupStateChange,
    onLayupHandled,
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    // Dimensions
    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;

    // Three.js Scene Setup
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0a0f1d);
    scene.fog = new THREE.FogExp2(0x0a0f1d, 0.03);

    const camera = new THREE.PerspectiveCamera(65, width / height, 0.1, 100);
    const CAMERA_HOME = new THREE.Vector3(0, 1.6, 3.2);
    camera.position.copy(CAMERA_HOME);

    const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false, powerPreference: 'high-performance' });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    // Lights
    const ambLight = new THREE.AmbientLight(0xffffff, 0.75);
    scene.add(ambLight);

    const dirLight = new THREE.DirectionalLight(0xfff5e6, 1.25);
    dirLight.position.set(5, 12, 6);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 1024;
    dirLight.shadow.mapSize.height = 1024;
    dirLight.shadow.camera.near = 0.5;
    dirLight.shadow.camera.far = 25;
    dirLight.shadow.camera.left = -7;
    dirLight.shadow.camera.right = 7;
    dirLight.shadow.camera.top = 8;
    dirLight.shadow.camera.bottom = -2;
    scene.add(dirLight);

    const courtSpotlight = new THREE.SpotLight(0x38bdf8, 1.5, 18, Math.PI / 4, 0.4);
    courtSpotlight.position.set(0, 8, -4);
    courtSpotlight.target.position.set(0, 2.7, -4.15);
    scene.add(courtSpotlight);
    scene.add(courtSpotlight.target);

    // Texture Loader
    const textureLoader = new THREE.TextureLoader();

    // 1. Basketball Court Parquet Wood Floor Asset
    const courtFloorTexture = textureLoader.load(courtFloorTextureUrl);
    courtFloorTexture.wrapS = THREE.RepeatWrapping;
    courtFloorTexture.wrapT = THREE.RepeatWrapping;
    courtFloorTexture.repeat.set(3, 5);

    const courtGeo = new THREE.PlaneGeometry(16, 26);
    const courtMat = new THREE.MeshStandardMaterial({
      map: courtFloorTexture,
      roughness: 0.35,
      metalness: 0.1,
    });
    const court = new THREE.Mesh(courtGeo, courtMat);
    court.rotation.x = -Math.PI / 2;
    court.receiveShadow = true;
    scene.add(court);

    // Court Paint Key Area
    const keyGeo = new THREE.PlaneGeometry(4.8, 8);
    const keyMat = new THREE.MeshStandardMaterial({
      color: 0x1d4ed8,
      roughness: 0.4,
      metalness: 0.05,
    });
    const keyArea = new THREE.Mesh(keyGeo, keyMat);
    keyArea.rotation.x = -Math.PI / 2;
    keyArea.position.set(0, 0.005, -5.5);
    keyArea.receiveShadow = true;
    scene.add(keyArea);

    // Free Throw Semi-Circle Line
    const circleGeo = new THREE.RingGeometry(1.6, 1.68, 32, 1, 0, Math.PI);
    const circleMat = new THREE.MeshBasicMaterial({ color: 0xffffff, side: THREE.DoubleSide });
    const freeThrowCircle = new THREE.Mesh(circleGeo, circleMat);
    freeThrowCircle.rotation.x = -Math.PI / 2;
    freeThrowCircle.position.set(0, 0.008, -1.5);
    scene.add(freeThrowCircle);

    // 2. Arena Stadium Lights Panoramic Backdrop Asset
    const arenaTexture = textureLoader.load(arenaBackdropTextureUrl);
    arenaTexture.wrapS = THREE.ClampToEdgeWrapping;
    arenaTexture.wrapT = THREE.ClampToEdgeWrapping;
    const arenaGeo = new THREE.CylinderGeometry(20, 20, 16, 32, 1, true, -Math.PI * 0.7, Math.PI * 1.4);
    const arenaMat = new THREE.MeshBasicMaterial({
      map: arenaTexture,
      side: THREE.BackSide,
    });
    const arenaMesh = new THREE.Mesh(arenaGeo, arenaMat);
    arenaMesh.position.set(0, 6, -5);
    scene.add(arenaMesh);

    // Hoop & Backboard Assembly
    const hoopGroup = new THREE.Group();
    const HOOP_POS = new THREE.Vector3(0, 2.7, -4.15); // Rim position
    scene.add(hoopGroup);

    // Solid Black Stanchion Pole
    const poleGeo = new THREE.CylinderGeometry(0.12, 0.14, 5.2, 16);
    const poleMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.2, metalness: 0.8 });
    const pole = new THREE.Mesh(poleGeo, poleMat);
    pole.position.set(0, 2.6, -5.2);
    pole.castShadow = true;
    hoopGroup.add(pole);

    // Backboard Support Struts
    const strutGeo = new THREE.CylinderGeometry(0.04, 0.04, 1.1, 8);
    const strut1 = new THREE.Mesh(strutGeo, poleMat);
    strut1.position.set(-0.35, 3.1, -4.9);
    strut1.rotation.x = Math.PI / 4;
    hoopGroup.add(strut1);

    const strut2 = new THREE.Mesh(strutGeo, poleMat);
    strut2.position.set(0.35, 3.1, -4.9);
    strut2.rotation.x = Math.PI / 4;
    hoopGroup.add(strut2);

    // Backboard (Polycarbonate Glass with Red border)
    const boardGeo = new THREE.BoxGeometry(1.8, 1.2, 0.08);
    const boardMat = new THREE.MeshStandardMaterial({
      color: 0xf8fafc,
      roughness: 0.15,
      transparent: true,
      opacity: 0.9,
    });
    const backboard = new THREE.Mesh(boardGeo, boardMat);
    backboard.position.set(0, 3.2, -4.6);
    backboard.castShadow = true;
    hoopGroup.add(backboard);

    // Inner Target Square
    const innerSqGeo = new THREE.BoxGeometry(0.6, 0.48, 0.09);
    const innerSqMat = new THREE.MeshStandardMaterial({ color: 0xef4444, roughness: 0.3 });
    const innerSq = new THREE.Mesh(innerSqGeo, innerSqMat);
    innerSq.position.set(0, 3.0, -4.6);
    hoopGroup.add(innerSq);

    // Rim Ring (Orange Steel Tube)
    const RIM_RADIUS = 0.38;
    const rimGeo = new THREE.TorusGeometry(RIM_RADIUS, 0.035, 12, 32);
    const rimMat = new THREE.MeshStandardMaterial({ color: 0xea580c, roughness: 0.25, metalness: 0.65 });
    const rim = new THREE.Mesh(rimGeo, rimMat);
    rim.rotation.x = Math.PI / 2;
    rim.position.copy(HOOP_POS);
    rim.castShadow = true;
    hoopGroup.add(rim);

    // White Rope Net (Tapered Open Cylinder Wireframe)
    const netGeo = new THREE.CylinderGeometry(RIM_RADIUS, RIM_RADIUS * 0.65, 0.55, 12, 6, true);
    const netMat = new THREE.MeshBasicMaterial({ color: 0xffffff, wireframe: true, transparent: true, opacity: 0.85 });
    const net = new THREE.Mesh(netGeo, netMat);
    net.position.set(HOOP_POS.x, HOOP_POS.y - 0.275, HOOP_POS.z);
    hoopGroup.add(net);

    // 3. 3D Basketball with Generated Pebble Leather Texture Map Asset
    const BALL_RADIUS = 0.22;
    const ballTexture = textureLoader.load(basketballTextureUrl);
    const ballGeo = new THREE.SphereGeometry(BALL_RADIUS, 32, 32);
    const ballMat = new THREE.MeshStandardMaterial({
      map: ballTexture,
      roughness: 0.45,
      metalness: 0.08,
    });
    const ballMesh = new THREE.Mesh(ballGeo, ballMat);
    ballMesh.castShadow = true;
    scene.add(ballMesh);

    const BALL_START_POS = new THREE.Vector3(0, 1.25, 2.2);
    ballMesh.position.copy(BALL_START_POS);

    // Protagonist 1st-Person Arms
    const playerArmsGroup = new THREE.Group();
    scene.add(playerArmsGroup);

    const skinMat = new THREE.MeshStandardMaterial({ color: 0xe5a36f, roughness: 0.65 });
    const sleeveMat = new THREE.MeshStandardMaterial({ color: 0x1e40af, roughness: 0.5 }); // Blue Team Jersey

    // Right Arm (Shooting Arm)
    const rightArmGroup = new THREE.Group();
    const rSleeve = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.11, 0.32, 12), sleeveMat);
    rSleeve.position.set(0.36, 1.1, 2.5);
    rSleeve.rotation.z = -0.3;
    rightArmGroup.add(rSleeve);

    const rArm = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.075, 0.6, 12), skinMat);
    rArm.position.set(0.28, 1.15, 2.3);
    rArm.rotation.set(-0.6, 0, -0.3);
    rightArmGroup.add(rArm);

    const rHand = new THREE.Mesh(new THREE.SphereGeometry(0.1, 12, 12), skinMat);
    rHand.position.set(0.16, 1.25, 2.05);
    rightArmGroup.add(rHand);
    playerArmsGroup.add(rightArmGroup);

    // Left Arm (Guide Arm)
    const leftArmGroup = new THREE.Group();
    const lSleeve = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.11, 0.32, 12), sleeveMat);
    lSleeve.position.set(-0.36, 1.1, 2.5);
    lSleeve.rotation.z = 0.3;
    leftArmGroup.add(lSleeve);

    const lArm = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.075, 0.6, 12), skinMat);
    lArm.position.set(-0.28, 1.15, 2.3);
    lArm.rotation.set(-0.6, 0, 0.3);
    leftArmGroup.add(lArm);

    const lHand = new THREE.Mesh(new THREE.SphereGeometry(0.1, 12, 12), skinMat);
    lHand.position.set(-0.16, 1.25, 2.05);
    leftArmGroup.add(lHand);
    playerArmsGroup.add(leftArmGroup);

    // Trajectory Arc Dotted Line Guide
    const arcGeo = new THREE.BufferGeometry();
    const arcMat = new THREE.LineDashedMaterial({
      color: 0x38bdf8,
      dashSize: 0.1,
      gapSize: 0.08,
      linewidth: 3,
    });
    const arcLine = new THREE.Line(arcGeo, arcMat);
    arcLine.visible = false;
    scene.add(arcLine);

    // Bonus Star Mesh
    const starGeo = new THREE.OctahedronGeometry(0.28, 0);
    const starMat = new THREE.MeshStandardMaterial({
      color: 0xfacc15,
      roughness: 0.1,
      metalness: 0.9,
      emissive: 0x854d0e,
    });
    const starMesh = new THREE.Mesh(starGeo, starMat);
    starMesh.visible = false;
    scene.add(starMesh);

    // Physics Engine State
    const ballPhysics = {
      pos: BALL_START_POS.clone(),
      vel: new THREE.Vector3(0, 0, 0),
      rotVel: new THREE.Vector3(0, 0, 0),
      state: 'ready' as 'ready' | 'flying' | 'layup' | 'done',
      touchedRim: false,
      touchedBoard: false,
      scored: false,
      starHit: false,
      doneTimer: 0,
    };

    const aim = {
      holding: false,
      chargeTime: 0,
      power: 0, // 0.0 to 1.0
      angleX: 0, // Horizontal aim degrees (-18 to +18)
      shootFollowThrough: 0,
    };

    function computeLaunchVelocity(powerNorm: number, angleXDeg: number): THREE.Vector3 {
      const currentHoopPos = HOOP_POS.clone().add(hoopGroup.position);
      const flightTime = 0.92;
      const g = 9.8;

      const targetX = currentHoopPos.x;
      const targetY = currentHoopPos.y + 0.38;
      const targetZ = currentHoopPos.z;

      const dx = targetX - BALL_START_POS.x;
      const dy = targetY - BALL_START_POS.y;
      const dz = targetZ - BALL_START_POS.z;

      const idealVx = (dx - 0.5 * (stateRef.current.windOn ? stateRef.current.windX : 0) * flightTime * flightTime) / flightTime;
      const idealVz = dz / flightTime;
      const idealVy = (dy + 0.5 * g * flightTime * flightTime) / flightTime;

      // Green Zone Check (67% ~ 77% optimal power -> guaranteed clean swish)
      const isGreenZone = powerNorm >= 0.67 && powerNorm <= 0.77;

      const aimAngleRad = (angleXDeg * Math.PI) / 180;
      if (isGreenZone) {
        return new THREE.Vector3(idealVx + Math.tan(aimAngleRad) * 2.5, idealVy, idealVz);
      } else {
        const targetCenter = 0.72;
        const factor = Math.max(0.15, powerNorm / targetCenter);
        const vx = idealVx * factor + Math.tan(aimAngleRad) * 3.0;
        const vy = idealVy * Math.pow(factor, 0.85);
        const vz = idealVz * factor;
        return new THREE.Vector3(vx, vy, vz);
      }
    }

    function shootBall() {
      if (ballPhysics.state !== 'ready') return;

      ballPhysics.state = 'flying';
      ballPhysics.pos.copy(ballMesh.position);

      const vel = computeLaunchVelocity(aim.power, aim.angleX);
      ballPhysics.vel.copy(vel);

      ballPhysics.rotVel.set(-8 - aim.power * 4, (Math.random() - 0.5) * 4, 0);

      sfxShoot(aim.power);
      arcLine.visible = false;
      aim.shootFollowThrough = 0.35;

      // Real-time Release Marker & Status Feedback
      const pct = Math.round(aim.power * 100);
      const isGreen = aim.power >= 0.67 && aim.power <= 0.77;

      const markerEl = document.getElementById('gaugeReleaseMarker');
      if (markerEl) {
        markerEl.style.left = `${pct}%`;
        markerEl.style.display = 'block';
        markerEl.style.backgroundColor = isGreen ? '#34d399' : '#ffffff';
        markerEl.style.boxShadow = isGreen ? '0 0 12px #10b981' : '0 0 8px #ffffff';
      }

      const zoneBadge = document.getElementById('gaugeZoneBadge');
      if (zoneBadge) {
        if (isGreen) {
          zoneBadge.textContent = '🎯 완벽!';
          zoneBadge.className = 'text-[10px] font-black px-2 py-0.5 rounded-md bg-emerald-500 text-slate-950 shadow-[0_0_10px_#10b981]';
        } else if (pct < 67) {
          zoneBadge.textContent = '⬇️ 약함';
          zoneBadge.className = 'text-[10px] font-black px-2 py-0.5 rounded-md bg-sky-500/30 text-sky-300 border border-sky-400/50';
        } else {
          zoneBadge.textContent = '⬆️ 강함';
          zoneBadge.className = 'text-[10px] font-black px-2 py-0.5 rounded-md bg-rose-500/30 text-rose-300 border border-rose-400/50';
        }
      }

      const statusEl = document.getElementById('gaugeStatus');
      if (statusEl) {
        if (isGreen) {
          statusEl.textContent = `(발사: ${pct}% - 완벽한 스위시 타이밍!)`;
        } else if (pct < 67) {
          statusEl.textContent = `(발사: ${pct}% - 파워가 약해 숏입니다)`;
        } else {
          statusEl.textContent = `(발사: ${pct}% - 파워가 강해 백보드를 맞힙니다)`;
        }
      }

      const fillEl = document.getElementById('gaugeFill');
      if (fillEl) {
        fillEl.style.opacity = '0.45';
      }
    }

    function triggerLayup() {
      if (!stateRef.current.isPlaying || ballPhysics.state !== 'ready' || stateRef.current.isLayupActive) return;
      stateRef.current.isLayupActive = true;
      stateRef.current.layupTime = 0;
      ballPhysics.state = 'layup';
      callbacksRef.current.onLayupStateChange(true);
      sfxLayup();
      arcLine.visible = false;
    }

    function resetForNextBall() {
      ballPhysics.pos.copy(BALL_START_POS);
      ballPhysics.vel.set(0, 0, 0);
      ballPhysics.rotVel.set(0, 0, 0);
      ballPhysics.state = 'ready';
      ballPhysics.touchedRim = false;
      ballPhysics.touchedBoard = false;
      ballPhysics.scored = false;
      ballPhysics.starHit = false;
      ballPhysics.doneTimer = 0;

      stateRef.current.isLayupActive = false;
      stateRef.current.layupTime = 0;
      callbacksRef.current.onLayupStateChange(false);

      aim.holding = false;
      aim.chargeTime = 0;
      aim.power = 0;
      aim.shootFollowThrough = 0;
      callbacksRef.current.onPowerChange(0);

      // Reset gauge DOM elements
      const fillEl = document.getElementById('gaugeFill');
      if (fillEl) {
        fillEl.style.width = '0%';
        fillEl.style.opacity = '1';
        fillEl.className = 'absolute top-0 left-0 bottom-0 bg-gradient-to-r from-blue-500 via-amber-400 to-rose-500 will-change-[width] pointer-events-none';
      }
      const powerVal = document.getElementById('powerVal');
      if (powerVal) {
        powerVal.textContent = '0%';
        powerVal.className = 'text-amber-400 font-mono font-black text-sm min-w-[36px] text-right';
      }
      const markerEl = document.getElementById('gaugeReleaseMarker');
      if (markerEl) {
        markerEl.style.display = 'none';
      }
      const zoneBadge = document.getElementById('gaugeZoneBadge');
      if (zoneBadge) {
        zoneBadge.textContent = '대기 중';
        zoneBadge.className = 'text-[10px] font-black px-2 py-0.5 rounded-md bg-slate-800 text-slate-400';
      }
      const statusEl = document.getElementById('gaugeStatus');
      if (statusEl) {
        statusEl.textContent = '(화면/게이지 터치 or 스페이스바 유지)';
      }

      camera.position.copy(CAMERA_HOME);

      playerArmsGroup.visible = true;
      playerArmsGroup.position.set(0, 0, 0);
      rightArmGroup.position.set(0, 0, 0);
      rightArmGroup.rotation.set(0, 0, 0);
      leftArmGroup.position.set(0, 0, 0);

      ballMesh.visible = true;
      ballMesh.position.copy(BALL_START_POS);
      ballMesh.rotation.set(0, 0, 0);

      if (stateRef.current.level >= 3 && Math.random() < 0.7) {
        starMesh.visible = true;
        starMesh.position.set(rand(-1.2, 1.2), rand(2.8, 3.8), rand(-2.5, -3.8));
      } else {
        starMesh.visible = false;
      }
    }

    function handleScore() {
      ballPhysics.scored = true;
      const isSwish = !ballPhysics.touchedRim && !ballPhysics.touchedBoard;
      const starHit = ballPhysics.starHit;

      let pts = 100;
      if (isSwish) {
        pts += 100;
        sfxSwish();
      } else {
        sfxGoal();
      }
      if (starHit) {
        pts += 150;
      }

      stateRef.current.shake = 0.2;
      stateRef.current.shakeMag = 0.08;
      callbacksRef.current.onScore(pts, isSwish, starHit);
    }

    function handleMiss() {
      callbacksRef.current.onMiss();
    }

    // Input Handlers
    const keys: Record<string, boolean> = {};

    const onKeyDown = (e: KeyboardEvent) => {
      keys[e.code] = true;
      if (e.code === 'Space') {
        e.preventDefault();
        if (stateRef.current.isPlaying && ballPhysics.state === 'ready') {
          if (!aim.holding) {
            ensureAudio();
            aim.holding = true;
          }
        }
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      keys[e.code] = false;
      if (e.code === 'Space') {
        e.preventDefault();
        if (stateRef.current.isPlaying && ballPhysics.state === 'ready') {
          if (aim.holding) {
            aim.holding = false;
            shootBall();
          }
        }
      }
    };

    let pointerDown = false;
    const onPointerDown = (e: PointerEvent) => {
      const target = e.target as HTMLElement | null;
      if (target?.closest('button') || target?.closest('#titleScreen') || target?.closest('#overScreen')) return;
      if (stateRef.current.isPlaying && ballPhysics.state === 'ready') {
        ensureAudio();
        pointerDown = true;
        aim.holding = true;
      }
    };

    const onPointerUp = () => {
      if (pointerDown && stateRef.current.isPlaying && ballPhysics.state === 'ready') {
        pointerDown = false;
        aim.holding = false;
        shootBall();
      }
    };

    const onPointerCancel = () => {
      if (pointerDown) {
        pointerDown = false;
        if (aim.holding) {
          aim.holding = false;
          if (ballPhysics.state === 'ready') {
            shootBall();
          }
        }
      }
    };

    const onPointerMove = (e: PointerEvent) => {
      if (pointerDown && ballPhysics.state === 'ready') {
        aim.angleX += e.movementX * 0.08;
        aim.angleX = clamp(aim.angleX, -18, 18);
      }
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('pointerdown', onPointerDown);
    window.addEventListener('pointerup', onPointerUp);
    window.addEventListener('pointercancel', onPointerCancel);
    window.addEventListener('pointermove', onPointerMove);

    // Resize Handler
    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    // Main Animation Loop
    let animId: number;
    const clock = new THREE.Clock();

    const animate = () => {
      animId = requestAnimationFrame(animate);

      const dt = Math.min(clock.getDelta(), 0.1);
      stateRef.current.time += dt;

      // Check external layup trigger
      if (stateRef.current.isLayupTriggered) {
        callbacksRef.current.onLayupHandled();
        triggerLayup();
      }

      if (stateRef.current.isPlaying) {
        // Keyboard Aiming
        if (ballPhysics.state === 'ready') {
          if (keys['ArrowLeft'] || keys['KeyA']) aim.angleX -= 35 * dt;
          if (keys['ArrowRight'] || keys['KeyD']) aim.angleX += 35 * dt;
          aim.angleX = clamp(aim.angleX, -18, 18);
        }

        // Layup Driving Sequence
        if (stateRef.current.isLayupActive && ballPhysics.state === 'layup') {
          stateRef.current.layupTime += dt * 1.8;
          const t = stateRef.current.layupTime;

          if (t < 0.6) {
            const prog = t / 0.6;
            camera.position.set(0, CAMERA_HOME.y + Math.sin(prog * Math.PI) * 0.45, CAMERA_HOME.z - prog * 4.2);
            playerArmsGroup.position.set(0, Math.sin(prog * Math.PI) * 0.5, -prog * 4.2);
            ballMesh.position.set(0, 1.35 + Math.sin(prog * Math.PI) * 0.7, 2.2 - prog * 4.2);
          } else if (t >= 0.6 && t < 0.8) {
            if (ballPhysics.state === 'layup') {
              ballPhysics.state = 'flying';
              ballPhysics.pos.set(0, 2.85, -3.2);
              ballPhysics.vel.set(0, 3.2, -1.8);
              ballPhysics.rotVel.set(-6, 0, 0);
              sfxShoot(0.8);
              stateRef.current.shake = 0.15;
              stateRef.current.shakeMag = 0.1;
              aim.shootFollowThrough = 0.35;
            }
          }
        }

        // Power Charging & Arc Display
        if (ballPhysics.state === 'ready') {
          if (aim.holding) {
            aim.chargeTime += dt * 1.1; // Smooth, accessible human timing
            const cycle = aim.chargeTime % 2.0;
            aim.power = cycle <= 1.0 ? cycle : 2.0 - cycle;
          } else {
            aim.chargeTime = 0;
            aim.power = Math.max(0, aim.power - dt * 2.5);
          }

          const pct = Math.round(aim.power * 100);
          const isGreen = aim.power >= 0.67 && aim.power <= 0.77;

          // Direct DOM updates for 0ms lag
          const fillEl = document.getElementById('gaugeFill');
          if (fillEl) {
            fillEl.style.width = `${pct}%`;
            if (isGreen) {
              fillEl.className = 'absolute top-0 left-0 bottom-0 bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-400 shadow-[0_0_12px_#34d399] will-change-[width] pointer-events-none';
            } else {
              fillEl.className = 'absolute top-0 left-0 bottom-0 bg-gradient-to-r from-blue-500 via-amber-400 to-rose-500 will-change-[width] pointer-events-none';
            }
          }

          const powerVal = document.getElementById('powerVal');
          if (powerVal) {
            powerVal.textContent = `${pct}%`;
            if (isGreen) {
              powerVal.className = 'text-emerald-400 font-mono font-black text-sm min-w-[36px] text-right drop-shadow-[0_0_8px_rgba(52,211,153,0.8)]';
            } else {
              powerVal.className = 'text-amber-400 font-mono font-black text-sm min-w-[36px] text-right';
            }
          }

          const zoneBadge = document.getElementById('gaugeZoneBadge');
          if (zoneBadge && aim.holding) {
            if (isGreen) {
              zoneBadge.textContent = '🎯 성공권!';
              zoneBadge.className = 'text-[10px] font-black px-2 py-0.5 rounded-md bg-emerald-500 text-slate-950 animate-bounce shadow-[0_0_10px_#10b981]';
            } else if (pct < 67) {
              zoneBadge.textContent = '충전 중';
              zoneBadge.className = 'text-[10px] font-black px-2 py-0.5 rounded-md bg-blue-900/60 text-blue-300 border border-blue-500/40';
            } else {
              zoneBadge.textContent = '파워 초과';
              zoneBadge.className = 'text-[10px] font-black px-2 py-0.5 rounded-md bg-rose-900/60 text-rose-300 border border-rose-500/40';
            }
          }

          const statusEl = document.getElementById('gaugeStatus');
          if (statusEl && aim.holding) {
            statusEl.textContent = isGreen ? '✨ 지금 손을 떼세요!' : '충전 중... 적정 파워(67%~77%)에서 떼기';
          }

          const dip = aim.power * 0.15;
          rightArmGroup.position.set(0, -dip, -dip * 0.4);
          leftArmGroup.position.set(0, -dip, -dip * 0.4);
          ballMesh.position.set(BALL_START_POS.x, BALL_START_POS.y - dip, BALL_START_POS.z - dip * 0.4);

          arcLine.visible = aim.power > 0.02;
          if (arcLine.visible) {
            const pts: THREE.Vector3[] = [];
            const simPos = ballMesh.position.clone();
            const simVel = computeLaunchVelocity(aim.power, aim.angleX);
            const simDt = 0.04;
            for (let i = 0; i < 22; i++) {
              pts.push(simPos.clone());
              simVel.y -= 9.8 * simDt;
              if (stateRef.current.windOn) simVel.x += stateRef.current.windX * simDt;
              simPos.addScaledVector(simVel, simDt);
            }
            arcGeo.setFromPoints(pts);
            arcLine.computeLineDistances();
          }
        }

        // Arm Follow-Through Motion
        if (aim.shootFollowThrough > 0) {
          aim.shootFollowThrough -= dt;
          const ft = aim.shootFollowThrough / 0.35;
          rightArmGroup.position.set(0, (1 - ft) * 0.35, -(1 - ft) * 0.4);
          rightArmGroup.rotation.x = -(1 - ft) * 0.6;
          if (aim.shootFollowThrough <= 0) {
            playerArmsGroup.visible = false;
          }
        }

        // Flight & Collision Engine
        if (ballPhysics.state === 'flying') {
          const p = ballPhysics.pos;
          const v = ballPhysics.vel;

          v.y -= 9.8 * dt;
          if (stateRef.current.windOn) v.x += stateRef.current.windX * dt;

          p.addScaledVector(v, dt);
          ballMesh.position.copy(p);

          ballMesh.rotation.x += ballPhysics.rotVel.x * dt;
          ballMesh.rotation.y += ballPhysics.rotVel.y * dt;

          // Metal Pole Collision (Position: X:0, Z:-5.2)
          const poleRadius = 0.14;
          const dxPole = p.x;
          const dzPole = p.z - -5.2;
          const distPoleSq = dxPole * dxPole + dzPole * dzPole;
          const minDistPole = poleRadius + BALL_RADIUS;
          if (p.y >= 0 && p.y <= 5.5 && distPoleSq < minDistPole * minDistPole) {
            const distPole = Math.sqrt(distPoleSq);
            if (distPole > 0.001) {
              const nx = dxPole / distPole;
              const nz = dzPole / distPole;
              const dot = v.x * nx + v.z * nz;
              if (dot < 0) {
                v.x -= 1.8 * dot * nx;
                v.z -= 1.8 * dot * nz;
                v.multiplyScalar(0.68);
                p.x = nx * (minDistPole + 0.01);
                p.z = -5.2 + nz * (minDistPole + 0.01);
                sfxBounce(true);
              }
            }
          }

          // Bonus Star Collision
          if (starMesh.visible && !ballPhysics.starHit) {
            if (p.distanceTo(starMesh.position) < BALL_RADIUS + 0.3) {
              ballPhysics.starHit = true;
              starMesh.visible = false;
              sfxStar();
            }
          }

          const currentHoopPos = HOOP_POS.clone().add(hoopGroup.position);
          const backboardZ = currentHoopPos.z - 0.45;

          // Backboard Collision
          if (p.z - BALL_RADIUS <= backboardZ && p.z + BALL_RADIUS >= backboardZ - 0.1) {
            if (Math.abs(p.x - currentHoopPos.x) < 1.1 && p.y > currentHoopPos.y - 0.2 && p.y < currentHoopPos.y + 1.2) {
              if (v.z < 0) {
                v.z = -v.z * 0.55;
                p.z = backboardZ + BALL_RADIUS;
                ballPhysics.touchedBoard = true;
                sfxBounce(true);
              }
            }
          }

          // Rim Ring Collision
          const distToRimCenter = Math.sqrt(Math.pow(p.x - currentHoopPos.x, 2) + Math.pow(p.z - currentHoopPos.z, 2));
          if (Math.abs(p.y - currentHoopPos.y) < BALL_RADIUS + 0.08 && Math.abs(distToRimCenter - RIM_RADIUS) < BALL_RADIUS) {
            ballPhysics.touchedRim = true;
            sfxBounce(false);

            const normal = new THREE.Vector3(p.x - currentHoopPos.x, (p.y - currentHoopPos.y) * 2, p.z - currentHoopPos.z).normalize();
            v.reflect(normal).multiplyScalar(0.6);
            p.addScaledVector(v, dt * 2);
          }

          // Goal Trigger
          if (!ballPhysics.scored && p.y <= currentHoopPos.y && p.y >= currentHoopPos.y - 0.4) {
            if (distToRimCenter < RIM_RADIUS - 0.08 && v.y < 0) {
              handleScore();
            }
          }

          // Floor Bounce & Rolling
          if (p.y - BALL_RADIUS <= 0.001) {
            p.y = BALL_RADIUS;
            if (Math.abs(v.y) > 1.2) {
              sfxBounce(false);
              v.y = -v.y * 0.4;
            } else {
              v.y = 0;
            }
            v.x *= 0.92;
            v.z *= 0.92;
          }

          // End Shot Determination
          if (p.y <= BALL_RADIUS + 0.02 && Math.abs(v.y) < 0.5) {
            if (v.length() < 0.5) {
              ballPhysics.doneTimer += dt;
              if (ballPhysics.doneTimer > 0.8) {
                ballPhysics.state = 'done';
                if (!ballPhysics.scored) handleMiss();
                setTimeout(resetForNextBall, 500);
              }
            }
          } else if (p.z < -9 || p.y < 0.1 || p.z > 6) {
            ballPhysics.doneTimer += dt;
            if (ballPhysics.doneTimer > 0.2) {
              ballPhysics.state = 'done';
              if (!ballPhysics.scored) handleMiss();
              setTimeout(resetForNextBall, 500);
            }
          }
        }

        // Camera Shake
        if (stateRef.current.shake > 0) {
          stateRef.current.shake -= dt;
          camera.position.x = (stateRef.current.isLayupActive ? camera.position.x : CAMERA_HOME.x) + (Math.random() * 2 - 1) * stateRef.current.shakeMag;
          camera.position.y = (stateRef.current.isLayupActive ? camera.position.y : CAMERA_HOME.y) + (Math.random() * 2 - 1) * stateRef.current.shakeMag;
        } else if (!stateRef.current.isLayupActive) {
          camera.position.copy(CAMERA_HOME);
        }
        camera.lookAt(hoopGroup.position.x * 0.2, 2.7, -4.15);
      }

      // Rotate Star Item
      if (starMesh.visible) {
        starMesh.rotation.y += dt * 2.5;
        starMesh.rotation.x += dt * 1.2;
      }

      renderer.render(scene, camera);
    };

    // Kick off animation loop immediately
    animate();

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('pointerdown', onPointerDown);
      window.removeEventListener('pointerup', onPointerUp);
      window.removeEventListener('pointercancel', onPointerCancel);
      window.removeEventListener('pointermove', onPointerMove);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
    };
  }, []);

  return (
    <div ref={containerRef} className="relative w-full h-full overflow-hidden select-none bg-slate-950">
      <canvas
        ref={canvasRef}
        id="gameCanvas"
        className="w-full h-full block cursor-crosshair touch-none"
      />
    </div>
  );
}
