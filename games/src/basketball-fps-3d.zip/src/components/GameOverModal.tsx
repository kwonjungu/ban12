import heroBannerUrl from '../assets/images/basketball_hero_banner_1789882147270.jpg';
import { RotateCcw, Trophy, Flame, Zap } from 'lucide-react';

interface GameOverModalProps {
  score: number;
  bestScore: number;
  bestCombo: number;
  swishes: number;
  onRetry: () => void;
}

export default function GameOverModal({
  score,
  bestScore,
  bestCombo,
  swishes,
  onRetry,
}: GameOverModalProps) {
  const isNewRecord = score > 0 && score >= bestScore;

  return (
    <div
      id="overScreen"
      className="absolute inset-0 bg-slate-950/85 backdrop-blur-md z-30 flex items-center justify-center p-4 overflow-y-auto"
    >
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col my-auto animate-in zoom-in-95 duration-200">
        {/* Banner with Result */}
        <div className="relative w-full h-36 sm:h-40 overflow-hidden bg-slate-950">
          <img
            src={heroBannerUrl}
            alt="Basketball Match Result"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center brightness-75"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/40 to-transparent" />
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-4">
            <span className="text-3xl mb-1">🏁</span>
            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              게임 종료!
            </h2>
            {isNewRecord && (
              <span className="mt-1 px-3 py-0.5 rounded-full bg-amber-500 text-slate-950 text-xs font-black animate-bounce">
                🎉 신기록 달성!
              </span>
            )}
          </div>
        </div>

        {/* Stats Content */}
        <div className="p-5 sm:p-6 space-y-4">
          <div className="bg-slate-950/80 p-4 rounded-2xl border border-slate-800 space-y-3">
            <div className="flex justify-between items-center text-sm text-slate-300">
              <span className="flex items-center gap-1.5 font-bold">
                <Trophy className="w-4 h-4 text-amber-400" />
                최종 점수
              </span>
              <span id="finalScore" className="text-2xl font-black text-amber-400 font-mono">
                {score}점
              </span>
            </div>

            <div className="w-full h-px bg-slate-800" />

            <div className="flex justify-between items-center text-xs text-slate-400">
              <span className="flex items-center gap-1.5">
                <Flame className="w-3.5 h-3.5 text-orange-400" />
                최고 연속 콤보
              </span>
              <span id="finalCombo" className="font-bold text-white">
                {bestCombo}회
              </span>
            </div>

            <div className="flex justify-between items-center text-xs text-slate-400">
              <span className="flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-emerald-400" />
                클린 스위시(SWISH) 골
              </span>
              <span id="finalSwish" className="font-bold text-emerald-400">
                {swishes}회
              </span>
            </div>
          </div>

          <button
            id="retryBtn"
            onClick={onRetry}
            className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-orange-500 via-amber-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white font-black text-lg py-3.5 px-6 rounded-full shadow-[0_8px_25px_rgba(249,115,22,0.4)] active:scale-95 transition-all cursor-pointer"
          >
            <RotateCcw className="w-5 h-5" />
            <span>다시 도전하기</span>
          </button>

          <div className="text-center text-xs font-bold text-slate-400">
            역대 최고 기록: <span id="bestOver" className="text-amber-400 font-mono text-sm">{bestScore}</span>점
          </div>
        </div>
      </div>
    </div>
  );
}
