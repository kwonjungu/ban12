import * as THREE from 'three';
import { WeaponId, WeaponData, JobClassId, JobClassData } from '../types';

export const INITIAL_WEAPONS: Record<WeaponId, WeaponData> = {
  // Slot 1: Primary (주무기)
  RIFLE: {
    id: 'RIFLE',
    name: '헤비 어설트 라이플',
    category: '돌격소총',
    slot: 1,
    damage: 55,
    fireRate: 0.12,
    magSize: 30,
    maxReserve: 210,
    reloadTime: 1.2,
    cost: 0,
    unlocked: true,
    icon: 'Crosshair',
    description: '연사력과 명중률의 균형이 뛰어난 군용 표준 돌격소총'
  },
  SNIPER: {
    id: 'SNIPER',
    name: '대물 저격소총',
    category: '저격총',
    slot: 1,
    damage: 350,
    fireRate: 0.85,
    magSize: 5,
    maxReserve: 35,
    reloadTime: 2.0,
    cost: 650,
    unlocked: false,
    icon: 'Target',
    description: '원거리의 강력한 좀비와 보스를 관통하는 고위력 대구경 저격총'
  },
  SHOTGUN: {
    id: 'SHOTGUN',
    name: '네온 샷건',
    category: '산탄총',
    slot: 1,
    damage: 190,
    fireRate: 0.65,
    magSize: 8,
    maxReserve: 56,
    reloadTime: 1.7,
    cost: 800,
    unlocked: false,
    icon: 'Zap',
    description: '근접에서 강력한 네온 파쇄탄을 쏟아붓는 펌프액션 산탄총'
  },
  MINIGUN: {
    id: 'MINIGUN',
    name: '회전식 미니건',
    category: '중화기',
    slot: 1,
    damage: 42,
    fireRate: 0.055,
    magSize: 120,
    maxReserve: 480,
    reloadTime: 3.0,
    cost: 1800,
    unlocked: false,
    icon: 'Layers',
    description: '6연장 회전 총열에서 초당 18발의 총탄을 퍼붓는 학살용 화기'
  },

  // Slot 2: Secondary (보조무기)
  PISTOL: {
    id: 'PISTOL',
    name: '전술 레이저 권총',
    category: '권총',
    slot: 2,
    damage: 45,
    fireRate: 0.2,
    magSize: 15,
    maxReserve: 120,
    reloadTime: 0.9,
    cost: 0,
    unlocked: true,
    icon: 'Crosshair',
    description: '가볍고 민첩하며 하단 레이저 조준기를 장착한 전술 권총'
  },
  SMG: {
    id: 'SMG',
    name: '플라즈마 SMG',
    category: '기관단총',
    slot: 2,
    damage: 36,
    fireRate: 0.08,
    magSize: 35,
    maxReserve: 210,
    reloadTime: 1.1,
    cost: 500,
    unlocked: false,
    icon: 'Radio',
    description: '초고속 탄막을 뿜어내는 컴팩트 플라즈마 기관단총'
  },

  // Slot 3: Melee (근접무기)
  KATANA: {
    id: 'KATANA',
    name: '사이보그 카타나',
    category: '근접도검',
    slot: 3,
    damage: 160,
    fireRate: 0.32,
    magSize: 1,
    maxReserve: 999,
    reloadTime: 0.1,
    cost: 0,
    unlocked: true,
    isMelee: true,
    icon: 'Sword',
    description: '고주파 진동으로 장갑을 절단하는 사이버네틱 특수 검'
  },

  // Slot 4: Throwable & Throwable Melee (투척 및 투척 근접무기)
  GRENADE: {
    id: 'GRENADE',
    name: '고성능 세열수류탄',
    category: '투척무기',
    slot: 4,
    damage: 550,
    fireRate: 0.9,
    magSize: 1,
    maxReserve: 10,
    reloadTime: 0.6,
    cost: 0,
    unlocked: true,
    isThrowable: true,
    icon: 'Bomb',
    impactType: 'NORMAL',
    description: '광범위의 좀비 무리를 일격에 섬멸하는 강력한 지연 신관 세열 폭탄'
  },
  THROWING_AXE: {
    id: 'THROWING_AXE',
    name: '플라즈마 투척 토마호크',
    category: '투척근접무기',
    slot: 4,
    damage: 420,
    fireRate: 0.45,
    magSize: 1,
    maxReserve: 15,
    reloadTime: 0.3,
    cost: 450,
    unlocked: true,
    isThrowable: true,
    icon: 'Axe',
    impactType: 'AXE',
    description: '[투척 근접무기] 던지면 회전하며 날아가 적에게 꽂히는 순간 고열 충격 폭발을 일으키는 투척 도끼'
  },
  EXPLOSIVE_SPEAR: {
    id: 'EXPLOSIVE_SPEAR',
    name: '사이퍼 폭탄 투척창',
    category: '투척근접무기',
    slot: 4,
    damage: 680,
    fireRate: 0.75,
    magSize: 1,
    maxReserve: 8,
    reloadTime: 0.4,
    cost: 750,
    unlocked: false,
    isThrowable: true,
    icon: 'Zap',
    impactType: 'SPEAR',
    description: '[투척 근접무기] 초고속으로 직선 비행하여 관통 후 초강력 연쇄 폭발을 일으키는 최첨단 투창'
  },

  // 직업별 전용 신규 무기 (5 Class Signature Weapons)
  COMMANDO_VULCAN: {
    id: 'COMMANDO_VULCAN',
    name: '커맨더 택티컬 발칸포',
    category: '돌격대장 전용',
    slot: 1,
    damage: 90,
    fireRate: 0.08,
    magSize: 50,
    maxReserve: 350,
    reloadTime: 1.4,
    cost: 1200,
    unlocked: false,
    icon: 'Crosshair',
    exclusiveJob: 'COMMANDO',
    impactType: 'VULCAN',
    description: '[돌격대장 전용] 3점사 연쇄 폭발탄을 고속 발사하여 화염 폭풍 충격을 일으키는 강화 발칸포'
  },
  RAILGUN: {
    id: 'RAILGUN',
    name: '초전자 레일건 캐논',
    category: '스나이퍼 전용',
    slot: 1,
    damage: 750,
    fireRate: 1.1,
    magSize: 4,
    maxReserve: 28,
    reloadTime: 2.2,
    cost: 1500,
    unlocked: false,
    icon: 'Target',
    exclusiveJob: 'SNIPER',
    impactType: 'RAILGUN',
    description: '[스나이퍼 전용] 음속 5배의 전자기 코일 가속으로 경로상의 모든 좀비를 꿰뚫는 일격필살 캐논'
  },
  BIO_LAUNCHER: {
    id: 'BIO_LAUNCHER',
    name: '나노 바이오 런처',
    category: '메디크 전용',
    slot: 1,
    damage: 220,
    fireRate: 0.45,
    magSize: 12,
    maxReserve: 84,
    reloadTime: 1.5,
    cost: 1100,
    unlocked: false,
    icon: 'Heart',
    exclusiveJob: 'MEDIC',
    impactType: 'BIO',
    description: '[메디크 전용] 산성 맹독 플라즈마 구체를 사출하여 광역 침식 폭발을 일으키고 좀비를 융해'
  },
  BLOOD_SCYTHE: {
    id: 'BLOOD_SCYTHE',
    name: '블러드 서클 대낫',
    category: '버서커 전용',
    slot: 3,
    damage: 380,
    fireRate: 0.38,
    magSize: 1,
    maxReserve: 999,
    reloadTime: 0.1,
    cost: 1600,
    unlocked: false,
    isMelee: true,
    icon: 'Flame',
    exclusiveJob: 'BERSERKER',
    impactType: 'BLOOD',
    description: '[버서커 전용] 핏빛 검기를 360도 전방위로 방출하며 좀비들을 단번에 베어 넘기는 거대 낫'
  },
  TITAN_HAMMER: {
    id: 'TITAN_HAMMER',
    name: '타이탄 지진분쇄 해머',
    category: '중장갑 든든이 전용',
    slot: 3,
    damage: 550,
    fireRate: 0.55,
    magSize: 1,
    maxReserve: 999,
    reloadTime: 0.1,
    cost: 1800,
    unlocked: false,
    isMelee: true,
    icon: 'ShieldAlert',
    exclusiveJob: 'JUGGERNAUT',
    impactType: 'TITAN',
    description: '[중장갑 든든이 전용] 강철 망치로 지면을 강타하여 거대한 지진 충격파와 함께 좀비들을 넉백 분쇄'
  }
};

export const INITIAL_CLASSES: Record<JobClassId, JobClassData> = {
  COMMANDO: {
    id: 'COMMANDO',
    name: '돌격대장',
    desc: '균형 잡힌 전투 능력과 표준 이동속도. 전용 무기: 커맨더 택티컬 발칸포',
    cost: 0,
    unlocked: true,
    hpBonus: 0,
    shieldBonus: 0,
    dmgMultiplier: 1.0,
    speedBonus: 0,
    signatureWeaponId: 'COMMANDO_VULCAN',
    icon: 'Shield'
  },
  SNIPER: {
    id: 'SNIPER',
    name: '스나이퍼',
    desc: '사격 총기 데미지 +30% 및 원거리 관통 특화. 전용 무기: 초전자 레일건 캐논',
    cost: 500,
    unlocked: false,
    hpBonus: -10,
    shieldBonus: 0,
    dmgMultiplier: 1.3,
    speedBonus: 0.015,
    signatureWeaponId: 'RAILGUN',
    icon: 'Target'
  },
  MEDIC: {
    id: 'MEDIC',
    name: '메디크',
    desc: '체력 +50, 실드 +20, 포션 효과 2배 증폭. 전용 무기: 나노 바이오 런처',
    cost: 800,
    unlocked: false,
    hpBonus: 50,
    shieldBonus: 20,
    dmgMultiplier: 1.0,
    speedBonus: 0,
    signatureWeaponId: 'BIO_LAUNCHER',
    icon: 'Heart'
  },
  BERSERKER: {
    id: 'BERSERKER',
    name: '버서커',
    desc: '이동속도 +25% 및 근접 공격 데미지 2.2배 증폭. 전용 무기: 블러드 서클 대낫',
    cost: 1200,
    unlocked: false,
    hpBonus: 30,
    shieldBonus: 0,
    dmgMultiplier: 1.1,
    speedBonus: 0.045,
    meleeMultiplier: 2.2,
    signatureWeaponId: 'BLOOD_SCYTHE',
    icon: 'Flame'
  },
  JUGGERNAUT: {
    id: 'JUGGERNAUT',
    name: '중장갑 든든이',
    desc: '체력 +100, 실드 +100 및 궁극의 방어 내성. 전용 무기: 타이탄 지진분쇄 해머',
    cost: 2000,
    unlocked: false,
    hpBonus: 100,
    shieldBonus: 100,
    dmgMultiplier: 1.15,
    speedBonus: -0.01,
    signatureWeaponId: 'TITAN_HAMMER',
    icon: 'ShieldAlert'
  }
};

/**
 * Procedurally generates distinct, high-detail 3D models for each weapon!
 */
export function createWeapon3DModel(weaponId: WeaponId): { root: THREE.Group; barrels?: THREE.Mesh[] } {
  const root = new THREE.Group();

  switch (weaponId) {
    case 'RIFLE': {
      // 1. Heavy Assault Rifle
      // Receiver
      const bodyMat = new THREE.MeshStandardMaterial({ color: 0x1c1e24, roughness: 0.4, metalness: 0.8 });
      const tanMat = new THREE.MeshStandardMaterial({ color: 0x6e5d48, roughness: 0.6 });
      const glowCyan = new THREE.MeshBasicMaterial({ color: 0x00f0ff });

      const receiver = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.12, 0.38), bodyMat);
      receiver.position.set(0, 0, -0.15);
      root.add(receiver);

      // Long fluted barrel
      const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.022, 0.45, 12), bodyMat);
      barrel.rotation.x = Math.PI / 2;
      barrel.position.set(0, 0.02, -0.48);
      root.add(barrel);

      // Muzzle brake
      const brake = new THREE.Mesh(new THREE.BoxGeometry(0.045, 0.045, 0.08), bodyMat);
      brake.position.set(0, 0.02, -0.73);
      root.add(brake);

      // Curved magazine
      const mag = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.22, 0.1), bodyMat);
      mag.position.set(0, -0.12, -0.16);
      mag.rotation.x = -0.3;
      root.add(mag);

      // Stock
      const stock = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.14, 0.24), tanMat);
      stock.position.set(0, -0.02, 0.1);
      root.add(stock);

      // Holo sight mount & glass
      const sightMount = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.05, 0.12), bodyMat);
      sightMount.position.set(0, 0.085, -0.2);
      root.add(sightMount);

      const holoGlass = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.04, 0.01), glowCyan);
      holoGlass.position.set(0, 0.09, -0.25);
      root.add(holoGlass);

      // Foregrip
      const foregrip = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 0.12, 8), tanMat);
      foregrip.position.set(0, -0.08, -0.36);
      root.add(foregrip);

      return { root };
    }

    case 'SNIPER': {
      // 2. Heavy Anti-Material Sniper Rifle
      const camoMat = new THREE.MeshStandardMaterial({ color: 0x2d3a29, roughness: 0.5, metalness: 0.7 });
      const metalMat = new THREE.MeshStandardMaterial({ color: 0x111317, roughness: 0.2, metalness: 0.95 });
      const scopeLensMat = new THREE.MeshBasicMaterial({ color: 0x00ff88 });

      // Extended chassis
      const frame = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.12, 0.55), camoMat);
      frame.position.set(0, 0, -0.2);
      root.add(frame);

      // Massive long barrel
      const longBarrel = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.03, 0.75, 12), metalMat);
      longBarrel.rotation.x = Math.PI / 2;
      longBarrel.position.set(0, 0.03, -0.75);
      root.add(longBarrel);

      // Giant slotted muzzle brake
      const bigBrake = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.06, 0.14), metalMat);
      bigBrake.position.set(0, 0.03, -1.14);
      root.add(bigBrake);

      // Dual-ring Telescopic Scope
      const scopeBody = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.04, 0.36, 16), metalMat);
      scopeBody.rotation.x = Math.PI / 2;
      scopeBody.position.set(0, 0.12, -0.22);
      root.add(scopeBody);

      const lensFront = new THREE.Mesh(new THREE.CircleGeometry(0.038, 16), scopeLensMat);
      lensFront.position.set(0, 0.12, -0.4);
      lensFront.rotation.y = Math.PI;
      root.add(lensFront);

      // Folded Bipod legs
      const bipodL = new THREE.Mesh(new THREE.BoxGeometry(0.015, 0.18, 0.02), metalMat);
      bipodL.position.set(-0.06, -0.05, -0.65);
      bipodL.rotation.z = -0.3;
      root.add(bipodL);

      const bipodR = new THREE.Mesh(new THREE.BoxGeometry(0.015, 0.18, 0.02), metalMat);
      bipodR.position.set(0.06, -0.05, -0.65);
      bipodR.rotation.z = 0.3;
      root.add(bipodR);

      // Cheek rest thumbhole stock
      const stock = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.18, 0.3), camoMat);
      stock.position.set(0, -0.02, 0.18);
      root.add(stock);

      return { root };
    }

    case 'SHOTGUN': {
      // 3. Neon Combat Shotgun
      const darkMat = new THREE.MeshStandardMaterial({ color: 0x181a1f, roughness: 0.3, metalness: 0.85 });
      const pumpMat = new THREE.MeshStandardMaterial({ color: 0x4a4f5a, roughness: 0.7 });
      const neonCyan = new THREE.MeshBasicMaterial({ color: 0x00f0ff });
      const shellRed = new THREE.MeshStandardMaterial({ color: 0xd63031, roughness: 0.4 });

      // Dual barrel layout (top barrel + bottom magazine tube)
      const topBarrel = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.52, 12), darkMat);
      topBarrel.rotation.x = Math.PI / 2;
      topBarrel.position.set(0, 0.03, -0.5);
      root.add(topBarrel);

      const magTube = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.48, 12), darkMat);
      magTube.rotation.x = Math.PI / 2;
      magTube.position.set(0, -0.035, -0.48);
      root.add(magTube);

      // Ribbed sliding pump grip
      const pumpGrip = new THREE.Mesh(new THREE.CylinderGeometry(0.042, 0.042, 0.18, 10), pumpMat);
      pumpGrip.rotation.x = Math.PI / 2;
      pumpGrip.position.set(0, -0.035, -0.42);
      root.add(pumpGrip);

      // Neon heatsink vent lines along the top
      const vent = new THREE.Mesh(new THREE.BoxGeometry(0.015, 0.015, 0.42), neonCyan);
      vent.position.set(0, 0.065, -0.48);
      root.add(vent);

      // Receiver with red shell chamber
      const receiver = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.14, 0.3), darkMat);
      receiver.position.set(0, 0, -0.15);
      root.add(receiver);

      const shellPort = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.04, 0.08), shellRed);
      shellPort.position.set(0.046, 0.02, -0.15);
      root.add(shellPort);

      // Combat stock
      const stock = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.13, 0.22), darkMat);
      stock.position.set(0, -0.04, 0.1);
      root.add(stock);

      return { root };
    }

    case 'MINIGUN': {
      // 4. Rotary Gatling Minigun (6 Barrels)
      const gunMetal = new THREE.MeshStandardMaterial({ color: 0x1f242d, roughness: 0.3, metalness: 0.9 });
      const hazardYellow = new THREE.MeshStandardMaterial({ color: 0xf1c40f, roughness: 0.5 });
      const blackStripe = new THREE.MeshStandardMaterial({ color: 0x111111, roughness: 0.8 });

      // Central shaft
      const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 0.6, 12), gunMetal);
      shaft.rotation.x = Math.PI / 2;
      shaft.position.set(0, 0, -0.5);
      root.add(shaft);

      // 6 Rotating Barrels
      const barrelMeshes: THREE.Mesh[] = [];
      const numBarrels = 6;
      const radius = 0.065;
      for (let i = 0; i < numBarrels; i++) {
        const angle = (i / numBarrels) * Math.PI * 2;
        const bx = Math.cos(angle) * radius;
        const by = Math.sin(angle) * radius;

        const b = new THREE.Mesh(new THREE.CylinderGeometry(0.016, 0.016, 0.65, 8), gunMetal);
        b.rotation.x = Math.PI / 2;
        b.position.set(bx, by, -0.52);
        root.add(b);
        barrelMeshes.push(b);
      }

      // Reinforcing ring plates
      const ring1 = new THREE.Mesh(new THREE.TorusGeometry(radius, 0.015, 8, 20), gunMetal);
      ring1.position.set(0, 0, -0.4);
      root.add(ring1);

      const ring2 = ring1.clone();
      ring2.position.set(0, 0, -0.75);
      root.add(ring2);

      // Massive cylindrical ammo drum underneath
      const drum = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 0.22, 16), hazardYellow);
      drum.position.set(0, -0.16, -0.18);
      root.add(drum);

      const stripe = new THREE.Mesh(new THREE.CylinderGeometry(0.122, 0.122, 0.06, 16), blackStripe);
      stripe.position.set(0, -0.16, -0.18);
      root.add(stripe);

      // Top carry handle
      const handle = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.08, 0.24), gunMetal);
      handle.position.set(0, 0.12, -0.15);
      root.add(handle);

      return { root, barrels: barrelMeshes };
    }

    case 'PISTOL': {
      // 5. Tactical Laser Handgun
      const slideMat = new THREE.MeshStandardMaterial({ color: 0x4b5563, roughness: 0.25, metalness: 0.9 });
      const gripMat = new THREE.MeshStandardMaterial({ color: 0x111827, roughness: 0.8 });
      const laserDotMat = new THREE.MeshBasicMaterial({ color: 0xff0033 });

      // Slide (top)
      const slide = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.06, 0.25), slideMat);
      slide.position.set(0, 0.04, -0.15);
      root.add(slide);

      // Iron sights
      const frontSight = new THREE.Mesh(new THREE.BoxGeometry(0.012, 0.018, 0.015), slideMat);
      frontSight.position.set(0, 0.075, -0.26);
      root.add(frontSight);

      // Ergonomic grip (angled)
      const grip = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.16, 0.08), gripMat);
      grip.position.set(0, -0.06, -0.08);
      grip.rotation.x = -0.25;
      root.add(grip);

      // Under-barrel laser module
      const laserBox = new THREE.Mesh(new THREE.BoxGeometry(0.035, 0.03, 0.1), gripMat);
      laserBox.position.set(0, -0.01, -0.2);
      root.add(laserBox);

      // Visible red laser dot beam
      const laserBeam = new THREE.Mesh(new THREE.CylinderGeometry(0.003, 0.003, 2.5, 6), laserDotMat);
      laserBeam.rotation.x = Math.PI / 2;
      laserBeam.position.set(0, -0.01, -1.45);
      root.add(laserBeam);

      return { root };
    }

    case 'SMG': {
      // 6. Sci-Fi Plasma SMG
      const bodyMat = new THREE.MeshStandardMaterial({ color: 0x1a202c, roughness: 0.4, metalness: 0.8 });
      const plasmaBlue = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });
      const orangeAccent = new THREE.MeshStandardMaterial({ color: 0xf97316 });

      // Compact chassis
      const body = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.11, 0.32), bodyMat);
      body.position.set(0, 0, -0.16);
      root.add(body);

      // Short dual barrel
      const barrel = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.04, 0.16), bodyMat);
      barrel.position.set(0, 0.01, -0.38);
      root.add(barrel);

      // Plasma coils running along the top
      const coil1 = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 0.18, 8), plasmaBlue);
      coil1.rotation.x = Math.PI / 2;
      coil1.position.set(0, 0.07, -0.16);
      root.add(coil1);

      // Extended blue stick mag
      const stickMag = new THREE.Mesh(new THREE.BoxGeometry(0.038, 0.28, 0.06), plasmaBlue);
      stickMag.position.set(0, -0.14, -0.12);
      stickMag.rotation.x = 0.15;
      root.add(stickMag);

      // Front vertical angled grip
      const frontGrip = new THREE.Mesh(new THREE.BoxGeometry(0.035, 0.1, 0.05), orangeAccent);
      frontGrip.position.set(0, -0.08, -0.28);
      frontGrip.rotation.x = -0.2;
      root.add(frontGrip);

      return { root };
    }

    case 'KATANA': {
      // 7. Cyberpunk Energy Katana
      const bladeMat = new THREE.MeshStandardMaterial({
        color: 0x00f0ff,
        emissive: 0x00a8ff,
        emissiveIntensity: 0.7,
        metalness: 0.95,
        roughness: 0.1
      });
      const goldTsuba = new THREE.MeshStandardMaterial({ color: 0xd4af37, metalness: 0.9, roughness: 0.2 });
      const hiltWrap = new THREE.MeshStandardMaterial({ color: 0x8b0000, roughness: 0.8 });

      // Curved long high-frequency blade
      const blade = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.06, 0.95), bladeMat);
      blade.position.set(0, 0, -0.5);
      root.add(blade);

      // Glowing cutting edge
      const edgeGlow = new THREE.Mesh(new THREE.BoxGeometry(0.005, 0.02, 0.96), new THREE.MeshBasicMaterial({ color: 0xffffff }));
      edgeGlow.position.set(0, 0.03, -0.5);
      root.add(edgeGlow);

      // Tsuba guard
      const tsuba = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, 0.02, 12), goldTsuba);
      tsuba.rotation.x = Math.PI / 2;
      tsuba.position.set(0, 0, -0.02);
      root.add(tsuba);

      // Wrapped tsuka hilt
      const hilt = new THREE.Mesh(new THREE.CylinderGeometry(0.024, 0.024, 0.26, 8), hiltWrap);
      hilt.rotation.x = Math.PI / 2;
      hilt.position.set(0, 0, 0.12);
      root.add(hilt);

      // Default hold angle
      root.rotation.y = Math.PI / 5;
      root.position.set(0.12, -0.22, -0.35);

      return { root };
    }

    case 'GRENADE': {
      // 8. Tactical Pineapple Hand Grenade
      const bodyOlive = new THREE.MeshStandardMaterial({ color: 0x3d4f27, roughness: 0.6, metalness: 0.3 });
      const metalFuse = new THREE.MeshStandardMaterial({ color: 0x6b7280, roughness: 0.4, metalness: 0.9 });
      const pinGold = new THREE.MeshStandardMaterial({ color: 0xf59e0b, metalness: 0.9 });

      // Textured oval body
      const grenadeBody = new THREE.Mesh(new THREE.SphereGeometry(0.08, 12, 12), bodyOlive);
      grenadeBody.scale.set(1, 1.3, 1);
      grenadeBody.position.set(0, -0.05, -0.25);
      root.add(grenadeBody);

      // Top fuse cap
      const fuse = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.06, 10), metalFuse);
      fuse.position.set(0, 0.08, -0.25);
      root.add(fuse);

      // Safety lever (spoon)
      const lever = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.1, 0.015), metalFuse);
      lever.position.set(0.035, 0.04, -0.25);
      lever.rotation.z = -0.15;
      root.add(lever);

      // Pull ring
      const ring = new THREE.Mesh(new THREE.TorusGeometry(0.025, 0.005, 8, 16), pinGold);
      ring.position.set(-0.04, 0.08, -0.25);
      ring.rotation.y = Math.PI / 2;
      root.add(ring);

      root.position.set(0.14, -0.18, -0.3);
      return { root };
    }

    case 'COMMANDO_VULCAN': {
      // 9. Commando Tactical Vulcan (돌격대장 전용 발칸포)
      // High-grade military titanium with triple fluted barrels and ammo link feed
      const darkTitanium = new THREE.MeshStandardMaterial({ color: 0x1a2130, roughness: 0.3, metalness: 0.95 });
      const desertTan = new THREE.MeshStandardMaterial({ color: 0x8a724d, roughness: 0.6 });
      const heatOrange = new THREE.MeshBasicMaterial({ color: 0xff4500 });

      // Receiver body
      const body = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.14, 0.42), darkTitanium);
      body.position.set(0, 0, -0.15);
      root.add(body);

      // Desert armor plates
      const plate = new THREE.Mesh(new THREE.BoxGeometry(0.126, 0.09, 0.28), desertTan);
      plate.position.set(0, 0.03, -0.12);
      root.add(plate);

      // Triple triangular barrel cluster
      const barrelRadius = 0.035;
      for (let i = 0; i < 3; i++) {
        const angle = (i / 3) * Math.PI * 2;
        const bx = Math.cos(angle) * barrelRadius;
        const by = Math.sin(angle) * barrelRadius;
        const b = new THREE.Mesh(new THREE.CylinderGeometry(0.016, 0.016, 0.58, 10), darkTitanium);
        b.rotation.x = Math.PI / 2;
        b.position.set(bx, by + 0.02, -0.55);
        root.add(b);

        // Glowing heat vents near muzzle
        const vent = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 0.08, 8), heatOrange);
        vent.rotation.x = Math.PI / 2;
        vent.position.set(bx, by + 0.02, -0.78);
        root.add(vent);
      }

      // Reinforced muzzle clamp ring
      const clamp = new THREE.Mesh(new THREE.TorusGeometry(0.05, 0.012, 8, 16), darkTitanium);
      clamp.position.set(0, 0.02, -0.74);
      root.add(clamp);

      // Side belt ammo feed box
      const ammoBox = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.14, 0.18), desertTan);
      ammoBox.position.set(0.1, -0.06, -0.12);
      ammoBox.rotation.z = -0.2;
      root.add(ammoBox);

      // Heavy tactical stock
      const stock = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.16, 0.22), darkTitanium);
      stock.position.set(0, -0.02, 0.14);
      root.add(stock);

      return { root };
    }

    case 'RAILGUN': {
      // 10. Electromagnetic Railgun (스나이퍼 전용 레일건 캐논)
      // Long sleek particle accelerator with glowing blue superconducting coil rings
      const railChassis = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.15, metalness: 0.95 });
      const coilGlow = new THREE.MeshBasicMaterial({ color: 0x00f0ff });
      const whiteHot = new THREE.MeshBasicMaterial({ color: 0xffffff });
      const carbonFiber = new THREE.MeshStandardMaterial({ color: 0x222222, roughness: 0.7 });

      // Main upper & lower rail guide beams
      const topRail = new THREE.Mesh(new THREE.BoxGeometry(0.035, 0.025, 0.95), railChassis);
      topRail.position.set(0, 0.045, -0.7);
      root.add(topRail);

      const bottomRail = new THREE.Mesh(new THREE.BoxGeometry(0.035, 0.025, 0.95), railChassis);
      bottomRail.position.set(0, -0.015, -0.7);
      root.add(bottomRail);

      // Glowing central plasma bore core
      const coreBeam = new THREE.Mesh(new THREE.BoxGeometry(0.012, 0.012, 0.92), whiteHot);
      coreBeam.position.set(0, 0.015, -0.68);
      root.add(coreBeam);

      // 5 Superconducting magnetic accelerator rings
      for (let i = 0; i < 5; i++) {
        const ringZ = -0.35 - i * 0.17;
        const ring = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.11, 0.035), coilGlow);
        ring.position.set(0, 0.015, ringZ);
        root.add(ring);
      }

      // Compact high-voltage capacitor housing
      const capacitor = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.16, 0.35), railChassis);
      capacitor.position.set(0, 0.02, -0.12);
      root.add(capacitor);

      // Cybernetic high-magnification targeting sensor
      const sensor = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.06, 0.22), carbonFiber);
      sensor.position.set(0, 0.13, -0.16);
      root.add(sensor);

      const sensorLens = new THREE.Mesh(new THREE.CircleGeometry(0.022, 12), coilGlow);
      sensorLens.position.set(0, 0.13, -0.275);
      sensorLens.rotation.y = Math.PI;
      root.add(sensorLens);

      // Ergonomic skeleton stock
      const stock = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.15, 0.26), railChassis);
      stock.position.set(0, -0.04, 0.16);
      root.add(stock);

      return { root };
    }

    case 'BIO_LAUNCHER': {
      // 11. Nano Bio-Acid Launcher (메디크 전용 나노 바이오 런처)
      // Medical white casing with glowing toxic green fluid chamber and pressurized nozzle
      const medWhite = new THREE.MeshStandardMaterial({ color: 0xecfdf5, roughness: 0.2, metalness: 0.2 });
      const bioGreen = new THREE.MeshStandardMaterial({
        color: 0x10b981,
        emissive: 0x34d399,
        emissiveIntensity: 0.8,
        transparent: true,
        opacity: 0.85
      });
      const darkSteel = new THREE.MeshStandardMaterial({ color: 0x27272a, roughness: 0.4, metalness: 0.8 });
      const redCrossMat = new THREE.MeshBasicMaterial({ color: 0xef4444 });

      // Medical main body
      const body = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.15, 0.42), medWhite);
      body.position.set(0, 0, -0.16);
      root.add(body);

      // Red Cross medical emblem
      const crossV = new THREE.Mesh(new THREE.BoxGeometry(0.102, 0.06, 0.015), redCrossMat);
      crossV.position.set(0, 0.02, -0.16);
      root.add(crossV);
      const crossH = new THREE.Mesh(new THREE.BoxGeometry(0.102, 0.015, 0.06), redCrossMat);
      crossH.position.set(0, 0.02, -0.16);
      root.add(crossH);

      // Transparent cylindrical chemical incubation flask on top
      const bioVial = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.045, 0.28, 16), bioGreen);
      bioVial.rotation.x = Math.PI / 2;
      bioVial.position.set(0, 0.12, -0.18);
      root.add(bioVial);

      // Wide funnel pressure nozzle
      const nozzle = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.035, 0.22, 16), darkSteel);
      nozzle.rotation.x = Math.PI / 2;
      nozzle.position.set(0, 0, -0.44);
      root.add(nozzle);

      // Chemical pressure tubes
      const tubeL = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 0.35, 8), bioGreen);
      tubeL.rotation.x = Math.PI / 2;
      tubeL.position.set(-0.06, -0.04, -0.22);
      root.add(tubeL);

      const tubeR = tubeL.clone();
      tubeR.position.x = 0.06;
      root.add(tubeR);

      return { root };
    }

    case 'BLOOD_SCYTHE': {
      // 12. Berserker Blood Scythe (버서커 전용 블러드 서클 대낫)
      // Massive crimson curved curved blade with bone handle and glowing demonic aura
      const darkSteel = new THREE.MeshStandardMaterial({ color: 0x1c1917, roughness: 0.5, metalness: 0.8 });
      const bloodCrimson = new THREE.MeshStandardMaterial({
        color: 0x990000,
        emissive: 0xef4444,
        emissiveIntensity: 0.9,
        roughness: 0.1,
        metalness: 0.9
      });
      const boneMat = new THREE.MeshStandardMaterial({ color: 0xd6d3d1, roughness: 0.7 });

      // Long heavy two-handed shaft
      const staff = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.022, 1.25, 12), darkSteel);
      staff.rotation.x = Math.PI / 2;
      staff.position.set(0, 0, -0.35);
      root.add(staff);

      // Grip wraps
      const wrap1 = new THREE.Mesh(new THREE.CylinderGeometry(0.028, 0.028, 0.24, 8), boneMat);
      wrap1.rotation.x = Math.PI / 2;
      wrap1.position.set(0, 0, 0.05);
      root.add(wrap1);

      // Huge curved scythe blade cutting head
      const bladeCurve = new THREE.Mesh(new THREE.BoxGeometry(0.025, 0.38, 0.45), bloodCrimson);
      bladeCurve.position.set(0.12, 0.16, -0.92);
      bladeCurve.rotation.z = -Math.PI / 4.5;
      root.add(bladeCurve);

      // Razor razor tip
      const tip = new THREE.Mesh(new THREE.ConeGeometry(0.06, 0.32, 4), bloodCrimson);
      tip.rotation.z = Math.PI / 3;
      tip.position.set(0.28, 0.24, -1.05);
      root.add(tip);

      // Demonic skull socket
      const skull = new THREE.Mesh(new THREE.SphereGeometry(0.055, 8, 8), boneMat);
      skull.position.set(0, 0.02, -0.95);
      root.add(skull);

      // Dynamic holding pose
      root.rotation.set(-0.2, 0.35, -0.15);
      root.position.set(0.12, -0.22, -0.28);
      return { root };
    }

    case 'TITAN_HAMMER': {
      // 13. Juggernaut Seismic Hammer (중장갑 든든이 전용 타이탄 지진분쇄 해머)
      // Massive industrial steel sledgehammer with hazard yellow stripes and exhaust thrusters
      const heavyIron = new THREE.MeshStandardMaterial({ color: 0x27272a, roughness: 0.3, metalness: 0.95 });
      const hazardYellow = new THREE.MeshStandardMaterial({ color: 0xeab308, roughness: 0.5 });
      const thrusterGlow = new THREE.MeshBasicMaterial({ color: 0xf97316 });

      // Thick reinforced hexagonal handle
      const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.032, 0.032, 1.1, 8), heavyIron);
      shaft.rotation.x = Math.PI / 2;
      shaft.position.set(0, 0, -0.32);
      root.add(shaft);

      // Giant crushing hammer head block
      const hammerHead = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.24, 0.36), heavyIron);
      hammerHead.position.set(0, 0.05, -0.85);
      root.add(hammerHead);

      // Hazard yellow reinforced impact plates (front and back)
      const frontPlate = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.22, 0.04), hazardYellow);
      frontPlate.position.set(0, 0.05, -1.04);
      root.add(frontPlate);

      // Rear rocket boosters for kinetic smash acceleration
      const thrusterL = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.05, 0.12, 10), heavyIron);
      thrusterL.rotation.x = Math.PI / 2;
      thrusterL.position.set(-0.07, 0.05, -0.65);
      root.add(thrusterL);

      const glowL = new THREE.Mesh(new THREE.CircleGeometry(0.042, 10), thrusterGlow);
      glowL.position.set(-0.07, 0.05, -0.59);
      root.add(glowL);

      const thrusterR = thrusterL.clone();
      thrusterR.position.x = 0.07;
      root.add(thrusterR);
      const glowR = glowL.clone();
      glowR.position.x = 0.07;
      root.add(glowR);

      // Holding angle
      root.rotation.set(-0.15, 0.28, -0.2);
      root.position.set(0.14, -0.24, -0.28);
      return { root };
    }

    case 'THROWING_AXE': {
      // 14. Tactical Plasma Throwing Tomahawk (플라즈마 투척 토마호크)
      const carbonHandle = new THREE.MeshStandardMaterial({ color: 0x1f2937, roughness: 0.6 });
      const axeBladeMat = new THREE.MeshStandardMaterial({
        color: 0x0284c7,
        emissive: 0x38bdf8,
        emissiveIntensity: 0.8,
        metalness: 0.9,
        roughness: 0.2
      });
      const neonOrange = new THREE.MeshBasicMaterial({ color: 0xf97316 });

      // Handle shaft
      const handle = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.55, 8), carbonHandle);
      handle.position.set(0, -0.05, -0.32);
      handle.rotation.x = Math.PI / 2.2;
      root.add(handle);

      // Curved axe head
      const axeHead = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.22, 0.16), axeBladeMat);
      axeHead.position.set(0, 0.16, -0.52);
      root.add(axeHead);

      // Curved cutting edge
      const edge = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.24, 4), axeBladeMat);
      edge.rotation.z = Math.PI / 2;
      edge.position.set(0.08, 0.16, -0.52);
      root.add(edge);

      // Plasma power capacitor core
      const core = new THREE.Mesh(new THREE.SphereGeometry(0.03, 8, 8), neonOrange);
      core.position.set(0, 0.16, -0.48);
      root.add(core);

      root.rotation.set(-0.1, 0.2, -0.1);
      root.position.set(0.16, -0.18, -0.28);
      return { root };
    }

    case 'EXPLOSIVE_SPEAR': {
      // 15. Cypher Bomb Throwing Spear (사이퍼 폭탄 투척창)
      const shaftMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.3, metalness: 0.8 });
      const warheadMat = new THREE.MeshStandardMaterial({
        color: 0xd97706,
        emissive: 0xf59e0b,
        emissiveIntensity: 0.7,
        metalness: 0.9
      });
      const yellowFin = new THREE.MeshBasicMaterial({ color: 0xfacc15 });

      // Long sleek aerodynamic spear shaft
      const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 1.2, 8), shaftMat);
      shaft.rotation.x = Math.PI / 2;
      shaft.position.set(0, 0, -0.4);
      root.add(shaft);

      // Diamond-pointed explosive tip
      const spearTip = new THREE.Mesh(new THREE.ConeGeometry(0.045, 0.28, 4), warheadMat);
      spearTip.rotation.x = -Math.PI / 2;
      spearTip.position.set(0, 0, -1.05);
      root.add(spearTip);

      // Aerodynamic stabilizer fins at tail
      for (let i = 0; i < 3; i++) {
        const angle = (i / 3) * Math.PI * 2;
        const fin = new THREE.Mesh(new THREE.BoxGeometry(0.008, 0.08, 0.14), yellowFin);
        fin.position.set(Math.cos(angle) * 0.03, Math.sin(angle) * 0.03, 0.12);
        fin.rotation.z = angle;
        root.add(fin);
      }

      root.rotation.set(-0.12, 0.18, -0.05);
      root.position.set(0.14, -0.2, -0.32);
      return { root };
    }
  }
}
