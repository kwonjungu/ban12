import zombieBannerImg from '../assets/images/zombie_hunter_banner_1789886025597.jpg';
import safeHavenHubImg from '../assets/images/safe_haven_hub_1789886042109.jpg';
import mutantBossCardImg from '../assets/images/mutant_boss_card_1789886056786.jpg';

export const GAME_ASSETS = {
  banner: zombieBannerImg,
  hub: safeHavenHubImg,
  bossCard: mutantBossCardImg,
};
