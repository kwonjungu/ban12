import React from 'react';
import {
  Heart,
  Shield,
  Coins,
  Crosshair,
  Target,
  Zap,
  Layers,
  Radio,
  Sword,
  Bomb,
  FlaskConical,
  Home,
  MousePointer,
  RotateCcw,
  Cpu,
  Flame,
  Wrench,
  Axe,
  Gauge,
  Sparkles
} from 'lucide-react';
import { WeaponData, WeaponSlot, WeaponId, JobClassData } from '../types';
import { GAME_ASSETS } from '../game/assets';

interface HUDProps {
  hp: number;
  maxHp: number;
  shield: number;
  maxShield: number;
  stage: number;
  zombiesLeft: number;
  zombiesTotal: number;
  bossHp: number | null;
  maxBossHp: number | null;
  gold: number;
  job: JobClassData;
  activeSlot: WeaponSlot;
  equippedSlots: Record<WeaponSlot, WeaponId>;
  weapons: Record<WeaponId, WeaponData>;
  currentAmmo: number;
  reserveAmmo: number;
  isReloading: boolean;
  hpPotions: number;
  shieldPotions: number;
  speedPotions: number;
  berserkPotions: number;
  fullRestorePotions: number;
  speedBuffTimer: number;
  berserkBuffTimer: number;
  isZoomed?: boolean;
  onSelectSlot: (slot: WeaponSlot) => void;
  onUseHpPotion: () => void;
  onUseShieldPotion: () => void;
  onUseSpeedPotion: () => void;
  onUseBerserkPotion: () => void;
  onUseFullRestorePotion: () => void;
  onGiveUp: () => void;
}

export const HUD: React.FC<HUDProps> = ({
  hp,
  maxHp,
  shield,
  maxShield,
  stage,
  zombiesLeft,
  zombiesTotal,
  bossHp,
  maxBossHp,
  gold,
  job,
  activeSlot,
  equippedSlots,
  weapons,
  currentAmmo,
  reserveAmmo,
  isReloading,
  hpPotions,
  shieldPotions,
  speedPotions,
  berserkPotions,
  fullRestorePotions,
  speedBuffTimer,
  berserkBuffTimer,
  isZoomed = false,
  onSelectSlot,
  onUseHpPotion,
  onUseShieldPotion,
  onUseSpeedPotion,
  onUseBerserkPotion,
  onUseFullRestorePotion,
  onGiveUp
}) => {
  const activeWeapon = weapons[equippedSlots[activeSlot]];

  const getSlotIcon = (id: WeaponId) => {
    switch (id) {
      case 'RIFLE': return <Crosshair className="w-4 h-4 text-cyan-400" />;
      case 'SNIPER': return <Target className="w-4 h-4 text-emerald-400" />;
      case 'SHOTGUN': return <Zap className="w-4 h-4 text-orange-400" />;
      case 'MINIGUN': return <Layers className="w-4 h-4 text-yellow-400" />;
      case 'PISTOL': return <Crosshair className="w-4 h-4 text-blue-400" />;
      case 'SMG': return <Radio className="w-4 h-4 text-purple-400" />;
      case 'KATANA': return <Sword className="w-4 h-4 text-cyan-300" />;
      case 'GRENADE': return <Bomb className="w-4 h-4 text-red-400" />;
      case 'COMMANDO_VULCAN': return <Shield className="w-4 h-4 text-amber-400" />;
      case 'RAILGUN': return <Cpu className="w-4 h-4 text-cyan-400" />;
      case 'BIO_LAUNCHER': return <FlaskConical className="w-4 h-4 text-emerald-400" />;
      case 'BLOOD_SCYTHE': return <Flame className="w-4 h-4 text-red-500" />;
      case 'TITAN_HAMMER': return <Wrench className="w-4 h-4 text-yellow-400" />;
      case 'THROWING_AXE': return <Axe className="w-4 h-4 text-sky-400" />;
      case 'EXPLOSIVE_SPEAR': return <Zap className="w-4 h-4 text-amber-400" />;
    }
  };

  const hpPct = Math.max(0, Math.min(100, (hp / maxHp) * 100));
  const shieldPct = Math.max(0, Math.min(100, (shield / maxShield) * 100));
  const bossPct = bossHp !== null && maxBossHp ? Math.max(0, Math.min(100, (bossHp / maxBossHp) * 100)) : 0;

  return (
    <div className="absolute inset-0 pointer-events-none z-20 flex flex-col justify-between p-3 md:p-6 select-none">
      
      {/* Top Header */}
      <div className="flex justify-between items-start w-full">
        
        {/* Left: HP & Shield & Active Buffs */}
        <div className="flex flex-col gap-1.5 w-52 md:w-80">
          <div className="flex items-center gap-2">
            <Heart className="w-4 h-4 text-red-500 shrink-0" />
            <div className="w-full bg-gray-950/80 border border-red-500/50 rounded-full h-3.5 p-0.5 overflow-hidden shadow-inner">
              <div
                className="bg-gradient-to-r from-red-600 to-pink-500 h-full rounded-full transition-all duration-150"
                style={{ width: `${hpPct}%` }}
              />
            </div>
            <span className="text-xs font-orbitron font-bold text-red-400 min-w-[70px] text-right">
              {Math.ceil(hp)}/{maxHp}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-cyan-400 shrink-0" />
            <div className="w-full bg-gray-950/80 border border-cyan-500/50 rounded-full h-3 p-0.5 overflow-hidden shadow-inner">
              <div
                className="bg-gradient-to-r from-cyan-600 to-blue-400 h-full rounded-full transition-all duration-150"
                style={{ width: `${shieldPct}%` }}
              />
            </div>
            <span className="text-xs font-orbitron font-bold text-cyan-300 min-w-[70px] text-right">
              {Math.ceil(shield)}/{maxShield}
            </span>
          </div>

          {/* Active Buff Badges */}
          {(speedBuffTimer > 0 || berserkBuffTimer > 0) && (
            <div className="flex items-center gap-2 mt-1">
              {speedBuffTimer > 0 && (
                <div className="flex items-center gap-1.5 bg-emerald-950/90 border border-emerald-400/80 text-emerald-300 px-2.5 py-0.5 rounded-full text-[10px] font-orbitron font-bold shadow-[0_0_12px_rgba(16,185,129,0.3)] animate-pulse">
                  <Gauge className="w-3.5 h-3.5 text-emerald-400" />
                  <span>스피드 가속 {Math.ceil(speedBuffTimer)}s</span>
                </div>
              )}
              {berserkBuffTimer > 0 && (
                <div className="flex items-center gap-1.5 bg-amber-950/90 border border-amber-400/80 text-amber-300 px-2.5 py-0.5 rounded-full text-[10px] font-orbitron font-bold shadow-[0_0_12px_rgba(245,158,11,0.3)] animate-pulse">
                  <Zap className="w-3.5 h-3.5 text-amber-400" />
                  <span>버서커 화력 2x {Math.ceil(berserkBuffTimer)}s</span>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Center: Stage & Zombie Counter & Boss Health Bar */}
        <div className="flex flex-col items-center">
          <div className="bg-red-950/85 border border-red-500/80 px-4 py-1 rounded-2xl flex items-center gap-2 shadow-lg">
            <span className="text-[10px] font-orbitron text-red-400 tracking-wider">SECTOR</span>
            <span className="text-xl font-black font-orbitron text-yellow-400 neon-glow-gold">
              STAGE {stage}
            </span>
          </div>

          <div className="mt-1 text-xs font-orbitron font-bold text-gray-300 bg-gray-900/90 px-3 py-0.5 rounded-full border border-gray-700 shadow-md">
            남은 좀비: <span className="text-red-400 font-black">{zombiesLeft}</span> / <span>{zombiesTotal}</span>
          </div>

          {/* Boss HP Bar with Boss Avatar */}
          {bossHp !== null && (
            <div className="w-64 md:w-96 mt-2 flex flex-col items-center animate-pulse">
              <div className="flex justify-between items-center w-full text-xs font-orbitron text-red-500 mb-1 font-bold">
                <div className="flex items-center gap-1.5">
                  <img
                    src={GAME_ASSETS.bossCard}
                    alt="보스"
                    referrerPolicy="no-referrer"
                    className="w-5 h-5 rounded-full object-cover border border-red-500"
                  />
                  <span>STAGE {stage} 오메가 변종 보스</span>
                </div>
                <span>{Math.ceil(bossPct)}%</span>
              </div>
              <div className="w-full bg-black/90 border-2 border-red-600 rounded-full h-3.5 p-0.5 overflow-hidden shadow-[0_0_15px_rgba(255,0,85,0.6)]">
                <div
                  className="bg-gradient-to-r from-red-600 via-pink-600 to-yellow-500 h-full rounded-full transition-all duration-100"
                  style={{ width: `${bossPct}%` }}
                />
              </div>
            </div>
          )}
        </div>

        {/* Right: Gold, Class & Exit */}
        <div className="flex flex-col items-end gap-1.5">
          <div className="flex items-center gap-1.5 bg-gray-900/90 border border-yellow-500/50 rounded-xl px-3 py-1 shadow-md">
            <Coins className="w-4 h-4 text-yellow-400" />
            <span className="font-orbitron font-bold text-yellow-400 text-sm md:text-base">
              {gold.toLocaleString()} G
            </span>
          </div>
          <div className="text-[11px] font-orbitron font-bold text-cyan-300 bg-cyan-950/80 px-2.5 py-0.5 rounded-lg border border-cyan-500/40">
            직업: <span>{job.name}</span>
          </div>
          <button
            onClick={onGiveUp}
            className="pointer-events-auto text-xs bg-red-950/80 hover:bg-red-800 text-red-200 border border-red-500/50 px-2.5 py-1 rounded-lg transition flex items-center gap-1 shadow-md active:scale-95"
          >
            <Home className="w-3.5 h-3.5" /> 기지 후퇴
          </button>
        </div>
      </div>

      {/* Sniper Scope Overlay when Zoomed */}
      {isZoomed && (
        <div className="absolute inset-0 pointer-events-none z-10 flex items-center justify-center overflow-hidden">
          {/* Black vignette mask around round scope lens */}
          <div className="absolute inset-0 bg-black/60 shadow-[inset_0_0_120px_rgba(0,0,0,0.95)]" />
          
          {/* Circular Scope Border */}
          <div className="relative w-[340px] h-[340px] md:w-[500px] md:h-[500px] rounded-full border-4 border-emerald-500/80 shadow-[0_0_50px_rgba(16,185,129,0.35),inset_0_0_40px_rgba(16,185,129,0.2)] flex items-center justify-center">
            {/* Scope crosshair reticle lines */}
            <div className="absolute w-full h-[1px] bg-emerald-400/90" />
            <div className="absolute h-full w-[1px] bg-emerald-400/90" />
            
            {/* Rangefinder ticks */}
            <div className="absolute w-12 h-[1px] bg-emerald-400/80 top-[35%]" />
            <div className="absolute w-12 h-[1px] bg-emerald-400/80 bottom-[35%]" />
            <div className="absolute w-20 h-[1px] bg-emerald-400/80 bottom-[25%]" />
            <div className="absolute w-12 h-[1px] bg-emerald-400/80 bottom-[15%]" />
            
            {/* Center target circle */}
            <div className="w-10 h-10 rounded-full border border-emerald-400/70 flex items-center justify-center">
              <div className="w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_10px_#10b981]" />
            </div>

            {/* Scope HUD Text */}
            <div className="absolute top-6 font-orbitron text-[10px] text-emerald-400 font-bold tracking-widest bg-black/60 px-2 py-0.5 rounded">
              SNIPER SCOPE 4.0X
            </div>
            <div className="absolute bottom-6 font-orbitron text-[10px] text-emerald-300 font-bold bg-black/60 px-2 py-0.5 rounded flex items-center gap-1.5">
              <span>ELEVATION: AUTO</span>
              <span className="text-red-400 font-black animate-pulse">● LOCKED</span>
            </div>
          </div>
        </div>
      )}

      {/* Crosshair in the Center of Screen (Hidden when zoomed) */}
      {!isZoomed && (
        <div id="crosshair" className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none flex items-center justify-center">
          <div className="w-1.5 h-1.5 bg-red-500 rounded-full shadow-[0_0_8px_#ff0033]" />
          <div className="absolute w-5 h-0.5 bg-cyan-400/80 -left-3.5" />
          <div className="absolute w-5 h-0.5 bg-cyan-400/80 -right-3.5" />
          <div className="absolute h-5 w-0.5 bg-cyan-400/80 -top-3.5" />
          <div className="absolute h-5 w-0.5 bg-cyan-400/80 -bottom-3.5" />
        </div>
      )}

      {/* Bottom Controls Info & Active 4-Slot Hotbar */}
      <div className="flex flex-col md:flex-row justify-between items-end w-full gap-3">
        
        {/* Potions quick access (5 Tactical Potions) */}
        <div className="flex flex-col gap-1.5">
          <div className="text-[10px] font-orbitron text-gray-400 font-bold flex items-center gap-1">
            <FlaskConical className="w-3.5 h-3.5 text-purple-400" />
            <span>전술 포션 [단축키 사용 가능]</span>
          </div>
          <div className="flex flex-wrap items-center gap-1.5 max-w-[420px]">
            {/* 1. HP Potion */}
            <button
              onClick={onUseHpPotion}
              className={`pointer-events-auto px-2.5 py-1 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-md active:scale-95 ${
                hpPotions > 0
                  ? 'bg-red-950/90 border border-red-500/80 text-red-300 hover:bg-red-900'
                  : 'bg-gray-900/60 border border-gray-800 text-gray-500 opacity-60'
              }`}
            >
              <Heart className="w-3.5 h-3.5 text-red-400" /> [Q] HP ({hpPotions})
            </button>

            {/* 2. Shield Potion */}
            <button
              onClick={onUseShieldPotion}
              className={`pointer-events-auto px-2.5 py-1 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-md active:scale-95 ${
                shieldPotions > 0
                  ? 'bg-cyan-950/90 border border-cyan-500/80 text-cyan-300 hover:bg-cyan-900'
                  : 'bg-gray-900/60 border border-gray-800 text-gray-500 opacity-60'
              }`}
            >
              <Shield className="w-3.5 h-3.5 text-cyan-400" /> [E] 실드 ({shieldPotions})
            </button>

            {/* 3. Speed Potion */}
            <button
              onClick={onUseSpeedPotion}
              className={`pointer-events-auto px-2.5 py-1 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-md active:scale-95 ${
                speedPotions > 0
                  ? 'bg-emerald-950/90 border border-emerald-500/80 text-emerald-300 hover:bg-emerald-900'
                  : 'bg-gray-900/60 border border-gray-800 text-gray-500 opacity-60'
              }`}
            >
              <Gauge className="w-3.5 h-3.5 text-emerald-400" /> [Z] 스피드 ({speedPotions})
            </button>

            {/* 4. Berserk Potion */}
            <button
              onClick={onUseBerserkPotion}
              className={`pointer-events-auto px-2.5 py-1 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-md active:scale-95 ${
                berserkPotions > 0
                  ? 'bg-amber-950/90 border border-amber-500/80 text-amber-300 hover:bg-amber-900'
                  : 'bg-gray-900/60 border border-gray-800 text-gray-500 opacity-60'
              }`}
            >
              <Zap className="w-3.5 h-3.5 text-amber-400" /> [X] 버서커 ({berserkPotions})
            </button>

            {/* 5. Full Restore Potion */}
            <button
              onClick={onUseFullRestorePotion}
              className={`pointer-events-auto px-2.5 py-1 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-md active:scale-95 ${
                fullRestorePotions > 0
                  ? 'bg-purple-950/90 border border-purple-500/80 text-purple-300 hover:bg-purple-900'
                  : 'bg-gray-900/60 border border-gray-800 text-gray-500 opacity-60'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-purple-400" /> [C] 풀회복 ({fullRestorePotions})
            </button>
          </div>
        </div>

        {/* 4 Weapon Hotbar Inventory Display with Mouse Wheel Indicator */}
        <div className="flex flex-col items-center gap-1">
          {/* Mouse Wheel Switching Tip */}
          <div className="flex items-center gap-1.5 bg-black/75 border border-cyan-500/40 text-cyan-300 px-3 py-0.5 rounded-full text-[10px] font-orbitron shadow-md">
            <MousePointer className="w-3 h-3 text-cyan-400 animate-pulse" />
            <span>마우스 휠(Scroll)로 무기 전환 가능</span>
          </div>

          <div className="pointer-events-auto flex items-center gap-1.5 md:gap-2 bg-gray-950/85 p-2 rounded-2xl border border-gray-800 shadow-2xl">
            {([1, 2, 3, 4] as WeaponSlot[]).map((slotNum) => {
              const wepId = equippedSlots[slotNum];
              const wep = weapons[wepId];
              const isActive = activeSlot === slotNum;
              const slotLabel = slotNum === 1 ? '1:주무기' : slotNum === 2 ? '2:보조' : slotNum === 3 ? '3:근접' : '4:투척';

              return (
                <div
                  key={slotNum}
                  onClick={() => onSelectSlot(slotNum)}
                  className={`hotbar-slot p-2 rounded-xl flex flex-col items-center justify-center cursor-pointer min-w-[65px] md:min-w-[80px] ${
                    isActive ? 'active' : ''
                  }`}
                >
                  <span className="text-[10px] text-cyan-400 font-orbitron font-bold">
                    {slotLabel}
                  </span>
                  <div className="my-1 text-sm text-yellow-400">
                    {getSlotIcon(wepId)}
                  </div>
                  <span className="text-[10px] text-gray-300 truncate max-w-[70px]">
                    {wep ? wep.name : '미장착'}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Ammo & Active Weapon Status */}
        <div className="bg-gray-950/90 border border-red-500/60 rounded-2xl px-4 py-2 flex items-center gap-3 shadow-xl">
          <div className="text-2xl text-cyan-400">
            {getSlotIcon(activeWeapon.id)}
          </div>
          <div className="flex flex-col">
            <span className="text-xs font-orbitron text-gray-300 font-bold truncate max-w-[130px]">
              {activeWeapon.name}
            </span>
            <div className="flex items-baseline gap-1.5 font-orbitron font-extrabold text-lg text-yellow-400">
              {activeWeapon.isMelee ? (
                <span className="text-cyan-300 text-sm">무제한 근접</span>
              ) : activeWeapon.isThrowable ? (
                <>
                  <span>{reserveAmmo}</span>
                  <span className="text-xs text-gray-400">개 보유</span>
                </>
              ) : (
                <>
                  <span>{currentAmmo}</span>
                  <span className="text-xs text-gray-400">/</span>
                  <span className="text-xs text-cyan-300">{reserveAmmo}</span>
                </>
              )}
              {isReloading && (
                <span className="text-xs text-red-400 animate-pulse ml-1 flex items-center gap-1">
                  <RotateCcw className="w-3 h-3 animate-spin" /> 재장전 중...
                </span>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
