import React from 'react';
import { Skull, ShieldAlert, Crosshair, MousePointer, BookOpen } from 'lucide-react';
import { GAME_ASSETS } from '../game/assets';

interface IntroModalProps {
  onStart: () => void;
}

export const IntroModal: React.FC<IntroModalProps> = ({ onStart }) => {
  return (
    <div className="absolute inset-0 z-40 flex flex-col items-center justify-center bg-black/95 p-4 md:p-6 text-center overflow-y-auto">
      <div className="max-w-2xl w-full flex flex-col items-center my-auto">
        {/* Banner Image Asset */}
        <div className="w-full relative rounded-2xl overflow-hidden border-2 border-red-500/50 shadow-2xl mb-4 max-h-56">
          <img
            src={GAME_ASSETS.banner}
            alt="바이오 해저드 3D 좀비 사냥꾼"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent flex flex-col justify-end p-4 text-left">
            <div className="text-red-500 font-orbitron font-bold text-xs tracking-widest uppercase flex items-center gap-1.5">
              <ShieldAlert className="w-4 h-4 text-red-500" /> BIOHAZARD 3D ZOMBIE HUNTER
            </div>
            <h1 className="text-2xl md:text-4xl font-black font-orbitron text-transparent bg-clip-text bg-gradient-to-r from-red-500 via-pink-400 to-yellow-300 neon-glow-red">
              바이오 해저드: 3D 좀비 헌터
            </h1>
          </div>
        </div>

        <p className="text-sm md:text-base font-bold text-cyan-300 mb-4">
          20개 스테이지 변종 좀비 소탕 작전 • 4슬롯 로드아웃 • 직업 길드 시스템
        </p>

        {/* Operation Guide */}
        <div className="bg-gray-950/85 border border-red-500/40 rounded-2xl p-4 mb-5 text-left text-xs text-gray-300 space-y-2.5 w-full shadow-lg">
          <div className="font-bold text-yellow-400 border-b border-red-500/30 pb-1.5 flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-yellow-400" /> 작전 핵심 브리핑 & 조작법
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
            <div className="flex items-start gap-2 bg-gray-900/60 p-2 rounded-xl border border-gray-800">
              <MousePointer className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-cyan-300">마우스 휠 무기 교체:</span>
                <p className="text-gray-400">마우스 휠 위/아래 스크롤 또는 숫자 1~4키로 즉시 무기 교체</p>
              </div>
            </div>
            <div className="flex items-start gap-2 bg-gray-900/60 p-2 rounded-xl border border-gray-800">
              <Crosshair className="w-4 h-4 text-yellow-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-yellow-300">개별 3D 총기 디자인:</span>
                <p className="text-gray-400">돌격소총, 대물저격총, 네온샷건, 6연장미니건, 전술권총 등 전용 3D 모델 탑재</p>
              </div>
            </div>
            <div className="flex items-start gap-2 bg-gray-900/60 p-2 rounded-xl border border-gray-800">
              <span className="text-pink-400 font-black text-sm">WASD</span>
              <div>
                <span className="font-bold text-pink-300">기본 이동 & 전투:</span>
                <p className="text-gray-400">WASD 이동, Space 점프, R 장전, 좌클릭 사격, Shift 달리기</p>
              </div>
            </div>
            <div className="flex items-start gap-2 bg-gray-900/60 p-2 rounded-xl border border-gray-800">
              <span className="text-emerald-400 font-black text-sm">Q / E</span>
              <div>
                <span className="font-bold text-emerald-300">포션 복용:</span>
                <p className="text-gray-400">[Q] 체력 회복 포션 / [E] 나노 실드 충전 포션</p>
              </div>
            </div>
          </div>
        </div>

        <button
          id="startIntroBtn"
          onClick={onStart}
          className="w-full max-w-md py-3.5 bg-gradient-to-r from-red-600 via-pink-600 to-yellow-500 hover:from-red-500 hover:to-yellow-400 rounded-2xl font-black font-orbitron text-lg text-white shadow-xl transition transform hover:scale-[1.02] active:scale-95 flex items-center justify-center gap-2"
        >
          <Skull className="w-5 h-5" /> 생존 작전 기지로 진입하기
        </button>
      </div>
    </div>
  );
};
