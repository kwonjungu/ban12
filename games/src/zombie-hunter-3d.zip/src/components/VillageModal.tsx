import React, { useState } from 'react';
import {
  MapPin,
  UserCheck,
  Crosshair,
  FlaskConical,
  Coins,
  Shield,
  Target,
  Heart,
  Flame,
  ShieldAlert,
  Play,
  Zap,
  Sword,
  Bomb,
  Radio,
  Layers,
  Sparkles,
  Cpu,
  Lock,
  Wrench,
  Axe,
  Gauge,
  Activity
} from 'lucide-react';
import { WeaponData, JobClassData, PlayerState, WeaponId, WeaponSlot, JobClassId, PotionType } from '../types';
import { GAME_ASSETS } from '../game/assets';

interface VillageModalProps {
  playerState: PlayerState;
  weapons: Record<WeaponId, WeaponData>;
  classes: Record<JobClassId, JobClassData>;
  onSelectStage: (stage: number) => void;
  onSelectClass: (classId: JobClassId) => void;
  onBuyClass: (classId: JobClassId) => void;
  onEquipWeapon: (weaponId: WeaponId, slot: WeaponSlot) => void;
  onBuyWeapon: (weaponId: WeaponId) => void;
  onBuyPotion: (type: PotionType) => void;
  onLaunch: () => void;
}

type TabKey = 'STAGES' | 'CLASSES' | 'WEAPONS' | 'POTIONS';

export const VillageModal: React.FC<VillageModalProps> = ({
  playerState,
  weapons,
  classes,
  onSelectStage,
  onSelectClass,
  onBuyClass,
  onEquipWeapon,
  onBuyWeapon,
  onBuyPotion,
  onLaunch
}) => {
  const [activeTab, setActiveTab] = useState<TabKey>('STAGES');

  const getWeaponIcon = (id: WeaponId) => {
    switch (id) {
      case 'RIFLE': return <Crosshair className="w-4 h-4 text-cyan-400" />;
      case 'SNIPER': return <Target className="w-4 h-4 text-emerald-400" />;
      case 'SHOTGUN': return <Zap className="w-4 h-4 text-orange-400" />;
      case 'MINIGUN': return <Layers className="w-4 h-4 text-yellow-400" />;
      case 'PISTOL': return <Crosshair className="w-4 h-4 text-blue-400" />;
      case 'SMG': return <Radio className="w-4 h-4 text-purple-400" />;
      case 'KATANA': return <Sword className="w-4 h-4 text-cyan-300" />;
      case 'GRENADE': return <Bomb className="w-4 h-4 text-red-400" />;
      case 'COMMANDO_VULCAN': return <Shield className="w-4 h-4 text-amber-400" />;
      case 'RAILGUN': return <Cpu className="w-4 h-4 text-cyan-400" />;
      case 'BIO_LAUNCHER': return <FlaskConical className="w-4 h-4 text-emerald-400" />;
      case 'BLOOD_SCYTHE': return <Flame className="w-4 h-4 text-red-500" />;
      case 'TITAN_HAMMER': return <Wrench className="w-4 h-4 text-yellow-400" />;
      case 'THROWING_AXE': return <Axe className="w-4 h-4 text-sky-400" />;
      case 'EXPLOSIVE_SPEAR': return <Zap className="w-4 h-4 text-amber-400" />;
    }
  };

  const getClassIcon = (id: JobClassId) => {
    switch (id) {
      case 'COMMANDO': return <Shield className="w-5 h-5 text-cyan-400" />;
      case 'SNIPER': return <Target className="w-5 h-5 text-emerald-400" />;
      case 'MEDIC': return <Heart className="w-5 h-5 text-pink-400" />;
      case 'BERSERKER': return <Flame className="w-5 h-5 text-red-400" />;
      case 'JUGGERNAUT': return <ShieldAlert className="w-5 h-5 text-amber-400" />;
    }
  };

  return (
    <div className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-black/85 backdrop-blur-md p-3 md:p-6 overflow-hidden">
      <div className="max-w-5xl w-full max-h-[95vh] custom-glass-cyan rounded-3xl p-4 md:p-6 flex flex-col shadow-2xl border-2 border-green-500/50 bg-gradient-to-b from-green-950/40 via-gray-950/95 to-black overflow-hidden">
        
        {/* Header with Base Camp Asset Background */}
        <div className="relative rounded-2xl overflow-hidden border border-green-500/30 p-4 mb-3 shadow-lg flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
          <img
            src={GAME_ASSETS.hub}
            alt="안전 생존자 기지"
            referrerPolicy="no-referrer"
            className="absolute inset-0 w-full h-full object-cover opacity-25"
          />
          <div className="relative z-10">
            <div className="text-[10px] md:text-xs font-orbitron text-green-400 tracking-widest font-bold uppercase flex items-center gap-1.5">
              <Shield className="w-3.5 h-3.5 text-green-400" /> SAFE ZONE COMMAND CENTER
            </div>
            <h1 className="text-xl md:text-3xl font-black font-orbitron text-transparent bg-clip-text bg-gradient-to-r from-green-400 via-emerald-300 to-yellow-400 neon-glow-cyan">
              좀비 생존자 사령부
            </h1>
          </div>

          <div className="relative z-10 flex items-center gap-2">
            <div className="bg-gray-950/90 border border-yellow-500/60 px-4 py-1.5 rounded-2xl flex items-center gap-2 shadow-lg">
              <Coins className="w-5 h-5 text-yellow-400" />
              <span className="font-orbitron font-extrabold text-yellow-400 text-lg md:text-2xl">
                {playerState.gold.toLocaleString()} G
              </span>
            </div>
          </div>
        </div>

        {/* Tab Buttons */}
        <div className="flex gap-2 mb-3 border-b border-gray-800 pb-2.5 overflow-x-auto shrink-0">
          <button
            onClick={() => setActiveTab('STAGES')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold font-orbitron flex items-center gap-2 shrink-0 transition ${
              activeTab === 'STAGES'
                ? 'bg-amber-600/90 text-amber-100 border border-amber-400/80 shadow-md'
                : 'bg-gray-900/90 text-gray-400 hover:text-white border border-gray-800'
            }`}
          >
            <MapPin className="w-3.5 h-3.5 text-yellow-400" /> 작전 지도 (스테이지 1~20)
          </button>
          <button
            onClick={() => setActiveTab('CLASSES')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold font-orbitron flex items-center gap-2 shrink-0 transition ${
              activeTab === 'CLASSES'
                ? 'bg-cyan-600/90 text-cyan-100 border border-cyan-400/80 shadow-md'
                : 'bg-gray-900/90 text-gray-400 hover:text-white border border-gray-800'
            }`}
          >
            <UserCheck className="w-3.5 h-3.5 text-cyan-400" /> 직업 길드 (전직)
          </button>
          <button
            onClick={() => setActiveTab('WEAPONS')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold font-orbitron flex items-center gap-2 shrink-0 transition ${
              activeTab === 'WEAPONS'
                ? 'bg-orange-600/90 text-orange-100 border border-orange-400/80 shadow-md'
                : 'bg-gray-900/90 text-gray-400 hover:text-white border border-gray-800'
            }`}
          >
            <Crosshair className="w-3.5 h-3.5 text-orange-400" /> 무기 상점 & 4슬롯 로드아웃
          </button>
          <button
            onClick={() => setActiveTab('POTIONS')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold font-orbitron flex items-center gap-2 shrink-0 transition ${
              activeTab === 'POTIONS'
                ? 'bg-purple-600/90 text-purple-100 border border-purple-400/80 shadow-md'
                : 'bg-gray-900/90 text-gray-400 hover:text-white border border-gray-800'
            }`}
          >
            <FlaskConical className="w-3.5 h-3.5 text-purple-400" /> 마법 포션 상점
          </button>
        </div>

        {/* NPC Dialogue Box */}
        <div className="bg-green-950/40 border border-green-500/30 rounded-2xl p-2.5 mb-3 text-xs text-green-200 flex items-center gap-3 shrink-0">
          <div className="w-8 h-8 rounded-full bg-green-900/80 border border-green-400 flex items-center justify-center shrink-0">
            <Sparkles className="w-4 h-4 text-yellow-300" />
          </div>
          <div>
            {activeTab === 'STAGES' && (
              <span><b className="text-yellow-300">[작전 사령관]:</b> 20개 구역 중 출격할 작전지를 선택하십시오! 5, 10, 15, 20 스테이지에는 거대 변종 오메가 보스가 출현합니다.</span>
            )}
            {activeTab === 'CLASSES' && (
              <span><b className="text-cyan-300">[직업 길드장]:</b> 골드를 투자해 전문 직업으로 전직하십시오! 스나이퍼, 버서커, 중장갑 든든이 등 강력한 고유 패시브가 적용됩니다.</span>
            )}
            {activeTab === 'WEAPONS' && (
              <span><b className="text-orange-300">[수석 총기 기술자]:</b> 모든 총기는 고유한 3D 디자인을 갖추고 있습니다. 마우스 휠로 전투 중 언제든 1~4번 무기로 교체할 수 있습니다!</span>
            )}
            {activeTab === 'POTIONS' && (
              <span><b className="text-purple-300">[의무 보급관]:</b> 전투 중 위급할 때 [Q]키로 체력 포션, [E]키로 실드 포션을 즉시 섭취할 수 있습니다. 넉넉히 챙겨가십시오.</span>
            )}
          </div>
        </div>

        {/* Main Tab Content */}
        <div className="flex-1 overflow-y-auto pr-1 space-y-4">
          
          {/* TAB 1: STAGES */}
          {activeTab === 'STAGES' && (
            <div>
              <div className="flex justify-between items-center mb-2.5">
                <h2 className="text-xs font-orbitron font-bold text-yellow-400 flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-yellow-400" /> 출격 작전 구역 (STAGE 1 ~ 20)
                </h2>
                <span className="text-[11px] text-gray-400">
                  클리어 달성 시 다음 구역 자동 해금
                </span>
              </div>

              {/* Boss stage warning card preview */}
              {playerState.selectedStage % 5 === 0 && (
                <div className="mb-3 rounded-2xl overflow-hidden border border-red-500/60 bg-red-950/50 p-3 flex items-center gap-4">
                  <img
                    src={GAME_ASSETS.bossCard}
                    alt="보스 좀비"
                    referrerPolicy="no-referrer"
                    className="w-16 h-16 rounded-xl object-cover border border-red-500 shadow-md shrink-0"
                  />
                  <div>
                    <div className="text-xs font-orbitron font-black text-red-400 flex items-center gap-1">
                      <ShieldAlert className="w-4 h-4 text-red-500" /> STAGE {playerState.selectedStage} 위험 경보: 거대 변종 오메가 보스 구역
                    </div>
                    <p className="text-[11px] text-gray-300 mt-0.5">
                      엄청난 체력과 강력한 공격력을 지닌 보스 좀비가 배회하고 있습니다. 충분한 탄약과 포션을 준비하십시오!
                    </p>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-5 sm:grid-cols-8 md:grid-cols-10 gap-2 max-h-72 overflow-y-auto pr-1">
                {Array.from({ length: 40 }, (_, idx) => {
                  const stageNum = idx + 1;
                  const isUnlocked = stageNum <= playerState.unlockedStage;
                  const isSelected = stageNum === playerState.selectedStage;
                  const isBoss = stageNum % 5 === 0;

                  return (
                    <button
                      key={stageNum}
                      disabled={!isUnlocked}
                      onClick={() => onSelectStage(stageNum)}
                      className={`p-2 rounded-xl text-center flex flex-col items-center justify-center border font-orbitron text-xs transition-all ${
                        isSelected
                          ? 'border-yellow-400 bg-yellow-500/25 text-yellow-300 font-extrabold scale-105 shadow-lg ring-2 ring-yellow-400/40'
                          : isUnlocked
                            ? isBoss
                              ? 'border-red-500/80 bg-red-950/60 text-red-300 hover:bg-red-900/80'
                              : 'border-green-500/50 bg-green-950/40 text-green-300 hover:bg-green-900/60'
                            : 'border-gray-800 bg-gray-950/40 text-gray-600 cursor-not-allowed opacity-50'
                      }`}
                    >
                      <span className="text-[11px] font-bold">ST.{stageNum}</span>
                      {isBoss ? (
                        <span className="text-[9px] text-red-400 font-black flex items-center gap-0.5 mt-0.5">
                          BOSS
                        </span>
                      ) : (
                        <span className="text-[9px] text-gray-400 mt-0.5">소탕</span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 2: CLASSES / JOBS */}
          {activeTab === 'CLASSES' && (
            <div>
              <div className="flex justify-between items-center mb-2.5">
                <h2 className="text-xs font-orbitron font-bold text-cyan-400 flex items-center gap-1.5">
                  <UserCheck className="w-4 h-4 text-cyan-400" /> 전투 직업 선택 & 전직 (JOB SHOP)
                </h2>
                <span className="text-[11px] text-gray-400">
                  현재 적용 직업: <b className="text-cyan-300">{classes[playerState.currentJobKey]?.name}</b>
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                {Object.values(classes).map((job) => {
                  const isCurrent = playerState.currentJobKey === job.id;

                  return (
                    <div
                      key={job.id}
                      className={`p-3.5 rounded-2xl border flex flex-col justify-between transition ${
                        isCurrent
                          ? 'border-cyan-400 bg-cyan-950/40 shadow-[0_0_15px_rgba(0,240,255,0.2)]'
                          : 'border-gray-800 bg-gray-950/70 hover:border-gray-700'
                      }`}
                    >
                      <div>
                        <div className="flex justify-between items-center mb-1.5">
                          <div className="flex items-center gap-2">
                            {getClassIcon(job.id)}
                            <span className="font-bold text-sm text-cyan-200">{job.name}</span>
                          </div>
                          {isCurrent && (
                            <span className="text-[10px] bg-cyan-500 text-black px-2 py-0.5 rounded-full font-bold">
                              장착 중
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-gray-300 mb-2.5 leading-relaxed">{job.desc}</p>
                        
                        <div className="text-[10px] space-y-0.5 text-gray-400 mb-3 bg-black/40 p-2 rounded-xl border border-gray-900">
                          {job.hpBonus !== 0 && <div>• 체력 보너스: <b className={job.hpBonus > 0 ? 'text-green-400' : 'text-red-400'}>{job.hpBonus > 0 ? `+${job.hpBonus}` : job.hpBonus} HP</b></div>}
                          {job.shieldBonus !== 0 && <div>• 실드 보너스: <b className="text-cyan-400">+{job.shieldBonus}</b></div>}
                          {job.dmgMultiplier !== 1.0 && <div>• 공격력 배율: <b className="text-yellow-400">x{job.dmgMultiplier}</b></div>}
                          {job.speedBonus !== 0 && <div>• 이동속도 보너스: <b className="text-emerald-400">+{Math.round(job.speedBonus * 1000)}%</b></div>}
                          {job.meleeMultiplier && <div>• 카타나/근접 증폭: <b className="text-pink-400">x{job.meleeMultiplier}</b></div>}
                          <div className="pt-1 border-t border-gray-800 text-yellow-300 font-bold flex items-center gap-1">
                            <span>⭐ 전용 무기:</span>
                            <span className="text-orange-400">{weapons[job.signatureWeaponId]?.name}</span>
                          </div>
                        </div>
                      </div>

                      <div>
                        {isCurrent ? (
                          <div className="w-full py-2 bg-cyan-500/20 text-cyan-300 border border-cyan-400 text-xs rounded-xl font-bold text-center">
                            현재 선택된 직업
                          </div>
                        ) : job.unlocked ? (
                          <button
                            onClick={() => onSelectClass(job.id)}
                            className="w-full py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs rounded-xl transition shadow-md"
                          >
                            전직하기
                          </button>
                        ) : (
                          <button
                            onClick={() => onBuyClass(job.id)}
                            disabled={playerState.gold < job.cost}
                            className={`w-full py-2 font-extrabold text-xs rounded-xl transition flex items-center justify-center gap-1.5 ${
                              playerState.gold >= job.cost
                                ? 'bg-yellow-500 hover:bg-yellow-400 text-black shadow-lg'
                                : 'bg-gray-800 text-gray-500 cursor-not-allowed'
                            }`}
                          >
                            <Coins className="w-3.5 h-3.5" /> 해금하기 ({job.cost} G)
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 3: WEAPONS & LOADOUT */}
          {activeTab === 'WEAPONS' && (
            <div>
              <div className="flex justify-between items-center mb-1">
                <h2 className="text-xs font-orbitron font-bold text-orange-400 flex items-center gap-1.5">
                  <Crosshair className="w-4 h-4 text-orange-400" /> 무기 상점 & 4개 슬롯 무기 장착 (WEAPONS LOADOUT)
                </h2>
                <span className="text-[11px] text-cyan-300">
                  마우스 휠(Scroll)로 무기 전환 가능
                </span>
              </div>
              <p className="text-[11px] text-gray-400 mb-3">
                슬롯 1(주무기) • 슬롯 2(보조무기) • 슬롯 3(근접도검) • 슬롯 4(투척수류탄)에 자유롭게 장착하십시오.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                {Object.values(weapons).map((wep) => {
                  const isEquipped = Object.values(playerState.equippedSlots).includes(wep.id);

                  return (
                    <div
                      key={wep.id}
                      className={`p-3 rounded-2xl border flex flex-col justify-between transition ${
                        isEquipped
                          ? 'border-orange-400 bg-orange-950/35 shadow-[0_0_12px_rgba(249,115,22,0.2)]'
                          : 'border-gray-800 bg-gray-950/70 hover:border-gray-700'
                      }`}
                    >
                      <div>
                        <div className="flex items-center gap-2.5 mb-2">
                          <div className="w-9 h-9 rounded-xl bg-gray-900 border border-orange-500/40 flex items-center justify-center shrink-0">
                            {getWeaponIcon(wep.id)}
                          </div>
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="font-bold text-xs text-gray-100 truncate">{wep.name}</span>
                              {wep.exclusiveJob && (
                                <span className="text-[9px] px-1.5 py-0.2 bg-purple-500/30 text-purple-300 border border-purple-400/50 rounded font-orbitron font-bold">
                                  직업 전용
                                </span>
                              )}
                            </div>
                            <div className="text-[10px] text-orange-400 font-orbitron">
                              슬롯 {wep.slot} • {wep.category}
                            </div>
                          </div>
                        </div>

                        <p className="text-[11px] text-gray-300 mb-2 leading-tight">{wep.description}</p>

                        <div className="grid grid-cols-2 gap-1 text-[10px] text-gray-400 bg-black/40 p-2 rounded-xl mb-3 border border-gray-900">
                          <div>공격력: <b className="text-yellow-400">{wep.damage}</b></div>
                          <div>발사간격: <b className="text-cyan-400">{wep.fireRate}s</b></div>
                          <div>탄창: <b className="text-emerald-400">{wep.isMelee ? '무제한' : wep.magSize}</b></div>
                          <div>장전속도: <b className="text-gray-300">{wep.isMelee ? '-' : `${wep.reloadTime}s`}</b></div>
                        </div>
                      </div>

                      <div>
                        {isEquipped ? (
                          <div className="w-full py-1.5 bg-orange-500/20 text-orange-400 border border-orange-500/60 text-[11px] rounded-xl font-bold text-center">
                            슬롯 {wep.slot}에 장착 중
                          </div>
                        ) : wep.exclusiveJob && playerState.currentJobKey !== wep.exclusiveJob ? (
                          <div className="w-full py-1.5 bg-gray-900/80 text-gray-500 border border-gray-800 text-[10px] rounded-xl font-bold text-center flex items-center justify-center gap-1">
                            <Lock className="w-3 h-3 text-red-400" /> [{classes[wep.exclusiveJob]?.name || wep.exclusiveJob}] 직업 전용
                          </div>
                        ) : wep.unlocked ? (
                          <button
                            onClick={() => onEquipWeapon(wep.id, wep.slot)}
                            className="w-full py-1.5 bg-orange-600 hover:bg-orange-500 text-white font-bold text-[11px] rounded-xl transition shadow-md"
                          >
                            슬롯 {wep.slot}에 장착하기
                          </button>
                        ) : (
                          <button
                            onClick={() => onBuyWeapon(wep.id)}
                            disabled={playerState.gold < wep.cost}
                            className={`w-full py-1.5 font-extrabold text-[11px] rounded-xl transition flex items-center justify-center gap-1.5 ${
                              playerState.gold >= wep.cost
                                ? 'bg-yellow-500 hover:bg-yellow-400 text-black shadow-lg'
                                : 'bg-gray-800 text-gray-500 cursor-not-allowed'
                            }`}
                          >
                            <Coins className="w-3.5 h-3.5" /> 구매하기 ({wep.cost} G)
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 4: POTIONS */}
          {activeTab === 'POTIONS' && (
            <div>
              <div className="flex justify-between items-center mb-2.5">
                <h2 className="text-xs font-orbitron font-bold text-purple-400 flex items-center gap-1.5">
                  <FlaskConical className="w-4 h-4 text-purple-400" /> 전투 비상 전술 포션 상점 (TACTICAL POTIONS)
                </h2>
                <span className="text-[11px] text-gray-400">전투 중 [Q], [E], [Z], [X], [C] 단축키로 복용</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {/* 1. HP Potion */}
                <div className="p-3.5 rounded-2xl border border-red-500/40 bg-red-950/25 flex flex-col justify-between">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-2xl bg-red-900/60 border border-red-500 flex items-center justify-center shrink-0">
                      <Heart className="w-5 h-5 text-red-400" />
                    </div>
                    <div>
                      <div className="font-bold text-xs text-red-300">체력 회복 포션 [Q]</div>
                      <div className="text-[11px] text-gray-300 mt-0.5 leading-tight">
                        체력 +50 즉시 회복 (메디크 직업은 +100 회복)
                      </div>
                      <div className="text-[11px] text-yellow-400 font-bold mt-1">
                        보유량: {playerState.hpPotions}개
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => onBuyPotion('HP')}
                    disabled={playerState.gold < 80}
                    className={`mt-2.5 w-full py-1.5 font-bold text-xs rounded-xl transition flex items-center justify-center gap-1.5 ${
                      playerState.gold >= 80
                        ? 'bg-red-600 hover:bg-red-500 text-white shadow-lg'
                        : 'bg-gray-800 text-gray-500 cursor-not-allowed'
                    }`}
                  >
                    <Coins className="w-3.5 h-3.5" /> 구매 (80 G)
                  </button>
                </div>

                {/* 2. Shield Potion */}
                <div className="p-3.5 rounded-2xl border border-cyan-500/40 bg-cyan-950/25 flex flex-col justify-between">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-2xl bg-cyan-900/60 border border-cyan-500 flex items-center justify-center shrink-0">
                      <Shield className="w-5 h-5 text-cyan-400" />
                    </div>
                    <div>
                      <div className="font-bold text-xs text-cyan-300">나노 실드 충전 포션 [E]</div>
                      <div className="text-[11px] text-gray-300 mt-0.5 leading-tight">
                        나노 실드 +40 충전 (메디크 직업은 +80 충전)
                      </div>
                      <div className="text-[11px] text-yellow-400 font-bold mt-1">
                        보유량: {playerState.shieldPotions}개
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => onBuyPotion('SHIELD')}
                    disabled={playerState.gold < 100}
                    className={`mt-2.5 w-full py-1.5 font-bold text-xs rounded-xl transition flex items-center justify-center gap-1.5 ${
                      playerState.gold >= 100
                        ? 'bg-cyan-600 hover:bg-cyan-500 text-white shadow-lg'
                        : 'bg-gray-800 text-gray-500 cursor-not-allowed'
                    }`}
                  >
                    <Coins className="w-3.5 h-3.5" /> 구매 (100 G)
                  </button>
                </div>

                {/* 3. Speed / Adrenaline Potion */}
                <div className="p-3.5 rounded-2xl border border-emerald-500/40 bg-emerald-950/25 flex flex-col justify-between">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-2xl bg-emerald-900/60 border border-emerald-500 flex items-center justify-center shrink-0">
                      <Gauge className="w-5 h-5 text-emerald-400" />
                    </div>
                    <div>
                      <div className="font-bold text-xs text-emerald-300">아드레날린 가속제 [Z]</div>
                      <div className="text-[11px] text-gray-300 mt-0.5 leading-tight">
                        15초간 이동속도 +75% 초고속 기동 버프 활성화
                      </div>
                      <div className="text-[11px] text-yellow-400 font-bold mt-1">
                        보유량: {playerState.speedPotions}개
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => onBuyPotion('SPEED')}
                    disabled={playerState.gold < 120}
                    className={`mt-2.5 w-full py-1.5 font-bold text-xs rounded-xl transition flex items-center justify-center gap-1.5 ${
                      playerState.gold >= 120
                        ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg'
                        : 'bg-gray-800 text-gray-500 cursor-not-allowed'
                    }`}
                  >
                    <Coins className="w-3.5 h-3.5" /> 구매 (120 G)
                  </button>
                </div>

                {/* 4. Berserk Potion */}
                <div className="p-3.5 rounded-2xl border border-amber-500/40 bg-amber-950/25 flex flex-col justify-between">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-2xl bg-amber-900/60 border border-amber-500 flex items-center justify-center shrink-0">
                      <Zap className="w-5 h-5 text-amber-400" />
                    </div>
                    <div>
                      <div className="font-bold text-xs text-amber-300">버서커 오버드라이브 [X]</div>
                      <div className="text-[11px] text-gray-300 mt-0.5 leading-tight">
                        12초간 화력 +100% 증폭 및 치명타 확률 +35% 극대화
                      </div>
                      <div className="text-[11px] text-yellow-400 font-bold mt-1">
                        보유량: {playerState.berserkPotions}개
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => onBuyPotion('BERSERK')}
                    disabled={playerState.gold < 160}
                    className={`mt-2.5 w-full py-1.5 font-bold text-xs rounded-xl transition flex items-center justify-center gap-1.5 ${
                      playerState.gold >= 160
                        ? 'bg-amber-600 hover:bg-amber-500 text-white shadow-lg'
                        : 'bg-gray-800 text-gray-500 cursor-not-allowed'
                    }`}
                  >
                    <Coins className="w-3.5 h-3.5" /> 구매 (160 G)
                  </button>
                </div>

                {/* 5. Full Restore Potion */}
                <div className="p-3.5 rounded-2xl border border-purple-500/50 bg-purple-950/30 flex flex-col justify-between sm:col-span-2 lg:col-span-1">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-2xl bg-purple-900/60 border border-purple-400 flex items-center justify-center shrink-0">
                      <Sparkles className="w-5 h-5 text-purple-300" />
                    </div>
                    <div>
                      <div className="font-bold text-xs text-purple-200">풀 나노 코어 엘릭서 [C]</div>
                      <div className="text-[11px] text-gray-300 mt-0.5 leading-tight">
                        체력과 나노 실드를 100% 완전 완충 복원
                      </div>
                      <div className="text-[11px] text-yellow-400 font-bold mt-1">
                        보유량: {playerState.fullRestorePotions}개
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => onBuyPotion('FULL_RESTORE')}
                    disabled={playerState.gold < 240}
                    className={`mt-2.5 w-full py-1.5 font-bold text-xs rounded-xl transition flex items-center justify-center gap-1.5 ${
                      playerState.gold >= 240
                        ? 'bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white shadow-lg'
                        : 'bg-gray-800 text-gray-500 cursor-not-allowed'
                    }`}
                  >
                    <Coins className="w-3.5 h-3.5" /> 구매 (240 G)
                  </button>
                </div>
              </div>
            </div>
          )}

        </div>

        {/* Footer: Selected Stage and Launch Button */}
        <div className="mt-3 pt-3 border-t border-green-500/30 flex justify-between items-center shrink-0">
          <div className="flex flex-col">
            <span className="text-[11px] text-gray-400">현재 목표 구역</span>
            <span className="text-sm font-orbitron font-extrabold text-yellow-400 neon-glow-gold">
              STAGE {playerState.selectedStage} {playerState.selectedStage % 5 === 0 ? '• [BOSS 구역]' : '• [일반 소탕]'}
            </span>
          </div>

          <button
            id="launchStageBtn"
            onClick={onLaunch}
            className="px-6 py-2.5 bg-gradient-to-r from-green-600 via-emerald-600 to-yellow-500 hover:from-green-500 hover:to-yellow-400 text-white font-black font-orbitron text-base rounded-2xl shadow-xl transition transform hover:scale-[1.03] active:scale-95 flex items-center gap-2"
          >
            <Play className="w-5 h-5 fill-current" /> 작전 출격하기
          </button>
        </div>
      </div>
    </div>
  );
};
