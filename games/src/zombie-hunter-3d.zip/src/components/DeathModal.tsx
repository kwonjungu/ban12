import React from 'react';
import { Skull, Home, Coins, Trophy } from 'lucide-react';

interface DeathModalProps {
  stage: number;
  goldEarned: number;
  kills: number;
  onReturnVillage: () => void;
}

export const DeathModal: React.FC<DeathModalProps> = ({
  stage,
  goldEarned,
  kills,
  onReturnVillage
}) => {
  return (
    <div className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-black/95 p-6 text-center animate-fade-in">
      <div className="w-16 h-16 rounded-full bg-red-950/80 border-2 border-red-600 flex items-center justify-center mb-3 shadow-[0_0_25px_rgba(255,0,0,0.6)]">
        <Skull className="w-8 h-8 text-red-500 animate-pulse" />
      </div>

      <div className="text-3xl md:text-5xl font-black font-orbitron mb-2 text-red-600 neon-glow-red">
        작전 실패 (DIED)
      </div>
      <p className="text-gray-300 text-xs md:text-sm mb-6 max-w-sm">
        전투 중 치명상을 입고 쓰러졌습니다. 사령부 수색구조팀에 의해 안전 기지로 후송되었습니다.
      </p>

      <div className="bg-gray-950/90 border border-red-500/50 p-5 rounded-2xl w-full max-w-sm mb-6 flex flex-col gap-2.5 text-xs shadow-2xl">
        <div className="flex justify-between border-b border-gray-800 pb-2">
          <span className="text-gray-400">교전 구역</span>
          <span className="font-orbitron font-bold text-red-400">STAGE {stage}</span>
        </div>
        <div className="flex justify-between border-b border-gray-800 pb-2 items-center">
          <span className="text-gray-400 flex items-center gap-1"><Coins className="w-3.5 h-3.5 text-yellow-400" /> 전투 획득 골드</span>
          <span className="font-orbitron font-extrabold text-yellow-400">+{goldEarned.toLocaleString()} G</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-gray-400 flex items-center gap-1"><Trophy className="w-3.5 h-3.5 text-cyan-400" /> 처치한 좀비 수</span>
          <span className="font-orbitron font-bold text-cyan-400">{kills} 마리</span>
        </div>
      </div>

      <button
        id="returnVillageBtn"
        onClick={onReturnVillage}
        className="px-8 py-3 bg-gradient-to-r from-cyan-600 via-blue-600 to-pink-600 hover:from-cyan-500 hover:to-pink-500 rounded-2xl font-black font-orbitron text-base text-white shadow-xl transition transform hover:scale-105 active:scale-95 flex items-center gap-2"
      >
        <Home className="w-5 h-5" /> 안전 사령부로 복귀
      </button>
    </div>
  );
};
