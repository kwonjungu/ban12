import React from 'react';
import { Trophy, Coins, ArrowRight, ShieldCheck } from 'lucide-react';
import { GAME_ASSETS } from '../game/assets';

interface VictoryModalProps {
  stage: number;
  goldEarned: number;
  kills: number;
  nextStage: number;
  onContinue: () => void;
}

export const VictoryModal: React.FC<VictoryModalProps> = ({
  stage,
  goldEarned,
  kills,
  nextStage,
  onContinue
}) => {
  const isBossStage = stage % 5 === 0;

  return (
    <div className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-black/90 p-6 text-center animate-fade-in backdrop-blur-sm">
      <div className="w-16 h-16 rounded-full bg-emerald-950/80 border-2 border-emerald-500 flex items-center justify-center mb-3 shadow-[0_0_25px_rgba(0,255,100,0.6)]">
        <Trophy className="w-8 h-8 text-yellow-400 animate-bounce" />
      </div>

      <div className="text-3xl md:text-5xl font-black font-orbitron mb-1 text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-yellow-300 to-cyan-400 neon-glow-gold">
        {isBossStage ? '오메가 보스 격파!' : '구역 소탕 완료!'}
      </div>
      <p className="text-gray-300 text-xs md:text-sm mb-5">
        STAGE {stage} 의 모든 변종 좀비를 성공적으로 섬멸하였습니다!
      </p>

      {/* Reward Card */}
      <div className="bg-gray-950/90 border border-emerald-500/50 p-5 rounded-2xl w-full max-w-sm mb-6 flex flex-col gap-2.5 text-xs shadow-2xl">
        <div className="flex justify-between border-b border-gray-800 pb-2">
          <span className="text-gray-400">클리어 구역</span>
          <span className="font-orbitron font-bold text-emerald-400">STAGE {stage}</span>
        </div>
        <div className="flex justify-between border-b border-gray-800 pb-2 items-center">
          <span className="text-gray-400 flex items-center gap-1"><Coins className="w-3.5 h-3.5 text-yellow-400" /> 총 획득 골드</span>
          <span className="font-orbitron font-extrabold text-yellow-400">+{goldEarned.toLocaleString()} G</span>
        </div>
        <div className="flex justify-between border-b border-gray-800 pb-2 items-center">
          <span className="text-gray-400 flex items-center gap-1"><Trophy className="w-3.5 h-3.5 text-cyan-400" /> 처치한 좀비</span>
          <span className="font-orbitron font-bold text-cyan-400">{kills} 마리</span>
        </div>
        <div className="flex justify-between items-center text-yellow-300 font-bold">
          <span className="flex items-center gap-1"><ShieldCheck className="w-4 h-4 text-green-400" /> 다음 작전 구역 해금</span>
          <span className="font-orbitron">STAGE {nextStage}</span>
        </div>
      </div>

      <button
        onClick={onContinue}
        className="px-8 py-3 bg-gradient-to-r from-emerald-600 via-green-600 to-yellow-500 hover:from-emerald-500 hover:to-yellow-400 rounded-2xl font-black font-orbitron text-base text-white shadow-xl transition transform hover:scale-105 active:scale-95 flex items-center gap-2"
      >
        <span>사령부 복귀 및 정비</span> <ArrowRight className="w-5 h-5" />
      </button>
    </div>
  );
};
