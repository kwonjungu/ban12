import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import {
  WeaponSlot,
  WeaponId,
  JobClassId,
  PlayerState,
  ActiveSession,
  WeaponData,
  WeaponImpactType
} from './types';
import { INITIAL_WEAPONS, INITIAL_CLASSES, createWeapon3DModel } from './game/weapons';
import { sounds } from './game/sound';
import { IntroModal } from './components/IntroModal';
import { VillageModal } from './components/VillageModal';
import { HUD } from './components/HUD';
import { DeathModal } from './components/DeathModal';
import { VictoryModal } from './components/VictoryModal';

interface ZombieEntity {
  mesh: THREE.Group;
  hpSpriteObj: {
    sprite: THREE.Sprite;
    canvas: HTMLCanvasElement;
    ctx: CanvasRenderingContext2D;
    texture: THREE.CanvasTexture;
  };
  leftLeg?: THREE.Mesh;
  rightLeg?: THREE.Mesh;
  type: string;
  hp: number;
  maxHp: number;
  speed: number;
  damage: number;
  walkAnimTime: number;
}

interface GrenadeEntity {
  mesh: THREE.Group | THREE.Mesh;
  velocity: THREE.Vector3;
  timer: number;
  damage: number;
  type: 'GRENADE' | 'AXE' | 'SPEAR';
  radius: number;
  rotSpeed?: { x: number; y: number; z: number };
}

interface ParticleEntity {
  mesh: THREE.Mesh;
  velocity: THREE.Vector3;
  life: number;
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // App UI Screen state
  const [gameState, setGameState] = useState<'INTRO' | 'VILLAGE' | 'PLAYING' | 'DEATH' | 'VICTORY'>('INTRO');

  // Player Persistent State
  const [playerState, setPlayerState] = useState<PlayerState>({
    gold: 350,
    unlockedStage: 1,
    selectedStage: 1,
    currentJobKey: 'COMMANDO',
    equippedSlots: { 1: 'RIFLE', 2: 'PISTOL', 3: 'KATANA', 4: 'GRENADE' },
    activeSlot: 1,
    hpPotions: 3,
    shieldPotions: 2,
    speedPotions: 1,
    berserkPotions: 1,
    fullRestorePotions: 1,
    baseMaxHp: 100,
    baseMaxShield: 50,
    baseSpeed: 0.17,
    critChance: 0.15
  });

  const [weapons, setWeapons] = useState(INITIAL_WEAPONS);
  const [classes, setClasses] = useState(INITIAL_CLASSES);

  // Active Session state for UI
  const [hudHp, setHudHp] = useState(100);
  const [hudShield, setHudShield] = useState(50);
  const [currentAmmo, setCurrentAmmo] = useState(30);
  const [reserveAmmo, setReserveAmmo] = useState(210);
  const [isReloading, setIsReloading] = useState(false);
  const [zombiesLeft, setZombiesLeft] = useState(0);
  const [zombiesTotal, setZombiesTotal] = useState(0);
  const [bossHp, setBossHp] = useState<number | null>(null);
  const [maxBossHp, setMaxBossHp] = useState<number | null>(null);
  const [lastKills, setLastKills] = useState(0);
  const [lastEarnedGold, setLastEarnedGold] = useState(0);
  const [showAimHint, setShowAimHint] = useState(false);
  const [isZoomed, setIsZoomed] = useState(false);
  const isZoomedRef = useRef(false);

  // Buff Timers (Speed Adrenaline & Berserk Overdrive)
  const [speedBuffTimer, setSpeedBuffTimer] = useState(0);
  const [berserkBuffTimer, setBerserkBuffTimer] = useState(0);
  const speedBuffTimerRef = useRef(0);
  const berserkBuffTimerRef = useRef(0);

  // Overlays
  const [damageFlash, setDamageFlash] = useState(false);
  const [healFlash, setHealFlash] = useState(false);
  const [shieldFlash, setShieldFlash] = useState(false);
  const [speedFlash, setSpeedFlash] = useState(false);
  const [berserkFlash, setBerserkFlash] = useState(false);
  const [fullRestoreFlash, setFullRestoreFlash] = useState(false);

  // Three.js References
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const weaponContainerRef = useRef<THREE.Group | null>(null);
  const currentWeaponModelRef = useRef<THREE.Group | null>(null);
  const minigunBarrelsRef = useRef<THREE.Mesh[] | null>(null);
  const muzzleFlashLightRef = useRef<THREE.PointLight | null>(null);

  const zombiesRef = useRef<ZombieEntity[]>([]);
  const grenadesRef = useRef<GrenadeEntity[]>([]);
  const particlesRef = useRef<ParticleEntity[]>([]);
  const bossEntityRef = useRef<ZombieEntity | null>(null);

  // Session ref for zero-latency game loop
  const sessionRef = useRef<ActiveSession>({
    hp: 100,
    shield: 50,
    weaponAmmo: {
      RIFLE: 30,
      SNIPER: 5,
      SHOTGUN: 8,
      MINIGUN: 120,
      PISTOL: 15,
      SMG: 35,
      KATANA: 1,
      GRENADE: 8,
      COMMANDO_VULCAN: 50,
      RAILGUN: 4,
      BIO_LAUNCHER: 12,
      BLOOD_SCYTHE: 1,
      TITAN_HAMMER: 1,
      THROWING_AXE: 1,
      EXPLOSIVE_SPEAR: 1
    },
    weaponReserve: {
      RIFLE: 210,
      SNIPER: 35,
      SHOTGUN: 56,
      MINIGUN: 480,
      PISTOL: 120,
      SMG: 210,
      KATANA: 999,
      GRENADE: 10,
      COMMANDO_VULCAN: 350,
      RAILGUN: 28,
      BIO_LAUNCHER: 84,
      BLOOD_SCYTHE: 999,
      TITAN_HAMMER: 999,
      THROWING_AXE: 15,
      EXPLOSIVE_SPEAR: 8
    },
    isReloading: false,
    killsThisRun: 0,
    goldEarnedThisRun: 0,
    isPlaying: false,
    velocityY: 0,
    isGrounded: true
  });

  const keysRef = useRef<{ w: boolean; a: boolean; s: boolean; d: boolean; shift: boolean }>({
    w: false,
    a: false,
    s: false,
    d: false,
    shift: false
  });

  const lastShootTimeRef = useRef(0);
  const isPointerLockedRef = useRef(false);
  const isMouseDownRef = useRef(false);
  const prevMouseRef = useRef({ x: 0, y: 0 });

  // Calculate Max HP & Shield based on class
  const getMaxHp = useCallback(() => {
    const job = classes[playerState.currentJobKey];
    return playerState.baseMaxHp + (job ? job.hpBonus : 0);
  }, [classes, playerState.currentJobKey, playerState.baseMaxHp]);

  const getMaxShield = useCallback(() => {
    const job = classes[playerState.currentJobKey];
    return playerState.baseMaxShield + (job ? job.shieldBonus : 0);
  }, [classes, playerState.currentJobKey, playerState.baseMaxShield]);

  // Attach weapon 3D model into camera
  const switchWeapon3DModel = useCallback((weaponId: WeaponId) => {
    if (!weaponContainerRef.current) return;

    // Remove old model
    if (currentWeaponModelRef.current) {
      weaponContainerRef.current.remove(currentWeaponModelRef.current);
      currentWeaponModelRef.current = null;
      minigunBarrelsRef.current = null;
    }

    // Build new distinct 3D model
    const { root, barrels } = createWeapon3DModel(weaponId);
    currentWeaponModelRef.current = root;
    if (barrels) {
      minigunBarrelsRef.current = barrels;
    }

    weaponContainerRef.current.add(root);
  }, []);

  // Cycle slot via mouse wheel or keys
  const cycleSlot = useCallback((direction: number) => {
    // Reset sniper zoom if zooming
    if (isZoomedRef.current) {
      isZoomedRef.current = false;
      setIsZoomed(false);
      sounds.zoomOut();
      if (cameraRef.current) {
        cameraRef.current.fov = 75;
        cameraRef.current.updateProjectionMatrix();
      }
      if (weaponContainerRef.current) {
        weaponContainerRef.current.visible = true;
      }
    }

    setPlayerState((prev) => {
      let nextSlot = (prev.activeSlot + direction) as WeaponSlot;
      if (nextSlot > 4) nextSlot = 1;
      if (nextSlot < 1) nextSlot = 4;

      sounds.switchWeapon();
      const nextWepId = prev.equippedSlots[nextSlot];
      switchWeapon3DModel(nextWepId);

      // Update ammo displays
      const ammo = sessionRef.current.weaponAmmo[nextWepId] || 0;
      const reserve = sessionRef.current.weaponReserve[nextWepId] || 0;
      setCurrentAmmo(ammo);
      setReserveAmmo(reserve);

      return { ...prev, activeSlot: nextSlot };
    });
  }, [switchWeapon3DModel]);

  const selectSlot = useCallback((slot: WeaponSlot) => {
    // Reset sniper zoom if zooming
    if (isZoomedRef.current) {
      isZoomedRef.current = false;
      setIsZoomed(false);
      sounds.zoomOut();
      if (cameraRef.current) {
        cameraRef.current.fov = 75;
        cameraRef.current.updateProjectionMatrix();
      }
      if (weaponContainerRef.current) {
        weaponContainerRef.current.visible = true;
      }
    }

    setPlayerState((prev) => {
      if (prev.activeSlot === slot) return prev;
      sounds.switchWeapon();
      const nextWepId = prev.equippedSlots[slot];
      switchWeapon3DModel(nextWepId);

      const ammo = sessionRef.current.weaponAmmo[nextWepId] || 0;
      const reserve = sessionRef.current.weaponReserve[nextWepId] || 0;
      setCurrentAmmo(ammo);
      setReserveAmmo(reserve);

      return { ...prev, activeSlot: slot };
    });
  }, [switchWeapon3DModel]);

  // Zombie HP Sprite Helper
  const createZombieHpSprite = () => {
    const canvas = document.createElement('canvas');
    canvas.width = 128;
    canvas.height = 20;
    const ctx = canvas.getContext('2d')!;
    const texture = new THREE.CanvasTexture(canvas);
    const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: texture, depthTest: false }));
    sprite.scale.set(1.4, 0.22, 1);
    return { sprite, canvas, ctx, texture };
  };

  const updateZombieHpBar = (z: ZombieEntity) => {
    const { ctx, canvas, texture } = z.hpSpriteObj;
    const pct = Math.max(0, z.hp / z.maxHp);

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = 'rgba(0, 0, 0, 0.85)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = z.type === 'BOSS' ? '#ff0055' : pct > 0.5 ? '#00ff66' : '#ff3300';
    ctx.fillRect(2, 2, Math.floor((canvas.width - 4) * pct), canvas.height - 4);
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 2;
    ctx.strokeRect(1, 1, canvas.width - 2, canvas.height - 2);

    texture.needsUpdate = true;
  };

  // Zombie Mesh Generator
  const createZombieMesh = (type: string) => {
    const group = new THREE.Group();
    let skinColor = 0x2e7d32;
    let clothesColor = 0x3e2723;
    let scale = 1.0;

    if (type === 'RUNNER') {
      skinColor = 0xc62828;
      clothesColor = 0x212121;
    } else if (type === 'SPITTER') {
      skinColor = 0x6a1b9a;
      clothesColor = 0x37474f;
    } else if (type === 'CYBER') {
      skinColor = 0x00838f;
      clothesColor = 0x263238;
    } else if (type === 'FLAME') {
      skinColor = 0xef6c00;
      clothesColor = 0x424242;
    } else if (type === 'GHOST') {
      skinColor = 0x90a4ae;
      clothesColor = 0x1e293b;
      scale = 0.9;
    } else if (type === 'BOSS') {
      skinColor = 0x880e4f;
      clothesColor = 0x0d1117;
      scale = 2.5;
    }

    const bodyMat = new THREE.MeshStandardMaterial({ color: clothesColor, roughness: 0.8 });
    const skinMat = new THREE.MeshStandardMaterial({ color: skinColor, roughness: 0.5 });
    const eyeMat = new THREE.MeshBasicMaterial({ color: type === 'CYBER' ? 0x00f0ff : 0xff0033 });

    // Torso
    const body = new THREE.Mesh(new THREE.BoxGeometry(0.55 * scale, 0.95 * scale, 0.35 * scale), bodyMat);
    body.position.y = 0.95 * scale;
    body.castShadow = true;
    group.add(body);

    // Head
    const head = new THREE.Mesh(new THREE.BoxGeometry(0.42 * scale, 0.42 * scale, 0.42 * scale), skinMat);
    head.position.y = 1.6 * scale;
    head.castShadow = true;
    group.add(head);

    // Glowing Eyes
    const eye1 = new THREE.Mesh(new THREE.BoxGeometry(0.08 * scale, 0.06 * scale, 0.05 * scale), eyeMat);
    eye1.position.set(-0.1 * scale, 1.65 * scale, -0.21 * scale);
    const eye2 = eye1.clone();
    eye2.position.x = 0.1 * scale;
    group.add(eye1);
    group.add(eye2);

    // Outstretched Arms
    const leftArm = new THREE.Mesh(new THREE.BoxGeometry(0.14 * scale, 0.14 * scale, 0.7 * scale), skinMat);
    leftArm.position.set(-0.35 * scale, 1.2 * scale, -0.35 * scale);
    leftArm.rotation.x = -0.2;
    group.add(leftArm);

    const rightArm = leftArm.clone();
    rightArm.position.x = 0.35 * scale;
    group.add(rightArm);

    // Legs
    const legMat = new THREE.MeshStandardMaterial({ color: 0x1a237e });
    const leftLeg = new THREE.Mesh(new THREE.BoxGeometry(0.18 * scale, 0.75 * scale, 0.2 * scale), legMat);
    leftLeg.position.set(-0.15 * scale, 0.38 * scale, 0);
    group.add(leftLeg);

    const rightLeg = leftLeg.clone();
    rightLeg.position.x = 0.15 * scale;
    group.add(rightLeg);

    // Sprite HP bar
    const hpSpriteObj = createZombieHpSprite();
    hpSpriteObj.sprite.position.y = 2.0 * scale + 0.35;
    group.add(hpSpriteObj.sprite);

    return { group, hpSpriteObj, leftLeg, rightLeg };
  };

  // Spawn Zombies for Stage
  const spawnStageZombies = useCallback((stage: number) => {
    if (!sceneRef.current) return;

    // Clean existing zombies
    zombiesRef.current.forEach((z) => sceneRef.current?.remove(z.mesh));
    zombiesRef.current = [];
    bossEntityRef.current = null;
    setBossHp(null);
    setMaxBossHp(null);

    const isBossStage = stage % 5 === 0;
    const totalCount = isBossStage ? 8 + stage * 2 : 6 + stage * 3;

    setZombiesTotal(totalCount);
    setZombiesLeft(totalCount);

    // Spawn Boss on boss stages
    if (isBossStage) {
      const bossHpValue = 1200 + stage * 550;
      const { group, hpSpriteObj, leftLeg, rightLeg } = createZombieMesh('BOSS');
      group.position.set(0, 0, -42);
      sceneRef.current.add(group);

      const bossEntity: ZombieEntity = {
        mesh: group,
        hpSpriteObj,
        leftLeg,
        rightLeg,
        type: 'BOSS',
        hp: bossHpValue,
        maxHp: bossHpValue,
        speed: 0.05 + stage * 0.004,
        damage: 35 + stage * 3,
        walkAnimTime: 0
      };

      bossEntityRef.current = bossEntity;
      zombiesRef.current.push(bossEntity);
      updateZombieHpBar(bossEntity);
      setBossHp(bossHpValue);
      setMaxBossHp(bossHpValue);
    }

    const standardCount = isBossStage ? totalCount - 1 : totalCount;

    for (let i = 0; i < standardCount; i++) {
      const angle = Math.random() * Math.PI * 2;
      const dist = 16 + Math.random() * 45;
      const x = Math.cos(angle) * dist;
      const z = Math.sin(angle) * dist;

      let type = 'NORMAL';
      const rand = Math.random();
      if (stage >= 2 && rand < 0.25) type = 'RUNNER';
      else if (stage >= 3 && rand < 0.45) type = 'SPITTER';
      else if (stage >= 6 && rand < 0.65) type = 'CYBER';
      else if (stage >= 8 && rand < 0.8) type = 'FLAME';
      else if (stage >= 11 && rand < 0.92) type = 'GHOST';

      let hp = 75 + stage * 32;
      let speed = 0.045 + Math.random() * 0.02;
      let damage = 12 + stage * 2;

      if (type === 'RUNNER') {
        speed *= 1.65;
        hp *= 0.7;
      }
      if (type === 'CYBER') {
        hp *= 1.4;
        damage *= 1.3;
      }
      if (type === 'FLAME') {
        damage *= 1.5;
        hp *= 1.2;
      }

      const { group, hpSpriteObj, leftLeg, rightLeg } = createZombieMesh(type);
      group.position.set(x, 0, z);
      sceneRef.current.add(group);

      const zombieData: ZombieEntity = {
        mesh: group,
        hpSpriteObj,
        leftLeg,
        rightLeg,
        type,
        hp,
        maxHp: hp,
        speed,
        damage,
        walkAnimTime: Math.random() * 10
      };

      zombiesRef.current.push(zombieData);
      updateZombieHpBar(zombieData);
    }
  }, []);

  // Blood FX
  const createBloodFX = (pos: THREE.Vector3) => {
    if (!sceneRef.current) return;
    for (let i = 0; i < 8; i++) {
      const p = new THREE.Mesh(
        new THREE.SphereGeometry(0.04, 4, 4),
        new THREE.MeshBasicMaterial({ color: 0xcc0000 })
      );
      p.position.copy(pos);
      const velocity = new THREE.Vector3(
        (Math.random() - 0.5) * 0.12,
        Math.random() * 0.1,
        (Math.random() - 0.5) * 0.12
      );
      sceneRef.current.add(p);
      particlesRef.current.push({ mesh: p, velocity, life: 0.3 });
    }
  };

  // Custom Impact Visual FX for Signature Weapons
  const createImpactFX = (pos: THREE.Vector3, type: WeaponData['impactType']) => {
    if (!sceneRef.current) return;

    if (type === 'VULCAN') {
      // High-heat explosive fireball shockwave
      for (let i = 0; i < 14; i++) {
        const p = new THREE.Mesh(
          new THREE.SphereGeometry(0.08, 4, 4),
          new THREE.MeshBasicMaterial({ color: i % 2 === 0 ? 0xff4500 : 0xffaa00 })
        );
        p.position.copy(pos);
        const velocity = new THREE.Vector3(
          (Math.random() - 0.5) * 0.22,
          Math.random() * 0.18,
          (Math.random() - 0.5) * 0.22
        );
        sceneRef.current.add(p);
        particlesRef.current.push({ mesh: p, velocity, life: 0.45 });
      }
    } else if (type === 'RAILGUN') {
      // Supercharged electric plasma burst
      for (let i = 0; i < 18; i++) {
        const p = new THREE.Mesh(
          new THREE.BoxGeometry(0.04, 0.04, 0.25),
          new THREE.MeshBasicMaterial({ color: i % 2 === 0 ? 0x00f0ff : 0xffffff })
        );
        p.position.copy(pos);
        p.rotation.set(Math.random() * Math.PI, Math.random() * Math.PI, Math.random() * Math.PI);
        const velocity = new THREE.Vector3(
          (Math.random() - 0.5) * 0.28,
          (Math.random() - 0.5) * 0.28,
          (Math.random() - 0.5) * 0.28
        );
        sceneRef.current.add(p);
        particlesRef.current.push({ mesh: p, velocity, life: 0.5 });
      }
    } else if (type === 'BIO') {
      // Toxic corrosive acid splash
      for (let i = 0; i < 16; i++) {
        const p = new THREE.Mesh(
          new THREE.SphereGeometry(0.07, 6, 6),
          new THREE.MeshStandardMaterial({
            color: 0x10b981,
            emissive: 0x34d399,
            emissiveIntensity: 0.8
          })
        );
        p.position.copy(pos);
        const velocity = new THREE.Vector3(
          (Math.random() - 0.5) * 0.16,
          Math.random() * 0.14,
          (Math.random() - 0.5) * 0.16
        );
        sceneRef.current.add(p);
        particlesRef.current.push({ mesh: p, velocity, life: 0.6 });
      }
    } else if (type === 'BLOOD') {
      // 360-degree crimson demonic scythe wave
      for (let i = 0; i < 24; i++) {
        const angle = (i / 24) * Math.PI * 2;
        const p = new THREE.Mesh(
          new THREE.BoxGeometry(0.08, 0.05, 0.18),
          new THREE.MeshBasicMaterial({ color: 0xef4444 })
        );
        p.position.set(pos.x, pos.y + 0.3, pos.z);
        p.rotation.y = angle;
        const speed = 0.24;
        const velocity = new THREE.Vector3(Math.cos(angle) * speed, 0.02, Math.sin(angle) * speed);
        sceneRef.current.add(p);
        particlesRef.current.push({ mesh: p, velocity, life: 0.4 });
      }
    } else if (type === 'TITAN') {
      // Ground-shattering seismic kinetic shockwave
      for (let i = 0; i < 22; i++) {
        const angle = (i / 22) * Math.PI * 2;
        const p = new THREE.Mesh(
          new THREE.BoxGeometry(0.12, 0.16, 0.12),
          new THREE.MeshStandardMaterial({ color: i % 2 === 0 ? 0xfacc15 : 0x71717a })
        );
        p.position.set(pos.x, 0.1, pos.z);
        const speed = 0.22;
        const velocity = new THREE.Vector3(
          Math.cos(angle) * speed,
          0.12 + Math.random() * 0.1,
          Math.sin(angle) * speed
        );
        sceneRef.current.add(p);
        particlesRef.current.push({ mesh: p, velocity, life: 0.55 });
      }
    } else if (type === 'AXE') {
      // High-heat blue plasma explosion with shrapnel burst
      for (let i = 0; i < 18; i++) {
        const p = new THREE.Mesh(
          new THREE.SphereGeometry(0.08, 4, 4),
          new THREE.MeshBasicMaterial({ color: i % 2 === 0 ? 0x00f0ff : 0x38bdf8 })
        );
        p.position.copy(pos);
        const velocity = new THREE.Vector3(
          (Math.random() - 0.5) * 0.28,
          Math.random() * 0.22,
          (Math.random() - 0.5) * 0.28
        );
        sceneRef.current.add(p);
        particlesRef.current.push({ mesh: p, velocity, life: 0.45 });
      }
    } else if (type === 'SPEAR') {
      // Massive cypher shockwave explosion with yellow & orange sparks
      for (let i = 0; i < 28; i++) {
        const p = new THREE.Mesh(
          new THREE.BoxGeometry(0.09, 0.09, 0.09),
          new THREE.MeshBasicMaterial({ color: i % 3 === 0 ? 0xfacc15 : i % 3 === 1 ? 0xf97316 : 0xffffff })
        );
        p.position.copy(pos);
        const velocity = new THREE.Vector3(
          (Math.random() - 0.5) * 0.35,
          Math.random() * 0.28,
          (Math.random() - 0.5) * 0.35
        );
        sceneRef.current.add(p);
        particlesRef.current.push({ mesh: p, velocity, life: 0.6 });
      }
    }
  };

  // Reload Current Weapon
  const reloadWeapon = useCallback(() => {
    if (sessionRef.current.isReloading) return;
    const activeWepKey = playerState.equippedSlots[playerState.activeSlot];
    const w = weapons[activeWepKey];

    if (w.isMelee || w.isThrowable) return;
    if (sessionRef.current.weaponAmmo[activeWepKey] === w.magSize) return;
    if (sessionRef.current.weaponReserve[activeWepKey] <= 0) return;

    sessionRef.current.isReloading = true;
    setIsReloading(true);
    sounds.reload();

    setTimeout(() => {
      const needed = w.magSize - sessionRef.current.weaponAmmo[activeWepKey];
      const transfer = Math.min(needed, sessionRef.current.weaponReserve[activeWepKey]);
      sessionRef.current.weaponAmmo[activeWepKey] += transfer;
      sessionRef.current.weaponReserve[activeWepKey] -= transfer;

      sessionRef.current.isReloading = false;
      setIsReloading(false);
      setCurrentAmmo(sessionRef.current.weaponAmmo[activeWepKey]);
      setReserveAmmo(sessionRef.current.weaponReserve[activeWepKey]);
    }, w.reloadTime * 1000);
  }, [playerState.equippedSlots, playerState.activeSlot, weapons]);

  // Attack Trigger
  const triggerAttack = useCallback(() => {
    if (sessionRef.current.isReloading || !sessionRef.current.isPlaying) return;

    const now = performance.now() / 1000;
    const activeWepKey = playerState.equippedSlots[playerState.activeSlot];
    const w = weapons[activeWepKey];

    if (now - lastShootTimeRef.current < w.fireRate) return;

    // 1. Melee attack
    if (w.isMelee) {
      lastShootTimeRef.current = now;

      if (w.id === 'BLOOD_SCYTHE') sounds.slashBloodScythe();
      else if (w.id === 'TITAN_HAMMER') sounds.smashTitanHammer();
      else sounds.slashKatana();

      if (currentWeaponModelRef.current) {
        currentWeaponModelRef.current.rotation.z = -Math.PI / 2.5;
        setTimeout(() => {
          if (currentWeaponModelRef.current) currentWeaponModelRef.current.rotation.z = 0;
        }, 150);
      }

      const job = classes[playerState.currentJobKey];
      const meleeMult = job && job.meleeMultiplier ? job.meleeMultiplier : 1.0;
      const berserkMult = berserkBuffTimerRef.current > 0 ? 2.0 : 1.0;
      const finalDmg = w.damage * (job ? job.dmgMultiplier : 1.0) * meleeMult * berserkMult;

      if (cameraRef.current) {
        const camPos = cameraRef.current.position;
        // Blood Scythe has huge sweep range (6.0), Titan Hammer has wide shockwave (5.5), Katana has standard (4.2)
        const hitRange = w.id === 'BLOOD_SCYTHE' ? 6.0 : w.id === 'TITAN_HAMMER' ? 5.5 : 4.2;

        if (w.impactType) {
          createImpactFX(camPos, w.impactType);
        }

        for (let i = zombiesRef.current.length - 1; i >= 0; i--) {
          const z = zombiesRef.current[i];
          const dist = camPos.distanceTo(z.mesh.position);
          if (dist < hitRange) {
            z.hp -= finalDmg;
            sounds.zombieHit();
            updateZombieHpBar(z);
            createBloodFX(z.mesh.position);

            if (w.impactType) {
              createImpactFX(z.mesh.position, w.impactType);
            }

            // Titan Hammer knocks back zombies!
            if (w.id === 'TITAN_HAMMER') {
              const knockDir = z.mesh.position.clone().sub(camPos).normalize();
              z.mesh.position.add(knockDir.multiplyScalar(2.0));
            }

            if (z.hp <= 0) {
              sceneRef.current?.remove(z.mesh);
              zombiesRef.current.splice(i, 1);
              sessionRef.current.killsThisRun++;
              const earned = 25 + Math.floor(Math.random() * 20);
              sessionRef.current.goldEarnedThisRun += earned;
              setPlayerState((p) => ({ ...p, gold: p.gold + earned }));
              setZombiesLeft(zombiesRef.current.length);

              if (zombiesRef.current.length === 0) {
                stageClearVictory();
              }
            }
          }
        }
      }
      return;
    }

    // 2. Throwable Weapons (수류탄 및 투척 근접무기 토마호크, 투척창)
    if (w.isThrowable) {
      const currentReserve = sessionRef.current.weaponReserve[activeWepKey] || 0;
      if (currentReserve <= 0) return;

      lastShootTimeRef.current = now;
      sessionRef.current.weaponReserve[activeWepKey]--;
      setReserveAmmo(sessionRef.current.weaponReserve[activeWepKey]);

      const job = classes[playerState.currentJobKey];
      const berserkMult = berserkBuffTimerRef.current > 0 ? 2.0 : 1.0;
      const finalDmg = w.damage * (job ? job.dmgMultiplier : 1.0) * berserkMult;

      if (cameraRef.current && sceneRef.current) {
        const throwDir = new THREE.Vector3();
        cameraRef.current.getWorldDirection(throwDir);

        if (w.id === 'THROWING_AXE') {
          sounds.throwAxe();
          // Axe model for throwing projectile
          const axeProj = new THREE.Group();
          const axeHandle = new THREE.Mesh(
            new THREE.CylinderGeometry(0.02, 0.02, 0.45, 8),
            new THREE.MeshStandardMaterial({ color: 0x1f2937 })
          );
          axeProj.add(axeHandle);
          const axeHead = new THREE.Mesh(
            new THREE.BoxGeometry(0.03, 0.18, 0.14),
            new THREE.MeshStandardMaterial({ color: 0x0284c7, emissive: 0x38bdf8, emissiveIntensity: 0.8 })
          );
          axeHead.position.set(0, 0.14, 0.05);
          axeProj.add(axeHead);
          axeProj.position.copy(cameraRef.current.position);

          const velocity = throwDir.multiplyScalar(0.65);
          velocity.y += 0.08;

          sceneRef.current.add(axeProj);
          grenadesRef.current.push({
            mesh: axeProj,
            velocity,
            timer: 0.9,
            damage: finalDmg,
            type: 'AXE',
            radius: 5.5,
            rotSpeed: { x: 0.35, y: 0.1, z: 0.2 }
          });
        } else if (w.id === 'EXPLOSIVE_SPEAR') {
          sounds.throwSpear();
          // Spear projectile
          const spearProj = new THREE.Group();
          const shaft = new THREE.Mesh(
            new THREE.CylinderGeometry(0.015, 0.015, 1.0, 8),
            new THREE.MeshStandardMaterial({ color: 0x0f172a, metalness: 0.8 })
          );
          shaft.rotation.x = Math.PI / 2;
          spearProj.add(shaft);
          const tip = new THREE.Mesh(
            new THREE.ConeGeometry(0.045, 0.24, 4),
            new THREE.MeshStandardMaterial({ color: 0xd97706, emissive: 0xf59e0b, emissiveIntensity: 0.8 })
          );
          tip.rotation.x = -Math.PI / 2;
          tip.position.z = -0.6;
          spearProj.add(tip);
          spearProj.position.copy(cameraRef.current.position);
          spearProj.quaternion.copy(cameraRef.current.quaternion);

          const velocity = throwDir.multiplyScalar(0.85);
          velocity.y += 0.04;

          sceneRef.current.add(spearProj);
          grenadesRef.current.push({
            mesh: spearProj,
            velocity,
            timer: 0.8,
            damage: finalDmg,
            type: 'SPEAR',
            radius: 7.5
          });
        } else {
          // Standard GRENADE
          sounds.init();
          const nadeMesh = new THREE.Mesh(
            new THREE.SphereGeometry(0.12, 8, 8),
            new THREE.MeshStandardMaterial({ color: 0x3d4f27, roughness: 0.6 })
          );
          nadeMesh.position.copy(cameraRef.current.position);

          const velocity = throwDir.multiplyScalar(0.48);
          velocity.y += 0.16;

          sceneRef.current.add(nadeMesh);
          grenadesRef.current.push({
            mesh: nadeMesh,
            velocity,
            timer: 1.2,
            damage: finalDmg,
            type: 'GRENADE',
            radius: 7.0,
            rotSpeed: { x: 0.1, y: 0.15, z: 0.05 }
          });
        }
      }
      return;
    }

    // 3. Firearms
    if (sessionRef.current.weaponAmmo[activeWepKey] <= 0) {
      reloadWeapon();
      return;
    }

    lastShootTimeRef.current = now;
    sessionRef.current.weaponAmmo[activeWepKey]--;
    setCurrentAmmo(sessionRef.current.weaponAmmo[activeWepKey]);

    // Recoil and flash
    if (muzzleFlashLightRef.current) {
      muzzleFlashLightRef.current.intensity = w.id === 'RAILGUN' ? 6.0 : 3.5;
      if (w.id === 'RAILGUN') {
        muzzleFlashLightRef.current.color.setHex(0x00f0ff);
      } else if (w.id === 'BIO_LAUNCHER') {
        muzzleFlashLightRef.current.color.setHex(0x10b981);
      } else {
        muzzleFlashLightRef.current.color.setHex(0xffcc00);
      }
      setTimeout(() => {
        if (muzzleFlashLightRef.current) muzzleFlashLightRef.current.intensity = 0;
      }, 60);
    }

    if (weaponContainerRef.current) {
      weaponContainerRef.current.position.z = w.id === 'RAILGUN' ? -0.26 : -0.32;
      setTimeout(() => {
        if (weaponContainerRef.current) weaponContainerRef.current.position.z = -0.42;
      }, 90);
    }

    // Minigun & Commando Vulcan barrel rotation
    if ((w.id === 'MINIGUN' || w.id === 'COMMANDO_VULCAN') && minigunBarrelsRef.current) {
      minigunBarrelsRef.current.forEach((b) => {
        b.rotation.z += 0.5;
      });
    }

    // Play Sound
    if (w.id === 'SHOTGUN') sounds.shootShotgun();
    else if (w.id === 'SNIPER') sounds.shootSniper();
    else if (w.id === 'MINIGUN') sounds.shootMinigun();
    else if (w.id === 'PISTOL') sounds.shootPistol();
    else if (w.id === 'SMG') sounds.shootSMG();
    else if (w.id === 'COMMANDO_VULCAN') sounds.shootVulcan();
    else if (w.id === 'RAILGUN') sounds.shootRailgun();
    else if (w.id === 'BIO_LAUNCHER') sounds.shootBioLauncher();
    else sounds.shootRifle();

    // Raycast Shot
    if (cameraRef.current) {
      const raycaster = new THREE.Raycaster();
      raycaster.setFromCamera(new THREE.Vector2(0, 0), cameraRef.current);

      const job = classes[playerState.currentJobKey];
      const berserkActive = berserkBuffTimerRef.current > 0;
      const effectiveCrit = playerState.critChance + (berserkActive ? 0.35 : 0);
      const isCrit = Math.random() < effectiveCrit;
      const berserkDmgMult = berserkActive ? 2.0 : 1.0;
      const finalDmg = w.damage * (job ? job.dmgMultiplier : 1.0) * (isCrit ? 1.8 : 1.0) * berserkDmgMult;

      // Special handling: RAILGUN penetrates through multiple zombies!
      if (w.id === 'RAILGUN') {
        let hitCount = 0;
        for (let i = zombiesRef.current.length - 1; i >= 0; i--) {
          const z = zombiesRef.current[i];
          const intersects = raycaster.intersectObject(z.mesh, true);

          if (intersects.length > 0) {
            hitCount++;
            z.hp -= finalDmg;
            sounds.zombieHit();
            updateZombieHpBar(z);
            createImpactFX(intersects[0].point, 'RAILGUN');

            if (z.type === 'BOSS') {
              setBossHp(Math.max(0, z.hp));
            }

            if (z.hp <= 0) {
              sceneRef.current?.remove(z.mesh);
              zombiesRef.current.splice(i, 1);
              sessionRef.current.killsThisRun++;
              const earned = 30 + Math.floor(Math.random() * 25);
              sessionRef.current.goldEarnedThisRun += earned;
              setPlayerState((p) => ({ ...p, gold: p.gold + earned }));
              setZombiesLeft(zombiesRef.current.length);

              if (z.type === 'BOSS') {
                setBossHp(0);
              }

              if (zombiesRef.current.length === 0) {
                stageClearVictory();
              }
            }
          }
        }
        // Crosshair hit tick for Railgun
        if (hitCount > 0) {
          const crosshairEl = document.getElementById('crosshair');
          if (crosshairEl) {
            crosshairEl.classList.add('crosshair-active');
            setTimeout(() => crosshairEl.classList.remove('crosshair-active'), 140);
          }
        }
        return;
      }

      // Standard and Area-of-Effect raycast (Vulcan & Bio Launcher have splash impact!)
      for (let i = zombiesRef.current.length - 1; i >= 0; i--) {
        const z = zombiesRef.current[i];
        const intersects = raycaster.intersectObject(z.mesh, true);

        if (intersects.length > 0) {
          const hitPos = intersects[0].point;
          z.hp -= finalDmg;
          sounds.zombieHit();
          updateZombieHpBar(z);
          createBloodFX(hitPos);

          if (w.impactType) {
            createImpactFX(hitPos, w.impactType);
          }

          // Splash damage for Commando Vulcan (fire blast) and Bio Launcher (corrosive splash)
          if (w.impactType === 'VULCAN' || w.impactType === 'BIO') {
            const splashRadius = w.impactType === 'VULCAN' ? 3.5 : 4.5;
            const splashDmg = finalDmg * 0.45;
            zombiesRef.current.forEach((otherZ) => {
              if (otherZ !== z && otherZ.mesh.position.distanceTo(hitPos) < splashRadius) {
                otherZ.hp -= splashDmg;
                updateZombieHpBar(otherZ);
              }
            });
          }

          if (z.type === 'BOSS') {
            setBossHp(Math.max(0, z.hp));
          }

          // Crosshair hit tick
          const crosshairEl = document.getElementById('crosshair');
          if (crosshairEl) {
            crosshairEl.classList.add('crosshair-active');
            setTimeout(() => crosshairEl.classList.remove('crosshair-active'), 120);
          }

          if (z.hp <= 0) {
            sceneRef.current?.remove(z.mesh);
            zombiesRef.current.splice(i, 1);
            sessionRef.current.killsThisRun++;
            const earned = 25 + Math.floor(Math.random() * 20);
            sessionRef.current.goldEarnedThisRun += earned;
            setPlayerState((p) => ({ ...p, gold: p.gold + earned }));
            setZombiesLeft(zombiesRef.current.length);

            if (z.type === 'BOSS') {
              setBossHp(0);
            }

            if (zombiesRef.current.length === 0) {
              stageClearVictory();
            }
          }
          break;
        }
      }
    }
  }, [playerState.equippedSlots, playerState.activeSlot, weapons, classes, playerState.currentJobKey, playerState.critChance, reloadWeapon]);

  // Stage clear
  const stageClearVictory = () => {
    sessionRef.current.isPlaying = false;
    if (document.pointerLockElement) document.exitPointerLock();

    if (isZoomedRef.current) {
      isZoomedRef.current = false;
      setIsZoomed(false);
      if (cameraRef.current) {
        cameraRef.current.fov = 75;
        cameraRef.current.updateProjectionMatrix();
      }
      if (weaponContainerRef.current) {
        weaponContainerRef.current.visible = true;
      }
    }

    setLastKills(sessionRef.current.killsThisRun);
    setLastEarnedGold(sessionRef.current.goldEarnedThisRun);

    setPlayerState((prev) => {
      const nextUnlocked = prev.selectedStage === prev.unlockedStage && prev.unlockedStage < 40
        ? prev.unlockedStage + 1
        : prev.unlockedStage;
      return { ...prev, unlockedStage: nextUnlocked };
    });

    setTimeout(() => {
      setGameState('VICTORY');
    }, 600);
  };

  // Player Death
  const playerDeath = () => {
    sessionRef.current.isPlaying = false;
    if (document.pointerLockElement) document.exitPointerLock();

    if (isZoomedRef.current) {
      isZoomedRef.current = false;
      setIsZoomed(false);
      if (cameraRef.current) {
        cameraRef.current.fov = 75;
        cameraRef.current.updateProjectionMatrix();
      }
      if (weaponContainerRef.current) {
        weaponContainerRef.current.visible = true;
      }
    }

    setLastKills(sessionRef.current.killsThisRun);
    setLastEarnedGold(sessionRef.current.goldEarnedThisRun);
    setGameState('DEATH');
  };

  // Damage Player
  const damagePlayer = (amount: number) => {
    setDamageFlash(true);
    setTimeout(() => setDamageFlash(false), 150);

    if (sessionRef.current.shield > 0) {
      if (sessionRef.current.shield >= amount) {
        sessionRef.current.shield -= amount;
      } else {
        sessionRef.current.hp -= (amount - sessionRef.current.shield);
        sessionRef.current.shield = 0;
      }
    } else {
      sessionRef.current.hp -= amount;
    }

    if (sessionRef.current.hp <= 0) {
      sessionRef.current.hp = 0;
      playerDeath();
    }

    setHudHp(sessionRef.current.hp);
    setHudShield(sessionRef.current.shield);
  };

  // Use Potions
  const handleUseHpPotion = () => {
    if (!sessionRef.current.isPlaying) return;
    const maxHp = getMaxHp();
    if (playerState.hpPotions > 0 && sessionRef.current.hp < maxHp) {
      setPlayerState((prev) => ({ ...prev, hpPotions: prev.hpPotions - 1 }));
      const healAmt = playerState.currentJobKey === 'MEDIC' ? 100 : 50;
      sessionRef.current.hp = Math.min(maxHp, sessionRef.current.hp + healAmt);
      setHudHp(sessionRef.current.hp);
      sounds.potionDrink();
      setHealFlash(true);
      setTimeout(() => setHealFlash(false), 300);
    }
  };

  const handleUseShieldPotion = () => {
    if (!sessionRef.current.isPlaying) return;
    const maxShield = getMaxShield();
    if (playerState.shieldPotions > 0 && sessionRef.current.shield < maxShield) {
      setPlayerState((prev) => ({ ...prev, shieldPotions: prev.shieldPotions - 1 }));
      const shieldAmt = playerState.currentJobKey === 'MEDIC' ? 80 : 40;
      sessionRef.current.shield = Math.min(maxShield, sessionRef.current.shield + shieldAmt);
      setHudShield(sessionRef.current.shield);
      sounds.potionDrink();
      setShieldFlash(true);
      setTimeout(() => setShieldFlash(false), 300);
    }
  };

  const handleUseSpeedPotion = () => {
    if (!sessionRef.current.isPlaying) return;
    if (playerState.speedPotions > 0) {
      setPlayerState((prev) => ({ ...prev, speedPotions: prev.speedPotions - 1 }));
      speedBuffTimerRef.current = 15; // 15 seconds buff
      setSpeedBuffTimer(15);
      sounds.potionBuff();
      setSpeedFlash(true);
      setTimeout(() => setSpeedFlash(false), 350);
    }
  };

  const handleUseBerserkPotion = () => {
    if (!sessionRef.current.isPlaying) return;
    if (playerState.berserkPotions > 0) {
      setPlayerState((prev) => ({ ...prev, berserkPotions: prev.berserkPotions - 1 }));
      berserkBuffTimerRef.current = 12; // 12 seconds 2x damage & +35% crit
      setBerserkBuffTimer(12);
      sounds.potionBuff();
      setBerserkFlash(true);
      setTimeout(() => setBerserkFlash(false), 350);
    }
  };

  const handleUseFullRestorePotion = () => {
    if (!sessionRef.current.isPlaying) return;
    const maxHp = getMaxHp();
    const maxShield = getMaxShield();
    if (playerState.fullRestorePotions > 0 && (sessionRef.current.hp < maxHp || sessionRef.current.shield < maxShield)) {
      setPlayerState((prev) => ({ ...prev, fullRestorePotions: prev.fullRestorePotions - 1 }));
      sessionRef.current.hp = maxHp;
      sessionRef.current.shield = maxShield;
      setHudHp(maxHp);
      setHudShield(maxShield);
      sounds.potionFullRestore();
      setFullRestoreFlash(true);
      setTimeout(() => setFullRestoreFlash(false), 450);
    }
  };

  // Setup 3D Environment (Streets, Neon Buildings, Lights)
  useEffect(() => {
    if (!canvasRef.current) return;

    const width = window.innerWidth;
    const height = window.innerHeight;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0f172a);
    scene.fog = new THREE.FogExp2(0x0f172a, 0.018);
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(75, width / height, 0.1, 1000);
    camera.rotation.order = 'YXZ';
    camera.position.set(0, 1.7, 0);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({ canvas: canvasRef.current, antialias: true });
    renderer.setSize(width, height);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    rendererRef.current = renderer;

    // Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    scene.add(ambientLight);

    const sunLight = new THREE.DirectionalLight(0xffeedd, 1.2);
    sunLight.position.set(30, 70, 20);
    sunLight.castShadow = true;
    scene.add(sunLight);

    // City Street & Buildings
    const streetWidth = 24;
    const mapLength = 170;

    const roadGeo = new THREE.PlaneGeometry(streetWidth, mapLength);
    const roadMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.8 });
    const road = new THREE.Mesh(roadGeo, roadMat);
    road.rotation.x = -Math.PI / 2;
    road.receiveShadow = true;
    scene.add(road);

    // Sidewalks
    const sideGeo = new THREE.PlaneGeometry(14, mapLength);
    const sideMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.6 });
    const leftWalk = new THREE.Mesh(sideGeo, sideMat);
    leftWalk.rotation.x = -Math.PI / 2;
    leftWalk.position.set(-(streetWidth / 2 + 7), 0.05, 0);
    scene.add(leftWalk);

    const rightWalk = leftWalk.clone();
    rightWalk.position.x = streetWidth / 2 + 7;
    scene.add(rightWalk);

    // Road Stripes
    for (let z = -mapLength / 2 + 4; z < mapLength / 2; z += 8) {
      const stripe = new THREE.Mesh(
        new THREE.PlaneGeometry(0.5, 4),
        new THREE.MeshBasicMaterial({ color: 0xfacc15 })
      );
      stripe.rotation.x = -Math.PI / 2;
      stripe.position.set(0, 0.06, z);
      scene.add(stripe);
    }

    // Cyber Buildings
    const buildingColors = [0x1e293b, 0x0f172a, 0x334155, 0x1e1b4b, 0x0369a1];
    for (let z = -mapLength / 2 + 10; z < mapLength / 2 - 10; z += 18) {
      const h1 = 15 + Math.random() * 26;
      const b1 = new THREE.Mesh(
        new THREE.BoxGeometry(16, h1, 14),
        new THREE.MeshStandardMaterial({ color: buildingColors[Math.floor(Math.random() * buildingColors.length)] })
      );
      b1.position.set(-(streetWidth / 2 + 16), h1 / 2, z);
      scene.add(b1);

      const h2 = 15 + Math.random() * 26;
      const b2 = new THREE.Mesh(
        new THREE.BoxGeometry(16, h2, 14),
        new THREE.MeshStandardMaterial({ color: buildingColors[Math.floor(Math.random() * buildingColors.length)] })
      );
      b2.position.set(streetWidth / 2 + 16, h2 / 2, z);
      scene.add(b2);
    }

    // 1st-Person Weapon Group attached to Camera
    const weaponContainer = new THREE.Group();
    weaponContainer.position.set(0.24, -0.22, -0.42);
    camera.add(weaponContainer);
    weaponContainerRef.current = weaponContainer;

    const muzzleLight = new THREE.PointLight(0xffcc00, 0, 6);
    muzzleLight.position.set(0, 0, -0.6);
    weaponContainer.add(muzzleLight);
    muzzleFlashLightRef.current = muzzleLight;

    scene.add(camera);

    // Initial 3D weapon model
    switchWeapon3DModel(playerState.equippedSlots[playerState.activeSlot]);

    // Handle Resize
    const handleResize = () => {
      if (!cameraRef.current || !rendererRef.current) return;
      cameraRef.current.aspect = window.innerWidth / window.innerHeight;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(window.innerWidth, window.innerHeight);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, [switchWeapon3DModel]);

  // Main 60 FPS Game Loop
  useEffect(() => {
    let animId: number;

    const updateGame = () => {
      if (sessionRef.current.isPlaying && cameraRef.current) {
        // Decrement Buff Timers
        if (speedBuffTimerRef.current > 0) {
          speedBuffTimerRef.current = Math.max(0, speedBuffTimerRef.current - 0.016);
          setSpeedBuffTimer(speedBuffTimerRef.current);
        }
        if (berserkBuffTimerRef.current > 0) {
          berserkBuffTimerRef.current = Math.max(0, berserkBuffTimerRef.current - 0.016);
          setBerserkBuffTimer(berserkBuffTimerRef.current);
        }

        const job = classes[playerState.currentJobKey];
        const jobSpeed = job ? job.speedBonus : 0;
        const speedBuffMult = speedBuffTimerRef.current > 0 ? 1.75 : 1.0;
        const moveSpeed = (playerState.baseSpeed + jobSpeed) * (keysRef.current.shift ? 1.55 : 1.0) * speedBuffMult;

        const dir = new THREE.Vector3();
        if (keysRef.current.w) dir.z -= 1;
        if (keysRef.current.s) dir.z += 1;
        if (keysRef.current.a) dir.x -= 1;
        if (keysRef.current.d) dir.x += 1;

        if (dir.lengthSq() > 0) {
          dir.normalize();
          dir.applyQuaternion(cameraRef.current.quaternion);
          dir.y = 0;
          cameraRef.current.position.addScaledVector(dir, moveSpeed);
        }

        // Jump & Gravity
        if (!sessionRef.current.isGrounded) {
          cameraRef.current.position.y += sessionRef.current.velocityY;
          sessionRef.current.velocityY -= 0.012;

          if (cameraRef.current.position.y <= 1.7) {
            cameraRef.current.position.y = 1.7;
            sessionRef.current.velocityY = 0;
            sessionRef.current.isGrounded = true;
          }
        }

        cameraRef.current.position.x = Math.max(-10, Math.min(10, cameraRef.current.position.x));
        cameraRef.current.position.z = Math.max(-70, Math.min(70, cameraRef.current.position.z));

        // Grenades & Throwable Weapons Physics & Explosions (투척무기 폭발 로직)
        for (let i = grenadesRef.current.length - 1; i >= 0; i--) {
          const g = grenadesRef.current[i];
          g.mesh.position.add(g.velocity);
          g.velocity.y -= 0.012;
          g.timer -= 0.016;

          // Rotation effect during flight
          if (g.rotSpeed) {
            g.mesh.rotation.x += g.rotSpeed.x;
            g.mesh.rotation.y += g.rotSpeed.y;
            g.mesh.rotation.z += g.rotSpeed.z;
          } else if (g.type === 'SPEAR') {
            // Point spear along flight trajectory
            g.mesh.lookAt(g.mesh.position.clone().add(g.velocity));
          }

          // Check direct zombie collision or timer detonation
          let collided = false;
          for (let zi = 0; zi < zombiesRef.current.length; zi++) {
            if (g.mesh.position.distanceTo(zombiesRef.current[zi].mesh.position) < 1.2) {
              collided = true;
              break;
            }
          }

          if (g.timer <= 0 || g.mesh.position.y <= 0.1 || collided) {
            sounds.explosion();

            // Trigger weapon-specific visual explosion impact FX
            if (g.type === 'AXE') {
              createImpactFX(g.mesh.position, 'AXE');
            } else if (g.type === 'SPEAR') {
              createImpactFX(g.mesh.position, 'SPEAR');
            } else {
              createBloodFX(g.mesh.position);
              createImpactFX(g.mesh.position, 'VULCAN');
            }

            const explosionRadius = g.radius || 6.5;

            zombiesRef.current.forEach((z, zIdx) => {
              const dist = g.mesh.position.distanceTo(z.mesh.position);
              if (dist < explosionRadius) {
                // Closer to center deals more damage
                const falloff = Math.max(0.4, 1.0 - (dist / explosionRadius) * 0.6);
                z.hp -= g.damage * falloff;
                updateZombieHpBar(z);

                if (z.hp <= 0) {
                  sceneRef.current?.remove(z.mesh);
                  zombiesRef.current.splice(zIdx, 1);
                  sessionRef.current.killsThisRun++;
                  const earned = 30 + Math.floor(Math.random() * 15);
                  sessionRef.current.goldEarnedThisRun += earned;
                  setPlayerState((p) => ({ ...p, gold: p.gold + earned }));
                  setZombiesLeft(zombiesRef.current.length);

                  if (zombiesRef.current.length === 0) {
                    stageClearVictory();
                  }
                }
              }
            });

            sceneRef.current?.remove(g.mesh);
            grenadesRef.current.splice(i, 1);
          }
        }

        // Zombies AI
        const camPos = cameraRef.current.position;
        zombiesRef.current.forEach((z) => {
          const zPos = z.mesh.position;
          const dx = camPos.x - zPos.x;
          const dz = camPos.z - zPos.z;
          const dist = Math.hypot(dx, dz);

          if (dist > 1.35) {
            zPos.x += (dx / dist) * z.speed;
            zPos.z += (dz / dist) * z.speed;
            z.mesh.lookAt(camPos.x, zPos.y, camPos.z);

            z.walkAnimTime += 0.12;
            if (z.leftLeg && z.rightLeg) {
              z.leftLeg.rotation.x = Math.sin(z.walkAnimTime) * 0.6;
              z.rightLeg.rotation.x = -Math.sin(z.walkAnimTime) * 0.6;
            }
          } else {
            damagePlayer(z.damage * 0.016);
          }
        });

        // Particles
        for (let i = particlesRef.current.length - 1; i >= 0; i--) {
          const p = particlesRef.current[i];
          p.mesh.position.add(p.velocity);
          p.life -= 0.016;
          if (p.life <= 0) {
            sceneRef.current?.remove(p.mesh);
            particlesRef.current.splice(i, 1);
          }
        }
      }

      if (rendererRef.current && sceneRef.current && cameraRef.current) {
        rendererRef.current.render(sceneRef.current, cameraRef.current);
      }

      animId = requestAnimationFrame(updateGame);
    };

    animId = requestAnimationFrame(updateGame);
    return () => cancelAnimationFrame(animId);
  }, [classes, playerState.currentJobKey, playerState.baseSpeed]);

  // Input Event Listeners (Mouse Wheel, PointerLock, Keyboard)
  useEffect(() => {
    // 1. Mouse Wheel Weapon Switching
    const handleWheel = (e: WheelEvent) => {
      if (!sessionRef.current.isPlaying) return;
      e.preventDefault();
      sounds.init();

      if (e.deltaY > 0) {
        cycleSlot(1); // Next slot
      } else if (e.deltaY < 0) {
        cycleSlot(-1); // Previous slot
      }
    };

    // 2. Pointer Movement
    const handleMouseMove = (e: MouseEvent) => {
      if (!sessionRef.current.isPlaying || !cameraRef.current) return;
      // When zoomed in sniper scope, reduce sensitivity for precision aim
      const sensitivity = isZoomedRef.current ? 0.0009 : 0.0024;

      if (isPointerLockedRef.current) {
        cameraRef.current.rotation.y -= e.movementX * sensitivity;
        cameraRef.current.rotation.x -= e.movementY * sensitivity;
      } else if (isMouseDownRef.current) {
        const dx = e.clientX - prevMouseRef.current.x;
        const dy = e.clientY - prevMouseRef.current.y;
        cameraRef.current.rotation.y -= dx * sensitivity;
        cameraRef.current.rotation.x -= dy * sensitivity;
      }

      cameraRef.current.rotation.x = Math.max(
        -Math.PI * 0.45,
        Math.min(Math.PI * 0.45, cameraRef.current.rotation.x)
      );
      cameraRef.current.rotation.z = 0;

      prevMouseRef.current = { x: e.clientX, y: e.clientY };
    };

    // 3. Mouse Clicks (Left Click: Fire / Right Click: Sniper Zoom)
    const handleMouseDown = (e: MouseEvent) => {
      if (!sessionRef.current.isPlaying) return;

      if (e.button === 0) {
        // Left click = Attack
        isMouseDownRef.current = true;
        prevMouseRef.current = { x: e.clientX, y: e.clientY };
        sounds.init();
        triggerAttack();
      } else if (e.button === 2) {
        // Right click = Sniper Zoom
        e.preventDefault();
        const activeWepId = playerState.equippedSlots[playerState.activeSlot];
        if (activeWepId === 'SNIPER') {
          const nextZoom = !isZoomedRef.current;
          isZoomedRef.current = nextZoom;
          setIsZoomed(nextZoom);

          if (nextZoom) {
            sounds.zoomIn();
            if (cameraRef.current) {
              cameraRef.current.fov = 24; // 4x Optical Zoom FOV
              cameraRef.current.updateProjectionMatrix();
            }
            if (weaponContainerRef.current) {
              weaponContainerRef.current.visible = false; // Look through scope
            }
          } else {
            sounds.zoomOut();
            if (cameraRef.current) {
              cameraRef.current.fov = 75; // Standard FOV
              cameraRef.current.updateProjectionMatrix();
            }
            if (weaponContainerRef.current) {
              weaponContainerRef.current.visible = true;
            }
          }
        }
      }
    };

    const handleContextMenu = (e: MouseEvent) => {
      if (sessionRef.current.isPlaying) {
        e.preventDefault();
      }
    };

    const handleMouseUp = (e: MouseEvent) => {
      if (e.button === 0) {
        isMouseDownRef.current = false;
      }
    };

    // 4. PointerLock Change
    const handlePointerLockChange = () => {
      isPointerLockedRef.current = document.pointerLockElement === canvasRef.current;
      setShowAimHint(!isPointerLockedRef.current && sessionRef.current.isPlaying);
    };

    // 5. Keyboard
    const handleKeyDown = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      if (k === '1') selectSlot(1);
      if (k === '2') selectSlot(2);
      if (k === '3') selectSlot(3);
      if (k === '4') selectSlot(4);

      if (k === 'w' || k === 'arrowup') keysRef.current.w = true;
      if (k === 'a' || k === 'arrowleft') keysRef.current.a = true;
      if (k === 's' || k === 'arrowdown') keysRef.current.s = true;
      if (k === 'd' || k === 'arrowright') keysRef.current.d = true;

      if (k === ' ' || e.code === 'Space') {
        if (sessionRef.current.isGrounded) {
          sessionRef.current.velocityY = 0.22;
          sessionRef.current.isGrounded = false;
        }
      }
      if (e.key === 'Shift') keysRef.current.shift = true;
      if (k === 'r') reloadWeapon();
      if (k === 'q') handleUseHpPotion();
      if (k === 'e') handleUseShieldPotion();
      if (k === 'z') handleUseSpeedPotion();
      if (k === 'x') handleUseBerserkPotion();
      if (k === 'c') handleUseFullRestorePotion();
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      if (k === 'w' || k === 'arrowup') keysRef.current.w = false;
      if (k === 'a' || k === 'arrowleft') keysRef.current.a = false;
      if (k === 's' || k === 'arrowdown') keysRef.current.s = false;
      if (k === 'd' || k === 'arrowright') keysRef.current.d = false;
      if (e.key === 'Shift') keysRef.current.shift = false;
    };

    const canvas = canvasRef.current;
    if (canvas) {
      canvas.addEventListener('wheel', handleWheel, { passive: false });
    }
    window.addEventListener('wheel', handleWheel, { passive: false });
    document.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', handleMouseUp);
    window.addEventListener('contextmenu', handleContextMenu);
    document.addEventListener('pointerlockchange', handlePointerLockChange);
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      if (canvas) canvas.removeEventListener('wheel', handleWheel);
      window.removeEventListener('wheel', handleWheel);
      document.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mouseup', handleMouseUp);
      window.removeEventListener('contextmenu', handleContextMenu);
      document.removeEventListener('pointerlockchange', handlePointerLockChange);
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [cycleSlot, selectSlot, triggerAttack, reloadWeapon]);

  // Click Canvas to Lock Pointer
  const handleCanvasClick = () => {
    if (sessionRef.current.isPlaying && canvasRef.current) {
      sounds.init();
      canvasRef.current.requestPointerLock();
      setShowAimHint(false);
    }
  };

  // Launch Stage from Village
  const handleLaunchStage = () => {
    sounds.init();
    const maxHp = getMaxHp();
    const maxShield = getMaxShield();

    sessionRef.current.hp = maxHp;
    sessionRef.current.shield = maxShield;
    sessionRef.current.isReloading = false;
    sessionRef.current.killsThisRun = 0;
    sessionRef.current.goldEarnedThisRun = 0;
    sessionRef.current.isPlaying = true;
    sessionRef.current.velocityY = 0;
    sessionRef.current.isGrounded = true;

    // Refill ammo
    Object.values(playerState.equippedSlots).forEach((wKey) => {
      const w = weapons[wKey];
      sessionRef.current.weaponAmmo[wKey] = w.magSize;
      sessionRef.current.weaponReserve[wKey] = w.maxReserve;
    });

    const activeWepKey = playerState.equippedSlots[playerState.activeSlot];
    setCurrentAmmo(sessionRef.current.weaponAmmo[activeWepKey]);
    setReserveAmmo(sessionRef.current.weaponReserve[activeWepKey]);
    setHudHp(maxHp);
    setHudShield(maxShield);

    if (cameraRef.current) {
      cameraRef.current.position.set(0, 1.7, 0);
      cameraRef.current.rotation.set(0, 0, 0);
      cameraRef.current.fov = 75;
      cameraRef.current.updateProjectionMatrix();
    }
    if (weaponContainerRef.current) {
      weaponContainerRef.current.visible = true;
    }
    isZoomedRef.current = false;
    setIsZoomed(false);

    switchWeapon3DModel(activeWepKey);
    spawnStageZombies(playerState.selectedStage);

    setGameState('PLAYING');
    setShowAimHint(true);
  };

  return (
    <div className="w-screen h-screen relative overflow-hidden select-none bg-black text-white font-sans">
      
      {/* 3D WebGL Canvas */}
      <canvas
        ref={canvasRef}
        onClick={handleCanvasClick}
        className="w-full h-full block cursor-crosshair"
      />

      {/* Aim Hint */}
      {showAimHint && gameState === 'PLAYING' && (
        <div
          onClick={handleCanvasClick}
          className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 cursor-pointer bg-black/85 border border-yellow-400 text-yellow-300 px-6 py-2 rounded-full font-bold text-xs md:text-sm tracking-wide z-20 shadow-2xl animate-bounce flex items-center gap-2"
        >
          <span>화면을 클릭하여 3D 시점을 고정하세요! (마우스 휠: 무기 전환 | WASD: 이동)</span>
        </div>
      )}

      {/* Damage & Potion Flash Overlays */}
      <div
        className={`absolute inset-0 bg-red-600/35 pointer-events-none z-10 transition-opacity duration-150 ${
          damageFlash ? 'opacity-100' : 'opacity-0'
        }`}
      />
      <div
        className={`absolute inset-0 bg-emerald-500/30 pointer-events-none z-10 transition-opacity duration-300 ${
          healFlash ? 'opacity-100' : 'opacity-0'
        }`}
      />
      <div
        className={`absolute inset-0 bg-cyan-500/30 pointer-events-none z-10 transition-opacity duration-300 ${
          shieldFlash ? 'opacity-100' : 'opacity-0'
        }`}
      />
      <div
        className={`absolute inset-0 bg-emerald-400/25 pointer-events-none z-10 transition-opacity duration-350 ${
          speedFlash ? 'opacity-100' : 'opacity-0'
        }`}
      />
      <div
        className={`absolute inset-0 bg-amber-500/30 pointer-events-none z-10 transition-opacity duration-350 ${
          berserkFlash ? 'opacity-100' : 'opacity-0'
        }`}
      />
      <div
        className={`absolute inset-0 bg-gradient-to-r from-purple-500/40 via-pink-500/40 to-cyan-500/40 pointer-events-none z-10 transition-opacity duration-450 ${
          fullRestoreFlash ? 'opacity-100' : 'opacity-0'
        }`}
      />

      {/* 1. INTRO STORY MODAL */}
      {gameState === 'INTRO' && (
        <IntroModal
          onStart={() => {
            sounds.init();
            setGameState('VILLAGE');
          }}
        />
      )}

      {/* 2. VILLAGE / HUB MODAL */}
      {gameState === 'VILLAGE' && (
        <VillageModal
          playerState={playerState}
          weapons={weapons}
          classes={classes}
          onSelectStage={(stage) => setPlayerState((p) => ({ ...p, selectedStage: stage }))}
          onSelectClass={(classId) => {
            const sigId = classes[classId]?.signatureWeaponId;
            setPlayerState((p) => {
              let updatedEquipped = { ...p.equippedSlots };
              if (sigId && weapons[sigId]?.unlocked) {
                updatedEquipped[weapons[sigId].slot] = sigId;
              }
              return { ...p, currentJobKey: classId, equippedSlots: updatedEquipped };
            });
          }}
          onBuyClass={(classId) => {
            const cost = classes[classId].cost;
            const sigId = classes[classId]?.signatureWeaponId;
            if (playerState.gold >= cost) {
              setPlayerState((p) => {
                let updatedEquipped = { ...p.equippedSlots };
                if (sigId) {
                  updatedEquipped[weapons[sigId].slot] = sigId;
                }
                return { ...p, gold: p.gold - cost, currentJobKey: classId, equippedSlots: updatedEquipped };
              });
              setClasses((c) => ({
                ...c,
                [classId]: { ...c[classId], unlocked: true }
              }));
              // Also unlock the signature weapon when the class is bought!
              if (sigId) {
                setWeapons((w) => ({
                  ...w,
                  [sigId]: { ...w[sigId], unlocked: true }
                }));
              }
            }
          }}
          onEquipWeapon={(weaponId, slot) => {
            setPlayerState((p) => {
              const newEquipped = { ...p.equippedSlots, [slot]: weaponId };
              return { ...p, equippedSlots: newEquipped };
            });
          }}
          onBuyWeapon={(weaponId) => {
            const wep = weapons[weaponId];
            if (playerState.gold >= wep.cost) {
              setPlayerState((p) => ({
                ...p,
                gold: p.gold - wep.cost,
                equippedSlots: { ...p.equippedSlots, [wep.slot]: weaponId }
              }));
              setWeapons((w) => ({
                ...w,
                [weaponId]: { ...w[weaponId], unlocked: true }
              }));
            }
          }}
          onBuyPotion={(type) => {
            if (type === 'HP' && playerState.gold >= 80) {
              setPlayerState((p) => ({ ...p, gold: p.gold - 80, hpPotions: p.hpPotions + 1 }));
            } else if (type === 'SHIELD' && playerState.gold >= 100) {
              setPlayerState((p) => ({ ...p, gold: p.gold - 100, shieldPotions: p.shieldPotions + 1 }));
            } else if (type === 'SPEED' && playerState.gold >= 120) {
              setPlayerState((p) => ({ ...p, gold: p.gold - 120, speedPotions: p.speedPotions + 1 }));
            } else if (type === 'BERSERK' && playerState.gold >= 160) {
              setPlayerState((p) => ({ ...p, gold: p.gold - 160, berserkPotions: p.berserkPotions + 1 }));
            } else if (type === 'FULL_RESTORE' && playerState.gold >= 240) {
              setPlayerState((p) => ({ ...p, gold: p.gold - 240, fullRestorePotions: p.fullRestorePotions + 1 }));
            }
          }}
          onLaunch={handleLaunchStage}
        />
      )}

      {/* 3. IN-GAME FPS HUD */}
      {gameState === 'PLAYING' && (
        <HUD
          hp={hudHp}
          maxHp={getMaxHp()}
          shield={hudShield}
          maxShield={getMaxShield()}
          stage={playerState.selectedStage}
          zombiesLeft={zombiesLeft}
          zombiesTotal={zombiesTotal}
          bossHp={bossHp}
          maxBossHp={maxBossHp}
          gold={playerState.gold}
          job={classes[playerState.currentJobKey]}
          activeSlot={playerState.activeSlot}
          equippedSlots={playerState.equippedSlots}
          weapons={weapons}
          currentAmmo={currentAmmo}
          reserveAmmo={reserveAmmo}
          isReloading={isReloading}
          hpPotions={playerState.hpPotions}
          shieldPotions={playerState.shieldPotions}
          speedPotions={playerState.speedPotions}
          berserkPotions={playerState.berserkPotions}
          fullRestorePotions={playerState.fullRestorePotions}
          speedBuffTimer={speedBuffTimer}
          berserkBuffTimer={berserkBuffTimer}
          isZoomed={isZoomed}
          onSelectSlot={selectSlot}
          onUseHpPotion={handleUseHpPotion}
          onUseShieldPotion={handleUseShieldPotion}
          onUseSpeedPotion={handleUseSpeedPotion}
          onUseBerserkPotion={handleUseBerserkPotion}
          onUseFullRestorePotion={handleUseFullRestorePotion}
          onGiveUp={playerDeath}
        />
      )}

      {/* 4. DEATH MODAL */}
      {gameState === 'DEATH' && (
        <DeathModal
          stage={playerState.selectedStage}
          goldEarned={lastEarnedGold}
          kills={lastKills}
          onReturnVillage={() => setGameState('VILLAGE')}
        />
      )}

      {/* 5. VICTORY STAGE CLEAR MODAL */}
      {gameState === 'VICTORY' && (
        <VictoryModal
          stage={playerState.selectedStage}
          goldEarned={lastEarnedGold}
          kills={lastKills}
          nextStage={Math.min(40, playerState.selectedStage + 1)}
          onContinue={() => {
            setPlayerState((p) => ({
              ...p,
              selectedStage: Math.min(40, p.selectedStage + 1)
            }));
            setGameState('VILLAGE');
          }}
        />
      )}
    </div>
  );
}
