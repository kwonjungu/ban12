export type WeaponSlot = 1 | 2 | 3 | 4;

export type WeaponId =
  | 'RIFLE'
  | 'SNIPER'
  | 'SHOTGUN'
  | 'MINIGUN'
  | 'PISTOL'
  | 'SMG'
  | 'KATANA'
  | 'GRENADE'
  | 'COMMANDO_VULCAN'
  | 'RAILGUN'
  | 'BIO_LAUNCHER'
  | 'BLOOD_SCYTHE'
  | 'TITAN_HAMMER'
  | 'THROWING_AXE'
  | 'EXPLOSIVE_SPEAR';

export type WeaponImpactType = 'NORMAL' | 'VULCAN' | 'RAILGUN' | 'BIO' | 'BLOOD' | 'TITAN' | 'AXE' | 'SPEAR';

export interface WeaponData {
  id: WeaponId;
  name: string;
  category: string;
  slot: WeaponSlot;
  damage: number;
  fireRate: number; // in seconds between attacks
  magSize: number;
  maxReserve: number;
  reloadTime: number; // in seconds
  cost: number;
  unlocked: boolean;
  icon: string;
  isMelee?: boolean;
  isThrowable?: boolean;
  description: string;
  exclusiveJob?: JobClassId;
  impactType?: WeaponImpactType;
}

export type JobClassId = 'COMMANDO' | 'SNIPER' | 'MEDIC' | 'BERSERKER' | 'JUGGERNAUT';

export interface JobClassData {
  id: JobClassId;
  name: string;
  desc: string;
  cost: number;
  unlocked: boolean;
  hpBonus: number;
  shieldBonus: number;
  dmgMultiplier: number;
  speedBonus: number;
  meleeMultiplier?: number;
  signatureWeaponId: WeaponId;
  icon: string;
}

export type PotionType = 'HP' | 'SHIELD' | 'SPEED' | 'BERSERK' | 'FULL_RESTORE';

export interface PlayerState {
  gold: number;
  unlockedStage: number;
  selectedStage: number;
  currentJobKey: JobClassId;
  equippedSlots: Record<WeaponSlot, WeaponId>;
  activeSlot: WeaponSlot;
  hpPotions: number;
  shieldPotions: number;
  speedPotions: number;
  berserkPotions: number;
  fullRestorePotions: number;
  baseMaxHp: number;
  baseMaxShield: number;
  baseSpeed: number;
  critChance: number;
}

export interface ActiveSession {
  hp: number;
  shield: number;
  weaponAmmo: Record<WeaponId, number>;
  weaponReserve: Record<WeaponId, number>;
  isReloading: boolean;
  killsThisRun: number;
  goldEarnedThisRun: number;
  isPlaying: boolean;
  velocityY: number;
  isGrounded: boolean;
}
