import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { PlayerStats, GoblinEnemy, Projectile, WeaponId } from '../types';
import { WEAPONS_CATALOG } from '../weapons';
import { sounds } from '../audio';

interface GameCanvasProps {
  stats: PlayerStats;
  onUpdateStats: (updater: (prev: PlayerStats) => PlayerStats) => void;
  onSpawnDamage: (amount: number, isCrit: boolean, screenPos: { x: number; y: number }) => void;
  onGoblinKilled: (isBoss: boolean) => void;
  onChatMessage: (author: string, text: string, color?: string) => void;
  isPointerLocked: boolean;
  setIsPointerLocked: (locked: boolean) => void;
  onQuestProgress: () => void;
  activeSkillTrigger: string | null;
  onClearSkillTrigger: () => void;
}

export const GameCanvas: React.FC<GameCanvasProps> = ({
  stats,
  onUpdateStats,
  onSpawnDamage,
  onGoblinKilled,
  onChatMessage,
  setIsPointerLocked,
  onQuestProgress,
  activeSkillTrigger,
  onClearSkillTrigger,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);

  // References for cross-scope access in game loop
  const statsRef = useRef(stats);
  statsRef.current = stats;

  const callbacksRef = useRef({
    onUpdateStats,
    onSpawnDamage,
    onGoblinKilled,
    onChatMessage,
    onQuestProgress,
  });
  callbacksRef.current = {
    onUpdateStats,
    onSpawnDamage,
    onGoblinKilled,
    onChatMessage,
    onQuestProgress,
  };

  const activeSkillRef = useRef(activeSkillTrigger);
  activeSkillRef.current = activeSkillTrigger;

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // --- THREE.JS SETUP ---
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x76b6ff); // Bright fantasy daylight blue
    scene.fog = new THREE.FogExp2(0x76b6ff, 0.008);

    const camera = new THREE.PerspectiveCamera(72, container.clientWidth / container.clientHeight, 0.1, 800);
    camera.position.set(0, 2.0, 18); // Start on the cobblestone street looking down towards town center

    const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.appendChild(renderer.domElement);

    // --- LIGHTS ---
    const ambientLight = new THREE.AmbientLight(0xfffaed, 1.4);
    scene.add(ambientLight);

    const sunLight = new THREE.DirectionalLight(0xfff3d6, 2.2);
    sunLight.position.set(40, 80, 50);
    sunLight.castShadow = true;
    sunLight.shadow.mapSize.width = 2048;
    sunLight.shadow.mapSize.height = 2048;
    sunLight.shadow.camera.near = 0.5;
    sunLight.shadow.camera.far = 250;
    sunLight.shadow.camera.left = -60;
    sunLight.shadow.camera.right = 60;
    sunLight.shadow.camera.top = 60;
    sunLight.shadow.camera.bottom = -60;
    scene.add(sunLight);

    // --- TEXTURES (Procedural high-res canvas textures for cobblestone, wood, roof) ---
    function createCobbleTexture() {
      const c = document.createElement('canvas');
      c.width = 512;
      c.height = 512;
      const ctx = c.getContext('2d')!;
      ctx.fillStyle = '#6b7280';
      ctx.fillRect(0, 0, 512, 512);

      // Cobblestone stones
      const rows = 16;
      const cols = 8;
      const rh = 512 / rows;
      const rw = 512 / cols;

      for (let r = 0; r < rows; r++) {
        const offset = (r % 2) * (rw / 2);
        for (let col = -1; col < cols + 1; col++) {
          const x = col * rw + offset + (Math.random() - 0.5) * 4;
          const y = r * rh + (Math.random() - 0.5) * 4;
          const shade = 100 + Math.floor(Math.random() * 50);
          ctx.fillStyle = `rgb(${shade}, ${shade + 2}, ${shade + 5})`;
          ctx.beginPath();
          ctx.roundRect(x + 2, y + 2, rw - 4, rh - 4, 6);
          ctx.fill();
          ctx.strokeStyle = '#374151';
          ctx.lineWidth = 3;
          ctx.stroke();
        }
      }
      const tex = new THREE.CanvasTexture(c);
      tex.wrapS = THREE.RepeatWrapping;
      tex.wrapT = THREE.RepeatWrapping;
      tex.repeat.set(4, 30);
      return tex;
    }

    function createTimberPlasterTexture() {
      const c = document.createElement('canvas');
      c.width = 256;
      c.height = 256;
      const ctx = c.getContext('2d')!;
      ctx.fillStyle = '#f8fafc'; // White/stucco plaster
      ctx.fillRect(0, 0, 256, 256);
      // Dark brown timber beams
      ctx.fillStyle = '#451a03';
      ctx.fillRect(0, 0, 24, 256);
      ctx.fillRect(232, 0, 24, 256);
      ctx.fillRect(0, 0, 256, 20);
      ctx.fillRect(0, 236, 256, 20);
      // Diagonal cross beam
      ctx.lineWidth = 18;
      ctx.strokeStyle = '#451a03';
      ctx.beginPath();
      ctx.moveTo(12, 12);
      ctx.lineTo(244, 244);
      ctx.stroke();

      const tex = new THREE.CanvasTexture(c);
      tex.wrapS = THREE.RepeatWrapping;
      tex.wrapT = THREE.RepeatWrapping;
      return tex;
    }

    function createRoofTileTexture() {
      const c = document.createElement('canvas');
      c.width = 256;
      c.height = 256;
      const ctx = c.getContext('2d')!;
      ctx.fillStyle = '#7c2d12';
      ctx.fillRect(0, 0, 256, 256);
      ctx.fillStyle = '#991b1b';
      for (let y = 0; y < 256; y += 32) {
        ctx.fillRect(0, y, 256, 16);
      }
      const tex = new THREE.CanvasTexture(c);
      tex.wrapS = THREE.RepeatWrapping;
      tex.wrapT = THREE.RepeatWrapping;
      tex.repeat.set(2, 4);
      return tex;
    }

    // --- ENVIRONMENT BUILDING ---
    const cobbleTex = createCobbleTexture();
    const timberTex = createTimberPlasterTexture();
    const roofTex = createRoofTileTexture();

    // Cobblestone Main Street
    const streetGeo = new THREE.PlaneGeometry(16, 260);
    const streetMat = new THREE.MeshStandardMaterial({
      map: cobbleTex,
      roughness: 0.8,
      metalness: 0.1,
    });
    const streetMesh = new THREE.Mesh(streetGeo, streetMat);
    streetMesh.rotation.x = -Math.PI / 2;
    streetMesh.receiveShadow = true;
    scene.add(streetMesh);

    // Grassy Sidewalks / Countryside
    const grassMat = new THREE.MeshStandardMaterial({
      color: 0x4d7c0f,
      roughness: 0.9,
    });
    const leftGrass = new THREE.Mesh(new THREE.PlaneGeometry(80, 260), grassMat);
    leftGrass.rotation.x = -Math.PI / 2;
    leftGrass.position.set(-48, -0.02, 0);
    leftGrass.receiveShadow = true;
    scene.add(leftGrass);

    const rightGrass = new THREE.Mesh(new THREE.PlaneGeometry(80, 260), grassMat);
    rightGrass.rotation.x = -Math.PI / 2;
    rightGrass.position.set(48, -0.02, 0);
    rightGrass.receiveShadow = true;
    scene.add(rightGrass);

    // Medieval Houses along both sides
    const housePlasterMat = new THREE.MeshStandardMaterial({
      map: timberTex,
      roughness: 0.7,
    });
    const roofMat = new THREE.MeshStandardMaterial({
      map: roofTex,
      roughness: 0.6,
    });
    const woodTrimMat = new THREE.MeshStandardMaterial({
      color: 0x3e2723,
      roughness: 0.8,
    });

    function createMedievalHouse(x: number, z: number, rotationY: number, scale = 1.0) {
      const house = new THREE.Group();

      // Main base
      const bodyW = 10 * scale;
      const bodyH = 8 * scale;
      const bodyD = 12 * scale;
      const bodyGeo = new THREE.BoxGeometry(bodyW, bodyH, bodyD);
      const body = new THREE.Mesh(bodyGeo, housePlasterMat);
      body.position.y = bodyH / 2;
      body.castShadow = true;
      body.receiveShadow = true;
      house.add(body);

      // Second floor overhang
      const upperGeo = new THREE.BoxGeometry(bodyW * 1.08, bodyH * 0.9, bodyD * 1.05);
      const upper = new THREE.Mesh(upperGeo, housePlasterMat);
      upper.position.y = bodyH + (bodyH * 0.9) / 2;
      upper.castShadow = true;
      upper.receiveShadow = true;
      house.add(upper);

      // Pitched Roof
      const roofGeo = new THREE.ConeGeometry(bodyW * 0.9, 5 * scale, 4);
      const roof = new THREE.Mesh(roofGeo, roofMat);
      roof.position.y = bodyH * 1.9 + 2.5 * scale;
      roof.rotation.y = Math.PI / 4;
      roof.scale.set(1.1, 1, 1.4);
      roof.castShadow = true;
      house.add(roof);

      // Chimney
      const chimGeo = new THREE.BoxGeometry(1.2 * scale, 4 * scale, 1.2 * scale);
      const chimMat = new THREE.MeshStandardMaterial({ color: 0x52525b });
      const chim = new THREE.Mesh(chimGeo, chimMat);
      chim.position.set(bodyW * 0.3, bodyH * 2.1, bodyD * 0.2);
      chim.castShadow = true;
      house.add(chim);

      // Window with warm glow
      const winGeo = new THREE.BoxGeometry(1.4 * scale, 1.6 * scale, 0.1);
      const winMat = new THREE.MeshBasicMaterial({ color: 0xfef08a });
      const win = new THREE.Mesh(winGeo, winMat);
      win.position.set(0, bodyH * 1.3, bodyD * 0.53);
      house.add(win);

      house.position.set(x, 0, z);
      house.rotation.y = rotationY;
      scene.add(house);
    }

    // Spawn row of houses
    for (let z = -100; z <= 100; z += 24) {
      createMedievalHouse(-14, z, Math.PI / 2, 1.0 + Math.random() * 0.2);
      createMedievalHouse(14, z, -Math.PI / 2, 1.0 + Math.random() * 0.2);
    }

    // Street Lantern Posts with glowing lights
    const lanternGroup = new THREE.Group();
    for (let z = -90; z <= 90; z += 30) {
      [-8.5, 8.5].forEach((x) => {
        const postGeo = new THREE.CylinderGeometry(0.12, 0.15, 4.5, 8);
        const post = new THREE.Mesh(postGeo, woodTrimMat);
        post.position.set(x, 2.25, z);
        post.castShadow = true;
        lanternGroup.add(post);

        const lanternGeo = new THREE.BoxGeometry(0.6, 0.8, 0.6);
        const lanternMat = new THREE.MeshBasicMaterial({ color: 0xfde047 });
        const lantern = new THREE.Mesh(lanternGeo, lanternMat);
        lantern.position.set(x, 4.2, z);
        lanternGroup.add(lantern);

        const lLight = new THREE.PointLight(0xfde047, 0.8, 12);
        lLight.position.set(x, 4.2, z);
        lanternGroup.add(lLight);
      });
    }
    scene.add(lanternGroup);

    // Voxel Trees on grass
    function createVoxelTree(x: number, z: number) {
      const tree = new THREE.Group();
      const trunkGeo = new THREE.BoxGeometry(1, 4.5, 1);
      const trunkMat = new THREE.MeshStandardMaterial({ color: 0x5c3818 });
      const trunk = new THREE.Mesh(trunkGeo, trunkMat);
      trunk.position.y = 2.25;
      trunk.castShadow = true;
      tree.add(trunk);

      const leafMat = new THREE.MeshStandardMaterial({ color: 0x15803d, roughness: 0.9 });
      const tiers = [
        { s: 5, y: 5 },
        { s: 4, y: 7 },
        { s: 2.5, y: 8.8 },
      ];
      tiers.forEach((t) => {
        const leaves = new THREE.Mesh(new THREE.BoxGeometry(t.s, 2, t.s), leafMat);
        leaves.position.y = t.y;
        leaves.castShadow = true;
        tree.add(leaves);
      });

      tree.position.set(x, 0, z);
      scene.add(tree);
    }

    for (let i = 0; i < 24; i++) {
      const side = Math.random() > 0.5 ? 1 : -1;
      const x = side * (24 + Math.random() * 20);
      const z = (Math.random() - 0.5) * 200;
      createVoxelTree(x, z);
    }

    // Puffy Voxel Clouds in sky
    const clouds: THREE.Group[] = [];
    for (let i = 0; i < 12; i++) {
      const cloud = new THREE.Group();
      const cloudMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.9 });
      const numBlocks = 4 + Math.floor(Math.random() * 5);
      for (let b = 0; b < numBlocks; b++) {
        const bx = (Math.random() - 0.5) * 12;
        const by = (Math.random() - 0.5) * 3;
        const bz = (Math.random() - 0.5) * 8;
        const block = new THREE.Mesh(new THREE.BoxGeometry(6, 4, 6), cloudMat);
        block.position.set(bx, by, bz);
        cloud.add(block);
      }
      cloud.position.set((Math.random() - 0.5) * 250, 45 + Math.random() * 20, (Math.random() - 0.5) * 250);
      scene.add(cloud);
      clouds.push(cloud);
    }

    // --- FRIENDLY NPCs ("? Quest Giver") ---
    const questGiverGroup = new THREE.Group();
    // Body & head (Roblox style blocky avatar)
    const qHead = new THREE.Mesh(
      new THREE.BoxGeometry(0.8, 0.8, 0.8),
      new THREE.MeshStandardMaterial({ color: 0xfed7aa })
    );
    qHead.position.y = 2.4;
    // Hair
    const qHair = new THREE.Mesh(
      new THREE.BoxGeometry(0.9, 0.4, 0.9),
      new THREE.MeshStandardMaterial({ color: 0xfacc15 }) // Blonde hair
    );
    qHair.position.y = 2.75;
    const qTorso = new THREE.Mesh(
      new THREE.BoxGeometry(1.2, 1.2, 0.6),
      new THREE.MeshStandardMaterial({ color: 0xdc2626 }) // Red shirt
    );
    qTorso.position.y = 1.4;
    const qLegs = new THREE.Mesh(
      new THREE.BoxGeometry(1.1, 1.0, 0.6),
      new THREE.MeshStandardMaterial({ color: 0x1e3a8a }) // Blue pants
    );
    qLegs.position.y = 0.5;

    questGiverGroup.add(qHead);
    questGiverGroup.add(qHair);
    questGiverGroup.add(qTorso);
    questGiverGroup.add(qLegs);

    // Glowing Question Mark '?' floating above
    const qMarkCanvas = document.createElement('canvas');
    qMarkCanvas.width = 128;
    qMarkCanvas.height = 128;
    const qCtx = qMarkCanvas.getContext('2d')!;
    qCtx.fillStyle = '#facc15';
    qCtx.font = 'bold 80px sans-serif';
    qCtx.textAlign = 'center';
    qCtx.textBaseline = 'middle';
    qCtx.fillText('?', 64, 64);
    const qMarkTex = new THREE.CanvasTexture(qMarkCanvas);
    const qMarkMat = new THREE.SpriteMaterial({ map: qMarkTex });
    const qMarkSprite = new THREE.Sprite(qMarkMat);
    qMarkSprite.position.y = 3.6;
    qMarkSprite.scale.set(1.4, 1.4, 1);
    questGiverGroup.add(qMarkSprite);

    questGiverGroup.position.set(6, 0, 5);
    questGiverGroup.rotation.y = -Math.PI / 4;
    scene.add(questGiverGroup);

    // --- FIRST-PERSON WEAPON: MULTI-WEAPON ARSENAL RIG ---
    const weaponRig = new THREE.Group();

    // 1. Weapon barrel group that adapts based on selected weapon
    const weaponBarrelGroup = new THREE.Group();
    weaponRig.add(weaponBarrelGroup);

    // Barrel Mesh
    const rpgMainTube = new THREE.Mesh(
      new THREE.CylinderGeometry(0.14, 0.16, 1.8, 16),
      new THREE.MeshStandardMaterial({
        color: 0x3f1e10,
        roughness: 0.4,
        metalness: 0.4,
      })
    );
    rpgMainTube.rotation.x = Math.PI / 2;
    rpgMainTube.position.set(0, 0, -0.4);
    weaponBarrelGroup.add(rpgMainTube);

    // Gold/accent rings
    const barrelRings: THREE.Mesh[] = [];
    [-0.8, -0.4, 0.0, 0.4].forEach((pz) => {
      const ring = new THREE.Mesh(
        new THREE.TorusGeometry(0.17, 0.035, 12, 24),
        new THREE.MeshStandardMaterial({ color: 0xf59e0b, metalness: 0.9, roughness: 0.2 })
      );
      ring.position.set(0, 0, pz);
      barrelRings.push(ring);
      weaponBarrelGroup.add(ring);
    });

    // Muzzle
    const dragonMuzzle = new THREE.Mesh(
      new THREE.ConeGeometry(0.24, 0.6, 8),
      new THREE.MeshStandardMaterial({ color: 0xd97706, metalness: 0.8, roughness: 0.3 })
    );
    dragonMuzzle.rotation.x = -Math.PI / 2;
    dragonMuzzle.position.set(0, 0, -1.35);
    weaponBarrelGroup.add(dragonMuzzle);

    // Glowing Iron Sight
    const sightSphere = new THREE.Mesh(
      new THREE.SphereGeometry(0.08, 16, 16),
      new THREE.MeshBasicMaterial({ color: 0xff5500 })
    );
    sightSphere.position.set(0, 0.22, -1.1);
    weaponBarrelGroup.add(sightSphere);

    const sightLight = new THREE.PointLight(0xff7700, 1.5, 3);
    sightLight.position.set(0, 0.22, -1.1);
    weaponBarrelGroup.add(sightLight);

    // 5. Curved stock & grip
    const stock = new THREE.Mesh(
      new THREE.BoxGeometry(0.12, 0.4, 0.7),
      new THREE.MeshStandardMaterial({ color: 0x451a03, roughness: 0.7 })
    );
    stock.position.set(0, -0.22, 0.4);
    stock.rotation.x = 0.2;
    weaponRig.add(stock);

    // Function to visually restyle weapon model when weapon switches
    let lastRenderedWeaponId: WeaponId | null = null;
    function syncWeaponVisuals(wId: WeaponId) {
      if (lastRenderedWeaponId === wId) return;
      lastRenderedWeaponId = wId;

      const def = WEAPONS_CATALOG[wId] || WEAPONS_CATALOG.dragonfire;
      const barrelMat = rpgMainTube.material as THREE.MeshStandardMaterial;
      const muzzleMat = dragonMuzzle.material as THREE.MeshStandardMaterial;
      const sightMat = sightSphere.material as THREE.MeshBasicMaterial;

      if (wId === 'plasma_laser') {
        barrelMat.color.setHex(0x0e7490);
        barrelMat.metalness = 0.9;
        barrelMat.roughness = 0.2;
        muzzleMat.color.setHex(0x06b6d4);
        sightMat.color.setHex(0x22d3ee);
        sightLight.color.setHex(0x06b6d4);
        barrelRings.forEach((r) => ((r.material as THREE.MeshStandardMaterial).color.setHex(0x38bdf8)));
      } else if (wId === 'cluster_meteor') {
        barrelMat.color.setHex(0x262626); // volcanic obsidian
        barrelMat.metalness = 0.6;
        barrelMat.roughness = 0.8;
        muzzleMat.color.setHex(0xea580c);
        sightMat.color.setHex(0xff3b00);
        sightLight.color.setHex(0xea580c);
        barrelRings.forEach((r) => ((r.material as THREE.MeshStandardMaterial).color.setHex(0x9a3412)));
      } else if (wId === 'holy_radiance') {
        barrelMat.color.setHex(0xfef08a); // divine gold & white
        barrelMat.metalness = 0.95;
        barrelMat.roughness = 0.1;
        muzzleMat.color.setHex(0xf59e0b);
        sightMat.color.setHex(0xfacc15);
        sightLight.color.setHex(0xfef08a);
        barrelRings.forEach((r) => ((r.material as THREE.MeshStandardMaterial).color.setHex(0xffffff)));
      } else {
        // dragonfire
        barrelMat.color.setHex(0x3f1e10);
        barrelMat.metalness = 0.4;
        barrelMat.roughness = 0.4;
        muzzleMat.color.setHex(0xd97706);
        sightMat.color.setHex(0xff5500);
        sightLight.color.setHex(0xff7700);
        barrelRings.forEach((r) => ((r.material as THREE.MeshStandardMaterial).color.setHex(0xf59e0b)));
      }
    }

    // 6. Player Blocky Roblox Arms holding the RPG
    const armMat = new THREE.MeshStandardMaterial({ color: 0xfed7aa });
    const sleeveMat = new THREE.MeshStandardMaterial({ color: 0x1e293b });

    // Right arm
    const rightArm = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.25, 0.9), armMat);
    rightArm.position.set(0.28, -0.25, 0.2);
    rightArm.rotation.set(-0.3, -0.2, 0.1);
    weaponRig.add(rightArm);

    // Left arm reaching to foregrip
    const leftArm = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.25, 1.0), armMat);
    leftArm.position.set(-0.25, -0.3, -0.3);
    leftArm.rotation.set(-0.4, 0.4, -0.2);
    weaponRig.add(leftArm);

    // Position weapon in lower right viewport
    weaponRig.position.set(0.48, -0.36, -0.85);
    camera.add(weaponRig);
    scene.add(camera);

    // --- ENEMY GOBLINS LOGIC ---
    interface ActiveGoblin {
      id: string;
      mesh: THREE.Group;
      health: number;
      maxHp: number;
      speed: number;
      isBoss: boolean;
      hitFlashTime: number;
      attackCooldown: number;
      healthBarSprite: THREE.Sprite;
      leftLeg: THREE.Mesh;
      rightLeg: THREE.Mesh;
      leftArm: THREE.Mesh;
      rightArm: THREE.Mesh;
    }

    const activeGoblins: ActiveGoblin[] = [];

    function createGoblinMesh(isBoss = false) {
      const g = new THREE.Group();
      const scale = isBoss ? 2.2 : 1.1;

      const skinMat = new THREE.MeshStandardMaterial({
        color: isBoss ? 0x166534 : 0x22c55e, // Goblin green
        roughness: 0.6,
      });
      const armorMat = new THREE.MeshStandardMaterial({
        color: 0x78350f, // Leather harness
        roughness: 0.8,
      });

      // Head
      const head = new THREE.Mesh(new THREE.BoxGeometry(0.7 * scale, 0.7 * scale, 0.7 * scale), skinMat);
      head.position.y = 1.9 * scale;
      g.add(head);

      // Pointy ears
      [-0.45 * scale, 0.45 * scale].forEach((ex) => {
        const ear = new THREE.Mesh(new THREE.ConeGeometry(0.18 * scale, 0.4 * scale, 4), skinMat);
        ear.position.set(ex, 2.0 * scale, 0);
        ear.rotation.z = (ex > 0 ? -1 : 1) * 0.8;
        g.add(ear);
      });

      // Red glowing eyes
      [-0.18 * scale, 0.18 * scale].forEach((eyex) => {
        const eye = new THREE.Mesh(
          new THREE.SphereGeometry(0.08 * scale, 8, 8),
          new THREE.MeshBasicMaterial({ color: 0xef4444 })
        );
        eye.position.set(eyex, 1.95 * scale, 0.38 * scale);
        g.add(eye);
      });

      // Torso
      const torso = new THREE.Mesh(new THREE.BoxGeometry(0.9 * scale, 1.0 * scale, 0.5 * scale), armorMat);
      torso.position.y = 1.1 * scale;
      g.add(torso);

      // Legs
      const leftLeg = new THREE.Mesh(new THREE.BoxGeometry(0.35 * scale, 0.8 * scale, 0.35 * scale), skinMat);
      leftLeg.position.set(-0.25 * scale, 0.4 * scale, 0);
      g.add(leftLeg);

      const rightLeg = new THREE.Mesh(new THREE.BoxGeometry(0.35 * scale, 0.8 * scale, 0.35 * scale), skinMat);
      rightLeg.position.set(0.25 * scale, 0.4 * scale, 0);
      g.add(rightLeg);

      // Arms with spiked club
      const leftArm = new THREE.Mesh(new THREE.BoxGeometry(0.3 * scale, 0.8 * scale, 0.3 * scale), skinMat);
      leftArm.position.set(-0.6 * scale, 1.1 * scale, 0);
      g.add(leftArm);

      const rightArm = new THREE.Mesh(new THREE.BoxGeometry(0.3 * scale, 0.8 * scale, 0.3 * scale), skinMat);
      rightArm.position.set(0.6 * scale, 1.1 * scale, 0);
      g.add(rightArm);

      // Spiked wooden club in right hand
      const club = new THREE.Mesh(
        new THREE.CylinderGeometry(0.12 * scale, 0.08 * scale, 1.2 * scale, 6),
        new THREE.MeshStandardMaterial({ color: 0x451a03 })
      );
      club.position.set(0.6 * scale, 0.8 * scale, 0.4 * scale);
      club.rotation.x = Math.PI / 4;
      g.add(club);

      // Floating Overhead Health Bar Sprite
      const hbCanvas = document.createElement('canvas');
      hbCanvas.width = 256;
      hbCanvas.height = 48;
      const hbTex = new THREE.CanvasTexture(hbCanvas);
      const hbMat = new THREE.SpriteMaterial({ map: hbTex });
      const hbSprite = new THREE.Sprite(hbMat);
      hbSprite.position.y = 2.6 * scale;
      hbSprite.scale.set(2.4 * scale, 0.5 * scale, 1);
      g.add(hbSprite);

      return { group: g, leftLeg, rightLeg, leftArm, rightArm, healthBarSprite: hbSprite, hbCanvas, hbTex };
    }

    function updateHealthBarSprite(goblin: ActiveGoblin, hbCanvas: HTMLCanvasElement, hbTex: THREE.CanvasTexture) {
      const ctx = hbCanvas.getContext('2d')!;
      ctx.clearRect(0, 0, 256, 48);

      // Background pill
      ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
      ctx.beginPath();
      ctx.roundRect(4, 4, 248, 40, 8);
      ctx.fill();

      // Border
      ctx.strokeStyle = '#eab308';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Health fill
      const pct = Math.max(0, goblin.health / goblin.maxHp);
      const fillGrad = ctx.createLinearGradient(10, 0, 240, 0);
      fillGrad.addColorStop(0, '#ef4444');
      fillGrad.addColorStop(1, '#22c55e');
      ctx.fillStyle = fillGrad;
      ctx.beginPath();
      ctx.roundRect(8, 8, 240 * pct, 32, 6);
      ctx.fill();

      // Text label
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 22px Nunito, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      const label = goblin.isBoss
        ? `☠ BOSS Lv 30 (${Math.ceil(goblin.health)})`
        : `Lv 20 Goblin (${Math.ceil(goblin.health)})`;
      ctx.fillText(label, 128, 24);

      hbTex.needsUpdate = true;
    }

    function spawnGoblinWave(count: number, hasBoss = false) {
      for (let i = 0; i < count; i++) {
        const isBoss = hasBoss && i === 0;
        const goblinData = createGoblinMesh(isBoss);

        // Spawn down the street ahead of player
        const spawnZ = camera.position.z - (45 + Math.random() * 35);
        const spawnX = (Math.random() - 0.5) * 10;
        goblinData.group.position.set(spawnX, 0, spawnZ);
        scene.add(goblinData.group);

        const hp = isBoss ? 600 : 120;
        const goblinObj: ActiveGoblin = {
          id: 'goblin_' + Math.random(),
          mesh: goblinData.group,
          health: hp,
          maxHp: hp,
          speed: isBoss ? 3.2 : 4.2 + Math.random() * 1.5,
          isBoss,
          hitFlashTime: 0,
          attackCooldown: 0,
          healthBarSprite: goblinData.healthBarSprite,
          leftLeg: goblinData.leftLeg,
          rightLeg: goblinData.rightLeg,
          leftArm: goblinData.leftArm,
          rightArm: goblinData.rightArm,
        };

        updateHealthBarSprite(goblinObj, goblinData.hbCanvas, goblinData.hbTex);
        activeGoblins.push(goblinObj);
      }
    }

    // Initial Goblin Spawn
    spawnGoblinWave(7, false);

    // --- PROJECTILES & PARTICLES ---
    interface ActiveRocket {
      mesh: THREE.Group;
      pos: THREE.Vector3;
      vel: THREE.Vector3;
      life: number;
      damage: number;
      splashRadius: number;
      trailColor1: number;
      trailColor2: number;
      weaponId: WeaponId;
    }

    const activeRockets: ActiveRocket[] = [];

    interface ExplosionEffect {
      mesh: THREE.Mesh;
      light: THREE.PointLight;
      scale: number;
      maxScale: number;
      opacity: number;
      color: number;
    }
    const activeExplosions: ExplosionEffect[] = [];

    interface SmokeParticle {
      mesh: THREE.Mesh;
      vel: THREE.Vector3;
      life: number;
      maxLife: number;
    }
    const activeSmokes: SmokeParticle[] = [];

    // --- CONTROLS & PHYSICS STATE ---
    const keys: { [code: string]: boolean } = {};
    const playerVel = new THREE.Vector3();
    let isGrounded = true;
    const playerRot = { yaw: 0, pitch: 0 };
    let walkBobTimer = 0;
    let recoilOffset = 0;
    let recoilRot = 0;

    const onKeyDown = (e: KeyboardEvent) => {
      keys[e.code] = true;

      if (e.code === 'KeyR') {
        // Reload RPG
        handleReload();
      } else if (e.code === 'KeyQ') {
        // Skill 1: Dragon Swipe
        handleDragonSwipe();
      } else if (e.code === 'KeyE') {
        // Skill 2: Dragon Dash
        handleDragonDash();
      } else if (e.code === 'KeyF') {
        // Mana Potion
        handleDrinkPotion();
      } else if (e.code === 'Digit1') {
        selectWeaponSlot('dragonfire');
      } else if (e.code === 'Digit2') {
        selectWeaponSlot('plasma_laser');
      } else if (e.code === 'Digit3') {
        selectWeaponSlot('cluster_meteor');
      } else if (e.code === 'Digit4') {
        selectWeaponSlot('holy_radiance');
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      keys[e.code] = false;
    };

    const onMouseMove = (e: MouseEvent) => {
      if (document.pointerLockElement === renderer.domElement) {
        playerRot.yaw -= e.movementX * 0.0025;
        playerRot.pitch -= e.movementY * 0.0022;
        playerRot.pitch = Math.max(-Math.PI / 2.2, Math.min(Math.PI / 2.2, playerRot.pitch));
      }
    };

    const onMouseDown = (e: MouseEvent) => {
      if (document.pointerLockElement !== renderer.domElement) {
        renderer.domElement.requestPointerLock();
        return;
      }
      if (e.button === 0) {
        fireRPG();
      }
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    document.addEventListener('mousemove', onMouseMove);
    renderer.domElement.addEventListener('mousedown', onMouseDown);

    const onPointerLockChange = () => {
      const locked = document.pointerLockElement === renderer.domElement;
      setIsPointerLocked(locked);
    };
    document.addEventListener('pointerlockchange', onPointerLockChange);

    // --- ACTIONS IMPLEMENTATION ---
    function selectWeaponSlot(weaponId: WeaponId) {
      const cur = statsRef.current;
      if (!cur.unlockedWeapons.includes(weaponId)) {
        callbacksRef.current.onChatMessage('Arsenal', `🔒 You need to unlock ${WEAPONS_CATALOG[weaponId]?.name || weaponId} in the shop first!`, '#f87171');
        return;
      }
      const weaponDef = WEAPONS_CATALOG[weaponId];
      if (!weaponDef) return;

      callbacksRef.current.onUpdateStats((prev) => ({
        ...prev,
        selectedWeaponId: weaponId,
        clipSize: weaponDef.clipSize,
        ammoInClip: Math.min(prev.ammoInClip, weaponDef.clipSize),
      }));
      sounds.playEquip();
      callbacksRef.current.onChatMessage('Arsenal', `Equipped: ${weaponDef.name} (${weaponDef.description})`, weaponDef.themeColor);
    }

    function fireRPG() {
      const curStats = statsRef.current;
      if (curStats.isReloading || curStats.ammoInClip <= 0) {
        handleReload();
        return;
      }

      const activeWeapon = WEAPONS_CATALOG[curStats.selectedWeaponId] || WEAPONS_CATALOG.dragonfire;

      // Consume ammo
      callbacksRef.current.onUpdateStats((prev) => ({
        ...prev,
        ammoInClip: prev.ammoInClip - 1,
      }));

      // Play weapon-specific launch sound
      if (activeWeapon.id === 'plasma_laser') {
        sounds.playLaserShot();
      } else if (activeWeapon.id === 'cluster_meteor') {
        sounds.playClusterLaunch();
      } else if (activeWeapon.id === 'holy_radiance') {
        sounds.playHolyBlast();
      } else {
        sounds.playRocketLaunch();
      }

      // Recoil
      recoilOffset = 0.28;
      recoilRot = 0.35;

      // Forward direction
      const forwardDir = new THREE.Vector3(0, 0, -1)
        .applyEuler(new THREE.Euler(playerRot.pitch, playerRot.yaw, 0, 'YXZ'))
        .normalize();

      const spawnPos = camera.position.clone().add(forwardDir.clone().multiplyScalar(1.2));
      spawnPos.y -= 0.15;

      // Spawn projectile(s)
      const count = activeWeapon.projectileCount || 1;
      const spread = activeWeapon.spread || 0;

      for (let pIdx = 0; pIdx < count; pIdx++) {
        const pForward = forwardDir.clone();
        if (spread > 0) {
          pForward.x += (Math.random() - 0.5) * spread;
          pForward.y += (Math.random() - 0.5) * spread * 0.5;
          pForward.z += (Math.random() - 0.5) * spread;
          pForward.normalize();
        }

        const rocketGrp = new THREE.Group();

        if (activeWeapon.id === 'plasma_laser') {
          // Sleek glowing plasma bolt
          const bolt = new THREE.Mesh(
            new THREE.CylinderGeometry(0.08, 0.08, 1.2, 8),
            new THREE.MeshBasicMaterial({ color: 0x06b6d4 })
          );
          bolt.rotation.x = Math.PI / 2;
          rocketGrp.add(bolt);

          const core = new THREE.Mesh(
            new THREE.SphereGeometry(0.18, 8, 8),
            new THREE.MeshBasicMaterial({ color: 0xffffff })
          );
          rocketGrp.add(core);

          const glow = new THREE.PointLight(0x06b6d4, 3.0, 8);
          rocketGrp.add(glow);
        } else if (activeWeapon.id === 'cluster_meteor') {
          // Jagged volcanic meteor orb
          const rock = new THREE.Mesh(
            new THREE.DodecahedronGeometry(0.24, 0),
            new THREE.MeshStandardMaterial({ color: 0x431407, roughness: 0.9 })
          );
          rocketGrp.add(rock);

          const lava = new THREE.Mesh(
            new THREE.SphereGeometry(0.2, 8, 8),
            new THREE.MeshBasicMaterial({ color: 0xea580c })
          );
          rocketGrp.add(lava);

          const glow = new THREE.PointLight(0xff4500, 3.2, 7);
          rocketGrp.add(glow);
        } else if (activeWeapon.id === 'holy_radiance') {
          // Sacred crystalline spear/cruciform missile
          const shaft = new THREE.Mesh(
            new THREE.CylinderGeometry(0.09, 0.04, 1.4, 8),
            new THREE.MeshBasicMaterial({ color: 0xfef08a })
          );
          shaft.rotation.x = Math.PI / 2;
          rocketGrp.add(shaft);

          const crossCrossbar = new THREE.Mesh(
            new THREE.CylinderGeometry(0.05, 0.05, 0.6, 8),
            new THREE.MeshBasicMaterial({ color: 0xffffff })
          );
          crossCrossbar.position.z = -0.3;
          rocketGrp.add(crossCrossbar);

          const glow = new THREE.PointLight(0xfef08a, 4.0, 10);
          rocketGrp.add(glow);
        } else {
          // Classic Dragonfire RPG rocket
          const body = new THREE.Mesh(
            new THREE.CylinderGeometry(0.12, 0.12, 0.7, 8),
            new THREE.MeshStandardMaterial({ color: 0x78350f, metalness: 0.8, roughness: 0.3 })
          );
          body.rotation.x = Math.PI / 2;
          rocketGrp.add(body);

          const head = new THREE.Mesh(
            new THREE.ConeGeometry(0.18, 0.4, 8),
            new THREE.MeshStandardMaterial({ color: 0xf59e0b, metalness: 0.9, roughness: 0.2 })
          );
          head.rotation.x = -Math.PI / 2;
          head.position.z = -0.45;
          rocketGrp.add(head);

          const headGlow = new THREE.PointLight(0xff5500, 2.5, 6);
          headGlow.position.z = -0.45;
          rocketGrp.add(headGlow);
        }

        rocketGrp.position.copy(spawnPos);
        rocketGrp.rotation.set(playerRot.pitch, playerRot.yaw, 0, 'YXZ');
        scene.add(rocketGrp);

        activeRockets.push({
          mesh: rocketGrp,
          pos: spawnPos.clone(),
          vel: pForward.clone().multiplyScalar(activeWeapon.projectileSpeed),
          life: 4.0,
          damage: activeWeapon.damage,
          splashRadius: activeWeapon.splashRadius,
          trailColor1: activeWeapon.trailColor1,
          trailColor2: activeWeapon.trailColor2,
          weaponId: activeWeapon.id,
        });
      }

      // Muzzle flash particle
      triggerExplosion(spawnPos, 1.2, 0, false, activeWeapon.explosionColor);
    }

    function triggerExplosion(
      pos: THREE.Vector3,
      maxRadius: number,
      damage: number,
      dealDamage = true,
      explosionColor = 0xff4500
    ) {
      if (dealDamage) {
        sounds.playExplosion();
      }

      // Expanding Energy Sphere
      const expMat = new THREE.MeshBasicMaterial({
        color: explosionColor,
        transparent: true,
        opacity: 0.9,
      });
      const expMesh = new THREE.Mesh(new THREE.SphereGeometry(1, 16, 16), expMat);
      expMesh.position.copy(pos);
      scene.add(expMesh);

      const expLight = new THREE.PointLight(explosionColor, 3.8, maxRadius * 2.5);
      expLight.position.copy(pos);
      scene.add(expLight);

      activeExplosions.push({
        mesh: expMesh,
        light: expLight,
        scale: 0.2,
        maxScale: maxRadius,
        opacity: 0.9,
        color: explosionColor,
      });

      // Flying smoke / sparks
      for (let s = 0; s < 10; s++) {
        const smGeo = new THREE.BoxGeometry(0.3, 0.3, 0.3);
        const smMat = new THREE.MeshBasicMaterial({
          color: Math.random() > 0.5 ? explosionColor : 0x475569,
          transparent: true,
          opacity: 0.8,
        });
        const smMesh = new THREE.Mesh(smGeo, smMat);
        smMesh.position.copy(pos);
        scene.add(smMesh);

        activeSmokes.push({
          mesh: smMesh,
          vel: new THREE.Vector3(
            (Math.random() - 0.5) * 12,
            Math.random() * 8 + 2,
            (Math.random() - 0.5) * 12
          ),
          life: 0,
          maxLife: 0.6 + Math.random() * 0.4,
        });
      }

      if (!dealDamage) return;

      // Camera shake
      camera.position.x += (Math.random() - 0.5) * 0.4;
      camera.position.y += (Math.random() - 0.5) * 0.4;

      // Area of Effect Damage on Goblins
      activeGoblins.forEach((goblin) => {
        const gPos = goblin.mesh.position.clone();
        gPos.y += 1.2;
        const dist = pos.distanceTo(gPos);
        if (dist <= maxRadius) {
          const falloff = 1 - dist / maxRadius;
          const actualDmg = Math.round(damage * Math.max(0.4, falloff));
          applyDamageToGoblin(goblin, actualDmg, pos);
        }
      });
    }

    function applyDamageToGoblin(goblin: ActiveGoblin, amount: number, hitSourcePos: THREE.Vector3) {
      goblin.health -= amount;
      goblin.hitFlashTime = 0.2; // flash red
      sounds.playGoblinHit();

      // Knockback away from explosion
      const knockDir = goblin.mesh.position.clone().sub(hitSourcePos).normalize();
      knockDir.y = 0.5;
      goblin.mesh.position.add(knockDir.multiplyScalar(2.0));

      // 2D Floating screen damage numbers
      const screenPos = getScreenPosition(goblin.mesh.position.clone().add(new THREE.Vector3(0, 2.5, 0)));
      const isCrit = amount > 140;
      callbacksRef.current.onSpawnDamage(amount, isCrit, screenPos);

      // Check death
      if (goblin.health <= 0) {
        scene.remove(goblin.mesh);
        const idx = activeGoblins.indexOf(goblin);
        if (idx !== -1) {
          activeGoblins.splice(idx, 1);
        }

        const wasBoss = goblin.isBoss;
        callbacksRef.current.onGoblinKilled(wasBoss);
        callbacksRef.current.onQuestProgress();

        // Check Victory Condition if this was the Boss!
        if (wasBoss) {
          sounds.playVictoryFanfare();
          callbacksRef.current.onUpdateStats((prev) => ({
            ...prev,
            gameWon: true,
          }));
          callbacksRef.current.onChatMessage(
            'VICTORY',
            '🏆 The Goblin Warlord has been slain! The Medieval Kingdom is saved!',
            '#fbbf24'
          );
        }

        // Spawn more regular horde if thinned out and boss not dead or continuing endless mode
        if (activeGoblins.length <= 2) {
          // If boss hasn't appeared yet and player killed enough goblins, spawn boss
          const curS = statsRef.current;
          const shouldSpawnBoss = !curS.bossAppeared && curS.kills >= 12;
          if (shouldSpawnBoss) {
            callbacksRef.current.onUpdateStats((prev) => ({ ...prev, bossAppeared: true }));
            sounds.playBossRoar();
            callbacksRef.current.onChatMessage(
              'WARNING',
              '⚠ A terrifying ROAR shakes the city! THE GOBLIN WARLORD HAS ARRIVED!',
              '#ef4444'
            );
            spawnGoblinWave(5, true);
          } else {
            spawnGoblinWave(6, false);
            callbacksRef.current.onChatMessage('Quest System', '⚔ A new wave of Goblin Warriors approaches!', '#eab308');
          }
        }
      }
    }

    function getScreenPosition(worldPos: THREE.Vector3): { x: number; y: number } {
      const p = worldPos.clone().project(camera);
      const hw = container!.clientWidth / 2;
      const hh = container!.clientHeight / 2;
      return {
        x: p.x * hw + hw,
        y: -(p.y * hh) + hh,
      };
    }

    function handleReload() {
      const cur = statsRef.current;
      if (cur.isReloading || cur.ammoInClip >= cur.clipSize || cur.ammoReserve <= 0) return;

      callbacksRef.current.onUpdateStats((prev) => ({ ...prev, isReloading: true, reloadProgress: 0 }));
      sounds.playReload();

      let prog = 0;
      const interval = setInterval(() => {
        prog += 0.2;
        callbacksRef.current.onUpdateStats((prev) => ({ ...prev, reloadProgress: Math.min(1, prog) }));
        if (prog >= 1) {
          clearInterval(interval);
          callbacksRef.current.onUpdateStats((prev) => {
            const needed = prev.clipSize - prev.ammoInClip;
            const take = Math.min(needed, prev.ammoReserve);
            return {
              ...prev,
              ammoInClip: prev.ammoInClip + take,
              ammoReserve: prev.ammoReserve - take,
              isReloading: false,
              reloadProgress: 0,
            };
          });
        }
      }, 200);
    }

    function handleDragonSwipe() {
      const cur = statsRef.current;
      if (cur.mana < 25) return;

      callbacksRef.current.onUpdateStats((prev) => ({ ...prev, mana: prev.mana - 25 }));
      sounds.playDragonSwipe();

      // Flame wave in front of player
      const fwd = new THREE.Vector3(0, 0, -1).applyEuler(new THREE.Euler(0, playerRot.yaw, 0, 'YXZ'));
      const swipePos = camera.position.clone().add(fwd.multiplyScalar(4));
      triggerExplosion(swipePos, 8.5, 260, true);
    }

    function handleDragonDash() {
      const cur = statsRef.current;
      if (cur.mana < 15) return;

      callbacksRef.current.onUpdateStats((prev) => ({ ...prev, mana: prev.mana - 15 }));
      sounds.playRocketLaunch();

      const fwd = new THREE.Vector3(0, 0, -1).applyEuler(new THREE.Euler(0, playerRot.yaw, 0, 'YXZ'));
      camera.position.add(fwd.multiplyScalar(8.0));
    }

    function handleDrinkPotion() {
      const cur = statsRef.current;
      if (cur.potions <= 0) return;

      callbacksRef.current.onUpdateStats((prev) => ({
        ...prev,
        potions: prev.potions - 1,
        hp: Math.min(prev.maxHp, prev.hp + 60),
        mana: Math.min(prev.maxMana, prev.mana + 50),
      }));
      sounds.playPotionDrink();
      callbacksRef.current.onChatMessage('System', 'Consumed Mana Potion (+60 HP, +50 Mana)', '#38bdf8');
    }

    // --- GAME LOOP ---
    let lastTime = performance.now();
    let animId: number;

    const animate = () => {
      animId = requestAnimationFrame(animate);

      const now = performance.now();
      const delta = Math.min((now - lastTime) / 1000, 0.1);
      lastTime = now;

      // Handle external skill trigger from Hotbar click
      if (activeSkillRef.current) {
        const skill = activeSkillRef.current;
        onClearSkillTrigger();
        if (skill === 'swipe') handleDragonSwipe();
        if (skill === 'dash') handleDragonDash();
        if (skill === 'potion') handleDrinkPotion();
        if (skill === 'reload') handleReload();
        if (skill === 'fire') fireRPG();
      }

      // --- PLAYER MOVEMENT & CAMERA ROTATION ---
      const moveVec = new THREE.Vector3();
      if (keys['KeyW']) moveVec.z -= 1;
      if (keys['KeyS']) moveVec.z += 1;
      if (keys['KeyA']) moveVec.x -= 1;
      if (keys['KeyD']) moveVec.x += 1;

      const isMoving = moveVec.lengthSq() > 0;
      if (isMoving) {
        moveVec.normalize();
        const moveSpeed = keys['ShiftLeft'] ? 13.0 : 8.5;
        // Transform direction relative to yaw
        const forward = new THREE.Vector3(0, 0, -1).applyAxisAngle(new THREE.Vector3(0, 1, 0), playerRot.yaw);
        const right = new THREE.Vector3(1, 0, 0).applyAxisAngle(new THREE.Vector3(0, 1, 0), playerRot.yaw);

        const worldMove = forward.multiplyScalar(-moveVec.z).add(right.multiplyScalar(moveVec.x)).normalize();
        camera.position.addScaledVector(worldMove, moveSpeed * delta);

        // Keep player on street boundaries
        camera.position.x = Math.max(-12, Math.min(12, camera.position.x));
        camera.position.z = Math.max(-110, Math.min(110, camera.position.z));

        // Walking head/weapon bobbing
        walkBobTimer += delta * (keys['ShiftLeft'] ? 16 : 11);
      }

      // Jump / Gravity
      if (keys['Space'] && isGrounded) {
        playerVel.y = 8.5;
        isGrounded = false;
      }
      if (!isGrounded) {
        playerVel.y -= 24 * delta; // Gravity
        camera.position.y += playerVel.y * delta;
        if (camera.position.y <= 2.0) {
          camera.position.y = 2.0;
          playerVel.y = 0;
          isGrounded = true;
        }
      }

      // Apply camera rotation
      camera.rotation.set(playerRot.pitch, playerRot.yaw, 0, 'YXZ');

      // --- FIRST-PERSON WEAPON MOTION DYNAMICS ---
      // Sync 3D weapon rig appearance to currently equipped weapon
      syncWeaponVisuals(statsRef.current.selectedWeaponId);

      // 1. Idle breathing
      const breatheY = Math.sin(now * 0.002) * 0.008;
      const breatheX = Math.cos(now * 0.001) * 0.005;

      // 2. Walk sway
      const bobY = isMoving ? Math.sin(walkBobTimer) * 0.03 : 0;
      const bobX = isMoving ? Math.cos(walkBobTimer * 0.5) * 0.03 : 0;

      // 3. Recoil recovery
      recoilOffset = THREE.MathUtils.lerp(recoilOffset, 0, delta * 12);
      recoilRot = THREE.MathUtils.lerp(recoilRot, 0, delta * 10);

      weaponRig.position.set(
        0.48 + breatheX + bobX,
        -0.36 + breatheY + bobY,
        -0.85 + recoilOffset
      );
      weaponRig.rotation.set(recoilRot, 0, 0);

      // Flickering dragon flame on iron sight
      sightLight.intensity = 1.2 + Math.sin(now * 0.02) * 0.5;

      // --- UPDATE ROCKETS ---
      for (let i = activeRockets.length - 1; i >= 0; i--) {
        const r = activeRockets[i];
        r.life -= delta;
        r.pos.addScaledVector(r.vel, delta);
        r.mesh.position.copy(r.pos);

        // Rocket smoke trail with weapon-specific colors
        if (Math.random() > 0.3) {
          const trailGeo = new THREE.BoxGeometry(0.18, 0.18, 0.18);
          const trailMat = new THREE.MeshBasicMaterial({
            color: Math.random() > 0.5 ? r.trailColor1 : r.trailColor2,
            transparent: true,
            opacity: 0.8,
          });
          const trailMesh = new THREE.Mesh(trailGeo, trailMat);
          trailMesh.position.copy(r.pos);
          scene.add(trailMesh);

          activeSmokes.push({
            mesh: trailMesh,
            vel: new THREE.Vector3((Math.random() - 0.5) * 2, (Math.random() - 0.5) * 2, (Math.random() - 0.5) * 2),
            life: 0,
            maxLife: 0.35,
          });
        }

        // Collision with ground or buildings or goblins
        let collided = false;
        if (r.pos.y <= 0.2 || r.life <= 0) {
          collided = true;
        } else {
          // Check collision with any goblin
          for (const g of activeGoblins) {
            if (r.pos.distanceTo(g.mesh.position) < 2.0) {
              collided = true;
              break;
            }
          }
        }

        if (collided) {
          const weaponDef = WEAPONS_CATALOG[r.weaponId] || WEAPONS_CATALOG.dragonfire;
          triggerExplosion(r.pos, r.splashRadius, r.damage, true, weaponDef.explosionColor);
          scene.remove(r.mesh);
          activeRockets.splice(i, 1);
        }
      }

      // --- UPDATE EXPLOSIONS ---
      for (let i = activeExplosions.length - 1; i >= 0; i--) {
        const exp = activeExplosions[i];
        exp.scale += (exp.maxScale - exp.scale) * delta * 15;
        exp.mesh.scale.set(exp.scale, exp.scale, exp.scale);
        exp.opacity -= delta * 2.2;
        (exp.mesh.material as THREE.MeshBasicMaterial).opacity = Math.max(0, exp.opacity);
        exp.light.intensity = exp.opacity * 3.5;

        if (exp.opacity <= 0) {
          scene.remove(exp.mesh);
          scene.remove(exp.light);
          activeExplosions.splice(i, 1);
        }
      }

      // --- UPDATE SMOKE PARTICLES ---
      for (let i = activeSmokes.length - 1; i >= 0; i--) {
        const sm = activeSmokes[i];
        sm.life += delta;
        sm.mesh.position.addScaledVector(sm.vel, delta);
        const progress = sm.life / sm.maxLife;
        (sm.mesh.material as THREE.MeshBasicMaterial).opacity = (1 - progress) * 0.8;
        sm.mesh.scale.multiplyScalar(0.97);

        if (progress >= 1) {
          scene.remove(sm.mesh);
          activeSmokes.splice(i, 1);
        }
      }

      // --- UPDATE GOBLINS (Walking AI & Animation) ---
      activeGoblins.forEach((g) => {
        // Look towards player
        g.mesh.lookAt(camera.position.x, 0, camera.position.z);

        // Run towards player
        const distToPlayer = g.mesh.position.distanceTo(camera.position);
        if (distToPlayer > 2.2) {
          const dir = camera.position.clone().sub(g.mesh.position).normalize();
          g.mesh.position.x += dir.x * g.speed * delta;
          g.mesh.position.z += dir.z * g.speed * delta;

          // Leg running swing animation
          const legAngle = Math.sin(now * 0.01 * g.speed) * 0.6;
          g.leftLeg.rotation.x = legAngle;
          g.rightLeg.rotation.x = -legAngle;
          g.leftArm.rotation.x = -legAngle;
          g.rightArm.rotation.x = legAngle;
        } else {
          // Attack player
          g.attackCooldown -= delta;
          if (g.attackCooldown <= 0) {
            g.attackCooldown = 1.4;
            const dmg = g.isBoss ? 28 : 14;
            callbacksRef.current.onUpdateStats((prev) => ({
              ...prev,
              hp: Math.max(0, prev.hp - dmg),
            }));
            sounds.playGoblinHit();
          }
        }

        // Damage flash reaction
        if (g.hitFlashTime > 0) {
          g.hitFlashTime -= delta;
        }
      });

      // Float quest giver mark
      qMarkSprite.position.y = 3.6 + Math.sin(now * 0.004) * 0.2;

      // Slow drift clouds
      clouds.forEach((cl) => {
        cl.position.x += delta * 2.0;
        if (cl.position.x > 150) cl.position.x = -150;
      });

      renderer.render(scene, camera);
    };

    animate();

    // Resize handling
    const handleResize = () => {
      if (!container) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      document.removeEventListener('mousemove', onMouseMove);
      renderer.domElement.removeEventListener('mousedown', onMouseDown);
      document.removeEventListener('pointerlockchange', onPointerLockChange);
      window.removeEventListener('resize', handleResize);
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  return <div ref={mountRef} className="w-full h-full absolute inset-0 cursor-crosshair" />;
};
