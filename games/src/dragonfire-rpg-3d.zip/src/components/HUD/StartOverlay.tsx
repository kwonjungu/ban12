import React from 'react';
import { Play, MousePointer, Flame, ShieldAlert } from 'lucide-react';
import { ASSETS } from '../../assets';

interface StartOverlayProps {
  onStart: () => void;
}

export const StartOverlay: React.FC<StartOverlayProps> = ({ onStart }) => {
  return (
    <div
      onClick={onStart}
      className="absolute inset-0 bg-slate-950/70 backdrop-blur-xs z-40 flex items-center justify-center p-4 cursor-pointer select-none"
    >
      <div className="bg-slate-900/95 border-2 border-amber-500 rounded-xl max-w-md w-full p-6 text-center text-white shadow-[0_0_40px_rgba(245,158,11,0.5)]">
        {/* Dragonfire RPG Emblem */}
        <div className="w-20 h-20 mx-auto rounded-lg overflow-hidden border-2 border-amber-400 p-1 bg-slate-950 mb-3 shadow-[0_0_20px_rgba(245,158,11,0.6)]">
          <img
            src={ASSETS.dragonfireRpg}
            alt="Dragonfire RPG"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
        </div>

        <h1 className="text-2xl sm:text-3xl font-black text-amber-400 font-['Nunito'] tracking-wider mb-1">
          DRAGONFIRE RPG REPEATER
        </h1>
        <p className="text-xs font-mono text-amber-200/80 mb-4">
          ROBLOX MEDIEVAL FANTASY FPS SURVIVAL
        </p>

        <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 text-xs font-mono text-slate-300 mb-5 space-y-1 text-left">
          <div className="text-amber-300 font-bold mb-1 flex items-center gap-1.5">
            <Flame className="w-3.5 h-3.5 text-orange-500" />
            <span>MISSION OBJECTIVE:</span>
          </div>
          <div>• Repel the Lv 20 Goblin Horde advancing into the town.</div>
          <div>• Fire high-explosive Dragonfire rockets with Left Mouse Click.</div>
          <div>• Press [Q] for Dragon Swipe flame wave, [F] for Mana Potion.</div>
        </div>

        <button className="w-full bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-sm sm:text-base py-3 rounded-lg shadow-xl flex items-center justify-center gap-2 animate-pulse">
          <Play className="w-5 h-5 fill-slate-950" />
          <span>CLICK TO ENGAGE BATTLE (LOCK MOUSE)</span>
        </button>

        <div className="mt-3 text-[11px] text-slate-400 font-mono flex items-center justify-center gap-1">
          <MousePointer className="w-3 h-3" />
          <span>Press ESC anytime to free mouse cursor</span>
        </div>
      </div>
    </div>
  );
};
