import React from 'react';
import { Compass, Settings, ShieldAlert } from 'lucide-react';

interface MinimapProps {
  kills: number;
}

export const Minimap: React.FC<MinimapProps> = ({ kills }) => {
  return (
    <div id="game-minimap" className="relative w-28 h-28 sm:w-32 sm:h-32 bg-emerald-900/90 border-2 border-slate-900 rounded-sm overflow-hidden shadow-xl select-none pointer-events-auto">
      {/* Map Content Background */}
      <div className="absolute inset-0 bg-[#3f6212] overflow-hidden">
        {/* Cobblestone town street */}
        <div className="absolute top-0 bottom-0 left-1/2 -translate-x-1/2 w-8 bg-slate-600 border-x border-slate-500/50" />
        {/* Town square */}
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-14 h-12 bg-slate-500/80 rounded-sm border border-slate-400/40" />

        {/* Quest markers (Yellow '?') */}
        <div className="absolute top-6 left-1/3 text-amber-300 text-xs font-black drop-shadow animate-bounce">
          ?
        </div>
        <div className="absolute top-12 right-4 text-amber-300 text-xs font-black drop-shadow">
          ?
        </div>

        {/* Goblin enemies (Red dots / skulls) */}
        <div className="absolute top-4 left-1/2 -translate-x-1/2 w-2.5 h-2.5 bg-red-600 rounded-full border border-white animate-pulse" />
        <div className="absolute top-8 left-[45%] w-2 h-2 bg-red-500 rounded-full border border-white" />
        <div className="absolute top-7 left-[55%] w-2 h-2 bg-red-500 rounded-full border border-white" />

        {/* Player Indicator (Blue arrow in center pointing up) */}
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 -translate-y-1/2 w-0 h-0 border-l-[6px] border-l-transparent border-r-[6px] border-r-transparent border-b-[10px] border-b-sky-400 drop-shadow-[0_0_4px_#38bdf8]" />

        {/* Quests label */}
        <div className="absolute bottom-1 left-1/2 -translate-x-1/2 bg-slate-900/80 text-[8px] text-amber-300 font-bold px-1.5 py-0.2 rounded-full border border-amber-400/30 whitespace-nowrap">
          Quests
        </div>
      </div>

      {/* Top Controls Overlay */}
      <div className="absolute top-1 right-1 flex flex-col gap-1">
        <div className="bg-slate-900/80 p-0.5 rounded border border-slate-700 text-slate-300 hover:text-white cursor-pointer">
          <Settings className="w-2.5 h-2.5" />
        </div>
      </div>

      <div className="absolute top-1 left-1 flex items-center gap-0.5 bg-slate-900/80 px-1 py-0.2 rounded text-[8px] font-bold text-slate-200">
        <Compass className="w-2.5 h-2.5 text-sky-400" />
        <span>N</span>
      </div>
    </div>
  );
};
