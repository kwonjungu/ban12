import React from 'react';
import { Skull, RotateCcw } from 'lucide-react';
import { PlayerStats } from '../../types';

interface GameOverModalProps {
  stats: PlayerStats;
  onRespawn: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({ stats, onRespawn }) => {
  return (
    <div className="fixed inset-0 bg-red-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4 select-none animate-fadeIn">
      <div className="bg-slate-900 border-2 border-red-500 rounded-lg max-w-md w-full p-6 text-center text-white shadow-[0_0_30px_rgba(239,68,68,0.5)]">
        <div className="w-16 h-16 bg-red-500/20 rounded-full mx-auto flex items-center justify-center border border-red-500 mb-3 animate-pulse">
          <Skull className="w-10 h-10 text-red-500" />
        </div>

        <h2 className="text-2xl font-black text-red-400 font-['Nunito'] tracking-wider mb-1">
          YOU WERE OVERWHELMED!
        </h2>
        <p className="text-xs text-slate-300 font-mono mb-4">
          The Goblin Horde breached the town defenses.
        </p>

        <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1.5 text-xs font-mono mb-5 text-left">
          <div className="flex justify-between">
            <span className="text-slate-400">Goblins Defeated:</span>
            <span className="font-bold text-emerald-400">{stats.kills}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">Total Score:</span>
            <span className="font-bold text-amber-400">{stats.score}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">Gold Plundered:</span>
            <span className="font-bold text-yellow-300">${stats.gold}</span>
          </div>
        </div>

        <button
          onClick={onRespawn}
          className="w-full bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 hover:to-amber-500 text-white font-black text-sm py-3 rounded shadow-lg flex items-center justify-center gap-2 transition-transform active:scale-95"
        >
          <RotateCcw className="w-4 h-4" />
          <span>RESPAWN IN TOWN</span>
        </button>
      </div>
    </div>
  );
};
