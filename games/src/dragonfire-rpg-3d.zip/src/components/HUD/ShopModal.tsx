import React from 'react';
import { X, Sparkles, Heart, Crosshair, Check, Lock } from 'lucide-react';
import { PlayerStats, WeaponId } from '../../types';
import { ASSETS } from '../../assets';
import { WEAPONS_CATALOG } from '../../weapons';
import { sounds } from '../../audio';

interface ShopModalProps {
  stats: PlayerStats;
  onClose: () => void;
  onUpdateStats: (updater: (prev: PlayerStats) => PlayerStats) => void;
  onSelectWeapon: (weaponId: WeaponId) => void;
}

export const ShopModal: React.FC<ShopModalProps> = ({ stats, onClose, onUpdateStats, onSelectWeapon }) => {
  const buyAmmo = () => {
    if (stats.gold < 50) return;
    onUpdateStats((prev) => ({
      ...prev,
      gold: prev.gold - 50,
      ammoReserve: Math.min(prev.maxReserve, prev.ammoReserve + 50),
    }));
    sounds.playReload();
  };

  const buyPotion = () => {
    if (stats.gold < 40) return;
    onUpdateStats((prev) => ({
      ...prev,
      gold: prev.gold - 40,
      potions: prev.potions + 2,
    }));
    sounds.playPotionDrink();
  };

  const healHP = () => {
    if (stats.gold < 60 || stats.hp >= stats.maxHp) return;
    onUpdateStats((prev) => ({
      ...prev,
      gold: prev.gold - 60,
      hp: prev.maxHp,
    }));
    sounds.playPotionDrink();
  };

  const buyOrEquipWeapon = (weaponId: WeaponId) => {
    const weapon = WEAPONS_CATALOG[weaponId];
    const isUnlocked = stats.unlockedWeapons.includes(weaponId);

    if (isUnlocked) {
      onSelectWeapon(weaponId);
      sounds.playReload();
      return;
    }

    if (stats.gold < weapon.cost) return;

    onUpdateStats((prev) => ({
      ...prev,
      gold: prev.gold - weapon.cost,
      unlockedWeapons: [...prev.unlockedWeapons, weaponId],
      selectedWeaponId: weaponId,
      clipSize: weapon.clipSize,
      ammoInClip: weapon.clipSize,
      ammoReserve: weapon.maxReserve,
      maxReserve: weapon.maxReserve,
    }));
    sounds.playQuestComplete();
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4 select-none">
      <div className="bg-slate-900 border-2 border-amber-500/80 rounded-lg max-w-2xl w-full p-5 text-white shadow-[0_0_30px_rgba(245,158,11,0.3)] max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex justify-between items-center border-b border-slate-800 pb-3 mb-4">
          <div className="flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-amber-400" />
            <h2 className="text-xl font-black text-amber-300 font-['Nunito'] tracking-wide">
              MEDIEVAL ARMORY & WEAPONS SHOP
            </h2>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-amber-400 font-mono font-bold text-sm bg-slate-950 px-2.5 py-1 rounded border border-amber-500/30">
              Gold: ${stats.gold}
            </span>
            <button
              onClick={onClose}
              className="text-slate-400 hover:text-white p-1 rounded-md transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Weapons Catalog Section */}
        <div className="mb-5">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-black text-cyan-300 uppercase tracking-wider flex items-center gap-1.5">
              <Crosshair className="w-4 h-4 text-cyan-400" />
              <span>총기 라인업 (숫자키 1, 2, 3, 4로 즉시 전환 가능)</span>
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {Object.values(WEAPONS_CATALOG).map((w) => {
              const isUnlocked = stats.unlockedWeapons.includes(w.id);
              const isEquipped = stats.selectedWeaponId === w.id;

              return (
                <div
                  key={w.id}
                  className={`p-2.5 rounded-lg border transition-all flex flex-col justify-between ${
                    isEquipped
                      ? 'bg-amber-950/40 border-amber-400 shadow-[0_0_12px_rgba(245,158,11,0.3)]'
                      : isUnlocked
                      ? 'bg-slate-950/70 border-slate-700 hover:border-slate-500'
                      : 'bg-slate-950/40 border-slate-800'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-14 h-14 rounded bg-slate-900 border border-slate-700 overflow-hidden flex-shrink-0 relative">
                      <img
                        src={w.icon}
                        alt={w.name}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                      <span className="absolute top-0.5 left-1 text-[10px] font-mono font-black text-amber-300 bg-black/70 px-1 rounded-xs">
                        [{w.slotNumber}]
                      </span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-bold text-xs text-white truncate flex items-center gap-1">
                        <span>{w.name}</span>
                        {isEquipped && (
                          <span className="bg-amber-400 text-slate-950 text-[9px] font-black px-1.5 py-0.2 rounded-xs">
                            장착중
                          </span>
                        )}
                      </div>
                      <div className="text-[10px] text-slate-400 line-clamp-2 mt-0.5">
                        {w.description}
                      </div>
                      <div className="flex items-center gap-2 mt-1 text-[10px] font-mono">
                        <span className="text-amber-400 font-bold">DMG: {w.damage}</span>
                        <span className="text-slate-400">범위: {w.splashRadius}m</span>
                        <span className="text-cyan-400">탄창: {w.clipSize}</span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-2 pt-2 border-t border-slate-800 flex justify-end">
                    {isEquipped ? (
                      <div className="flex items-center gap-1 text-xs font-bold text-amber-400">
                        <Check className="w-3.5 h-3.5" />
                        <span>현재 장착됨</span>
                      </div>
                    ) : isUnlocked ? (
                      <button
                        onClick={() => buyOrEquipWeapon(w.id)}
                        className="bg-slate-800 hover:bg-slate-700 text-amber-300 font-bold text-xs px-3 py-1 rounded border border-slate-600 transition-colors"
                      >
                        무기 장착하기
                      </button>
                    ) : (
                      <button
                        onClick={() => buyOrEquipWeapon(w.id)}
                        disabled={stats.gold < w.cost}
                        className="bg-amber-500 hover:bg-amber-400 disabled:opacity-40 text-slate-950 font-black text-xs px-3.5 py-1 rounded flex items-center gap-1.5"
                      >
                        <Lock className="w-3 h-3" />
                        <span>해금 구매 (${w.cost})</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Consumables and Supplies */}
        <h3 className="text-xs font-black text-slate-400 uppercase tracking-wider mb-2">
          소모품 및 보급
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 mb-4">
          {/* Ammo Cache */}
          <div className="bg-slate-950/80 p-2.5 rounded border border-slate-800 flex flex-col justify-between">
            <div className="flex items-center gap-2 mb-2">
              <Crosshair className="w-5 h-5 text-amber-400" />
              <div>
                <div className="font-bold text-xs text-white">탄약 보급 (+50)</div>
                <div className="text-[10px] text-slate-400">모든 총기 공용 예비탄</div>
              </div>
            </div>
            <button
              onClick={buyAmmo}
              disabled={stats.gold < 50 || stats.ammoReserve >= stats.maxReserve}
              className="w-full bg-amber-500 hover:bg-amber-400 disabled:opacity-40 text-slate-950 font-black text-xs py-1.5 rounded"
            >
              $50 구매
            </button>
          </div>

          {/* Mana Potions */}
          <div className="bg-slate-950/80 p-2.5 rounded border border-slate-800 flex flex-col justify-between">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-6 h-6 rounded overflow-hidden">
                <img src={ASSETS.potionMana} alt="Potion" className="w-full h-full object-cover" />
              </div>
              <div>
                <div className="font-bold text-xs text-white">마나 물약 x2</div>
                <div className="text-[10px] text-slate-400">HP & 마나 50 회복</div>
              </div>
            </div>
            <button
              onClick={buyPotion}
              disabled={stats.gold < 40}
              className="w-full bg-sky-500 hover:bg-sky-400 disabled:opacity-40 text-slate-950 font-black text-xs py-1.5 rounded"
            >
              $40 구매
            </button>
          </div>

          {/* Healing Blessing */}
          <div className="bg-slate-950/80 p-2.5 rounded border border-slate-800 flex flex-col justify-between">
            <div className="flex items-center gap-2 mb-2">
              <Heart className="w-5 h-5 text-emerald-400" />
              <div>
                <div className="font-bold text-xs text-white">완전 회복 축복</div>
                <div className="text-[10px] text-slate-400">체력 100% 즉시 충전</div>
              </div>
            </div>
            <button
              onClick={healHP}
              disabled={stats.gold < 60 || stats.hp >= stats.maxHp}
              className="w-full bg-emerald-500 hover:bg-emerald-400 disabled:opacity-40 text-slate-950 font-black text-xs py-1.5 rounded"
            >
              $60 치유
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="flex justify-end pt-2 border-t border-slate-800">
          <button
            onClick={onClose}
            className="bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs px-4 py-2 rounded"
          >
            닫기 (Close Shop)
          </button>
        </div>
      </div>
    </div>
  );
};
