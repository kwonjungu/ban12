import React from 'react';

export const Crosshair: React.FC = () => {
  return (
    <div
      id="game-crosshair"
      className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none z-20 flex items-center justify-center select-none"
    >
      {/* Outer RPG Target Ring */}
      <div className="relative w-14 h-14 sm:w-16 sm:h-16 flex items-center justify-center">
        {/* Circular reticle with dashed ticks */}
        <div className="absolute inset-0 rounded-full border border-white/60 border-dashed animate-[spin_24s_linear_infinite]" />

        {/* 4 Directional Brackets */}
        <div className="absolute top-0 w-2 h-1 bg-white/90 shadow-[0_0_4px_rgba(255,255,255,0.8)]" />
        <div className="absolute bottom-0 w-2 h-1 bg-white/90 shadow-[0_0_4px_rgba(255,255,255,0.8)]" />
        <div className="absolute left-0 w-1 h-2 bg-white/90 shadow-[0_0_4px_rgba(255,255,255,0.8)]" />
        <div className="absolute right-0 w-1 h-2 bg-white/90 shadow-[0_0_4px_rgba(255,255,255,0.8)]" />

        {/* Center Precision Dot */}
        <div className="w-1.5 h-1.5 rounded-full bg-amber-400 shadow-[0_0_6px_#f59e0b]" />
      </div>
    </div>
  );
};
