import React from 'react';
import { PlayerStats, WeaponId } from '../../types';
import { ASSETS } from '../../assets';
import { WEAPONS_CATALOG } from '../../weapons';
import { Shield, Sparkles, Flame, RotateCcw, Lock } from 'lucide-react';

interface HotbarProps {
  stats: PlayerStats;
  onTriggerSkill: (skillId: string) => void;
  onSelectWeapon: (weaponId: WeaponId) => void;
}

export const Hotbar: React.FC<HotbarProps> = ({ stats, onTriggerSkill, onSelectWeapon }) => {
  const currentWeapon = WEAPONS_CATALOG[stats.selectedWeaponId] || WEAPONS_CATALOG.dragonfire;

  return (
    <div id="game-hotbar-container" className="flex flex-col items-center gap-1.5 select-none pointer-events-auto">
      {/* Upper Active Skills & Equipped Weapon */}
      <div className="flex items-end gap-2 bg-slate-950/70 p-1.5 rounded-md border border-slate-700/60 backdrop-blur-sm shadow-2xl">
        {/* Skill [Q]: Dragon Swipe */}
        <button
          onClick={() => onTriggerSkill('swipe')}
          className="group relative flex flex-col items-center bg-slate-900/90 border-2 border-amber-600/80 hover:border-amber-400 rounded-sm p-1 transition-transform active:scale-95 focus:outline-none"
          title="Dragon Swipe [Q] (25 Mana)"
        >
          <div className="text-[10px] font-extrabold text-amber-300 font-['Nunito'] mb-0.5">Dragon Swipe</div>
          <div className="w-11 h-11 sm:w-13 sm:h-13 rounded-sm overflow-hidden relative border border-slate-700">
            <img
              src={ASSETS.skillDragonSwipe}
              alt="Dragon Swipe"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform"
            />
            <span className="absolute bottom-0.5 right-0.5 text-[9px] font-bold text-amber-300 bg-black/70 px-1 rounded-xs">
              25M
            </span>
          </div>
          <div className="mt-0.5 bg-slate-800 text-[10px] font-black text-amber-400 px-1.5 py-0.2 rounded-xs border border-slate-600 font-mono">
            [Q]
          </div>
        </button>

        {/* Skill [E]: Stance / Dragon Dash */}
        <button
          onClick={() => onTriggerSkill('dash')}
          className="group relative flex flex-col items-center bg-slate-900/90 border-2 border-orange-600/80 hover:border-orange-400 rounded-sm p-1 transition-transform active:scale-95 focus:outline-none"
          title="Dragon Dash [E] (15 Mana)"
        >
          <div className="text-[10px] font-extrabold text-orange-300 font-['Nunito'] mb-0.5">Stance</div>
          <div className="w-11 h-11 sm:w-13 sm:h-13 bg-gradient-to-br from-amber-900 via-orange-800 to-red-900 rounded-sm overflow-hidden relative border border-slate-700 flex items-center justify-center">
            <Flame className="w-6 h-6 text-amber-300 drop-shadow-[0_0_8px_#f59e0b]" />
            <span className="absolute bottom-0.5 right-0.5 text-[9px] font-bold text-orange-300 bg-black/70 px-1 rounded-xs">
              15M
            </span>
          </div>
          <div className="mt-0.5 bg-slate-800 text-[10px] font-black text-orange-400 px-1.5 py-0.2 rounded-xs border border-slate-600 font-mono">
            [E]
          </div>
        </button>

        {/* Skill [C]: Guard Stance */}
        <button
          onClick={() => onTriggerSkill('dash')}
          className="group relative flex flex-col items-center bg-slate-900/90 border-2 border-slate-500 hover:border-slate-300 rounded-sm p-1 transition-transform active:scale-95 focus:outline-none"
          title="Guard Stance"
        >
          <div className="text-[10px] font-extrabold text-slate-300 font-['Nunito'] mb-0.5">Stance</div>
          <div className="w-11 h-11 sm:w-13 sm:h-13 bg-gradient-to-br from-slate-800 to-slate-900 rounded-sm overflow-hidden relative border border-slate-700 flex items-center justify-center">
            <Shield className="w-6 h-6 text-slate-300 drop-shadow" />
            <span className="absolute bottom-0.5 right-0.5 text-[9px] font-bold text-slate-400 bg-black/70 px-1 rounded-xs">
              0M
            </span>
          </div>
          <div className="mt-0.5 bg-slate-800 text-[10px] font-black text-slate-300 px-1.5 py-0.2 rounded-xs border border-slate-600 font-mono">
            [C]
          </div>
        </button>

        {/* Skill [F]: Mana Potion */}
        <button
          onClick={() => onTriggerSkill('potion')}
          className="group relative flex flex-col items-center bg-slate-900/90 border-2 border-sky-500/80 hover:border-sky-300 rounded-sm p-1 transition-transform active:scale-95 focus:outline-none"
          title="Drink Mana Potion [F]"
        >
          <div className="text-[10px] font-extrabold text-sky-300 font-['Nunito'] mb-0.5">Mana Potion</div>
          <div className="w-11 h-11 sm:w-13 sm:h-13 rounded-sm overflow-hidden relative border border-slate-700">
            <img
              src={ASSETS.potionMana}
              alt="Mana Potion"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform"
            />
            <span className="absolute bottom-0.5 right-0.5 text-[9px] font-bold text-sky-300 bg-black/80 px-1 rounded-xs">
              x{stats.potions}
            </span>
          </div>
          <div className="mt-0.5 bg-slate-800 text-[10px] font-black text-sky-400 px-1.5 py-0.2 rounded-xs border border-slate-600 font-mono">
            [F]
          </div>
        </button>

        {/* Currently Equipped Weapon Card */}
        <div
          className="flex flex-col items-center bg-slate-900/95 border-2 rounded-sm p-1.5 relative transition-all"
          style={{
            borderColor: currentWeapon.glowColor,
            boxShadow: `0 0 15px ${currentWeapon.glowColor}50`,
          }}
        >
          <div className="text-[11px] font-black font-['Nunito'] tracking-wide mb-0.5 flex items-center gap-1.5" style={{ color: currentWeapon.glowColor }}>
            <span>{currentWeapon.name}</span>
            <span className="bg-slate-800 text-slate-300 px-1 py-0.2 rounded text-[9px] font-mono border border-slate-600">
              [{currentWeapon.slotNumber}]
            </span>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-14 h-12 sm:w-18 sm:h-14 rounded-sm overflow-hidden relative border bg-slate-950" style={{ borderColor: currentWeapon.glowColor + '70' }}>
              <img
                src={currentWeapon.icon}
                alt={currentWeapon.name}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </div>

            {/* Ammo Display */}
            <div className="flex flex-col items-center pr-1">
              <div className="flex items-baseline gap-1 font-mono">
                <span className="text-xl sm:text-2xl font-black text-white">
                  {stats.ammoInClip}
                </span>
                <span className="text-slate-400 font-bold text-xs sm:text-sm">
                  / {stats.ammoReserve}
                </span>
              </div>
              <button
                onClick={() => onTriggerSkill('reload')}
                disabled={stats.isReloading}
                className="mt-1 flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-bold border transition-colors bg-slate-800/80 hover:bg-slate-700 text-slate-200 border-slate-600"
              >
                <RotateCcw className={`w-2.5 h-2.5 ${stats.isReloading ? 'animate-spin text-amber-400' : ''}`} />
                <span>{stats.isReloading ? 'Reloading...' : 'Reload [R]'}</span>
              </button>
            </div>
          </div>

          {/* Reload Progress Bar */}
          {stats.isReloading && (
            <div className="w-full h-1.5 bg-slate-800 rounded-full mt-1 overflow-hidden border border-slate-700">
              <div
                className="h-full bg-amber-400 transition-all duration-200"
                style={{ width: `${stats.reloadProgress * 100}%` }}
              />
            </div>
          )}
        </div>
      </div>

      {/* Lower Inventory Belt Slots 1 to 8 (Quick Switch 1,2,3,4 for Weapons) */}
      <div className="flex items-center gap-1 bg-slate-950/80 px-2 py-1 rounded-sm border border-slate-800">
        {[1, 2, 3, 4, 5, 6, 7, 8].map((slotNum) => {
          let weaponForSlot: (typeof WEAPONS_CATALOG)[keyof typeof WEAPONS_CATALOG] | null = null;
          if (slotNum === 1) weaponForSlot = WEAPONS_CATALOG.dragonfire;
          if (slotNum === 2) weaponForSlot = WEAPONS_CATALOG.plasma_laser;
          if (slotNum === 3) weaponForSlot = WEAPONS_CATALOG.cluster_meteor;
          if (slotNum === 4) weaponForSlot = WEAPONS_CATALOG.holy_radiance;

          const isUnlocked = weaponForSlot ? stats.unlockedWeapons.includes(weaponForSlot.id) : false;
          const isSelected = weaponForSlot ? stats.selectedWeaponId === weaponForSlot.id : false;

          return (
            <button
              key={slotNum}
              onClick={() => {
                if (weaponForSlot && isUnlocked) {
                  onSelectWeapon(weaponForSlot.id);
                }
              }}
              className={`w-9 h-9 sm:w-10 sm:h-10 rounded-sm flex items-center justify-center relative border transition-all cursor-pointer ${
                isSelected
                  ? 'border-amber-400 bg-amber-950/50 shadow-[0_0_10px_rgba(245,158,11,0.6)] scale-105 z-10'
                  : isUnlocked
                  ? 'border-slate-700 bg-slate-900/90 hover:border-slate-400'
                  : weaponForSlot
                  ? 'border-slate-800/80 bg-slate-950/80 opacity-50'
                  : 'border-slate-900 bg-slate-950/50 text-slate-600 cursor-default'
              }`}
            >
              <span className="absolute top-0.5 left-1 text-[9px] font-mono font-bold text-slate-400">
                {slotNum}
              </span>

              {/* Weapon Icon */}
              {weaponForSlot && (
                <div className="w-7 h-7 relative flex items-center justify-center">
                  <img
                    src={weaponForSlot.icon}
                    alt={weaponForSlot.name}
                    referrerPolicy="no-referrer"
                    className={`w-full h-full object-cover rounded-xs ${!isUnlocked ? 'filter grayscale brightness-50' : ''}`}
                  />
                  {!isUnlocked && (
                    <Lock className="w-3.5 h-3.5 text-amber-400 absolute drop-shadow-md" />
                  )}
                </div>
              )}

              {/* Slot 5: Mana Potion Shortcut */}
              {slotNum === 5 && (
                <img
                  src={ASSETS.potionMana}
                  alt="Potion"
                  referrerPolicy="no-referrer"
                  className="w-6 h-6 object-cover rounded-xs opacity-75"
                />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};
