import React from 'react';
import { Settings } from 'lucide-react';
import { PlayerStats } from '../../types';
import { ASSETS } from '../../assets';

interface PlayerStatusProps {
  stats: PlayerStats;
  onOpenSettings?: () => void;
}

export const PlayerStatus: React.FC<PlayerStatusProps> = ({ stats, onOpenSettings }) => {
  const hpPct = Math.max(0, Math.min(100, (stats.hp / stats.maxHp) * 100));
  const manaPct = Math.max(0, Math.min(100, (stats.mana / stats.maxMana) * 100));

  return (
    <div id="player-status-card" className="flex items-start gap-2 select-none pointer-events-auto">
      {/* Avatar Box */}
      <div className="w-16 h-16 sm:w-20 sm:h-20 bg-gradient-to-b from-sky-400 to-blue-600 border-2 border-slate-900 rounded-sm p-1 shadow-lg relative overflow-hidden flex-shrink-0">
        <img
          src={ASSETS.playerAvatar}
          alt="Avatar"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover rounded-sm"
        />
        <div className="absolute bottom-0 right-0 bg-slate-900/80 text-[10px] font-black px-1 text-amber-300 font-mono">
          Lv.{stats.level}
        </div>
      </div>

      {/* Stats Details & Bars */}
      <div className="w-48 sm:w-60 flex flex-col justify-between">
        {/* Title Header */}
        <div className="flex items-center justify-between bg-slate-950/80 px-2 py-0.5 border border-slate-700/80 rounded-t-sm">
          <span className="text-white font-extrabold text-xs sm:text-sm tracking-wide font-['Nunito']">
            Lv {stats.level} {stats.title}
          </span>
          <button
            onClick={onOpenSettings}
            className="text-slate-400 hover:text-white transition-colors p-0.5"
            title="Options"
          >
            <Settings className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Health Bar (Green) */}
        <div className="bg-slate-950/90 p-1 border-x border-b border-slate-700/80">
          <div className="flex justify-between text-[10px] font-bold text-white mb-0.5 px-0.5">
            <span className="text-emerald-300">HP</span>
            <span className="font-mono">{Math.ceil(stats.hp)} / {stats.maxHp}</span>
          </div>
          <div className="w-full h-3 bg-slate-900 rounded-[2px] overflow-hidden border border-slate-800 p-[1px]">
            <div
              className="h-full bg-gradient-to-r from-emerald-600 via-green-500 to-emerald-400 rounded-[1px] transition-all duration-200 shadow-[0_0_8px_rgba(34,197,94,0.6)]"
              style={{ width: `${hpPct}%` }}
            />
          </div>

          {/* Mana Bar (Blue) */}
          <div className="flex justify-between text-[10px] font-bold text-white mt-1 mb-0.5 px-0.5">
            <span className="text-sky-300">Mana</span>
            <span className="font-mono">{Math.ceil(stats.mana)} / {stats.maxMana}</span>
          </div>
          <div className="w-full h-3 bg-slate-900 rounded-[2px] overflow-hidden border border-slate-800 p-[1px]">
            <div
              className="h-full bg-gradient-to-r from-blue-700 via-sky-500 to-cyan-400 rounded-[1px] transition-all duration-200 shadow-[0_0_8px_rgba(56,189,248,0.6)]"
              style={{ width: `${manaPct}%` }}
            />
          </div>
        </div>
      </div>
    </div>
  );
};
