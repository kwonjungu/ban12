import React from 'react';
import { Sparkles, CheckCircle2 } from 'lucide-react';
import { Quest } from '../../types';

interface QuestTrackerProps {
  quest: Quest;
}

export const QuestTracker: React.FC<QuestTrackerProps> = ({ quest }) => {
  const pct = Math.min(100, (quest.current / quest.target) * 100);

  return (
    <div id="quest-tracker-panel" className="bg-slate-950/85 backdrop-blur-sm border border-slate-700/80 rounded-sm p-2.5 sm:p-3 text-white max-w-xs shadow-xl select-none pointer-events-auto">
      {/* Header */}
      <div className="flex items-center gap-1.5 text-amber-400 font-extrabold text-sm sm:text-base border-b border-slate-800 pb-1 font-['Nunito']">
        <Sparkles className="w-4 h-4 fill-amber-400" />
        <span>Quest Tracker</span>
      </div>

      {/* Quest Details */}
      <div className="mt-1.5 space-y-1 text-xs">
        <div className="text-slate-300 font-semibold">
          Active Quest: <span className="text-white font-bold">{quest.title}</span>
        </div>
        <div className="text-slate-200 font-mono text-[11px] flex justify-between items-center">
          <span>{quest.objective}</span>
          <span className={`font-bold ${quest.completed ? 'text-emerald-400' : 'text-amber-400'}`}>
            ({quest.current}/{quest.target})
          </span>
        </div>

        {/* Progress Bar */}
        <div className="w-full h-2 bg-slate-900 rounded-full overflow-hidden border border-slate-800">
          <div
            className={`h-full transition-all duration-300 ${
              quest.completed ? 'bg-emerald-500 shadow-[0_0_8px_#10b981]' : 'bg-amber-500 shadow-[0_0_8px_#f59e0b]'
            }`}
            style={{ width: `${pct}%` }}
          />
        </div>

        {/* Rewards */}
        <div className="flex justify-between text-[10px] text-slate-400 pt-0.5 font-mono">
          <span>Reward: <strong className="text-amber-300">+{quest.rewardGold} Gold</strong></span>
          <span>EXP: <strong className="text-sky-300">+{quest.rewardExp}</strong></span>
        </div>

        {quest.completed && (
          <div className="flex items-center gap-1 text-[11px] text-emerald-400 font-bold bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/40 animate-pulse">
            <CheckCircle2 className="w-3 h-3" />
            <span>Quest Complete! Talk to Quest Giver</span>
          </div>
        )}
      </div>
    </div>
  );
};
