import React, { useState } from 'react';
import { MessageSquare, Send } from 'lucide-react';
import { ChatMessage } from '../../types';

interface ChatBoxProps {
  messages: ChatMessage[];
  onSendMessage: (text: string) => void;
}

export const ChatBox: React.FC<ChatBoxProps> = ({ messages, onSendMessage }) => {
  const [inputText, setInputText] = useState('');
  const [activeTab, setActiveTab] = useState<'Chat' | 'Shout'>('Chat');

  const handleSend = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputText.trim()) return;
    onSendMessage(inputText.trim());
    setInputText('');
  };

  const quickShouts = ['Cover me!', 'Fire in the hole!', 'Need mana potion!', 'Boss incoming!'];

  return (
    <div id="game-chat-box" className="w-64 sm:w-80 bg-slate-950/75 backdrop-blur-md rounded-sm border border-slate-800/90 shadow-2xl flex flex-col pointer-events-auto select-none overflow-hidden">
      {/* Tab Header */}
      <div className="flex items-center border-b border-slate-800 bg-slate-900/60 px-2 pt-1 gap-1">
        <button
          onClick={() => setActiveTab('Chat')}
          className={`text-xs font-bold px-2 py-0.5 rounded-t-sm transition-colors ${
            activeTab === 'Chat'
              ? 'bg-slate-800 text-amber-300 border-t-2 border-amber-400'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Chat
        </button>
        <button
          onClick={() => setActiveTab('Shout')}
          className={`text-xs font-bold px-2 py-0.5 rounded-t-sm transition-colors ${
            activeTab === 'Shout'
              ? 'bg-slate-800 text-amber-300 border-t-2 border-amber-400'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Quick Shout
        </button>
      </div>

      {/* Messages Scroll Area */}
      <div className="h-24 sm:h-28 overflow-y-auto p-2 space-y-1 text-xs font-mono">
        {messages.map((msg) => (
          <div key={msg.id} className="leading-tight break-words">
            <span style={{ color: msg.authorColor || '#38bdf8' }} className="font-bold">
              [{msg.author}]:{' '}
            </span>
            <span className="text-slate-200">{msg.text}</span>
          </div>
        ))}
      </div>

      {/* Quick Shout shortcuts if tab is Shout */}
      {activeTab === 'Shout' && (
        <div className="grid grid-cols-2 gap-1 p-1 bg-slate-900/80 border-t border-slate-800">
          {quickShouts.map((phrase) => (
            <button
              key={phrase}
              onClick={() => onSendMessage(phrase)}
              className="text-[10px] font-semibold bg-slate-800 hover:bg-slate-700 text-amber-200 px-1 py-0.5 rounded text-left truncate"
            >
              {phrase}
            </button>
          ))}
        </div>
      )}

      {/* Input Field */}
      <form onSubmit={handleSend} className="flex items-center border-t border-slate-800 bg-slate-950 p-1">
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder="Type here to chat..."
          className="flex-1 bg-slate-900 border border-slate-700/60 rounded px-2 py-1 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-amber-400"
        />
        <button
          type="submit"
          className="ml-1 bg-amber-500 hover:bg-amber-400 text-slate-950 p-1 rounded font-bold transition-colors"
          title="Send"
        >
          <Send className="w-3 h-3" />
        </button>
      </form>
    </div>
  );
};
