import React from 'react';
import { Trophy, Sparkles, Flame, RotateCcw, Crosshair, Star } from 'lucide-react';
import { PlayerStats } from '../../types';
import { WEAPONS_CATALOG } from '../../weapons';

interface VictoryModalProps {
  stats: PlayerStats;
  onContinueEndless: () => void;
  onRestart: () => void;
}

export const VictoryModal: React.FC<VictoryModalProps> = ({ stats, onContinueEndless, onRestart }) => {
  return (
    <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4 select-none animate-in fade-in duration-300">
      <div className="bg-slate-900 border-4 border-amber-400 rounded-xl max-w-lg w-full p-6 text-center text-white shadow-[0_0_50px_rgba(245,158,11,0.6)] relative overflow-hidden">
        {/* Glow ambient background */}
        <div className="absolute -top-24 -left-24 w-48 h-48 bg-amber-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -right-24 w-48 h-48 bg-yellow-400/20 rounded-full blur-3xl pointer-events-none" />

        {/* Golden Trophy Icon */}
        <div className="w-20 h-20 mx-auto mb-3 bg-gradient-to-br from-amber-400 to-yellow-600 rounded-2xl flex items-center justify-center shadow-lg border-2 border-yellow-200">
          <Trophy className="w-12 h-12 text-slate-950" />
        </div>

        {/* Victory Headlines */}
        <h1 className="text-3xl sm:text-4xl font-black text-amber-300 font-['Nunito'] tracking-wide drop-shadow-md">
          VICTORY! 마을을 구원했습니다!
        </h1>
        <p className="text-sm sm:text-base text-slate-300 mt-1 font-semibold">
          사악한 고블린 대장군과 호드를 모조리 섬멸하여 중세 왕국에 평화가 찾아왔습니다.
        </p>

        {/* Final Battle Results Card */}
        <div className="bg-slate-950/80 rounded-lg border border-amber-500/40 p-4 my-5 grid grid-cols-2 gap-3 text-left">
          <div className="bg-slate-900/90 p-2.5 rounded border border-slate-800">
            <span className="text-[11px] font-bold text-slate-400 block">FINAL SCORE</span>
            <span className="text-xl sm:text-2xl font-black text-amber-400 font-mono">
              {stats.score.toLocaleString()}
            </span>
          </div>
          <div className="bg-slate-900/90 p-2.5 rounded border border-slate-800">
            <span className="text-[11px] font-bold text-slate-400 block">TOTAL KILLS</span>
            <span className="text-xl sm:text-2xl font-black text-red-400 font-mono">
              {stats.kills} Goblins
            </span>
          </div>
          <div className="bg-slate-900/90 p-2.5 rounded border border-slate-800">
            <span className="text-[11px] font-bold text-slate-400 block">GOLD EARNED</span>
            <span className="text-xl sm:text-2xl font-black text-yellow-400 font-mono">
              ${stats.gold}
            </span>
          </div>
          <div className="bg-slate-900/90 p-2.5 rounded border border-slate-800">
            <span className="text-[11px] font-bold text-slate-400 block">WEAPONS UNLOCKED</span>
            <span className="text-xl sm:text-2xl font-black text-cyan-400 font-mono">
              {stats.unlockedWeapons.length} / 4
            </span>
          </div>
        </div>

        {/* Arsenal Showcase */}
        <div className="mb-5 text-left">
          <span className="text-xs font-bold text-amber-300 uppercase tracking-wider mb-1.5 block">
            당신의 무기고 아스널
          </span>
          <div className="grid grid-cols-4 gap-2">
            {Object.values(WEAPONS_CATALOG).map((w) => {
              const unlocked = stats.unlockedWeapons.includes(w.id);
              return (
                <div
                  key={w.id}
                  className={`p-1.5 rounded border flex flex-col items-center justify-center text-center ${
                    unlocked
                      ? 'bg-slate-950/80 border-amber-400/60'
                      : 'bg-slate-950/40 border-slate-800 opacity-40'
                  }`}
                >
                  <img
                    src={w.icon}
                    alt={w.name}
                    referrerPolicy="no-referrer"
                    className="w-10 h-10 object-cover rounded mb-1"
                  />
                  <span className="text-[10px] font-bold text-white truncate max-w-full">
                    {w.name.split(' ')[0]}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-3">
          <button
            onClick={onContinueEndless}
            className="flex-1 bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black py-3 px-4 rounded-lg shadow-lg flex items-center justify-center gap-2 transition-transform active:scale-95"
          >
            <Sparkles className="w-5 h-5 text-slate-950" />
            <span>무한 모드로 계속하기 (Endless)</span>
          </button>
          <button
            onClick={onRestart}
            className="bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-bold py-3 px-4 rounded-lg border border-slate-700 flex items-center justify-center gap-2 transition-colors"
          >
            <RotateCcw className="w-4 h-4" />
            <span>처음부터 재도전</span>
          </button>
        </div>
      </div>
    </div>
  );
};
