import React from 'react';
import { MessageSquare, Users, Volume2, VolumeX, Maximize2, ShieldCheck, Sparkles } from 'lucide-react';
import { sounds } from '../../audio';

interface RobloxTopBarProps {
  score: number;
  gold: number;
  kills: number;
  isMuted: boolean;
  onToggleMute: () => void;
  onOpenShop: () => void;
}

export const RobloxTopBar: React.FC<RobloxTopBarProps> = ({
  score,
  gold,
  kills,
  isMuted,
  onToggleMute,
  onOpenShop,
}) => {
  return (
    <div id="roblox-top-bar" className="w-full flex items-center justify-between px-3 py-1.5 select-none pointer-events-none z-30">
      {/* Top Left: Roblox Emblem / Quick Buttons */}
      <div className="flex items-center gap-2 pointer-events-auto">
        {/* Roblox style tilted silver square logo */}
        <div className="w-8 h-8 bg-slate-900 border border-slate-700 rounded-sm flex items-center justify-center shadow-md">
          <div className="w-4 h-4 bg-slate-200 border border-slate-400 rotate-12 flex items-center justify-center">
            <div className="w-1.5 h-1.5 bg-slate-900" />
          </div>
        </div>

        <div className="hidden sm:flex items-center gap-1 bg-slate-950/70 border border-slate-800 rounded px-2 py-1 text-xs font-mono">
          <span className="text-amber-400 font-bold">Gold:</span>
          <span className="text-white">${gold}</span>
          <span className="text-slate-600 mx-1">|</span>
          <span className="text-sky-400 font-bold">Score:</span>
          <span className="text-white">{score}</span>
          <span className="text-slate-600 mx-1">|</span>
          <span className="text-emerald-400 font-bold">Kills:</span>
          <span className="text-white">{kills}</span>
        </div>
      </div>

      {/* Top Right: System Buttons */}
      <div className="flex items-center gap-2 pointer-events-auto">
        {/* Armory Shop button */}
        <button
          onClick={onOpenShop}
          className="flex items-center gap-1.5 bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-slate-950 font-black text-xs px-2.5 py-1 rounded shadow-lg transition-all"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>ARMORY SHOP</span>
        </button>

        {/* Audio mute toggle */}
        <button
          onClick={onToggleMute}
          className="p-1.5 bg-slate-900/80 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-white rounded transition-colors"
          title={isMuted ? 'Unmute Sound' : 'Mute Sound'}
        >
          {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
        </button>

        {/* Fullscreen request */}
        <button
          onClick={() => {
            if (!document.fullscreenElement) {
              document.documentElement.requestFullscreen().catch(() => {});
            } else {
              document.exitFullscreen().catch(() => {});
            }
          }}
          className="p-1.5 bg-slate-900/80 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-white rounded transition-colors"
          title="Fullscreen"
        >
          <Maximize2 className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
