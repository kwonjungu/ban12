import React from 'react';
import { DamageNumber } from '../../types';

interface DamageNumbersProps {
  damages: DamageNumber[];
}

export const DamageNumbers: React.FC<DamageNumbersProps> = ({ damages }) => {
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden z-20">
      {damages.map((dmg) => (
        <div
          key={dmg.id}
          style={{
            left: `${dmg.x}px`,
            top: `${dmg.y}px`,
            transform: 'translate(-50%, -50%)',
          }}
          className={`absolute font-black font-['Cinzel',sans-serif] select-none pointer-events-none animate-[floatDamage_0.75s_ease-out_forwards] ${
            dmg.isCrit
              ? 'text-3xl text-amber-400 drop-shadow-[0_0_12px_#f59e0b] scale-125'
              : 'text-xl text-yellow-200 drop-shadow-[0_0_8px_#ef4444]'
          }`}
        >
          {dmg.isCrit ? `💥 CRIT -${dmg.amount}` : `-${dmg.amount}`}
        </div>
      ))}
    </div>
  );
};
