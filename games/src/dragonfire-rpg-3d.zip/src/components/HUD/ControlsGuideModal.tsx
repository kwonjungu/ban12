import React from 'react';
import { X, Gamepad2, MousePointer, Crosshair, Sparkles } from 'lucide-react';

interface ControlsGuideModalProps {
  onClose: () => void;
}

export const ControlsGuideModal: React.FC<ControlsGuideModalProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4 select-none">
      <div className="bg-slate-900 border-2 border-slate-700 rounded-lg max-w-lg w-full p-5 text-white shadow-2xl">
        <div className="flex justify-between items-center border-b border-slate-800 pb-3 mb-4">
          <div className="flex items-center gap-2">
            <Gamepad2 className="w-6 h-6 text-amber-400" />
            <h2 className="text-xl font-black text-amber-300 font-['Nunito']">
              HOW TO PLAY & CONTROLS
            </h2>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-md transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-2.5 text-xs font-mono">
          <div className="flex justify-between items-center bg-slate-950 p-2 rounded border border-slate-800">
            <span className="text-slate-400">Aim & Look:</span>
            <span className="text-amber-300 font-bold bg-slate-900 px-2 py-0.5 rounded border border-slate-700">Mouse Move (Click screen to lock)</span>
          </div>
          <div className="flex justify-between items-center bg-slate-950 p-2 rounded border border-slate-800">
            <span className="text-slate-400">Fire Dragonfire RPG:</span>
            <span className="text-amber-300 font-bold bg-slate-900 px-2 py-0.5 rounded border border-slate-700">Left Click (Mouse 1)</span>
          </div>
          <div className="flex justify-between items-center bg-slate-950 p-2 rounded border border-slate-800">
            <span className="text-slate-400">Navigate Town:</span>
            <span className="text-amber-300 font-bold bg-slate-900 px-2 py-0.5 rounded border border-slate-700">W, A, S, D</span>
          </div>
          <div className="flex justify-between items-center bg-slate-950 p-2 rounded border border-slate-800">
            <span className="text-slate-400">Hyper Sprint / Dash:</span>
            <span className="text-amber-300 font-bold bg-slate-900 px-2 py-0.5 rounded border border-slate-700">Left Shift</span>
          </div>
          <div className="flex justify-between items-center bg-slate-950 p-2 rounded border border-slate-800">
            <span className="text-slate-400">Jump:</span>
            <span className="text-amber-300 font-bold bg-slate-900 px-2 py-0.5 rounded border border-slate-700">Spacebar</span>
          </div>
          <div className="flex justify-between items-center bg-slate-950 p-2 rounded border border-slate-800">
            <span className="text-slate-400">Reload Rocket:</span>
            <span className="text-amber-300 font-bold bg-slate-900 px-2 py-0.5 rounded border border-slate-700">R Key</span>
          </div>
          <div className="flex justify-between items-center bg-slate-950 p-2 rounded border border-slate-800">
            <span className="text-slate-400">Dragon Swipe (Fire Wave):</span>
            <span className="text-amber-300 font-bold bg-slate-900 px-2 py-0.5 rounded border border-slate-700">Q Key (25 Mana)</span>
          </div>
          <div className="flex justify-between items-center bg-slate-950 p-2 rounded border border-slate-800">
            <span className="text-slate-400">Dragon Dash / Stance:</span>
            <span className="text-amber-300 font-bold bg-slate-900 px-2 py-0.5 rounded border border-slate-700">E Key (15 Mana)</span>
          </div>
          <div className="flex justify-between items-center bg-slate-950 p-2 rounded border border-slate-800">
            <span className="text-slate-400">Weapon Switching (총기 변경):</span>
            <span className="text-cyan-300 font-bold bg-slate-900 px-2 py-0.5 rounded border border-slate-700">1, 2, 3, 4 Keys</span>
          </div>
          <div className="flex justify-between items-center bg-slate-950 p-2 rounded border border-slate-800">
            <span className="text-slate-400">Open Armory Shop (상점):</span>
            <span className="text-amber-300 font-bold bg-slate-900 px-2 py-0.5 rounded border border-slate-700">B Key or Top Button</span>
          </div>
          <div className="flex justify-between items-center bg-slate-950 p-2 rounded border border-slate-800">
            <span className="text-slate-400">Boss & Ending (최종 보스 및 엔딩):</span>
            <span className="text-red-400 font-bold bg-slate-900 px-2 py-0.5 rounded border border-slate-700">20 마리 처치 시 대장군 보스 출현!</span>
          </div>
          <div className="flex justify-between items-center bg-slate-950 p-2 rounded border border-slate-800">
            <span className="text-slate-400">Drink Mana Potion:</span>
            <span className="text-sky-300 font-bold bg-slate-900 px-2 py-0.5 rounded border border-slate-700">F Key</span>
          </div>
        </div>

        <div className="mt-4 flex justify-end">
          <button
            onClick={onClose}
            className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs px-5 py-2 rounded transition-transform active:scale-95"
          >
            Got It!
          </button>
        </div>
      </div>
    </div>
  );
};
