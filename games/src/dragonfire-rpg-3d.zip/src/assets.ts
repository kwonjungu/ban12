import playerAvatarImg from './assets/images/player_avatar_1789885455373.jpg';
import dragonfireRpgImg from './assets/images/dragonfire_rpg_1789885478198.jpg';
import skillDragonSwipeImg from './assets/images/skill_dragon_swipe_1789885490605.jpg';
import potionManaImg from './assets/images/potion_mana_1789885505612.jpg';
import goblinPortraitImg from './assets/images/goblin_portrait_1789885519587.jpg';
import plasmaLaserCannonImg from './assets/images/plasma_laser_cannon_1789886006176.jpg';
import clusterMeteorLauncherImg from './assets/images/cluster_meteor_launcher_1789886023697.jpg';
import holyRadianceMortarImg from './assets/images/holy_radiance_mortar_1789886038434.jpg';

export const ASSETS = {
  playerAvatar: playerAvatarImg,
  dragonfireRpg: dragonfireRpgImg,
  skillDragonSwipe: skillDragonSwipeImg,
  potionMana: potionManaImg,
  goblinPortrait: goblinPortraitImg,
  plasmaCannon: plasmaLaserCannonImg,
  clusterLauncher: clusterMeteorLauncherImg,
  holyMortar: holyRadianceMortarImg,
};

