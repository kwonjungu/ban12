export type WeaponId = 'dragonfire' | 'plasma_laser' | 'cluster_meteor' | 'holy_radiance';

export interface WeaponDefinition {
  id: WeaponId;
  name: string;
  slotNumber: number;
  icon: string;
  themeColor: string;
  glowColor: string;
  fireRate: number; // ms between shots
  damage: number;
  splashRadius: number;
  clipSize: number;
  maxReserve: number;
  projectileSpeed: number;
  projectileType: 'dragon_fire' | 'plasma_beam' | 'meteor_cluster' | 'holy_orb';
  projectileColor: number;
  projectileCount?: number;
  spread?: number;
  trailColor1: number;
  trailColor2: number;
  explosionColor: number;
  description: string;
  cost: number;
  unlocked: boolean;
}

export interface PlayerStats {
  level: number;
  title: string;
  hp: number;
  maxHp: number;
  mana: number;
  maxMana: number;
  gold: number;
  score: number;
  selectedWeaponId: WeaponId;
  unlockedWeapons: WeaponId[];
  ammoInClip: number;
  clipSize: number;
  ammoReserve: number;
  maxReserve: number;
  potions: number;
  kills: number;
  isReloading: boolean;
  reloadProgress: number;
  gameWon: boolean;
  bossAppeared: boolean;
}


export interface GoblinEnemy {
  id: string;
  name: string;
  level: number;
  hp: number;
  maxHp: number;
  speed: number;
  damage: number;
  position: { x: number; y: number; z: number };
  isBoss?: boolean;
}

export interface Projectile {
  id: string;
  type: 'rocket' | 'dragon_fire';
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  damage: number;
  radius: number;
  lifetime: number;
}

export interface DamageNumber {
  id: string;
  amount: number;
  isCrit: boolean;
  x: number;
  y: number;
}

export interface ChatMessage {
  id: string;
  author: string;
  authorColor: string;
  text: string;
  timestamp: number;
  system?: boolean;
}

export interface Quest {
  id: string;
  title: string;
  objective: string;
  current: number;
  target: number;
  rewardGold: number;
  rewardExp: number;
  completed: boolean;
}

export interface SkillState {
  id: string;
  name: string;
  key: string;
  icon: string;
  cooldown: number; // in seconds
  currentCooldown: number; // remaining seconds
  manaCost: number;
  description: string;
}
