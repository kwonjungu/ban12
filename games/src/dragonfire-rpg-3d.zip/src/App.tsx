import React, { useState, useEffect, useCallback } from 'react';
import { GameCanvas } from './components/GameCanvas';
import { PlayerStatus } from './components/HUD/PlayerStatus';
import { Minimap } from './components/HUD/Minimap';
import { QuestTracker } from './components/HUD/QuestTracker';
import { Hotbar } from './components/HUD/Hotbar';
import { ChatBox } from './components/HUD/ChatBox';
import { RobloxTopBar } from './components/HUD/RobloxTopBar';
import { Crosshair } from './components/HUD/Crosshair';
import { DamageNumbers } from './components/HUD/DamageNumbers';
import { ShopModal } from './components/HUD/ShopModal';
import { GameOverModal } from './components/HUD/GameOverModal';
import { ControlsGuideModal } from './components/HUD/ControlsGuideModal';
import { StartOverlay } from './components/HUD/StartOverlay';
import { VictoryModal } from './components/HUD/VictoryModal';
import { PlayerStats, Quest, ChatMessage, DamageNumber, WeaponId } from './types';
import { WEAPONS_CATALOG } from './weapons';
import { sounds } from './audio';

export default function App() {
  // Player Core Stats
  const [stats, setStats] = useState<PlayerStats>({
    level: 25,
    title: 'Warrior',
    hp: 180,
    maxHp: 180,
    mana: 90,
    maxMana: 90,
    gold: 320,
    score: 1840,
    selectedWeaponId: 'dragonfire',
    unlockedWeapons: ['dragonfire'],
    ammoInClip: 25,
    clipSize: 25,
    ammoReserve: 200,
    maxReserve: 300,
    potions: 3,
    kills: 12,
    isReloading: false,
    reloadProgress: 0,
    gameWon: false,
    bossAppeared: false,
  });

  // Active Quest State (Matching the screenshot: 12/20 Goblins)
  const [quest, setQuest] = useState<Quest>({
    id: 'quest_goblin_horde',
    title: 'Defeat Goblin Horde',
    objective: 'Defeat Goblin Horde',
    current: 12,
    target: 20,
    rewardGold: 250,
    rewardExp: 500,
    completed: false,
  });

  // Roblox In-Game Chat (Including the exact messages from screenshot)
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: 'm1',
      author: 'nmalirley',
      authorColor: '#38bdf8',
      text: 'yo, check my new RPG gear!',
      timestamp: Date.now() - 40000,
    },
    {
      id: 'm2',
      author: 'sserenney',
      authorColor: '#fb923c',
      text: 'where u get that quest?',
      timestamp: Date.now() - 25000,
    },
    {
      id: 'm3',
      author: 'Quest Master',
      authorColor: '#facc15',
      text: 'Goblins approaching the cobblestone gate! Defend the town!',
      timestamp: Date.now() - 10000,
    },
  ]);

  // Floating Damage Numbers
  const [damages, setDamages] = useState<DamageNumber[]>([]);

  // UI Modals & Interaction States
  const [hasStarted, setHasStarted] = useState<boolean>(false);
  const [isPointerLocked, setIsPointerLocked] = useState<boolean>(false);
  const [shopOpen, setShopOpen] = useState<boolean>(false);
  const [controlsOpen, setControlsOpen] = useState<boolean>(false);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [activeSkillTrigger, setActiveSkillTrigger] = useState<string | null>(null);

  // Mana Auto-Regen
  useEffect(() => {
    const timer = setInterval(() => {
      setStats((prev) => {
        if (prev.mana < prev.maxMana) {
          return { ...prev, mana: Math.min(prev.maxMana, prev.mana + 2) };
        }
        return prev;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Spawn damage number handler
  const handleSpawnDamage = useCallback((amount: number, isCrit: boolean, screenPos: { x: number; y: number }) => {
    const id = 'dmg_' + Math.random();
    setDamages((prev) => [...prev, { id, amount, isCrit, x: screenPos.x, y: screenPos.y }]);
    setTimeout(() => {
      setDamages((prev) => prev.filter((d) => d.id !== id));
    }, 750);
  }, []);

  // Goblin Kill Handler
  const handleGoblinKilled = useCallback((isBoss: boolean) => {
    setStats((prev) => {
      const reward = isBoss ? 250 : 35;
      const scoreAdd = isBoss ? 800 : 150;
      return {
        ...prev,
        kills: prev.kills + 1,
        gold: prev.gold + reward,
        score: prev.score + scoreAdd,
      };
    });
  }, []);

  // Quest Progression Handler
  const handleQuestProgress = useCallback(() => {
    setQuest((prev) => {
      if (prev.completed) return prev;
      const nextCount = prev.current + 1;
      const isNowDone = nextCount >= prev.target;
      if (isNowDone) {
        sounds.playQuestComplete();
        // Give quest reward
        setStats((s) => ({
          ...s,
          gold: s.gold + prev.rewardGold,
          score: s.score + prev.rewardExp,
          level: s.level + 1,
        }));
        setChatMessages((msgs) => [
          ...msgs,
          {
            id: 'm_' + Date.now(),
            author: 'Quest System',
            authorColor: '#eab308',
            text: `★ Quest Completed: ${prev.title}! Earned $${prev.rewardGold} Gold & Level Up!`,
            timestamp: Date.now(),
          },
        ]);
      }
      return {
        ...prev,
        current: Math.min(prev.target, nextCount),
        completed: isNowDone,
      };
    });
  }, []);

  // Send Chat Message
  const handleSendMessage = (text: string) => {
    const newMsg: ChatMessage = {
      id: 'm_' + Date.now(),
      author: 'You',
      authorColor: '#4ade80',
      text,
      timestamp: Date.now(),
    };
    setChatMessages((prev) => [...prev.slice(-25), newMsg]);
  };

  // Sound Toggle
  const handleToggleMute = () => {
    const nextMuted = !isMuted;
    setIsMuted(nextMuted);
    sounds.setMuted(nextMuted);
  };

  // Respawn after game over
  const handleRespawn = () => {
    setStats((prev) => ({
      ...prev,
      hp: prev.maxHp,
      mana: prev.maxMana,
      ammoInClip: prev.clipSize,
    }));
  };

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-slate-950 font-['Nunito',sans-serif]">
      {/* 3D WebGL Canvas Layer */}
      <GameCanvas
        stats={stats}
        onUpdateStats={setStats}
        onSpawnDamage={handleSpawnDamage}
        onGoblinKilled={handleGoblinKilled}
        onChatMessage={(author, text, color) => {
          setChatMessages((prev) => [
            ...prev.slice(-25),
            {
              id: 'm_' + Date.now(),
              author,
              authorColor: color || '#facc15',
              text,
              timestamp: Date.now(),
            },
          ]);
        }}
        isPointerLocked={isPointerLocked}
        setIsPointerLocked={setIsPointerLocked}
        onQuestProgress={handleQuestProgress}
        activeSkillTrigger={activeSkillTrigger}
        onClearSkillTrigger={() => setActiveSkillTrigger(null)}
      />

      {/* Floating Damage Numbers */}
      <DamageNumbers damages={damages} />

      {/* Crosshair (centered) */}
      <Crosshair />

      {/* Main HUD Overlays (Pointer events handled inside individual cards) */}
      <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-3 sm:p-4 z-20">
        {/* Top Roblox System Navigation Bar */}
        <RobloxTopBar
          score={stats.score}
          gold={stats.gold}
          kills={stats.kills}
          isMuted={isMuted}
          onToggleMute={handleToggleMute}
          onOpenShop={() => setShopOpen(true)}
        />

        {/* Top HUD Row: Player Status + Minimap (Left) & Quest Tracker (Right) */}
        <div className="flex justify-between items-start w-full px-1">
          {/* Top Left: Avatar Status Card & Minimap */}
          <div className="flex flex-col gap-2">
            <PlayerStatus
              stats={stats}
              onOpenSettings={() => setControlsOpen(true)}
            />
            <Minimap kills={stats.kills} />
          </div>

          {/* Top Right: Quest Tracker */}
          <div className="flex flex-col items-end gap-2">
            <QuestTracker quest={quest} />
          </div>
        </div>

        {/* Bottom HUD Row: Chat Box (Bottom Left) & Action Hotbar (Bottom Center) */}
        <div className="flex flex-col sm:flex-row justify-between items-end w-full gap-3 px-1">
          {/* Bottom Left: Roblox In-Game Chat Box */}
          <div className="order-2 sm:order-1">
            <ChatBox
              messages={chatMessages}
              onSendMessage={handleSendMessage}
            />
          </div>

          {/* Bottom Center: Skills & Dragonfire RPG Hotbar */}
          <div className="order-1 sm:order-2 mx-auto sm:mx-0">
            <Hotbar
              stats={stats}
              onTriggerSkill={(skillId) => setActiveSkillTrigger(skillId)}
              onSelectWeapon={(weaponId) => {
                const w = WEAPONS_CATALOG[weaponId];
                if (w) {
                  setStats((prev) => ({
                    ...prev,
                    selectedWeaponId: weaponId,
                    clipSize: w.clipSize,
                    ammoInClip: Math.min(prev.ammoInClip, w.clipSize),
                    maxReserve: w.maxReserve,
                  }));
                  setChatMessages((msgs) => [
                    ...msgs.slice(-25),
                    {
                      id: 'm_' + Date.now(),
                      author: 'Armory',
                      authorColor: w.glowColor,
                      text: `Equipped: ${w.name}`,
                      timestamp: Date.now(),
                    },
                  ]);
                }
              }}
            />
          </div>
        </div>
      </div>

      {/* Modals & Overlays */}
      {!hasStarted && (
        <StartOverlay
          onStart={() => {
            setHasStarted(true);
            sounds.playRocketLaunch();
          }}
        />
      )}

      {shopOpen && (
        <ShopModal
          stats={stats}
          onClose={() => setShopOpen(false)}
          onUpdateStats={setStats}
          onSelectWeapon={(wId) => {
            const w = WEAPONS_CATALOG[wId];
            if (w) {
              setStats((prev) => ({
                ...prev,
                selectedWeaponId: wId,
                clipSize: w.clipSize,
                ammoInClip: Math.min(prev.ammoInClip, w.clipSize),
              }));
              sounds.playEquip();
              setChatMessages((msgs) => [
                ...msgs.slice(-25),
                {
                  id: 'm_' + Date.now(),
                  author: 'Armory',
                  authorColor: w.glowColor,
                  text: `Equipped: ${w.name}`,
                  timestamp: Date.now(),
                },
              ]);
            }
          }}
        />
      )}

      {controlsOpen && (
        <ControlsGuideModal onClose={() => setControlsOpen(false)} />
      )}

      {stats.hp <= 0 && (
        <GameOverModal stats={stats} onRespawn={handleRespawn} />
      )}

      {stats.gameWon && (
        <VictoryModal
          stats={stats}
          onContinueEndless={() => {
            setStats((prev) => ({ ...prev, gameWon: false }));
          }}
          onRestart={() => {
            setStats({
              level: 25,
              title: 'Warrior',
              hp: 180,
              maxHp: 180,
              mana: 90,
              maxMana: 90,
              gold: 320,
              score: 0,
              selectedWeaponId: 'dragonfire',
              unlockedWeapons: ['dragonfire'],
              ammoInClip: 25,
              clipSize: 25,
              ammoReserve: 200,
              maxReserve: 300,
              potions: 3,
              kills: 0,
              isReloading: false,
              reloadProgress: 0,
              gameWon: false,
              bossAppeared: false,
            });
            setQuest({
              id: 'quest_goblin_horde',
              title: 'Defeat Goblin Horde',
              objective: 'Defeat Goblin Horde',
              current: 0,
              target: 20,
              rewardGold: 250,
              rewardExp: 500,
              completed: false,
            });
          }}
        />
      )}
    </div>
  );
}
