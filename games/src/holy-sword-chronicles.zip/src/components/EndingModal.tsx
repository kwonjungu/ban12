import { Crown, RotateCcw, Skull } from 'lucide-react';
import { TITLE_KEY_ART } from '../assets/gameAssets';
import { GameImage } from './GameImage';

interface EndingModalProps {
  outcome: 'victory' | 'defeat';
  partyLevel: number;
  onRestart: () => void;
}

export function EndingModal({ outcome, partyLevel, onRestart }: EndingModalProps) {
  const isVictory = outcome === 'victory';

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={isVictory ? '대서사시 완결' : '원정대 전멸'}
      className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center p-4"
    >
      <div className="w-full max-w-md rounded-2xl overflow-hidden bg-[#0b0f1c] border-2 border-amber-400/70 shadow-2xl">
        {isVictory && (
          <div className="h-40 w-full relative overflow-hidden">
            <GameImage
              src={TITLE_KEY_ART}
              alt="승리의 여명"
              className="w-full h-full object-cover object-center"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0b0f1c] via-[#0b0f1c]/40 to-transparent" />
          </div>
        )}

        <div className="p-6 sm:p-8 text-center">
          <div className="w-14 h-14 mx-auto rounded-full bg-slate-900 border border-amber-400/50 flex items-center justify-center mb-4">
            {isVictory ? (
              <Crown className="w-7 h-7 text-amber-300" />
            ) : (
              <Skull className="w-7 h-7 text-rose-400" />
            )}
          </div>

          <h2 className="text-2xl font-bold text-amber-100 mb-2">
            {isVictory ? '대서사시의 완결' : '원정대 전멸'}
          </h2>

          <p className="text-sm text-slate-300 leading-relaxed mb-6">
            {isVictory
              ? `마왕 말라카르를 쓰러뜨리고 에테르니아 대륙에 영원한 빛과 평화를 되찾았습니다. (최종 원정대 Lv.${partyLevel})`
              : '어둠의 힘 앞에 원정대가 쓰러졌습니다. 다시 일어서서 세계를 구원해 주세요.'}
          </p>

          <button
            type="button"
            onClick={onRestart}
            className="w-full h-12 rounded-xl bg-gradient-to-b from-amber-400 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-slate-950 font-bold text-sm sm:text-base inline-flex items-center justify-center gap-2 cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>타이틀로 돌아가기</span>
          </button>
        </div>
      </div>
    </div>
  );
}
