import { Play, Compass, ShieldAlert, Users } from 'lucide-react';
import { TITLE_KEY_ART, CHARACTER_PORTRAITS } from '../assets/gameAssets';
import { GameImage } from './GameImage';

interface TitleScreenProps {
  onStartGame: () => void;
}

const HERO_PREVIEW = [
  { id: 'hero' as const, name: '아르스', role: '빛의 성기사' },
  { id: 'kyle' as const, name: '카일', role: '왕국 근위검사' },
  { id: 'elena' as const, name: '엘레나', role: '고대 마법학자' },
  { id: 'seraphim' as const, name: '세라핌', role: '전투치유사' },
];

export function TitleScreen({ onStartGame }: TitleScreenProps) {
  return (
    <section className="relative flex-1 w-full min-h-[calc(100dvh-4rem)] flex items-end lg:items-center overflow-hidden bg-[#090b12]">
      {/* Full-bleed Generated Title Key Art */}
      <div className="absolute inset-0">
        <GameImage
          src={TITLE_KEY_ART}
          alt="성검의 연대기 메인 키 아트"
          fallbackLabel="성검의 연대기"
          className="w-full h-full object-cover object-center"
        />
        {/* Measured contrast scrims ensuring >= 4.5:1 legibility across desktop and mobile */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#090b12] via-[#090b12]/70 to-[#090b12]/25" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#090b12]/90 via-[#090b12]/55 to-transparent" />
      </div>

      {/* Main Content Container */}
      <div className="relative z-10 w-full max-w-6xl mx-auto px-5 sm:px-8 lg:px-12 py-10 sm:py-14 grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-end">
        {/* Left Column: Title & Primary CTA */}
        <div className="lg:col-span-7 space-y-5">
          <div className="flex items-center gap-2.5 text-xs sm:text-sm text-amber-300/90 font-display tracking-[0.25em]">
            <span>CHRONICLES OF THE HOLY SWORD</span>
            <span aria-hidden="true" className="text-amber-500/60">·</span>
            <span>3D TURN-BASED RPG</span>
          </div>

          <h1
            className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-amber-100 leading-[1.15]"
            style={{ textWrap: 'balance' }}
          >
            성검의 연대기
          </h1>

          <p className="max-w-xl text-sm sm:text-base text-slate-200 leading-relaxed">
            1,000년의 봉인을 깨고 부활하려는 심연의 마왕 말라카르. 빛의 성검을 뽑은 용사가 되어
            광활한 에테르니아 대륙과 지하 던전을 탐험하고, 동료들과 유대를 맺어 세계를 구원하십시오.
          </p>

          {/* Compact Core Pillars (Clean unboxed typography) */}
          <div className="flex flex-wrap items-center gap-x-6 gap-y-2 pt-1 text-xs sm:text-sm text-slate-300">
            <span className="inline-flex items-center gap-2">
              <Compass className="w-4 h-4 text-amber-300 shrink-0" />
              3D 오픈 월드 · 던전 탐험
            </span>
            <span className="inline-flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-sky-300 shrink-0" />
              약점 실드 브레이크 전투
            </span>
            <span className="inline-flex items-center gap-2">
              <Users className="w-4 h-4 text-emerald-300 shrink-0" />
              4인 원정대 서사시
            </span>
          </div>

          <div className="pt-3">
            <button
              type="button"
              onClick={onStartGame}
              className="h-13 px-8 rounded-xl bg-gradient-to-b from-amber-400 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-slate-950 font-bold text-base sm:text-lg tracking-wide inline-flex items-center gap-3 shadow-[0_8px_28px_rgba(245,158,11,0.35)] transition-transform duration-150 active:scale-[0.98] whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-200"
            >
              <Play className="w-5 h-5 fill-slate-950" />
              <span>모험 시작하기</span>
            </button>
          </div>
        </div>

        {/* Right Column: Companion Portrait Strip */}
        <div className="lg:col-span-5">
          <div className="rounded-2xl bg-[#0c101b]/90 border border-amber-500/25 p-4 sm:p-5">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-xs sm:text-sm font-semibold text-amber-200 tracking-wide">
                빛의 원정대 주요 영웅
              </h2>
              <span className="text-xs text-slate-400 tabular-nums">4명의 동료</span>
            </div>
            <div className="grid grid-cols-4 gap-2.5">
              {HERO_PREVIEW.map((hero) => (
                <div key={hero.id} className="group">
                  <div className="aspect-square rounded-xl overflow-hidden border border-amber-500/30 bg-slate-900">
                    <GameImage
                      src={CHARACTER_PORTRAITS[hero.id]}
                      alt={`${hero.name} 초상화`}
                      fallbackLabel={hero.name}
                      className="w-full h-full object-cover object-top transition-transform duration-300 group-hover:scale-105"
                    />
                  </div>
                  <div className="mt-1.5 text-center">
                    <div className="text-xs font-semibold text-slate-100 truncate">{hero.name}</div>
                    <div className="text-[11px] text-slate-400 truncate hidden sm:block">{hero.role}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
