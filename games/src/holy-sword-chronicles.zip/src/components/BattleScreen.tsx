import { useEffect } from 'react';
import { Shield, Swords, Zap } from 'lucide-react';
import type { BattleLogEntry, EnemyData, PartyMember, TurnUnit, ZoneId } from '../types/game';
import { CHARACTER_PORTRAITS, ENEMY_ART, SCENE_BACKDROPS } from '../assets/gameAssets';
import { GameImage } from './GameImage';
import { ElementBadge, ElementIcon } from './ElementIcon';

interface BattleScreenProps {
  zone: ZoneId;
  chapterBackdropKey: 'arcadia' | 'library' | 'solaris' | 'abyss';
  enemy: EnemyData;
  party: PartyMember[];
  turnQueue: TurnUnit[];
  activeUnit: TurnUnit | null;
  isEnemyBroken: boolean;
  enemyShakeKey: number;
  healFlashKey: number;
  floatingDamage: { id: number; text: string; tone: 'normal' | 'weak' | 'break' } | null;
  logs: BattleLogEntry[];
  onUseSkill: (skillIdx: number) => void;
}

export function BattleScreen({
  zone,
  chapterBackdropKey,
  enemy,
  party,
  turnQueue,
  activeUnit,
  isEnemyBroken,
  enemyShakeKey,
  healFlashKey,
  floatingDamage,
  logs,
  onUseSkill,
}: BattleScreenProps) {
  const activeAlly =
    activeUnit?.type === 'ally' ? party.find((member) => member.id === activeUnit.id) ?? null : null;

  const backdropSrc =
    zone === 'crypt'
      ? SCENE_BACKDROPS.crypt
      : zone === 'volcano'
        ? SCENE_BACKDROPS.volcano
        : SCENE_BACKDROPS[chapterBackdropKey];

  const enemyArtSrc = ENEMY_ART[enemy.id] ?? ENEMY_ART.field_slime;
  const enemyHpPct = Math.max(0, Math.round((enemy.hp / enemy.maxHp) * 100));

  // Keyboard shortcuts 1-4 for active ally skills
  useEffect(() => {
    if (!activeAlly) return;
    const handleKey = (e: KeyboardEvent) => {
      const idx = Number(e.key) - 1;
      if (idx >= 0 && idx < activeAlly.skills.length) {
        const skill = activeAlly.skills[idx];
        if (activeAlly.mp >= skill.mp) {
          onUseSkill(idx);
        }
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [activeAlly, onUseSkill]);

  return (
    <section className="relative flex-1 w-full min-h-[calc(100dvh-4rem)] flex flex-col justify-between overflow-hidden bg-[#090b12]">
      {/* Generated Battle Stage Backdrop */}
      <div className="absolute inset-0">
        <GameImage
          src={backdropSrc}
          alt="전투 배경"
          className="w-full h-full object-cover object-center opacity-55"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#090b12]/80 via-[#090b12]/45 to-[#090b12]/95" />
      </div>

      {/* Main Layout Container */}
      <div className="relative z-10 w-full max-w-6xl mx-auto flex-1 flex flex-col justify-between gap-3 p-3 sm:p-5">
        {/* Top Row: Turn Timeline & Break Rule Hint */}
        <div className="flex flex-wrap items-center justify-between gap-2 bg-[#0b0f1c]/92 border border-slate-700/70 rounded-xl px-3.5 py-2.5">
          <div className="flex items-center gap-2 overflow-x-auto min-w-0">
            <span className="text-xs font-semibold text-amber-300 whitespace-nowrap shrink-0">
              행동 순서
            </span>
            <div className="flex items-center gap-1.5">
              {turnQueue.slice(0, 6).map((unit, idx) => (
                <div
                  key={`${unit.id}-${idx}`}
                  className={`flex items-center gap-1.5 px-2 py-1 rounded-lg border text-xs whitespace-nowrap shrink-0 ${
                    unit.type === 'enemy'
                      ? 'bg-rose-950/80 border-rose-500/50 text-rose-200'
                      : 'bg-slate-900/90 border-amber-500/35 text-slate-100'
                  } ${idx === 0 ? 'ring-2 ring-amber-400 font-bold' : 'opacity-80'}`}
                >
                  <GameImage
                    src={unit.portraitSrc}
                    alt={unit.name}
                    className="w-5 h-5 rounded object-cover object-top"
                  />
                  <span>{unit.name}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="text-xs text-slate-300 hidden md:flex items-center gap-1.5 shrink-0">
            <Zap className="w-3.5 h-3.5 text-amber-300" />
            <span>약점 공격으로 실드를 0으로 만들면 BREAK (행동 불능 · 피해 1.5배)</span>
          </div>
        </div>

        {/* Center Stage: Enemy Showcase */}
        <div className="flex-1 flex items-center justify-center py-2">
          <div
            key={enemyShakeKey}
            className={`relative w-full max-w-lg bg-[#0b0f1c]/92 border rounded-2xl p-4 sm:p-5 shadow-2xl ${
              isEnemyBroken ? 'border-rose-500/80' : 'border-amber-500/30'
            } ${enemyShakeKey > 0 ? 'animate-hit-shake' : ''}`}
          >
            {/* Floating Damage Number */}
            {floatingDamage && (
              <div
                key={floatingDamage.id}
                className={`pointer-events-none absolute left-1/2 top-16 z-30 font-display text-2xl sm:text-3xl font-black drop-shadow-[0_4px_12px_rgba(0,0,0,0.95)] animate-float-damage ${
                  floatingDamage.tone === 'break'
                    ? 'text-rose-400'
                    : floatingDamage.tone === 'weak'
                      ? 'text-amber-300'
                      : 'text-white'
                }`}
              >
                {floatingDamage.text}
              </div>
            )}

            <div className="flex flex-col sm:flex-row items-center gap-4 sm:gap-5">
              {/* Generated Enemy Artwork */}
              <div className="relative w-36 h-36 sm:w-44 sm:h-44 rounded-xl overflow-hidden border border-rose-500/40 bg-slate-950 shrink-0 shadow-[0_0_28px_rgba(244,63,94,0.2)]">
                <GameImage
                  src={enemyArtSrc}
                  alt={enemy.name}
                  fallbackLabel={enemy.name}
                  className="w-full h-full object-cover object-center"
                />
                {isEnemyBroken && (
                  <div className="absolute inset-x-0 bottom-0 bg-rose-600/90 text-white text-center text-xs font-bold py-1 tracking-wider">
                    BREAK · 피해 1.5x
                  </div>
                )}
              </div>

              {/* Enemy Combat Telemetry */}
              <div className="flex-1 w-full min-w-0 space-y-3">
                <div>
                  <div className="text-xs text-rose-300/90 font-medium mb-0.5">
                    {enemy.isBoss ? '주요 보스' : '적대 개체'}
                  </div>
                  <h2 className="text-lg sm:text-xl font-bold text-slate-100 truncate">
                    {enemy.name}
                  </h2>
                </div>

                {/* Shield Pips */}
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                  <span className="inline-flex items-center gap-1.5 text-sky-300 font-semibold whitespace-nowrap">
                    <Shield className="w-4 h-4" />
                    실드 방어력
                  </span>
                  <div className="flex flex-wrap items-center gap-1 tabular-nums">
                    {Array.from({ length: enemy.maxShield }).map((_, i) => (
                      <span
                        key={i}
                        className={`w-3 h-2 rounded-sm transition-colors ${
                          i < enemy.shield ? 'bg-sky-400' : 'bg-slate-800 border border-slate-700'
                        }`}
                      />
                    ))}
                    <span className="ml-1.5 text-sky-200 font-bold">
                      {enemy.shield}/{enemy.maxShield}
                    </span>
                  </div>
                </div>

                {/* Weaknesses */}
                <div className="flex flex-wrap items-center gap-1.5">
                  <span className="text-xs text-slate-400 mr-1">약점</span>
                  {enemy.weaknesses.map((w) => (
                    <ElementBadge key={w} element={w} />
                  ))}
                </div>

                {/* HP Bar */}
                <div>
                  <div className="flex justify-between text-xs mb-1 tabular-nums">
                    <span className="text-slate-400">HP</span>
                    <span className="font-bold text-rose-300">
                      {Math.max(0, enemy.hp)} / {enemy.maxHp}
                    </span>
                  </div>
                  <div className="w-full h-3 rounded-full bg-slate-900 border border-slate-700 overflow-hidden p-0.5">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-rose-700 to-rose-400 transition-all duration-300"
                      style={{ width: `${enemyHpPct}%` }}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Command Deck: Party Cards + Skill Menu + Battle Log */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-3">
          {/* Party Member Cards (7 cols) */}
          <div
            key={healFlashKey}
            className={`lg:col-span-7 grid grid-cols-2 sm:grid-cols-4 gap-2.5 items-start ${
              healFlashKey > 0 ? 'animate-heal-flash rounded-xl' : ''
            }`}
          >
            {party.map((member) => {
              const isActive = activeAlly?.id === member.id;
              const isDead = member.hp <= 0;
              const hpPct = Math.max(0, Math.round((member.hp / member.maxHp) * 100));
              const mpPct = Math.max(0, Math.round((member.mp / member.maxMp) * 100));

              return (
                <div
                  key={member.id}
                  className={`rounded-xl bg-[#0b0f1c]/95 border p-2.5 transition-colors flex flex-col justify-between ${
                    isActive
                      ? 'border-amber-400 ring-2 ring-amber-400/40'
                      : 'border-slate-700/80'
                  } ${isDead ? 'opacity-45 grayscale' : ''}`}
                >
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-10 h-10 rounded-lg overflow-hidden border border-amber-500/30 bg-slate-900 shrink-0">
                      <GameImage
                        src={CHARACTER_PORTRAITS[member.id]}
                        alt={member.name}
                        fallbackLabel={member.shortName}
                        className="w-full h-full object-cover object-top"
                      />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className={`text-xs font-bold truncate ${member.accentColor}`}>
                        {member.shortName}
                      </div>
                      <div className="text-[11px] text-slate-400 tabular-nums">
                        Lv.{member.lv}
                        {member.buffAtk > 0 && (
                          <span className="text-amber-300 ml-1">+{member.buffAtk}</span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="space-y-1.5 tabular-nums">
                    <div>
                      <div className="flex justify-between text-[11px] text-slate-300">
                        <span>HP</span>
                        <span>
                          {Math.max(0, member.hp)}/{member.maxHp}
                        </span>
                      </div>
                      <div className="w-full h-1.5 rounded-full bg-slate-900 overflow-hidden">
                        <div
                          className="h-full bg-emerald-500 transition-all duration-300"
                          style={{ width: `${hpPct}%` }}
                        />
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between text-[11px] text-slate-300">
                        <span>MP</span>
                        <span>
                          {member.mp}/{member.maxMp}
                        </span>
                      </div>
                      <div className="w-full h-1.5 rounded-full bg-slate-900 overflow-hidden">
                        <div
                          className="h-full bg-sky-500 transition-all duration-300"
                          style={{ width: `${mpPct}%` }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Active Skills & Combat Log (5 cols) */}
          <div className="lg:col-span-5 flex flex-col gap-2.5">
            <div className="rounded-xl bg-[#0b0f1c]/95 border border-amber-500/35 p-3">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs sm:text-sm font-bold text-amber-200 inline-flex items-center gap-1.5">
                  <Swords className="w-4 h-4 text-amber-300" />
                  {activeAlly ? `${activeAlly.name}의 행동 선택` : `${enemy.name}의 턴 진행 중...`}
                </span>
                <span className="text-[11px] text-slate-400">턴 종료 시 MP +4</span>
              </div>

              {activeAlly ? (
                <div className="grid grid-cols-2 gap-2">
                  {activeAlly.skills.map((skill, idx) => {
                    const insufficientMp = activeAlly.mp < skill.mp;
                    return (
                      <button
                        key={skill.name}
                        type="button"
                        disabled={insufficientMp}
                        onClick={() => onUseSkill(idx)}
                        className="min-h-[54px] px-3 py-2 rounded-lg border border-amber-500/35 bg-slate-900/90 hover:bg-slate-800 hover:border-amber-300 disabled:opacity-40 disabled:cursor-not-allowed text-left transition-colors flex flex-col justify-between cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400"
                      >
                        <div className="flex items-center justify-between gap-1 w-full">
                          <span className="text-xs font-bold text-slate-100 inline-flex items-center gap-1 truncate">
                            {skill.element && <ElementIcon element={skill.element} className="w-3.5 h-3.5 text-amber-300 shrink-0" />}
                            <span className="truncate">{skill.name}</span>
                          </span>
                          <span className="text-[11px] font-semibold text-sky-300 tabular-nums shrink-0">
                            {skill.mp > 0 ? `MP ${skill.mp}` : '0'}
                          </span>
                        </div>
                        <span className="text-[11px] text-slate-400 truncate mt-0.5">{skill.desc}</span>
                      </button>
                    );
                  })}
                </div>
              ) : (
                <div className="h-[116px] flex items-center justify-center text-xs text-slate-400">
                  적의 행동을 주시하고 있습니다...
                </div>
              )}
            </div>

            {/* Real-time Battle Log */}
            <div className="rounded-xl bg-[#090c15]/95 border border-slate-800 p-2.5 h-24 overflow-y-auto space-y-1 text-xs">
              {logs.map((entry) => {
                const toneClass =
                  entry.tone === 'break'
                    ? 'text-rose-400 font-bold'
                    : entry.tone === 'weak'
                      ? 'text-amber-300 font-semibold'
                      : entry.tone === 'heal'
                        ? 'text-emerald-300'
                        : entry.tone === 'buff'
                          ? 'text-sky-300'
                          : entry.tone === 'enemy'
                            ? 'text-rose-300'
                            : 'text-slate-300';
                return (
                  <p key={entry.id} className={toneClass}>
                    {entry.text}
                  </p>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
