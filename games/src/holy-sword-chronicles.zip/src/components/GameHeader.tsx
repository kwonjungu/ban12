import { BookOpen, RotateCcw, Volume2, VolumeX } from 'lucide-react';
import type { GameScreen } from '../types/game';

interface GameHeaderProps {
  screen: GameScreen;
  chapterBadge: string;
  partyLevel: number;
  audioEnabled: boolean;
  onToggleAudio: () => void;
  onOpenRoster: () => void;
  onReturnTitle: () => void;
}

export function GameHeader({
  screen,
  chapterBadge,
  partyLevel,
  audioEnabled,
  onToggleAudio,
  onOpenRoster,
  onReturnTitle,
}: GameHeaderProps) {
  return (
    <header className="w-full h-14 sm:h-16 px-4 sm:px-6 bg-[#0b0e17]/95 border-b border-amber-500/20 flex items-center justify-between gap-4 shrink-0 z-30">
      {/* Zone 1: Brand Title */}
      <button
        type="button"
        onClick={onReturnTitle}
        className="text-left flex items-baseline gap-2.5 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400 rounded px-1 py-0.5 cursor-pointer"
        title="타이틀 화면으로"
      >
        <span className="font-display text-base sm:text-lg font-bold tracking-wider text-amber-200">
          성검의 연대기
        </span>
        <span className="hidden md:inline font-display text-[11px] tracking-[0.22em] text-slate-400">
          CHRONICLES OF THE HOLY SWORD
        </span>
      </button>

      {/* Zone 2: Clean Unboxed Chapter Metadata */}
      <div className="hidden sm:flex items-center gap-2 text-xs sm:text-sm text-slate-300 truncate min-w-0">
        <span className="truncate font-medium text-amber-100/90">{chapterBadge}</span>
        {screen !== 'title' && (
          <>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span className="tabular-nums text-slate-400 shrink-0">원정대 Lv.{partyLevel}</span>
          </>
        )}
      </div>

      {/* Zone 3: Functional Controls */}
      <div className="flex items-center gap-2 shrink-0">
        {screen !== 'title' && (
          <>
            <button
              type="button"
              onClick={onOpenRoster}
              className="h-10 px-3 rounded-lg border border-amber-500/30 bg-slate-900/80 hover:bg-slate-800 hover:border-amber-400/60 text-xs font-semibold text-amber-100 inline-flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400"
            >
              <BookOpen className="w-4 h-4 text-amber-300" />
              <span>원정대</span>
            </button>
            <button
              type="button"
              onClick={onReturnTitle}
              aria-label="타이틀로 돌아가기"
              title="타이틀로 돌아가기"
              className="w-10 h-10 rounded-lg border border-slate-700 bg-slate-900/80 hover:bg-slate-800 hover:border-slate-500 text-slate-300 inline-flex items-center justify-center transition-colors shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </>
        )}
        <button
          type="button"
          onClick={onToggleAudio}
          aria-label={audioEnabled ? '효과음 끄기' : '효과음 켜기'}
          title={audioEnabled ? '효과음 끄기' : '효과음 켜기'}
          className="w-10 h-10 rounded-lg border border-amber-500/30 bg-slate-900/80 hover:bg-slate-800 hover:border-amber-400/60 text-amber-200 inline-flex items-center justify-center transition-colors shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400"
        >
          {audioEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
        </button>
      </div>
    </header>
  );
}
