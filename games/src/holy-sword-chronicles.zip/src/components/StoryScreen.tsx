import { ChevronRight, Swords, FastForward } from 'lucide-react';
import type { StoryChapter } from '../types/game';
import { CHARACTER_PORTRAITS, ENEMY_ART, SCENE_BACKDROPS } from '../assets/gameAssets';
import { GameImage } from './GameImage';

interface StoryScreenProps {
  chapter: StoryChapter;
  dialogueIndex: number;
  onNext: () => void;
  onSkipToBattle: () => void;
}

export function StoryScreen({ chapter, dialogueIndex, onNext, onSkipToBattle }: StoryScreenProps) {
  const dialogue = chapter.dialogues[dialogueIndex] ?? chapter.dialogues[0];
  const isLast = dialogueIndex >= chapter.dialogues.length - 1;
  const backdropSrc = SCENE_BACKDROPS[chapter.backdropKey];

  let portraitSrc = '';
  if (dialogue.speakerId === 'malakar') {
    portraitSrc = ENEMY_ART.malakar;
  } else if (dialogue.speakerId && dialogue.speakerId !== 'narrator') {
    portraitSrc = CHARACTER_PORTRAITS[dialogue.speakerId];
  }

  return (
    <section className="relative flex-1 w-full min-h-[calc(100dvh-4rem)] flex flex-col justify-between overflow-hidden bg-[#090b12]">
      {/* Generated Environment Backdrop */}
      <div className="absolute inset-0">
        <GameImage
          src={backdropSrc}
          alt={chapter.location}
          fallbackLabel={chapter.location}
          className="w-full h-full object-cover object-center"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#090b12] via-[#090b12]/55 to-[#090b12]/40" />
      </div>

      {/* Top Location Header */}
      <div className="relative z-10 w-full max-w-5xl mx-auto px-4 sm:px-8 pt-5 sm:pt-8 flex flex-col sm:flex-row items-start justify-between gap-3 sm:gap-4">
        <div className="bg-[#0b0f1c]/90 border border-amber-500/30 rounded-xl px-4 py-3 max-w-xl w-full sm:w-auto">
          <div className="text-xs text-amber-300 font-semibold mb-1">{chapter.badge}</div>
          <h2 className="text-lg sm:text-2xl font-bold text-slate-100">{chapter.location}</h2>
          <p className="text-xs sm:text-sm text-slate-300 mt-1 leading-relaxed">{chapter.desc}</p>
        </div>

        <button
          type="button"
          onClick={onSkipToBattle}
          className="h-10 px-3.5 rounded-lg bg-[#0b0f1c]/90 border border-slate-600/60 hover:border-amber-400/60 text-xs font-medium text-slate-200 inline-flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 self-end sm:self-start cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400"
        >
          <FastForward className="w-3.5 h-3.5 text-amber-300" />
          <span>전투로 건너뛰기</span>
        </button>
      </div>

      {/* Bottom Dialogue & Speaker Portrait Panel */}
      <div className="relative z-10 w-full max-w-5xl mx-auto px-4 sm:px-8 pb-6 sm:pb-8 mt-auto">
        <div className="bg-[#0b0f1c]/95 border border-amber-500/40 rounded-2xl p-4 sm:p-6 shadow-2xl flex flex-col sm:flex-row items-stretch gap-4 sm:gap-6">
          {portraitSrc && (
            <div className="w-24 h-24 sm:w-32 sm:h-32 rounded-xl overflow-hidden border border-amber-400/50 bg-slate-900 shrink-0 self-start">
              <GameImage
                src={portraitSrc}
                alt={dialogue.speaker}
                fallbackLabel={dialogue.speaker}
                className="w-full h-full object-cover object-top"
              />
            </div>
          )}

          <div className="flex-1 flex flex-col justify-between min-w-0">
            <div>
              <div className="flex flex-wrap items-center gap-2 mb-2">
                <span className="text-sm sm:text-base font-bold text-amber-300">{dialogue.speaker}</span>
                <span aria-hidden="true" className="text-slate-600">·</span>
                <span className="text-xs text-slate-400">{dialogue.role}</span>
                <span className="ml-auto text-xs text-slate-400 tabular-nums">
                  {dialogueIndex + 1} / {chapter.dialogues.length}
                </span>
              </div>
              <p className="text-sm sm:text-base lg:text-lg text-slate-100 leading-relaxed min-h-[3.5rem]">
                {dialogue.text}
              </p>
            </div>

            <div className="flex justify-end mt-4">
              <button
                type="button"
                onClick={onNext}
                className={`h-11 px-6 rounded-xl font-bold text-sm sm:text-base inline-flex items-center gap-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-300 ${
                  isLast
                    ? 'bg-gradient-to-b from-rose-500 to-rose-700 hover:from-rose-400 hover:to-rose-600 text-white shadow-lg'
                    : 'bg-gradient-to-b from-amber-400 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-slate-950'
                }`}
              >
                {isLast ? (
                  <>
                    <Swords className="w-4 h-4" />
                    <span>전투 돌입</span>
                  </>
                ) : (
                  <>
                    <span>다음 대사</span>
                    <ChevronRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
