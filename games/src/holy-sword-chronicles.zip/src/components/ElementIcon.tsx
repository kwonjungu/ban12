import { Flame, Sparkles, Sword, Cross } from 'lucide-react';
import type { ElementType } from '../types/game';
import { ELEMENTS } from '../data/gameData';

interface ElementBadgeProps {
  element: ElementType;
  showLabel?: boolean;
  size?: 'sm' | 'md';
}

export function ElementIcon({ element, className = 'w-3.5 h-3.5' }: { element: ElementType; className?: string }) {
  switch (element) {
    case 'SWORD':
      return <Sword className={className} />;
    case 'FIRE':
      return <Flame className={className} />;
    case 'LIGHT':
      return <Sparkles className={className} />;
    case 'HOLY':
      return <Cross className={className} />;
  }
}

export function ElementBadge({ element, showLabel = true, size = 'sm' }: ElementBadgeProps) {
  const meta = ELEMENTS[element];
  return (
    <span
      className={`inline-flex items-center gap-1 border rounded font-semibold whitespace-nowrap shrink-0 ${meta.badgeBg} ${
        size === 'sm' ? 'px-2 py-0.5 text-xs' : 'px-2.5 py-1 text-xs'
      }`}
    >
      <ElementIcon element={element} className="w-3.5 h-3.5" />
      {showLabel && <span>{meta.name}</span>}
    </span>
  );
}
