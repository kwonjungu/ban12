import { useState } from 'react';
import { ImageOff } from 'lucide-react';

interface GameImageProps {
  src: string;
  alt: string;
  className?: string;
  fallbackLabel?: string;
}

export function GameImage({ src, alt, className = '', fallbackLabel }: GameImageProps) {
  const [failed, setFailed] = useState(false);

  if (failed || !src) {
    return (
      <div
        role="img"
        aria-label={alt}
        className={`flex flex-col items-center justify-center bg-gradient-to-br from-slate-800 via-slate-900 to-slate-950 text-amber-300/70 ${className}`}
      >
        <ImageOff className="w-6 h-6 mb-1 opacity-70" />
        {fallbackLabel && (
          <span className="text-xs font-medium text-slate-300 px-2 text-center truncate max-w-full">
            {fallbackLabel}
          </span>
        )}
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setFailed(true)}
      className={className}
      loading="eager"
      decoding="async"
    />
  );
}
