import { X, Shield, Sparkles } from 'lucide-react';
import type { PartyMember } from '../types/game';
import { CHARACTER_PORTRAITS } from '../assets/gameAssets';
import { GameImage } from './GameImage';
import { ElementIcon } from './ElementIcon';

interface PartyModalProps {
  party: PartyMember[];
  onClose: () => void;
}

export function PartyModal({ party, onClose }: PartyModalProps) {
  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="원정대 상세 정보"
      className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4"
    >
      <div className="w-full max-w-4xl max-h-[88dvh] bg-[#0b0f1c] border border-amber-500/40 rounded-2xl overflow-hidden flex flex-col shadow-2xl">
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-amber-200">빛의 원정대 현황 및 보유 스킬</h2>
            <p className="text-xs text-slate-400 mt-0.5">
              각 영웅의 속성과 약점 브레이크 스킬을 확인하세요.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="닫기"
            className="w-10 h-10 rounded-lg border border-slate-700 hover:border-amber-400/60 text-slate-300 inline-flex items-center justify-center cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 sm:p-6 overflow-y-auto grid grid-cols-1 md:grid-cols-2 gap-4">
          {party.map((member) => (
            <div
              key={member.id}
              className="rounded-xl bg-slate-900/80 border border-slate-700/80 p-4 space-y-3"
            >
              <div className="flex items-center gap-3.5">
                <div className="w-16 h-16 rounded-xl overflow-hidden border border-amber-400/40 bg-slate-950 shrink-0">
                  <GameImage
                    src={CHARACTER_PORTRAITS[member.id]}
                    alt={member.name}
                    fallbackLabel={member.shortName}
                    className="w-full h-full object-cover object-top"
                  />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between">
                    <span className={`text-base font-bold ${member.accentColor}`}>{member.name}</span>
                    <span className="text-xs font-semibold text-amber-200 tabular-nums">
                      Lv.{member.lv}
                    </span>
                  </div>
                  <div className="text-xs text-slate-400">{member.role}</div>
                  <div className="flex items-center gap-3 text-xs text-slate-300 mt-1.5 tabular-nums">
                    <span>HP {member.hp}/{member.maxHp}</span>
                    <span aria-hidden="true" className="text-slate-600">·</span>
                    <span>MP {member.mp}/{member.maxMp}</span>
                    <span aria-hidden="true" className="text-slate-600">·</span>
                    <span>ATK {member.atk}</span>
                    <span aria-hidden="true" className="text-slate-600">·</span>
                    <span>SPD {member.spd}</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 pt-1">
                {member.skills.map((skill) => (
                  <div
                    key={skill.name}
                    className="rounded-lg bg-slate-950/90 border border-slate-800 px-2.5 py-2"
                  >
                    <div className="flex items-center justify-between gap-1 text-xs font-semibold text-slate-100">
                      <span className="inline-flex items-center gap-1 truncate">
                        {skill.element ? (
                          <ElementIcon element={skill.element} className="w-3.5 h-3.5 text-amber-300 shrink-0" />
                        ) : (
                          <Sparkles className="w-3.5 h-3.5 text-emerald-300 shrink-0" />
                        )}
                        <span className="truncate">{skill.name}</span>
                      </span>
                      <span className="text-[11px] text-sky-300 tabular-nums shrink-0">
                        {skill.mp > 0 ? `${skill.mp}` : '0'}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-0.5 truncate">{skill.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="px-5 py-3 border-t border-slate-800 bg-slate-950/70 flex items-center justify-between text-xs text-slate-400">
          <span className="inline-flex items-center gap-1.5">
            <Shield className="w-4 h-4 text-sky-400" />
            야영 버튼을 누르면 파티 HP/MP가 모두 회복되고 필드 마물이 다시 출현합니다.
          </span>
          <button
            type="button"
            onClick={onClose}
            className="h-9 px-4 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold cursor-pointer"
          >
            확인
          </button>
        </div>
      </div>
    </div>
  );
}
