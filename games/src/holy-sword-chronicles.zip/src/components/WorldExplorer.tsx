import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import {
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  Compass,
  DoorOpen,
  Eye,
  EyeOff,
  Map as MapIcon,
  Tent,
} from 'lucide-react';
import type { EnemyShape, PartyMember, StoryChapter, ZoneId } from '../types/game';
import { DUNGEON_PORTALS, ENEMIES, STORY_CHAPTERS, WORLD_HALF_SIZE } from '../data/gameData';
import { CHARACTER_PORTRAITS, SCENE_BACKDROPS } from '../assets/gameAssets';
import {
  createAncientRuinModel,
  createCharacterModel,
  createGroundTexture,
  createMonsterModel,
  createPineTreeModel,
} from '../three/proceduralModels';
import { GameImage } from './GameImage';

interface WorldExplorerProps {
  isActive: boolean;
  party: PartyMember[];
  currentChapter: StoryChapter;
  currentChapterIdx: number;
  zone: ZoneId;
  campTrigger: number;
  resetTrigger: number;
  toast: { title: string; desc: string } | null;
  onEnterStoryBeacon: () => void;
  onEncounterMonster: (enemyId: string) => void;
  onZoneChange: (nextZone: ZoneId, toastTitle: string, toastDesc: string) => void;
  onCamp: () => void;
}

interface FieldMonsterEntry {
  mesh: THREE.Group;
  enemyId: string;
  baseX: number;
  baseZ: number;
  phase: number;
  active: boolean;
}

const _targetVec = new THREE.Vector3();

export function WorldExplorer({
  isActive,
  party,
  currentChapter,
  currentChapterIdx,
  zone,
  campTrigger,
  resetTrigger,
  toast,
  onEnterStoryBeacon,
  onEncounterMonster,
  onZoneChange,
  onCamp,
}: WorldExplorerProps) {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const minimapRef = useRef<HTMLCanvasElement | null>(null);

  const [webglError, setWebglError] = useState(false);
  const [hudCompact, setHudCompact] = useState(() =>
    typeof window !== 'undefined' ? window.innerWidth < 640 : false,
  );
  const [goalDistance, setGoalDistance] = useState<number>(44);
  const [goalBearingDeg, setGoalBearingDeg] = useState<number>(0);

  // Mutable refs for 3D loop access without tearing down WebGL
  const isActiveRef = useRef(isActive);
  isActiveRef.current = isActive;

  const partyRef = useRef(party);
  partyRef.current = party;

  const chapterIdxRef = useRef(currentChapterIdx);
  chapterIdxRef.current = currentChapterIdx;

  const zoneRef = useRef<ZoneId>(zone);
  zoneRef.current = zone;

  const callbacksRef = useRef({
    onEnterStoryBeacon,
    onEncounterMonster,
    onZoneChange,
  });
  callbacksRef.current = {
    onEnterStoryBeacon,
    onEncounterMonster,
    onZoneChange,
  };

  const moveKeysRef = useRef({ up: false, down: false, left: false, right: false });
  const playerPosRef = useRef({ x: 0, z: 18 });
  const savedOverworldPosRef = useRef({ x: 0, z: 18 });
  const cameraAngleRef = useRef(0);
  const encounterCooldownRef = useRef(false);

  // Scene object refs for dynamic updates
  const sceneObjectsRef = useRef<{
    scene: THREE.Scene;
    renderer: THREE.WebGLRenderer;
    camera: THREE.PerspectiveCamera;
    overworldGroup: THREE.Group;
    dungeonGroup: THREE.Group;
    playerGroup: THREE.Group;
    followerMeshes: THREE.Group[];
    fieldMonsters: FieldMonsterEntry[];
    storyBeacons: { group: THREE.Group; ring: THREE.Mesh; chapterIdx: number }[];
    dungeonPortals: { id: 'crypt' | 'volcano'; name: string; x: number; z: number; vortex: THREE.Mesh }[];
    dungeonExitPortal: { x: number; z: number; ring: THREE.Mesh } | null;
    maxAnisotropy: number;
    texturesToDispose: THREE.Texture[];
  } | null>(null);

  // Reset cooldown when becoming active again
  useEffect(() => {
    if (isActive) {
      moveKeysRef.current = { up: false, down: false, left: false, right: false };
      const t = window.setTimeout(() => {
        encounterCooldownRef.current = false;
      }, 650);
      return () => window.clearTimeout(t);
    }
  }, [isActive]);

  // Spawn helpers
  const spawnOverworldMonsters = () => {
    const objs = sceneObjectsRef.current;
    if (!objs) return;

    objs.fieldMonsters.forEach((m) => objs.scene.remove(m.mesh));
    objs.fieldMonsters = [];

    const spawns: { x: number; z: number; enemyId: string; shape: EnemyShape; color: number; scale: number }[] = [
      { x: -16, z: -4, enemyId: 'field_slime', shape: 'slime', color: 0x38bdf8, scale: 1.0 },
      { x: 18, z: -6, enemyId: 'field_slime', shape: 'slime', color: 0x38bdf8, scale: 1.0 },
      { x: 0, z: -10, enemyId: 'field_slime', shape: 'slime', color: 0x38bdf8, scale: 1.0 },
      { x: -24, z: -22, enemyId: 'field_goblin', shape: 'goblin', color: 0x4ade80, scale: 1.05 },
      { x: 26, z: -20, enemyId: 'field_goblin', shape: 'goblin', color: 0x4ade80, scale: 1.05 },
      { x: -38, z: -34, enemyId: 'field_wolf', shape: 'wolf', color: 0x94a3b8, scale: 1.1 },
      { x: 36, z: -36, enemyId: 'field_wolf', shape: 'wolf', color: 0x94a3b8, scale: 1.1 },
      { x: -18, z: -46, enemyId: 'field_salamander', shape: 'salamander', color: 0xf97316, scale: 1.15 },
      { x: 20, z: -48, enemyId: 'field_salamander', shape: 'salamander', color: 0xf97316, scale: 1.15 },
      { x: 46, z: -10, enemyId: 'field_goblin', shape: 'goblin', color: 0x4ade80, scale: 1.1 },
      { x: -46, z: -10, enemyId: 'field_wolf', shape: 'wolf', color: 0x94a3b8, scale: 1.1 },
      { x: 74, z: -26, enemyId: 'field_skeleton', shape: 'skeleton', color: 0xe2e8f0, scale: 1.15 },
      { x: 82, z: -62, enemyId: 'field_skeleton', shape: 'skeleton', color: 0xe2e8f0, scale: 1.2 },
      { x: -76, z: -30, enemyId: 'field_knight', shape: 'knight', color: 0x64748b, scale: 1.2 },
      { x: -84, z: -68, enemyId: 'field_knight', shape: 'knight', color: 0x64748b, scale: 1.2 },
      { x: 42, z: -76, enemyId: 'field_gargoyle', shape: 'gargoyle', color: 0xa855f7, scale: 1.25 },
      { x: -42, z: -76, enemyId: 'field_gargoyle', shape: 'gargoyle', color: 0xa855f7, scale: 1.25 },
      { x: 64, z: 34, enemyId: 'field_salamander', shape: 'salamander', color: 0xf97316, scale: 1.15 },
      { x: -64, z: 34, enemyId: 'field_skeleton', shape: 'skeleton', color: 0xe2e8f0, scale: 1.15 },
      { x: -22, z: -88, enemyId: 'field_wyvern', shape: 'wyvern', color: 0xf43f5e, scale: 1.4 },
      { x: 22, z: -88, enemyId: 'field_wyvern', shape: 'wyvern', color: 0xf43f5e, scale: 1.4 },
    ];

    spawns.forEach((sp) => {
      const mesh = createMonsterModel(sp.shape, sp.color, sp.scale);
      mesh.position.set(sp.x, 0, sp.z);
      objs.scene.add(mesh);
      objs.fieldMonsters.push({
        mesh,
        enemyId: sp.enemyId,
        baseX: sp.x,
        baseZ: sp.z,
        phase: Math.random() * Math.PI * 2,
        active: true,
      });
    });
  };

  const spawnDungeonMonsters = (dungeonId: 'crypt' | 'volcano') => {
    const objs = sceneObjectsRef.current;
    if (!objs) return;

    objs.fieldMonsters.forEach((m) => objs.scene.remove(m.mesh));
    objs.fieldMonsters = [];

    const spawns =
      dungeonId === 'crypt'
        ? [
            { x: -18, z: 20, enemyId: 'dungeon_banshee', shape: 'skeleton' as EnemyShape, color: 0xc084fc, scale: 1.15 },
            { x: 18, z: 20, enemyId: 'dungeon_banshee', shape: 'skeleton' as EnemyShape, color: 0xc084fc, scale: 1.15 },
            { x: -24, z: -4, enemyId: 'dungeon_archmage', shape: 'gargoyle' as EnemyShape, color: 0x818cf8, scale: 1.25 },
            { x: 24, z: 2, enemyId: 'dungeon_archmage', shape: 'gargoyle' as EnemyShape, color: 0x818cf8, scale: 1.25 },
            { x: 0, z: -32, enemyId: 'dungeon_lich', shape: 'wyvern' as EnemyShape, color: 0xe879f9, scale: 1.65 },
          ]
        : [
            { x: -18, z: 20, enemyId: 'dungeon_cerberus', shape: 'wolf' as EnemyShape, color: 0xf97316, scale: 1.2 },
            { x: 18, z: 20, enemyId: 'dungeon_cerberus', shape: 'wolf' as EnemyShape, color: 0xf97316, scale: 1.2 },
            { x: -24, z: -4, enemyId: 'dungeon_drake', shape: 'wyvern' as EnemyShape, color: 0xef4444, scale: 1.3 },
            { x: 24, z: 2, enemyId: 'dungeon_drake', shape: 'wyvern' as EnemyShape, color: 0xef4444, scale: 1.3 },
            { x: 0, z: -32, enemyId: 'dungeon_ifrit', shape: 'knight' as EnemyShape, color: 0xfacc15, scale: 1.7 },
          ];

    spawns.forEach((sp) => {
      const mesh = createMonsterModel(sp.shape, sp.color, sp.scale);
      mesh.position.set(sp.x, 0, sp.z);
      objs.scene.add(mesh);
      objs.fieldMonsters.push({
        mesh,
        enemyId: sp.enemyId,
        baseX: sp.x,
        baseZ: sp.z,
        phase: Math.random() * Math.PI * 2,
        active: true,
      });
    });
  };

  const syncFollowers = () => {
    const objs = sceneObjectsRef.current;
    if (!objs) return;

    objs.followerMeshes.forEach((m) => objs.scene.remove(m));
    objs.followerMeshes = [];

    const members = partyRef.current;
    for (let i = 1; i < members.length; i++) {
      const m = members[i];
      const mesh = createCharacterModel(m.id, m.meshColor);
      mesh.position.set(playerPosRef.current.x - i * 1.6, 0, playerPosRef.current.z + i * 1.6);
      objs.scene.add(mesh);
      objs.followerMeshes.push(mesh);
    }
  };

  const switchIntoDungeon = (dungeonId: 'crypt' | 'volcano') => {
    const objs = sceneObjectsRef.current;
    if (!objs) return;

    savedOverworldPosRef.current = { x: playerPosRef.current.x, z: playerPosRef.current.z + 4.5 };
    objs.overworldGroup.visible = false;
    objs.dungeonGroup.visible = true;

    while (objs.dungeonGroup.children.length > 0) {
      objs.dungeonGroup.remove(objs.dungeonGroup.children[0]);
    }

    const isCrypt = dungeonId === 'crypt';
    const bgHex = isCrypt ? 0x090514 : 0x1a0804;
    objs.scene.background = new THREE.Color(bgHex);
    objs.scene.fog = new THREE.FogExp2(bgHex, 0.016);

    const floorTex = createGroundTexture(dungeonId, objs.maxAnisotropy);
    objs.texturesToDispose.push(floorTex);
    const floor = new THREE.Mesh(
      new THREE.PlaneGeometry(92, 92),
      new THREE.MeshStandardMaterial({ map: floorTex, roughness: 0.85, metalness: 0.1 }),
    );
    floor.rotation.x = -Math.PI / 2;
    floor.receiveShadow = true;
    objs.dungeonGroup.add(floor);

    const wallMat = new THREE.MeshStandardMaterial({
      color: isCrypt ? 0x312e81 : 0x431407,
      roughness: 0.78,
    });
    const wallSpecs = [
      { x: 0, z: -45, w: 92, d: 3 },
      { x: 0, z: 45, w: 92, d: 3 },
      { x: -45, z: 0, w: 3, d: 92 },
      { x: 45, z: 0, w: 3, d: 92 },
      { x: -16, z: 10, w: 26, d: 3 },
      { x: 16, z: -12, w: 26, d: 3 },
    ];
    wallSpecs.forEach((ws) => {
      const wMesh = new THREE.Mesh(new THREE.BoxGeometry(ws.w, 8.5, ws.d), wallMat);
      wMesh.position.set(ws.x, 4.25, ws.z);
      objs.dungeonGroup.add(wMesh);
    });

    const exitRing = new THREE.Mesh(
      new THREE.TorusGeometry(2.3, 0.22, 12, 28),
      new THREE.MeshBasicMaterial({ color: 0x38bdf8 }),
    );
    exitRing.rotation.x = Math.PI / 2;
    exitRing.position.set(0, 0.3, 34);
    objs.dungeonGroup.add(exitRing);
    objs.dungeonExitPortal = { x: 0, z: 34, ring: exitRing };

    playerPosRef.current = { x: 0, z: 26 };
    syncFollowers();
    spawnDungeonMonsters(dungeonId);

    callbacksRef.current.onZoneChange(
      dungeonId,
      isCrypt ? '고대 마력 지하묘지 입장' : '화염의 심연 동굴 입장',
      '강력한 던전 마물과 최심부 수호자가 도사리고 있습니다.',
    );
  };

  const switchToOverworld = () => {
    const objs = sceneObjectsRef.current;
    if (!objs) return;

    objs.dungeonGroup.visible = false;
    objs.overworldGroup.visible = true;
    objs.dungeonExitPortal = null;

    objs.scene.background = new THREE.Color(0x0b132b);
    objs.scene.fog = new THREE.FogExp2(0x0b132b, 0.0075);

    playerPosRef.current = { ...savedOverworldPosRef.current };
    syncFollowers();
    spawnOverworldMonsters();

    callbacksRef.current.onZoneChange(
      'overworld',
      '에테르니아 대평원 귀환',
      '광활한 대륙 평야로 돌아왔습니다.',
    );
  };

  // Sync followers whenever party grows
  useEffect(() => {
    syncFollowers();
  }, [party.length]);

  // Respawn monsters on camp trigger
  useEffect(() => {
    if (campTrigger === 0) return;
    if (zoneRef.current === 'overworld') {
      spawnOverworldMonsters();
    } else {
      spawnDungeonMonsters(zoneRef.current);
    }
  }, [campTrigger]);

  // Reset player position when starting a new game
  useEffect(() => {
    if (resetTrigger === 0) return;
    playerPosRef.current = { x: 0, z: 18 };
    savedOverworldPosRef.current = { x: 0, z: 18 };
    cameraAngleRef.current = 0;
    const objs = sceneObjectsRef.current;
    if (objs) {
      objs.dungeonGroup.visible = false;
      objs.overworldGroup.visible = true;
      objs.dungeonExitPortal = null;
      objs.scene.background = new THREE.Color(0x0b132b);
      objs.scene.fog = new THREE.FogExp2(0x0b132b, 0.0075);
      syncFollowers();
      spawnOverworldMonsters();
    }
  }, [resetTrigger]);

  // Initialize Three.js once
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const isSoftwareGl = (() => {
      const probe = document.createElement('canvas').getContext('webgl2');
      if (!probe) return true;
      const ext = probe.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : probe.RENDERER;
      const gpu = String(probe.getParameter(param));
      probe.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: !isSoftwareGl,
        powerPreference: 'high-performance',
      });
    } catch {
      setWebglError(true);
      return;
    }

    const width = container.clientWidth || 1024;
    const height = container.clientHeight || 640;
    renderer.setSize(width, height);
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.08;
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    const handleContextLost = (e: Event) => {
      e.preventDefault();
      setWebglError(true);
    };
    const handleContextRestored = () => {
      setWebglError(false);
    };
    renderer.domElement.addEventListener('webglcontextlost', handleContextLost);
    renderer.domElement.addEventListener('webglcontextrestored', handleContextRestored);

    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0b132b);
    scene.fog = new THREE.FogExp2(0x0b132b, 0.0075);

    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const envTex = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environment = envTex;
    pmremGenerator.dispose();

    const camera = new THREE.PerspectiveCamera(54, width / height, 0.1, 460);

    // 3-Point / Natural Outdoor Lighting
    const hemiLight = new THREE.HemisphereLight(0x93c5fd, 0x1e293b, 0.75);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight(0xfef3c7, 1.35);
    keyLight.position.set(55, 95, 45);
    keyLight.castShadow = !isSoftwareGl;
    keyLight.shadow.mapSize.set(1024, 1024);
    keyLight.shadow.bias = -0.0005;
    keyLight.shadow.normalBias = 0.02;
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0x60a5fa, 0.45);
    rimLight.position.set(-60, 40, -70);
    scene.add(rimLight);

    const overworldGroup = new THREE.Group();
    const dungeonGroup = new THREE.Group();
    dungeonGroup.visible = false;
    scene.add(overworldGroup, dungeonGroup);

    const texturesToDispose: THREE.Texture[] = [];
    const maxAnisotropy = renderer.capabilities.getMaxAnisotropy();

    // Extended Seamless Ground beyond playable perimeter (no floating void!)
    const overworldTex = createGroundTexture('overworld', maxAnisotropy);
    texturesToDispose.push(overworldTex);
    const ground = new THREE.Mesh(
      new THREE.PlaneGeometry(WORLD_HALF_SIZE * 2.8, WORLD_HALF_SIZE * 2.8),
      new THREE.MeshStandardMaterial({ map: overworldTex, roughness: 0.92, metalness: 0.04 }),
    );
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    overworldGroup.add(ground);

    // Natural Perimeter Mountain Ring & Pine Groves
    const mountainMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.92, metalness: 0.05 });
    for (let i = 0; i < 48; i++) {
      const angle = (i / 48) * Math.PI * 2;
      const dist = WORLD_HALF_SIZE + 14 + (i % 3) * 8;
      const h = 24 + (i % 5) * 9;
      const r = 14 + (i % 4) * 5;
      const peak = new THREE.Mesh(new THREE.ConeGeometry(r, h, 7), mountainMat);
      peak.position.set(Math.cos(angle) * dist, h / 2 - 1, Math.sin(angle) * dist);
      overworldGroup.add(peak);
    }

    // Rich Multi-Part Ruins, Pine Trees, and Crystals
    const crystalMat = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      emissive: 0x0284c7,
      emissiveIntensity: 0.45,
      roughness: 0.25,
      metalness: 0.2,
    });
    for (let i = 0; i < 72; i++) {
      const angle = i * 137.5 * (Math.PI / 180);
      const radius = 25 + (i % 22) * 4.7;
      const x = Math.cos(angle) * radius;
      const z = Math.sin(angle) * radius;
      if (Math.hypot(x, z - 18) < 12) continue;

      if (i % 3 === 0) {
        const ruin = createAncientRuinModel(3.8 + (i % 3));
        ruin.position.set(x, 0, z);
        overworldGroup.add(ruin);
      } else if (i % 3 === 1) {
        const tree = createPineTreeModel();
        tree.position.set(x, 0, z);
        tree.scale.setScalar(0.85 + (i % 4) * 0.12);
        overworldGroup.add(tree);
      } else {
        const crystal = new THREE.Mesh(new THREE.DodecahedronGeometry(1.15, 0), crystalMat);
        crystal.position.set(x, 0.9, z);
        crystal.rotation.set(0.3, i, 0.2);
        overworldGroup.add(crystal);
      }
    }

    // Story Beacons
    const storyBeacons: { group: THREE.Group; ring: THREE.Mesh; chapterIdx: number }[] = [];
    STORY_CHAPTERS.forEach((chap, idx) => {
      const group = new THREE.Group();
      const isFinal = idx === STORY_CHAPTERS.length - 1;
      const color = isFinal ? 0xf43f5e : 0xfbbf24;

      const pillar = new THREE.Mesh(
        new THREE.CylinderGeometry(1.05, 1.05, 24, 16, 1, true),
        new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.34, side: THREE.DoubleSide }),
      );
      pillar.position.y = 12;

      const ring = new THREE.Mesh(
        new THREE.TorusGeometry(2.3, 0.18, 12, 32),
        new THREE.MeshBasicMaterial({ color }),
      );
      ring.rotation.x = Math.PI / 2;
      ring.position.y = 0.28;

      group.add(pillar, ring);
      group.position.set(chap.worldPos.x, 0, chap.worldPos.z);
      overworldGroup.add(group);
      storyBeacons.push({ group, ring, chapterIdx: idx });
    });

    // Dungeon Portals
    const dungeonPortals: { id: 'crypt' | 'volcano'; name: string; x: number; z: number; vortex: THREE.Mesh }[] = [];
    DUNGEON_PORTALS.forEach((p) => {
      const group = new THREE.Group();
      const arch = new THREE.Mesh(
        new THREE.TorusGeometry(2.7, 0.38, 12, 24, Math.PI),
        new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.6, metalness: 0.3 }),
      );
      arch.position.y = 0.2;

      const vortex = new THREE.Mesh(
        new THREE.CircleGeometry(2.35, 24),
        new THREE.MeshBasicMaterial({ color: p.color, transparent: true, opacity: 0.68, side: THREE.DoubleSide }),
      );
      vortex.position.y = 1.45;

      group.add(arch, vortex);
      group.position.set(p.x, 0, p.z);
      overworldGroup.add(group);
      dungeonPortals.push({ id: p.id, name: p.name, x: p.x, z: p.z, vortex });
    });

    // Player Composite Model
    const playerGroup = createCharacterModel('hero', 0xfbbf24);
    playerGroup.position.set(playerPosRef.current.x, 0, playerPosRef.current.z);
    scene.add(playerGroup);

    sceneObjectsRef.current = {
      scene,
      renderer,
      camera,
      overworldGroup,
      dungeonGroup,
      playerGroup,
      followerMeshes: [],
      fieldMonsters: [],
      storyBeacons,
      dungeonPortals,
      dungeonExitPortal: null,
      maxAnisotropy,
      texturesToDispose,
    };

    syncFollowers();
    spawnOverworldMonsters();

    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    // Input Listeners
    let isDragging = false;
    let prevX = 0;

    const onPointerDown = (e: PointerEvent) => {
      isDragging = true;
      prevX = e.clientX;
    };
    const onPointerUp = () => {
      isDragging = false;
    };
    const onPointerMove = (e: PointerEvent) => {
      if (!isDragging || !isActiveRef.current) return;
      const dx = e.clientX - prevX;
      prevX = e.clientX;
      cameraAngleRef.current -= dx * 0.008;
    };

    const onKeyDown = (e: KeyboardEvent) => {
      if (!isActiveRef.current) return;
      const k = e.key.toLowerCase();
      if (k === 'w' || e.key === 'ArrowUp') moveKeysRef.current.up = true;
      if (k === 's' || e.key === 'ArrowDown') moveKeysRef.current.down = true;
      if (k === 'a' || e.key === 'ArrowLeft') moveKeysRef.current.left = true;
      if (k === 'd' || e.key === 'ArrowRight') moveKeysRef.current.right = true;
    };
    const onKeyUp = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      if (k === 'w' || e.key === 'ArrowUp') moveKeysRef.current.up = false;
      if (k === 's' || e.key === 'ArrowDown') moveKeysRef.current.down = false;
      if (k === 'a' || e.key === 'ArrowLeft') moveKeysRef.current.left = false;
      if (k === 'd' || e.key === 'ArrowRight') moveKeysRef.current.right = false;
    };

    const onResize = () => {
      if (!container) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      if (w > 0 && h > 0) {
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
        renderer.setSize(w, h);
      }
    };

    renderer.domElement.addEventListener('pointerdown', onPointerDown);
    window.addEventListener('pointerup', onPointerUp);
    window.addEventListener('pointermove', onPointerMove);
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('resize', onResize);

    // Paced Animation Loop
    const clock = new THREE.Clock();
    let frameId = 0;
    let disposed = false;
    let hudTimer = 0;

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync?.(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        if (disposed) return;
        const state = sync ? gl.getSyncParameter(sync, gl.SYNC_STATUS) : gl.SIGNALED;
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    const renderMinimap = () => {
      const canvas = minimapRef.current;
      const objs = sceneObjectsRef.current;
      if (!canvas || !objs) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const w = canvas.width;
      const h = canvas.height;
      ctx.clearRect(0, 0, w, h);

      const scale = zoneRef.current === 'overworld' ? w / (WORLD_HALF_SIZE * 2) : w / 92;
      const toMapX = (wx: number) => w / 2 + wx * scale;
      const toMapY = (wz: number) => h / 2 + wz * scale;

      ctx.strokeStyle = 'rgba(148, 163, 184, 0.18)';
      ctx.lineWidth = 1;
      ctx.strokeRect(1, 1, w - 2, h - 2);

      if (zoneRef.current === 'overworld') {
        objs.dungeonPortals.forEach((p) => {
          const mx = toMapX(p.x);
          const my = toMapY(p.z);
          ctx.fillStyle = '#c084fc';
          ctx.beginPath();
          ctx.moveTo(mx, my - 4);
          ctx.lineTo(mx + 4, my);
          ctx.lineTo(mx, my + 4);
          ctx.lineTo(mx - 4, my);
          ctx.closePath();
          ctx.fill();
        });

        const chap = STORY_CHAPTERS[chapterIdxRef.current];
        if (chap) {
          ctx.fillStyle = '#fde047';
          ctx.beginPath();
          ctx.arc(toMapX(chap.worldPos.x), toMapY(chap.worldPos.z), 4.5, 0, Math.PI * 2);
          ctx.fill();
        }
      } else if (objs.dungeonExitPortal) {
        ctx.fillStyle = '#38bdf8';
        ctx.fillRect(toMapX(objs.dungeonExitPortal.x) - 3.5, toMapY(objs.dungeonExitPortal.z) - 3.5, 7, 7);
      }

      objs.fieldMonsters.forEach((m) => {
        if (!m.active) return;
        ctx.fillStyle = '#fb7185';
        ctx.beginPath();
        ctx.arc(toMapX(m.mesh.position.x), toMapY(m.mesh.position.z), 2.3, 0, Math.PI * 2);
        ctx.fill();
      });

      ctx.fillStyle = '#fbbf24';
      ctx.beginPath();
      ctx.arc(toMapX(playerPosRef.current.x), toMapY(playerPosRef.current.z), 3.8, 0, Math.PI * 2);
      ctx.fill();
    };

    const tick = () => {
      if (disposed) return;
      const delta = Math.min(clock.getDelta(), 0.08);
      const elapsed = clock.getElapsedTime();
      const objs = sceneObjectsRef.current;

      if (isActiveRef.current && objs) {
        const keys = moveKeysRef.current;
        let forward = 0;
        let strafe = 0;
        if (keys.up) forward -= 1;
        if (keys.down) forward += 1;
        if (keys.left) strafe -= 1;
        if (keys.right) strafe += 1;

        if (forward !== 0 || strafe !== 0) {
          const speed = 21 * delta;
          const sin = Math.sin(cameraAngleRef.current);
          const cos = Math.cos(cameraAngleRef.current);
          const moveX = (strafe * cos + forward * sin) * speed;
          const moveZ = (forward * cos - strafe * sin) * speed;

          const limit = zoneRef.current === 'overworld' ? WORLD_HALF_SIZE - 4 : 41;
          playerPosRef.current.x = Math.max(-limit, Math.min(limit, playerPosRef.current.x + moveX));
          playerPosRef.current.z = Math.max(-limit, Math.min(limit, playerPosRef.current.z + moveZ));
          objs.playerGroup.rotation.y = Math.atan2(moveX, moveZ);
          objs.playerGroup.position.y = Math.abs(Math.sin(elapsed * 10)) * 0.14;
        } else {
          objs.playerGroup.position.y = THREE.MathUtils.damp(objs.playerGroup.position.y, 0, 10, delta);
        }

        objs.playerGroup.position.x = playerPosRef.current.x;
        objs.playerGroup.position.z = playerPosRef.current.z;

        objs.followerMeshes.forEach((fMesh, idx) => {
          const target = idx === 0 ? objs.playerGroup.position : objs.followerMeshes[idx - 1].position;
          const dist = fMesh.position.distanceTo(target);
          if (dist > 1.8) {
            _targetVec.set(target.x, 0, target.z);
            fMesh.position.lerp(_targetVec, 1 - Math.exp(-5.5 * delta));
            fMesh.lookAt(target.x, 0, target.z);
          }
        });

        // Smooth camera follow
        const camDist = 14.5;
        const camHeight = 9.5;
        const desiredCamX = playerPosRef.current.x + Math.sin(cameraAngleRef.current) * camDist;
        const desiredCamZ = playerPosRef.current.z + Math.cos(cameraAngleRef.current) * camDist;
        camera.position.x = THREE.MathUtils.damp(camera.position.x, desiredCamX, 10, delta);
        camera.position.z = THREE.MathUtils.damp(camera.position.z, desiredCamZ, 10, delta);
        camera.position.y = camHeight;
        camera.lookAt(playerPosRef.current.x, 1.2, playerPosRef.current.z);

        // Animate beacons & portals
        objs.storyBeacons.forEach((b) => {
          b.group.visible = b.chapterIdx === chapterIdxRef.current;
          b.ring.rotation.z = elapsed * 1.4;
        });
        objs.dungeonPortals.forEach((p) => {
          p.vortex.rotation.z = elapsed * 2.2;
        });
        if (objs.dungeonExitPortal) {
          objs.dungeonExitPortal.ring.rotation.z = -elapsed * 2.2;
        }

        // Monsters patrol & encounter detection
        objs.fieldMonsters.forEach((m) => {
          if (!m.active) return;
          m.mesh.position.x = m.baseX + Math.sin(elapsed * 1.2 + m.phase) * 2.4;
          m.mesh.position.z = m.baseZ + Math.cos(elapsed * 1.2 + m.phase) * 2.4;
          m.mesh.rotation.y = elapsed * 1.1;

          if (!encounterCooldownRef.current) {
            const d = Math.hypot(
              playerPosRef.current.x - m.mesh.position.x,
              playerPosRef.current.z - m.mesh.position.z,
            );
            if (d < 2.1) {
              m.active = false;
              m.mesh.visible = false;
              encounterCooldownRef.current = true;
              moveKeysRef.current = { up: false, down: false, left: false, right: false };
              callbacksRef.current.onEncounterMonster(m.enemyId);
            }
          }
        });

        // Overworld beacons & portals
        if (zoneRef.current === 'overworld' && !encounterCooldownRef.current) {
          const activeBeacon = objs.storyBeacons.find((b) => b.chapterIdx === chapterIdxRef.current);
          if (activeBeacon) {
            const bDist = Math.hypot(
              playerPosRef.current.x - activeBeacon.group.position.x,
              playerPosRef.current.z - activeBeacon.group.position.z,
            );
            if (bDist < 2.8) {
              encounterCooldownRef.current = true;
              moveKeysRef.current = { up: false, down: false, left: false, right: false };
              callbacksRef.current.onEnterStoryBeacon();
            }
          }

          for (const p of objs.dungeonPortals) {
            const pDist = Math.hypot(playerPosRef.current.x - p.x, playerPosRef.current.z - p.z);
            if (pDist < 2.8) {
              encounterCooldownRef.current = true;
              switchIntoDungeon(p.id);
              window.setTimeout(() => {
                encounterCooldownRef.current = false;
              }, 1100);
              break;
            }
          }
        } else if (zoneRef.current !== 'overworld' && objs.dungeonExitPortal && !encounterCooldownRef.current) {
          const eDist = Math.hypot(
            playerPosRef.current.x - objs.dungeonExitPortal.x,
            playerPosRef.current.z - objs.dungeonExitPortal.z,
          );
          if (eDist < 2.6) {
            encounterCooldownRef.current = true;
            switchToOverworld();
            window.setTimeout(() => {
              encounterCooldownRef.current = false;
            }, 1100);
          }
        }

        // Update HUD distance & compass bearing periodically
        hudTimer += delta;
        if (hudTimer > 0.16) {
          hudTimer = 0;
          const chap = STORY_CHAPTERS[chapterIdxRef.current];
          let targetX = 0;
          let targetZ = 0;
          let hasTarget = false;
          if (chap && zoneRef.current === 'overworld') {
            targetX = chap.worldPos.x;
            targetZ = chap.worldPos.z;
            hasTarget = true;
          } else if (objs.dungeonExitPortal) {
            targetX = objs.dungeonExitPortal.x;
            targetZ = objs.dungeonExitPortal.z;
            hasTarget = true;
          }
          if (hasTarget) {
            const dx = targetX - playerPosRef.current.x;
            const dz = targetZ - playerPosRef.current.z;
            setGoalDistance(Math.round(Math.hypot(dx, dz)));
            // Screen-relative angle: camera looks along (-sin(camAngle), -cos(camAngle))
            const worldAngle = Math.atan2(dx, -dz);
            const relDeg = ((worldAngle + cameraAngleRef.current) * 180) / Math.PI;
            setGoalBearingDeg(Math.round(relDeg));
          }
        }

        renderMinimap();
        renderer.render(scene, camera);
      }

      if (isSoftwareGl) {
        afterDraw(tick);
      } else {
        frameId = requestAnimationFrame(tick);
      }
    };

    tick();

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      window.clearTimeout(frameId);
      renderer.domElement.removeEventListener('pointerdown', onPointerDown);
      renderer.domElement.removeEventListener('webglcontextlost', handleContextLost);
      renderer.domElement.removeEventListener('webglcontextrestored', handleContextRestored);
      window.removeEventListener('pointerup', onPointerUp);
      window.removeEventListener('pointermove', onPointerMove);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('resize', onResize);

      envTex.dispose();
      texturesToDispose.forEach((t) => t.dispose());
      renderer.dispose();
    };
  }, []);

  // Resize renderer when switching back to world view
  useEffect(() => {
    if (!isActive || !mountRef.current || !sceneObjectsRef.current) return;
    const { renderer, camera } = sceneObjectsRef.current;
    const w = mountRef.current.clientWidth;
    const h = mountRef.current.clientHeight;
    if (w > 0 && h > 0) {
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    }
  }, [isActive]);

  const leader = party[0];
  const expPct = leader ? Math.min(100, Math.round((leader.exp / leader.nextExp) * 100)) : 0;
  const zoneLabel =
    zone === 'overworld'
      ? '에테르니아 대평원'
      : zone === 'crypt'
        ? '고대 마력 지하묘지'
        : '화염의 심연 동굴';

  const setMoveInput = (dir: 'up' | 'down' | 'left' | 'right', pressed: boolean) => {
    moveKeysRef.current[dir] = pressed;
  };

  return (
    <section
      className={`relative flex-1 w-full min-h-[calc(100dvh-4rem)] overflow-hidden bg-[#090b12] ${
        isActive ? 'flex flex-col' : 'hidden'
      }`}
    >
      {/* Dedicated WebGL Mount Container */}
      <div ref={mountRef} className="absolute inset-0 w-full h-full z-0" />

      {/* Graceful WebGL Fallback */}
      {webglError && (
        <div className="absolute inset-0 z-10 flex flex-col items-center justify-center p-6 text-center bg-[#090b12]">
          <div className="max-w-md rounded-2xl overflow-hidden border border-amber-500/40 bg-[#0b0f1c] p-5">
            <GameImage
              src={SCENE_BACKDROPS.arcadia}
              alt="에테르니아 대평원"
              className="w-full h-44 object-cover rounded-xl mb-4"
            />
            <h3 className="text-lg font-bold text-amber-200 mb-2">3D 가속 초기화 대기</h3>
            <p className="text-xs text-slate-300 mb-4">
              현재 브라우저 환경에서 WebGL 컨텍스트가 중단되었습니다. 아래 버튼으로 현재 챕터 전투에 바로 진입할 수 있습니다.
            </p>
            <button
              type="button"
              onClick={onEnterStoryBeacon}
              className="h-10 px-5 rounded-lg bg-amber-500 text-slate-950 font-bold text-sm cursor-pointer"
            >
              현재 챕터 진행하기
            </button>
          </div>
        </div>
      )}

      {/* Top HUD Layer (No backdrop-filter over WebGL) */}
      <div className="relative z-10 p-3 sm:p-4 flex items-start justify-between gap-2 pointer-events-none">
        {/* Top-Left: Expedition Party Status */}
        <div className="bg-[#0b0f1c]/92 border border-amber-500/35 rounded-xl p-2.5 sm:p-3 pointer-events-auto max-w-[180px] sm:max-w-[260px] w-full">
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs font-bold text-amber-200">원정대</span>
            <span className="text-xs font-bold text-amber-300 tabular-nums">
              Lv.{leader?.lv ?? 1}
            </span>
          </div>

          <div className="mb-2 tabular-nums">
            <div className="flex justify-between text-[11px] text-slate-300 mb-0.5">
              <span>EXP</span>
              <span>
                {leader?.exp ?? 0}/{leader?.nextExp ?? 100}
              </span>
            </div>
            <div className="w-full h-1.5 rounded-full bg-slate-900 border border-slate-700 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-amber-500 to-yellow-300 transition-all duration-300"
                style={{ width: `${expPct}%` }}
              />
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {party.map((member) => (
              <div
                key={member.id}
                title={`${member.name} (HP ${member.hp}/${member.maxHp})`}
                className="w-8 h-8 sm:w-9 sm:h-9 rounded-lg overflow-hidden border border-amber-500/40 bg-slate-900 shrink-0"
              >
                <GameImage
                  src={CHARACTER_PORTRAITS[member.id]}
                  alt={member.shortName}
                  className="w-full h-full object-cover object-top"
                />
              </div>
            ))}
          </div>
        </div>

        {/* Top-Right: Minimap & Quest Dock (Collapsible on small screens) */}
        <div className="flex flex-col items-end gap-2 pointer-events-auto ml-auto">
          <div className="flex items-center gap-1.5">
            {hudCompact && (
              <div className="bg-[#0b0f1c]/92 border border-amber-500/35 rounded-lg h-9 px-2.5 inline-flex items-center gap-2 text-xs text-amber-200 tabular-nums">
                <ArrowUp
                  className="w-3.5 h-3.5 text-amber-300 transition-transform duration-150"
                  style={{ transform: `rotate(${goalBearingDeg}deg)` }}
                />
                <span>{zone === 'overworld' ? `목표 ${goalDistance}m` : `출구 ${goalDistance}m`}</span>
              </div>
            )}
            {hudCompact && (
              <button
                type="button"
                onClick={onCamp}
                aria-label="야영 회복"
                className="h-9 px-2.5 rounded-lg bg-[#0b0f1c]/92 border border-emerald-500/40 text-xs font-semibold text-emerald-200 inline-flex items-center gap-1 cursor-pointer"
              >
                <Tent className="w-3.5 h-3.5 text-emerald-400" />
                <span>야영</span>
              </button>
            )}
            <button
              type="button"
              onClick={() => setHudCompact((prev) => !prev)}
              aria-label={hudCompact ? '지도 및 목표 펼치기' : '지도 및 목표 접기'}
              className="h-9 px-2.5 sm:px-3 rounded-lg bg-[#0b0f1c]/92 border border-amber-500/35 text-xs font-medium text-amber-200 inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
            >
              {hudCompact ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
              <span className="hidden sm:inline">{hudCompact ? 'HUD 펼치기' : 'HUD 접기'}</span>
            </button>
          </div>

          {!hudCompact && (
            <div className="flex flex-col sm:flex-row items-end sm:items-start gap-2">
              <div className="bg-[#0b0f1c]/92 border border-amber-500/35 rounded-xl p-2.5 flex flex-col items-center">
                <div className="w-full flex items-center justify-between gap-2 mb-1.5">
                  <span className="text-[11px] font-bold text-amber-200 inline-flex items-center gap-1">
                    <MapIcon className="w-3.5 h-3.5 text-amber-300" />
                    레이더
                  </span>
                  <span className="text-[11px] text-slate-300 truncate max-w-[95px]">{zoneLabel}</span>
                </div>
                <canvas
                  ref={minimapRef}
                  width={108}
                  height={108}
                  className="rounded-lg border border-amber-500/30 bg-[#060912]"
                />
                <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-1.5">
                  <span><span className="text-amber-400">●</span> 아군</span>
                  <span><span className="text-yellow-300">●</span> 목표</span>
                  <span><span className="text-purple-400">◆</span> 던전</span>
                  <span><span className="text-rose-400">●</span> 마물</span>
                </div>
              </div>

              <div className="bg-[#0b0f1c]/92 border border-amber-500/35 rounded-xl p-3 max-w-[260px]">
                <div className="flex items-center justify-between gap-2 mb-1">
                  <span className="text-xs font-bold text-amber-300 inline-flex items-center gap-1">
                    <Compass className="w-3.5 h-3.5" />
                    현재 목표
                  </span>
                  <span className="text-[11px] text-slate-200 tabular-nums inline-flex items-center gap-1">
                    <ArrowUp
                      className="w-3.5 h-3.5 text-amber-300 transition-transform duration-150"
                      style={{ transform: `rotate(${goalBearingDeg}deg)` }}
                    />
                    {zone === 'overworld' ? `${goalDistance}m` : `출구 ${goalDistance}m`}
                  </span>
                </div>
                <p className="text-xs text-slate-200 leading-relaxed">{currentChapter.questHint}</p>

                <div className="mt-2.5 flex flex-wrap gap-1.5">
                  <button
                    type="button"
                    onClick={onCamp}
                    className="h-9 px-3 rounded-lg bg-slate-900 hover:bg-slate-800 border border-emerald-500/40 text-xs font-semibold text-emerald-200 inline-flex items-center gap-1.5 cursor-pointer"
                  >
                    <Tent className="w-3.5 h-3.5 text-emerald-400" />
                    <span>야영 회복</span>
                  </button>
                  {zone !== 'overworld' && (
                    <button
                      type="button"
                      onClick={() => switchToOverworld()}
                      className="h-9 px-3 rounded-lg bg-slate-900 hover:bg-slate-800 border border-purple-500/50 text-xs font-semibold text-purple-200 inline-flex items-center gap-1.5 cursor-pointer"
                    >
                      <DoorOpen className="w-3.5 h-3.5 text-purple-300" />
                      <span>평야 귀환</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Bottom Controls Hint (Desktop) & Touch D-Pad (Mobile/Tablet) */}
      <div className="relative z-10 mt-auto p-3 sm:p-4 flex items-end justify-between pointer-events-none">
        <div className="hidden md:block bg-[#0b0f1c]/90 border border-slate-700/80 rounded-xl px-4 py-2 text-xs text-slate-300 pointer-events-auto">
          <span className="font-semibold text-amber-200">WASD / 방향키</span> 이동
          <span aria-hidden="true" className="mx-2 text-slate-600">·</span>
          <span className="font-semibold text-amber-200">마우스 드래그</span> 시점 회전
          <span aria-hidden="true" className="mx-2 text-slate-600">·</span>
          <span>황금 빛기둥(스토리) / 던전 포탈 / 붉은 마물</span>
        </div>

        {/* Touch D-Pad for Mobile & Touchscreens */}
        <div className="grid grid-cols-3 gap-1.5 pointer-events-auto md:hidden mx-auto">
          <div />
          <button
            type="button"
            aria-label="앞으로 이동"
            onPointerDown={() => setMoveInput('up', true)}
            onPointerUp={() => setMoveInput('up', false)}
            onPointerLeave={() => setMoveInput('up', false)}
            onPointerCancel={() => setMoveInput('up', false)}
            className="w-12 h-12 rounded-xl bg-[#0b0f1c]/92 border border-amber-500/40 text-amber-200 flex items-center justify-center active:bg-amber-500/20"
          >
            <ArrowUp className="w-5 h-5" />
          </button>
          <div />
          <button
            type="button"
            aria-label="왼쪽 이동"
            onPointerDown={() => setMoveInput('left', true)}
            onPointerUp={() => setMoveInput('left', false)}
            onPointerLeave={() => setMoveInput('left', false)}
            onPointerCancel={() => setMoveInput('left', false)}
            className="w-12 h-12 rounded-xl bg-[#0b0f1c]/92 border border-amber-500/40 text-amber-200 flex items-center justify-center active:bg-amber-500/20"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <button
            type="button"
            aria-label="뒤로 이동"
            onPointerDown={() => setMoveInput('down', true)}
            onPointerUp={() => setMoveInput('down', false)}
            onPointerLeave={() => setMoveInput('down', false)}
            onPointerCancel={() => setMoveInput('down', false)}
            className="w-12 h-12 rounded-xl bg-[#0b0f1c]/92 border border-amber-500/40 text-amber-200 flex items-center justify-center active:bg-amber-500/20"
          >
            <ArrowDown className="w-5 h-5" />
          </button>
          <button
            type="button"
            aria-label="오른쪽 이동"
            onPointerDown={() => setMoveInput('right', true)}
            onPointerUp={() => setMoveInput('right', false)}
            onPointerLeave={() => setMoveInput('right', false)}
            onPointerCancel={() => setMoveInput('right', false)}
            className="w-12 h-12 rounded-xl bg-[#0b0f1c]/92 border border-amber-500/40 text-amber-200 flex items-center justify-center active:bg-amber-500/20"
          >
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* World Notification Toast */}
      {toast && (
        <div
          role="status"
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-30 bg-[#0b0f1c]/95 border-2 border-amber-400 rounded-2xl px-6 py-4 text-center shadow-2xl max-w-sm w-[90%] pointer-events-none"
        >
          <div className="text-lg font-bold text-amber-200 mb-1">{toast.title}</div>
          <p className="text-xs sm:text-sm text-slate-200">{toast.desc}</p>
        </div>
      )}
    </section>
  );
}
