export type ElementType = 'SWORD' | 'FIRE' | 'LIGHT' | 'HOLY';

export type SkillType =
  | 'damage'
  | 'damage_and_heal'
  | 'debuff_def'
  | 'heal_single'
  | 'heal_all'
  | 'shield_party'
  | 'buff'
  | 'self_buff'
  | 'restore_mp';

export type CharacterId = 'hero' | 'kyle' | 'elena' | 'seraphim';

export type ZoneId = 'overworld' | 'crypt' | 'volcano';

export type GameScreen = 'title' | 'world' | 'story' | 'battle';

export interface Skill {
  name: string;
  mp: number;
  type: SkillType;
  element?: ElementType;
  power: number;
  desc: string;
}

export interface CharacterGrowth {
  hp: number;
  mp: number;
  atk: number;
  spd: number;
}

export interface PartyMember {
  id: CharacterId;
  name: string;
  shortName: string;
  role: string;
  accentColor: string;
  meshColor: number;
  lv: number;
  exp: number;
  nextExp: number;
  maxHp: number;
  hp: number;
  maxMp: number;
  mp: number;
  atk: number;
  spd: number;
  growth: CharacterGrowth;
  buffAtk: number;
  skills: Skill[];
}

export type EnemyShape =
  | 'slime'
  | 'goblin'
  | 'wolf'
  | 'salamander'
  | 'skeleton'
  | 'knight'
  | 'gargoyle'
  | 'wyvern';

export interface EnemyData {
  id: string;
  name: string;
  maxHp: number;
  hp: number;
  atk: number;
  spd: number;
  maxShield: number;
  shield: number;
  weaknesses: ElementType[];
  expReward: number;
  isBoss: boolean;
  shape: EnemyShape;
}

export interface DialogueLine {
  speaker: string;
  speakerId?: CharacterId | 'malakar' | 'narrator';
  role: string;
  text: string;
}

export interface StoryChapter {
  id: number;
  badge: string;
  location: string;
  desc: string;
  backdropKey: 'arcadia' | 'library' | 'solaris' | 'abyss';
  worldPos: { x: number; z: number };
  questHint: string;
  dialogues: DialogueLine[];
  recruitAfterDialogue: CharacterId | null;
  enemyId: string;
}

export interface TurnUnit {
  type: 'ally' | 'enemy';
  id: string;
  name: string;
  spd: number;
  portraitSrc: string;
}

export interface BattleLogEntry {
  id: number;
  text: string;
  tone: 'neutral' | 'damage' | 'weak' | 'break' | 'heal' | 'buff' | 'enemy';
}
