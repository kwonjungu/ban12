import * as THREE from 'three';
import type { CharacterId, EnemyShape } from '../types/game';

const SHADOW_DISC_GEO = new THREE.CircleGeometry(0.95, 20);
const SHADOW_DISC_MAT = new THREE.MeshBasicMaterial({
  color: 0x000000,
  transparent: true,
  opacity: 0.42,
  depthWrite: false,
});

export function createGroundTexture(
  variant: 'overworld' | 'crypt' | 'volcano',
  maxAnisotropy: number,
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  if (variant === 'overworld') {
    ctx.fillStyle = '#193524';
    ctx.fillRect(0, 0, 512, 512);
    for (let i = 0; i < 1600; i++) {
      const x = Math.random() * 512;
      const y = Math.random() * 512;
      const r = 1 + Math.random() * 3.5;
      ctx.fillStyle = i % 3 === 0 ? 'rgba(45, 106, 79, 0.35)' : 'rgba(17, 38, 25, 0.4)';
      ctx.beginPath();
      ctx.arc(x, y, r, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.strokeStyle = 'rgba(116, 198, 157, 0.08)';
    ctx.lineWidth = 1;
    for (let g = 0; g <= 512; g += 64) {
      ctx.beginPath();
      ctx.moveTo(g, 0);
      ctx.lineTo(g, 512);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(0, g);
      ctx.lineTo(512, g);
      ctx.stroke();
    }
  } else if (variant === 'crypt') {
    ctx.fillStyle = '#1b1838';
    ctx.fillRect(0, 0, 512, 512);
    ctx.strokeStyle = '#312e81';
    ctx.lineWidth = 3;
    for (let x = 0; x < 512; x += 64) {
      for (let y = 0; y < 512; y += 64) {
        ctx.fillStyle = (x + y) % 128 === 0 ? '#211d45' : '#181533';
        ctx.fillRect(x + 2, y + 2, 60, 60);
        ctx.strokeRect(x, y, 64, 64);
      }
    }
  } else {
    ctx.fillStyle = '#24120d';
    ctx.fillRect(0, 0, 512, 512);
    for (let i = 0; i < 40; i++) {
      ctx.strokeStyle = i % 2 === 0 ? 'rgba(249, 115, 22, 0.38)' : 'rgba(234, 88, 12, 0.22)';
      ctx.lineWidth = 2 + Math.random() * 2;
      ctx.beginPath();
      const sx = Math.random() * 512;
      const sy = Math.random() * 512;
      ctx.moveTo(sx, sy);
      ctx.lineTo(sx + (Math.random() - 0.5) * 90, sy + (Math.random() - 0.5) * 90);
      ctx.stroke();
    }
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(variant === 'overworld' ? 28 : 12, variant === 'overworld' ? 28 : 12);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = maxAnisotropy;
  return texture;
}

export function createCharacterModel(charId: CharacterId, accentHex: number): THREE.Group {
  const group = new THREE.Group();

  // Contact Shadow Grounding
  const shadow = new THREE.Mesh(SHADOW_DISC_GEO, SHADOW_DISC_MAT);
  shadow.rotation.x = -Math.PI / 2;
  shadow.position.y = 0.03;
  group.add(shadow);

  const armorMat = new THREE.MeshStandardMaterial({
    color: accentHex,
    roughness: 0.35,
    metalness: 0.55,
  });
  const darkMetalMat = new THREE.MeshStandardMaterial({
    color: 0x334155,
    roughness: 0.65,
    metalness: 0.4,
  });
  const skinMat = new THREE.MeshStandardMaterial({
    color: 0xfde6c4,
    roughness: 0.6,
    metalness: 0.05,
  });
  const capeMat = new THREE.MeshStandardMaterial({
    color: charId === 'kyle' ? 0x1d4ed8 : charId === 'elena' ? 0x5b21b6 : charId === 'seraphim' ? 0x047857 : 0x92400e,
    roughness: 0.85,
    metalness: 0.05,
  });

  // Boots / Legs
  const leftLeg = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.16, 0.62, 10), darkMetalMat);
  leftLeg.position.set(-0.2, 0.31, 0);
  leftLeg.castShadow = true;
  const rightLeg = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.16, 0.62, 10), darkMetalMat);
  rightLeg.position.set(0.2, 0.31, 0);
  rightLeg.castShadow = true;
  group.add(leftLeg, rightLeg);

  // Torso Breastplate
  const torso = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.34, 0.88, 12), armorMat);
  torso.position.y = 1.02;
  torso.castShadow = true;
  group.add(torso);

  // Pauldrons (Shoulders)
  const leftPauldron = new THREE.Mesh(new THREE.SphereGeometry(0.22, 10, 10), armorMat);
  leftPauldron.position.set(-0.48, 1.32, 0);
  const rightPauldron = new THREE.Mesh(new THREE.SphereGeometry(0.22, 10, 10), armorMat);
  rightPauldron.position.set(0.48, 1.32, 0);
  group.add(leftPauldron, rightPauldron);

  // Flowing Cape
  const cape = new THREE.Mesh(new THREE.BoxGeometry(0.74, 0.98, 0.1), capeMat);
  cape.position.set(0, 0.94, -0.34);
  cape.rotation.x = 0.18;
  group.add(cape);

  // Head & Hair/Crest
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.32, 16, 16), skinMat);
  head.position.y = 1.74;
  head.castShadow = true;
  group.add(head);

  const hairMat = new THREE.MeshStandardMaterial({
    color: charId === 'hero' ? 0xfbbf24 : charId === 'kyle' ? 0x1e293b : charId === 'elena' ? 0xc4b5fd : 0xb45309,
    roughness: 0.7,
  });
  const crown = new THREE.Mesh(new THREE.SphereGeometry(0.34, 14, 10, 0, Math.PI * 2, 0, Math.PI * 0.58), hairMat);
  crown.position.y = 1.78;
  group.add(crown);

  // Distinct Weapon
  if (charId === 'hero' || charId === 'kyle') {
    const bladeMat = new THREE.MeshStandardMaterial({
      color: charId === 'hero' ? 0xfef08a : 0xe2e8f0,
      emissive: charId === 'hero' ? 0xf59e0b : 0x000000,
      emissiveIntensity: charId === 'hero' ? 0.55 : 0,
      metalness: 0.9,
      roughness: 0.2,
    });
    const blade = new THREE.Mesh(new THREE.BoxGeometry(0.11, 1.38, 0.05), bladeMat);
    blade.position.set(0.64, 1.25, 0.28);
    blade.rotation.z = -0.35;
    blade.rotation.x = 0.25;
    const guard = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.08, 0.1), darkMetalMat);
    guard.position.set(0.5, 0.72, 0.16);
    guard.rotation.z = -0.35;
    group.add(blade, guard);
  } else if (charId === 'elena') {
    const staffShaft = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.06, 1.8, 8), darkMetalMat);
    staffShaft.position.set(0.6, 1.05, 0.2);
    const orb = new THREE.Mesh(
      new THREE.OctahedronGeometry(0.2, 0),
      new THREE.MeshStandardMaterial({ color: 0xf97316, emissive: 0xea580c, emissiveIntensity: 0.7, roughness: 0.2 }),
    );
    orb.position.set(0.6, 2.02, 0.2);
    group.add(staffShaft, orb);
  } else {
    const maceShaft = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 1.4, 8), darkMetalMat);
    maceShaft.position.set(0.58, 1.05, 0.2);
    const maceHead = new THREE.Mesh(
      new THREE.DodecahedronGeometry(0.22, 0),
      new THREE.MeshStandardMaterial({ color: 0xfde047, emissive: 0x10b981, emissiveIntensity: 0.45, metalness: 0.8, roughness: 0.2 }),
    );
    maceHead.position.set(0.58, 1.82, 0.2);
    group.add(maceShaft, maceHead);
  }

  return group;
}

export function createMonsterModel(shape: EnemyShape, colorHex: number, scale = 1.0): THREE.Group {
  const group = new THREE.Group();

  const shadow = new THREE.Mesh(SHADOW_DISC_GEO, SHADOW_DISC_MAT);
  shadow.rotation.x = -Math.PI / 2;
  shadow.position.y = 0.03;
  group.add(shadow);

  const primaryMat = new THREE.MeshStandardMaterial({
    color: colorHex,
    emissive: colorHex,
    emissiveIntensity: 0.18,
    roughness: 0.45,
    metalness: 0.35,
  });
  const accentMat = new THREE.MeshStandardMaterial({
    color: 0x1e293b,
    roughness: 0.7,
    metalness: 0.5,
  });
  const eyeMat = new THREE.MeshBasicMaterial({ color: 0xf43f5e });

  if (shape === 'slime') {
    const gel = new THREE.Mesh(
      new THREE.SphereGeometry(0.85, 18, 14),
      new THREE.MeshStandardMaterial({
        color: colorHex,
        emissive: colorHex,
        emissiveIntensity: 0.25,
        roughness: 0.15,
        transparent: true,
        opacity: 0.85,
      }),
    );
    gel.scale.set(1.1, 0.85, 1.1);
    gel.position.y = 0.72;
    const core = new THREE.Mesh(new THREE.OctahedronGeometry(0.36, 0), eyeMat);
    core.position.y = 0.75;
    const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.1, 8, 8), eyeMat);
    eyeL.position.set(-0.24, 0.9, 0.72);
    const eyeR = eyeL.clone();
    eyeR.position.x = 0.24;
    group.add(gel, core, eyeL, eyeR);
  } else if (shape === 'wyvern' || shape === 'gargoyle') {
    const body = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.56, 1.3, 10), primaryMat);
    body.position.y = 1.25;
    const head = new THREE.Mesh(new THREE.ConeGeometry(0.38, 0.8, 6), primaryMat);
    head.rotation.x = Math.PI / 2;
    head.position.set(0, 1.95, 0.5);
    const wingGeo = new THREE.BoxGeometry(1.5, 0.08, 0.7);
    const leftWing = new THREE.Mesh(wingGeo, accentMat);
    leftWing.position.set(-1.0, 1.55, -0.15);
    leftWing.rotation.z = 0.35;
    const rightWing = new THREE.Mesh(wingGeo, accentMat);
    rightWing.position.set(1.0, 1.55, -0.15);
    rightWing.rotation.z = -0.35;
    const crest = new THREE.Mesh(new THREE.ConeGeometry(0.18, 0.55, 5), eyeMat);
    crest.position.set(0, 2.25, 0.2);
    group.add(body, head, leftWing, rightWing, crest);
  } else if (shape === 'wolf' || shape === 'salamander') {
    const torso = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.65, 1.45), primaryMat);
    torso.position.y = 0.85;
    const head = new THREE.Mesh(new THREE.ConeGeometry(0.38, 0.75, 6), primaryMat);
    head.rotation.x = Math.PI / 2;
    head.position.set(0, 1.05, 0.92);
    const spike1 = new THREE.Mesh(new THREE.ConeGeometry(0.14, 0.45, 5), accentMat);
    spike1.position.set(0, 1.35, 0.1);
    const spike2 = spike1.clone();
    spike2.position.z = -0.35;
    const tail = new THREE.Mesh(new THREE.ConeGeometry(0.15, 0.8, 6), primaryMat);
    tail.rotation.x = -Math.PI / 2.6;
    tail.position.set(0, 0.95, -0.95);
    group.add(torso, head, spike1, spike2, tail);
  } else {
    // knight / skeleton / goblin composite warrior
    const torso = new THREE.Mesh(new THREE.BoxGeometry(0.95, 1.05, 0.65), primaryMat);
    torso.position.y = 1.1;
    const head = new THREE.Mesh(new THREE.DodecahedronGeometry(0.36, 0), accentMat);
    head.position.y = 1.92;
    const shoulderL = new THREE.Mesh(new THREE.ConeGeometry(0.28, 0.48, 6), accentMat);
    shoulderL.position.set(-0.62, 1.55, 0);
    const shoulderR = shoulderL.clone();
    shoulderR.position.x = 0.62;
    const weapon = new THREE.Mesh(new THREE.BoxGeometry(0.14, 1.45, 0.08), eyeMat);
    weapon.position.set(0.75, 1.25, 0.25);
    weapon.rotation.z = -0.25;
    const eyeVisor = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.08, 0.12), eyeMat);
    eyeVisor.position.set(0, 1.92, 0.31);
    group.add(torso, head, shoulderL, shoulderR, weapon, eyeVisor);
  }

  group.scale.setScalar(scale);
  return group;
}

export function createPineTreeModel(): THREE.Group {
  const group = new THREE.Group();
  const trunkMat = new THREE.MeshStandardMaterial({ color: 0x451a03, roughness: 0.9 });
  const leafMat1 = new THREE.MeshStandardMaterial({ color: 0x064e3b, roughness: 0.85 });
  const leafMat2 = new THREE.MeshStandardMaterial({ color: 0x065f46, roughness: 0.8 });

  const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.26, 0.42, 2.0, 8), trunkMat);
  trunk.position.y = 1.0;
  trunk.castShadow = true;

  const tier1 = new THREE.Mesh(new THREE.ConeGeometry(1.9, 2.8, 8), leafMat1);
  tier1.position.y = 2.8;
  tier1.castShadow = true;

  const tier2 = new THREE.Mesh(new THREE.ConeGeometry(1.4, 2.4, 8), leafMat2);
  tier2.position.y = 4.3;
  tier2.castShadow = true;

  const tier3 = new THREE.Mesh(new THREE.ConeGeometry(0.85, 1.8, 8), leafMat2);
  tier3.position.y = 5.5;

  group.add(trunk, tier1, tier2, tier3);
  return group;
}

export function createAncientRuinModel(height: number): THREE.Group {
  const group = new THREE.Group();
  const stoneMat = new THREE.MeshStandardMaterial({ color: 0x475569, roughness: 0.85, metalness: 0.1 });
  const runeMat = new THREE.MeshStandardMaterial({
    color: 0x38bdf8,
    emissive: 0x0284c7,
    emissiveIntensity: 0.45,
    roughness: 0.3,
  });

  const plinth = new THREE.Mesh(new THREE.BoxGeometry(2.1, 0.6, 2.1), stoneMat);
  plinth.position.y = 0.3;
  const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.62, 0.78, height, 8), stoneMat);
  shaft.position.y = 0.6 + height / 2;
  shaft.castShadow = true;
  const cap = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.4, 1.6), stoneMat);
  cap.position.y = 0.6 + height + 0.15;
  const runeRing = new THREE.Mesh(new THREE.TorusGeometry(0.72, 0.06, 8, 24), runeMat);
  runeRing.rotation.x = Math.PI / 2;
  runeRing.position.y = 0.6 + height * 0.75;

  group.add(plinth, shaft, cap, runeRing);
  return group;
}
