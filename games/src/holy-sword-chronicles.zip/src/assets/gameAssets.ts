import titleKeyArt from './images/title_key_art_1794636250989.jpg';

import charHeroArs from './images/char_hero_ars_1794636251863.jpg';
import charKyle from './images/char_kyle_1794636252184.jpg';
import charElena from './images/char_elena_1794636253259.jpg';
import charSeraphim from './images/char_seraphim_1794636252565.jpg';

import bgArcadiaPlains from './images/bg_arcadia_plains_1794636254188.jpg';
import bgAncientLibrary from './images/bg_ancient_library_1794636254173.jpg';
import bgSolarisHarbor from './images/bg_solaris_harbor_1794636254658.jpg';
import bgAbyssCitadel from './images/bg_abyss_citadel_1794636254915.jpg';
import bgDungeonCrypt from './images/bg_dungeon_crypt_1794636255615.jpg';
import bgDungeonVolcano from './images/bg_dungeon_volcano_1794636256903.jpg';

import enemyShadowSlime from './images/enemy_shadow_slime_1794636255407.jpg';
import enemyGoblinRaider from './images/enemy_goblin_raider_1794636256456.jpg';
import enemyDireWolf from './images/enemy_dire_wolf_1794636256029.jpg';
import enemyLavaSalamander from './images/enemy_lava_salamander_1794636256858.jpg';
import enemySkeletonWarrior from './images/enemy_skeleton_warrior_1794636257309.jpg';
import enemyCursedKnight from './images/enemy_cursed_knight_1794636258191.jpg';
import enemyStoneGargoyle from './images/enemy_stone_gargoyle_1794636258856.jpg';
import enemyStormWyvern from './images/enemy_storm_wyvern_1794636259899.jpg';
import enemyCryptBanshee from './images/enemy_crypt_banshee_1794636259277.jpg';
import enemySkeletonArchmage from './images/enemy_skeleton_archmage_1794636259933.jpg';
import enemyHellCerberus from './images/enemy_hell_cerberus_1794636260506.jpg';
import enemyObsidianDrake from './images/enemy_obsidian_drake_1794636261730.jpg';
import enemyLichKing from './images/enemy_lich_king_1794636261404.jpg';
import enemyIfrit from './images/enemy_ifrit_1794636262018.jpg';
import enemyFallenCommander from './images/enemy_fallen_commander_1794636263628.jpg';
import enemyGuardianGolem from './images/enemy_guardian_golem_1794636263879.jpg';
import enemyPlagueWraith from './images/enemy_plague_wraith_1794636264230.jpg';
import enemyMalakar from './images/enemy_malakar_1794636264652.jpg';

import type { CharacterId } from '../types/game';

export const TITLE_KEY_ART = titleKeyArt;

export const CHARACTER_PORTRAITS: Record<CharacterId, string> = {
  hero: charHeroArs,
  kyle: charKyle,
  elena: charElena,
  seraphim: charSeraphim,
};

export const SCENE_BACKDROPS = {
  arcadia: bgArcadiaPlains,
  library: bgAncientLibrary,
  solaris: bgSolarisHarbor,
  abyss: bgAbyssCitadel,
  crypt: bgDungeonCrypt,
  volcano: bgDungeonVolcano,
} as const;

export const ENEMY_ART: Record<string, string> = {
  field_slime: enemyShadowSlime,
  field_goblin: enemyGoblinRaider,
  field_wolf: enemyDireWolf,
  field_salamander: enemyLavaSalamander,
  field_skeleton: enemySkeletonWarrior,
  field_knight: enemyCursedKnight,
  field_gargoyle: enemyStoneGargoyle,
  field_wyvern: enemyStormWyvern,
  dungeon_banshee: enemyCryptBanshee,
  dungeon_archmage: enemySkeletonArchmage,
  dungeon_cerberus: enemyHellCerberus,
  dungeon_drake: enemyObsidianDrake,
  dungeon_lich: enemyLichKing,
  dungeon_ifrit: enemyIfrit,
  goblin_scout: enemyFallenCommander,
  golem: enemyGuardianGolem,
  plague_wraith: enemyPlagueWraith,
  malakar: enemyMalakar,
};
