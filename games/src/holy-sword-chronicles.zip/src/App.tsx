import { useCallback, useEffect, useRef, useState } from 'react';
import type {
  BattleLogEntry,
  EnemyData,
  GameScreen,
  PartyMember,
  TurnUnit,
  ZoneId,
} from './types/game';
import { CHARACTER_ROSTER, ENEMIES, STORY_CHAPTERS } from './data/gameData';
import { CHARACTER_PORTRAITS, ENEMY_ART } from './assets/gameAssets';
import { soundEngine } from './utils/audio';
import { GameHeader } from './components/GameHeader';
import { TitleScreen } from './components/TitleScreen';
import { WorldExplorer } from './components/WorldExplorer';
import { StoryScreen } from './components/StoryScreen';
import { BattleScreen } from './components/BattleScreen';
import { PartyModal } from './components/PartyModal';
import { EndingModal } from './components/EndingModal';

function cloneHero(id: keyof typeof CHARACTER_ROSTER): PartyMember {
  return JSON.parse(JSON.stringify(CHARACTER_ROSTER[id])) as PartyMember;
}

function cloneEnemy(id: string): EnemyData {
  const source = ENEMIES[id] ?? ENEMIES.field_slime;
  return JSON.parse(JSON.stringify(source)) as EnemyData;
}

export default function App() {
  const [screen, setScreen] = useState<GameScreen>('title');
  const [audioEnabled, setAudioEnabled] = useState(true);
  const [showRosterModal, setShowRosterModal] = useState(false);

  const [party, setParty] = useState<PartyMember[]>(() => [cloneHero('hero')]);
  const [chapterIdx, setChapterIdx] = useState(0);
  const [dialogueIdx, setDialogueIdx] = useState(0);
  const [zone, setZone] = useState<ZoneId>('overworld');

  const [campTrigger, setCampTrigger] = useState(0);
  const [resetTrigger, setResetTrigger] = useState(0);
  const [worldToast, setWorldToast] = useState<{ title: string; desc: string } | null>(null);
  const toastTimerRef = useRef<number | null>(null);

  // Battle State
  const [enemy, setEnemy] = useState<EnemyData>(() => cloneEnemy('field_slime'));
  const [turnQueue, setTurnQueue] = useState<TurnUnit[]>([]);
  const [isEnemyBroken, setIsEnemyBroken] = useState(false);
  const [logs, setLogs] = useState<BattleLogEntry[]>([]);
  const [enemyShakeKey, setEnemyShakeKey] = useState(0);
  const [healFlashKey, setHealFlashKey] = useState(0);
  const [floatingDamage, setFloatingDamage] = useState<{
    id: number;
    text: string;
    tone: 'normal' | 'weak' | 'break';
  } | null>(null);

  const [endingOutcome, setEndingOutcome] = useState<'victory' | 'defeat' | null>(null);

  // Refs for async enemy turn timeouts
  const partyRef = useRef(party);
  partyRef.current = party;
  const enemyRef = useRef(enemy);
  enemyRef.current = enemy;
  const brokenRef = useRef(isEnemyBroken);
  brokenRef.current = isEnemyBroken;
  const chapterIdxRef = useRef(chapterIdx);
  chapterIdxRef.current = chapterIdx;
  const screenRef = useRef(screen);
  screenRef.current = screen;
  const enemyTurnTimeoutRef = useRef<number | null>(null);
  const logIdRef = useRef(1);

  const showToast = useCallback((title: string, desc: string) => {
    if (toastTimerRef.current) window.clearTimeout(toastTimerRef.current);
    setWorldToast({ title, desc });
    toastTimerRef.current = window.setTimeout(() => {
      setWorldToast(null);
    }, 2600);
  }, []);

  useEffect(() => {
    return () => {
      if (toastTimerRef.current) window.clearTimeout(toastTimerRef.current);
      if (enemyTurnTimeoutRef.current) window.clearTimeout(enemyTurnTimeoutRef.current);
    };
  }, []);

  const appendLog = useCallback((text: string, tone: BattleLogEntry['tone'] = 'neutral') => {
    const id = logIdRef.current++;
    setLogs((prev) => [...prev.slice(-24), { id, text, tone }]);
  }, []);

  const buildQueue = useCallback((currentParty: PartyMember[], currentEnemy: EnemyData): TurnUnit[] => {
    const units: TurnUnit[] = [
      ...currentParty
        .filter((p) => p.hp > 0)
        .map((p) => ({
          type: 'ally' as const,
          id: p.id,
          name: p.shortName,
          spd: p.spd,
          portraitSrc: CHARACTER_PORTRAITS[p.id],
        })),
      {
        type: 'enemy' as const,
        id: 'enemy',
        name: currentEnemy.name.split(' ')[0],
        spd: currentEnemy.spd,
        portraitSrc: ENEMY_ART[currentEnemy.id] ?? ENEMY_ART.field_slime,
      },
    ];
    units.sort((a, b) => b.spd - a.spd);
    return units;
  }, []);

  const startBattle = useCallback(
    (enemyId: string, overrideParty?: PartyMember[]) => {
      if (enemyTurnTimeoutRef.current) {
        window.clearTimeout(enemyTurnTimeoutRef.current);
        enemyTurnTimeoutRef.current = null;
      }

      const activeParty = (overrideParty ?? partyRef.current).map((member) => ({
        ...member,
        buffAtk: 0,
        hp: member.hp <= 0 ? Math.round(member.maxHp * 0.3) : member.hp,
      }));
      const nextEnemy = cloneEnemy(enemyId);
      const queue = buildQueue(activeParty, nextEnemy);

      setParty(activeParty);
      setEnemy(nextEnemy);
      setIsEnemyBroken(false);
      setTurnQueue(queue);
      setFloatingDamage(null);
      setLogs([
        {
          id: logIdRef.current++,
          text: `${nextEnemy.name}이(가) 앞을 가로막았습니다.`,
          tone: 'weak',
        },
      ]);
      setScreen('battle');
    },
    [buildQueue],
  );

  const handleBattleVictory = useCallback(
    (wonEnemy: EnemyData, survivingParty: PartyMember[]) => {
      soundEngine.play('heal');
      const expGain = wonEnemy.expReward || 80;
      let leveledUp = false;
      let newLv = survivingParty[0]?.lv ?? 1;

      const updatedParty = survivingParty.map((member) => {
        const next = { ...member, exp: member.exp + expGain };
        while (next.exp >= next.nextExp) {
          next.exp -= next.nextExp;
          next.lv += 1;
          next.nextExp = Math.round(next.nextExp * 1.35);
          next.maxHp += next.growth.hp;
          next.maxMp += next.growth.mp;
          next.atk += next.growth.atk;
          next.spd += next.growth.spd;
          next.hp = next.maxHp;
          next.mp = next.maxMp;
          leveledUp = true;
          newLv = next.lv;
        }
        return next;
      });

      setParty(updatedParty);

      if (wonEnemy.isBoss) {
        if (chapterIdxRef.current >= STORY_CHAPTERS.length - 1) {
          soundEngine.play('levelup');
          setEndingOutcome('victory');
          return;
        }
        setChapterIdx((prev) => prev + 1);
      }

      if (leveledUp) {
        soundEngine.play('levelup');
      }

      setScreen('world');
      showToast(
        leveledUp ? `LEVEL UP! (Lv.${newLv})` : `전투 승리 (+${expGain} EXP)`,
        leveledUp
          ? `경험치 +${expGain} 획득! 원정대 능력치가 상승하고 HP/MP가 회복되었습니다.`
          : `적 처치 보상으로 경험치 +${expGain}을 획득했습니다.`,
      );
    },
    [showToast],
  );

  const advanceTurnQueue = useCallback(
    (nextQueue: TurnUnit[], nextParty: PartyMember[], nextEnemy: EnemyData, nextBroken: boolean) => {
      if (nextEnemy.hp <= 0) {
        handleBattleVictory(nextEnemy, nextParty);
        return;
      }
      if (nextParty.every((p) => p.hp <= 0)) {
        setEndingOutcome('defeat');
        return;
      }

      let queue = [...nextQueue];
      if (queue.length === 0) {
        queue = buildQueue(nextParty, nextEnemy);
      }

      // Skip dead allies
      while (queue.length > 0 && queue[0].type === 'ally') {
        const ally = nextParty.find((p) => p.id === queue[0].id);
        if (ally && ally.hp > 0) break;
        queue.shift();
        if (queue.length === 0) {
          queue = buildQueue(nextParty, nextEnemy);
        }
      }

      setTurnQueue(queue);

      if (queue[0]?.type === 'enemy') {
        enemyTurnTimeoutRef.current = window.setTimeout(() => {
          if (screenRef.current !== 'battle') return;
          const curEnemy = enemyRef.current;
          const curParty = partyRef.current;

          if (curEnemy.hp <= 0) {
            handleBattleVictory(curEnemy, curParty);
            return;
          }

          if (brokenRef.current) {
            const recoveredEnemy = { ...curEnemy, shield: curEnemy.maxShield };
            setEnemy(recoveredEnemy);
            setIsEnemyBroken(false);
            appendLog(`${curEnemy.name}이(가) 기절에서 깨어나 실드를 복구했습니다.`, 'buff');
            advanceTurnQueue(queue.slice(1), curParty, recoveredEnemy, false);
            return;
          }

          const alive = curParty.filter((p) => p.hp > 0);
          if (alive.length === 0) {
            setEndingOutcome('defeat');
            return;
          }

          soundEngine.play('attack');
          const isAoE = curEnemy.isBoss && Math.random() < 0.35;
          let updatedParty: PartyMember[];

          if (isAoE) {
            const dmg = Math.round(curEnemy.atk * 0.75);
            updatedParty = curParty.map((m) => (m.hp > 0 ? { ...m, hp: m.hp - dmg } : m));
            appendLog(`${curEnemy.name}의 광역 파동! 아군 전체에게 ${dmg} 피해`, 'enemy');
          } else {
            const target = alive[Math.floor(Math.random() * alive.length)];
            const dmg = Math.round(curEnemy.atk * (0.9 + Math.random() * 0.25));
            updatedParty = curParty.map((m) => (m.id === target.id ? { ...m, hp: m.hp - dmg } : m));
            appendLog(`${curEnemy.name}의 강타! ${target.shortName}에게 ${dmg} 피해`, 'enemy');
          }

          setParty(updatedParty);
          advanceTurnQueue(queue.slice(1), updatedParty, curEnemy, nextBroken);
        }, 720);
      }
    },
    [appendLog, buildQueue, handleBattleVictory],
  );

  const handleUseSkill = useCallback(
    (skillIdx: number) => {
      const currentHead = turnQueue[0];
      if (!currentHead || currentHead.type !== 'ally') return;

      const allyIdx = party.findIndex((p) => p.id === currentHead.id);
      if (allyIdx === -1) return;
      const ally = party[allyIdx];
      const skill = ally.skills[skillIdx];
      if (!skill || ally.mp < skill.mp) return;

      const totalAtk = ally.atk + ally.buffAtk;
      let updatedParty = party.map((m, idx) =>
        idx === allyIdx ? { ...m, mp: Math.min(m.maxMp, m.mp - skill.mp + 4) } : m,
      );
      let updatedEnemy = { ...enemy };
      let updatedBroken = isEnemyBroken;

      if (skill.type === 'damage' || skill.type === 'damage_and_heal' || skill.type === 'debuff_def') {
        const isWeak = Boolean(skill.element && updatedEnemy.weaknesses.includes(skill.element));
        const mult = skill.power * (isWeak ? 1.3 : 1.0) * (updatedBroken ? 1.5 : 1.0);
        const dmg = Math.round(totalAtk * mult);

        updatedEnemy.hp -= dmg;
        setEnemyShakeKey((k) => k + 1);

        if (isWeak || skill.type === 'debuff_def') {
          const breakAmt = skill.type === 'debuff_def' ? 2 : 1;
          if (!updatedBroken && updatedEnemy.shield > 0) {
            updatedEnemy.shield = Math.max(0, updatedEnemy.shield - breakAmt);
            if (updatedEnemy.shield === 0) {
              updatedBroken = true;
              soundEngine.play('break');
              setFloatingDamage({ id: Date.now(), text: `BREAK! -${dmg}`, tone: 'break' });
              appendLog(`WEAK & BREAK! ${ally.shortName}의 [${skill.name}] 실드 파괴 · ${dmg} 피해!`, 'break');
            } else {
              soundEngine.play('attack');
              setFloatingDamage({ id: Date.now(), text: `WEAK -${dmg}`, tone: 'weak' });
              appendLog(`약점 적중! ${ally.shortName}의 [${skill.name}] → ${dmg} 피해 (실드 -${breakAmt})`, 'weak');
            }
          } else {
            soundEngine.play('attack');
            setFloatingDamage({ id: Date.now(), text: `-${dmg}`, tone: 'normal' });
            appendLog(`${ally.shortName}의 [${skill.name}] → ${dmg} 피해`, 'damage');
          }
        } else {
          soundEngine.play('attack');
          setFloatingDamage({ id: Date.now(), text: `-${dmg}`, tone: 'normal' });
          appendLog(`${ally.shortName}의 [${skill.name}] → ${dmg} 피해`, 'damage');
        }

        if (skill.type === 'damage_and_heal') {
          updatedParty = updatedParty.map((m) =>
            m.hp > 0 ? { ...m, hp: Math.min(m.maxHp, m.hp + 30) } : m,
          );
          setHealFlashKey((k) => k + 1);
          appendLog('신성의 여파로 아군 전체 HP +30 회복', 'heal');
        }
      } else if (skill.type === 'heal_single') {
        soundEngine.play('heal');
        const aliveSorted = [...updatedParty]
          .filter((m) => m.hp > 0)
          .sort((a, b) => a.hp / a.maxHp - b.hp / b.maxHp);
        const target = aliveSorted[0];
        if (target) {
          updatedParty = updatedParty.map((m) =>
            m.id === target.id ? { ...m, hp: Math.min(m.maxHp, m.hp + skill.power) } : m,
          );
          setHealFlashKey((k) => k + 1);
          appendLog(`${ally.shortName}이(가) ${target.shortName}의 HP를 ${skill.power} 회복`, 'heal');
        }
      } else if (skill.type === 'heal_all' || skill.type === 'shield_party') {
        soundEngine.play('heal');
        updatedParty = updatedParty.map((m) =>
          m.hp > 0 ? { ...m, hp: Math.min(m.maxHp, m.hp + skill.power) } : m,
        );
        setHealFlashKey((k) => k + 1);
        appendLog(`${ally.shortName}의 [${skill.name}]! 아군 전체 HP +${skill.power} 회복`, 'heal');
      } else if (skill.type === 'buff') {
        soundEngine.play('magic');
        updatedParty = updatedParty.map((m) =>
          m.hp > 0 ? { ...m, buffAtk: m.buffAtk + skill.power } : m,
        );
        appendLog(`${ally.shortName}의 [${skill.name}]! 아군 전체 공격력 +${skill.power}`, 'buff');
      } else if (skill.type === 'self_buff') {
        soundEngine.play('magic');
        updatedParty = updatedParty.map((m, idx) =>
          idx === allyIdx ? { ...m, buffAtk: m.buffAtk + skill.power } : m,
        );
        appendLog(`${ally.shortName}의 [${skill.name}]! 자신의 공격력 +${skill.power}`, 'buff');
      } else if (skill.type === 'restore_mp') {
        soundEngine.play('magic');
        updatedParty = updatedParty.map((m, idx) =>
          idx === allyIdx ? { ...m, mp: Math.min(m.maxMp, m.mp + skill.power) } : m,
        );
        appendLog(`${ally.shortName}이(가) 마나 순환으로 MP +${skill.power} 회복`, 'buff');
      }

      setParty(updatedParty);
      setEnemy(updatedEnemy);
      setIsEnemyBroken(updatedBroken);

      advanceTurnQueue(turnQueue.slice(1), updatedParty, updatedEnemy, updatedBroken);
    },
    [advanceTurnQueue, appendLog, enemy, isEnemyBroken, party, turnQueue],
  );

  const handleStartGame = () => {
    soundEngine.play('magic');
    setParty([cloneHero('hero')]);
    setChapterIdx(0);
    setDialogueIdx(0);
    setZone('overworld');
    setEndingOutcome(null);
    setResetTrigger((n) => n + 1);
    setScreen('world');
  };

  const handleReturnTitle = () => {
    if (enemyTurnTimeoutRef.current) window.clearTimeout(enemyTurnTimeoutRef.current);
    soundEngine.play('ui');
    setEndingOutcome(null);
    setZone('overworld');
    setScreen('title');
  };

  const handleToggleAudio = () => {
    const next = !audioEnabled;
    setAudioEnabled(next);
    soundEngine.setEnabled(next);
    if (next) soundEngine.play('ui');
  };

  const handleEnterStoryBeacon = useCallback(() => {
    soundEngine.play('magic');
    setDialogueIdx(0);
    setScreen('story');
  }, []);

  const recruitCompanionForChapter = useCallback(
    (chapIdx: number, currentParty: PartyMember[]): PartyMember[] => {
      const chap = STORY_CHAPTERS[chapIdx];
      if (!chap?.recruitAfterDialogue) return currentParty;
      if (currentParty.some((p) => p.id === chap.recruitAfterDialogue)) return currentParty;

      const template = cloneHero(chap.recruitAfterDialogue);
      const leader = currentParty[0];
      const leaderLv = leader?.lv ?? 1;
      for (let l = 1; l < leaderLv; l++) {
        template.lv += 1;
        template.nextExp = Math.round(template.nextExp * 1.35);
        template.maxHp += template.growth.hp;
        template.maxMp += template.growth.mp;
        template.atk += template.growth.atk;
        template.spd += template.growth.spd;
      }
      template.exp = leader?.exp ?? 0;
      template.hp = template.maxHp;
      template.mp = template.maxMp;
      return [...currentParty, template];
    },
    [],
  );

  const handleNextDialogue = () => {
    soundEngine.play('ui');
    const chap = STORY_CHAPTERS[chapterIdx];
    if (dialogueIdx < chap.dialogues.length - 1) {
      setDialogueIdx((d) => d + 1);
    } else {
      const nextParty = recruitCompanionForChapter(chapterIdx, party);
      startBattle(chap.enemyId, nextParty);
    }
  };

  const handleSkipToBattle = () => {
    soundEngine.play('attack');
    const chap = STORY_CHAPTERS[chapterIdx];
    const nextParty = recruitCompanionForChapter(chapterIdx, party);
    startBattle(chap.enemyId, nextParty);
  };

  const handleCamp = useCallback(() => {
    soundEngine.play('heal');
    setParty((prev) =>
      prev.map((p) => ({
        ...p,
        hp: p.maxHp,
        mp: p.maxMp,
        buffAtk: 0,
      })),
    );
    setCampTrigger((c) => c + 1);
    showToast('야영 완료', '원정대 전체 HP/MP가 100% 회복되고 주변 마물들이 다시 나타났습니다.');
  }, [showToast]);

  const handleZoneChange = useCallback(
    (nextZone: ZoneId, title: string, desc: string) => {
      soundEngine.play(nextZone === 'overworld' ? 'heal' : 'magic');
      setZone(nextZone);
      showToast(title, desc);
    },
    [showToast],
  );

  const handleEncounterMonster = useCallback(
    (enemyId: string) => {
      soundEngine.play('attack');
      startBattle(enemyId);
    },
    [startBattle],
  );

  const currentChapter = STORY_CHAPTERS[chapterIdx] ?? STORY_CHAPTERS[0];
  const partyLevel = party[0]?.lv ?? 1;

  return (
    <div className="min-h-dvh flex flex-col bg-[#090b12] text-slate-100">
      <GameHeader
        screen={screen}
        chapterBadge={currentChapter.badge}
        partyLevel={partyLevel}
        audioEnabled={audioEnabled}
        onToggleAudio={handleToggleAudio}
        onOpenRoster={() => {
          soundEngine.play('ui');
          setShowRosterModal(true);
        }}
        onReturnTitle={handleReturnTitle}
      />

      <main className="flex-1 flex flex-col relative">
        {screen === 'title' && <TitleScreen onStartGame={handleStartGame} />}

        {/* Keep 3D WebGL World mounted across exploration/story/battle to preserve position & WebGL state */}
        {screen !== 'title' && (
          <WorldExplorer
            isActive={screen === 'world'}
            party={party}
            currentChapter={currentChapter}
            currentChapterIdx={chapterIdx}
            zone={zone}
            campTrigger={campTrigger}
            resetTrigger={resetTrigger}
            toast={worldToast}
            onEnterStoryBeacon={handleEnterStoryBeacon}
            onEncounterMonster={handleEncounterMonster}
            onZoneChange={handleZoneChange}
            onCamp={handleCamp}
          />
        )}

        {screen === 'story' && (
          <StoryScreen
            chapter={currentChapter}
            dialogueIndex={dialogueIdx}
            onNext={handleNextDialogue}
            onSkipToBattle={handleSkipToBattle}
          />
        )}

        {screen === 'battle' && (
          <BattleScreen
            zone={zone}
            chapterBackdropKey={currentChapter.backdropKey}
            enemy={enemy}
            party={party}
            turnQueue={turnQueue}
            activeUnit={turnQueue[0] ?? null}
            isEnemyBroken={isEnemyBroken}
            enemyShakeKey={enemyShakeKey}
            healFlashKey={healFlashKey}
            floatingDamage={floatingDamage}
            logs={logs}
            onUseSkill={handleUseSkill}
          />
        )}
      </main>

      {showRosterModal && (
        <PartyModal party={party} onClose={() => setShowRosterModal(false)} />
      )}

      {endingOutcome && (
        <EndingModal
          outcome={endingOutcome}
          partyLevel={partyLevel}
          onRestart={handleReturnTitle}
        />
      )}
    </div>
  );
}
