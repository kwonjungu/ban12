import { useState, useCallback, useRef } from 'react';
import { GameCanvas } from './components/GameCanvas';
import { HUD } from './components/HUD';
import { DialogueModal } from './components/DialogueModal';
import { StartScreen } from './components/StartScreen';
import { GameState, TargetInfo, DialogueData } from './types';
import { soundEngine } from './audio';
import { Info } from 'lucide-react';

const INITIAL_GAME_STATE: GameState = {
  currentLocation: 'village',
  hp: 100,
  maxHp: 100,
  gold: 50,
  hasKey: false,
  weapon: 1,
  ammo: 12,
  maxAmmo: 30,
  swordDamage: 35,
  gunDamage: 60,
  quests: {
    talkChief: false,
    visitedShop: false,
    upgradedGear: false,
    unlockedCastle: false,
    bossDefeated: false,
  },
  boss: {
    hp: 500,
    maxHp: 500,
    active: false,
    isAttacking: false,
    dead: false,
  },
  isGameOver: false,
  isVictory: false,
};

export default function App() {
  const [gameState, setGameState] = useState<GameState>(INITIAL_GAME_STATE);
  const [isStarted, setIsStarted] = useState<boolean>(false);
  const [isLocked, setIsLocked] = useState<boolean>(false);
  const [currentTarget, setCurrentTarget] = useState<TargetInfo | null>(null);
  const [activeDialogue, setActiveDialogue] = useState<DialogueData | null>(null);
  const [toast, setToast] = useState<{ message: string; visible: boolean }>({
    message: '',
    visible: false,
  });
  const [showFlash, setShowFlash] = useState<boolean>(false);
  const [showDamage, setShowDamage] = useState<boolean>(false);

  const toastTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const showToast = useCallback((msg: string) => {
    if (toastTimeoutRef.current) {
      clearTimeout(toastTimeoutRef.current);
    }
    setToast({ message: msg, visible: true });
    toastTimeoutRef.current = setTimeout(() => {
      setToast((prev) => ({ ...prev, visible: false }));
    }, 2800);
  }, []);

  const handleFlash = useCallback(() => {
    setShowFlash(true);
    setTimeout(() => setShowFlash(false), 80);
  }, []);

  const handleDamage = useCallback(() => {
    setShowDamage(true);
    setTimeout(() => setShowDamage(false), 240);
  }, []);

  const handleStartGame = () => {
    soundEngine.init();
    setIsStarted(true);
    setIsLocked(true);
    showToast('마을 광장에 도착했습니다. 촌장 엘드린을 찾아가세요!');
  };

  const handleEquipWeapon = (wep: 1 | 2) => {
    setGameState((prev) => ({ ...prev, weapon: wep }));
  };

  const handleOpenDialogue = (data: DialogueData) => {
    soundEngine.playPickup();
    setActiveDialogue(data);
    setIsLocked(false);
  };

  const handleCloseDialogue = () => {
    setActiveDialogue(null);
    setIsLocked(true);
  };

  const handleRespawn = () => {
    setGameState((prev) => ({
      ...prev,
      hp: 100,
      currentLocation: 'village',
      isGameOver: false,
      boss: {
        ...prev.boss,
        active: false,
        isAttacking: false,
      },
    }));
    setIsLocked(true);
    showToast('마을 광장에서 다시 체력을 회복하고 부활했습니다!');
  };

  const handleRestart = () => {
    setGameState(INITIAL_GAME_STATE);
    setIsStarted(false);
    setIsLocked(false);
    setActiveDialogue(null);
  };

  return (
    <main className="relative w-screen h-screen overflow-hidden bg-slate-950 font-sans select-none">
      {/* 3D Canvas Rendering Layer */}
      {isStarted && (
        <GameCanvas
          gameState={gameState}
          setGameState={setGameState}
          onOpenDialogue={handleOpenDialogue}
          onShowToast={showToast}
          currentTarget={currentTarget}
          setCurrentTarget={setCurrentTarget}
          onFlashScreen={handleFlash}
          onDamageScreen={handleDamage}
          isLocked={isLocked}
          setIsLocked={setIsLocked}
          isDialogueOpen={!!activeDialogue}
        />
      )}

      {/* Floating HUD */}
      {isStarted && (
        <HUD
          gameState={gameState}
          currentTarget={currentTarget}
          onEquipWeapon={handleEquipWeapon}
          showFlash={showFlash}
          showDamage={showDamage}
        />
      )}

      {/* Dialogue Box Overlay */}
      {activeDialogue && (
        <DialogueModal dialogue={activeDialogue} onClose={handleCloseDialogue} />
      )}

      {/* Toast Notification */}
      <div
        id="toast"
        className={`fixed top-20 left-1/2 -translate-x-1/2 z-50 bg-slate-950/90 backdrop-blur-md px-5 py-2.5 rounded-xl border border-amber-400/70 text-amber-300 font-bold text-xs sm:text-sm tracking-wide transition-all duration-300 pointer-events-none shadow-2xl flex items-center gap-2 ${
          toast.visible ? 'opacity-100 -translate-y-0 scale-100' : 'opacity-0 -translate-y-4 scale-95'
        }`}
      >
        <Info className="w-4 h-4 text-amber-400" />
        <span id="toast-text">{toast.message}</span>
      </div>

      {/* Modals: Start / Game Over / Victory / Pause */}
      <StartScreen
        isStarted={isStarted}
        onStart={handleStartGame}
        isGameOver={gameState.isGameOver}
        onRespawn={handleRespawn}
        isVictory={gameState.isVictory}
        onRestart={handleRestart}
        isLocked={isLocked}
        onResume={() => setIsLocked(true)}
        isDialogueOpen={!!activeDialogue}
      />
    </main>
  );
}
