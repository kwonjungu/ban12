export type LocationType = 'village' | 'shop' | 'castle' | 'boss_lair';

export type WeaponType = 1 | 2; // 1: 검(Sword), 2: 권총(Gun)

export interface QuestsState {
  talkChief: boolean;
  visitedShop: boolean;
  upgradedGear: boolean;
  unlockedCastle: boolean;
  bossDefeated: boolean;
}

export interface BossState {
  hp: number;
  maxHp: number;
  active: boolean;
  isAttacking: boolean;
  dead: boolean;
}

export interface GameState {
  currentLocation: LocationType;
  hp: number;
  maxHp: number;
  gold: number;
  hasKey: boolean;
  weapon: WeaponType;
  ammo: number;
  maxAmmo: number;
  swordDamage: number;
  gunDamage: number;
  quests: QuestsState;
  boss: BossState;
  isGameOver: boolean;
  isVictory: boolean;
}

export interface DialogueOption {
  text: string;
  action: () => void;
  condition?: () => boolean;
}

export interface DialogueData {
  name: string;
  role: string;
  dialogues: string[];
  options?: DialogueOption[];
}

export interface TargetInfo {
  type: 'npc' | 'portal' | 'chest' | 'item';
  name: string;
  promptText: string;
}
