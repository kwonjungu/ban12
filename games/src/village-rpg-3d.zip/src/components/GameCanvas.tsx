import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import confetti from 'canvas-confetti';
import { GameState, LocationType, TargetInfo, DialogueData } from '../types';
import { soundEngine } from '../audio';

interface GameCanvasProps {
  gameState: GameState;
  setGameState: React.Dispatch<React.SetStateAction<GameState>>;
  onOpenDialogue: (dialogue: DialogueData) => void;
  onShowToast: (msg: string) => void;
  currentTarget: TargetInfo | null;
  setCurrentTarget: (target: TargetInfo | null) => void;
  onFlashScreen: () => void;
  onDamageScreen: () => void;
  isLocked: boolean;
  setIsLocked: (locked: boolean) => void;
  isDialogueOpen: boolean;
}

export const GameCanvas: React.FC<GameCanvasProps> = ({
  gameState,
  setGameState,
  onOpenDialogue,
  onShowToast,
  currentTarget: _currentTarget,
  setCurrentTarget,
  onFlashScreen,
  onDamageScreen,
  isLocked,
  setIsLocked,
  isDialogueOpen,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const minimapCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // References to keep Three.js state synced with React
  const stateRef = useRef(gameState);
  stateRef.current = gameState;

  const isLockedRef = useRef(isLocked);
  isLockedRef.current = isLocked;

  const isDialogueOpenRef = useRef(isDialogueOpen);
  isDialogueOpenRef.current = isDialogueOpen;

  // Key controls ref
  const keysRef = useRef<{ [key: string]: boolean }>({});
  const mouseStateRef = useRef<{ isDragging: boolean; prevX: number; prevY: number }>({
    isDragging: false,
    prevX: 0,
    prevY: 0,
  });

  // Action trigger refs (to bridge DOM events into render loop)
  const actionTriggerRef = useRef<{
    attackRequested: boolean;
    interactRequested: boolean;
    collectRequested: boolean;
    switchWeapon: number | null;
  }>({
    attackRequested: false,
    interactRequested: false,
    collectRequested: false,
    switchWeapon: null,
  });

  useEffect(() => {
    if (!containerRef.current) return;

    // 1. THREE.JS INITIALIZATION
    const container = containerRef.current;
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0a0f1d);
    scene.fog = new THREE.FogExp2(0x0a0f1d, 0.016);

    const camera = new THREE.PerspectiveCamera(
      75,
      container.clientWidth / container.clientHeight,
      0.1,
      1000
    );
    camera.position.set(0, 1.6, 5);

    const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // Camera Rig & First Person Angles
    const cameraPitchObject = new THREE.Object3D();
    cameraPitchObject.add(camera);
    const cameraYawObject = new THREE.Object3D();
    cameraYawObject.position.set(0, 1.6, 5);
    cameraYawObject.add(cameraPitchObject);
    scene.add(cameraYawObject);

    // Procedural Textures & Materials
    function createCobbleTexture(): THREE.CanvasTexture {
      const c = document.createElement('canvas');
      c.width = 256;
      c.height = 256;
      const ctx = c.getContext('2d')!;
      ctx.fillStyle = '#2d3342';
      ctx.fillRect(0, 0, 256, 256);
      for (let y = 0; y < 256; y += 32) {
        for (let x = 0; x < 256; x += 32) {
          const ox = Math.floor(y / 32) % 2 === 0 ? 0 : 16;
          ctx.fillStyle = '#3f475a';
          ctx.beginPath();
          ctx.roundRect(x + ox + 2, y + 2, 28, 28, 5);
          ctx.fill();
          ctx.strokeStyle = '#1a1f2c';
          ctx.lineWidth = 2;
          ctx.stroke();
        }
      }
      const tex = new THREE.CanvasTexture(c);
      tex.wrapS = THREE.RepeatWrapping;
      tex.wrapT = THREE.RepeatWrapping;
      tex.repeat.set(16, 16);
      return tex;
    }

    const cobbleTex = createCobbleTexture();
    const materials = {
      stoneFloor: new THREE.MeshStandardMaterial({ map: cobbleTex, roughness: 0.8, metalness: 0.1 }),
      woodWall: new THREE.MeshStandardMaterial({ color: 0x5c3a21, roughness: 0.7 }),
      roofTile: new THREE.MeshStandardMaterial({ color: 0x8b2626, roughness: 0.5 }),
      gold: new THREE.MeshStandardMaterial({ color: 0xf59e0b, metalness: 0.9, roughness: 0.2 }),
      steel: new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.9, roughness: 0.1 }),
      skin: new THREE.MeshStandardMaterial({ color: 0xe0ac69, roughness: 0.6 }),
      clothChief: new THREE.MeshStandardMaterial({ color: 0x1e3a8a, roughness: 0.8 }),
      clothShop: new THREE.MeshStandardMaterial({ color: 0x065f46, roughness: 0.8 }),
      clothGuard: new THREE.MeshStandardMaterial({ color: 0x991b1b, metalness: 0.4, roughness: 0.4 }),
      demonSkin: new THREE.MeshStandardMaterial({ color: 0x450a0a, roughness: 0.3, metalness: 0.3 }),
      lavaFloor: new THREE.MeshStandardMaterial({ color: 0x240808, roughness: 0.9 }),
    };

    // Containers for dynamic entities
    const mapContainer = new THREE.Group();
    scene.add(mapContainer);

    let npcs: THREE.Group[] = [];
    let items: THREE.Mesh[] = [];
    let portals: THREE.Mesh[] = [];
    let chests: THREE.Group[] = [];

    // Weapon Meshes inside First-Person camera view
    const weaponGroup = new THREE.Group();
    camera.add(weaponGroup);

    // Sword Model
    const swordGroup = new THREE.Group();
    const bladeGeo = new THREE.BoxGeometry(0.04, 0.85, 0.08);
    const blade = new THREE.Mesh(bladeGeo, materials.steel);
    blade.position.set(0, 0.42, 0);
    const hiltGeo = new THREE.CylinderGeometry(0.02, 0.02, 0.22);
    const hilt = new THREE.Mesh(hiltGeo, materials.woodWall);
    hilt.position.set(0, -0.06, 0);
    const guardGeo = new THREE.BoxGeometry(0.24, 0.03, 0.06);
    const guard = new THREE.Mesh(guardGeo, materials.gold);
    guard.position.set(0, 0.05, 0);
    swordGroup.add(blade, hilt, guard);
    swordGroup.position.set(0.3, -0.3, -0.5);
    swordGroup.rotation.set(0.2, -0.3, 0);
    weaponGroup.add(swordGroup);

    // Gun Model
    const gunGroup = new THREE.Group();
    const barrelGeo = new THREE.CylinderGeometry(0.03, 0.035, 0.5);
    barrelGeo.rotateX(Math.PI / 2);
    const barrel = new THREE.Mesh(barrelGeo, materials.steel);
    barrel.position.set(0, 0, -0.2);
    const handleGeo = new THREE.BoxGeometry(0.06, 0.22, 0.08);
    const handle = new THREE.Mesh(handleGeo, materials.woodWall);
    handle.position.set(0, -0.1, 0);
    handle.rotation.x = -0.35;
    gunGroup.add(barrel, handle);
    gunGroup.position.set(0.3, -0.25, -0.4);
    gunGroup.visible = false;
    weaponGroup.add(gunGroup);

    // Muzzle Flash Light
    const muzzleLight = new THREE.PointLight(0xffbe3b, 0, 8);
    muzzleLight.position.set(0.3, -0.2, -0.75);
    weaponGroup.add(muzzleLight);

    // 2. PROCEDURAL ENTITY BUILDERS
    function createHumanoid(role: 'chief' | 'merchant' | 'guard'): THREE.Group {
      const g = new THREE.Group();
      const clothMat =
        role === 'chief'
          ? materials.clothChief
          : role === 'merchant'
          ? materials.clothShop
          : materials.clothGuard;

      // Head
      const head = new THREE.Mesh(new THREE.SphereGeometry(0.32, 16, 16), materials.skin);
      head.position.y = 1.6;
      head.castShadow = true;
      g.add(head);

      // Eyes
      const eyeMat = new THREE.MeshBasicMaterial({ color: 0x0f172a });
      const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.04, 8, 8), eyeMat);
      eyeL.position.set(-0.1, 1.64, 0.28);
      const eyeR = eyeL.clone();
      eyeR.position.x = 0.1;
      g.add(eyeL, eyeR);

      // Hat / Helmet
      if (role === 'chief') {
        const hat = new THREE.Mesh(new THREE.ConeGeometry(0.48, 0.45, 8), new THREE.MeshStandardMaterial({ color: 0xd97706 }));
        hat.position.y = 1.95;
        g.add(hat);
      } else if (role === 'guard') {
        const helm = new THREE.Mesh(new THREE.SphereGeometry(0.36, 12, 12), materials.steel);
        helm.position.y = 1.65;
        g.add(helm);
      }

      // Torso
      const torso = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.24, 0.8, 12), clothMat);
      torso.position.y = 1.0;
      torso.castShadow = true;
      g.add(torso);

      // Arms
      const armGeo = new THREE.CylinderGeometry(0.07, 0.06, 0.7, 8);
      const armL = new THREE.Mesh(armGeo, clothMat);
      armL.position.set(-0.4, 0.9, 0);
      const armR = new THREE.Mesh(armGeo, clothMat);
      armR.position.set(0.4, 0.9, 0);
      g.add(armL, armR);

      // Legs
      const legGeo = new THREE.CylinderGeometry(0.09, 0.08, 0.7, 8);
      const legMat = new THREE.MeshStandardMaterial({ color: 0x1e293b });
      const legL = new THREE.Mesh(legGeo, legMat);
      legL.position.set(-0.16, 0.35, 0);
      const legR = new THREE.Mesh(legGeo, legMat);
      legR.position.set(0.16, 0.35, 0);
      g.add(legL, legR);

      g.userData = {
        role,
        head,
        armL,
        armR,
        animTimer: Math.random() * 10,
        isTalking: false,
      };
      return g;
    }

    function createBoss(): THREE.Group {
      const g = new THREE.Group();

      // Torso
      const torso = new THREE.Mesh(new THREE.CylinderGeometry(0.9, 0.7, 2.4, 14), materials.demonSkin);
      torso.position.y = 1.7;
      torso.castShadow = true;
      g.add(torso);

      // Head
      const head = new THREE.Mesh(new THREE.SphereGeometry(0.55, 16, 16), materials.demonSkin);
      head.position.y = 3.0;
      g.add(head);

      // Eyes (Glowing Red)
      const eyeMat = new THREE.MeshBasicMaterial({ color: 0xff2222 });
      const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.09, 8, 8), eyeMat);
      eyeL.position.set(-0.2, 3.1, 0.46);
      const eyeR = eyeL.clone();
      eyeR.position.x = 0.2;
      g.add(eyeL, eyeR);

      // Horns
      const hornGeo = new THREE.ConeGeometry(0.16, 0.9, 8);
      const hornMat = new THREE.MeshStandardMaterial({ color: 0x111827, roughness: 0.2 });
      const hornL = new THREE.Mesh(hornGeo, hornMat);
      hornL.position.set(-0.4, 3.5, 0);
      hornL.rotation.z = -0.4;
      const hornR = hornL.clone();
      hornR.position.x = 0.4;
      hornR.rotation.z = 0.4;
      g.add(hornL, hornR);

      // Wings
      const wingShape = new THREE.Shape();
      wingShape.moveTo(0, 0);
      wingShape.lineTo(-1.8, 1.4);
      wingShape.lineTo(-2.4, 0.3);
      wingShape.lineTo(-1.2, -0.9);
      wingShape.closePath();
      const wingGeo = new THREE.ShapeGeometry(wingShape);
      const wingMat = new THREE.MeshStandardMaterial({ color: 0x300505, side: THREE.DoubleSide });

      const wingL = new THREE.Mesh(wingGeo, wingMat);
      wingL.position.set(-0.5, 2.1, -0.4);
      const wingR = wingL.clone();
      wingR.scale.x = -1;
      wingR.position.x = 0.5;
      g.add(wingL, wingR);

      // Giant Dark Sword
      const sword = new THREE.Mesh(
        new THREE.BoxGeometry(0.24, 2.8, 0.08),
        new THREE.MeshStandardMaterial({ color: 0x881337, metalness: 0.9, roughness: 0.2 })
      );
      sword.position.set(1.2, 1.4, 0.5);
      sword.rotation.x = 0.35;
      g.add(sword);

      g.userData = {
        role: 'boss',
        head,
        wingL,
        wingR,
        sword,
        animTimer: 0,
      };
      g.position.set(0, 0, -14);
      return g;
    }

    function createPortal(x: number, z: number, targetLoc: LocationType, promptText: string) {
      const geo = new THREE.TorusGeometry(1.2, 0.1, 16, 32);
      const mat = new THREE.MeshBasicMaterial({ color: 0x38bdf8, wireframe: true });
      const portal = new THREE.Mesh(geo, mat);
      portal.position.set(x, 1.2, z);

      const pLight = new THREE.PointLight(0x38bdf8, 1.2, 7);
      pLight.position.set(x, 1.2, z);
      mapContainer.add(pLight);

      portal.userData = { isPortal: true, targetLoc, promptText };
      mapContainer.add(portal);
      portals.push(portal);
    }

    function createChest(x: number, z: number, gold: number): THREE.Group {
      const chestGroup = new THREE.Group();
      const baseGeo = new THREE.BoxGeometry(1, 0.5, 0.8);
      const chestMat = new THREE.MeshStandardMaterial({ color: 0xb45309 });
      const base = new THREE.Mesh(baseGeo, chestMat);
      base.position.y = 0.25;

      const lidGeo = new THREE.CylinderGeometry(0.4, 0.4, 1, 12, 1, false, 0, Math.PI);
      lidGeo.rotateZ(Math.PI / 2);
      const lid = new THREE.Mesh(lidGeo, new THREE.MeshStandardMaterial({ color: 0x92400e }));
      lid.position.set(0, 0.5, 0);

      chestGroup.add(base, lid);
      chestGroup.position.set(x, 0, z);

      chestGroup.userData = { isChest: true, gold, opened: false, lid };
      mapContainer.add(chestGroup);
      chests.push(chestGroup);
      return chestGroup;
    }

    function createItemDrop(x: number, z: number, type: 'health' | 'ammo' | 'gold') {
      const itemGeo = new THREE.SphereGeometry(0.24, 12, 12);
      const mat =
        type === 'health'
          ? new THREE.MeshStandardMaterial({ color: 0xef4444, emissive: 0x7f1d1d })
          : type === 'ammo'
          ? new THREE.MeshStandardMaterial({ color: 0x38bdf8, emissive: 0x0369a1 })
          : materials.gold;

      const item = new THREE.Mesh(itemGeo, mat);
      item.position.set(x, 0.35, z);
      item.userData = { isItem: true, type };
      mapContainer.add(item);
      items.push(item);
    }

    // 3. MAP BUILDER
    function buildMap(loc: LocationType) {
      while (mapContainer.children.length > 0) {
        mapContainer.remove(mapContainer.children[0]);
      }
      npcs = [];
      items = [];
      portals = [];
      chests = [];

      if (loc === 'village') {
        scene.background = new THREE.Color(0x1e293b);
        scene.fog?.color.setHex(0x1e293b);

        const sun = new THREE.DirectionalLight(0xfef08a, 1.2);
        sun.position.set(20, 35, 20);
        sun.castShadow = true;
        mapContainer.add(sun);

        const ambient = new THREE.AmbientLight(0x64748b, 0.7);
        mapContainer.add(ambient);

        // Ground
        const ground = new THREE.Mesh(new THREE.PlaneGeometry(80, 80), materials.stoneFloor);
        ground.rotation.x = -Math.PI / 2;
        ground.receiveShadow = true;
        mapContainer.add(ground);

        // Village Houses
        for (let i = -2; i <= 2; i++) {
          if (i === 0) continue;
          const house = new THREE.Mesh(new THREE.BoxGeometry(8, 6, 8), materials.woodWall);
          house.position.set(i * 13, 3, -15);
          house.castShadow = true;

          const roof = new THREE.Mesh(new THREE.ConeGeometry(6.5, 4, 4), materials.roofTile);
          roof.position.set(i * 13, 8, -15);
          roof.rotation.y = Math.PI / 4;
          mapContainer.add(house, roof);
        }

        // Trees
        for (let i = 0; i < 12; i++) {
          const angle = (i / 12) * Math.PI * 2;
          const r = 24 + Math.random() * 6;
          const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.4, 3), materials.woodWall);
          trunk.position.set(Math.cos(angle) * r, 1.5, Math.sin(angle) * r);
          const leaves = new THREE.Mesh(new THREE.DodecahedronGeometry(1.8), new THREE.MeshStandardMaterial({ color: 0x15803d }));
          leaves.position.set(Math.cos(angle) * r, 3.8, Math.sin(angle) * r);
          leaves.castShadow = true;
          mapContainer.add(trunk, leaves);
        }

        // Elder Eldrin NPC
        const chief = createHumanoid('chief');
        chief.position.set(-3, 0, -5);
        chief.userData.name = '마을 촌장 엘드린';
        chief.userData.dialogue = [
          '용사여, 드디어 오셨구려! 마왕 말라코르가 왕궁을 장악하고 온 마을을 위협하고 있소.',
          '무기점에 들러 플린트록 탄약과 검을 강화한 뒤, 준비가 되면 내게 [왕궁 열쇠]를 받아 왕궁으로 향하시오!',
        ];
        mapContainer.add(chief);
        npcs.push(chief);

        // Portals & Chests
        createPortal(12, -10, 'shop', '무기점 입장 (E)');
        createPortal(0, -25, 'castle', '왕궁 성문 진입 (E)');
        createChest(5, -4, 60);

        // Dropped items
        createItemDrop(-6, -3, 'health');
        createItemDrop(6, -6, 'ammo');
      } else if (loc === 'shop') {
        scene.background = new THREE.Color(0x0f172a);
        scene.fog?.color.setHex(0x0f172a);

        const shopLight = new THREE.PointLight(0xf59e0b, 1.8, 22);
        shopLight.position.set(0, 4, 0);
        mapContainer.add(shopLight);

        const floor = new THREE.Mesh(new THREE.PlaneGeometry(24, 24), materials.woodWall);
        floor.rotation.x = -Math.PI / 2;
        mapContainer.add(floor);

        // Merchant NPC
        const merchant = createHumanoid('merchant');
        merchant.position.set(0, 0, -4);
        merchant.userData.name = '무기상 바니';
        merchant.userData.dialogue = [
          '어서 오게! 마왕을 무찌르려면 강력한 화력이 필수지!',
          '플린트록 권총은 원거리에서 치명적이고, 검은 근접에서 신속하게 벨 수 있네.',
        ];
        mapContainer.add(merchant);
        npcs.push(merchant);

        createPortal(0, 8, 'village', '마을로 나가기 (E)');
      } else if (loc === 'castle') {
        scene.background = new THREE.Color(0x111827);
        scene.fog?.color.setHex(0x111827);

        const cLight = new THREE.DirectionalLight(0x94a3b8, 1);
        cLight.position.set(0, 20, 0);
        mapContainer.add(cLight);

        const floor = new THREE.Mesh(new THREE.PlaneGeometry(32, 42), materials.stoneFloor);
        floor.rotation.x = -Math.PI / 2;
        mapContainer.add(floor);

        // Royal Guard
        const guard = createHumanoid('guard');
        guard.position.set(-2, 0, -6);
        guard.userData.name = '왕실 근위대장';
        guard.userData.dialogue = [
          '멈추시오! 이 문 너머는 마왕 말라코르가 둥지를 튼 왕좌실이오.',
          '한 번 들어가면 마왕을 물리치기 전까지 안전을 장담할 수 없소. 부디 행운을!',
        ];
        mapContainer.add(guard);
        npcs.push(guard);

        createPortal(0, 15, 'village', '마을로 후퇴 (E)');
        createPortal(0, -15, 'boss_lair', '마왕의 둥지 진입 (E)');
        createChest(8, -8, 80);
      } else if (loc === 'boss_lair') {
        scene.background = new THREE.Color(0x350808);
        scene.fog?.color.setHex(0x350808);

        const bossLight = new THREE.PointLight(0xef4444, 2.2, 35);
        bossLight.position.set(0, 8, 0);
        mapContainer.add(bossLight);

        const floor = new THREE.Mesh(new THREE.PlaneGeometry(45, 45), materials.lavaFloor);
        floor.rotation.x = -Math.PI / 2;
        mapContainer.add(floor);

        if (!stateRef.current.boss.dead) {
          const boss = createBoss();
          mapContainer.add(boss);
          npcs.push(boss);
          setGameState((prev) => ({
            ...prev,
            boss: { ...prev.boss, active: true },
          }));
        }

        createPortal(0, 18, 'castle', '왕궁으로 후퇴 (E)');
        createItemDrop(-8, 5, 'health');
        createItemDrop(8, 5, 'ammo');
      }
    }

    // INITIALIZE MAP & WEAPON
    buildMap(stateRef.current.currentLocation);

    // 4. MOVEMENT & INPUT LOGIC
    let isSprinting = false;
    let lastWTime = 0;
    const velocity = new THREE.Vector3();
    const moveDir = new THREE.Vector3();
    let prevTime = performance.now();
    let headBobTimer = 0;
    let isAttackingAnim = false;

    // Pitch & Yaw tracking
    let yaw = 0;
    let pitch = 0;

    const handleKeyDown = (e: KeyboardEvent) => {
      keysRef.current[e.code] = true;

      // Sprint double-tap W or Shift
      if (e.code === 'KeyW') {
        const now = performance.now();
        if (now - lastWTime < 300) {
          isSprinting = true;
        }
        lastWTime = now;
      }
      if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') {
        isSprinting = true;
      }

      if (e.code === 'Digit1') actionTriggerRef.current.switchWeapon = 1;
      if (e.code === 'Digit2') actionTriggerRef.current.switchWeapon = 2;
      if (e.code === 'KeyE') actionTriggerRef.current.interactRequested = true;
      if (e.code === 'KeyQ') actionTriggerRef.current.collectRequested = true;
      if (e.code === 'Space') {
        // Space attacks or jumps
        actionTriggerRef.current.attackRequested = true;
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      keysRef.current[e.code] = false;
      if (e.code === 'KeyW' || e.code === 'ShiftLeft' || e.code === 'ShiftRight') {
        isSprinting = false;
      }
    };

    const handleMouseDown = (e: MouseEvent) => {
      if (isDialogueOpenRef.current) return;
      if (e.button === 0) {
        if (!isLockedRef.current) {
          // If clicked canvas while unlocked, request lock
          setIsLocked(true);
        } else {
          actionTriggerRef.current.attackRequested = true;
        }
      }
      mouseStateRef.current.isDragging = true;
      mouseStateRef.current.prevX = e.clientX;
      mouseStateRef.current.prevY = e.clientY;
    };

    const handleMouseUp = () => {
      mouseStateRef.current.isDragging = false;
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (isDialogueOpenRef.current) return;

      if (isLockedRef.current) {
        // Pointer Lock movement
        const movementX = e.movementX || 0;
        const movementY = e.movementY || 0;
        yaw -= movementX * 0.0022;
        pitch -= movementY * 0.0022;
        pitch = Math.max(-1.4, Math.min(1.4, pitch));
      } else if (mouseStateRef.current.isDragging) {
        // Fallback drag movement
        const deltaX = e.clientX - mouseStateRef.current.prevX;
        const deltaY = e.clientY - mouseStateRef.current.prevY;
        mouseStateRef.current.prevX = e.clientX;
        mouseStateRef.current.prevY = e.clientY;
        yaw -= deltaX * 0.003;
        pitch -= deltaY * 0.003;
        pitch = Math.max(-1.4, Math.min(1.4, pitch));
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    container.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', handleMouseUp);
    window.addEventListener('mousemove', handleMouseMove);

    // 5. COMBAT EXECUTION
    function executeAttack() {
      if (isAttackingAnim) return;
      const curState = stateRef.current;
      soundEngine.init();

      if (curState.weapon === 1) {
        // SWORD ATTACK
        isAttackingAnim = true;
        soundEngine.playSwordSwing();

        let swing = 0;
        const interval = setInterval(() => {
          swing += 0.16;
          swordGroup.rotation.z = Math.sin(swing * Math.PI) * 1.3;
          swordGroup.rotation.x = 0.2 - Math.sin(swing * Math.PI) * 0.6;
          if (swing >= 1) {
            clearInterval(interval);
            swordGroup.rotation.set(0.2, -0.3, 0);
            isAttackingAnim = false;
          }
        }, 16);

        checkHit(curState.swordDamage, 3.5);
      } else {
        // GUN ATTACK
        if (curState.ammo <= 0) {
          onShowToast('권총 탄약이 부족합니다! 무기점에서 보충하세요.');
          return;
        }
        isAttackingAnim = true;
        soundEngine.playGunshot();

        setGameState((prev) => ({
          ...prev,
          ammo: Math.max(0, prev.ammo - 1),
        }));

        // Muzzle flash
        muzzleLight.intensity = 3.5;
        onFlashScreen();
        setTimeout(() => {
          muzzleLight.intensity = 0;
        }, 60);

        gunGroup.position.z = -0.22;
        setTimeout(() => {
          gunGroup.position.z = -0.4;
          isAttackingAnim = false;
        }, 160);

        checkHit(curState.gunDamage, 18);
      }
    }

    function checkHit(dmg: number, maxDist: number) {
      const curState = stateRef.current;
      if (curState.currentLocation === 'boss_lair' && !curState.boss.dead) {
        const boss = npcs.find((n) => n.userData.role === 'boss');
        if (boss) {
          const dist = cameraYawObject.position.distanceTo(boss.position);
          if (dist <= maxDist) {
            soundEngine.playHit();
            const newHp = Math.max(0, curState.boss.hp - dmg);
            const isDead = newHp <= 0;

            setGameState((prev) => ({
              ...prev,
              gold: isDead ? prev.gold + 150 : prev.gold,
              boss: {
                ...prev.boss,
                hp: newHp,
                dead: isDead,
              },
              quests: {
                ...prev.quests,
                bossDefeated: isDead ? true : prev.quests.bossDefeated,
              },
              isVictory: isDead,
            }));

            if (isDead) {
              boss.visible = false;
              soundEngine.playVictory();
              confetti({ particleCount: 150, spread: 80, origin: { y: 0.6 } });
              onShowToast('🎉 마왕 말라코르를 처단하고 왕국의 평화를 되찾았습니다!');
              createItemDrop(boss.position.x, boss.position.z, 'gold');
            } else {
              onShowToast(`마왕에게 ${dmg} 데미지 적중! (남은 체력: ${newHp})`);
            }
          }
        }
      }
    }

    // 6. INTERACTION LOGIC
    function executeInteract() {
      const curState = stateRef.current;
      const raycaster = new THREE.Raycaster();
      raycaster.setFromCamera(new THREE.Vector2(0, 0), camera);

      const interactables = [...npcs, ...portals, ...chests];
      const hits = raycaster.intersectObjects(interactables, true);

      if (hits.length > 0 && hits[0].distance < 4.5) {
        let obj: THREE.Object3D | null = hits[0].object;
        while (
          obj &&
          obj.parent &&
          !obj.userData.role &&
          !obj.userData.isPortal &&
          !obj.userData.isChest
        ) {
          obj = obj.parent;
        }

        if (!obj) return;

        if (obj.userData.isPortal) {
          soundEngine.playPortalHum();
          const targetLoc: LocationType = obj.userData.targetLoc;

          if (targetLoc === 'castle' && !curState.hasKey) {
            onShowToast('성문이 굳게 닫혀 있습니다! 마을 촌장 엘드린에게 열쇠를 받으세요.');
            return;
          }

          setGameState((prev) => ({
            ...prev,
            currentLocation: targetLoc,
            quests: {
              ...prev.quests,
              visitedShop: targetLoc === 'shop' ? true : prev.quests.visitedShop,
              unlockedCastle: targetLoc === 'castle' ? true : prev.quests.unlockedCastle,
            },
          }));

          cameraYawObject.position.set(0, 1.6, 5);
          buildMap(targetLoc);
          onShowToast(`${obj.userData.promptText} 완료`);
        } else if (obj.userData.isChest) {
          if (!obj.userData.opened) {
            soundEngine.playPickup();
            obj.userData.opened = true;
            if (obj.userData.lid) {
              obj.userData.lid.rotation.x = -Math.PI / 3;
            }
            const goldEarned = obj.userData.gold || 50;
            setGameState((prev) => ({
              ...prev,
              gold: prev.gold + goldEarned,
            }));
            onShowToast(`보물상자 개방! +${goldEarned} 골드 획득`);
          }
        } else if (obj.userData.role) {
          // Open Dialogue
          const role = obj.userData.role;
          const name = obj.userData.name || '주민';
          const dialogues = obj.userData.dialogue || ['안녕하세요!'];

          if (role === 'chief') {
            setGameState((prev) => ({
              ...prev,
              quests: { ...prev.quests, talkChief: true },
            }));

            onOpenDialogue({
              name,
              role,
              dialogues,
              options: [
                {
                  text: '🔑 왕궁 열쇠 요청하기',
                  action: () => {
                    setGameState((prev) => ({
                      ...prev,
                      hasKey: true,
                    }));
                    soundEngine.playQuestComplete();
                    onShowToast('촌장 엘드린으로부터 왕궁 열쇠를 받았습니다!');
                  },
                },
              ],
            });
          } else if (role === 'merchant') {
            onOpenDialogue({
              name,
              role,
              dialogues,
              options: [
                {
                  text: '🔫 플린트록 탄약 10발 구매 (20 골드)',
                  action: () => {
                    if (stateRef.current.gold >= 20) {
                      setGameState((prev) => ({
                        ...prev,
                        gold: prev.gold - 20,
                        ammo: prev.ammo + 10,
                      }));
                      soundEngine.playPickup();
                      onShowToast('권총 탄약 10발을 구매했습니다!');
                    } else {
                      onShowToast('골드가 부족합니다!');
                    }
                  },
                },
                {
                  text: '⚔️ 검 제련 강화 (+15 공격력) (40 골드)',
                  action: () => {
                    if (stateRef.current.gold >= 40) {
                      setGameState((prev) => ({
                        ...prev,
                        gold: prev.gold - 40,
                        swordDamage: prev.swordDamage + 15,
                        quests: { ...prev.quests, upgradedGear: true },
                      }));
                      soundEngine.playQuestComplete();
                      onShowToast('검을 강화했습니다! 공격력이 15 증가합니다.');
                    } else {
                      onShowToast('골드가 부족합니다!');
                    }
                  },
                },
                {
                  text: '🧪 체력 회복 물약 구매 (+40 HP) (25 골드)',
                  action: () => {
                    if (stateRef.current.gold >= 25) {
                      setGameState((prev) => ({
                        ...prev,
                        gold: prev.gold - 25,
                        hp: Math.min(prev.maxHp, prev.hp + 40),
                      }));
                      soundEngine.playPickup();
                      onShowToast('체력 40이 회복되었습니다!');
                    } else {
                      onShowToast('골드가 부족합니다!');
                    }
                  },
                },
              ],
            });
          } else {
            onOpenDialogue({
              name,
              role,
              dialogues,
            });
          }
        }
      }
    }

    // 7. COLLECT DROPPED ITEMS
    function executeCollect() {
      const pos = cameraYawObject.position;
      let collectedAny = false;
      for (let i = items.length - 1; i >= 0; i--) {
        const item = items[i];
        if (pos.distanceTo(item.position) < 3.2) {
          collectedAny = true;
          soundEngine.playPickup();
          const t = item.userData.type;
          if (t === 'health') {
            setGameState((prev) => ({
              ...prev,
              hp: Math.min(prev.maxHp, prev.hp + 35),
            }));
            onShowToast('체력 물약 수집 (+35 HP)');
          } else if (t === 'ammo') {
            setGameState((prev) => ({
              ...prev,
              ammo: prev.ammo + 8,
            }));
            onShowToast('탄약 상자 수집 (+8발)');
          } else {
            setGameState((prev) => ({
              ...prev,
              gold: prev.gold + 40,
            }));
            onShowToast('골드 수집 (+40 골드)');
          }
          mapContainer.remove(item);
          items.splice(i, 1);
        }
      }
      if (!collectedAny) {
        onShowToast('주변에 수집할 아이템이 없습니다.');
      }
    }

    // 8. MINIMAP DRAWING FUNCTION (Fixes ReferenceError: drawMinimap is not defined!)
    function drawMinimap() {
      const canvas = document.getElementById('minimap-canvas') as HTMLCanvasElement | null;
      if (!canvas) return;
      minimapCanvasRef.current = canvas;

      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const w = canvas.width;
      const h = canvas.height;
      ctx.clearRect(0, 0, w, h);

      // Background
      ctx.fillStyle = 'rgba(15, 23, 42, 0.9)';
      ctx.fillRect(0, 0, w, h);

      // Radar circles
      ctx.strokeStyle = 'rgba(71, 85, 105, 0.4)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(w / 2, h / 2, 25, 0, Math.PI * 2);
      ctx.arc(w / 2, h / 2, 50, 0, Math.PI * 2);
      ctx.stroke();

      const cx = w / 2;
      const cz = h / 2;
      const scale = 2.4; // 1 meter = 2.4 pixels on radar
      const playerPos = cameraYawObject.position;

      // Draw Portals (Cyan rings)
      portals.forEach((p) => {
        const dx = (p.position.x - playerPos.x) * scale;
        const dz = (p.position.z - playerPos.z) * scale;
        if (Math.abs(dx) < w / 2 && Math.abs(dz) < h / 2) {
          ctx.strokeStyle = '#38bdf8';
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.arc(cx + dx, cz + dz, 4, 0, Math.PI * 2);
          ctx.stroke();
        }
      });

      // Draw Chests (Orange dots)
      chests.forEach((c) => {
        const dx = (c.position.x - playerPos.x) * scale;
        const dz = (c.position.z - playerPos.z) * scale;
        if (Math.abs(dx) < w / 2 && Math.abs(dz) < h / 2) {
          ctx.fillStyle = c.userData.opened ? '#78350f' : '#f59e0b';
          ctx.beginPath();
          ctx.arc(cx + dx, cz + dz, 3.5, 0, Math.PI * 2);
          ctx.fill();
        }
      });

      // Draw Items (Red/Blue dots)
      items.forEach((it) => {
        const dx = (it.position.x - playerPos.x) * scale;
        const dz = (it.position.z - playerPos.z) * scale;
        if (Math.abs(dx) < w / 2 && Math.abs(dz) < h / 2) {
          ctx.fillStyle = it.userData.type === 'health' ? '#ef4444' : '#38bdf8';
          ctx.beginPath();
          ctx.arc(cx + dx, cz + dz, 3, 0, Math.PI * 2);
          ctx.fill();
        }
      });

      // Draw NPCs (Elder/Merchant/Boss)
      npcs.forEach((npc) => {
        const dx = (npc.position.x - playerPos.x) * scale;
        const dz = (npc.position.z - playerPos.z) * scale;
        if (Math.abs(dx) < w / 2 && Math.abs(dz) < h / 2) {
          if (npc.userData.role === 'boss') {
            ctx.fillStyle = '#ef4444';
            ctx.beginPath();
            ctx.arc(cx + dx, cz + dz, 6, 0, Math.PI * 2);
            ctx.fill();
          } else {
            ctx.fillStyle = npc.userData.role === 'chief' ? '#fbbf24' : '#10b981';
            ctx.beginPath();
            ctx.arc(cx + dx, cz + dz, 4, 0, Math.PI * 2);
            ctx.fill();
          }
        }
      });

      // Player Arrow at center
      ctx.save();
      ctx.translate(cx, cz);
      ctx.rotate(-yaw);
      ctx.fillStyle = '#f8fafc';
      ctx.beginPath();
      ctx.moveTo(0, -6);
      ctx.lineTo(4, 5);
      ctx.lineTo(0, 3);
      ctx.lineTo(-4, 5);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    }

    // 9. ANIMATION LOOP
    let animFrameId: number;
    function animate() {
      animFrameId = requestAnimationFrame(animate);

      const time = performance.now();
      const delta = Math.min((time - prevTime) / 1000, 0.1);
      prevTime = time;

      // Handle weapon switch request
      if (actionTriggerRef.current.switchWeapon !== null) {
        const newWep = actionTriggerRef.current.switchWeapon as 1 | 2;
        actionTriggerRef.current.switchWeapon = null;
        setGameState((prev) => ({ ...prev, weapon: newWep }));
        if (newWep === 1) {
          swordGroup.visible = true;
          gunGroup.visible = false;
        } else {
          swordGroup.visible = false;
          gunGroup.visible = true;
        }
      }

      // Handle attacks, interacts, collects
      if (actionTriggerRef.current.attackRequested) {
        actionTriggerRef.current.attackRequested = false;
        executeAttack();
      }
      if (actionTriggerRef.current.interactRequested) {
        actionTriggerRef.current.interactRequested = false;
        executeInteract();
      }
      if (actionTriggerRef.current.collectRequested) {
        actionTriggerRef.current.collectRequested = false;
        executeCollect();
      }

      // Sync active weapon visibility with gameState
      swordGroup.visible = stateRef.current.weapon === 1;
      gunGroup.visible = stateRef.current.weapon === 2;

      // Apply Yaw / Pitch to Camera Rig
      cameraYawObject.rotation.y = yaw;
      cameraPitchObject.rotation.x = pitch;

      // Movement Calculations
      if (!isDialogueOpenRef.current) {
        velocity.x -= velocity.x * 10.0 * delta;
        velocity.z -= velocity.z * 10.0 * delta;

        const isFwd = keysRef.current['KeyW'] || false;
        const isBwd = keysRef.current['KeyS'] || false;
        const isLft = keysRef.current['KeyA'] || false;
        const isRgt = keysRef.current['KeyD'] || false;

        moveDir.z = Number(isFwd) - Number(isBwd);
        moveDir.x = Number(isRgt) - Number(isLft);
        moveDir.normalize();

        const curSpeed = isSprinting ? 22.0 : 12.0;
        const targetFOV = isSprinting && isFwd ? 84 : 75;
        camera.fov += (targetFOV - camera.fov) * 0.1;
        camera.updateProjectionMatrix();

        if (isFwd || isBwd) velocity.z -= moveDir.z * curSpeed * delta;
        if (isLft || isRgt) velocity.x -= moveDir.x * curSpeed * delta;

        // Apply local translation based on yaw
        const forwardVector = new THREE.Vector3(0, 0, -1).applyAxisAngle(new THREE.Vector3(0, 1, 0), yaw);
        const rightVector = new THREE.Vector3(1, 0, 0).applyAxisAngle(new THREE.Vector3(0, 1, 0), yaw);

        cameraYawObject.position.addScaledVector(forwardVector, -velocity.z * delta);
        cameraYawObject.position.addScaledVector(rightVector, velocity.x * delta);

        // Head bobbing & footsteps
        if (isFwd || isBwd || isLft || isRgt) {
          const bobSpeed = isSprinting ? 16 : 10;
          const bobHeight = isSprinting ? 0.08 : 0.05;
          headBobTimer += delta * bobSpeed;
          cameraPitchObject.position.y = Math.sin(headBobTimer) * bobHeight;

          if (Math.sin(headBobTimer) > 0.98) {
            soundEngine.playFootstep(isSprinting);
          }
        } else {
          cameraPitchObject.position.y = 0;
        }
      }

      // Raycasting for Interaction Crosshair
      const raycaster = new THREE.Raycaster();
      raycaster.setFromCamera(new THREE.Vector2(0, 0), camera);
      const interactables = [...npcs, ...portals, ...chests];
      const hits = raycaster.intersectObjects(interactables, true);

      if (hits.length > 0 && hits[0].distance < 4.5) {
        let obj: THREE.Object3D | null = hits[0].object;
        while (
          obj &&
          obj.parent &&
          !obj.userData.role &&
          !obj.userData.isPortal &&
          !obj.userData.isChest
        ) {
          obj = obj.parent;
        }

        if (obj) {
          if (obj.userData.role) {
            setCurrentTarget({
              type: 'npc',
              name: obj.userData.name,
              promptText: `${obj.userData.name}와 대화하기 (E)`,
            });
          } else if (obj.userData.isPortal) {
            setCurrentTarget({
              type: 'portal',
              name: '포탈',
              promptText: obj.userData.promptText,
            });
          } else if (obj.userData.isChest) {
            setCurrentTarget({
              type: 'chest',
              name: '보물상자',
              promptText: obj.userData.opened ? '열린 보물상자' : '보물상자 열기 (E)',
            });
          }
        }
      } else {
        setCurrentTarget(null);
      }

      // NPC Animations & Boss AI
      const pPos = cameraYawObject.position;
      npcs.forEach((npc) => {
        npc.userData.animTimer = (npc.userData.animTimer || 0) + delta;
        const t = npc.userData.animTimer;

        if (npc.userData.head) {
          npc.userData.head.position.y =
            (npc.userData.role === 'boss' ? 3.0 : 1.6) + Math.sin(t * 2) * 0.02;
          const dist = pPos.distanceTo(npc.position);
          if (dist < 9.0) {
            npc.userData.head.lookAt(pPos.x, npc.userData.head.position.y, pPos.z);
          }
        }

        if (npc.userData.role === 'boss' && !stateRef.current.boss.dead) {
          if (npc.userData.wingL && npc.userData.wingR) {
            npc.userData.wingL.rotation.y = Math.sin(t * 3.5) * 0.35;
            npc.userData.wingR.rotation.y = -Math.sin(t * 3.5) * 0.35;
          }

          const distToPlayer = pPos.distanceTo(npc.position);

          // Boss chase player if within 16m
          if (distToPlayer > 3.0 && distToPlayer < 16.0) {
            const dir = new THREE.Vector3().subVectors(pPos, npc.position).normalize();
            npc.position.x += dir.x * 2.8 * delta;
            npc.position.z += dir.z * 2.8 * delta;
            npc.lookAt(pPos.x, npc.position.y, pPos.z);
          }

          // Boss Attack
          if (
            distToPlayer <= 3.8 &&
            !stateRef.current.boss.isAttacking &&
            stateRef.current.hp > 0
          ) {
            setGameState((prev) => ({
              ...prev,
              boss: { ...prev.boss, isAttacking: true },
            }));

            soundEngine.playPlayerHurt();
            onDamageScreen();

            setGameState((prev) => {
              const newHp = Math.max(0, prev.hp - 20);
              const isOver = newHp <= 0;
              if (isOver) {
                soundEngine.playGameOver();
              }
              return {
                ...prev,
                hp: newHp,
                isGameOver: isOver,
              };
            });

            setTimeout(() => {
              setGameState((prev) => ({
                ...prev,
                boss: { ...prev.boss, isAttacking: false },
              }));
            }, 1400);
          }
        }
      });

      // Rotate Portals
      portals.forEach((p) => {
        p.rotation.z += delta * 0.9;
      });

      // Rotate Item Drops
      items.forEach((it) => {
        it.rotation.y += delta * 2;
        it.position.y = 0.35 + Math.sin(time * 0.004) * 0.08;
      });

      // Update Minimap (Called safely on every frame)
      drawMinimap();

      renderer.render(scene, camera);
    }

    animate();

    // 10. RESIZE LISTENER
    const handleResize = () => {
      if (!container) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animFrameId);
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      container.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mouseup', handleMouseUp);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
    };
  }, []);

  return (
    <div
      ref={containerRef}
      id="canvas-container"
      className="w-full h-full absolute inset-0 cursor-crosshair z-0"
    />
  );
};
