import React, { useState } from 'react';
import { DialogueData } from '../types';
import { UserCheck, ShieldAlert, Sparkles, X, ChevronRight } from 'lucide-react';

interface DialogueModalProps {
  dialogue: DialogueData;
  onClose: () => void;
}

export const DialogueModal: React.FC<DialogueModalProps> = ({ dialogue, onClose }) => {
  const [pageIndex, setPageIndex] = useState(0);

  const isLastPage = pageIndex >= dialogue.dialogues.length - 1;

  const handleNext = () => {
    if (!isLastPage) {
      setPageIndex((p) => p + 1);
    }
  };

  const getRoleIcon = () => {
    if (dialogue.role === 'chief') return <Sparkles className="w-5 h-5 text-amber-400" />;
    if (dialogue.role === 'guard') return <ShieldAlert className="w-5 h-5 text-red-400" />;
    return <UserCheck className="w-5 h-5 text-emerald-400" />;
  };

  return (
    <div className="fixed inset-0 z-40 flex items-end justify-center pb-10 sm:pb-16 pointer-events-none p-4">
      <div
        id="dialogue-box"
        className="w-full max-w-2xl bg-slate-950/95 backdrop-blur-xl border border-amber-500/50 rounded-2xl p-6 shadow-2xl space-y-4 pointer-events-auto transition-all animate-in fade-in duration-200"
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-amber-500/10 border border-amber-500/30">
              {getRoleIcon()}
            </div>
            <div>
              <h3 id="npc-name" className="text-base sm:text-lg font-bold text-amber-300">
                {dialogue.name}
              </h3>
              <span className="text-[11px] text-slate-400">
                {dialogue.role === 'chief'
                  ? '마을 지도자'
                  : dialogue.role === 'merchant'
                  ? '무기 상인'
                  : '왕실 근위대'}
              </span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Text Body */}
        <p
          id="npc-text"
          className="text-slate-200 text-sm sm:text-base leading-relaxed min-h-[54px] bg-slate-900/60 p-3.5 rounded-xl border border-slate-800/80"
        >
          {dialogue.dialogues[pageIndex]}
        </p>

        {/* Options & Progression Buttons */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-800/80">
          <div id="dialogue-options" className="flex flex-wrap gap-2">
            {dialogue.options &&
              dialogue.options.map((opt, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    opt.action();
                    onClose();
                  }}
                  className="px-4 py-2 bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-white font-semibold rounded-xl text-xs sm:text-sm shadow-md transition-transform active:scale-95 cursor-pointer flex items-center gap-1.5"
                >
                  {opt.text}
                </button>
              ))}
          </div>

          <div className="flex items-center gap-2 ml-auto">
            {!isLastPage ? (
              <button
                onClick={handleNext}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-amber-300 font-semibold rounded-xl text-xs sm:text-sm border border-slate-700 flex items-center gap-1 cursor-pointer transition-colors"
              >
                다음 <ChevronRight className="w-4 h-4" />
              </button>
            ) : (
              <button
                onClick={onClose}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-medium rounded-xl text-xs sm:text-sm border border-slate-700 cursor-pointer transition-colors"
              >
                대화 종료
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
