import React from 'react';
import { Play, RotateCcw, Trophy, Skull, Swords, Compass, Sparkles } from 'lucide-react';

interface StartScreenProps {
  isStarted: boolean;
  onStart: () => void;
  isGameOver: boolean;
  onRespawn: () => void;
  isVictory: boolean;
  onRestart: () => void;
  isLocked: boolean;
  onResume: () => void;
  isDialogueOpen: boolean;
}

export const StartScreen: React.FC<StartScreenProps> = ({
  isStarted,
  onStart,
  isGameOver,
  onRespawn,
  isVictory,
  onRestart,
  isLocked,
  onResume,
  isDialogueOpen,
}) => {
  // Game Over View
  if (isGameOver) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md p-4">
        <div className="max-w-md w-full bg-slate-950 border border-red-800/60 rounded-2xl p-6 sm:p-8 text-center space-y-6 shadow-2xl">
          <div className="inline-flex p-4 rounded-full bg-red-950/80 border border-red-600/40 text-red-500">
            <Skull className="w-12 h-12 animate-pulse" />
          </div>
          <div className="space-y-2">
            <h2 className="text-3xl font-extrabold text-red-500 tracking-tight">용사의 패배</h2>
            <p className="text-slate-400 text-sm leading-relaxed">
              마왕 말라코르의 강력한 암흑 기운에 쓰러졌습니다. 재정비 후 다시 도전하십시오!
            </p>
          </div>
          <button
            onClick={onRespawn}
            className="w-full py-3.5 bg-gradient-to-r from-red-700 to-red-600 hover:from-red-600 hover:to-red-500 text-white font-bold rounded-xl shadow-lg transition-transform active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
          >
            <RotateCcw className="w-5 h-5" /> 마을 광장에서 부활하기
          </button>
        </div>
      </div>
    );
  }

  // Victory View
  if (isVictory) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4">
        <div className="max-w-md w-full bg-slate-950 border border-amber-500/60 rounded-2xl p-6 sm:p-8 text-center space-y-6 shadow-2xl">
          <div className="inline-flex p-4 rounded-full bg-amber-500/10 border border-amber-500/40 text-amber-400">
            <Trophy className="w-12 h-12" />
          </div>
          <div className="space-y-2">
            <h2 className="text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-amber-400 to-amber-600 tracking-tight">
              왕국의 평화 구원!
            </h2>
            <p className="text-slate-300 text-sm leading-relaxed">
              마왕 말라코르를 성공적으로 처단하고 마을 사람들에게 자유를 되찾아주었습니다!
            </p>
          </div>
          <div className="p-4 bg-slate-900/80 rounded-xl border border-slate-800 text-xs text-amber-300 space-y-1">
            <p className="font-bold flex items-center justify-center gap-1.5">
              <Sparkles className="w-4 h-4" /> 모든 주요 퀘스트 완료 달성
            </p>
            <p className="text-slate-400">보상: 명예의 용사 칭호 및 대량의 전리품</p>
          </div>
          <button
            onClick={onRestart}
            className="w-full py-3.5 bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-slate-950 font-extrabold rounded-xl shadow-lg transition-transform active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
          >
            <RotateCcw className="w-5 h-5" /> 새로운 여정 시작하기
          </button>
        </div>
      </div>
    );
  }

  // Initial Game Start Modal
  if (!isStarted) {
    return (
      <div
        id="start-screen"
        className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/90 backdrop-blur-md text-white p-4 overflow-y-auto"
      >
        <div className="max-w-xl w-full text-center space-y-6 bg-slate-900/90 border border-amber-500/40 p-6 sm:p-8 rounded-2xl shadow-2xl my-auto">
          <div className="inline-flex p-3 rounded-2xl bg-amber-500/10 text-amber-400 border border-amber-500/30">
            <Compass className="w-10 h-10" />
          </div>

          <div className="space-y-2">
            <h1 className="text-3xl sm:text-4xl font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-amber-400 to-amber-500">
              몰락한 왕의 마을
            </h1>
            <p className="text-slate-300 text-xs sm:text-sm leading-relaxed">
              1인칭 3D 중세 판타지 액션 RPG. 마을 주민들과 대화하고 무기를 강화하여 왕궁의 마왕을 처단하세요!
            </p>
          </div>

          {/* Key Bindings Table */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-left bg-slate-950/70 p-4 rounded-xl text-xs text-slate-300 border border-slate-800">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 bg-slate-800 rounded text-amber-300 font-bold border border-slate-700">W A S D</span>
              <span>이동 (W 2번: 달리기)</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 bg-slate-800 rounded text-amber-300 font-bold border border-slate-700">마우스</span>
              <span>시점 회전 (드래그/조준)</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 bg-slate-800 rounded text-amber-300 font-bold border border-slate-700">클릭 / SPACE</span>
              <span>공격 (검 / 권총)</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 bg-slate-800 rounded text-amber-300 font-bold border border-slate-700">E</span>
              <span>상호작용 / 포탈 / 상자</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 bg-slate-800 rounded text-amber-300 font-bold border border-slate-700">Q</span>
              <span>주변 드롭 아이템 수집</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 bg-slate-800 rounded text-amber-300 font-bold border border-slate-700">1 / 2</span>
              <span>무기 교체 (검 / 권총)</span>
            </div>
          </div>

          <button
            id="btn-start"
            onClick={onStart}
            className="w-full py-4 bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-slate-950 font-black rounded-xl shadow-xl transition-all transform active:scale-98 flex items-center justify-center gap-2 text-base sm:text-lg cursor-pointer"
          >
            <Play className="w-5 h-5 fill-slate-950" /> 왕국 입장하기 (게임 시작)
          </button>
        </div>
      </div>
    );
  }

  // Resume Overlay when paused or unlocked (and not in dialogue)
  if (!isLocked && !isDialogueOpen) {
    return (
      <div
        onClick={onResume}
        className="fixed bottom-24 left-1/2 -translate-x-1/2 z-30 bg-slate-950/85 backdrop-blur-md px-6 py-3 rounded-full border border-amber-500/50 text-amber-300 text-xs sm:text-sm font-semibold shadow-2xl flex items-center gap-2 cursor-pointer animate-pulse hover:bg-slate-900"
      >
        <Swords className="w-4 h-4" />
        <span>화면을 클릭하여 시점 조작 활성화</span>
      </div>
    );
  }

  return null;
};
