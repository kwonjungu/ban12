import React from 'react';
import { GameState, TargetInfo } from '../types';
import {
  Heart,
  Coins,
  Key,
  MapPin,
  Skull,
  Scroll,
  CheckCircle2,
  Circle,
  Shield,
  Crosshair,
} from 'lucide-react';

interface HUDProps {
  gameState: GameState;
  currentTarget: TargetInfo | null;
  onEquipWeapon: (wep: 1 | 2) => void;
  showFlash: boolean;
  showDamage: boolean;
}

export const HUD: React.FC<HUDProps> = ({
  gameState,
  currentTarget,
  onEquipWeapon,
  showFlash,
  showDamage,
}) => {
  const { hp, maxHp, gold, hasKey, weapon, ammo, maxAmmo, currentLocation, quests, boss } =
    gameState;

  const locationName =
    currentLocation === 'village'
      ? '마을 광장'
      : currentLocation === 'shop'
      ? '무기점'
      : currentLocation === 'castle'
      ? '왕궁 전당'
      : '마왕의 둥지';

  return (
    <>
      {/* Damage Overlay */}
      <div
        id="damage-overlay"
        className={`fixed inset-0 pointer-events-none z-10 transition-opacity duration-200 ${
          showDamage ? 'opacity-100' : 'opacity-0'
        }`}
        style={{
          background: 'radial-gradient(circle, transparent 40%, rgba(220, 38, 38, 0.6) 100%)',
        }}
      />

      {/* Muzzle Flash Overlay */}
      <div
        id="flash-overlay"
        className={`fixed inset-0 pointer-events-none z-10 transition-opacity duration-75 bg-amber-200/20 ${
          showFlash ? 'opacity-100' : 'opacity-0'
        }`}
      />

      {/* Crosshair */}
      <div
        id="crosshair"
        className={`fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full pointer-events-none z-20 transition-all duration-150 flex items-center justify-center ${
          currentTarget
            ? 'w-6 h-6 border-2 border-amber-400 bg-amber-400/20 scale-125'
            : 'w-2 h-2 border border-white/80 bg-white/40'
        }`}
      >
        {currentTarget && <div className="w-1 h-1 bg-amber-300 rounded-full animate-ping" />}
      </div>

      {/* Main HUD Layer */}
      <div id="hud" className="fixed inset-0 pointer-events-none z-20 flex flex-col justify-between p-4 md:p-6">
        {/* Top Bar */}
        <div className="flex items-start justify-between gap-4">
          {/* Hero Stats */}
          <div
            id="hero-stats-panel"
            className="bg-slate-950/80 backdrop-blur-md border border-slate-700/70 p-4 rounded-xl space-y-3 w-64 md:w-72 pointer-events-auto shadow-2xl"
          >
            <div className="flex items-center justify-between text-xs text-slate-300 font-semibold tracking-wider">
              <span className="flex items-center gap-1.5 text-red-400">
                <Heart className="w-4 h-4 fill-red-500 text-red-500" /> 체력
              </span>
              <span id="hp-text" className="text-white font-mono font-bold">
                {hp} / {maxHp}
              </span>
            </div>
            <div className="w-full bg-slate-900 h-2.5 rounded-full overflow-hidden p-0.5 border border-slate-700">
              <div
                id="hp-bar"
                className="h-full bg-gradient-to-r from-red-600 via-amber-500 to-emerald-500 rounded-full transition-all duration-300"
                style={{ width: `${Math.max(0, (hp / maxHp) * 100)}%` }}
              />
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-xs text-slate-300">
              <div className="flex items-center gap-1.5">
                <Coins className="w-4 h-4 text-amber-400" />
                <span>
                  골드: <strong id="gold-val" className="text-amber-300 font-mono text-sm">{gold}</strong>
                </span>
              </div>
              <div className="flex items-center gap-1.5">
                <Key className={`w-4 h-4 ${hasKey ? 'text-amber-400' : 'text-slate-500'}`} />
                <span id="key-status" className={hasKey ? 'text-amber-300 font-bold' : 'text-slate-500'}>
                  {hasKey ? '열쇠 보유' : '열쇠 없음'}
                </span>
              </div>
            </div>
          </div>

          {/* Location Badge & Boss Health Bar */}
          <div className="flex flex-col items-center gap-2 flex-1 max-w-md mx-auto">
            <div
              id="location-badge"
              className="bg-slate-950/80 backdrop-blur-md px-5 py-2 rounded-full border border-amber-500/40 text-amber-300 font-bold text-xs md:text-sm tracking-wide shadow-xl flex items-center gap-2"
            >
              <MapPin className="w-4 h-4 text-amber-400" />
              <span id="location-name">{locationName}</span>
            </div>

            {/* Boss Bar in boss lair */}
            {boss.active && !boss.dead && (
              <div
                id="boss-hp-container"
                className="bg-slate-950/90 backdrop-blur-md p-3 rounded-xl w-full border border-red-600/60 shadow-2xl animate-pulse"
              >
                <div className="flex justify-between text-xs text-red-400 font-bold mb-1 uppercase tracking-wider">
                  <span className="flex items-center gap-1.5">
                    <Skull className="w-4 h-4 text-red-500" /> 마왕 말라코르
                  </span>
                  <span id="boss-hp-text" className="font-mono text-white">
                    {boss.hp} / {boss.maxHp}
                  </span>
                </div>
                <div className="w-full bg-slate-900 h-3 rounded-full overflow-hidden p-0.5 border border-red-950">
                  <div
                    id="boss-hp-bar"
                    className="h-full bg-gradient-to-r from-red-800 via-red-600 to-red-400 rounded-full transition-all duration-200"
                    style={{ width: `${Math.max(0, (boss.hp / boss.maxHp) * 100)}%` }}
                  />
                </div>
              </div>
            )}
          </div>

          {/* Quests Tracker */}
          <div
            id="quest-panel"
            className="bg-slate-950/80 backdrop-blur-md border border-slate-700/70 p-4 rounded-xl w-64 md:w-72 space-y-2.5 pointer-events-auto shadow-2xl hidden sm:block"
          >
            <div className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-2 border-b border-slate-800 pb-2">
              <Scroll className="w-4 h-4" /> 주요 퀘스트
            </div>
            <ul id="quest-list" className="text-xs space-y-2">
              <li
                id="q1"
                className={`flex items-start gap-2 transition-colors ${
                  quests.talkChief ? 'text-emerald-400' : 'text-amber-200 font-medium'
                }`}
              >
                {quests.talkChief ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                ) : (
                  <Circle className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                )}
                <span>촌장 엘드린과 대화 및 열쇠 획득</span>
              </li>
              <li
                id="q2"
                className={`flex items-start gap-2 transition-colors ${
                  quests.visitedShop ? 'text-emerald-400' : 'text-slate-400'
                }`}
              >
                {quests.visitedShop ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                ) : (
                  <Circle className="w-3.5 h-3.5 text-slate-500 shrink-0 mt-0.5" />
                )}
                <span>무기점 방문 및 장비 정비</span>
              </li>
              <li
                id="q3"
                className={`flex items-start gap-2 transition-colors ${
                  quests.unlockedCastle ? 'text-emerald-400' : 'text-slate-400'
                }`}
              >
                {quests.unlockedCastle ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                ) : (
                  <Circle className="w-3.5 h-3.5 text-slate-500 shrink-0 mt-0.5" />
                )}
                <span>왕궁 성문 개방 및 전당 진입</span>
              </li>
              <li
                id="q4"
                className={`flex items-start gap-2 transition-colors ${
                  quests.bossDefeated ? 'text-emerald-400 font-bold' : 'text-slate-400'
                }`}
              >
                {quests.bossDefeated ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                ) : (
                  <Circle className="w-3.5 h-3.5 text-slate-500 shrink-0 mt-0.5" />
                )}
                <span>마왕 말라코르 처단하기</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Center Target Prompt */}
        {currentTarget && (
          <div
            id="interaction-prompt"
            className="self-center bg-slate-950/90 backdrop-blur-md px-6 py-2.5 rounded-full border border-amber-400/60 text-amber-200 text-xs md:text-sm font-semibold shadow-2xl flex items-center gap-2.5 animate-bounce pointer-events-auto"
          >
            <span className="px-2 py-0.5 bg-amber-500/20 border border-amber-400 rounded text-amber-300 font-bold text-xs">
              E
            </span>
            <span id="prompt-text">{currentTarget.promptText}</span>
          </div>
        )}

        {/* Bottom HUD: Minimap, Hotkeys & Weapons */}
        <div className="flex items-end justify-between gap-4">
          {/* Radar / Minimap */}
          <div
            id="minimap-container"
            className="bg-slate-950/80 backdrop-blur-md p-2 rounded-2xl border border-slate-700/70 overflow-hidden pointer-events-auto shadow-2xl"
          >
            <canvas id="minimap-canvas" width="130" height="130" className="rounded-xl bg-slate-950" />
            <div className="flex justify-between px-1 pt-1.5 text-[10px] text-slate-400">
              <span className="text-amber-400 font-medium">레이더</span>
              <span>🟢주민 🔴마왕 🔵포탈</span>
            </div>
          </div>

          {/* Quick Keys Guide */}
          <div className="hidden md:flex items-center gap-3 bg-slate-950/75 backdrop-blur-md px-4 py-2 rounded-xl border border-slate-800 text-[11px] text-slate-400">
            <span><strong className="text-slate-200">WASD</strong> 이동</span>
            <span><strong className="text-slate-200">Shift</strong> 달리기</span>
            <span><strong className="text-slate-200">클릭/스페이스</strong> 공격</span>
            <span><strong className="text-slate-200">E</strong> 상호작용</span>
            <span><strong className="text-slate-200">Q</strong> 루팅</span>
          </div>

          {/* Weapon Slots & Ammo */}
          <div
            id="weapon-hud"
            className="bg-slate-950/85 backdrop-blur-md p-3 rounded-2xl flex items-center gap-3 pointer-events-auto border border-slate-700/80 shadow-2xl"
          >
            <button
              id="slot-1"
              onClick={() => onEquipWeapon(1)}
              className={`relative px-4 py-2.5 rounded-xl border flex flex-col items-center transition-all cursor-pointer ${
                weapon === 1
                  ? 'border-amber-500 bg-amber-500/20 text-amber-300 shadow-md shadow-amber-500/20'
                  : 'border-slate-800 bg-slate-900/60 text-slate-500 hover:text-slate-300'
              }`}
            >
              <span className="absolute top-1 left-2 text-[10px] font-bold text-slate-400">1</span>
              <Shield className="w-5 h-5 my-1" />
              <span className="text-[11px] font-bold">검 (+{gameState.swordDamage})</span>
            </button>

            <button
              id="slot-2"
              onClick={() => onEquipWeapon(2)}
              className={`relative px-4 py-2.5 rounded-xl border flex flex-col items-center transition-all cursor-pointer ${
                weapon === 2
                  ? 'border-amber-500 bg-amber-500/20 text-amber-300 shadow-md shadow-amber-500/20'
                  : 'border-slate-800 bg-slate-900/60 text-slate-500 hover:text-slate-300'
              }`}
            >
              <span className="absolute top-1 left-2 text-[10px] font-bold text-slate-400">2</span>
              <Crosshair className="w-5 h-5 my-1" />
              <span className="text-[11px] font-bold">권총 (+{gameState.gunDamage})</span>
            </button>

            <div className="pl-3 border-l border-slate-800 flex flex-col text-right">
              <span className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">탄약</span>
              <span id="ammo-count" className="text-xl font-mono font-extrabold text-amber-400">
                {ammo} <span className="text-xs text-slate-500 font-normal">/ {maxAmmo}</span>
              </span>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
