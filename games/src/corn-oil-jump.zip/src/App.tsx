import React, { useEffect, useRef, useState } from 'react';
import { Sparkles, Trophy, RotateCcw, Volume2, VolumeX, ArrowUp, Compass } from 'lucide-react';

import cornMascotImg from './assets/images/corn_start_mascot_1789885525730.jpg';
import goldenOilBadgeImg from './assets/images/golden_oil_badge_1789885540749.jpg';
import kitchenStartBgImg from './assets/images/kitchen_start_bg_1789885553990.jpg';

import stage1Img from './assets/images/stage1_kitchen_1789885607866.jpg';
import stage2Img from './assets/images/stage2_pantry_1789885627574.jpg';
import stage3Img from './assets/images/stage3_bakery_1789885643836.jpg';
import stage4Img from './assets/images/stage4_garden_1789885655066.jpg';
import stage5Img from './assets/images/stage5_stewpot_1789885677411.jpg';
import stage6Img from './assets/images/stage6_sunsetsky_1789885690653.jpg';
import stage7Img from './assets/images/stage7_starlit_1789885702485.jpg';
import stage8Img from './assets/images/stage8_aurora_1789885717897.jpg';
import stage9Img from './assets/images/stage9_palace_1789885732608.jpg';
import stage10Img from './assets/images/stage10_galaxy_1789885744638.jpg';

interface UtensilType {
  name: string;
  color: string;
  accent: string;
}

interface Platform {
  x: number;
  y: number;
  width: number;
  height: number;
  type: UtensilType;
  speed: number;
  dir: number;
  hasOil: boolean;
  oilCollected: boolean;
  isRare: boolean;
  oilValue: number;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  alpha: number;
  size: number;
  color: string;
  shape?: 'circle' | 'star';
}

interface FloatingText {
  x: number;
  y: number;
  text: string;
  alpha: number;
  vy: number;
  isRare?: boolean;
}

interface Popcorn {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  rot: number;
  vRot: number;
  gravity: number;
  alpha: number;
}

interface StageTransitionEffect {
  fromStage: number;
  toStage: number;
  progress: number; // 0 to 1
  bannerTimer: number; // seconds remaining
  flashAlpha: number;
  particlesSpawned: boolean;
}

interface StageInfo {
  level: number;
  name: string;
  subTitle: string;
  threshold: number;
  imageSrc: string;
  accentColor: string;
  badgeEmoji: string;
}

const STAGES: StageInfo[] = [
  { level: 1, name: '아침 햇살 주방', subTitle: '상쾌하고 아늑한 요리의 시작', threshold: 0, imageSrc: stage1Img, accentColor: '#f59e0b', badgeEmoji: '🍳' },
  { level: 2, name: '달콤한 잼 팬트리', subTitle: '달콤한 꿀과 잼 선반', threshold: 5, imageSrc: stage2Img, accentColor: '#ec4899', badgeEmoji: '🍯' },
  { level: 3, name: '따스한 베이커리', subTitle: '갓 구운 황금빛 빵 내음', threshold: 10, imageSrc: stage3Img, accentColor: '#d97706', badgeEmoji: '🥐' },
  { level: 4, name: '싱그러운 허브 정원', subTitle: '초록빛 싱그러운 테라스', threshold: 15, imageSrc: stage4Img, accentColor: '#10b981', badgeEmoji: '🌿' },
  { level: 5, name: '보글보글 마법 스튜', subTitle: '향긋하고 따뜻한 요리 파티', threshold: 20, imageSrc: stage5Img, accentColor: '#ea580c', badgeEmoji: '🍲' },
  { level: 6, name: '솜사탕 노을 하늘', subTitle: '달콤하게 물드는 저녁 구름', threshold: 25, imageSrc: stage6Img, accentColor: '#a855f7', badgeEmoji: '☁️' },
  { level: 7, name: '별빛 은하수 테라스', subTitle: '별똥별이 쏟아지는 밤하늘', threshold: 30, imageSrc: stage7Img, accentColor: '#3b82f6', badgeEmoji: '✨' },
  { level: 8, name: '신비로운 오로라', subTitle: '하늘을 수놓는 에메랄드 빛무리', threshold: 35, imageSrc: stage8Img, accentColor: '#06b6d4', badgeEmoji: '🌌' },
  { level: 9, name: '황금 버터 궁전', subTitle: '고귀하고 눈부신 24K 전당', threshold: 40, imageSrc: stage9Img, accentColor: '#eab308', badgeEmoji: '👑' },
  { level: 10, name: '환상의 팝콘 은하수', subTitle: '최종 목적지! 팡팡 팝콘 우주', threshold: 45, imageSrc: stage10Img, accentColor: '#8b5cf6', badgeEmoji: '🍿' },
];

const UTENSIL_TYPES: UtensilType[] = [
  { name: '도마', color: '#d97706', accent: '#b45309' },
  { name: '뒤집개', color: '#94a3b8', accent: '#64748b' },
  { name: '후라이팬', color: '#334155', accent: '#1e293b' },
  { name: '트레이', color: '#f59e0b', accent: '#d97706' },
];

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // React states
  const [gameState, setGameState] = useState<'START' | 'PLAYING' | 'GAMEOVER' | 'CLEAR'>('START');
  const [score, setScore] = useState<number>(0);
  const [currentStageIdx, setCurrentStageIdx] = useState<number>(0);
  const [stageBanner, setStageBanner] = useState<{ show: boolean; stage: StageInfo } | null>(null);
  const [bestScore, setBestScore] = useState<number>(() => {
    try {
      return parseInt(localStorage.getItem('corn_oil_game_best') || '0', 10) || 0;
    } catch {
      return 0;
    }
  });
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);

  // Audio Context Ref
  const audioCtxRef = useRef<AudioContext | null>(null);

  // Image cache
  const loadedImagesRef = useRef<Map<string, HTMLImageElement>>(new Map());

  // Game Engine Refs
  const gameRef = useRef({
    gameState: 'START' as 'START' | 'PLAYING' | 'GAMEOVER' | 'CLEAR',
    score: 0,
    bestScore: 0,
    soundEnabled: true,
    currentStageIdx: 0,
    cameraY: 0,
    targetCameraY: 0,
    rareOilCounter: 0,
    platforms: [] as Platform[],
    corn: {
      x: 0,
      y: 0,
      vx: 0,
      vy: 0,
      radius: 19,
      isJumping: false,
      scaleX: 1,
      scaleY: 1,
      rotation: 0,
      standingPlatform: null as Platform | null,
    },
    particles: [] as Particle[],
    floatingTexts: [] as FloatingText[],
    popcorns: [] as Popcorn[],
    transition: null as StageTransitionEffect | null,
    animationFrameId: 0,
    lastFrameTime: performance.now(),
  });

  // Preload images into HTMLImageElement
  useEffect(() => {
    const allImages = [
      stage1Img,
      stage2Img,
      stage3Img,
      stage4Img,
      stage5Img,
      stage6Img,
      stage7Img,
      stage8Img,
      stage9Img,
      stage10Img,
      cornMascotImg,
      goldenOilBadgeImg,
      kitchenStartBgImg,
    ];

    allImages.forEach((src) => {
      const img = new Image();
      img.src = src;
      img.onload = () => {
        loadedImagesRef.current.set(src, img);
      };
    });
  }, []);

  // Synchronize refs with React state
  useEffect(() => {
    gameRef.current.gameState = gameState;
  }, [gameState]);

  useEffect(() => {
    gameRef.current.score = score;
  }, [score]);

  useEffect(() => {
    gameRef.current.bestScore = bestScore;
  }, [bestScore]);

  useEffect(() => {
    gameRef.current.soundEnabled = soundEnabled;
  }, [soundEnabled]);

  const initAudio = () => {
    if (!audioCtxRef.current) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      audioCtxRef.current = new AudioCtx();
    }
    if (audioCtxRef.current.state === 'suspended') {
      audioCtxRef.current.resume();
    }
  };

  const playSoundTone = (freq: number, type: OscillatorType, duration: number, gainVal = 0.15) => {
    if (!gameRef.current.soundEnabled || !audioCtxRef.current) return;
    try {
      const ctx = audioCtxRef.current;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      gain.gain.setValueAtTime(gainVal, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + duration);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + duration);
    } catch {
      // Audio autoplay policy fallback
    }
  };

  const playJumpSound = () => {
    playSoundTone(392, 'triangle', 0.1, 0.18); // G4
  };

  const playOilCollectSound = () => {
    playSoundTone(659.25, 'triangle', 0.12, 0.2); // E5
  };

  const playRareOilCollectSound = () => {
    playSoundTone(783.99, 'sine', 0.15, 0.22); // G5
    setTimeout(() => playSoundTone(1046.5, 'sine', 0.22, 0.25), 80); // C6
    setTimeout(() => playSoundTone(1318.5, 'triangle', 0.3, 0.22), 160); // E6
  };

  const playStageUpFanfare = () => {
    // Grand celebratory ascending chime for Stage Up transition
    const notes = [523.25, 659.25, 783.99, 1046.5, 1318.5]; // C5, E5, G5, C6, E6
    notes.forEach((freq, idx) => {
      setTimeout(() => playSoundTone(freq, 'triangle', 0.25, 0.25), idx * 80);
    });
  };

  const playGameOverSound = () => {
    playSoundTone(220, 'sawtooth', 0.25, 0.2);
    setTimeout(() => playSoundTone(164.8, 'sawtooth', 0.35, 0.25), 180);
  };

  const playVictorySound = () => {
    [523.25, 659.25, 783.99, 1046.5, 1318.5, 1567.98].forEach((freq, idx) => {
      setTimeout(() => playSoundTone(freq, 'triangle', 0.35, 0.22), idx * 110);
    });
  };

  const generatePlatforms = (count = 20, canvasWidth: number, canvasHeight: number) => {
    const { platforms } = gameRef.current;

    if (platforms.length === 0) {
      const startY = canvasHeight * 0.75;
      platforms.push({
        x: canvasWidth / 2,
        y: startY,
        width: 180,
        height: 22,
        type: UTENSIL_TYPES[0],
        speed: 0,
        dir: 1,
        hasOil: false,
        oilCollected: true,
        isRare: false,
        oilValue: 0,
      });
    }

    let lastPlat = platforms[platforms.length - 1];

    for (let i = 0; i < count; i++) {
      const type = UTENSIL_TYPES[Math.floor(Math.random() * UTENSIL_TYPES.length)];
      const gapY = 125 + Math.random() * 25;
      const nextY = lastPlat.y - gapY;

      const platWidth = Math.max(105, 155 - Math.floor(platforms.length * 0.75));
      const moveSpeed = 1.8 + Math.random() * 1.5 + Math.min(3, platforms.length * 0.05);

      gameRef.current.rareOilCounter++;
      // Guaranteed rare 5-drop oil every 4 platforms, or 25% chance
      const isRare = gameRef.current.rareOilCounter >= 4 || Math.random() < 0.25;
      if (isRare) {
        gameRef.current.rareOilCounter = 0;
      }

      platforms.push({
        x: Math.random() * (canvasWidth - platWidth - 80) + (platWidth / 2 + 40),
        y: nextY,
        width: platWidth,
        height: 20,
        type,
        speed: moveSpeed,
        dir: Math.random() < 0.5 ? 1 : -1,
        hasOil: true,
        oilCollected: false,
        isRare,
        oilValue: isRare ? 5 : 1,
      });

      lastPlat = platforms[platforms.length - 1];
    }
  };

  const resetGame = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    gameRef.current.score = 0;
    gameRef.current.currentStageIdx = 0;
    gameRef.current.cameraY = 0;
    gameRef.current.targetCameraY = 0;
    gameRef.current.rareOilCounter = 0;
    gameRef.current.platforms = [];
    gameRef.current.particles = [];
    gameRef.current.floatingTexts = [];
    gameRef.current.popcorns = [];
    gameRef.current.transition = null;

    generatePlatforms(40, canvas.width, canvas.height);

    const startPlat = gameRef.current.platforms[0];
    const { corn } = gameRef.current;
    corn.x = startPlat.x;
    corn.y = startPlat.y - corn.radius;
    corn.vx = 0;
    corn.vy = 0;
    corn.isJumping = false;
    corn.standingPlatform = startPlat;
    corn.scaleX = 1;
    corn.scaleY = 1;
    corn.rotation = 0;

    setScore(0);
    setCurrentStageIdx(0);
    setStageBanner(null);
  };

  const performJump = () => {
    if (gameRef.current.gameState !== 'PLAYING') return;
    initAudio();

    const { corn } = gameRef.current;
    if (!corn.isJumping && corn.standingPlatform) {
      corn.isJumping = true;
      corn.standingPlatform = null;
      corn.vy = -16.2;
      corn.scaleX = 0.72;
      corn.scaleY = 1.28;
      playJumpSound();
    }
  };

  const spawnOilParticles = (x: number, y: number) => {
    for (let i = 0; i < 9; i++) {
      gameRef.current.particles.push({
        x,
        y,
        vx: (Math.random() - 0.5) * 5,
        vy: (Math.random() - 0.5) * 5 - 2,
        alpha: 1.0,
        size: Math.random() * 5 + 3.5,
        color: Math.random() < 0.6 ? '#f59e0b' : '#fde047',
        shape: Math.random() < 0.4 ? 'star' : 'circle',
      });
    }

    gameRef.current.floatingTexts.push({
      x,
      y: y - 5,
      text: '+1 소중한 기름! 💧',
      alpha: 1.0,
      vy: -1.8,
      isRare: false,
    });
  };

  const spawnRareOilParticles = (x: number, y: number) => {
    for (let i = 0; i < 26; i++) {
      gameRef.current.particles.push({
        x,
        y,
        vx: (Math.random() - 0.5) * 9,
        vy: (Math.random() - 0.5) * 9 - 3,
        alpha: 1.0,
        size: Math.random() * 7 + 4,
        color: ['#f59e0b', '#fbbf24', '#fef08a', '#ffffff', '#fb7185'][Math.floor(Math.random() * 5)],
        shape: Math.random() < 0.6 ? 'star' : 'circle',
      });
    }

    gameRef.current.floatingTexts.push({
      x,
      y: y - 14,
      text: '👑 로열 골드 기름 +5 방울! ✨',
      alpha: 1.0,
      vy: -2.2,
      isRare: true,
    });
  };

  // Stage Up celebration effect: Golden shockwave particles & sparkles
  const triggerStageUpEffect = (fromStage: number, toStage: number) => {
    const canvas = canvasRef.current;
    const width = canvas ? canvas.width : 400;
    const height = canvas ? canvas.height : 700;

    playStageUpFanfare();

    gameRef.current.transition = {
      fromStage,
      toStage,
      progress: 0,
      bannerTimer: 2.4,
      flashAlpha: 0.85,
      particlesSpawned: false,
    };

    // Show Stage Banner in UI
    const targetStage = STAGES[toStage];
    setStageBanner({ show: true, stage: targetStage });
    setTimeout(() => {
      setStageBanner((prev) => (prev?.stage.level === targetStage.level ? { ...prev, show: false } : prev));
    }, 2400);

    // Spawn 50 celebratory stage-up sparkle particles
    for (let i = 0; i < 50; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 12 + 4;
      gameRef.current.particles.push({
        x: width / 2,
        y: height * 0.45 + gameRef.current.cameraY,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - 2,
        alpha: 1.0,
        size: Math.random() * 8 + 4,
        color: ['#fef08a', '#fbbf24', '#f59e0b', '#ffffff', '#67e8f9', '#c084fc'][Math.floor(Math.random() * 6)],
        shape: 'star',
      });
    }
  };

  const spawnPopcornExplosion = (x: number, y: number) => {
    const canvas = canvasRef.current;
    const cw = canvas ? canvas.width : 400;
    const ch = canvas ? canvas.height : 700;

    for (let i = 0; i < 40; i++) {
      gameRef.current.popcorns.push({
        x: x || cw / 2,
        y: y || ch / 2,
        vx: (Math.random() - 0.5) * 18,
        vy: (Math.random() - 0.8) * 20 - 4,
        size: Math.random() * 20 + 16,
        rot: Math.random() * Math.PI * 2,
        vRot: (Math.random() - 0.5) * 0.25,
        gravity: 0.4,
        alpha: 1.0,
      });
    }
  };

  const triggerGameOver = () => {
    setGameState('GAMEOVER');
    playGameOverSound();
  };

  const triggerMissionComplete = () => {
    setGameState('CLEAR');
    playVictorySound();
    const canvas = canvasRef.current;
    const { corn, cameraY } = gameRef.current;
    spawnPopcornExplosion(corn.x, corn.y - cameraY);
    if (canvas) {
      setTimeout(() => spawnPopcornExplosion(canvas.width * 0.3, canvas.height * 0.4), 200);
      setTimeout(() => spawnPopcornExplosion(canvas.width * 0.7, canvas.height * 0.4), 400);
    }
  };

  // -------------------------------------------------------------
  // CANVAS BACKGROUND DRAWING WITH 10 INDIVIDUAL STAGES & TRANSITION
  // -------------------------------------------------------------

  const drawStageCoverImage = (
    ctx: CanvasRenderingContext2D,
    img: HTMLImageElement,
    width: number,
    height: number,
    alpha: number,
    parallaxY: number
  ) => {
    if (alpha <= 0.001) return;

    ctx.save();
    ctx.globalAlpha = Math.min(1, Math.max(0, alpha));

    const imgRatio = img.width / img.height;
    const canvasRatio = width / height;
    let renderW = width;
    let renderH = height;
    let offsetX = 0;
    let offsetY = 0;

    if (canvasRatio > imgRatio) {
      renderW = width;
      renderH = width / imgRatio;
      offsetY = (height - renderH) / 2;
    } else {
      renderH = height;
      renderW = height * imgRatio;
      offsetX = (width - renderW) / 2;
    }

    // Parallax scrolling
    offsetY += parallaxY * 0.12;

    ctx.drawImage(img, offsetX, offsetY, renderW, renderH);

    // Warm high-legibility ambient overlay tint
    ctx.fillStyle = 'rgba(254, 243, 199, 0.28)';
    ctx.fillRect(0, 0, width, height);

    ctx.restore();
  };

  const drawStageBackground = (ctx: CanvasRenderingContext2D, width: number, height: number, dt: number) => {
    const { currentStageIdx, transition, cameraY } = gameRef.current;

    // Fallback gradient base
    const baseGrad = ctx.createLinearGradient(0, 0, 0, height);
    baseGrad.addColorStop(0, '#fef3c7');
    baseGrad.addColorStop(0.5, '#fed7aa');
    baseGrad.addColorStop(1, '#fde68a');
    ctx.fillStyle = baseGrad;
    ctx.fillRect(0, 0, width, height);

    // If transitioning between stages
    if (transition) {
      transition.progress = Math.min(1, transition.progress + dt * 1.1); // ~0.9s blend
      transition.bannerTimer -= dt;
      transition.flashAlpha = Math.max(0, transition.flashAlpha - dt * 1.8);

      const fromImg = loadedImagesRef.current.get(STAGES[transition.fromStage]?.imageSrc);
      const toImg = loadedImagesRef.current.get(STAGES[transition.toStage]?.imageSrc);

      if (fromImg) {
        drawStageCoverImage(ctx, fromImg, width, height, 1 - transition.progress, cameraY);
      }
      if (toImg) {
        drawStageCoverImage(ctx, toImg, width, height, transition.progress, cameraY);
      }

      // Stage Up Radiant Flash & Expanding Beams Effect
      if (transition.flashAlpha > 0.01) {
        ctx.save();
        ctx.globalAlpha = transition.flashAlpha;
        const flashGrad = ctx.createRadialGradient(width / 2, height / 2, 20, width / 2, height / 2, width);
        flashGrad.addColorStop(0, 'rgba(255, 255, 255, 0.95)');
        flashGrad.addColorStop(0.4, 'rgba(254, 240, 138, 0.7)');
        flashGrad.addColorStop(0.8, 'rgba(245, 158, 11, 0.3)');
        flashGrad.addColorStop(1, 'rgba(245, 158, 11, 0)');
        ctx.fillStyle = flashGrad;
        ctx.fillRect(0, 0, width, height);

        // Radiant light rays during flash
        const rot = Date.now() * 0.003;
        ctx.translate(width / 2, height / 2);
        ctx.rotate(rot);
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.6)';
        ctx.lineWidth = 4;
        for (let a = 0; a < Math.PI * 2; a += Math.PI / 6) {
          ctx.beginPath();
          ctx.moveTo(0, 0);
          ctx.lineTo(Math.cos(a) * width, Math.sin(a) * width);
          ctx.stroke();
        }
        ctx.restore();
      }

      if (transition.progress >= 1 && transition.bannerTimer <= 0) {
        gameRef.current.transition = null;
      }
    } else {
      // Normal single background render
      const currentStage = STAGES[currentStageIdx];
      const img = loadedImagesRef.current.get(currentStage?.imageSrc);
      if (img) {
        drawStageCoverImage(ctx, img, width, height, 1, cameraY);
      }
    }

    // Parallax subtle tile details & bottom countertop base
    ctx.save();
    ctx.translate(0, -cameraY * 0.15);

    ctx.strokeStyle = 'rgba(217, 119, 6, 0.08)';
    ctx.lineWidth = 1.5;
    const tileSize = 60;
    for (let x = 0; x < width; x += tileSize) {
      for (let y = -250; y < height + 650; y += tileSize) {
        ctx.strokeRect(x, y, tileSize, tileSize);
      }
    }

    const counterY = height * 0.78;
    ctx.fillStyle = '#b45309';
    ctx.fillRect(0, counterY, width, 320);
    ctx.fillStyle = '#78350f';
    ctx.fillRect(0, counterY, width, 12);

    ctx.restore();
  };

  // -----------------------------------------------------------------
  // 1. 기름 한방울 (1-Drop Oil) - [아기자기하게]
  // -----------------------------------------------------------------
  const drawCute1DropOil = (ctx: CanvasRenderingContext2D, oilY: number) => {
    const time = Date.now();
    const bob = Math.sin(time * 0.007) * 4.5;
    const squash = 1 + Math.sin(time * 0.008) * 0.06;
    const yPos = oilY + bob;

    ctx.save();
    ctx.translate(0, yPos);
    ctx.scale(2 - squash, squash);

    // Soft warm golden halo aura underneath
    const auraGrad = ctx.createRadialGradient(0, 2, 2, 0, 2, 18);
    auraGrad.addColorStop(0, 'rgba(251, 191, 36, 0.65)');
    auraGrad.addColorStop(0.6, 'rgba(245, 158, 11, 0.25)');
    auraGrad.addColorStop(1, 'rgba(245, 158, 11, 0)');
    ctx.fillStyle = auraGrad;
    ctx.beginPath();
    ctx.arc(0, 2, 18, 0, Math.PI * 2);
    ctx.fill();

    // Cute Plump Teardrop Body with rich honey-amber gradient
    const dropGrad = ctx.createRadialGradient(-3, -3, 1, 0, 3, 15);
    dropGrad.addColorStop(0, '#fef08a');
    dropGrad.addColorStop(0.35, '#fbbf24');
    dropGrad.addColorStop(0.85, '#f59e0b');
    dropGrad.addColorStop(1, '#d97706');

    ctx.fillStyle = dropGrad;
    ctx.beginPath();
    ctx.moveTo(0, -14);
    ctx.bezierCurveTo(9, -4, 13, 6, 0, 13);
    ctx.bezierCurveTo(-13, 6, -9, -4, 0, -14);
    ctx.closePath();
    ctx.fill();

    // Cute outer contour
    ctx.strokeStyle = '#b45309';
    ctx.lineWidth = 1.3;
    ctx.stroke();

    // Plump Jelly Gloss Highlight
    ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
    ctx.beginPath();
    ctx.ellipse(-4, -1, 3.2, 5.5, -0.4, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(-2, 6, 1.3, 0, Math.PI * 2);
    ctx.fill();

    // Cute Chibi Face
    const blinkProgress = time % 3200;
    const isBlinking = blinkProgress > 3050;

    if (isBlinking) {
      ctx.strokeStyle = '#78350f';
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.arc(-4, 2, 2.2, Math.PI * 1.1, Math.PI * 1.9);
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(4, 2, 2.2, Math.PI * 1.1, Math.PI * 1.9);
      ctx.stroke();
    } else {
      ctx.fillStyle = '#78350f';
      ctx.beginPath();
      ctx.ellipse(-4, 2, 1.8, 2.4, 0, 0, Math.PI * 2);
      ctx.ellipse(4, 2, 1.8, 2.4, 0, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(-4.6, 1.2, 0.9, 0, Math.PI * 2);
      ctx.arc(3.4, 1.2, 0.9, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(-3.4, 3, 0.5, 0, Math.PI * 2);
      ctx.arc(4.6, 3, 0.5, 0, Math.PI * 2);
      ctx.fill();
    }

    // Rosy Blushing Cheeks
    ctx.fillStyle = 'rgba(244, 63, 94, 0.55)';
    ctx.beginPath();
    ctx.ellipse(-7, 4.5, 2.2, 1.4, 0, 0, Math.PI * 2);
    ctx.ellipse(7, 4.5, 2.2, 1.4, 0, 0, Math.PI * 2);
    ctx.fill();

    // Sweet Smile
    ctx.strokeStyle = '#78350f';
    ctx.lineWidth = 1.3;
    ctx.beginPath();
    ctx.arc(0, 3.8, 2.2, 0.15, Math.PI - 0.15);
    ctx.stroke();

    // Tiny Twinkling Sparkle near tip
    const sparkleAngle = time * 0.005;
    const spX = Math.cos(sparkleAngle) * 11;
    const spY = -12 + Math.sin(sparkleAngle) * 3;
    ctx.fillStyle = '#fef08a';
    ctx.font = '9px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('✦', spX, spY);

    ctx.restore();
    ctx.save();
    ctx.translate(0, yPos);

    // Pill badge background
    ctx.fillStyle = 'rgba(255, 255, 255, 0.92)';
    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.roundRect(-30, -29, 60, 16, 8);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = '#b45309';
    ctx.font = 'bold 10px "Jua", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('소중한 기름 💧', 0, -21);

    ctx.restore();
  };

  // -----------------------------------------------------------------
  // 2. 기름 5방울 (5-Drop Oil / 대왕 기름) - [조금 더 고급스럽게]
  // -----------------------------------------------------------------
  const drawLuxurious5DropOil = (ctx: CanvasRenderingContext2D, oilY: number) => {
    const time = Date.now();
    const pulse = Math.sin(time * 0.005) * 5;
    const rot = time * 0.0025;
    const yPos = oilY + Math.sin(time * 0.006) * 3;

    ctx.save();
    ctx.translate(0, yPos);

    // 1. Layered Grand Celestial Golden Aura
    const auraOuter = ctx.createRadialGradient(0, 0, 4, 0, 0, 34 + pulse);
    auraOuter.addColorStop(0, 'rgba(254, 240, 138, 0.7)');
    auraOuter.addColorStop(0.35, 'rgba(245, 158, 11, 0.45)');
    auraOuter.addColorStop(0.7, 'rgba(217, 119, 6, 0.2)');
    auraOuter.addColorStop(1, 'rgba(180, 83, 9, 0)');
    ctx.fillStyle = auraOuter;
    ctx.beginPath();
    ctx.arc(0, 0, 34 + pulse, 0, Math.PI * 2);
    ctx.fill();

    // 2. Faceted Golden Ray Starburst
    ctx.save();
    ctx.rotate(rot);
    for (let a = 0; a < Math.PI * 2; a += Math.PI / 4) {
      const isCardinal = a % (Math.PI / 2) === 0;
      const len = isCardinal ? 32 + pulse * 0.7 : 24 + pulse * 0.5;

      const rayGrad = ctx.createLinearGradient(0, 0, Math.cos(a) * len, Math.sin(a) * len);
      rayGrad.addColorStop(0, 'rgba(255, 255, 255, 0.95)');
      rayGrad.addColorStop(0.5, 'rgba(254, 240, 138, 0.85)');
      rayGrad.addColorStop(1, 'rgba(245, 158, 11, 0)');

      ctx.strokeStyle = rayGrad;
      ctx.lineWidth = isCardinal ? 2.5 : 1.5;
      ctx.beginPath();
      ctx.moveTo(Math.cos(a) * 14, Math.sin(a) * 14);
      ctx.lineTo(Math.cos(a) * len, Math.sin(a) * len);
      ctx.stroke();
    }
    ctx.restore();

    // 3. Orbit Ring with Floating Gems
    ctx.strokeStyle = 'rgba(254, 240, 138, 0.5)';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.arc(0, 0, 25, 0, Math.PI * 2);
    ctx.stroke();

    for (let i = 0; i < 3; i++) {
      const orbAngle = rot * 2 + (i * Math.PI * 2) / 3;
      const ox = Math.cos(orbAngle) * 25;
      const oy = Math.sin(orbAngle) * 25;
      ctx.fillStyle = '#ffffff';
      ctx.font = '10px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('✦', ox, oy);
    }

    // 4. Regal Teardrop Body
    const dropGrad = ctx.createRadialGradient(-5, -6, 2, 2, 4, 24);
    dropGrad.addColorStop(0, '#ffffff');
    dropGrad.addColorStop(0.2, '#fef08a');
    dropGrad.addColorStop(0.55, '#f59e0b');
    dropGrad.addColorStop(0.85, '#d97706');
    dropGrad.addColorStop(1, '#92400e');

    ctx.fillStyle = dropGrad;
    ctx.beginPath();
    ctx.moveTo(0, -22);
    ctx.bezierCurveTo(17, -4, 20, 15, 0, 20);
    ctx.bezierCurveTo(-20, 15, -17, -4, 0, -22);
    ctx.closePath();
    ctx.fill();

    ctx.strokeStyle = '#b45309';
    ctx.lineWidth = 1.8;
    ctx.stroke();

    // Jewel Refraction Line
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.7)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(-2, -18);
    ctx.bezierCurveTo(-13, -2, -13, 11, -3, 16);
    ctx.stroke();

    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(-6, 2, 3.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.arc(-2, 10, 1.8, 0, Math.PI * 2);
    ctx.fill();

    // 5. Imperial Crown
    ctx.save();
    ctx.translate(0, -23);

    ctx.fillStyle = 'rgba(0, 0, 0, 0.2)';
    ctx.beginPath();
    ctx.ellipse(0, 3, 12, 3, 0, 0, Math.PI * 2);
    ctx.fill();

    const crownGrad = ctx.createLinearGradient(-12, 0, 12, 0);
    crownGrad.addColorStop(0, '#d97706');
    crownGrad.addColorStop(0.3, '#fef08a');
    crownGrad.addColorStop(0.7, '#f59e0b');
    crownGrad.addColorStop(1, '#b45309');

    ctx.fillStyle = crownGrad;
    ctx.beginPath();
    ctx.moveTo(-11, 2);
    ctx.lineTo(-13, -8);
    ctx.lineTo(-6, -4);
    ctx.lineTo(0, -12);
    ctx.lineTo(6, -4);
    ctx.lineTo(13, -8);
    ctx.lineTo(11, 2);
    ctx.closePath();
    ctx.fill();

    ctx.strokeStyle = '#78350f';
    ctx.lineWidth = 1.2;
    ctx.stroke();

    ctx.fillStyle = '#ef4444';
    ctx.beginPath();
    ctx.arc(0, -11, 2, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#3b82f6';
    ctx.beginPath();
    ctx.arc(-13, -7.5, 1.5, 0, Math.PI * 2);
    ctx.arc(13, -7.5, 1.5, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(-5, 0, 1, 0, Math.PI * 2);
    ctx.arc(0, 0, 1.2, 0, Math.PI * 2);
    ctx.arc(5, 0, 1, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();

    // 6. Luxurious Plaque Badge
    ctx.save();
    ctx.translate(0, -42);

    ctx.fillStyle = 'rgba(0, 0, 0, 0.25)';
    ctx.beginPath();
    ctx.roundRect(-46, 2, 92, 18, 9);
    ctx.fill();

    const plaqueGrad = ctx.createLinearGradient(0, -8, 0, 10);
    plaqueGrad.addColorStop(0, '#78350f');
    plaqueGrad.addColorStop(0.5, '#451a03');
    plaqueGrad.addColorStop(1, '#78350f');
    ctx.fillStyle = plaqueGrad;
    ctx.beginPath();
    ctx.roundRect(-45, -8, 90, 18, 9);
    ctx.fill();

    ctx.strokeStyle = '#fde047';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    ctx.fillStyle = '#fef08a';
    ctx.font = 'bold 10.5px "Jua", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('👑 로열 골드 (+5) 👑', 0, 1.5);

    ctx.restore();
    ctx.restore();
  };

  // -----------------------------------------------------------------
  // 3. 옥수수 (Corn / 맹구 옥수수) - [아기자기하게]
  // -----------------------------------------------------------------
  const drawCuteCorn = (ctx: CanvasRenderingContext2D) => {
    const { corn, cameraY } = gameRef.current;
    const screenY = corn.y - cameraY;
    const time = Date.now();

    ctx.save();
    ctx.translate(corn.x, screenY);
    ctx.scale(corn.scaleX, corn.scaleY);
    ctx.rotate(corn.rotation);

    // Soft Warm Shadow
    if (!corn.isJumping) {
      ctx.fillStyle = 'rgba(120, 53, 15, 0.22)';
      ctx.beginPath();
      ctx.ellipse(0, 17, 14, 5, 0, 0, Math.PI * 2);
      ctx.fill();
    }

    // Cute Husk Leaves Wrapping at Bottom
    ctx.fillStyle = '#65a30d';
    ctx.beginPath();
    ctx.moveTo(-15, 6);
    ctx.quadraticCurveTo(-18, 18, -4, 21);
    ctx.quadraticCurveTo(-10, 14, -15, 6);
    ctx.fill();
    ctx.strokeStyle = '#4d7c0f';
    ctx.lineWidth = 1.2;
    ctx.stroke();

    ctx.fillStyle = '#65a30d';
    ctx.beginPath();
    ctx.moveTo(15, 6);
    ctx.quadraticCurveTo(18, 18, 4, 21);
    ctx.quadraticCurveTo(10, 14, 15, 6);
    ctx.fill();
    ctx.strokeStyle = '#4d7c0f';
    ctx.lineWidth = 1.2;
    ctx.stroke();

    ctx.fillStyle = '#84cc16';
    ctx.beginPath();
    ctx.moveTo(-13, 11);
    ctx.quadraticCurveTo(0, 22, 13, 11);
    ctx.quadraticCurveTo(0, 17, -13, 11);
    ctx.fill();

    // Corn Kernel Body with Warm Golden Gradient
    const cornGrad = ctx.createRadialGradient(-3, -6, 4, 0, 2, 23);
    cornGrad.addColorStop(0, '#fef08a');
    cornGrad.addColorStop(0.35, '#fbbf24');
    cornGrad.addColorStop(0.8, '#f59e0b');
    cornGrad.addColorStop(1, '#d97706');
    ctx.fillStyle = cornGrad;

    ctx.beginPath();
    ctx.ellipse(0, -2, 16.5, 22.5, 0, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = '#b45309';
    ctx.lineWidth = 1.6;
    ctx.stroke();

    // Kernel Texture Lines
    ctx.strokeStyle = 'rgba(217, 119, 6, 0.35)';
    ctx.lineWidth = 1.2;
    [-11, -4, 3, 10].forEach((yOff) => {
      ctx.beginPath();
      const halfW = Math.sqrt(Math.max(0, 1 - (yOff * yOff) / (22 * 22))) * 14.5;
      ctx.arc(0, yOff, halfW, 0.2, Math.PI - 0.2);
      ctx.stroke();
    });

    ctx.beginPath();
    ctx.moveTo(-5, -16);
    ctx.quadraticCurveTo(-7, 0, -4, 14);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(5, -16);
    ctx.quadraticCurveTo(7, 0, 4, 14);
    ctx.stroke();

    // Specular Forehead Highlight
    ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
    ctx.beginPath();
    ctx.ellipse(-5, -14, 4, 2.2, -0.3, 0, Math.PI * 2);
    ctx.fill();

    // 맹구 (Bo-chan) Style Face Features
    ctx.strokeStyle = '#78350f';
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.arc(-6.5, -12.5, 4.5, Math.PI * 1.15, Math.PI * 1.85);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(6.5, -12.5, 4.5, Math.PI * 1.15, Math.PI * 1.85);
    ctx.stroke();

    // Eyes
    ctx.fillStyle = '#1e293b';
    ctx.beginPath();
    ctx.ellipse(-5.5, -5.5, 2.2, 3.4, 0, 0, Math.PI * 2);
    ctx.ellipse(5.5, -5.5, 2.2, 3.4, 0, 0, Math.PI * 2);
    ctx.fill();

    // Catchlights
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(-6.2, -6.5, 1.1, 0, Math.PI * 2);
    ctx.arc(-4.8, -4.2, 0.6, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.arc(4.8, -6.5, 1.1, 0, Math.PI * 2);
    ctx.arc(6.2, -4.2, 0.6, 0, Math.PI * 2);
    ctx.fill();

    // Cheeks
    ctx.fillStyle = 'rgba(244, 63, 94, 0.45)';
    ctx.beginPath();
    ctx.ellipse(-10.5, 0, 3.8, 2.4, 0, 0, Math.PI * 2);
    ctx.ellipse(10.5, 0, 3.8, 2.4, 0, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = '#e11d48';
    ctx.lineWidth = 1.1;
    [-11.5, -10, -8.5].forEach((xOff) => {
      ctx.beginPath();
      ctx.moveTo(xOff, -1.2);
      ctx.lineTo(xOff + 1.2, 1.6);
      ctx.stroke();
    });
    [8.5, 10, 11.5].forEach((xOff) => {
      ctx.beginPath();
      ctx.moveTo(xOff, -1.2);
      ctx.lineTo(xOff + 1.2, 1.6);
      ctx.stroke();
    });

    // Runny Nose Drop (콧물)
    const dripSwing = Math.sin(time * 0.007) * 2.2;
    const dripLen = 8 + Math.abs(dripSwing * 0.5);

    ctx.fillStyle = 'rgba(120, 53, 15, 0.15)';
    ctx.beginPath();
    ctx.arc(dripSwing * 0.5, 7, 2, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = 'rgba(255, 255, 255, 0.95)';
    ctx.strokeStyle = '#94a3b8';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, -2);
    ctx.quadraticCurveTo(2.5 + dripSwing, 2, dripSwing, dripLen);
    ctx.quadraticCurveTo(-2.5 + dripSwing, 2, 0, -2);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(dripSwing * 0.7 - 0.5, dripLen - 2, 0.9, 0, Math.PI * 2);
    ctx.fill();

    // Cute squiggled mouth )-(
    ctx.strokeStyle = '#78350f';
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.moveTo(-3, 8.5);
    ctx.quadraticCurveTo(0, 9.5, 3, 8.5);
    ctx.moveTo(0, 8.5);
    ctx.lineTo(0, 11);
    ctx.moveTo(-3, 12);
    ctx.quadraticCurveTo(0, 11, 3, 12);
    ctx.stroke();

    // Sprout Tuft with Twinkle
    const bounceOffset = Math.sin(time * 0.008) * 1.5;
    ctx.save();
    ctx.translate(0, -24 + bounceOffset);

    ctx.strokeStyle = '#84cc16';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(0, 2);
    ctx.quadraticCurveTo(4, -3, 2, -7);
    ctx.stroke();

    ctx.fillStyle = '#f59e0b';
    ctx.font = '13px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('✨', 0, -8);
    ctx.restore();

    ctx.restore();
  };

  const drawPlatforms = (ctx: CanvasRenderingContext2D, height: number) => {
    const { platforms, cameraY } = gameRef.current;

    for (let i = 0; i < platforms.length; i++) {
      const plat = platforms[i];
      const screenY = plat.y - cameraY;

      if (screenY < -120 || screenY > height + 120) continue;

      ctx.save();
      ctx.translate(plat.x, screenY);

      // Platform Shadow
      ctx.fillStyle = 'rgba(0, 0, 0, 0.14)';
      ctx.beginPath();
      ctx.roundRect(-plat.width / 2, 8, plat.width, plat.height, 10);
      ctx.fill();

      // Utensil Main Body
      ctx.fillStyle = plat.type.color;
      ctx.beginPath();
      ctx.roundRect(-plat.width / 2, -plat.height / 2, plat.width, plat.height, 8);
      ctx.fill();

      // Utensil Accent Border
      ctx.strokeStyle = plat.type.accent;
      ctx.lineWidth = 3;
      ctx.stroke();

      ctx.fillStyle = plat.type.accent;
      ctx.fillRect(-plat.width * 0.2, -2, plat.width * 0.4, 4);

      // Oil Item
      if (plat.hasOil && !plat.oilCollected) {
        const oilY = -plat.height / 2 - 20;
        if (plat.isRare) {
          drawLuxurious5DropOil(ctx, oilY);
        } else {
          drawCute1DropOil(ctx, oilY);
        }
      }

      ctx.restore();
    }
  };

  const updateAndDrawFX = (ctx: CanvasRenderingContext2D) => {
    const { particles, floatingTexts, popcorns, cameraY } = gameRef.current;

    // 1. Particles
    for (let i = particles.length - 1; i >= 0; i--) {
      const p = particles[i];
      p.x += p.vx;
      p.y += p.vy;
      p.alpha -= 0.024;

      if (p.alpha <= 0) {
        particles.splice(i, 1);
        continue;
      }

      ctx.save();
      ctx.globalAlpha = Math.max(0, p.alpha);
      ctx.fillStyle = p.color;

      if (p.shape === 'star') {
        ctx.font = `${Math.round(p.size * 1.5)}px sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('✦', p.x, p.y - cameraY);
      } else {
        ctx.beginPath();
        ctx.arc(p.x, p.y - cameraY, p.size, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    }

    // 2. Popping Popcorns FX
    for (let i = popcorns.length - 1; i >= 0; i--) {
      const pop = popcorns[i];
      pop.x += pop.vx;
      pop.vy += pop.gravity;
      pop.y += pop.vy;
      pop.rot += pop.vRot;
      pop.alpha -= 0.012;

      if (pop.alpha <= 0) {
        popcorns.splice(i, 1);
        continue;
      }

      ctx.save();
      ctx.globalAlpha = Math.max(0, pop.alpha);
      ctx.translate(pop.x, pop.y);
      ctx.rotate(pop.rot);
      ctx.font = `${pop.size}px sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('🍿', 0, 0);
      ctx.restore();
    }

    // 3. Floating Text
    for (let i = floatingTexts.length - 1; i >= 0; i--) {
      const ft = floatingTexts[i];
      ft.y += ft.vy;
      ft.alpha -= 0.02;

      if (ft.alpha <= 0) {
        floatingTexts.splice(i, 1);
        continue;
      }

      ctx.save();
      ctx.globalAlpha = Math.max(0, ft.alpha);
      ctx.fillStyle = ft.isRare ? '#b45309' : '#d97706';
      ctx.font = ft.isRare ? 'bold 16px "Jua", sans-serif' : 'bold 14px "Jua", sans-serif';
      ctx.textAlign = 'center';
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 3;
      ctx.strokeText(ft.text, ft.x, ft.y - cameraY);
      ctx.fillText(ft.text, ft.x, ft.y - cameraY);
      ctx.restore();
    }
  };

  const updateGame = (canvasWidth: number, canvasHeight: number, _dt: number) => {
    if (gameRef.current.gameState !== 'PLAYING') return;

    const { corn, platforms } = gameRef.current;

    // Platform motion
    for (let i = 0; i < platforms.length; i++) {
      const plat = platforms[i];
      if (plat.speed > 0) {
        plat.x += plat.speed * plat.dir;

        const minX = plat.width / 2 + 20;
        const maxX = canvasWidth - plat.width / 2 - 20;

        if (plat.x < minX) {
          plat.x = minX;
          plat.dir = 1;
        } else if (plat.x > maxX) {
          plat.x = maxX;
          plat.dir = -1;
        }
      }
    }

    if (!corn.isJumping && corn.standingPlatform) {
      corn.x += corn.standingPlatform.speed * corn.standingPlatform.dir;
      corn.y = corn.standingPlatform.y - corn.standingPlatform.height / 2 - corn.radius;
    }

    corn.scaleX += (1 - corn.scaleX) * 0.15;
    corn.scaleY += (1 - corn.scaleY) * 0.15;

    // Jump physics
    if (corn.isJumping) {
      corn.vy += 0.75;
      corn.y += corn.vy;

      if (corn.vy > 0) {
        for (let i = 0; i < platforms.length; i++) {
          const plat = platforms[i];
          const platTop = plat.y - plat.height / 2;
          const platLeft = plat.x - plat.width / 2 - 12;
          const platRight = plat.x + plat.width / 2 + 12;

          if (
            corn.x >= platLeft &&
            corn.x <= platRight &&
            corn.y + corn.radius >= platTop &&
            corn.y - corn.radius <= platTop + plat.height
          ) {
            corn.isJumping = false;
            corn.vy = 0;
            corn.standingPlatform = plat;
            corn.y = platTop - corn.radius;
            corn.scaleX = 1.25;
            corn.scaleY = 0.75;

            // Collect oil
            if (plat.hasOil && !plat.oilCollected) {
              plat.oilCollected = true;
              const gain = plat.oilValue || 1;
              const nextScore = gameRef.current.score + gain;
              gameRef.current.score = nextScore;
              setScore(nextScore);

              if (nextScore > gameRef.current.bestScore) {
                gameRef.current.bestScore = nextScore;
                setBestScore(nextScore);
                try { localStorage.setItem('corn_oil_game_best', nextScore.toString()); } catch {}
              }

              if (plat.isRare) {
                playRareOilCollectSound();
                spawnRareOilParticles(plat.x, plat.y - 25);
              } else {
                playOilCollectSound();
                spawnOilParticles(plat.x, plat.y - 25);
              }

              // Check Stage Progression (10 Stages total!)
              let nextStageIdx = 0;
              for (let s = STAGES.length - 1; s >= 0; s--) {
                if (nextScore >= STAGES[s].threshold) {
                  nextStageIdx = s;
                  break;
                }
              }

              if (nextStageIdx > gameRef.current.currentStageIdx) {
                const prevStage = gameRef.current.currentStageIdx;
                gameRef.current.currentStageIdx = nextStageIdx;
                setCurrentStageIdx(nextStageIdx);
                triggerStageUpEffect(prevStage, nextStageIdx);
              }

              // Popcorn burst mission complete at 50 drops
              if (nextScore >= 50) {
                triggerMissionComplete();
                break;
              }
            }

            if (platforms.length - i < 20) {
              generatePlatforms(25, canvasWidth, canvasHeight);
            }
            break;
          }
        }
      }

      if (corn.y - gameRef.current.cameraY > canvasHeight + 160) {
        triggerGameOver();
      }
    }

    gameRef.current.targetCameraY = corn.y - canvasHeight * 0.55;
    gameRef.current.cameraY += (gameRef.current.targetCameraY - gameRef.current.cameraY) * 0.1;
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    handleResize();
    window.addEventListener('resize', handleResize);

    resetGame();

    const renderLoop = (timeNow: number) => {
      const dt = Math.min(0.1, (timeNow - gameRef.current.lastFrameTime) / 1000);
      gameRef.current.lastFrameTime = timeNow;

      updateGame(canvas.width, canvas.height, dt);

      ctx.clearRect(0, 0, canvas.width, canvas.height);
      drawStageBackground(ctx, canvas.width, canvas.height, dt);
      drawPlatforms(ctx, canvas.height);
      drawCuteCorn(ctx);
      updateAndDrawFX(ctx);

      gameRef.current.animationFrameId = requestAnimationFrame(renderLoop);
    };

    gameRef.current.animationFrameId = requestAnimationFrame(renderLoop);

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(gameRef.current.animationFrameId);
    };
  }, []);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space') {
        e.preventDefault();
        if (gameState === 'PLAYING') {
          performJump();
        } else if (gameState === 'START') {
          handleStart();
        } else if (gameState === 'GAMEOVER' || gameState === 'CLEAR') {
          handleRestart();
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [gameState]);

  const handleStart = () => {
    initAudio();
    setGameState('PLAYING');
    resetGame();
  };

  const handleRestart = () => {
    initAudio();
    setGameState('PLAYING');
    resetGame();
  };

  const currentStage = STAGES[currentStageIdx] || STAGES[0];
  const nextStage = STAGES[currentStageIdx + 1] || null;
  const stageProgressPercent = nextStage
    ? Math.min(100, Math.max(0, ((score - currentStage.threshold) / (nextStage.threshold - currentStage.threshold)) * 100))
    : 100;

  return (
    <main className="relative w-screen h-screen overflow-hidden select-none bg-amber-50">
      {/* Top HUD with Stage & Score */}
      <header id="hud" className="absolute top-0 left-0 w-full p-3.5 z-20 flex flex-col items-center pointer-events-none">
        <div className="w-full max-w-md flex flex-col gap-2 bg-white/95 backdrop-blur-md px-4 py-2.5 rounded-2xl shadow-xl border-2 border-amber-300">
          <div className="flex justify-between items-center">
            {/* Stage Level Badge */}
            <div className="flex items-center space-x-2">
              <span className="text-xl p-1 bg-amber-100 rounded-lg border border-amber-300 shadow-sm">
                {currentStage.badgeEmoji}
              </span>
              <div className="flex flex-col">
                <span className="text-[10px] text-amber-800 font-bold uppercase tracking-wider">
                  STAGE {currentStage.level} / 10
                </span>
                <span className="text-sm font-black text-amber-700 leading-none">{currentStage.name}</span>
              </div>
            </div>

            {/* Score & Sound & Best */}
            <div className="flex items-center space-x-3">
              <div className="flex items-center space-x-1.5">
                <span className="text-2xl golden-glow">💧</span>
                <div className="flex flex-col text-right">
                  <span className="text-[10px] text-amber-700 font-bold leading-none">모은 기름</span>
                  <span id="scoreText" className="text-xl font-black text-amber-600 leading-none mt-0.5">
                    {score}
                    <span className="text-xs font-semibold ml-0.5 text-amber-800">방울</span>
                  </span>
                </div>
              </div>

              <div className="h-6 w-0.5 bg-amber-200" />

              <button
                onClick={() => setSoundEnabled(!soundEnabled)}
                className="pointer-events-auto p-1.5 rounded-xl bg-amber-100 hover:bg-amber-200 text-amber-800 transition-colors"
                title={soundEnabled ? '소리 끄기' : '소리 켜기'}
              >
                {soundEnabled ? <Volume2 size={16} /> : <VolumeX size={16} />}
              </button>
            </div>
          </div>

          {/* Stage Progress Bar to Next Background */}
          <div className="w-full bg-amber-100/90 rounded-full h-2 overflow-hidden border border-amber-300/80">
            <div
              className="h-full bg-gradient-to-r from-amber-400 via-amber-500 to-yellow-500 rounded-full transition-all duration-300 shadow-sm"
              style={{ width: `${stageProgressPercent}%` }}
            />
          </div>
        </div>
      </header>

      {/* Stage Up Floating Transition Banner */}
      {stageBanner?.show && (
        <div className="absolute top-24 left-1/2 -translate-x-1/2 z-30 pointer-events-none animate-bounce">
          <div className="bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 text-white px-6 py-2.5 rounded-2xl shadow-2xl border-2 border-yellow-200 flex items-center space-x-3 backdrop-blur-sm">
            <span className="text-3xl animate-spin">✨</span>
            <div className="flex flex-col items-center">
              <span className="text-[11px] font-black uppercase tracking-widest text-amber-100 drop-shadow">
                STAGE UP!
              </span>
              <span className="text-lg font-black text-white tracking-wide drop-shadow">
                {stageBanner.stage.level}단계: {stageBanner.stage.name}
              </span>
              <span className="text-[10px] text-amber-100 font-medium">{stageBanner.stage.subTitle}</span>
            </div>
            <span className="text-2xl">{stageBanner.stage.badgeEmoji}</span>
          </div>
        </div>
      )}

      {/* Main Game Canvas */}
      <canvas
        ref={canvasRef}
        id="gameCanvas"
        className="w-full h-full block cursor-pointer"
        onPointerDown={(e) => {
          e.preventDefault();
          performJump();
        }}
      />

      {/* Bottom Timing Jump Control Button */}
      <section
        id="controls"
        className="absolute bottom-6 w-full max-w-md left-1/2 -translate-x-1/2 px-6 z-20 flex justify-center items-center pointer-events-auto"
      >
        <button
          id="btnJump"
          onClick={(e) => {
            e.preventDefault();
            performJump();
          }}
          className="btn-bounce w-full bg-gradient-to-b from-amber-400 via-amber-500 to-yellow-600 hover:from-amber-300 hover:to-yellow-500 text-white font-black py-4 rounded-3xl shadow-2xl border-b-8 border-yellow-700 active:border-b-0 active:mt-2 transition-all flex flex-col items-center justify-center space-y-0.5"
        >
          <div className="flex items-center space-x-2">
            <ArrowUp className="text-2xl animate-pulse" />
            <span className="text-2xl tracking-wide">타이밍 점프!</span>
          </div>
          <span className="text-[11px] font-normal opacity-90">[ 스페이스바 (SPACE) / 화면 터치 ]</span>
        </button>
      </section>

      {/* Start Modal with Regenerated Assets */}
      {gameState === 'START' && (
        <section
          id="startModal"
          className="absolute inset-0 z-30 bg-black/65 backdrop-blur-sm flex flex-col justify-center items-center p-4 text-center overflow-y-auto"
        >
          <div className="bg-white rounded-3xl max-w-md w-full shadow-2xl border-4 border-amber-400 flex flex-col items-center overflow-hidden my-auto">
            {/* Visual Top Header using Newly Generated Kitchen Art */}
            <div className="relative w-full h-32 bg-amber-200 overflow-hidden">
              <img
                src={kitchenStartBgImg}
                alt="아늑한 주방 풍경"
                className="w-full h-full object-cover brightness-95"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-white via-transparent to-black/20" />

              {/* Regenerated Cute Corn Kernel Mascot Avatar */}
              <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 flex items-center justify-center">
                <div className="relative w-20 h-20 rounded-full border-4 border-white shadow-xl overflow-hidden bg-amber-100 ring-4 ring-amber-400">
                  <img
                    src={cornMascotImg}
                    alt="맹구 옥수수 마스코트"
                    className="w-full h-full object-cover"
                  />
                </div>
                {/* Regenerated Cute Golden Oil Badge */}
                <div className="absolute -bottom-1 -right-2 w-8 h-8 rounded-full border-2 border-white shadow-lg overflow-hidden bg-amber-200 ring-2 ring-yellow-400 animate-bounce">
                  <img
                    src={goldenOilBadgeImg}
                    alt="황금 기름 뱃지"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            </div>

            <div className="p-5 flex flex-col items-center space-y-3 w-full pt-4">
              <h1 className="text-2xl font-black text-amber-600 drop-shadow-sm flex items-center gap-1.5">
                맹구 옥수수의 기름 모으기 🌽✨
              </h1>
              <p className="text-xs text-slate-600 leading-relaxed font-bold">
                "맹~ 돌맹이보다 더 소중한 기름 한 방울... 💧"<br />
                주방 조리도구를 타고 <span className="text-amber-600">총 10단계의 환상적인 테마 스테이지</span>를 올라보세요!
              </p>

              {/* 10 Stages Preview Chips */}
              <div className="w-full bg-amber-50/80 p-2.5 rounded-2xl border border-amber-200">
                <div className="text-[11px] font-black text-amber-800 mb-1.5 flex items-center justify-between">
                  <span className="flex items-center gap-1">
                    <Compass size={13} className="text-amber-600" /> 10단계 개별 배경 스테이지:
                  </span>
                  <span className="text-[10px] text-amber-600">5방울마다 배경 전환!</span>
                </div>
                <div className="grid grid-cols-5 gap-1 text-[9px] font-bold text-amber-900">
                  {STAGES.map((st) => (
                    <div
                      key={st.level}
                      className="bg-white/90 p-1 rounded-lg border border-amber-200 flex flex-col items-center shadow-2xs"
                    >
                      <span>{st.badgeEmoji}</span>
                      <span className="truncate w-full text-center">{st.level}단계</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Instructions */}
              <div className="w-full bg-amber-50 p-3 rounded-xl border border-amber-200 text-left text-xs text-amber-900 space-y-1">
                <div>• <span className="font-bold text-amber-600">스페이스바 / 화면 터치</span>로 타이밍 점프!</div>
                <div>• 아기자기한 <span className="font-bold text-yellow-600">소중한 기름(+1)</span> & 고급스러운 <span className="font-bold text-amber-700">👑 로열 골드(+5)</span></div>
                <div>• 스테이지를 오를 때마다 화려한 <span className="font-bold text-amber-600">스테이지 업 이펙트</span>가 펼쳐집니다!</div>
              </div>

              <button
                id="btnStart"
                onClick={handleStart}
                className="btn-bounce w-full bg-gradient-to-r from-amber-500 to-yellow-500 text-white font-black text-lg py-3.5 rounded-2xl shadow-lg border-b-4 border-yellow-700 hover:brightness-105 mt-1"
              >
                10개 스테이지 모험 출발! 🌽✨
              </button>
            </div>
          </div>
        </section>
      )}

      {/* Game Over Modal */}
      {gameState === 'GAMEOVER' && (
        <section
          id="gameOverModal"
          className="absolute inset-0 z-30 bg-black/70 backdrop-blur-sm flex flex-col justify-center items-center p-6 text-center"
        >
          <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border-4 border-amber-500 flex flex-col items-center space-y-4">
            <div className="text-6xl animate-bounce">🌽💧</div>
            <h2 className="text-3xl font-black text-amber-600">아차! 바닥으로 떨어졌어요!</h2>

            <p
              id="gameOverSpeech"
              className="text-sm font-bold text-amber-900 italic bg-amber-50 p-3.5 rounded-xl w-full border border-amber-200"
            >
              "내 소중한 기름 한 방울... 조금만 더 높이 갈 수 있었는데!"
            </p>

            <div className="w-full bg-amber-50 p-4 rounded-2xl border border-amber-200 flex justify-around items-center">
              <div className="text-center">
                <span className="text-xs text-slate-500 font-bold">도달한 스테이지</span>
                <div className="text-lg font-black text-amber-700">
                  {currentStage.level}단계: {currentStage.name}
                </div>
              </div>
              <div className="h-10 w-0.5 bg-amber-200" />
              <div className="text-center">
                <span className="text-xs text-slate-500 font-bold">모은 기름</span>
                <div id="finalScore" className="text-2xl font-black text-amber-600">
                  {score} 방울
                </div>
              </div>
            </div>

            <button
              id="btnRestart"
              onClick={handleRestart}
              className="btn-bounce w-full bg-gradient-to-r from-amber-500 to-yellow-500 text-white font-black text-xl py-4 rounded-2xl shadow-lg border-b-4 border-yellow-700 hover:brightness-105 flex items-center justify-center gap-2"
            >
              다시 기름 모으기 <RotateCcw size={20} />
            </button>
          </div>
        </section>
      )}

      {/* Mission Complete Modal */}
      {gameState === 'CLEAR' && (
        <section
          id="missionCompleteModal"
          className="absolute inset-0 z-30 bg-black/70 backdrop-blur-sm flex flex-col justify-center items-center p-6 text-center"
        >
          <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border-4 border-amber-400 flex flex-col items-center space-y-4">
            <div className="text-6xl animate-bounce">🍿🎉🌽✨</div>
            <h2 className="text-3xl font-black text-amber-500 tracking-wider drop-shadow-sm">
              10단계 전 스테이지 완전 정복!
            </h2>
            <p className="text-sm font-bold text-amber-900 bg-amber-50 p-3.5 rounded-xl w-full border border-amber-200 leading-relaxed">
              환상의 팝콘 은하수까지 도달하여 50방울의 소중한 황금 기름을 모두 모아 팡팡 팝콘이 되었어요! 🍿✨
            </p>

            <div className="w-full bg-amber-50 p-4 rounded-2xl border border-amber-200 flex justify-around items-center">
              <div className="text-center">
                <span className="text-xs text-slate-500 font-bold">최종 모은 기름</span>
                <div id="clearScore" className="text-3xl font-black text-amber-600">
                  {score} 방울
                </div>
              </div>
              <div className="h-10 w-0.5 bg-amber-200" />
              <div className="text-center">
                <span className="text-xs text-slate-500 font-bold">최고 기록</span>
                <div id="clearBestScore" className="text-2xl font-extrabold text-slate-700">
                  {bestScore} 방울
                </div>
              </div>
            </div>

            <button
              id="btnClearRestart"
              onClick={handleRestart}
              className="btn-bounce w-full bg-gradient-to-r from-amber-500 to-yellow-500 text-white font-black text-xl py-4 rounded-2xl shadow-lg border-b-4 border-yellow-700 hover:brightness-105 flex items-center justify-center gap-2"
            >
              다시 도전하기 <RotateCcw size={20} />
            </button>
          </div>
        </section>
      )}
    </main>
  );
}
