import React, { useEffect, useRef, useState, useCallback } from 'react';
import { Volume2, VolumeX, Trophy, Play, RotateCcw, Sparkles, Heart, Clock, Flame, Zap } from 'lucide-react';
import { GAME_IMAGES, loadGameAssets, ImageAssets } from './assets/gameAssets';

type MoleType = 'normal' | 'gold' | 'bomb' | 'rainbow';
type MoleState = 'idle' | 'up' | 'hit';

interface Hole {
  state: MoleState;
  type: MoleType;
  time: number;
  dur: number;
  hitTime: number;
  seed: number;
  disguised: boolean;
  transformed: boolean;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  r: number;
  c: string;
  kind: 'dot' | 'star' | 'smoke';
  rot: number;
  vr: number;
}

interface FloatingText {
  x: number;
  y: number;
  text: string;
  color: string;
  life: number;
  size: number;
  vy: number;
}

interface Cell {
  cx: number;
  cy: number;
}

interface Layout {
  cells: Cell[];
  cw: number;
  ch: number;
  top: number;
  rx: number;
  ry: number;
  rise: number;
  horizon: number;
}

const BEST_KEY = 'whackamole_best_v3';

export default function App() {
  const stageRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Game UI States
  const [gameState, setGameState] = useState<'TITLE' | 'PLAY' | 'OVER'>('TITLE');
  const [score, setScore] = useState(0);
  const [lives, setLives] = useState(2);
  const [timeLeft, setTimeLeft] = useState(60);
  const [combo, setCombo] = useState(0);
  const [maxCombo, setMaxCombo] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [bannerText, setBannerText] = useState<string | null>(null);
  const [showComboPop, setShowComboPop] = useState(false);
  const [bestScore, setBestScore] = useState<number>(() => {
    try {
      const v = localStorage.getItem(BEST_KEY);
      const n = parseInt(v || '0', 10);
      return Number.isFinite(n) && n > 0 ? n : 0;
    } catch {
      return 0;
    }
  });

  // End game stats
  const [finalStats, setFinalStats] = useState({
    score: 0,
    grade: 'C',
    gradeName: '초보 망치꾼',
    regret: '조금 더 연습해봐요!',
    accuracy: 0,
    isNewBest: false,
  });

  // Assets ref
  const assetsRef = useRef<ImageAssets | null>(null);

  // Mutable Game Ref for 60fps Loop
  const gameRef = useRef({
    state: 'TITLE' as 'TITLE' | 'PLAY' | 'OVER',
    score: 0,
    lives: 2,
    timeLeft: 60,
    elapsed: 0,
    combo: 0,
    maxCombo: 0,
    swings: 0,
    hits: 0,
    spawnTimer: 0.35,
    rainbowSpawned: false,
    shake: 0,
    hitstop: 0,
    flash: 0,
    flashColor: '255,255,255',
    lastTickSec: -1,
    bgTime: 0,
    events: [
      { t: 10, text: '✨ 황금 두더지 등장! 아주 빨라요!', done: false },
      { t: 20, text: '💣 폭탄 두더지 조심! 1, 4, 6번 위장 주의!', done: false },
      { t: 30, text: '🔥 두더지 러시! 출현 속도 가속!', done: false },
      { t: 45, text: '🌟 황금 폭풍! 점수 대역전의 찬스!', done: false },
      { t: 55, text: '⚡ 마지막 5초! 초광속 무지개 두더지 출현!', done: false },
    ],
    holes: Array.from({ length: 9 }, (_, i) => ({
      state: 'idle' as MoleState,
      type: 'normal' as MoleType,
      time: 0,
      dur: 1,
      hitTime: 0,
      seed: Math.random() * 10,
      disguised: false,
      transformed: false,
    })),
    particles: [] as Particle[],
    pops: [] as FloatingText[],
    hammer: { x: -999, y: -999, swing: 0, show: 0 },
    layout: null as Layout | null,
    muted: false,
  });

  // Keep mute ref updated
  useEffect(() => {
    gameRef.current.muted = isMuted;
  }, [isMuted]);

  // WebAudio API Engine
  const audioContextRef = useRef<AudioContext | null>(null);
  const masterGainRef = useRef<GainNode | null>(null);

  const initAudio = useCallback(() => {
    if (!audioContextRef.current) {
      try {
        const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        if (AudioCtx) {
          const ctx = new AudioCtx();
          const gain = ctx.createGain();
          gain.gain.value = 0.25;
          gain.connect(ctx.destination);
          audioContextRef.current = ctx;
          masterGainRef.current = gain;
        }
      } catch (err) {
        console.warn('AudioContext initialization ignored:', err);
      }
    }
    if (audioContextRef.current && audioContextRef.current.state === 'suspended') {
      audioContextRef.current.resume().catch(() => {});
    }
  }, []);

  const playTone = useCallback((freq: number, dur: number, type: OscillatorType = 'square', vol = 0.3, delay = 0, slideTo?: number) => {
    if (gameRef.current.muted || !audioContextRef.current || !masterGainRef.current) return;
    try {
      const ac = audioContextRef.current;
      const master = masterGainRef.current;
      const t0 = ac.currentTime + delay;
      const osc = ac.createOscillator();
      const g = ac.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(freq, t0);
      if (slideTo) {
        osc.frequency.exponentialRampToValueAtTime(Math.max(30, slideTo), t0 + dur);
      }
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.exponentialRampToValueAtTime(vol, t0 + 0.012);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
      osc.connect(g);
      g.connect(master);
      osc.start(t0);
      osc.stop(t0 + dur + 0.03);
    } catch {
      // ignore
    }
  }, []);

  const playNoise = useCallback((dur: number, vol = 0.3, cutoff = 1200, delay = 0, sweepTo?: number) => {
    if (gameRef.current.muted || !audioContextRef.current || !masterGainRef.current) return;
    try {
      const ac = audioContextRef.current;
      const master = masterGainRef.current;
      const t0 = ac.currentTime + delay;
      const len = Math.max(1, Math.floor(ac.sampleRate * dur));
      const buf = ac.createBuffer(1, len, ac.sampleRate);
      const d = buf.getChannelData(0);
      for (let i = 0; i < len; i++) {
        d[i] = (Math.random() * 2 - 1) * (1 - i / len);
      }
      const src = ac.createBufferSource();
      src.buffer = buf;
      const f = ac.createBiquadFilter();
      f.type = 'lowpass';
      f.frequency.setValueAtTime(cutoff, t0);
      if (sweepTo) {
        f.frequency.exponentialRampToValueAtTime(Math.max(60, sweepTo), t0 + dur);
      }
      const g = ac.createGain();
      g.gain.setValueAtTime(vol, t0);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
      src.connect(f);
      f.connect(g);
      g.connect(master);
      src.start(t0);
      src.stop(t0 + dur + 0.02);
    } catch {
      // ignore
    }
  }, []);

  const playHitSound = useCallback((comboCount: number) => {
    const scale = [261.6, 293.7, 329.6, 349.2, 392.0, 440.0, 493.9, 523.3, 587.3, 659.3, 698.5, 784.0];
    const idx = Math.min(scale.length - 1, Math.max(0, comboCount - 1));
    const f = scale[idx];
    playNoise(0.06, 0.35, 2600, 0, 500);
    playTone(f, 0.11, 'square', 0.26, 0.005);
    playTone(f * 2, 0.08, 'triangle', 0.14, 0.01);
  }, [playNoise, playTone]);

  const playGoldSound = useCallback(() => {
    playTone(783.9, 0.1, 'triangle', 0.28, 0);
    playTone(987.7, 0.1, 'triangle', 0.28, 0.07);
    playTone(1174.6, 0.16, 'triangle', 0.3, 0.14);
    playTone(1567.9, 0.2, 'sine', 0.22, 0.21);
  }, [playTone]);

  const playBombSound = useCallback(() => {
    playNoise(0.45, 0.6, 900, 0, 60);
    playTone(160, 0.45, 'sawtooth', 0.32, 0, 40);
  }, [playNoise, playTone]);

  const playMissSound = useCallback(() => {
    playNoise(0.13, 0.2, 700, 0, 220);
  }, [playNoise]);

  const playComboSound = useCallback((level: number) => {
    const b = 523.3 * Math.pow(1.06, level);
    playTone(b, 0.1, 'triangle', 0.25, 0);
    playTone(b * 1.5, 0.12, 'triangle', 0.22, 0.06);
    playTone(b * 2, 0.16, 'sine', 0.18, 0.12);
  }, [playTone]);

  const playStartSound = useCallback(() => {
    playTone(392, 0.11, 'square', 0.26, 0);
    playTone(523.3, 0.11, 'square', 0.26, 0.1);
    playTone(659.3, 0.22, 'square', 0.28, 0.2);
  }, [playTone]);

  const playOverSound = useCallback(() => {
    playTone(523.3, 0.16, 'square', 0.24, 0);
    playTone(392, 0.16, 'square', 0.24, 0.15);
    playTone(311.1, 0.16, 'square', 0.24, 0.3);
    playTone(261.6, 0.4, 'square', 0.26, 0.45);
  }, [playTone]);

  const playRainbowSound = useCallback(() => {
    playTone(523.25, 0.1, 'triangle', 0.3, 0);
    playTone(659.25, 0.1, 'triangle', 0.3, 0.07);
    playTone(783.99, 0.1, 'triangle', 0.3, 0.14);
    playTone(1046.5, 0.1, 'triangle', 0.3, 0.21);
    playTone(1318.51, 0.15, 'sine', 0.35, 0.28);
    playTone(1567.98, 0.35, 'sine', 0.4, 0.35);
  }, [playTone]);

  const playRecordSound = useCallback(() => {
    playTone(523.3, 0.1, 'triangle', 0.28, 0);
    playTone(659.3, 0.1, 'triangle', 0.28, 0.08);
    playTone(783.9, 0.1, 'triangle', 0.3, 0.16);
    playTone(1046.5, 0.3, 'sine', 0.35, 0.24);
  }, [playTone]);

  // Load Image Assets on mount
  useEffect(() => {
    loadGameAssets().then((assets) => {
      assetsRef.current = assets;
    });
  }, []);

  // Compute Layout for canvas
  const computeLayout = useCallback((w: number, h: number): Layout => {
    const padX = w * 0.07;
    const top = h * 0.20;
    const bottom = h * 0.05;
    const gridW = w - padX * 2;
    const gridH = h - top - bottom;
    const cw = gridW / 3;
    const ch = gridH / 3;
    const cells: Cell[] = [];
    for (let i = 0; i < 9; i++) {
      const col = i % 3;
      const row = Math.floor(i / 3);
      cells.push({
        cx: padX + cw * (col + 0.5),
        cy: top + ch * (row + 0.78),
      });
    }
    return {
      cells,
      cw,
      ch,
      top,
      rx: Math.min(cw * 0.40, ch * 0.46),
      ry: Math.min(cw * 0.40, ch * 0.46) * 0.42,
      rise: ch * 0.66,
      horizon: h * 0.30,
    };
  }, []);

  // Handle Resize
  useEffect(() => {
    const handleResize = () => {
      if (!stageRef.current || !canvasRef.current) return;
      const rect = stageRef.current.getBoundingClientRect();
      const w = Math.max(200, Math.round(rect.width));
      const h = Math.max(240, Math.round(rect.height));
      const dpr = Math.min(3, window.devicePixelRatio || 1);

      const cv = canvasRef.current;
      cv.width = Math.round(w * dpr);
      cv.height = Math.round(h * dpr);
      const ctx = cv.getContext('2d');
      if (ctx) {
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      }
      gameRef.current.layout = computeLayout(w, h);
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    window.addEventListener('orientationchange', handleResize);
    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('orientationchange', handleResize);
    };
  }, [computeLayout]);

  // Show Banner Notification
  const triggerBanner = useCallback((text: string) => {
    setBannerText(text);
    setTimeout(() => {
      setBannerText((prev) => (prev === text ? null : prev));
    }, 2000);
  }, []);

  // Multiplier calculation
  const getMultiplier = (currentCombo: number) => Math.min(8, 1 + Math.floor(currentCombo / 3));

  // Add Particle Effect
  const addParticles = (x: number, y: number, n: number, colors: string[], power: number, kind: 'dot' | 'star' | 'smoke') => {
    const g = gameRef.current;
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      const sp = (0.4 + Math.random()) * power;
      g.particles.push({
        x,
        y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp - power * 0.5,
        life: 0.45 + Math.random() * 0.45,
        maxLife: 0.9,
        r: (kind === 'smoke' ? 7 : 3) + Math.random() * 5,
        c: colors[Math.floor(Math.random() * colors.length)],
        kind,
        rot: Math.random() * 6.3,
        vr: (Math.random() - 0.5) * 12,
      });
    }
    if (g.particles.length > 300) {
      g.particles.splice(0, g.particles.length - 300);
    }
  };

  // Add Floating Pop Text
  const addPop = (x: number, y: number, text: string, color: string, size = 26) => {
    const g = gameRef.current;
    g.pops.push({
      x,
      y,
      text,
      color,
      life: 0.95,
      size,
      vy: -60,
    });
    if (g.pops.length > 24) g.pops.shift();
  };

  const molePop = (m: Hole): number => {
    if (m.state === 'hit') return 1;
    if (m.state !== 'up') return 0.20;
    const isRainbow = m.type === 'rainbow';
    const isGold = m.type === 'gold';
    const riseT = isRainbow ? 0.05 : isGold ? 0.09 : 0.14;
    const sinkT = isRainbow ? 0.07 : isGold ? 0.12 : 0.18;
    if (m.time < riseT) {
      const k = m.time / riseT;
      return 0.20 + 0.80 * (1 - Math.pow(1 - k, 3));
    }
    if (m.time > m.dur - sinkT) {
      const k2 = Math.max(0, (m.dur - m.time) / sinkT);
      return 0.20 + 0.80 * (k2 * k2);
    }
    return 1;
  };

  // Trigger GameOver
  const triggerGameOver = useCallback(() => {
    const g = gameRef.current;
    g.state = 'OVER';
    setGameState('OVER');
    playOverSound();

    const isNew = g.score > bestScore;
    if (isNew) {
      setBestScore(g.score);
      try {
        localStorage.setItem(BEST_KEY, String(g.score));
      } catch {}
      playRecordSound();
    }

    const acc = g.swings > 0 ? Math.round((g.hits / g.swings) * 100) : 0;
    let grade = 'C';
    let gradeName = '초보 망치꾼';
    let regret = '조금 더 연습해봐요!';

    if (g.score >= 800) {
      grade = 'S+';
      gradeName = '두더지 신';
      regret = '완벽한 두더지 퇴치!';
    } else if (g.score >= 500) {
      grade = 'S';
      gradeName = '두더지 대왕';
      regret = '대단한 순발력이에요!';
    } else if (g.score >= 300) {
      grade = 'A';
      gradeName = '망치 달인';
      regret = '훌륭한 성적입니다!';
    } else if (g.score >= 150) {
      grade = 'B';
      gradeName = '숙련된 사냥꾼';
      regret = '아깝다! 조금만 더!';
    }

    setFinalStats({
      score: g.score,
      grade,
      gradeName,
      regret: isNew ? '🎉 축하합니다! 최고 기록 달성!' : regret,
      accuracy: acc,
      isNewBest: isNew,
    });
  }, [bestScore, playOverSound, playRecordSound]);

  // Hit Mole Logic
  const hitMole = (idx: number) => {
    const g = gameRef.current;
    const m = g.holes[idx];
    const L = g.layout;
    if (!L) return;

    const c = L.cells[idx];
    const pop = molePop(m);
    const mx = c.cx;
    const my = c.cy - L.rise * pop * 0.55;

    const actualType = m.type;

    if (actualType === 'rainbow') {
      g.score = 9999;
      setScore(9999);
      g.combo += 1;
      if (g.combo > g.maxCombo) g.maxCombo = g.combo;
      g.hits += 1;
      setCombo(g.combo);
      setMaxCombo(g.maxCombo);

      m.state = 'hit';
      m.hitTime = 0;
      g.hitstop = 0.12;
      g.shake = Math.min(26, g.shake + 24);
      g.flash = 0.55;
      g.flashColor = '255,200,240';

      addParticles(mx, my, 45, ['#ff4d4d', '#ff9f43', '#ffe066', '#1dd1a1', '#48dbfb', '#9c88ff', '#ffffff'], 380, 'star');
      addPop(mx, my - 20, '💯 만점! 9999점!', '#ffe066', 42);
      playRainbowSound();
      triggerBanner('🎉 만점 달성! 무지개 두더지 퇴치!');
      return;
    }

    if (actualType === 'bomb') {
      m.state = 'hit';
      m.hitTime = 0;
      g.score = Math.max(0, g.score - 20);
      g.lives -= 1;
      g.combo = 0;
      setScore(g.score);
      setLives(g.lives);
      setCombo(0);
      setShowComboPop(false);

      g.shake = Math.min(26, g.shake + 22);
      g.flash = 0.6;
      g.flashColor = '255,80,80';
      g.hitstop = 0.09;

      addParticles(mx, my, 26, ['#ff5252', '#ffb703', '#333333', '#888888'], 320, 'smoke');
      addPop(mx, my - 15, '-20 (목숨 -1)', '#ff6b6b', 32);
      playBombSound();

      if (g.lives <= 0) {
        setTimeout(() => triggerGameOver(), 260);
      }
      return;
    }

    // Normal or Gold Mole Hit
    g.combo += 1;
    if (g.combo > g.maxCombo) g.maxCombo = g.combo;
    g.hits += 1;

    const base = actualType === 'gold' ? 50 : 10;
    const gain = base * getMultiplier(g.combo);
    g.score += gain;

    setScore(g.score);
    setCombo(g.combo);
    setMaxCombo(g.maxCombo);

    m.state = 'hit';
    m.hitTime = 0;
    g.hitstop = actualType === 'gold' ? 0.075 : 0.05;
    g.shake = Math.min(26, g.shake + (actualType === 'gold' ? 12 : 6));

    if (actualType === 'gold') {
      g.flash = 0.35;
      g.flashColor = '255,220,120';
      addParticles(mx, my, 28, ['#ffe066', '#fff3b0', '#ffd166', '#ffffff'], 300, 'star');
      addPop(mx, my - 15, `+${gain}`, '#ffe066', 38);
      playGoldSound();
    } else {
      addParticles(mx, my, 18, ['#c98a4b', '#8b5a2b', '#ffe066', '#ffffff'], 240, 'dot');
      addPop(mx, my - 15, `+${gain}`, '#ffffff', 28);
      playHitSound(g.combo);
    }

    if (g.combo >= 2) {
      setShowComboPop(true);
    }

    if (g.combo % 5 === 0) {
      const bonus = g.combo * 5;
      g.score += bonus;
      setScore(g.score);
      addPop(mx, my - 45, `${g.combo}연속 보너스! +${bonus}`, '#7dffb0', 26);
      addParticles(mx, my - 30, 20, ['#7dffb0', '#ffe066', '#ffffff'], 260, 'star');
      g.flash = 0.22;
      g.flashColor = '160,255,200';
      playComboSound(Math.floor(g.combo / 5));
      triggerBanner(`🔥 ${g.combo}연속 콤보! 배율 x${getMultiplier(g.combo)}`);
    }
  };

  // Swing at coordinates
  const swingAt = (x: number, y: number, fromKey: boolean) => {
    const g = gameRef.current;
    if (g.state !== 'PLAY') return;

    g.swings += 1;
    g.hammer.x = x;
    g.hammer.y = y;
    g.hammer.swing = 0.001;
    g.hammer.show = 1;

    const L = g.layout;
    if (!L) return;

    let found = -1;
    let bestD = 1e9;

    for (let i = 0; i < 9; i++) {
      const m = g.holes[i];
      if (m.state !== 'up') continue;
      const p = molePop(m);
      if (p < 0.20) continue;
      const c = L.cells[i];
      const my = c.cy - L.rise * p * 0.55;
      const dx = (x - c.cx) / (L.cw * 0.54);
      const dy = (y - my) / (L.ch * 0.48);
      const d = dx * dx + dy * dy;
      if (d <= 1 && d < bestD) {
        bestD = d;
        found = i;
      }
    }

    if (found >= 0) {
      hitMole(found);
      return;
    }

    // Missed Swing
    g.combo = 0;
    setCombo(0);
    setShowComboPop(false);
    playMissSound();
    addParticles(x, y, 7, ['#ffffff', '#cfe8ff'], 130, 'dot');
    if (!fromKey) {
      addPop(x, y - 6, '헛스윙!', 'rgba(255,255,255,.75)', 18);
    }
    g.shake = Math.min(26, g.shake + 3);
  };

  // Reset Game
  const resetGame = () => {
    const g = gameRef.current;
    for (let i = 0; i < 9; i++) {
      g.holes[i] = {
        state: 'idle',
        type: 'normal',
        time: 0,
        dur: 1,
        hitTime: 0,
        seed: Math.random() * 10,
        disguised: false,
        transformed: false,
      };
    }
    g.score = 0;
    g.lives = 2;
    g.combo = 0;
    g.maxCombo = 0;
    g.swings = 0;
    g.hits = 0;
    g.timeLeft = 60;
    g.elapsed = 0;
    g.spawnTimer = 0.35;
    g.rainbowSpawned = false;
    g.shake = 0;
    g.hitstop = 0;
    g.flash = 0;
    g.particles = [];
    g.pops = [];
    g.lastTickSec = -1;
    g.events = [
      { t: 10, text: '✨ 황금 두더지 등장! 아주 빨라요!', done: false },
      { t: 20, text: '💣 폭탄 두더지 조심! 1, 4, 6번 위장 주의!', done: false },
      { t: 30, text: '🔥 두더지 러시! 출현 속도 가속!', done: false },
      { t: 45, text: '🌟 황금 폭풍! 점수 대역전의 찬스!', done: false },
      { t: 55, text: '⚡ 마지막 5초! 초광속 무지개 두더지 출현!', done: false },
    ];

    setScore(0);
    setLives(2);
    setTimeLeft(60);
    setCombo(0);
    setMaxCombo(0);
    setShowComboPop(false);
  };

  // Start Game
  const startGame = () => {
    initAudio();
    resetGame();
    gameRef.current.state = 'PLAY';
    setGameState('PLAY');
    playStartSound();
  };

  // Keyboard Shortcuts (1~9 to hit holes, Space to start)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space') {
        if (gameRef.current.state === 'TITLE' || gameRef.current.state === 'OVER') {
          e.preventDefault();
          startGame();
        }
      } else if (e.key >= '1' && e.key <= '9') {
        if (gameRef.current.state === 'PLAY' && gameRef.current.layout) {
          const idx = parseInt(e.key, 10) - 1;
          const cell = gameRef.current.layout.cells[idx];
          if (cell) {
            swingAt(cell.cx, cell.cy - 12, true);
          }
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Main Animation Loop
  useEffect(() => {
    let animId: number;
    let lastT = performance.now();

    const loop = (now: number) => {
      const dt = Math.min(0.1, (now - lastT) / 1000);
      lastT = now;

      const g = gameRef.current;
      const cv = canvasRef.current;
      const ctx = cv?.getContext('2d');
      const L = g.layout;

      // Update State
      g.bgTime += dt;
      if (g.shake > 0) g.shake = Math.max(0, g.shake - dt * 60);
      if (g.flash > 0) g.flash = Math.max(0, g.flash - dt * 2.6);
      if (g.hammer.show > 0) g.hammer.show = Math.max(0, g.hammer.show - dt * 1.6);
      if (g.hammer.swing > 0) {
        g.hammer.swing += dt;
        if (g.hammer.swing > 0.26) g.hammer.swing = 0;
      }

      // Update particles
      for (let i = g.particles.length - 1; i >= 0; i--) {
        const p = g.particles[i];
        p.life -= dt;
        if (p.life <= 0) {
          g.particles.splice(i, 1);
          continue;
        }
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        p.vy += (p.kind === 'smoke' ? -180 : 850) * dt;
        p.vx *= 0.99;
        p.rot += p.vr * dt;
      }

      // Update Pops
      for (let i = g.pops.length - 1; i >= 0; i--) {
        const q = g.pops[i];
        q.life -= dt;
        if (q.life <= 0) {
          g.pops.splice(i, 1);
          continue;
        }
        q.y += q.vy * dt;
        q.vy *= 0.94;
      }

      if (g.state === 'TITLE') {
        // Subtle mole popups in title screen
        g.spawnTimer -= dt;
        if (g.spawnTimer <= 0) {
          g.spawnTimer = 0.55 + Math.random() * 0.5;
          const activeCount = g.holes.filter((h) => h.state === 'up').length;
          if (activeCount < 3) {
            const free = g.holes.map((h, idx) => (h.state === 'idle' ? idx : -1)).filter((idx) => idx !== -1);
            if (free.length) {
              const idx = free[Math.floor(Math.random() * free.length)];
              const mm = g.holes[idx];
              mm.state = 'up';
              mm.time = 0;
              mm.dur = 1.2 + Math.random() * 0.8;
              mm.type = Math.random() < 0.2 ? 'gold' : 'normal';
              mm.seed = Math.random() * 10;
            }
          }
        }
        for (let i = 0; i < 9; i++) {
          const tm = g.holes[i];
          if (tm.state === 'up') {
            tm.time += dt;
            if (tm.time >= tm.dur) {
              tm.state = 'idle';
              tm.time = 0;
            }
          }
        }
      } else if (g.state === 'PLAY') {
        let actualDt = dt;
        if (g.hitstop > 0) {
          g.hitstop -= dt;
          actualDt = dt * 0.06;
        }

        g.elapsed += actualDt;
        g.timeLeft -= actualDt;
        setTimeLeft(Math.max(0, Math.ceil(g.timeLeft)));

        if (g.timeLeft <= 0) {
          g.timeLeft = 0;
          triggerGameOver();
        }

        // Ticking audio in last 10 seconds
        const sec = Math.ceil(g.timeLeft);
        if (g.timeLeft <= 10 && sec !== g.lastTickSec && sec >= 0) {
          g.lastTickSec = sec;
          playTone(sec <= 3 ? 1046 : 880, 0.07, 'square', 0.18, 0);
        }

        // Event triggers
        for (let i = 0; i < g.events.length; i++) {
          if (!g.events[i].done && g.elapsed >= g.events[i].t) {
            g.events[i].done = true;
            triggerBanner(g.events[i].text);
            g.flash = 0.25;
            g.flashColor = '255,240,180';
            playComboSound(2);
          }
        }

        // Rainbow Mole Spawn at last 5 seconds (Ultra Fast! 0.85s popup duration, re-emerges if missed!)
        if (g.timeLeft <= 5 && g.score < 9999 && L) {
          const hasRainbowUp = g.holes.some((h) => h.type === 'rainbow' && (h.state === 'up' || h.state === 'hit'));
          if (!hasRainbowUp && g.timeLeft > 0.4) {
            if (!g.rainbowSpawned) {
              g.rainbowSpawned = true;
              triggerBanner('⚡ [초광속] 3번 구멍 무지개 두더지 출현!! 번개처럼 때려라!');
              playRainbowSound();
            }
            // Candidate holes: 3번 구멍(index 2) 우선, 놓칠 시 신속하게 재출현
            const candidateHoles = [2, 4, 2, 6];
            const targetIdx = candidateHoles[Math.floor((5 - g.timeLeft) * 1.5) % candidateHoles.length];
            const mR = g.holes[targetIdx];
            if (mR && mR.state === 'idle') {
              mR.type = 'rainbow';
              mR.state = 'up';
              mR.time = 0;
              mR.dur = 0.85; // 0.85초만에 쏙 들어가는 초광속 스피드!
              mR.disguised = false;
              mR.transformed = true;
              const cR = L.cells[targetIdx];
              addParticles(cR.cx, cR.cy - 20, 30, ['#ff4d4d', '#ff9f43', '#ffe066', '#1dd1a1', '#48dbfb', '#9c88ff'], 360, 'star');
              addPop(cR.cx, cR.cy - 15, '⚡ 초광속!', '#ff75c3', 28);
            }
          }
        }

        // Mole Spawning Logic
        g.spawnTimer -= actualDt;
        if (g.spawnTimer <= 0) {
          const progressRatio = Math.max(0, Math.min(1, g.elapsed / 60));
          let interval = 1.05 - 0.66 * progressRatio;
          if (g.elapsed >= 30) interval *= 0.78;
          if (g.elapsed >= 45) interval *= 0.88;
          g.spawnTimer = Math.max(0.22, interval);

          // Max active count
          let maxAct = 1 + Math.floor(progressRatio * 3);
          if (g.elapsed >= 30) maxAct += 1;
          const activeCount = g.holes.filter((h) => h.state === 'up').length;

          if (activeCount < Math.min(5, maxAct)) {
            const free = g.holes.map((h, idx) => (h.state === 'idle' ? idx : -1)).filter((idx) => idx !== -1);
            if (free.length > 0) {
              const idx = free[Math.floor(Math.random() * free.length)];
              const m = g.holes[idx];
              // Pick type
              let t: MoleType = 'normal';
              if (g.elapsed >= 10) {
                const r = Math.random();
                const goldP = g.elapsed >= 45 ? 0.22 : 0.10;
                const bombP = g.elapsed >= 20 ? (g.elapsed >= 30 ? 0.20 : 0.15) : 0;
                if (r < goldP) t = 'gold';
                else if (r < goldP + bombP) t = 'bomb';
              }

              m.type = t;
              m.state = 'up';
              m.time = 0;
              m.hitTime = 0;
              m.seed = Math.random() * 10;

              // Duration
              if (t === 'gold') m.dur = 0.75 - 0.20 * progressRatio;
              else if (t === 'bomb') m.dur = 1.30 - 0.35 * progressRatio;
              else m.dur = Math.max(0.75, 1.55 - 0.80 * progressRatio);

              // 1번(0), 4번(3), 6번(5) 구멍 폭탄 위장
              if (t === 'bomb' && (idx === 0 || idx === 3 || idx === 5)) {
                m.disguised = true;
                m.transformed = false;
              } else {
                m.disguised = false;
                m.transformed = false;
              }
            }
          }
        }

        // Update mole timers and disguise transforms
        for (let i = 0; i < 9; i++) {
          const m = g.holes[i];
          if (m.state === 'up') {
            m.time += actualDt;

            // Disguised bomb transformation into bomb sprite
            if (m.type === 'bomb' && m.disguised && !m.transformed && m.time >= m.dur * 0.35 && L) {
              m.disguised = false;
              m.transformed = true;
              const cTr = L.cells[i];
              const popTr = molePop(m);
              const mxTr = cTr.cx;
              const myTr = cTr.cy - L.rise * popTr * 0.55;
              addParticles(mxTr, myTr, 18, ['#ff5252', '#ffb703', '#333333', '#ffffff'], 220, 'smoke');
              addPop(mxTr, myTr - 15, '💣 폭탄 변신!', '#ff5252', 24);
              playTone(800, 0.08, 'sawtooth', 0.25, 0, 200);
            }

            if (m.time >= m.dur) {
              m.state = 'idle';
              m.time = 0;
            }
          } else if (m.state === 'hit') {
            m.hitTime += actualDt;
            if (m.hitTime > 0.35) {
              m.state = 'idle';
              m.time = 0;
            }
          }
        }
      }

      // ================= DRAW CANVAS =================
      if (ctx && cv && L) {
        const W = cv.width / (window.devicePixelRatio || 1);
        const H = cv.height / (window.devicePixelRatio || 1);
        const assets = assetsRef.current;

        ctx.save();

        // Screen Shake
        if (g.shake > 0) {
          const sx = (Math.random() - 0.5) * g.shake;
          const sy = (Math.random() - 0.5) * g.shake;
          ctx.translate(sx, sy);
        }

        // Draw Stage Background (Using generated garden background asset if available)
        if (assets && assets.gardenBg && assets.gardenBg.complete) {
          ctx.drawImage(assets.gardenBg, 0, 0, W, H);
          // Darken bottom grassy ground for holes visibility
          const groundGrad = ctx.createLinearGradient(0, H * 0.22, 0, H);
          groundGrad.addColorStop(0, 'rgba(34, 139, 34, 0.2)');
          groundGrad.addColorStop(0.3, 'rgba(46, 125, 50, 0.7)');
          groundGrad.addColorStop(1, 'rgba(27, 94, 32, 0.95)');
          ctx.fillStyle = groundGrad;
          ctx.fillRect(0, H * 0.20, W, H * 0.80);
        } else {
          // Fallback vector gradient
          const bgGrad = ctx.createLinearGradient(0, 0, 0, H);
          bgGrad.addColorStop(0, '#6fc2ef');
          bgGrad.addColorStop(0.35, '#a1dbf7');
          bgGrad.addColorStop(0.36, '#4caf50');
          bgGrad.addColorStop(1, '#2e7d32');
          ctx.fillStyle = bgGrad;
          ctx.fillRect(0, 0, W, H);
        }

        // Draw 9 Holes and Moles
        for (let i = 0; i < 9; i++) {
          const c = L.cells[i];
          const m = g.holes[i];

          // 1. Hole Dirt Mound & Dark Burrow (Back)
          ctx.save();
          // Dirt mound shadow
          ctx.fillStyle = 'rgba(15, 35, 15, 0.35)';
          ctx.beginPath();
          ctx.ellipse(c.cx, c.cy + L.ry * 0.3, L.rx * 1.25, L.ry * 1.1, 0, 0, Math.PI * 2);
          ctx.fill();

          // Outer hole rim
          ctx.fillStyle = '#4e2d08';
          ctx.beginPath();
          ctx.ellipse(c.cx, c.cy, L.rx * 1.08, L.ry * 1.05, 0, 0, Math.PI * 2);
          ctx.fill();

          // Deep hole darkness
          ctx.fillStyle = '#180a00';
          ctx.beginPath();
          ctx.ellipse(c.cx, c.cy + L.ry * 0.15, L.rx * 0.90, L.ry * 0.75, 0, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();

          // 2. Mole Sprite Rising (Clipped inside hole)
          const pop = molePop(m);
          if (pop > 0 || m.state === 'hit') {
            ctx.save();
            // Hole clipping mask: Only show above the inner bottom rim
            ctx.beginPath();
            ctx.rect(c.cx - L.rx * 2, 0, L.rx * 4, c.cy + L.ry * 0.35);
            ctx.clip();

            const renderType = m.type === 'bomb' && m.disguised ? 'normal' : m.type;
            const riseOffset = L.rise * pop;
            const mx = c.cx;
            const my = c.cy + L.ry * 0.2 - riseOffset;
            const mw = L.rx * 1.6;
            const mh = L.ry * 3.0;

            // Pick corresponding image asset
            let moleImg: HTMLImageElement | null = null;
            if (assets) {
              if (renderType === 'gold' && assets.goldenMole?.complete) moleImg = assets.goldenMole;
              else if (renderType === 'bomb' && assets.bombMole?.complete) moleImg = assets.bombMole;
              else if (renderType === 'rainbow' && assets.rainbowMole?.complete) moleImg = assets.rainbowMole;
              else if (assets.normalMole?.complete) moleImg = assets.normalMole;
            }

            ctx.save();
            ctx.translate(mx, my);

            // Wobble / Hit Animation
            if (m.state === 'hit') {
              const hitRot = Math.sin(m.hitTime * 40) * 0.25;
              ctx.rotate(hitRot);
              ctx.scale(0.9, 0.85);
            } else {
              // Bouncy breathing
              const bob = Math.sin(g.bgTime * 6 + m.seed) * 0.03;
              ctx.scale(1 + bob, 1 - bob);
            }

            // Draw Sprite or Stylized Fallback
            if (moleImg) {
              // Rounded clip or frame for clean sprite pop
              ctx.drawImage(moleImg, -mw * 0.5, -mh * 0.6, mw, mh);

              // Subtle disguise hint for bomb moles in 1, 4, 6 before transforming!
              if (m.type === 'bomb' && m.disguised) {
                // Subtle glowing red eye spark
                ctx.fillStyle = 'rgba(255, 60, 60, 0.75)';
                ctx.beginPath();
                ctx.arc(-mw * 0.12, -mh * 0.25, 2.5 + Math.sin(g.bgTime * 15) * 1.5, 0, Math.PI * 2);
                ctx.arc(mw * 0.12, -mh * 0.25, 2.5 + Math.sin(g.bgTime * 15) * 1.5, 0, Math.PI * 2);
                ctx.fill();
              }
            } else {
              // Vector Fallback if image not ready yet
              ctx.fillStyle = renderType === 'gold' ? '#f59e0b' : renderType === 'bomb' ? '#1f2937' : '#92400e';
              ctx.beginPath();
              ctx.ellipse(0, 0, mw * 0.45, mh * 0.45, 0, 0, Math.PI * 2);
              ctx.fill();
            }

            // Rainbow Aura Effect for Rainbow Mole (High-speed shimmer & lightning sparks)
            if (renderType === 'rainbow') {
              ctx.strokeStyle = `hsl(${(g.bgTime * 720) % 360}, 100%, 70%)`;
              ctx.lineWidth = 4;
              ctx.beginPath();
              ctx.arc(0, -mh * 0.1, mw * 0.54, 0, Math.PI * 2);
              ctx.stroke();

              // High-speed sparkle line
              ctx.strokeStyle = '#ffffff';
              ctx.lineWidth = 2.5;
              const sparkA = (g.bgTime * 16) % Math.PI;
              ctx.beginPath();
              ctx.moveTo(Math.cos(sparkA) * mw * 0.6, Math.sin(sparkA) * mh * 0.4);
              ctx.lineTo(Math.cos(sparkA + Math.PI) * mw * 0.6, Math.sin(sparkA + Math.PI) * mh * 0.4);
              ctx.stroke();
            }

            // Hit stars / dizzy effect when hit
            if (m.state === 'hit') {
              ctx.font = 'bold 20px -apple-system, sans-serif';
              ctx.textAlign = 'center';
              ctx.fillText('💫', 0, -mh * 0.6);
            }

            ctx.restore();
            ctx.restore();
          }

          // 3. Hole Front Earth Lip (Overlaps the mole's lower half)
          ctx.save();
          ctx.fillStyle = '#6d3c12';
          ctx.beginPath();
          ctx.ellipse(c.cx, c.cy + L.ry * 0.35, L.rx * 1.05, L.ry * 0.75, 0, 0, Math.PI);
          ctx.fill();

          ctx.fillStyle = '#874f1b';
          ctx.beginPath();
          ctx.ellipse(c.cx, c.cy + L.ry * 0.46, L.rx * 0.88, L.ry * 0.4, 0, 0, Math.PI);
          ctx.fill();

          // Hole Number Badge (1~9 for quick keyboard aid)
          ctx.fillStyle = 'rgba(255, 255, 255, 0.45)';
          ctx.font = 'bold 12px -apple-system, sans-serif';
          ctx.textAlign = 'center';
          ctx.fillText(String(i + 1), c.cx, c.cy + L.ry * 0.85);
          ctx.restore();
        }

        // Draw Particles
        for (let i = 0; i < g.particles.length; i++) {
          const p = g.particles[i];
          ctx.save();
          ctx.globalAlpha = Math.max(0, p.life / p.maxLife);
          ctx.fillStyle = p.c;
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rot);
          if (p.kind === 'star') {
            ctx.beginPath();
            for (let st = 0; st < 5; st++) {
              ctx.lineTo(Math.cos((18 + st * 72) * 0.01745) * p.r, -Math.sin((18 + st * 72) * 0.01745) * p.r);
              ctx.lineTo(Math.cos((54 + st * 72) * 0.01745) * (p.r * 0.4), -Math.sin((54 + st * 72) * 0.01745) * (p.r * 0.4));
            }
            ctx.closePath();
            ctx.fill();
          } else {
            ctx.beginPath();
            ctx.arc(0, 0, p.r, 0, Math.PI * 2);
            ctx.fill();
          }
          ctx.restore();
        }

        // Draw Floating Text Pops
        for (let i = 0; i < g.pops.length; i++) {
          const q = g.pops[i];
          ctx.save();
          ctx.globalAlpha = Math.max(0, q.life / 0.95);
          ctx.font = `900 ${q.size}px -apple-system, sans-serif`;
          ctx.textAlign = 'center';
          ctx.fillStyle = q.color;
          ctx.shadowColor = 'rgba(0,0,0,0.7)';
          ctx.shadowBlur = 6;
          ctx.fillText(q.text, q.x, q.y);
          ctx.restore();
        }

        // Draw Toy Hammer Asset
        if (g.hammer.show > 0 && g.hammer.x > -500) {
          ctx.save();
          ctx.translate(g.hammer.x, g.hammer.y);
          const rot = g.hammer.swing > 0 ? -Math.sin((g.hammer.swing / 0.26) * Math.PI) * 1.15 : -0.25;
          ctx.rotate(rot);

          if (assets && assets.toyHammer?.complete) {
            const hw = 80;
            const hh = 80;
            ctx.drawImage(assets.toyHammer, -hw * 0.45, -hh * 0.85, hw, hh);
          } else {
            // Safe fallback without roundRect to avoid older browser crashes
            ctx.fillStyle = '#8b5a2b';
            ctx.fillRect(-5, -60, 10, 60);
            ctx.fillStyle = '#ef4444';
            ctx.fillRect(-25, -80, 50, 28);
          }
          ctx.restore();
        }

        // Screen Flash Effect
        if (g.flash > 0) {
          ctx.save();
          ctx.globalAlpha = Math.min(0.75, g.flash);
          ctx.fillStyle = `rgb(${g.flashColor})`;
          ctx.fillRect(-20, -20, W + 40, H + 40);
          ctx.restore();
        }

        ctx.restore();
      }

      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [triggerGameOver, playComboSound, playRainbowSound, playTone]);

  // Pointer Interaction Handler (PointerDown prevents duplicate touch/mouse triggers)
  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    initAudio();
    if (gameState !== 'PLAY') return;

    if (!stageRef.current) return;
    const r = stageRef.current.getBoundingClientRect();
    const x = e.clientX - r.left;
    const y = e.clientY - r.top;
    swingAt(x, y, false);
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-slate-950 text-white p-2 font-sans select-none overflow-hidden">
      {/* Outer Phone/Stage Wrapper */}
      <div className="w-full max-w-[460px]">
        <div
          ref={stageRef}
          onPointerDown={handlePointerDown}
          className="relative w-full aspect-[9/11] max-h-[calc(100vh-20px)] mx-auto rounded-3xl overflow-hidden bg-sky-400 shadow-[0_20px_50px_rgba(0,0,0,0.65),0_0_0_3px_rgba(255,255,255,0.15)] touch-none cursor-crosshair"
        >
          {/* Main Game Canvas */}
          <canvas ref={canvasRef} className="block w-full h-full" />

          {/* Top HUD */}
          <div className="absolute left-0 right-0 top-0 pt-2.5 px-3 flex items-center justify-between gap-2 pointer-events-none z-10">
            {/* Score Pill */}
            <div className="bg-slate-900/75 border border-white/25 rounded-2xl px-3 py-1 text-center backdrop-blur-sm shadow-md min-w-[76px]">
              <span className="block text-[10px] tracking-wider text-amber-200/80 font-bold uppercase">점수</span>
              <span className="text-xl font-black text-amber-300 drop-shadow">{score}</span>
            </div>

            {/* Lives Pill */}
            <div className="bg-slate-900/75 border border-white/25 rounded-2xl px-3 py-1 text-center backdrop-blur-sm shadow-md">
              <span className="block text-[10px] tracking-wider text-rose-200/80 font-bold uppercase">목숨</span>
              <div className="flex items-center justify-center gap-1 mt-0.5 text-base">
                {Array.from({ length: 2 }).map((_, i) => (
                  <Heart
                    key={i}
                    size={18}
                    className={i < lives ? 'fill-rose-500 text-rose-400 drop-shadow' : 'fill-slate-700 text-slate-600'}
                  />
                ))}
              </div>
            </div>

            {/* Time Pill */}
            <div className="bg-slate-900/75 border border-white/25 rounded-2xl px-3 py-1 text-center backdrop-blur-sm shadow-md min-w-[76px]">
              <span className="block text-[10px] tracking-wider text-sky-200/80 font-bold uppercase">남은 시간</span>
              <span className={`text-xl font-black drop-shadow ${timeLeft <= 10 ? 'text-rose-400 animate-pulse' : 'text-white'}`}>
                {timeLeft}s
              </span>
            </div>
          </div>

          {/* Time Progress Bar */}
          <div className="absolute left-3 right-3 top-[58px] h-2 rounded-full bg-slate-900/60 border border-white/20 overflow-hidden pointer-events-none z-10">
            <div
              className={`h-full rounded-full transition-all duration-300 ${
                timeLeft <= 10 ? 'bg-gradient-to-r from-orange-500 to-rose-500' : 'bg-gradient-to-r from-emerald-400 to-amber-300'
              }`}
              style={{ width: `${Math.max(0, Math.min(100, (timeLeft / 60) * 100))}%` }}
            />
          </div>

          {/* Dynamic Combo Box */}
          {combo >= 2 && showComboPop && (
            <div className="absolute left-0 right-0 top-[72px] text-center pointer-events-none z-10 animate-bounce">
              <span className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-amber-400/90 text-amber-950 font-black text-sm tracking-wide shadow-lg border border-white/60">
                <Flame size={16} className="fill-amber-600 text-amber-600" />
                {combo} 콤보! (점수 x{getMultiplier(combo)})
              </span>
            </div>
          )}

          {/* Event Banner */}
          {bannerText && (
            <div className="absolute left-0 right-0 top-[38%] px-4 text-center pointer-events-none z-20 animate-fade-in">
              <span className="inline-block bg-gradient-to-b from-amber-100 to-amber-300 text-amber-950 font-black text-sm sm:text-base px-4 py-2 rounded-2xl border-2 border-white shadow-2xl">
                {bannerText}
              </span>
            </div>
          )}

          {/* Mute Button */}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              initAudio();
              setIsMuted((prev) => !prev);
            }}
            className="absolute right-2.5 bottom-2.5 w-10 h-10 rounded-xl border border-white/30 bg-slate-900/70 text-white flex items-center justify-center backdrop-blur-sm cursor-pointer shadow-lg active:scale-95 transition-transform z-30"
            title={isMuted ? '음소거 해제' : '음소거'}
          >
            {isMuted ? <VolumeX size={18} /> : <Volume2 size={18} />}
          </button>

          {/* TITLE SCREEN OVERLAY */}
          {gameState === 'TITLE' && (
            <div className="absolute inset-0 flex flex-col items-center justify-between p-5 bg-slate-950/80 backdrop-blur-sm z-30 text-center animate-fade-in">
              {/* Header Title with Toy Hammer Icon */}
              <div className="pt-2 flex flex-col items-center gap-1">
                <div className="relative mb-1">
                  <img
                    src={GAME_IMAGES.toyHammer}
                    alt="망치"
                    className="w-16 h-16 object-contain rotate-[-12deg] drop-shadow-2xl animate-bounce"
                    referrerPolicy="no-referrer"
                  />
                  <Sparkles size={20} className="absolute -top-1 -right-1 text-amber-300 animate-spin" />
                </div>
                <h1 className="text-3xl sm:text-4xl font-black tracking-tight text-amber-300 drop-shadow-[0_4px_0_#b45309]">
                  두더지 잡기 🔨
                </h1>
                <p className="text-xs sm:text-sm text-slate-200 mt-0.5">
                  튀어나온 두더지를 <b>탕! 탕!</b> 때려라!<br />
                  60초 동안 신나게 스트레스를 날려보세요.
                </p>
              </div>

              {/* Character Guide Cards with Generated Asset Sprites */}
              <div className="w-full bg-white/10 border border-white/20 rounded-2xl p-3 text-left space-y-2 backdrop-blur-md">
                <div className="text-[11px] font-bold text-amber-300 uppercase tracking-wider mb-1 flex items-center gap-1">
                  <Zap size={14} /> 두더지 도감 & 규칙
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  {/* Normal Mole */}
                  <div className="flex items-center gap-2 bg-black/25 rounded-xl p-1.5 border border-white/10">
                    <img
                      src={GAME_IMAGES.normalMole}
                      alt="일반 두더지"
                      className="w-9 h-9 rounded-lg object-cover bg-amber-950/50 border border-white/20"
                      referrerPolicy="no-referrer"
                    />
                    <div>
                      <div className="font-bold text-slate-100">일반 두더지</div>
                      <div className="text-emerald-400 font-semibold text-[11px]">+10점</div>
                    </div>
                  </div>

                  {/* Golden Mole */}
                  <div className="flex items-center gap-2 bg-black/25 rounded-xl p-1.5 border border-amber-400/30">
                    <img
                      src={GAME_IMAGES.goldenMole}
                      alt="황금 두더지"
                      className="w-9 h-9 rounded-lg object-cover bg-amber-950/50 border border-amber-300/40"
                      referrerPolicy="no-referrer"
                    />
                    <div>
                      <div className="font-bold text-amber-300">황금 두더지</div>
                      <div className="text-amber-400 font-semibold text-[11px]">+50점 (초고속)</div>
                    </div>
                  </div>

                  {/* Bomb Mole */}
                  <div className="flex items-center gap-2 bg-black/25 rounded-xl p-1.5 border border-rose-500/30">
                    <img
                      src={GAME_IMAGES.bombMole}
                      alt="폭탄 두더지"
                      className="w-9 h-9 rounded-lg object-cover bg-slate-900 border border-rose-400/30"
                      referrerPolicy="no-referrer"
                    />
                    <div>
                      <div className="font-bold text-rose-300">폭탄 두더지</div>
                      <div className="text-rose-400 font-semibold text-[11px]">-20점 / 목숨 -1</div>
                    </div>
                  </div>

                  {/* Rainbow Mole */}
                  <div className="flex items-center gap-2 bg-black/25 rounded-xl p-1.5 border border-purple-400/30">
                    <img
                      src={GAME_IMAGES.rainbowMole}
                      alt="무지개 두더지"
                      className="w-9 h-9 rounded-lg object-cover bg-indigo-950 border border-purple-300/40"
                      referrerPolicy="no-referrer"
                    />
                    <div>
                      <div className="font-bold text-pink-300">무지개 두더지</div>
                      <div className="text-pink-400 font-semibold text-[11px]">만점 (9999점) / ⚡초광속</div>
                    </div>
                  </div>
                </div>

                <div className="text-[11px] text-amber-200/90 leading-tight pt-1 border-t border-white/10">
                  💡 <b>1, 4, 6번</b> 구멍은 폭탄이 일반 두더지로 위장해 나와요!<br />
                  🌈 <b>마지막 5초!</b> 3번 구멍에 <b>초광속(0.85초)</b> 무지개 두더지가 번개처럼 튀어나와요!
                </div>
              </div>

              {/* Start Button & Controls Hint */}
              <div className="w-full flex flex-col items-center gap-2 pb-2">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    startGame();
                  }}
                  className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-b from-amber-300 to-amber-500 text-amber-950 font-black text-lg shadow-[0_6px_0_#b45309,0_10px_20px_rgba(0,0,0,0.4)] hover:brightness-105 active:translate-y-1 active:shadow-[0_2px_0_#b45309] transition-all cursor-pointer flex items-center justify-center gap-2"
                >
                  <Play size={20} className="fill-amber-950" />
                  게임 시작하기!
                </button>

                <div className="text-[12px] text-slate-300 flex items-center gap-1.5">
                  <Trophy size={14} className="text-amber-400" /> 최고 기록:{' '}
                  <span className="font-bold text-amber-300">{bestScore}점</span>
                </div>
                <div className="text-[11px] text-slate-400">
                  마우스·터치로 두더지 클릭 / 키보드 숫자 <b>1 ~ 9</b>번 지원
                </div>
              </div>
            </div>
          )}

          {/* GAME OVER SCREEN OVERLAY */}
          {gameState === 'OVER' && (
            <div className="absolute inset-0 flex flex-col items-center justify-center p-5 bg-slate-950/85 backdrop-blur-md z-30 text-center gap-3 animate-fade-in">
              {/* Grade & Trophy Badge */}
              <div className="flex flex-col items-center">
                <div className="relative">
                  <div className="text-6xl font-black text-amber-400 drop-shadow-[0_4px_0_#b45309] tracking-tight">
                    {finalStats.grade}
                  </div>
                  {finalStats.isNewBest && (
                    <div className="absolute -top-3 -right-6 px-2 py-0.5 rounded-full bg-rose-500 text-white text-[10px] font-black animate-pulse">
                      NEW!
                    </div>
                  )}
                </div>
                <div className="text-base font-extrabold text-amber-200 mt-1">{finalStats.gradeName}</div>
              </div>

              {/* Final Score Display */}
              <div className="bg-white/10 border border-white/20 rounded-2xl px-6 py-2.5 backdrop-blur-sm">
                <div className="text-xs text-slate-300 uppercase tracking-widest font-bold">최종 점수</div>
                <div className="text-4xl font-black text-amber-300 drop-shadow">{finalStats.score}점</div>
              </div>

              {/* Accuracy & Max Combo */}
              <div className="text-xs text-slate-200 leading-relaxed">
                명중률 <span className="font-bold text-emerald-400">{finalStats.accuracy}%</span> · 최고 콤보{' '}
                <span className="font-bold text-amber-300">{maxCombo}연속</span>
                <div className="font-bold text-amber-200 mt-1">{finalStats.regret}</div>
              </div>

              {/* Play Again Button */}
              <div className="w-full max-w-xs flex flex-col items-center gap-2 mt-2">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    startGame();
                  }}
                  className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-b from-amber-300 to-amber-500 text-amber-950 font-black text-lg shadow-[0_6px_0_#b45309,0_10px_20px_rgba(0,0,0,0.4)] hover:brightness-105 active:translate-y-1 active:shadow-[0_2px_0_#b45309] transition-all cursor-pointer flex items-center justify-center gap-2"
                >
                  <RotateCcw size={20} />
                  한 판 더 하기!
                </button>
                <p className="text-[11px] text-slate-400">스페이스바를 누르거나 화면을 탭해도 다시 시작됩니다</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
