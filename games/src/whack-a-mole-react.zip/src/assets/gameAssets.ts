import normalMoleImg from './images/normal_mole_1789882109053.jpg';
import goldenMoleImg from './images/golden_mole_1789882120753.jpg';
import bombMoleImg from './images/bomb_mole_1789882132319.jpg';
import rainbowMoleImg from './images/rainbow_mole_1789882140395.jpg';
import toyHammerImg from './images/toy_hammer_1789882149975.jpg';
import gardenBgImg from './images/game_garden_bg_1789882162117.jpg';

export const GAME_IMAGES = {
  normalMole: normalMoleImg,
  goldenMole: goldenMoleImg,
  bombMole: bombMoleImg,
  rainbowMole: rainbowMoleImg,
  toyHammer: toyHammerImg,
  gardenBg: gardenBgImg,
};

export type ImageAssets = {
  normalMole: HTMLImageElement;
  goldenMole: HTMLImageElement;
  bombMole: HTMLImageElement;
  rainbowMole: HTMLImageElement;
  toyHammer: HTMLImageElement;
  gardenBg: HTMLImageElement;
};

export function loadGameAssets(): Promise<ImageAssets> {
  return new Promise((resolve) => {
    const assets: Partial<ImageAssets> = {};
    const entries = Object.entries(GAME_IMAGES) as [keyof ImageAssets, string][];
    let loadedCount = 0;

    entries.forEach(([key, src]) => {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.src = src;
      img.onload = () => {
        assets[key] = img;
        loadedCount++;
        if (loadedCount === entries.length) {
          resolve(assets as ImageAssets);
        }
      };
      img.onerror = () => {
        // Fallback: still assign the image so game doesn't stall
        assets[key] = img;
        loadedCount++;
        if (loadedCount === entries.length) {
          resolve(assets as ImageAssets);
        }
      };
    });
  });
}
