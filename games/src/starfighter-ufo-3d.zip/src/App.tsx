import { useCallback, useEffect, useRef, useState } from 'react';
import { StarfighterEngine } from './game/engine';
import {
  CameraMode,
  DEFAULT_SAVE_DATA,
  GameState,
  HudSnapshot,
  SaveData,
  ShipId,
  ShopTab,
} from './game/types';
import { StartScreen } from './components/StartScreen';
import { GameHud } from './components/GameHud';
import { ShopModal } from './components/ShopModal';
import { GameOverScreen } from './components/GameOverScreen';

const STORAGE_KEY = 'starfighter_3d_progress_v2';

function loadSavedProgress(): SaveData {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return { ...DEFAULT_SAVE_DATA, upgrades: { ...DEFAULT_SAVE_DATA.upgrades } };
    const parsed = JSON.parse(raw) as Partial<SaveData>;
    return {
      coins: typeof parsed.coins === 'number' ? parsed.coins : 0,
      highScore: typeof parsed.highScore === 'number' ? parsed.highScore : 0,
      ownedShips:
        Array.isArray(parsed.ownedShips) && parsed.ownedShips.length > 0
          ? (parsed.ownedShips as ShipId[])
          : ['falcon'],
      equippedShipId:
        typeof parsed.equippedShipId === 'string'
          ? (parsed.equippedShipId as ShipId)
          : 'falcon',
      upgrades: {
        ...DEFAULT_SAVE_DATA.upgrades,
        ...(parsed.upgrades || {}),
      },
    };
  } catch {
    return { ...DEFAULT_SAVE_DATA, upgrades: { ...DEFAULT_SAVE_DATA.upgrades } };
  }
}

function saveProgressToStorage(data: SaveData): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch {
    // Ignore storage quota errors
  }
}

export default function App() {
  const canvasMountRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<StarfighterEngine | null>(null);

  const [initialSave] = useState<SaveData>(() => loadSavedProgress());
  const [save, setSave] = useState<SaveData>(initialSave);
  const [ready, setReady] = useState(false);
  const [engineError, setEngineError] = useState<string | null>(null);

  const [gameState, setGameState] = useState<GameState>('START');
  const [shopOpenOnOverlay, setShopOpenOnOverlay] = useState(false);
  const [shopTab, setShopTab] = useState<ShopTab>('ships');
  const [cameraMode, setCameraMode] = useState<CameraMode>('ANGLED');
  const [isMuted, setIsMuted] = useState(false);

  const [hud, setHud] = useState<HudSnapshot>({
    score: 0,
    coins: initialSave.coins,
    highScore: initialSave.highScore,
    level: 1,
    hp: 3,
    maxHp: 5,
    powerLevel: initialSave.upgrades.weapon,
    shieldActive: initialSave.upgrades.shield,
    ultCharge: 0,
    ultActive: false,
    bossActive: false,
    bossHp: 1,
    bossMaxHp: 1,
    bossWarningVisible: false,
    equippedShipId: initialSave.equippedShipId,
  });

  useEffect(() => {
    const mountEl = canvasMountRef.current;
    if (!mountEl) return;

    const engine = new StarfighterEngine(mountEl, initialSave, {
      onHudUpdate: (snapshot) => {
        setHud(snapshot);
      },
      onGameStateChange: (nextState) => {
        setGameState(nextState);
        if (nextState !== 'PAUSED') {
          setShopOpenOnOverlay(false);
        }
      },
      onSaveProgress: (nextSave) => {
        setSave(nextSave);
        saveProgressToStorage(nextSave);
      },
      onReady: () => {
        setReady(true);
      },
      onError: (msg) => {
        setEngineError(msg);
      },
    });

    engineRef.current = engine;

    return () => {
      engine.dispose();
      engineRef.current = null;
    };
  }, [initialSave]);

  const handleStartGame = useCallback(() => {
    setShopOpenOnOverlay(false);
    engineRef.current?.startGame();
  }, []);

  const handleOpenShopFromBattle = useCallback(() => {
    engineRef.current?.toggleShop();
  }, []);

  const handleCloseShop = useCallback(() => {
    if (gameState === 'PAUSED') {
      engineRef.current?.toggleShop();
    } else {
      setShopOpenOnOverlay(false);
    }
  }, [gameState]);

  const handleToggleCamera = useCallback(() => {
    if (!engineRef.current) return;
    const mode = engineRef.current.toggleCameraMode();
    setCameraMode(mode);
  }, []);

  const handleToggleMute = useCallback(() => {
    if (!engineRef.current) return;
    const muted = engineRef.current.toggleMute();
    setIsMuted(muted);
  }, []);

  const handleActivateUlt = useCallback(() => {
    engineRef.current?.activateUltimate();
  }, []);

  const handleBuyOrEquipShip = useCallback((shipId: ShipId) => {
    const engine = engineRef.current;
    if (!engine) return;
    if (engine.buyOrEquipShip(shipId)) {
      setSave(engine.getSaveSnapshot());
    }
  }, []);

  const handleBuyUpgrade = useCallback(
    (id: 'weapon' | 'fireRate' | 'shield' | 'healAndHp' | 'speed' | 'ultGain') => {
      const engine = engineRef.current;
      if (!engine) return;
      if (engine.buyUpgrade(id)) {
        setSave(engine.getSaveSnapshot());
      }
    },
    []
  );

  const isShopVisible = gameState === 'PAUSED' || shopOpenOnOverlay;

  return (
    <main className="relative w-screen h-screen overflow-hidden bg-[#02050d]">
      {/* Dedicated WebGL Mount Container (never unmounted on React state changes) */}
      <div ref={canvasMountRef} className="absolute inset-0 w-full h-full" />

      {engineError && (
        <div className="absolute inset-0 z-40 flex items-center justify-center p-6 bg-[#02050d]/95 text-center">
          <div className="max-w-md bg-slate-900 border border-rose-500/50 rounded-2xl p-6">
            <h2 className="text-xl font-bold text-rose-400 mb-2">3D 그래픽 초기화 오류</h2>
            <p className="text-sm text-slate-300">{engineError}</p>
          </div>
        </div>
      )}

      {(gameState === 'PLAYING' || gameState === 'PAUSED') && (
        <GameHud
          hud={hud}
          cameraMode={cameraMode}
          isMuted={isMuted}
          onOpenShop={handleOpenShopFromBattle}
          onToggleCamera={handleToggleCamera}
          onToggleMute={handleToggleMute}
          onActivateUlt={handleActivateUlt}
        />
      )}

      {gameState === 'START' && !shopOpenOnOverlay && (
        <StartScreen
          coins={save.coins}
          highScore={save.highScore}
          equippedShipId={save.equippedShipId}
          ready={ready}
          onStart={handleStartGame}
          onOpenShop={() => setShopOpenOnOverlay(true)}
        />
      )}

      {gameState === 'GAMEOVER' && !shopOpenOnOverlay && (
        <GameOverScreen
          score={hud.score}
          coins={save.coins}
          highScore={save.highScore}
          onRestart={handleStartGame}
          onOpenShop={() => setShopOpenOnOverlay(true)}
        />
      )}

      {isShopVisible && (
        <ShopModal
          save={save}
          hud={hud}
          activeTab={shopTab}
          inBattle={gameState === 'PAUSED'}
          onChangeTab={setShopTab}
          onBuyOrEquipShip={handleBuyOrEquipShip}
          onBuyUpgrade={handleBuyUpgrade}
          onClose={handleCloseShop}
        />
      )}
    </main>
  );
}
