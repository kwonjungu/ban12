import * as THREE from 'three';
import { GENERATED_ASSETS, SHIPS_CATALOG } from './types';

export interface GameTextureSet {
  spaceBackdrop: THREE.Texture;
  spaceFloor: THREE.Texture;
  ships: Record<string, THREE.Texture>;
  ufoBasic: THREE.Texture;
  ufoFast: THREE.Texture;
  ufoHeavy: THREE.Texture;
  bossMothership: THREE.Texture;
  powerupWeapon: THREE.Texture;
  powerupHealth: THREE.Texture;
  vfxExplosion: THREE.Texture;
  vfxShieldOrb: THREE.Texture;
  laserBolt: THREE.Texture;
  enemyBolt: THREE.Texture;
}

function loadImage(url: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = (err) => reject(err);
    img.src = url;
  });
}

/**
 * Flood-fills exterior black pixels (#000000 background) from image borders
 * so internal dark metallic details stay 100% opaque while exterior background
 * becomes cleanly transparent with a 1px anti-aliased edge feather.
 */
function bakeCutoutCanvasTexture(
  img: HTMLImageElement,
  rotationRad: number,
  scaleFactor: number,
  maxAnisotropy: number,
  blackThreshold = 26,
  size = 512
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');

  if (!ctx) {
    const fallback = new THREE.CanvasTexture(canvas);
    fallback.colorSpace = THREE.SRGBColorSpace;
    return fallback;
  }

  // Fill pure black first so rotated corners match exterior background cleanly
  ctx.fillStyle = '#000000';
  ctx.fillRect(0, 0, size, size);

  ctx.save();
  ctx.translate(size / 2, size / 2);
  if (rotationRad !== 0) {
    ctx.rotate(rotationRad);
  }
  const drawSize = size * scaleFactor;
  ctx.drawImage(img, -drawSize / 2, -drawSize / 2, drawSize, drawSize);
  ctx.restore();

  const imgData = ctx.getImageData(0, 0, size, size);
  const data = imgData.data;
  const totalPixels = size * size;
  const visited = new Uint8Array(totalPixels);
  const isBackground = new Uint8Array(totalPixels);
  const queue = new Int32Array(totalPixels);
  let head = 0;
  let tail = 0;

  const isNearBlack = (idx: number) => {
    const o = idx * 4;
    const r = data[o];
    const g = data[o + 1];
    const b = data[o + 2];
    return r <= blackThreshold && g <= blackThreshold && b <= blackThreshold;
  };

  // Seed flood fill from all 4 outer edges
  for (let x = 0; x < size; x++) {
    const top = x;
    const bottom = (size - 1) * size + x;
    if (!visited[top] && isNearBlack(top)) {
      visited[top] = 1;
      queue[tail++] = top;
    }
    if (!visited[bottom] && isNearBlack(bottom)) {
      visited[bottom] = 1;
      queue[tail++] = bottom;
    }
  }
  for (let y = 1; y < size - 1; y++) {
    const left = y * size;
    const right = y * size + (size - 1);
    if (!visited[left] && isNearBlack(left)) {
      visited[left] = 1;
      queue[tail++] = left;
    }
    if (!visited[right] && isNearBlack(right)) {
      visited[right] = 1;
      queue[tail++] = right;
    }
  }

  while (head < tail) {
    const idx = queue[head++];
    isBackground[idx] = 1;
    data[idx * 4 + 3] = 0;

    const x = idx % size;
    const y = (idx - x) / size;

    if (x > 0) {
      const n = idx - 1;
      if (!visited[n] && isNearBlack(n)) {
        visited[n] = 1;
        queue[tail++] = n;
      }
    }
    if (x < size - 1) {
      const n = idx + 1;
      if (!visited[n] && isNearBlack(n)) {
        visited[n] = 1;
        queue[tail++] = n;
      }
    }
    if (y > 0) {
      const n = idx - size;
      if (!visited[n] && isNearBlack(n)) {
        visited[n] = 1;
        queue[tail++] = n;
      }
    }
    if (y < size - 1) {
      const n = idx + size;
      if (!visited[n] && isNearBlack(n)) {
        visited[n] = 1;
        queue[tail++] = n;
      }
    }
  }

  // Smooth 1px edge feathering on boundary pixels adjacent to transparent background
  for (let y = 1; y < size - 1; y++) {
    for (let x = 1; x < size - 1; x++) {
      const idx = y * size + x;
      if (isBackground[idx]) continue;
      if (
        isBackground[idx - 1] ||
        isBackground[idx + 1] ||
        isBackground[idx - size] ||
        isBackground[idx + size]
      ) {
        const o = idx * 4;
        const maxCh = Math.max(data[o], data[o + 1], data[o + 2]);
        if (maxCh < blackThreshold * 2.2) {
          data[o + 3] = Math.min(255, Math.floor(((maxCh - blackThreshold * 0.6) / (blackThreshold * 1.6)) * 255));
        }
      }
    }
  }

  ctx.putImageData(imgData, 0, 0);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = maxAnisotropy;
  texture.needsUpdate = true;
  return texture;
}

/**
 * Converts a glowing VFX image on pure black into an additive-ready CanvasTexture
 * with smooth luminance-derived alpha for halo-free blending.
 */
function bakeGlowTexture(
  img: HTMLImageElement,
  maxAnisotropy: number,
  size = 512
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');
  if (!ctx) {
    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    return tex;
  }

  ctx.drawImage(img, 0, 0, size, size);
  const imgData = ctx.getImageData(0, 0, size, size);
  const data = imgData.data;

  for (let i = 0; i < data.length; i += 4) {
    const maxCh = Math.max(data[i], data[i + 1], data[i + 2]);
    const alpha = maxCh < 14 ? 0 : Math.min(255, Math.floor((maxCh / 220) * 255));
    data[i + 3] = alpha;
  }

  ctx.putImageData(imgData, 0, 0);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = maxAnisotropy;
  texture.needsUpdate = true;
  return texture;
}

/**
 * Derives crisp projectile textures directly from our generated explosion energy core.
 */
function bakeEnergyBoltTexture(
  glowImg: HTMLImageElement,
  tintHex: string,
  elongated: boolean,
  maxAnisotropy: number
): THREE.CanvasTexture {
  const size = 256;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');
  if (!ctx) {
    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    return tex;
  }

  ctx.save();
  ctx.translate(size / 2, size / 2);
  if (elongated) {
    ctx.scale(0.32, 0.96);
  } else {
    ctx.scale(0.75, 0.75);
  }
  ctx.drawImage(glowImg, -size / 2, -size / 2, size, size);
  ctx.restore();

  ctx.globalCompositeOperation = 'source-atop';
  ctx.fillStyle = tintHex;
  ctx.globalAlpha = 0.65;
  ctx.fillRect(0, 0, size, size);
  ctx.globalCompositeOperation = 'source-over';
  ctx.globalAlpha = 1;

  // Luminance to alpha
  const imgData = ctx.getImageData(0, 0, size, size);
  const data = imgData.data;
  for (let i = 0; i < data.length; i += 4) {
    const maxCh = Math.max(data[i], data[i + 1], data[i + 2]);
    data[i + 3] = maxCh < 16 ? 0 : Math.min(255, Math.floor((maxCh / 190) * 255));
  }
  ctx.putImageData(imgData, 0, 0);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = maxAnisotropy;
  texture.needsUpdate = true;
  return texture;
}

export async function loadAllGameTextures(renderer: THREE.WebGLRenderer): Promise<GameTextureSet> {
  const maxAnisotropy = Math.min(8, renderer.capabilities.getMaxAnisotropy());
  const loader = new THREE.TextureLoader();

  const loadStandardTex = (url: string, repeatX = 1, repeatY = 1) =>
    new Promise<THREE.Texture>((resolve, reject) => {
      loader.load(
        url,
        (tex) => {
          tex.colorSpace = THREE.SRGBColorSpace;
          tex.anisotropy = maxAnisotropy;
          if (repeatX !== 1 || repeatY !== 1) {
            tex.wrapS = THREE.RepeatWrapping;
            tex.wrapT = THREE.RepeatWrapping;
            tex.repeat.set(repeatX, repeatY);
          }
          resolve(tex);
        },
        undefined,
        reject
      );
    });

  const [
    spaceBackdrop,
    spaceFloor,
    ufoBasicImg,
    ufoFastImg,
    ufoHeavyImg,
    bossImg,
    pwWeaponImg,
    pwHealthImg,
    explosionImg,
    shieldImg,
    ...shipImages
  ] = await Promise.all([
    loadStandardTex(GENERATED_ASSETS.spaceNebulaBg),
    loadStandardTex(GENERATED_ASSETS.spaceFloorGrid, 5, 9),
    loadImage(GENERATED_ASSETS.ufoBasic),
    loadImage(GENERATED_ASSETS.ufoFast),
    loadImage(GENERATED_ASSETS.ufoHeavy),
    loadImage(GENERATED_ASSETS.bossMothership),
    loadImage(GENERATED_ASSETS.powerupWeapon),
    loadImage(GENERATED_ASSETS.powerupHealth),
    loadImage(GENERATED_ASSETS.vfxExplosion),
    loadImage(GENERATED_ASSETS.vfxShieldOrb),
    ...SHIPS_CATALOG.map((ship) => loadImage(ship.imageUrl)),
  ]);

  const ships: Record<string, THREE.Texture> = {};
  SHIPS_CATALOG.forEach((ship, index) => {
    ships[ship.id] = bakeCutoutCanvasTexture(
      shipImages[index],
      ship.rotationRad,
      ship.scaleFactor,
      maxAnisotropy,
      26
    );
  });

  return {
    spaceBackdrop,
    spaceFloor,
    ships,
    ufoBasic: bakeCutoutCanvasTexture(ufoBasicImg, 0, 0.9, maxAnisotropy, 24),
    // Fast UFO crescent faces bottom-left in artwork -> rotate -45 deg to dive straight down toward player
    ufoFast: bakeCutoutCanvasTexture(ufoFastImg, -Math.PI / 4, 0.86, maxAnisotropy, 24),
    ufoHeavy: bakeCutoutCanvasTexture(ufoHeavyImg, 0, 0.9, maxAnisotropy, 24),
    bossMothership: bakeCutoutCanvasTexture(bossImg, 0, 0.94, maxAnisotropy, 24),
    powerupWeapon: bakeCutoutCanvasTexture(pwWeaponImg, 0, 0.92, maxAnisotropy, 24),
    powerupHealth: bakeCutoutCanvasTexture(pwHealthImg, 0, 0.92, maxAnisotropy, 24),
    vfxExplosion: bakeGlowTexture(explosionImg, maxAnisotropy),
    vfxShieldOrb: bakeGlowTexture(shieldImg, maxAnisotropy),
    laserBolt: bakeEnergyBoltTexture(explosionImg, '#38bdf8', true, maxAnisotropy),
    enemyBolt: bakeEnergyBoltTexture(explosionImg, '#f43f5e', false, maxAnisotropy),
  };
}

export function disposeGameTextures(textures: GameTextureSet | null): void {
  if (!textures) return;
  textures.spaceBackdrop.dispose();
  textures.spaceFloor.dispose();
  Object.values(textures.ships).forEach((t) => t.dispose());
  textures.ufoBasic.dispose();
  textures.ufoFast.dispose();
  textures.ufoHeavy.dispose();
  textures.bossMothership.dispose();
  textures.powerupWeapon.dispose();
  textures.powerupHealth.dispose();
  textures.vfxExplosion.dispose();
  textures.vfxShieldOrb.dispose();
  textures.laserBolt.dispose();
  textures.enemyBolt.dispose();
}
