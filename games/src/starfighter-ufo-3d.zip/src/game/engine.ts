import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import {
  CameraMode,
  GameState,
  HudSnapshot,
  SaveData,
  SHIPS_CATALOG,
  ShipId,
  UpgradeState,
} from './types';
import { disposeGameTextures, GameTextureSet, loadAllGameTextures } from './assets';
import { SoundManager } from './sound';

const FIELD_HALF_X = 14.5;
const PLAYER_Z = 11.5;
const SPAWN_Z = -48;

interface BulletEntity {
  x: number;
  z: number;
  vx: number;
  vz: number;
  radius: number;
  markedForDeletion: boolean;
  mesh: THREE.Mesh;
}

interface EnemyBulletEntity {
  x: number;
  z: number;
  vx: number;
  vz: number;
  radius: number;
  markedForDeletion: boolean;
  mesh: THREE.Mesh;
}

interface UFOEntity {
  type: 'basic' | 'fast' | 'heavy';
  x: number;
  z: number;
  vx: number;
  vz: number;
  radius: number;
  hp: number;
  maxHp: number;
  points: number;
  hitFlash: number;
  spinAngle: number;
  phaseOffset: number;
  markedForDeletion: boolean;
  group: THREE.Group;
  spriteMat: THREE.MeshBasicMaterial;
  flashMesh: THREE.Mesh;
  shadowMesh: THREE.Mesh;
}

interface BossEntity {
  x: number;
  z: number;
  vx: number;
  targetZ: number;
  radius: number;
  hp: number;
  maxHp: number;
  shootTimer: number;
  hitFlash: number;
  spinAngle: number;
  entering: boolean;
  group: THREE.Group;
  spriteMat: THREE.MeshBasicMaterial;
  flashMesh: THREE.Mesh;
  auraMesh: THREE.Mesh;
}

interface PowerUpEntity {
  type: 'weapon' | 'health';
  x: number;
  z: number;
  vz: number;
  radius: number;
  phaseOffset: number;
  markedForDeletion: boolean;
  group: THREE.Group;
}

interface ExplosionParticle {
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  scale: number;
  growRate: number;
  life: number;
  decay: number;
  mesh: THREE.Mesh;
  mat: THREE.MeshBasicMaterial;
}

export interface EngineCallbacks {
  onHudUpdate: (snapshot: HudSnapshot) => void;
  onGameStateChange: (state: GameState) => void;
  onSaveProgress: (data: SaveData) => void;
  onReady: () => void;
  onError: (msg: string) => void;
}

export class StarfighterEngine {
  private container: HTMLElement;
  private callbacks: EngineCallbacks;
  public sound: SoundManager;

  private isSoftwareGl = false;
  private renderer!: THREE.WebGLRenderer;
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private textures: GameTextureSet | null = null;

  private clock = new THREE.Clock();
  private frameId = 0;
  private disposed = false;

  // Shared geometries for zero-allocation spawns
  private unitPlaneGeo = new THREE.PlaneGeometry(1, 1);
  private shadowCircleGeo = new THREE.CircleGeometry(1, 24);
  private shieldSphereGeo = new THREE.SphereGeometry(2.35, 24, 18);

  // Environment references
  private starGeo!: THREE.BufferGeometry;
  private starCount = 700;
  private floorMesh!: THREE.Mesh;
  private backdropMesh!: THREE.Mesh;

  // Beam VFX
  private beamGroup = new THREE.Group();
  private beamOuterMesh!: THREE.Mesh;
  private beamCoreMesh!: THREE.Mesh;
  private beamRingMesh!: THREE.Mesh;

  // Player state
  private playerGroup = new THREE.Group();
  private playerTiltGroup = new THREE.Group();
  private playerShipMat!: THREE.MeshBasicMaterial;
  private playerThrusterMesh!: THREE.Mesh;
  private playerThrusterMat!: THREE.MeshBasicMaterial;
  private playerShieldMesh!: THREE.Mesh;
  private playerShadowMesh!: THREE.Mesh;

  private playerX = 0;
  private playerZ = PLAYER_Z;
  private playerRadius = 1.4;
  private playerSpeed = 0.35;
  private playerShootInterval = 13;
  private playerShootCooldown = 0;
  private playerHp = 3;
  private playerMaxHp = 5;
  private playerBasePower = 1;
  private playerPowerLevel = 1;
  private playerPowerTimer = 0;
  private playerInvuln = 0;
  private playerBankTilt = 0;
  private playerPitchAngle = -Math.PI / 2.45;

  // Game state
  private gameState: GameState = 'START';
  private cameraMode: CameraMode = 'ANGLED';
  private score = 0;
  private coins = 0;
  private highScore = 0;
  private level = 1;
  private elapsedFrames = 0;
  private spawnTimer = 0;
  private screenShake = 0;
  private nextBossScore = 1500;
  private ultCharge = 0;
  private ultActiveTimer = 0;
  private bossWarningTimer = 0;

  private ownedShips: ShipId[] = ['falcon'];
  private equippedShipId: ShipId = 'falcon';
  private upgrades: UpgradeState = {
    weapon: 1,
    fireRate: 0,
    maxHp: 0,
    speed: 0,
    ultGain: 0,
    shield: false,
  };

  // Entities
  private bullets: BulletEntity[] = [];
  private enemyBullets: EnemyBulletEntity[] = [];
  private ufos: UFOEntity[] = [];
  private boss: BossEntity | null = null;
  private powerUps: PowerUpEntity[] = [];
  private particles: ExplosionParticle[] = [];

  // Input
  private keys: Record<string, boolean> = { AutoFire: true };
  private touchTargetX: number | null = null;
  private isMouseDown = false;
  private lastHudEmit = 0;

  // Bound handlers
  private handleResizeBound: () => void;
  private handleKeyDownBound: (e: KeyboardEvent) => void;
  private handleKeyUpBound: (e: KeyboardEvent) => void;
  private handleTouchStartBound: (e: TouchEvent) => void;
  private handleTouchMoveBound: (e: TouchEvent) => void;
  private handleTouchEndBound: () => void;
  private handleMouseDownBound: (e: MouseEvent) => void;
  private handleMouseMoveBound: (e: MouseEvent) => void;
  private handleMouseUpBound: () => void;
  private handleContextLostBound: (e: Event) => void;
  private handleContextRestoredBound: () => void;

  constructor(container: HTMLElement, initialSave: SaveData, callbacks: EngineCallbacks) {
    this.container = container;
    this.callbacks = callbacks;
    this.sound = new SoundManager();

    this.coins = initialSave.coins;
    this.highScore = initialSave.highScore;
    this.ownedShips = [...initialSave.ownedShips];
    this.equippedShipId = initialSave.equippedShipId;
    this.upgrades = { ...initialSave.upgrades };

    this.handleResizeBound = this.onResize.bind(this);
    this.handleKeyDownBound = this.onKeyDown.bind(this);
    this.handleKeyUpBound = this.onKeyUp.bind(this);
    this.handleTouchStartBound = this.onTouchStart.bind(this);
    this.handleTouchMoveBound = this.onTouchMove.bind(this);
    this.handleTouchEndBound = () => {
      this.touchTargetX = null;
    };
    this.handleMouseDownBound = this.onMouseDown.bind(this);
    this.handleMouseMoveBound = this.onMouseMove.bind(this);
    this.handleMouseUpBound = () => {
      this.isMouseDown = false;
      this.touchTargetX = null;
    };
    this.handleContextLostBound = (e: Event) => {
      e.preventDefault();
    };
    this.handleContextRestoredBound = () => {
      this.applyCameraPosition(0, 0);
    };

    this.initThree().catch((err) => {
      this.callbacks.onError(err instanceof Error ? err.message : '3D 초기화 실패');
    });
  }

  private detectSoftwareGl(): boolean {
    try {
      const probe = document.createElement('canvas').getContext('webgl2');
      if (!probe) return true;
      const ext = probe.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : probe.RENDERER;
      const gpu = String(probe.getParameter(param));
      probe.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    } catch {
      return false;
    }
  }

  private async initThree(): Promise<void> {
    this.isSoftwareGl = this.detectSoftwareGl();

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x02050d);
    this.scene.fog = new THREE.FogExp2(0x02050d, 0.0085);

    const width = this.container.clientWidth || window.innerWidth;
    const height = this.container.clientHeight || window.innerHeight;
    this.camera = new THREE.PerspectiveCamera(60, width / height, 0.1, 240);
    this.applyCameraPosition(0, 0);

    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.1;
    this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    this.renderer.setSize(width, height);
    this.renderer.domElement.style.display = 'block';
    this.renderer.domElement.style.width = '100%';
    this.renderer.domElement.style.height = '100%';

    this.container.appendChild(this.renderer.domElement);

    // Studio environment reflection map
    const pmremGenerator = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // Balanced lighting
    const hemiLight = new THREE.HemisphereLight(0x7dd3fc, 0x0f172a, 1.1);
    this.scene.add(hemiLight);
    const keyLight = new THREE.DirectionalLight(0xfff7ed, 1.2);
    keyLight.position.set(10, 25, 18);
    this.scene.add(keyLight);

    // Load all generated images into GPU textures
    this.textures = await loadAllGameTextures(this.renderer);
    if (this.disposed) {
      disposeGameTextures(this.textures);
      return;
    }

    this.buildEnvironment();
    this.buildPlayerRig();
    this.buildMegaBeam();

    if (!this.isSoftwareGl) {
      this.renderer.compile(this.scene, this.camera);
    }

    this.attachEvents();
    this.applyStats(true);
    this.emitHud(true);
    this.callbacks.onReady();

    this.clock.start();
    this.startLoop();
  }

  private buildEnvironment(): void {
    if (!this.textures) return;

    // 1. Deep space nebula backdrop billboard in far horizon (wide enough for 21:9 in both camera modes)
    const bgGeo = new THREE.PlaneGeometry(300, 170);
    const bgMat = new THREE.MeshBasicMaterial({
      map: this.textures.spaceBackdrop,
      depthWrite: false,
      fog: false,
    });
    this.backdropMesh = new THREE.Mesh(bgGeo, bgMat);
    this.backdropMesh.position.set(0, 14, -100);
    this.scene.add(this.backdropMesh);

    // 2. Seamless scrolling textured orbital deck floor
    const floorTex = this.textures.spaceFloor;
    floorTex.repeat.set(12, 9);
    const floorGeo = new THREE.PlaneGeometry(240, 180);
    floorGeo.rotateX(-Math.PI / 2);
    const floorMat = new THREE.MeshStandardMaterial({
      map: floorTex,
      roughness: 0.45,
      metalness: 0.6,
      emissive: 0x082f49,
      emissiveMap: floorTex,
      emissiveIntensity: 0.55,
    });
    this.floorMesh = new THREE.Mesh(floorGeo, floorMat);
    this.floorMesh.position.set(0, -4.6, -24);
    this.scene.add(this.floorMesh);

    // Subtle playable lane guide rails at x = +/- 15.2
    const railGeo = new THREE.PlaneGeometry(0.18, 120);
    railGeo.rotateX(-Math.PI / 2);
    const railMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.25,
      depthWrite: false,
    });
    const leftRail = new THREE.Mesh(railGeo, railMat);
    leftRail.position.set(-FIELD_HALF_X - 0.8, -4.45, -24);
    const rightRail = new THREE.Mesh(railGeo, railMat);
    rightRail.position.set(FIELD_HALF_X + 0.8, -4.45, -24);
    this.scene.add(leftRail, rightRail);

    // 3. Streaking starfield particles
    this.starGeo = new THREE.BufferGeometry();
    const positions = new Float32Array(this.starCount * 3);
    for (let i = 0; i < this.starCount; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 120;
      positions[i * 3 + 1] = Math.random() * 45 - 3;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 150 - 20;
    }
    this.starGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const starMat = new THREE.PointsMaterial({
      color: 0xe0f2fe,
      size: 0.38,
      transparent: true,
      opacity: 0.85,
    });
    const starField = new THREE.Points(this.starGeo, starMat);
    this.scene.add(starField);
  }

  private buildPlayerRig(): void {
    if (!this.textures) return;

    this.playerGroup.position.set(this.playerX, 0, this.playerZ);

    // Main generated starfighter cutout plane
    this.playerShipMat = new THREE.MeshBasicMaterial({
      map: this.textures.ships[this.equippedShipId],
      transparent: true,
      alphaTest: 0.08,
      side: THREE.DoubleSide,
      depthWrite: true,
    });
    const shipPlane = new THREE.Mesh(this.unitPlaneGeo, this.playerShipMat);
    shipPlane.scale.set(4.8, 4.8, 1);
    shipPlane.rotation.x = this.playerPitchAngle;
    shipPlane.renderOrder = 2;
    this.playerTiltGroup.add(shipPlane);

    // Subtle additive thruster aura behind ship
    const spec = this.getShipSpec();
    this.playerThrusterMat = new THREE.MeshBasicMaterial({
      map: this.textures.vfxExplosion,
      color: spec.thrusterColor,
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      opacity: 0.52,
    });
    this.playerThrusterMesh = new THREE.Mesh(this.unitPlaneGeo, this.playerThrusterMat);
    this.playerThrusterMesh.scale.set(1.3, 1.5, 1);
    this.playerThrusterMesh.rotation.x = this.playerPitchAngle;
    this.playerThrusterMesh.position.set(0, -0.15, 2.35);
    this.playerThrusterMesh.renderOrder = 1;
    this.playerTiltGroup.add(this.playerThrusterMesh);

    // Crisp generated hexagonal energy shield aura plane (no sphere pole UV distortion)
    const shieldMat = new THREE.MeshBasicMaterial({
      map: this.textures.vfxShieldOrb,
      color: 0x38bdf8,
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      opacity: 0.85,
      side: THREE.DoubleSide,
    });
    this.playerShieldMesh = new THREE.Mesh(this.unitPlaneGeo, shieldMat);
    this.playerShieldMesh.scale.set(5.6, 5.6, 1);
    this.playerShieldMesh.rotation.x = this.playerPitchAngle;
    this.playerShieldMesh.position.set(0, 0.25, 0);
    this.playerShieldMesh.visible = this.upgrades.shield;
    this.playerShieldMesh.renderOrder = 4;
    this.playerTiltGroup.add(this.playerShieldMesh);

    this.playerGroup.add(this.playerTiltGroup);

    // Contact shadow / underglow disc on orbital deck
    const shadowMat = new THREE.MeshBasicMaterial({
      color: 0x0284c7,
      transparent: true,
      opacity: 0.35,
      depthWrite: false,
    });
    this.playerShadowMesh = new THREE.Mesh(this.shadowCircleGeo, shadowMat);
    this.playerShadowMesh.rotation.x = -Math.PI / 2;
    this.playerShadowMesh.scale.set(2.2, 2.2, 1);
    this.playerShadowMesh.position.set(0, -4.4, 0);
    this.playerGroup.add(this.playerShadowMesh);

    this.scene.add(this.playerGroup);
  }

  private buildMegaBeam(): void {
    if (!this.textures) return;

    const beamTex = this.textures.vfxExplosion.clone();
    beamTex.wrapS = THREE.RepeatWrapping;
    beamTex.wrapT = THREE.RepeatWrapping;
    beamTex.repeat.set(1, 7);
    beamTex.needsUpdate = true;

    const outerGeo = new THREE.PlaneGeometry(6.8, 74);
    outerGeo.rotateX(-Math.PI / 2);
    const outerMat = new THREE.MeshBasicMaterial({
      map: beamTex,
      color: 0xfacc15,
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      opacity: 0.88,
      side: THREE.DoubleSide,
    });
    this.beamOuterMesh = new THREE.Mesh(outerGeo, outerMat);

    const coreGeo = new THREE.PlaneGeometry(2.8, 74);
    coreGeo.rotateX(-Math.PI / 2);
    const coreMat = new THREE.MeshBasicMaterial({
      map: beamTex,
      color: 0xffffff,
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      opacity: 0.96,
      side: THREE.DoubleSide,
    });
    this.beamCoreMesh = new THREE.Mesh(coreGeo, coreMat);
    this.beamCoreMesh.position.y = 0.15;

    const ringMat = new THREE.MeshBasicMaterial({
      map: this.textures.vfxExplosion,
      color: 0xfde047,
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      opacity: 0.92,
      side: THREE.DoubleSide,
    });
    this.beamRingMesh = new THREE.Mesh(this.unitPlaneGeo, ringMat);
    this.beamRingMesh.scale.set(6.5, 6.5, 1);
    this.beamRingMesh.rotation.x = -Math.PI / 2.6;
    this.beamRingMesh.position.set(0, 0.3, 35);

    this.beamGroup.add(this.beamOuterMesh, this.beamCoreMesh, this.beamRingMesh);
    this.beamGroup.visible = false;
    this.scene.add(this.beamGroup);
  }

  private attachEvents(): void {
    window.addEventListener('resize', this.handleResizeBound);
    window.addEventListener('keydown', this.handleKeyDownBound);
    window.addEventListener('keyup', this.handleKeyUpBound);

    const dom = this.renderer.domElement;
    dom.addEventListener('touchstart', this.handleTouchStartBound, { passive: true });
    dom.addEventListener('touchmove', this.handleTouchMoveBound, { passive: true });
    dom.addEventListener('touchend', this.handleTouchEndBound);
    dom.addEventListener('mousedown', this.handleMouseDownBound);
    window.addEventListener('mousemove', this.handleMouseMoveBound);
    window.addEventListener('mouseup', this.handleMouseUpBound);

    dom.addEventListener('webglcontextlost', this.handleContextLostBound);
    dom.addEventListener('webglcontextrestored', this.handleContextRestoredBound);
  }

  private onResize(): void {
    if (this.disposed) return;
    const w = this.container.clientWidth || window.innerWidth;
    const h = this.container.clientHeight || window.innerHeight;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  }

  private onKeyDown(e: KeyboardEvent): void {
    this.keys[e.code] = true;
    if ((e.code === 'ShiftLeft' || e.code === 'ShiftRight' || e.code === 'KeyB') && this.gameState === 'PLAYING') {
      this.activateUltimate();
    }
    if (e.code === 'KeyP' && (this.gameState === 'PLAYING' || this.gameState === 'PAUSED')) {
      this.toggleShop();
    }
    if (e.code === 'KeyV' && this.gameState === 'PLAYING') {
      this.toggleCameraMode();
    }
  }

  private onKeyUp(e: KeyboardEvent): void {
    this.keys[e.code] = false;
  }

  private screenXToWorldX(clientX: number): number {
    const rect = this.renderer.domElement.getBoundingClientRect();
    const normX = ((clientX - rect.left) / (rect.width || window.innerWidth)) * 2 - 1;
    return normX * FIELD_HALF_X;
  }

  private onTouchStart(e: TouchEvent): void {
    if (this.gameState !== 'PLAYING' || e.touches.length === 0) return;
    this.touchTargetX = this.screenXToWorldX(e.touches[0].clientX);
  }

  private onTouchMove(e: TouchEvent): void {
    if (this.gameState !== 'PLAYING' || e.touches.length === 0) return;
    this.touchTargetX = this.screenXToWorldX(e.touches[0].clientX);
  }

  private onMouseDown(e: MouseEvent): void {
    if (this.gameState !== 'PLAYING') return;
    this.isMouseDown = true;
    this.touchTargetX = this.screenXToWorldX(e.clientX);
  }

  private onMouseMove(e: MouseEvent): void {
    if (this.isMouseDown && this.gameState === 'PLAYING') {
      this.touchTargetX = this.screenXToWorldX(e.clientX);
    }
  }

  private applyCameraPosition(shakeX: number, shakeY: number): void {
    if (!this.camera) return;
    if (this.cameraMode === 'ANGLED') {
      this.camera.position.set(shakeX, 18 + shakeY, 24);
      this.camera.lookAt(0, 0, -6);
    } else {
      this.camera.position.set(shakeX, 9 + shakeY, 21);
      this.camera.lookAt(0, 1, -15);
    }
  }

  private getShipSpec() {
    return SHIPS_CATALOG.find((s) => s.id === this.equippedShipId) || SHIPS_CATALOG[0];
  }

  private applyStats(isInit: boolean): void {
    const ship = this.getShipSpec();
    const prevMaxHp = this.playerMaxHp;

    this.playerSpeed = 0.35 + this.upgrades.speed * 0.06 + ship.bonusSpeed;
    this.playerShootInterval = Math.max(4, 13 - this.upgrades.fireRate * 1.5 - ship.bonusFireRate);
    this.playerMaxHp = 5 + this.upgrades.maxHp + ship.bonusHp;
    this.playerBasePower = Math.min(4, this.upgrades.weapon + ship.bonusWeapon);

    if (isInit) {
      this.playerHp = Math.min(this.playerMaxHp, 3 + this.upgrades.maxHp + ship.bonusHp);
      this.playerPowerLevel = this.playerBasePower;
    } else {
      const hpDiff = this.playerMaxHp - prevMaxHp;
      if (hpDiff > 0) {
        this.playerHp = Math.min(this.playerMaxHp, this.playerHp + hpDiff);
      } else {
        this.playerHp = Math.min(this.playerMaxHp, this.playerHp);
      }
      this.playerPowerLevel = Math.max(this.playerPowerLevel, this.playerBasePower);
    }

    if (this.textures && this.playerShipMat) {
      this.playerShipMat.map = this.textures.ships[this.equippedShipId];
      this.playerShipMat.needsUpdate = true;
    }
    if (this.playerThrusterMat) {
      this.playerThrusterMat.color.setHex(specOrDefaultColor(ship.thrusterColor));
    }
    if (this.playerShieldMesh) {
      this.playerShieldMesh.visible = this.upgrades.shield;
    }
  }

  // ==========================================
  // Public Control API for React UI
  // ==========================================

  public startGame(): void {
    this.sound.init();
    this.clearEntities();

    this.playerX = 0;
    this.playerZ = PLAYER_Z;
    this.playerBankTilt = 0;
    this.playerInvuln = 0;
    this.playerPowerTimer = 0;
    this.playerShootCooldown = 0;
    this.playerGroup.visible = true;
    this.playerGroup.position.set(0, 0, PLAYER_Z);

    this.applyStats(true);

    this.score = 0;
    this.level = 1;
    this.nextBossScore = 1500;
    this.ultCharge = 0;
    this.ultActiveTimer = 0;
    this.bossWarningTimer = 0;
    this.spawnTimer = 0;
    this.touchTargetX = null;
    this.gameState = 'PLAYING';

    this.callbacks.onGameStateChange('PLAYING');
    this.emitHud(true);
  }

  public toggleShop(): void {
    if (this.gameState === 'PLAYING') {
      this.gameState = 'PAUSED';
      this.touchTargetX = null;
      this.callbacks.onGameStateChange('PAUSED');
    } else if (this.gameState === 'PAUSED') {
      this.gameState = 'PLAYING';
      this.callbacks.onGameStateChange('PLAYING');
    }
  }

  public toggleCameraMode(): CameraMode {
    this.cameraMode = this.cameraMode === 'ANGLED' ? 'CHASE' : 'ANGLED';
    this.applyCameraPosition(0, 0);
    return this.cameraMode;
  }

  public toggleMute(): boolean {
    this.sound.init();
    return this.sound.toggleMute();
  }

  public activateUltimate(): void {
    if (this.gameState !== 'PLAYING' || this.ultCharge < 100 || this.ultActiveTimer > 0) return;

    this.ultCharge = 0;
    this.ultActiveTimer = 95;
    this.screenShake = 0.85;
    this.playerInvuln = 110;
    this.sound.playUltimate();

    this.enemyBullets.forEach((eb) => {
      this.spawnExplosion(eb.x, 0.3, eb.z, 0xfde047, 4, 0.9);
      this.scene.remove(eb.mesh);
      (eb.mesh.material as THREE.Material).dispose();
    });
    this.enemyBullets = [];
    this.emitHud(true);
  }

  public getSaveSnapshot(): SaveData {
    return {
      coins: this.coins,
      highScore: this.highScore,
      ownedShips: [...this.ownedShips],
      equippedShipId: this.equippedShipId,
      upgrades: { ...this.upgrades },
    };
  }

  public buyOrEquipShip(shipId: ShipId): boolean {
    const spec = SHIPS_CATALOG.find((s) => s.id === shipId);
    if (!spec) return false;
    const isOwned = this.ownedShips.includes(shipId);
    if (!isOwned) {
      if (this.coins < spec.cost) return false;
      this.coins -= spec.cost;
      this.ownedShips.push(shipId);
    }
    this.equippedShipId = shipId;
    this.applyStats(false);
    this.sound.init();
    this.sound.playPowerup();
    this.persistProgress();
    this.emitHud(true);
    return true;
  }

  public buyUpgrade(upgradeId: 'weapon' | 'fireRate' | 'shield' | 'healAndHp' | 'speed' | 'ultGain'): boolean {
    let cost = 0;
    switch (upgradeId) {
      case 'weapon':
        if (this.upgrades.weapon >= 4) return false;
        cost = this.upgrades.weapon * 250;
        if (this.coins < cost) return false;
        this.coins -= cost;
        this.upgrades.weapon++;
        this.applyStats(false);
        break;
      case 'fireRate':
        if (this.upgrades.fireRate >= 5) return false;
        cost = (this.upgrades.fireRate + 1) * 180;
        if (this.coins < cost) return false;
        this.coins -= cost;
        this.upgrades.fireRate++;
        this.applyStats(false);
        break;
      case 'shield':
        if (this.upgrades.shield) return false;
        cost = 200;
        if (this.coins < cost) return false;
        this.coins -= cost;
        this.upgrades.shield = true;
        if (this.playerShieldMesh) this.playerShieldMesh.visible = true;
        break;
      case 'healAndHp': {
        const atFullCap = this.playerHp >= this.playerMaxHp && this.upgrades.maxHp >= 5;
        if (atFullCap) return false;
        cost = 150 + this.upgrades.maxHp * 100;
        if (this.coins < cost) return false;
        this.coins -= cost;
        if (this.playerHp >= this.playerMaxHp && this.upgrades.maxHp < 5) {
          this.upgrades.maxHp++;
          this.applyStats(false);
        }
        this.playerHp = Math.min(this.playerMaxHp, this.playerHp + 1);
        break;
      }
      case 'speed':
        if (this.upgrades.speed >= 4) return false;
        cost = (this.upgrades.speed + 1) * 140;
        if (this.coins < cost) return false;
        this.coins -= cost;
        this.upgrades.speed++;
        this.applyStats(false);
        break;
      case 'ultGain':
        if (this.upgrades.ultGain >= 4) return false;
        cost = (this.upgrades.ultGain + 1) * 200;
        if (this.coins < cost) return false;
        this.coins -= cost;
        this.upgrades.ultGain++;
        break;
    }

    this.sound.init();
    this.sound.playPowerup();
    this.persistProgress();
    this.emitHud(true);
    return true;
  }

  // ==========================================
  // Spawners & Gameplay Logic
  // ==========================================

  private spawnPlayerBullet(x: number, z: number, vx: number, vz: number): void {
    if (!this.textures) return;
    const mat = new THREE.MeshBasicMaterial({
      map: this.textures.laserBolt,
      color: 0x7dd3fc,
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      side: THREE.DoubleSide,
    });
    const mesh = new THREE.Mesh(this.unitPlaneGeo, mat);
    mesh.scale.set(1.25, 3.0, 1);
    mesh.rotation.x = -Math.PI / 2.5;
    if (vx !== 0) mesh.rotation.z = -Math.atan2(vx, -vz);
    mesh.position.set(x, 0.2, z);
    this.scene.add(mesh);

    this.bullets.push({
      x,
      z,
      vx,
      vz,
      radius: 0.5,
      markedForDeletion: false,
      mesh,
    });
  }

  private firePlayerWeapon(power: number): void {
    this.sound.playLaser();
    if (power === 1) {
      this.spawnPlayerBullet(this.playerX, this.playerZ - 1.8, 0, -1.4);
    } else if (power === 2) {
      this.spawnPlayerBullet(this.playerX - 0.9, this.playerZ - 1.4, 0, -1.4);
      this.spawnPlayerBullet(this.playerX + 0.9, this.playerZ - 1.4, 0, -1.4);
    } else if (power === 3) {
      this.spawnPlayerBullet(this.playerX, this.playerZ - 1.8, 0, -1.5);
      this.spawnPlayerBullet(this.playerX - 1.1, this.playerZ - 1.2, -0.18, -1.4);
      this.spawnPlayerBullet(this.playerX + 1.1, this.playerZ - 1.2, 0.18, -1.4);
    } else {
      this.spawnPlayerBullet(this.playerX - 0.55, this.playerZ - 1.8, 0, -1.55);
      this.spawnPlayerBullet(this.playerX + 0.55, this.playerZ - 1.8, 0, -1.55);
      this.spawnPlayerBullet(this.playerX - 1.4, this.playerZ - 1.2, -0.2, -1.45);
      this.spawnPlayerBullet(this.playerX + 1.4, this.playerZ - 1.2, 0.2, -1.45);
    }
  }

  private spawnUFO(): void {
    if (!this.textures) return;
    const rand = Math.random();
    let type: 'basic' | 'fast' | 'heavy' = 'basic';
    let radius = 1.45;
    let hp = 1;
    let vz = 0.2 + this.level * 0.025;
    let vx = Math.sin(Math.random() * Math.PI) * 0.06;
    let points = 100;
    let tex = this.textures.ufoBasic;
    let size = 3.5;

    if (rand < 0.2 + this.level * 0.03) {
      type = 'fast';
      radius = 1.3;
      hp = 1;
      vz = 0.28 + this.level * 0.03;
      vx = (Math.random() < 0.5 ? -1 : 1) * (0.14 + Math.random() * 0.12);
      points = 150;
      tex = this.textures.ufoFast;
      size = 3.3;
    } else if (rand < 0.35 + this.level * 0.04) {
      type = 'heavy';
      radius = 1.95;
      hp = 3 + Math.floor(this.level / 2);
      vz = 0.14 + this.level * 0.015;
      vx = 0;
      points = 300;
      tex = this.textures.ufoHeavy;
      size = 4.6;
    }

    const x = (Math.random() * 2 - 1) * (FIELD_HALF_X - 1.5);
    const z = SPAWN_Z;

    const group = new THREE.Group();
    group.position.set(x, 0, z);

    const spriteMat = new THREE.MeshBasicMaterial({
      map: tex,
      transparent: true,
      alphaTest: 0.08,
      side: THREE.DoubleSide,
    });
    const bodyMesh = new THREE.Mesh(this.unitPlaneGeo, spriteMat);
    bodyMesh.scale.set(size, size, 1);
    bodyMesh.rotation.x = -Math.PI / 2.4;
    bodyMesh.renderOrder = 2;
    group.add(bodyMesh);

    const flashMat = new THREE.MeshBasicMaterial({
      map: this.textures.vfxExplosion,
      color: 0xffffff,
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      opacity: 0,
    });
    const flashMesh = new THREE.Mesh(this.unitPlaneGeo, flashMat);
    flashMesh.scale.set(size * 0.9, size * 0.9, 1);
    flashMesh.rotation.x = -Math.PI / 2.4;
    flashMesh.position.y = 0.15;
    flashMesh.renderOrder = 3;
    group.add(flashMesh);

    const shadowMat = new THREE.MeshBasicMaterial({
      color: type === 'fast' ? 0xf43f5e : type === 'heavy' ? 0xa855f7 : 0x10b981,
      transparent: true,
      opacity: 0.25,
      depthWrite: false,
    });
    const shadowMesh = new THREE.Mesh(this.shadowCircleGeo, shadowMat);
    shadowMesh.rotation.x = -Math.PI / 2;
    shadowMesh.scale.set(radius * 1.15, radius * 1.15, 1);
    shadowMesh.position.y = -4.45;
    group.add(shadowMesh);

    this.scene.add(group);
    this.ufos.push({
      type,
      x,
      z,
      vx,
      vz,
      radius,
      hp,
      maxHp: hp,
      points,
      hitFlash: 0,
      spinAngle: Math.random() * Math.PI * 2,
      phaseOffset: Math.random() * 10,
      markedForDeletion: false,
      group,
      spriteMat,
      flashMesh,
      shadowMesh,
    });
  }

  private spawnBoss(): void {
    if (!this.textures) return;
    const maxHp = 50 + (this.level - 1) * 30;
    const group = new THREE.Group();
    const x = 0;
    const z = SPAWN_Z - 6;
    group.position.set(x, 1.2, z);

    const spriteMat = new THREE.MeshBasicMaterial({
      map: this.textures.bossMothership,
      transparent: true,
      alphaTest: 0.08,
      side: THREE.DoubleSide,
    });
    const bossPlane = new THREE.Mesh(this.unitPlaneGeo, spriteMat);
    bossPlane.scale.set(11.2, 11.2, 1);
    bossPlane.rotation.x = -Math.PI / 2.35;
    bossPlane.renderOrder = 2;
    group.add(bossPlane);

    const auraMat = new THREE.MeshBasicMaterial({
      map: this.textures.vfxExplosion,
      color: 0xf43f5e,
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      opacity: 0.5,
    });
    const auraMesh = new THREE.Mesh(this.unitPlaneGeo, auraMat);
    auraMesh.scale.set(5.4, 5.4, 1);
    auraMesh.rotation.x = -Math.PI / 2.35;
    auraMesh.position.y = 0.2;
    auraMesh.renderOrder = 3;
    group.add(auraMesh);

    const flashMat = new THREE.MeshBasicMaterial({
      map: this.textures.vfxExplosion,
      color: 0xffffff,
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      opacity: 0,
    });
    const flashMesh = new THREE.Mesh(this.unitPlaneGeo, flashMat);
    flashMesh.scale.set(9.8, 9.8, 1);
    flashMesh.rotation.x = -Math.PI / 2.35;
    flashMesh.position.y = 0.3;
    flashMesh.renderOrder = 4;
    group.add(flashMesh);

    this.scene.add(group);

    this.boss = {
      x,
      z,
      vx: 0.14 + this.level * 0.015,
      targetZ: -26,
      radius: 4.6,
      hp: maxHp,
      maxHp,
      shootTimer: 0,
      hitFlash: 0,
      spinAngle: 0,
      entering: true,
      group,
      spriteMat,
      flashMesh,
      auraMesh,
    };

    this.sound.playBossWarning();
    this.bossWarningTimer = 144; // ~2.4 seconds
    this.emitHud(true);
  }

  private spawnEnemyBullet(x: number, z: number, vx: number, vz: number): void {
    if (!this.textures) return;
    const mat = new THREE.MeshBasicMaterial({
      map: this.textures.enemyBolt,
      color: 0xfb7185,
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      side: THREE.DoubleSide,
    });
    const mesh = new THREE.Mesh(this.unitPlaneGeo, mat);
    mesh.scale.set(1.6, 1.6, 1);
    mesh.rotation.x = -Math.PI / 2.6;
    mesh.position.set(x, 0.3, z);
    this.scene.add(mesh);

    this.enemyBullets.push({
      x,
      z,
      vx,
      vz,
      radius: 0.55,
      markedForDeletion: false,
      mesh,
    });
  }

  private spawnPowerUp(x: number, z: number): void {
    if (!this.textures) return;
    const type: 'weapon' | 'health' = Math.random() < 0.65 ? 'weapon' : 'health';
    const tex = type === 'weapon' ? this.textures.powerupWeapon : this.textures.powerupHealth;
    const glowColor = type === 'weapon' ? 0xf59e0b : 0xf43f5e;

    const group = new THREE.Group();
    group.position.set(x, 0.4, z);

    const mat = new THREE.MeshBasicMaterial({
      map: tex,
      transparent: true,
      alphaTest: 0.08,
      side: THREE.DoubleSide,
    });
    const mesh = new THREE.Mesh(this.unitPlaneGeo, mat);
    mesh.scale.set(2.3, 2.3, 1);
    mesh.rotation.x = -Math.PI / 3;
    mesh.renderOrder = 2;
    group.add(mesh);

    const auraMat = new THREE.MeshBasicMaterial({
      map: this.textures.vfxExplosion,
      color: glowColor,
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      opacity: 0.45,
    });
    const aura = new THREE.Mesh(this.unitPlaneGeo, auraMat);
    aura.scale.set(2.9, 2.9, 1);
    aura.rotation.x = -Math.PI / 3;
    aura.renderOrder = 1;
    group.add(aura);

    this.scene.add(group);
    this.powerUps.push({
      type,
      x,
      z,
      vz: 0.22,
      radius: 1.15,
      phaseOffset: Math.random() * 6,
      markedForDeletion: false,
      group,
    });
  }

  private spawnExplosion(x: number, y: number, z: number, color: number, count = 6, baseScale = 1.8): void {
    if (!this.textures) return;
    for (let i = 0; i < count; i++) {
      const mat = new THREE.MeshBasicMaterial({
        map: this.textures.vfxExplosion,
        color,
        transparent: true,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        opacity: 1,
        side: THREE.DoubleSide,
      });
      const mesh = new THREE.Mesh(this.unitPlaneGeo, mat);
      const isCore = i === 0;
      const scale = isCore ? baseScale * 1.65 : baseScale * (0.45 + Math.random() * 0.55);
      mesh.scale.set(scale, scale, 1);
      mesh.rotation.x = -Math.PI / 3;
      mesh.rotation.z = Math.random() * Math.PI * 2;
      mesh.position.set(x, y, z);
      mesh.renderOrder = 5;
      this.scene.add(mesh);

      this.particles.push({
        x,
        y,
        z,
        vx: isCore ? 0 : (Math.random() - 0.5) * 0.48,
        vy: isCore ? 0 : (Math.random() - 0.15) * 0.36,
        vz: isCore ? 0 : (Math.random() - 0.5) * 0.48,
        scale,
        growRate: isCore ? 0.14 : 0.04,
        life: 1.0,
        decay: isCore ? 0.055 : 0.032 + Math.random() * 0.025,
        mesh,
        mat,
      });
    }
  }

  private checkCollisionXZ(x1: number, z1: number, r1: number, x2: number, z2: number, r2: number): boolean {
    const dx = x1 - x2;
    const dz = z1 - z2;
    return dx * dx + dz * dz < (r1 + r2) * (r1 + r2);
  }

  private addUltCharge(amount: number): void {
    if (this.ultActiveTimer > 0 || this.ultCharge >= 100) return;
    const multiplier = 1 + this.upgrades.ultGain * 0.25;
    this.ultCharge = Math.min(100, this.ultCharge + amount * multiplier);
  }

  private damagePlayer(): void {
    if (this.playerInvuln > 0) return;

    if (this.upgrades.shield) {
      this.upgrades.shield = false;
      if (this.playerShieldMesh) this.playerShieldMesh.visible = false;
      this.playerInvuln = 60;
      this.screenShake = 0.45;
      this.sound.playHit();
      this.spawnExplosion(this.playerX, 0.5, this.playerZ, 0x38bdf8, 8, 2.2);
      this.persistProgress();
      this.emitHud(true);
      return;
    }

    this.playerHp--;
    this.playerInvuln = 75;
    this.screenShake = 0.6;
    this.sound.playHit();
    this.emitHud(true);

    if (this.playerHp <= 0) {
      this.triggerGameOver();
    }
  }

  private triggerGameOver(): void {
    this.gameState = 'GAMEOVER';
    this.sound.playExplosion();
    this.spawnExplosion(this.playerX, 0.5, this.playerZ, 0x38bdf8, 16, 2.6);
    this.playerGroup.visible = false;
    this.screenShake = 1.0;

    if (this.score > this.highScore) {
      this.highScore = this.score;
    }
    this.persistProgress();
    this.emitHud(true);

    window.setTimeout(() => {
      if (!this.disposed && this.gameState === 'GAMEOVER') {
        this.callbacks.onGameStateChange('GAMEOVER');
      }
    }, 850);
  }

  private destroyBoss(): void {
    if (!this.boss) return;
    this.sound.playExplosion();
    this.screenShake = 1.2;
    this.spawnExplosion(this.boss.x, 1, this.boss.z, 0xf43f5e, 18, 3.8);
    this.spawnExplosion(this.boss.x - 2.2, 1.2, this.boss.z, 0xfde047, 10, 2.8);
    this.spawnPowerUp(this.boss.x - 1.5, this.boss.z);
    this.spawnPowerUp(this.boss.x + 1.5, this.boss.z);
    this.score += 1000 * this.level;
    this.coins += 300 * this.level;
    this.nextBossScore = this.score + 2500;
    this.disposeGroup(this.boss.group);
    this.boss = null;
    this.addUltCharge(50);
    this.persistProgress();
    this.emitHud(true);
  }

  private disposeGroup(group: THREE.Group): void {
    this.scene.remove(group);
    group.traverse((obj) => {
      if (obj instanceof THREE.Mesh) {
        if (Array.isArray(obj.material)) {
          obj.material.forEach((m) => m.dispose());
        } else {
          obj.material.dispose();
        }
      }
    });
  }

  private clearEntities(): void {
    if (this.boss) {
      this.disposeGroup(this.boss.group);
      this.boss = null;
    }
    this.bullets.forEach((b) => {
      this.scene.remove(b.mesh);
      (b.mesh.material as THREE.Material).dispose();
    });
    this.enemyBullets.forEach((eb) => {
      this.scene.remove(eb.mesh);
      (eb.mesh.material as THREE.Material).dispose();
    });
    this.ufos.forEach((u) => this.disposeGroup(u.group));
    this.powerUps.forEach((p) => this.disposeGroup(p.group));
    this.particles.forEach((pt) => {
      this.scene.remove(pt.mesh);
      pt.mat.dispose();
    });

    this.bullets = [];
    this.enemyBullets = [];
    this.ufos = [];
    this.powerUps = [];
    this.particles = [];
    this.beamGroup.visible = false;
  }

  private persistProgress(): void {
    this.callbacks.onSaveProgress(this.getSaveSnapshot());
  }

  private emitHud(force = false): void {
    const now = performance.now();
    if (!force && now - this.lastHudEmit < 90) return;
    this.lastHudEmit = now;

    this.callbacks.onHudUpdate({
      score: this.score,
      coins: this.coins,
      highScore: this.highScore,
      level: this.level,
      hp: Math.max(0, this.playerHp),
      maxHp: this.playerMaxHp,
      powerLevel: Math.max(this.playerBasePower, this.playerPowerLevel),
      shieldActive: this.upgrades.shield,
      ultCharge: Math.min(100, Math.floor(this.ultCharge)),
      ultActive: this.ultActiveTimer > 0,
      bossActive: this.boss !== null,
      bossHp: this.boss ? Math.max(0, this.boss.hp) : 0,
      bossMaxHp: this.boss ? this.boss.maxHp : 1,
      bossWarningVisible: this.bossWarningTimer > 0,
      equippedShipId: this.equippedShipId,
    });
  }

  // ==========================================
  // Main Loop (Software WebGL Paced + GPU rAF)
  // ==========================================

  private startLoop(): void {
    const afterDraw = (cb: () => void) => {
      const gl = this.renderer.getContext() as WebGL2RenderingContext;
      if (gl && typeof gl.fenceSync === 'function') {
        const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
        gl.flush();
        const poll = () => {
          if (this.disposed) return;
          const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
          if (state === gl.UNSIGNALED) {
            this.frameId = window.setTimeout(poll, 5);
          } else {
            if (sync) gl.deleteSync(sync);
            this.frameId = window.setTimeout(cb, 80);
          }
        };
        this.frameId = window.setTimeout(poll, 5);
      } else {
        this.frameId = window.setTimeout(cb, 80);
      }
    };

    const tick = () => {
      if (this.disposed) return;
      const dt = Math.min(this.clock.getDelta(), 0.05);
      const step = dt * 60;

      this.updateScene(step, dt);
      this.renderer.render(this.scene, this.camera);

      if (this.isSoftwareGl) {
        afterDraw(tick);
      } else {
        this.frameId = requestAnimationFrame(tick);
      }
    };

    if (this.isSoftwareGl) {
      tick();
    } else {
      this.frameId = requestAnimationFrame(tick);
    }
  }

  private updateScene(step: number, dt: number): void {
    if (this.gameState === 'PAUSED') return;

    this.elapsedFrames += step;

    // Scroll starfield & orbital deck floor
    const posAttr = this.starGeo.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < this.starCount; i++) {
      let z = posAttr.getZ(i) + 0.45 * step;
      if (z > 40) z = -120;
      posAttr.setZ(i, z);
    }
    posAttr.needsUpdate = true;

    if (this.textures?.spaceFloor) {
      this.textures.spaceFloor.offset.y = (this.textures.spaceFloor.offset.y + 0.0085 * step) % 1;
    }

    // Smooth camera pitch transition for player plane
    const targetPitch = this.cameraMode === 'ANGLED' ? -Math.PI / 2.45 : -Math.PI / 3.3;
    this.playerPitchAngle = THREE.MathUtils.damp(this.playerPitchAngle, targetPitch, 8, dt);

    // Camera shake decay
    if (this.screenShake > 0.01) {
      const sx = (Math.random() - 0.5) * this.screenShake;
      const sy = (Math.random() - 0.5) * this.screenShake;
      this.applyCameraPosition(sx, sy);
      this.screenShake *= Math.pow(0.88, step);
    } else {
      this.applyCameraPosition(0, 0);
    }

    // Boss warning countdown
    if (this.bossWarningTimer > 0) {
      this.bossWarningTimer = Math.max(0, this.bossWarningTimer - step);
      if (this.bossWarningTimer === 0) this.emitHud(true);
    }

    if (this.gameState === 'PLAYING') {
      const newLevel = Math.floor(this.score / 1000) + 1;
      if (newLevel > this.level) {
        this.level = newLevel;
        this.emitHud(true);
      }

      // Player movement
      let moveDir = 0;
      if (this.keys['ArrowLeft'] || this.keys['KeyA']) {
        this.playerX -= this.playerSpeed * step;
        moveDir = -1;
      }
      if (this.keys['ArrowRight'] || this.keys['KeyD']) {
        this.playerX += this.playerSpeed * step;
        moveDir = 1;
      }
      if (this.touchTargetX !== null) {
        const diff = this.touchTargetX - this.playerX;
        if (Math.abs(diff) > 0.12) {
          this.playerX += diff * (1 - Math.exp(-14 * dt));
          moveDir = Math.sign(diff);
        }
      }
      this.playerX = Math.max(-FIELD_HALF_X, Math.min(FIELD_HALF_X, this.playerX));

      const targetTilt = -moveDir * 0.42;
      this.playerBankTilt = THREE.MathUtils.damp(this.playerBankTilt, targetTilt, 10, dt);

      this.playerGroup.position.set(this.playerX, Math.sin(this.elapsedFrames * 0.08) * 0.14, this.playerZ);
      this.playerTiltGroup.rotation.z = this.playerBankTilt;

      const shipMesh = this.playerTiltGroup.children[0] as THREE.Mesh | undefined;
      if (shipMesh) shipMesh.rotation.x = this.playerPitchAngle;

      if (this.playerThrusterMesh) {
        this.playerThrusterMesh.rotation.x = this.playerPitchAngle;
        const pulse = 0.85 + Math.random() * 0.35;
        this.playerThrusterMesh.scale.set(1.3 * pulse, 1.5 * pulse, 1);
      }

      if (this.playerShieldMesh && this.playerShieldMesh.visible) {
        this.playerShieldMesh.rotation.x = this.playerPitchAngle;
        this.playerShieldMesh.rotation.z += 0.025 * step;
      }

      // Temporary powerup timer
      const effectivePower = Math.max(this.playerBasePower, this.playerPowerLevel);
      if (this.playerPowerLevel > this.playerBasePower) {
        this.playerPowerTimer -= step;
        if (this.playerPowerTimer <= 0) {
          this.playerPowerLevel = this.playerBasePower;
          this.emitHud(true);
        }
      } else {
        this.playerPowerLevel = this.playerBasePower;
      }

      // Invulnerability blink
      if (this.playerInvuln > 0) {
        this.playerInvuln = Math.max(0, this.playerInvuln - step);
        this.playerGroup.visible = Math.floor(this.elapsedFrames / 3) % 2 === 0;
      } else {
        this.playerGroup.visible = true;
      }

      // Weapon fire
      if (this.playerShootCooldown > 0) this.playerShootCooldown -= step;
      if ((this.keys['Space'] || this.touchTargetX !== null || this.keys['AutoFire']) && this.playerShootCooldown <= 0) {
        this.firePlayerWeapon(effectivePower);
        this.playerShootCooldown = this.playerShootInterval;
      }

      // Hyper Mega Beam
      if (this.ultActiveTimer > 0) {
        this.ultActiveTimer = Math.max(0, this.ultActiveTimer - step);
        this.beamGroup.visible = true;
        this.beamGroup.position.set(this.playerX, 0.2, this.playerZ - 38);
        const pulseScale = 1 + Math.sin(this.elapsedFrames * 0.8) * 0.22;
        this.beamOuterMesh.scale.set(pulseScale, 1, 1);
        const beamMap = (this.beamOuterMesh.material as THREE.MeshBasicMaterial).map;
        if (beamMap) {
          beamMap.offset.y = (beamMap.offset.y - 0.12 * step) % 1;
        }
        this.beamRingMesh.rotation.z += 0.16 * step;

        this.ufos.forEach((ufo) => {
          if (!ufo.markedForDeletion && ufo.z < this.playerZ && Math.abs(ufo.x - this.playerX) < 2.8 + ufo.radius) {
            ufo.markedForDeletion = true;
            this.sound.playExplosion();
            this.spawnExplosion(ufo.x, 0, ufo.z, 0xfde047, 8, 2.2);
            this.score += ufo.points;
            this.coins += Math.floor(ufo.points / 5);
            if (Math.random() < 0.15) this.spawnPowerUp(ufo.x, ufo.z);
          }
        });

        if (this.boss && Math.floor(this.elapsedFrames) % 3 === 0 && Math.abs(this.boss.x - this.playerX) < 2.8 + this.boss.radius) {
          this.boss.hp--;
          this.boss.hitFlash = 2;
          this.spawnExplosion(this.boss.x + (Math.random() - 0.5) * 3, 1, this.boss.z + 2, 0xfde047, 2, 1.5);
          if (this.boss.hp <= 0) {
            this.destroyBoss();
          }
        }

        if (this.ultActiveTimer <= 0) {
          this.beamGroup.visible = false;
          this.persistProgress();
          this.emitHud(true);
        }
      } else {
        this.beamGroup.visible = false;
      }

      // Bullets
      this.bullets.forEach((b) => {
        b.x += b.vx * step;
        b.z += b.vz * step;
        b.mesh.position.set(b.x, 0.1, b.z);
        if (b.z < SPAWN_Z - 8) b.markedForDeletion = true;
      });

      // Boss update & bullet collision
      if (this.boss) {
        const bObj = this.boss;
        if (bObj.entering) {
          bObj.z += 0.24 * step;
          if (bObj.z >= bObj.targetZ) {
            bObj.z = bObj.targetZ;
            bObj.entering = false;
          }
        } else {
          bObj.x += bObj.vx * step;
          if (bObj.x < -FIELD_HALF_X + bObj.radius || bObj.x > FIELD_HALF_X - bObj.radius) {
            bObj.vx *= -1;
          }
          bObj.z = bObj.targetZ + Math.sin(this.elapsedFrames * 0.03) * 2.2;

          bObj.shootTimer += step;
          const isEnraged = bObj.hp < bObj.maxHp * 0.5;
          const fireInterval = isEnraged ? 45 : 68;
          if (bObj.shootTimer >= fireInterval) {
            bObj.shootTimer = 0;
            const baseAngle = Math.atan2(this.playerX - bObj.x, this.playerZ - bObj.z);
            const speed = 0.42 + this.level * 0.025;
            const spread = isEnraged ? [-0.36, -0.18, 0, 0.18, 0.36] : [-0.22, 0, 0.22];
            spread.forEach((offset) => {
              const angle = baseAngle + offset;
              this.spawnEnemyBullet(bObj.x, bObj.z + 2.5, Math.sin(angle) * speed, Math.cos(angle) * speed);
            });
          }
        }

        bObj.spinAngle += 0.012 * step;
        const bossSprite = bObj.group.children[0] as THREE.Mesh;
        if (bossSprite) bossSprite.rotation.z = bObj.spinAngle;
        bObj.auraMesh.rotation.z = -bObj.spinAngle * 2;
        bObj.group.position.set(bObj.x, 1.2 + Math.sin(this.elapsedFrames * 0.05) * 0.4, bObj.z);

        const flashMat = bObj.flashMesh.material as THREE.MeshBasicMaterial;
        if (bObj.hitFlash > 0) {
          bObj.hitFlash = Math.max(0, bObj.hitFlash - step);
          flashMat.opacity = 0.65;
        } else {
          flashMat.opacity = 0;
        }

        this.bullets.forEach((b) => {
          if (!b.markedForDeletion && this.boss) {
            if (this.checkCollisionXZ(b.x, b.z, b.radius, this.boss.x, this.boss.z, this.boss.radius)) {
              b.markedForDeletion = true;
              this.boss.hp--;
              this.boss.hitFlash = 4;
              this.spawnExplosion(b.x, 0.5, b.z, 0xfbbf24, 3, 1.1);
              if (this.boss.hp <= 0) {
                this.destroyBoss();
              }
            }
          }
        });
      }

      // Enemy bullets
      this.enemyBullets.forEach((eb) => {
        eb.x += eb.vx * step;
        eb.z += eb.vz * step;
        eb.mesh.position.set(eb.x, 0.3, eb.z);
        eb.mesh.rotation.z += 0.1 * step;
        if (eb.z > PLAYER_Z + 8 || Math.abs(eb.x) > FIELD_HALF_X + 6) {
          eb.markedForDeletion = true;
        } else if (this.playerInvuln <= 0) {
          if (this.checkCollisionXZ(this.playerX, this.playerZ, this.playerRadius * 0.75, eb.x, eb.z, eb.radius)) {
            eb.markedForDeletion = true;
            this.spawnExplosion(this.playerX, 0, this.playerZ, 0xf43f5e, 6, 1.8);
            this.damagePlayer();
          }
        }
      });

      // Spawn UFOs or Boss
      if (!this.boss && this.score >= this.nextBossScore) {
        this.spawnBoss();
      } else {
        const baseRate = this.boss ? 110 : 52;
        const spawnInterval = Math.max(20, baseRate - this.level * 3);
        this.spawnTimer += step;
        if (this.spawnTimer >= spawnInterval) {
          this.spawnTimer = 0;
          this.spawnUFO();
        }
      }

      // UFO updates & collisions
      this.ufos.forEach((ufo) => {
        ufo.z += ufo.vz * step;
        ufo.x += ufo.vx * step;
        if (ufo.x < -FIELD_HALF_X + ufo.radius || ufo.x > FIELD_HALF_X - ufo.radius) {
          ufo.vx *= -1;
        }

        const spriteMesh = ufo.group.children[0] as THREE.Mesh;
        if (ufo.type === 'fast') {
          spriteMesh.rotation.z = -ufo.vx * 1.4;
        } else {
          ufo.spinAngle += 0.03 * step;
          spriteMesh.rotation.z = ufo.spinAngle;
        }

        ufo.group.position.set(ufo.x, Math.sin(this.elapsedFrames * 0.08 + ufo.phaseOffset) * 0.25, ufo.z);

        const flashMat = ufo.flashMesh.material as THREE.MeshBasicMaterial;
        if (ufo.hitFlash > 0) {
          ufo.hitFlash = Math.max(0, ufo.hitFlash - step);
          flashMat.opacity = 0.75;
        } else {
          flashMat.opacity = 0;
        }

        if (ufo.z > PLAYER_Z + 8) {
          ufo.markedForDeletion = true;
          return;
        }

        this.bullets.forEach((b) => {
          if (!b.markedForDeletion && !ufo.markedForDeletion) {
            if (this.checkCollisionXZ(b.x, b.z, b.radius, ufo.x, ufo.z, ufo.radius)) {
              b.markedForDeletion = true;
              ufo.hp--;
              ufo.hitFlash = 4;

              if (ufo.hp <= 0) {
                ufo.markedForDeletion = true;
                this.sound.playExplosion();
                const expColor = ufo.type === 'fast' ? 0xf43f5e : ufo.type === 'heavy' ? 0xc084fc : 0x34d399;
                this.spawnExplosion(ufo.x, 0, ufo.z, expColor, 7, 2.0);
                this.score += ufo.points;
                this.coins += Math.floor(ufo.points / 5);
                this.screenShake = 0.25;
                this.addUltCharge(ufo.type === 'heavy' ? 18 : 10);
                this.persistProgress();
                if (Math.random() < 0.15) {
                  this.spawnPowerUp(ufo.x, ufo.z);
                }
              } else {
                this.spawnExplosion(b.x, 0, b.z, 0xffffff, 2, 1.0);
              }
            }
          }
        });

        if (!ufo.markedForDeletion && this.playerInvuln <= 0) {
          if (this.checkCollisionXZ(this.playerX, this.playerZ, this.playerRadius * 0.8, ufo.x, ufo.z, ufo.radius * 0.85)) {
            ufo.markedForDeletion = true;
            const expColor = ufo.type === 'fast' ? 0xf43f5e : ufo.type === 'heavy' ? 0xc084fc : 0x34d399;
            this.spawnExplosion(ufo.x, 0, ufo.z, expColor, 7, 2.0);
            this.damagePlayer();
          }
        }
      });

      // Powerups
      this.powerUps.forEach((item) => {
        item.z += item.vz * step;
        item.group.position.set(item.x, 0.4 + Math.sin(this.elapsedFrames * 0.1 + item.phaseOffset) * 0.2, item.z);
        const itemSprite = item.group.children[0] as THREE.Mesh;
        itemSprite.rotation.z += 0.03 * step;

        if (item.z > PLAYER_Z + 8) {
          item.markedForDeletion = true;
          return;
        }
        if (this.checkCollisionXZ(this.playerX, this.playerZ, this.playerRadius + 0.5, item.x, item.z, item.radius)) {
          item.markedForDeletion = true;
          this.sound.playPowerup();
          this.score += 50;
          this.coins += 25;
          if (item.type === 'weapon') {
            this.playerPowerLevel = Math.min(4, Math.max(this.playerBasePower, this.playerPowerLevel) + 1);
            this.playerPowerTimer = 600;
          } else {
            this.playerHp = Math.min(this.playerMaxHp, this.playerHp + 1);
          }
          this.persistProgress();
          this.emitHud(true);
        }
      });

      // Prune destroyed entities
      this.bullets = this.bullets.filter((b) => {
        if (b.markedForDeletion) {
          this.scene.remove(b.mesh);
          (b.mesh.material as THREE.Material).dispose();
          return false;
        }
        return true;
      });
      this.enemyBullets = this.enemyBullets.filter((eb) => {
        if (eb.markedForDeletion) {
          this.scene.remove(eb.mesh);
          (eb.mesh.material as THREE.Material).dispose();
          return false;
        }
        return true;
      });
      this.ufos = this.ufos.filter((u) => {
        if (u.markedForDeletion) {
          this.disposeGroup(u.group);
          return false;
        }
        return true;
      });
      this.powerUps = this.powerUps.filter((p) => {
        if (p.markedForDeletion) {
          this.disposeGroup(p.group);
          return false;
        }
        return true;
      });

      this.emitHud(false);
    }

    // Explosions update (also runs during GAMEOVER)
    this.particles.forEach((pt) => {
      pt.x += pt.vx * step;
      pt.y += pt.vy * step;
      pt.z += pt.vz * step;
      pt.scale += pt.growRate * step;
      pt.life -= pt.decay * step;
      pt.mesh.position.set(pt.x, pt.y, pt.z);
      pt.mesh.scale.set(pt.scale, pt.scale, 1);
      pt.mat.opacity = Math.max(0, pt.life);
    });
    this.particles = this.particles.filter((pt) => {
      if (pt.life <= 0) {
        this.scene.remove(pt.mesh);
        pt.mat.dispose();
        return false;
      }
      return true;
    });
  }

  public dispose(): void {
    this.disposed = true;
    cancelAnimationFrame(this.frameId);
    window.clearTimeout(this.frameId);

    window.removeEventListener('resize', this.handleResizeBound);
    window.removeEventListener('keydown', this.handleKeyDownBound);
    window.removeEventListener('keyup', this.handleKeyUpBound);
    window.removeEventListener('mousemove', this.handleMouseMoveBound);
    window.removeEventListener('mouseup', this.handleMouseUpBound);

    if (this.renderer?.domElement) {
      const dom = this.renderer.domElement;
      dom.removeEventListener('touchstart', this.handleTouchStartBound);
      dom.removeEventListener('touchmove', this.handleTouchMoveBound);
      dom.removeEventListener('touchend', this.handleTouchEndBound);
      dom.removeEventListener('mousedown', this.handleMouseDownBound);
      dom.removeEventListener('webglcontextlost', this.handleContextLostBound);
      dom.removeEventListener('webglcontextrestored', this.handleContextRestoredBound);
      if (dom.parentNode === this.container) {
        this.container.removeChild(dom);
      }
    }

    this.clearEntities();
    if (this.beamOuterMesh) {
      const mat = this.beamOuterMesh.material as THREE.MeshBasicMaterial;
      mat.map?.dispose();
      mat.dispose();
      this.beamOuterMesh.geometry.dispose();
    }
    if (this.beamCoreMesh) {
      (this.beamCoreMesh.material as THREE.Material).dispose();
      this.beamCoreMesh.geometry.dispose();
    }
    if (this.backdropMesh) {
      (this.backdropMesh.material as THREE.Material).dispose();
      this.backdropMesh.geometry.dispose();
    }
    if (this.floorMesh) {
      (this.floorMesh.material as THREE.Material).dispose();
      this.floorMesh.geometry.dispose();
    }
    this.unitPlaneGeo.dispose();
    this.shadowCircleGeo.dispose();
    this.shieldSphereGeo.dispose();
    this.starGeo?.dispose();

    disposeGameTextures(this.textures);
    this.textures = null;
    this.sound.dispose();
    this.renderer?.dispose();
  }
}

function specOrDefaultColor(hex: number): number {
  return typeof hex === 'number' ? hex : 0x38bdf8;
}
