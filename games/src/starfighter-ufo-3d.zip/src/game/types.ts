import shipFalconImg from '../assets/images/ship_falcon_1794636401918.jpg';
import shipViperImg from '../assets/images/ship_viper_1794636401867.jpg';
import shipTitanImg from '../assets/images/ship_titan_1794636402357.jpg';
import shipNovaImg from '../assets/images/ship_nova_1794636402931.jpg';
import ufoBasicImg from '../assets/images/ufo_basic_1794636403040.jpg';
import ufoFastImg from '../assets/images/ufo_fast_1794636403062.jpg';
import ufoHeavyImg from '../assets/images/ufo_heavy_1794636404516.jpg';
import bossMothershipImg from '../assets/images/boss_mothership_1794636404964.jpg';
import powerupWeaponImg from '../assets/images/powerup_weapon_1794636404666.jpg';
import powerupHealthImg from '../assets/images/powerup_health_1794636405295.jpg';
import vfxExplosionImg from '../assets/images/vfx_explosion_1794636405823.jpg';
import vfxShieldOrbImg from '../assets/images/vfx_shield_orb_1794636405951.jpg';
import spaceNebulaBgImg from '../assets/images/space_nebula_bg_1794636400559.jpg';
import spaceFloorGridImg from '../assets/images/space_floor_grid_1794636400452.jpg';

export type GameState = 'START' | 'PLAYING' | 'PAUSED' | 'GAMEOVER';
export type CameraMode = 'ANGLED' | 'CHASE';
export type ShipId = 'falcon' | 'viper' | 'titan' | 'nova';
export type ShopTab = 'ships' | 'upgrades';

export interface UpgradeState {
  weapon: number;
  fireRate: number;
  maxHp: number;
  speed: number;
  ultGain: number;
  shield: boolean;
}

export interface SaveData {
  coins: number;
  highScore: number;
  ownedShips: ShipId[];
  equippedShipId: ShipId;
  upgrades: UpgradeState;
}

export interface ShipSpec {
  id: ShipId;
  name: string;
  subtitle: string;
  cost: number;
  desc: string;
  statsText: string;
  bonusSpeed: number;
  bonusFireRate: number;
  bonusHp: number;
  bonusWeapon: number;
  accentHex: string;
  thrusterColor: number;
  imageUrl: string;
  rotationRad: number;
  scaleFactor: number;
}

export interface HudSnapshot {
  score: number;
  coins: number;
  highScore: number;
  level: number;
  hp: number;
  maxHp: number;
  powerLevel: number;
  shieldActive: boolean;
  ultCharge: number;
  ultActive: boolean;
  bossActive: boolean;
  bossHp: number;
  bossMaxHp: number;
  bossWarningVisible: boolean;
  equippedShipId: ShipId;
}

export const GENERATED_ASSETS = {
  spaceNebulaBg: spaceNebulaBgImg,
  spaceFloorGrid: spaceFloorGridImg,
  shipFalcon: shipFalconImg,
  shipViper: shipViperImg,
  shipTitan: shipTitanImg,
  shipNova: shipNovaImg,
  ufoBasic: ufoBasicImg,
  ufoFast: ufoFastImg,
  ufoHeavy: ufoHeavyImg,
  bossMothership: bossMothershipImg,
  powerupWeapon: powerupWeaponImg,
  powerupHealth: powerupHealthImg,
  vfxExplosion: vfxExplosionImg,
  vfxShieldOrb: vfxShieldOrbImg,
} as const;

export const SHIPS_CATALOG: ShipSpec[] = [
  {
    id: 'falcon',
    name: 'SF-01 팔콘',
    subtitle: '표준 우주 요격기',
    cost: 0,
    desc: '균형 잡힌 기동성과 안정적인 화력을 갖춘 표준형 우주 요격기입니다.',
    statsText: '균형형 · 기본 1연발',
    bonusSpeed: 0,
    bonusFireRate: 0,
    bonusHp: 0,
    bonusWeapon: 0,
    accentHex: '#38bdf8',
    thrusterColor: 0x38bdf8,
    imageUrl: shipFalconImg,
    // Nose points top-right (+45 deg from up), rotate CCW by 45 deg to point straight up (-Z)
    rotationRad: -Math.PI / 4,
    scaleFactor: 0.86,
  },
  {
    id: 'viper',
    name: 'VX-9 바이퍼',
    subtitle: '초고속 스텔스기',
    cost: 450,
    desc: '전진익 날개를 탑재한 초고속 회피 기동 및 고속 연사 특화 전투기입니다.',
    statsText: '이동속도 +35% · 연사속도 +25%',
    bonusSpeed: 0.12,
    bonusFireRate: 2.5,
    bonusHp: 0,
    bonusWeapon: 0,
    accentHex: '#f59e0b',
    thrusterColor: 0xf97316,
    imageUrl: shipViperImg,
    // Nose points bottom-left, rotate CW by 135 deg to point straight up (-Z)
    rotationRad: (3 * Math.PI) / 4,
    scaleFactor: 0.84,
  },
  {
    id: 'titan',
    name: 'HX-4 타이탄',
    subtitle: '중장갑 트윈 건십',
    cost: 750,
    desc: '이중 장갑과 트윈 포드를 탑재하여 높은 내구도와 화력을 자랑하는 중전투함입니다.',
    statsText: '최대 체력 +2 · 기본 화력 +1단계',
    bonusSpeed: -0.02,
    bonusFireRate: 0,
    bonusHp: 2,
    bonusWeapon: 1,
    accentHex: '#10b981',
    thrusterColor: 0x2dd4bf,
    imageUrl: shipTitanImg,
    rotationRad: (3 * Math.PI) / 4,
    scaleFactor: 0.86,
  },
  {
    id: 'nova',
    name: 'NX-99 노바 프라임',
    subtitle: '궁극의 황금 기함',
    cost: 1300,
    desc: '외계 코어 기술과 황금 플라즈마 링이 집약된 최상위 제왕 전투기입니다.',
    statsText: '올스탯 최상급 · 기본 화력 +2단계',
    bonusSpeed: 0.1,
    bonusFireRate: 3,
    bonusHp: 2,
    bonusWeapon: 2,
    accentHex: '#c084fc',
    thrusterColor: 0xfacc15,
    imageUrl: shipNovaImg,
    rotationRad: (3 * Math.PI) / 4,
    scaleFactor: 0.84,
  },
];

export const DEFAULT_UPGRADES: UpgradeState = {
  weapon: 1,
  fireRate: 0,
  maxHp: 0,
  speed: 0,
  ultGain: 0,
  shield: false,
};

export const DEFAULT_SAVE_DATA: SaveData = {
  coins: 0,
  highScore: 0,
  ownedShips: ['falcon'],
  equippedShipId: 'falcon',
  upgrades: { ...DEFAULT_UPGRADES },
};
