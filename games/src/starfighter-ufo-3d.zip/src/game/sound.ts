import * as Tone from 'tone';

export class SoundManager {
  public isMuted = false;
  private initialized = false;
  private lastPlayTime = 0;

  private laserSynth: Tone.Synth | null = null;
  private explosionSynth: Tone.NoiseSynth | null = null;
  private powerupSynth: Tone.PolySynth | null = null;
  private hitSynth: Tone.MembraneSynth | null = null;
  private bossWarnSynth: Tone.Synth | null = null;
  private ultSynth: Tone.Synth | null = null;

  public async init(): Promise<void> {
    if (this.initialized) return;
    try {
      await Tone.start();

      this.laserSynth = new Tone.Synth({
        oscillator: { type: 'sawtooth' },
        envelope: { attack: 0.005, decay: 0.08, sustain: 0, release: 0.05 },
      }).toDestination();
      this.laserSynth.volume.value = -16;

      this.explosionSynth = new Tone.NoiseSynth({
        noise: { type: 'brown' },
        envelope: { attack: 0.01, decay: 0.25, sustain: 0, release: 0.1 },
      }).toDestination();
      this.explosionSynth.volume.value = -10;

      this.powerupSynth = new Tone.PolySynth(Tone.Synth, {
        oscillator: { type: 'triangle' },
        envelope: { attack: 0.01, decay: 0.15, sustain: 0.1, release: 0.2 },
      }).toDestination();
      this.powerupSynth.volume.value = -10;

      this.hitSynth = new Tone.MembraneSynth({
        pitchDecay: 0.05,
        octaves: 4,
        envelope: { attack: 0.001, decay: 0.2, sustain: 0 },
      }).toDestination();
      this.hitSynth.volume.value = -8;

      this.bossWarnSynth = new Tone.Synth({
        oscillator: { type: 'square' },
        envelope: { attack: 0.05, decay: 0.3, sustain: 0.2, release: 0.2 },
      }).toDestination();
      this.bossWarnSynth.volume.value = -12;

      this.ultSynth = new Tone.Synth({
        oscillator: { type: 'sawtooth' },
        envelope: { attack: 0.05, decay: 0.6, sustain: 0.4, release: 0.5 },
      }).toDestination();
      this.ultSynth.volume.value = -6;

      this.initialized = true;
    } catch {
      // Audio context blocked or unavailable
    }
  }

  private getSafeTime(offset = 0): number {
    const now = Tone.now() + offset;
    if (now <= this.lastPlayTime) {
      this.lastPlayTime += 0.003;
    } else {
      this.lastPlayTime = now;
    }
    return this.lastPlayTime;
  }

  public playLaser(): void {
    if (this.isMuted || !this.initialized || !this.laserSynth) return;
    try {
      const t = this.getSafeTime();
      this.laserSynth.triggerAttackRelease('C6', '32n', t);
      this.laserSynth.frequency.exponentialRampToValueAtTime(220, t + 0.07);
    } catch {
      // Ignore transient scheduling errors
    }
  }

  public playExplosion(): void {
    if (this.isMuted || !this.initialized || !this.explosionSynth) return;
    try {
      const t = this.getSafeTime();
      this.explosionSynth.triggerAttackRelease('8n', t);
    } catch {
      // Ignore
    }
  }

  public playPowerup(): void {
    if (this.isMuted || !this.initialized || !this.powerupSynth) return;
    try {
      const t = this.getSafeTime();
      this.powerupSynth.triggerAttackRelease(['C5', 'E5', 'G5', 'C6'], '16n', t);
    } catch {
      // Ignore
    }
  }

  public playHit(): void {
    if (this.isMuted || !this.initialized || !this.hitSynth) return;
    try {
      const t = this.getSafeTime();
      this.hitSynth.triggerAttackRelease('G1', '8n', t);
    } catch {
      // Ignore
    }
  }

  public playBossWarning(): void {
    if (this.isMuted || !this.initialized || !this.bossWarnSynth) return;
    try {
      const t1 = this.getSafeTime(0);
      this.bossWarnSynth.triggerAttackRelease('A2', '8n', t1);
      const t2 = this.getSafeTime(0.25);
      this.bossWarnSynth.triggerAttackRelease('D#2', '4n', t2);
    } catch {
      // Ignore
    }
  }

  public playUltimate(): void {
    if (this.isMuted || !this.initialized || !this.ultSynth) return;
    try {
      const t = this.getSafeTime();
      this.ultSynth.triggerAttackRelease('C3', '1n', t);
      this.ultSynth.frequency.exponentialRampToValueAtTime(880, t + 0.8);
    } catch {
      // Ignore
    }
  }

  public toggleMute(): boolean {
    this.isMuted = !this.isMuted;
    return this.isMuted;
  }

  public dispose(): void {
    this.laserSynth?.dispose();
    this.explosionSynth?.dispose();
    this.powerupSynth?.dispose();
    this.hitSynth?.dispose();
    this.bossWarnSynth?.dispose();
    this.ultSynth?.dispose();
    this.initialized = false;
  }
}
