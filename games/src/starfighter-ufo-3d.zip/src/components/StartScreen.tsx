import { Coins, Flame, Keyboard, Play, ShoppingBag, Trophy } from 'lucide-react';
import { GENERATED_ASSETS, SHIPS_CATALOG, ShipId } from '../game/types';
import { AssetImage } from './AssetImage';

interface StartScreenProps {
  coins: number;
  highScore: number;
  equippedShipId: ShipId;
  ready: boolean;
  onStart: () => void;
  onOpenShop: () => void;
}

export function StartScreen({
  coins,
  highScore,
  equippedShipId,
  ready,
  onStart,
  onOpenShop,
}: StartScreenProps) {
  const equippedShip = SHIPS_CATALOG.find((s) => s.id === equippedShipId) || SHIPS_CATALOG[0];

  return (
    <div className="absolute inset-0 z-20 flex items-center justify-center p-4 sm:p-8 bg-[#02050d]/85 overflow-y-auto">
      {/* Subtle nebula backdrop artwork */}
      <div className="absolute inset-0 pointer-events-none opacity-45">
        <AssetImage
          src={GENERATED_ASSETS.spaceNebulaBg}
          alt="깊은 우주 성운 배경"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#02050d] via-[#02050d]/65 to-[#02050d]/80" />
      </div>

      <div className="relative z-10 w-full max-w-4xl grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        {/* Left: Hero Title & Launch Controls */}
        <div className="lg:col-span-7 flex flex-col justify-between bg-[#070d1d]/92 border border-slate-800 rounded-3xl p-6 sm:p-8">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold tracking-wider text-sky-400 mb-3">
              <span>3D 스페이스 아케이드 슈터</span>
              <span aria-hidden="true">·</span>
              <span>UFO 함대 요격 작전</span>
            </div>

            <h1 className="font-display text-4xl sm:text-6xl leading-[1.08] text-white tracking-tight mb-4 text-balance">
              스타파이터 3D
              <span className="block text-2xl sm:text-4xl text-emerald-400 mt-1">
                UFO 격추 작전
              </span>
            </h1>

            <p className="text-slate-300 text-sm sm:text-base leading-relaxed max-w-xl mb-6">
              성운 너머에서 침공하는 외계 UFO 함대와 거대 모선 보스를 격추하세요.
              전투에서 모은 코인으로 우주 격납고에서 새로운 전투기를 해금하고 무장을 강화할 수 있습니다.
            </p>

            {/* Unboxed Clean Metrics Row */}
            <div className="flex flex-wrap items-center gap-6 py-4 border-y border-slate-800/90 mb-6">
              <div className="flex items-center gap-2.5">
                <Coins className="w-5 h-5 text-amber-400 shrink-0" />
                <div>
                  <div className="text-[11px] text-slate-400">보유 코인</div>
                  <div className="text-xl font-bold text-amber-300 font-mono-num">
                    {coins.toLocaleString()}
                  </div>
                </div>
              </div>
              <div className="w-px h-8 bg-slate-800 hidden sm:block" />
              <div className="flex items-center gap-2.5">
                <Trophy className="w-5 h-5 text-sky-400 shrink-0" />
                <div>
                  <div className="text-[11px] text-slate-400">최고 기록</div>
                  <div className="text-xl font-bold text-white font-mono-num">
                    {highScore.toLocaleString()}
                  </div>
                </div>
              </div>
            </div>

            {/* Compact Controls Guide */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs sm:text-sm mb-6">
              <div className="flex items-start gap-2.5 bg-slate-900/80 border border-slate-800/90 rounded-xl p-3">
                <Keyboard className="w-4 h-4 text-sky-400 mt-0.5 shrink-0" />
                <div>
                  <div className="font-semibold text-slate-100">이동 및 사격</div>
                  <div className="text-slate-400 mt-0.5">← → / A D 또는 마우스·터치 드래그</div>
                </div>
              </div>
              <div className="flex items-start gap-2.5 bg-slate-900/80 border border-slate-800/90 rounded-xl p-3">
                <Flame className="w-4 h-4 text-amber-400 mt-0.5 shrink-0" />
                <div>
                  <div className="font-semibold text-slate-100">특수 기능 단축키</div>
                  <div className="text-slate-400 mt-0.5">[Shift / B] 메가 빔 · [P] 상점 · [V] 시점</div>
                </div>
              </div>
            </div>
          </div>

          {/* Primary Actions */}
          <div className="flex flex-col sm:flex-row gap-3">
            <button
              type="button"
              onClick={onStart}
              disabled={!ready}
              className="glow-cta flex-1 py-3.5 px-6 rounded-2xl bg-gradient-to-r from-sky-500 to-blue-600 text-white font-display text-xl sm:text-2xl tracking-wide flex items-center justify-center gap-2.5 cursor-pointer disabled:opacity-50 disabled:cursor-wait whitespace-nowrap"
            >
              <Play className="w-5 h-5 fill-current shrink-0" />
              <span>{ready ? '출격하기' : '에셋 로딩 중...'}</span>
            </button>

            <button
              type="button"
              onClick={onOpenShop}
              disabled={!ready}
              className="py-3.5 px-5 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-amber-500/45 text-amber-300 font-bold text-sm sm:text-base flex items-center justify-center gap-2 transition-colors cursor-pointer whitespace-nowrap"
            >
              <ShoppingBag className="w-4 h-4 shrink-0" />
              <span>격납고 상점</span>
            </button>
          </div>
        </div>

        {/* Right: Equipped Ship Spotlight + Threat Intel */}
        <div className="lg:col-span-5 flex flex-col justify-between bg-[#070d1d]/92 border border-slate-800 rounded-3xl p-5 sm:p-6">
          <div>
            <div className="flex items-center justify-between text-xs text-slate-400 mb-3">
              <span>현재 출격 편대기</span>
              <span className="text-sky-300 font-semibold">{equippedShip.subtitle}</span>
            </div>

            <div className="relative aspect-square w-full max-w-[260px] mx-auto rounded-2xl bg-black border border-slate-800/80 overflow-hidden mb-4">
              <AssetImage
                src={equippedShip.imageUrl}
                alt={equippedShip.name}
                className="w-full h-full object-contain p-2"
              />
            </div>

            <div className="text-center mb-5">
              <div className="text-xl font-bold text-white">{equippedShip.name}</div>
              <div className="text-xs font-semibold text-amber-300 mt-1">{equippedShip.statsText}</div>
            </div>
          </div>

          {/* Target Roster Strip */}
          <div className="pt-4 border-t border-slate-800/90">
            <div className="text-[11px] text-slate-400 mb-2.5">출현 적군 정찰 정보</div>
            <div className="grid grid-cols-4 gap-2">
              {[
                { img: GENERATED_ASSETS.ufoBasic, label: '정찰선' },
                { img: GENERATED_ASSETS.ufoFast, label: '고속기' },
                { img: GENERATED_ASSETS.ufoHeavy, label: '중장갑' },
                { img: GENERATED_ASSETS.bossMothership, label: '모선 보스' },
              ].map((enemy) => (
                <div
                  key={enemy.label}
                  className="bg-black border border-slate-800/80 rounded-xl p-1.5 flex flex-col items-center"
                >
                  <AssetImage
                    src={enemy.img}
                    alt={enemy.label}
                    className="w-11 h-11 object-contain"
                  />
                  <span className="text-[10px] text-slate-300 mt-1 whitespace-nowrap">
                    {enemy.label}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
