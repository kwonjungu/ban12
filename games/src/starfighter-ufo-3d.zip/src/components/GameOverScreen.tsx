import { Coins, RotateCcw, ShoppingBag, Trophy } from 'lucide-react';
import { GENERATED_ASSETS } from '../game/types';
import { AssetImage } from './AssetImage';

interface GameOverScreenProps {
  score: number;
  coins: number;
  highScore: number;
  onRestart: () => void;
  onOpenShop: () => void;
}

export function GameOverScreen({
  score,
  coins,
  highScore,
  onRestart,
  onOpenShop,
}: GameOverScreenProps) {
  return (
    <div className="absolute inset-0 z-20 flex flex-col items-center justify-center p-6 text-center bg-[#02050d]/88">
      <div className="w-full max-w-md bg-[#081021] border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl">
        <div className="w-20 h-20 mx-auto mb-4 rounded-2xl bg-black border border-rose-500/40 overflow-hidden">
          <AssetImage
            src={GENERATED_ASSETS.vfxExplosion}
            alt="전투기 파괴"
            className="w-full h-full object-contain p-1"
          />
        </div>

        <h2 className="text-4xl sm:text-5xl font-display text-rose-500 mb-2">
          MISSION FAILED
        </h2>
        <p className="text-slate-300 mb-6 text-sm">
          전투기가 파괴되었습니다. 정비를 마치고 다시 출격하세요.
        </p>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 mb-6 space-y-3">
          <div>
            <div className="text-xs text-slate-400 mb-1">최종 점수</div>
            <div className="text-4xl font-display text-white font-mono-num">
              {score.toLocaleString()}
            </div>
          </div>

          <div className="h-px bg-slate-800" />

          <div className="grid grid-cols-2 gap-4 pt-1">
            <div>
              <div className="text-xs text-amber-300/80 mb-1 flex items-center justify-center gap-1">
                <Coins className="w-3.5 h-3.5 text-amber-400" />
                <span>보유 코인</span>
              </div>
              <div className="text-lg font-bold text-amber-300 font-mono-num">
                {coins.toLocaleString()}
              </div>
            </div>

            <div>
              <div className="text-xs text-sky-300/80 mb-1 flex items-center justify-center gap-1">
                <Trophy className="w-3.5 h-3.5 text-sky-400" />
                <span>최고 기록</span>
              </div>
              <div className="text-lg font-bold text-white font-mono-num">
                {highScore.toLocaleString()}
              </div>
            </div>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <button
            type="button"
            onClick={onRestart}
            className="glow-cta flex-1 py-3.5 px-6 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 text-white font-display text-xl tracking-wide flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap"
          >
            <RotateCcw className="w-5 h-5 shrink-0" />
            <span>다시 도전하기</span>
          </button>

          <button
            type="button"
            onClick={onOpenShop}
            className="py-3.5 px-5 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-amber-500/45 text-amber-300 font-bold text-sm flex items-center justify-center gap-2 transition-colors cursor-pointer whitespace-nowrap"
          >
            <ShoppingBag className="w-4 h-4 shrink-0" />
            <span>상점</span>
          </button>
        </div>
      </div>
    </div>
  );
}
