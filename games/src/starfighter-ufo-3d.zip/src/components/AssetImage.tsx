import { useState } from 'react';
import { Sparkles } from 'lucide-react';

interface AssetImageProps {
  src: string;
  alt: string;
  className?: string;
}

export function AssetImage({ src, alt, className = '' }: AssetImageProps) {
  const [failed, setFailed] = useState(false);

  if (failed) {
    return (
      <div
        role="img"
        aria-label={alt}
        className={`flex items-center justify-center bg-gradient-to-br from-slate-900 via-sky-950/50 to-slate-950 text-sky-400 ${className}`}
      >
        <Sparkles className="w-5 h-5" />
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setFailed(true)}
      className={className}
    />
  );
}
