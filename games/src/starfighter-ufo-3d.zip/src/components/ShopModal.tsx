import { Check, Coins, Plane, Shield, Wrench, X, Zap } from 'lucide-react';
import {
  GENERATED_ASSETS,
  HudSnapshot,
  SaveData,
  SHIPS_CATALOG,
  ShipId,
  ShopTab,
} from '../game/types';
import { AssetImage } from './AssetImage';

interface ShopModalProps {
  save: SaveData;
  hud: HudSnapshot;
  activeTab: ShopTab;
  inBattle: boolean;
  onChangeTab: (tab: ShopTab) => void;
  onBuyOrEquipShip: (shipId: ShipId) => void;
  onBuyUpgrade: (id: 'weapon' | 'fireRate' | 'shield' | 'healAndHp' | 'speed' | 'ultGain') => void;
  onClose: () => void;
}

export function ShopModal({
  save,
  hud,
  activeTab,
  inBattle,
  onChangeTab,
  onBuyOrEquipShip,
  onBuyUpgrade,
  onClose,
}: ShopModalProps) {
  const upgrades = save.upgrades;

  const upgradeCards = [
    {
      id: 'weapon' as const,
      image: GENERATED_ASSETS.powerupWeapon,
      name: '기본 레이저 강화',
      desc: '기본 발사 탄환 수 증가 (최대 4연발 쿼드)',
      curLv: upgrades.weapon,
      maxLv: 4,
      cost: upgrades.weapon * 250,
      isMax: upgrades.weapon >= 4,
      lvText: `Lv.${upgrades.weapon} / 4`,
    },
    {
      id: 'fireRate' as const,
      image: GENERATED_ASSETS.vfxExplosion,
      name: '연사 쿨다운 단축',
      desc: '레이저 발사 간격이 대폭 빨라집니다',
      curLv: upgrades.fireRate,
      maxLv: 5,
      cost: (upgrades.fireRate + 1) * 180,
      isMax: upgrades.fireRate >= 5,
      lvText: `Lv.${upgrades.fireRate} / 5`,
    },
    {
      id: 'shield' as const,
      image: GENERATED_ASSETS.vfxShieldOrb,
      name: '플라즈마 에너지 실드',
      desc: '적 공격 또는 충돌을 1회 완벽 방어하는 보호막 장착',
      curLv: upgrades.shield ? 1 : 0,
      maxLv: 1,
      cost: 200,
      isMax: upgrades.shield,
      lvText: upgrades.shield ? '장착됨' : '미장착',
    },
    {
      id: 'healAndHp' as const,
      image: GENERATED_ASSETS.powerupHealth,
      name: '장갑 증설 & 긴급 수리',
      desc: '체력 1칸 즉시 회복 (최대 체력 시 한도 +1 확장)',
      curLv: upgrades.maxHp,
      maxLv: 5,
      cost: 150 + upgrades.maxHp * 100,
      isMax: hud.hp >= hud.maxHp && upgrades.maxHp >= 5,
      lvText: `Lv.${upgrades.maxHp} / 5`,
    },
    {
      id: 'speed' as const,
      image: GENERATED_ASSETS.shipViper,
      name: '추진기 출력 업그레이드',
      desc: '전투기 좌우 선회 및 회피 기동 속도 증가',
      curLv: upgrades.speed,
      maxLv: 4,
      cost: (upgrades.speed + 1) * 140,
      isMax: upgrades.speed >= 4,
      lvText: `Lv.${upgrades.speed} / 4`,
    },
    {
      id: 'ultGain' as const,
      image: GENERATED_ASSETS.vfxExplosion,
      name: '메가 빔 코어 증폭',
      desc: 'UFO 격추 시 필살기 게이지 충전량 +25%씩 증가',
      curLv: upgrades.ultGain,
      maxLv: 4,
      cost: (upgrades.ultGain + 1) * 200,
      isMax: upgrades.ultGain >= 4,
      lvText: `Lv.${upgrades.ultGain} / 4`,
    },
  ];

  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center p-4 bg-[#02050d]/88">
      <div className="bg-[#081021] border border-amber-500/45 rounded-3xl p-5 sm:p-6 max-w-3xl w-full shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex justify-between items-center border-b border-slate-800 pb-4 mb-4 gap-3">
          <div>
            <h2 className="text-2xl sm:text-3xl font-display text-amber-400">
              우주 격납고 상점
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
              코인으로 신규 스타파이터를 해금하거나 무장을 강화하세요.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <div className="bg-amber-950/80 border border-amber-500/40 px-3.5 py-2 rounded-2xl flex items-center gap-2">
              <Coins className="w-4 h-4 text-amber-400" />
              <span className="text-base sm:text-xl font-bold text-amber-300 font-mono-num">
                {save.coins.toLocaleString()}
              </span>
            </div>

            <button
              type="button"
              onClick={onClose}
              aria-label="상점 닫기"
              className="w-9 h-9 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-300 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Category Tabs */}
        <div className="grid grid-cols-2 gap-2 p-1 bg-slate-900/90 rounded-2xl border border-slate-800 mb-4">
          <button
            type="button"
            onClick={() => onChangeTab('ships')}
            className={`py-2.5 px-3 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'ships'
                ? 'bg-sky-600 text-white'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Plane className="w-4 h-4 shrink-0" />
            <span>전투기 격납고 (구매/탑승)</span>
          </button>

          <button
            type="button"
            onClick={() => onChangeTab('upgrades')}
            className={`py-2.5 px-3 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'upgrades'
                ? 'bg-amber-500 text-slate-950'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Wrench className="w-4 h-4 shrink-0" />
            <span>무기 및 장갑 강화</span>
          </button>
        </div>

        {/* Item Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 overflow-y-auto pr-1 mb-4 hangar-scroll">
          {activeTab === 'ships'
            ? SHIPS_CATALOG.map((ship) => {
                const isOwned = save.ownedShips.includes(ship.id);
                const isEquipped = save.equippedShipId === ship.id;
                const canAfford = !isOwned && save.coins >= ship.cost;

                return (
                  <div
                    key={ship.id}
                    className={`p-4 rounded-2xl border flex flex-col justify-between transition-colors ${
                      isEquipped
                        ? 'bg-sky-950/45 border-sky-400/70'
                        : isOwned
                          ? 'bg-slate-900/90 border-emerald-500/40'
                          : 'bg-slate-900/70 border-slate-800'
                    }`}
                  >
                    <div>
                      <div className="flex items-start gap-3 mb-2">
                        <div className="w-20 h-20 rounded-xl bg-black border border-slate-800 overflow-hidden shrink-0">
                          <AssetImage
                            src={ship.imageUrl}
                            alt={ship.name}
                            className="w-full h-full object-contain p-1"
                          />
                        </div>

                        <div className="min-w-0 flex-1">
                          <div className="flex items-center justify-between gap-2">
                            <span className="font-bold text-white text-base truncate">
                              {ship.name}
                            </span>
                          </div>
                          <div className="text-xs text-slate-400 mt-0.5">
                            {isEquipped ? (
                              <span className="text-sky-300 font-semibold">현재 탑승 중</span>
                            ) : isOwned ? (
                              <span className="text-emerald-400 font-semibold">보유함</span>
                            ) : (
                              <span className="text-amber-300 font-semibold">미보유</span>
                            )}
                            <span className="mx-1.5 text-slate-600">·</span>
                            <span>{ship.statsText}</span>
                          </div>
                          <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                            {ship.desc}
                          </p>
                        </div>
                      </div>
                    </div>

                    <button
                      type="button"
                      disabled={isEquipped || (!isOwned && !canAfford)}
                      onClick={() => onBuyOrEquipShip(ship.id)}
                      className={`mt-3 w-full py-2.5 px-4 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 transition-colors whitespace-nowrap ${
                        isEquipped
                          ? 'bg-sky-900/50 text-sky-200 cursor-default'
                          : isOwned
                            ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 cursor-pointer'
                            : canAfford
                              ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 cursor-pointer'
                              : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                      }`}
                    >
                      {isEquipped ? (
                        <>
                          <Check className="w-4 h-4 shrink-0" />
                          <span>현재 출격 기체</span>
                        </>
                      ) : isOwned ? (
                        <span>이 기체로 탑승하기</span>
                      ) : (
                        <>
                          <Coins className="w-4 h-4 shrink-0" />
                          <span className="font-mono-num">{ship.cost.toLocaleString()}</span>
                          <span>기체 구매</span>
                        </>
                      )}
                    </button>
                  </div>
                );
              })
            : upgradeCards.map((item) => {
                const canAfford = !item.isMax && save.coins >= item.cost;

                return (
                  <div
                    key={item.id}
                    className={`p-4 rounded-2xl border flex flex-col justify-between transition-colors ${
                      item.isMax
                        ? 'bg-slate-900/60 border-emerald-500/40'
                        : canAfford
                          ? 'bg-slate-900/90 border-amber-500/40'
                          : 'bg-slate-900/65 border-slate-800'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <div className="w-14 h-14 rounded-xl bg-black border border-slate-800 overflow-hidden shrink-0">
                        <AssetImage
                          src={item.image}
                          alt={item.name}
                          className="w-full h-full object-contain p-1"
                        />
                      </div>

                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between gap-2">
                          <span className="font-bold text-white text-sm sm:text-base truncate">
                            {item.name}
                          </span>
                          <span className="text-xs font-mono-num text-sky-300 shrink-0">
                            {item.lvText}
                          </span>
                        </div>
                        <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
                          {item.desc}
                        </p>
                      </div>
                    </div>

                    <button
                      type="button"
                      disabled={!canAfford}
                      onClick={() => onBuyUpgrade(item.id)}
                      className={`mt-3 w-full py-2.5 px-4 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 transition-colors whitespace-nowrap ${
                        item.isMax
                          ? 'bg-emerald-900/50 text-emerald-300 cursor-default'
                          : canAfford
                            ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 cursor-pointer'
                            : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                      }`}
                    >
                      {item.isMax ? (
                        <>
                          <Shield className="w-4 h-4 shrink-0" />
                          <span>강화 완료</span>
                        </>
                      ) : (
                        <>
                          <Zap className="w-4 h-4 shrink-0" />
                          <span className="font-mono-num">{item.cost.toLocaleString()}</span>
                          <span>업그레이드</span>
                        </>
                      )}
                    </button>
                  </div>
                );
              })}
        </div>

        {/* Footer CTA */}
        <button
          type="button"
          onClick={onClose}
          className="w-full py-3 rounded-2xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 text-white font-display text-lg sm:text-xl tracking-wide transition-colors cursor-pointer whitespace-nowrap"
        >
          {inBattle ? '전투 복귀하기' : '출격 준비 화면으로 돌아가기'}
        </button>
      </div>
    </div>
  );
}
