import { Camera, Coins, Flame, Heart, Shield, ShoppingBag, Volume2, VolumeX } from 'lucide-react';
import { CameraMode, GENERATED_ASSETS, HudSnapshot } from '../game/types';
import { AssetImage } from './AssetImage';

interface GameHudProps {
  hud: HudSnapshot;
  cameraMode: CameraMode;
  isMuted: boolean;
  onOpenShop: () => void;
  onToggleCamera: () => void;
  onToggleMute: () => void;
  onActivateUlt: () => void;
}

const WEAPON_LABELS = ['', '', '더블 레이저', '트리플 레이저', '쿼드 레이저 MAX'];

export function GameHud({
  hud,
  cameraMode,
  isMuted,
  onOpenShop,
  onToggleCamera,
  onToggleMute,
  onActivateUlt,
}: GameHudProps) {
  const bossPct = Math.max(0, Math.ceil((hud.bossHp / Math.max(1, hud.bossMaxHp)) * 100));
  const ultReady = hud.ultCharge >= 100 && !hud.ultActive;

  return (
    <>
      {/* Top Bar HUD */}
      <header className="absolute top-0 left-0 w-full p-3 sm:p-4 flex flex-wrap gap-2 justify-between items-start z-10 pointer-events-none">
        {/* Left: Score & Coins */}
        <div className="flex items-center gap-4 sm:gap-6 bg-[#050914]/80 border border-slate-800/90 rounded-2xl px-3.5 py-2">
          <div>
            <div className="text-[10px] sm:text-xs text-sky-400 font-bold tracking-wider">SCORE</div>
            <div className="text-xl sm:text-3xl font-bold font-display tracking-wider text-white font-mono-num">
              {hud.score.toLocaleString()}
            </div>
          </div>

          <div className="w-px h-7 bg-slate-800" />

          <div className="flex items-center gap-2">
            <Coins className="w-4 h-4 sm:w-5 sm:h-5 text-amber-400 shrink-0" />
            <div>
              <div className="text-[10px] text-amber-300/80 font-semibold">COINS</div>
              <div className="text-sm sm:text-xl font-bold text-amber-300 font-mono-num">
                {hud.coins.toLocaleString()}
              </div>
            </div>
          </div>

          <div className="w-px h-7 bg-slate-800 sm:hidden" />

          <div className="sm:hidden">
            <div className="text-[10px] text-purple-300/80 font-semibold">STAGE</div>
            <div className="text-sm font-bold text-purple-300 font-mono-num">{hud.level}</div>
          </div>
        </div>

        {/* Center: Stage & Weapon Status */}
        <div className="hidden sm:flex flex-col items-center bg-[#050914]/80 border border-slate-800/90 rounded-2xl px-4 py-1.5">
          <div className="text-xs sm:text-sm text-purple-300 font-bold tracking-wide">
            STAGE <span className="font-mono-num">{hud.level}</span>
          </div>
          {hud.powerLevel > 1 && (
            <div className="flex items-center gap-1.5 text-xs text-amber-300 font-semibold mt-0.5">
              <AssetImage
                src={GENERATED_ASSETS.powerupWeapon}
                alt="무기 강화"
                className="w-4 h-4 rounded-full object-cover"
              />
              <span>{WEAPON_LABELS[hud.powerLevel] || '강화 레이저'}</span>
            </div>
          )}
        </div>

        {/* Right: Health, Shield & Controls */}
        <div className="flex items-center gap-1.5 sm:gap-2 pointer-events-auto ml-auto">
          <div className="flex items-center gap-1 bg-[#050914]/80 border border-slate-800/90 rounded-xl px-2.5 py-1.5">
            {Array.from({ length: hud.maxHp }).map((_, idx) => (
              <Heart
                key={idx}
                className={`w-4 h-4 sm:w-5 sm:h-5 transition-opacity ${
                  idx < hud.hp
                    ? 'text-rose-500 fill-rose-500'
                    : 'text-slate-700 fill-slate-800/60'
                }`}
              />
            ))}
            {hud.shieldActive && (
              <Shield
                className="w-4 h-4 sm:w-5 sm:h-5 text-sky-400 fill-sky-400/25 ml-1"
                aria-label="에너지 실드 장착됨"
              />
            )}
          </div>

          <button
            type="button"
            onClick={onOpenShop}
            title="상점 열기 (P)"
            className="h-9 sm:h-10 px-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs sm:text-sm flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            <ShoppingBag className="w-4 h-4 shrink-0" />
            <span className="hidden sm:inline">상점</span>
          </button>

          <button
            type="button"
            onClick={onToggleCamera}
            title="시점 전환 (V)"
            className="h-9 sm:h-10 px-2.5 sm:px-3 rounded-xl bg-[#0a1224]/90 hover:bg-slate-800 border border-slate-700 text-sky-300 font-semibold text-xs flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            <Camera className="w-4 h-4 shrink-0" />
            <span className="hidden md:inline">
              {cameraMode === 'ANGLED' ? '3D 뷰' : '백뷰'}
            </span>
          </button>

          <button
            type="button"
            onClick={onToggleMute}
            aria-label={isMuted ? '음소거 해제' : '음소거'}
            className="h-9 w-9 sm:h-10 sm:w-10 rounded-xl bg-[#0a1224]/90 hover:bg-slate-800 border border-slate-700 text-slate-200 flex items-center justify-center transition-colors cursor-pointer shrink-0"
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4" />}
          </button>
        </div>
      </header>

      {/* Boss Health Bar */}
      {hud.bossActive && (
        <div className="absolute top-28 sm:top-20 left-1/2 -translate-x-1/2 w-11/12 max-w-md z-10 pointer-events-none">
          <div className="bg-[#050914]/88 border border-rose-500/50 rounded-2xl p-2.5">
            <div className="flex justify-between items-center text-xs sm:text-sm font-bold text-rose-300 mb-1.5">
              <div className="flex items-center gap-2">
                <AssetImage
                  src={GENERATED_ASSETS.bossMothership}
                  alt="모선 보스"
                  className="w-5 h-5 rounded-full object-cover bg-black"
                />
                <span>거대 모선 보스</span>
              </div>
              <span className="font-mono-num">{bossPct}%</span>
            </div>
            <div className="w-full h-3 bg-slate-900 rounded-full border border-rose-500/40 overflow-hidden p-0.5">
              <div
                className="h-full bg-gradient-to-r from-rose-600 via-orange-500 to-amber-400 rounded-full transition-all duration-100"
                style={{ width: `${bossPct}%` }}
              />
            </div>
          </div>
        </div>
      )}

      {/* Boss Warning Banner */}
      {hud.bossWarningVisible && (
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 z-20 pointer-events-none text-center w-full px-4">
          <div className="inline-flex items-center gap-4 bg-rose-950/95 border-2 border-rose-500 px-6 py-4 rounded-2xl shadow-2xl">
            <AssetImage
              src={GENERATED_ASSETS.bossMothership}
              alt="보스 경고"
              className="w-12 h-12 rounded-xl object-contain bg-black border border-rose-500/40"
            />
            <div className="text-left">
              <div className="text-rose-400 text-xs font-extrabold tracking-widest">WARNING</div>
              <div className="text-2xl sm:text-3xl font-display text-white mt-0.5">
                거대 모선 보스 출현!
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Bottom Ultimate Gauge */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center w-64 sm:w-72">
        <button
          type="button"
          onClick={onActivateUlt}
          disabled={!ultReady}
          className={`w-full py-2.5 px-4 rounded-2xl border-2 font-bold text-sm sm:text-base flex items-center justify-between transition-all duration-150 ${
            hud.ultActive
              ? 'bg-gradient-to-r from-amber-500 to-rose-600 border-yellow-200 text-white'
              : ultReady
                ? 'bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 border-yellow-200 text-white cursor-pointer ult-ready-glow hover:scale-[1.02] active:scale-[0.98]'
                : 'bg-[#050914]/90 border-slate-700 text-slate-400 cursor-not-allowed'
          }`}
        >
          <span className="flex items-center gap-2 whitespace-nowrap">
            <Flame className={`w-4 h-4 ${ultReady || hud.ultActive ? 'text-yellow-100' : 'text-amber-500'}`} />
            <span>
              {hud.ultActive
                ? '하이퍼 빔 발사 중!'
                : ultReady
                  ? '필살기 발동!'
                  : '필살기 충전 중'}
            </span>
          </span>
          <span className="font-mono-num text-xs sm:text-sm">{hud.ultCharge}%</span>
        </button>

        <div className="w-full h-2 bg-slate-900 rounded-full mt-1.5 overflow-hidden border border-slate-800">
          <div
            className="h-full bg-gradient-to-r from-amber-500 via-yellow-400 to-rose-500 transition-all duration-150"
            style={{ width: `${hud.ultCharge}%` }}
          />
        </div>
        <div className="text-[11px] text-slate-400 mt-1">
          100% 충전 시 클릭 또는 <span className="text-amber-300 font-semibold">[Shift / B]</span>
        </div>
      </div>
    </>
  );
}
