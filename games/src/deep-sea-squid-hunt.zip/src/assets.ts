// Scary Mode Assets
import scaryBgSrc from './assets/images/abyss_stage_bg_1789882075873.jpg';
import scaryMonsterSrc from './assets/images/monster_squid_1789882087344.jpg';
import scaryDiamondSrc from './assets/images/diamond_squid_1789882099264.jpg';
import scaryBombSrc from './assets/images/bomb_squid_1789882108419.jpg';
import scaryHammerSrc from './assets/images/hammer_weapon_1789882118927.jpg';

// Cute Mode Assets
import cuteBgSrc from './assets/images/cute_ocean_bg_1789882618858.jpg';
import cutePinkSquidSrc from './assets/images/cute_pink_squid_1789882540429.jpg';
import cuteDiamondSquidSrc from './assets/images/cute_diamond_squid_1789882573306.jpg';
import cuteBombSquidSrc from './assets/images/cute_bomb_squid_1789882605298.jpg';
import cuteSqueakyHammerSrc from './assets/images/cute_squeaky_hammer_1789882555914.jpg';

import { GameMode } from './types';

export interface ModeAssets {
  bg: HTMLImageElement | null;
  normal: HTMLImageElement | null;
  diamond: HTMLImageElement | null;
  bomb: HTMLImageElement | null;
  hammer: HTMLImageElement | null;
}

export interface AllGameAssets {
  scary: ModeAssets;
  cute: ModeAssets;
}

export const ASSET_SOURCES = {
  scary: {
    bg: scaryBgSrc,
    normal: scaryMonsterSrc,
    diamond: scaryDiamondSrc,
    bomb: scaryBombSrc,
    hammer: scaryHammerSrc,
  },
  cute: {
    bg: cuteBgSrc,
    normal: cutePinkSquidSrc,
    diamond: cuteDiamondSquidSrc,
    bomb: cuteBombSquidSrc,
    hammer: cuteSqueakyHammerSrc,
  },
};

export function loadAllGameAssets(onReady: (assets: AllGameAssets) => void): AllGameAssets {
  const assets: AllGameAssets = {
    scary: { bg: null, normal: null, diamond: null, bomb: null, hammer: null },
    cute: { bg: null, normal: null, diamond: null, bomb: null, hammer: null },
  };

  const toLoad: { mode: GameMode; key: keyof ModeAssets; src: string }[] = [
    { mode: 'scary', key: 'bg', src: scaryBgSrc },
    { mode: 'scary', key: 'normal', src: scaryMonsterSrc },
    { mode: 'scary', key: 'diamond', src: scaryDiamondSrc },
    { mode: 'scary', key: 'bomb', src: scaryBombSrc },
    { mode: 'scary', key: 'hammer', src: scaryHammerSrc },
    { mode: 'cute', key: 'bg', src: cuteBgSrc },
    { mode: 'cute', key: 'normal', src: cutePinkSquidSrc },
    { mode: 'cute', key: 'diamond', src: cuteDiamondSquidSrc },
    { mode: 'cute', key: 'bomb', src: cuteBombSquidSrc },
    { mode: 'cute', key: 'hammer', src: cuteSqueakyHammerSrc },
  ];

  let loadedCount = 0;

  toLoad.forEach(({ mode, key, src }) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.src = src;
    img.onload = () => {
      assets[mode][key] = img;
      loadedCount++;
      if (loadedCount === toLoad.length) {
        onReady(assets);
      }
    };
    img.onerror = () => {
      loadedCount++;
      if (loadedCount === toLoad.length) {
        onReady(assets);
      }
    };
  });

  return assets;
}
