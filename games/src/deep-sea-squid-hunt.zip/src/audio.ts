// Web Audio API Synthesizer for Deep-Sea Squid Whack-a-Mole

class SoundManager {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  public muted: boolean = false;

  private initCtx(): AudioContext | null {
    if (!this.ctx && typeof window !== 'undefined') {
      try {
        const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        if (AudioCtx) {
          this.ctx = new AudioCtx();
          this.master = this.ctx.createGain();
          this.master.gain.value = 0.28;
          this.master.connect(this.ctx.destination);
        }
      } catch {
        this.ctx = null;
        this.master = null;
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public ensureAudio() {
    this.initCtx();
  }

  public toggleMute(): boolean {
    this.muted = !this.muted;
    if (!this.muted) {
      this.initCtx();
      this.playTone(440, 0.09, 'sawtooth', 0.22);
    }
    return this.muted;
  }

  public playTone(freq: number, dur: number, type: OscillatorType = 'sawtooth', vol = 0.3, delay = 0, slideTo?: number) {
    if (this.muted) return;
    const ac = this.initCtx();
    if (!ac || !this.master) return;

    try {
      const t0 = ac.currentTime + delay;
      const osc = ac.createOscillator();
      const g = ac.createGain();

      osc.type = type;
      osc.frequency.setValueAtTime(freq, t0);
      if (slideTo) {
        osc.frequency.exponentialRampToValueAtTime(Math.max(30, slideTo), t0 + dur);
      }

      g.gain.setValueAtTime(0.0001, t0);
      g.gain.exponentialRampToValueAtTime(vol, t0 + 0.012);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);

      osc.connect(g);
      g.connect(this.master);

      osc.start(t0);
      osc.stop(t0 + dur + 0.03);
    } catch {
      // Audio node failure silently handled
    }
  }

  public playNoiseBurst(dur: number, vol = 0.3, cutoff = 1200, delay = 0, sweepTo?: number) {
    if (this.muted) return;
    const ac = this.initCtx();
    if (!ac || !this.master) return;

    try {
      const t0 = ac.currentTime + delay;
      const len = Math.max(1, Math.floor(ac.sampleRate * dur));
      const buf = ac.createBuffer(1, len, ac.sampleRate);
      const d = buf.getChannelData(0);
      for (let i = 0; i < len; i++) {
        d[i] = (Math.random() * 2 - 1) * (1 - i / len);
      }

      const src = ac.createBufferSource();
      src.buffer = buf;

      const f = ac.createBiquadFilter();
      f.type = 'lowpass';
      f.frequency.setValueAtTime(cutoff, t0);
      if (sweepTo) {
        f.frequency.exponentialRampToValueAtTime(Math.max(60, sweepTo), t0 + dur);
      }

      const g = ac.createGain();
      g.gain.setValueAtTime(vol, t0);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);

      src.connect(f);
      f.connect(g);
      g.connect(this.master);

      src.start(t0);
      src.stop(t0 + dur + 0.02);
    } catch {
      // Noise burst failure silently handled
    }
  }

  public playSqueak() {
    this.playTone(950, 0.08, 'sine', 0.28, 0, 1600);
  }

  public playHit(combo: number, mode: 'cute' | 'scary' = 'cute') {
    const scale = [392.0, 440.0, 493.9, 523.3, 587.3, 659.3, 698.5, 784.0, 880.0, 987.8, 1046.5];
    const idx = Math.min(scale.length - 1, Math.max(0, combo - 1));
    const f = scale[idx];

    if (mode === 'cute') {
      // Cute Squeaky Arcade Hammer (뿅망치 뿅!)
      this.playTone(880 + (combo % 8) * 40, 0.07, 'sine', 0.32, 0, 1650);
      this.playTone(f, 0.12, 'triangle', 0.24, 0.015);
    } else {
      // Heavy Industrial Monster Sledgehammer
      this.playNoiseBurst(0.08, 0.4, 2000, 0, 400);
      this.playTone(f * 0.75, 0.12, 'sawtooth', 0.3, 0.005);
    }
  }

  public playGold() {
    this.playTone(659.3, 0.09, 'triangle', 0.28, 0);
    this.playTone(880.0, 0.09, 'triangle', 0.28, 0.07);
    this.playTone(1174.6, 0.15, 'triangle', 0.3, 0.14);
  }

  public playDiamond() {
    this.playTone(1046.5, 0.08, 'sine', 0.35, 0);
    this.playTone(1318.5, 0.08, 'sine', 0.35, 0.06);
    this.playTone(1567.9, 0.09, 'sine', 0.38, 0.12);
    this.playTone(2093.0, 0.22, 'sine', 0.3, 0.18);
  }

  public playBomb() {
    this.playNoiseBurst(0.5, 0.7, 800, 0, 50);
    this.playTone(120, 0.5, 'sawtooth', 0.38, 0, 30);
  }

  public playMiss() {
    this.playNoiseBurst(0.12, 0.2, 600, 0, 180);
  }

  public playEscape() {
    this.playTone(220, 0.13, 'sawtooth', 0.18, 0, 120);
  }

  public playCombo(level: number) {
    const b = 440 * Math.pow(1.06, level);
    this.playTone(b, 0.1, 'triangle', 0.25, 0);
    this.playTone(b * 1.5, 0.12, 'sawtooth', 0.22, 0.06);
  }

  public playStart() {
    this.playTone(220, 0.11, 'sawtooth', 0.28, 0);
    this.playTone(330, 0.11, 'sawtooth', 0.28, 0.1);
    this.playTone(440, 0.22, 'sawtooth', 0.3, 0.2);
  }

  public playGameOver() {
    this.playTone(440, 0.16, 'sawtooth', 0.25, 0);
    this.playTone(330, 0.16, 'sawtooth', 0.25, 0.15);
    this.playTone(220, 0.4, 'sawtooth', 0.28, 0.3);
  }
}

export const sounds = new SoundManager();
