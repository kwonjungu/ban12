import React, { useEffect, useRef, useState, useCallback } from 'react';
import { Volume2, VolumeX, RotateCcw, Play, Zap, ShieldAlert, Sparkles, Gem, Heart, Skull, Smile } from 'lucide-react';
import { Hole, Particle, PopText, GridLayout, SquidType, GameMode } from './types';
import { loadAllGameAssets, AllGameAssets, ASSET_SOURCES } from './assets';
import { sounds } from './audio';

const BEST_STORAGE_KEY_PREFIX = 'whackamole_squid_best_';
const GAME_TIME = 60;

export default function App() {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Active Game Mode: 'cute' (귀여운 모드) by default, or 'scary' (무서운 모드)
  const [mode, setMode] = useState<GameMode>('cute');
  const [gameState, setGameState] = useState<'title' | 'play' | 'over'>('title');
  const [score, setScore] = useState(0);
  const [lives, setLives] = useState(3);
  const [timeLeft, setTimeLeft] = useState(GAME_TIME);
  const [combo, setCombo] = useState(0);
  const [bestScore, setBestScore] = useState(0);
  const [isMuted, setIsMuted] = useState(sounds.muted);
  const [bannerText, setBannerText] = useState<string | null>(null);
  const [isNewRecord, setIsNewRecord] = useState(false);
  const [finalStats, setFinalStats] = useState({ accuracy: 0, maxCombo: 0, grade: 'C', gradeName: '', comment: '' });

  // Load high score per mode
  useEffect(() => {
    try {
      const v = localStorage.getItem(`${BEST_STORAGE_KEY_PREFIX}${mode}`);
      const n = parseInt(v || '0', 10);
      setBestScore(Number.isFinite(n) && n > 0 ? n : 0);
    } catch {
      setBestScore(0);
    }
  }, [mode]);

  // High performance game state ref (avoids state thrashing in 60fps canvas loop)
  const gameRef = useRef<{
    mode: GameMode;
    state: 'title' | 'play' | 'over';
    score: number;
    lives: number;
    combo: number;
    maxCombo: number;
    swings: number;
    hits: number;
    timeLeft: number;
    elapsed: number;
    spawnTimer: number;
    shake: number;
    hitstop: number;
    flash: number;
    flashColor: string;
    particles: Particle[];
    pops: PopText[];
    holes: Hole[];
    events: { t: number; text: string; done: boolean }[];
    lastTickSec: number;
    hammer: { x: number; y: number; swing: number; show: number };
    bgTime: number;
    bgBubbles: { x: number; y: number; r: number; speed: number; seed: number; color?: string }[];
    layout: GridLayout | null;
    width: number;
    height: number;
    dpr: number;
    assets: AllGameAssets;
  }>({
    mode: 'cute',
    state: 'title',
    score: 0,
    lives: 3,
    combo: 0,
    maxCombo: 0,
    swings: 0,
    hits: 0,
    timeLeft: GAME_TIME,
    elapsed: 0,
    spawnTimer: 0.35,
    shake: 0,
    hitstop: 0,
    flash: 0,
    flashColor: '255,255,255',
    particles: [],
    pops: [],
    holes: Array.from({ length: 9 }, () => ({
      state: 'idle',
      type: 'normal',
      time: 0,
      dur: 1,
      hitTime: 0,
      seed: Math.random() * 10,
    })),
    events: [],
    lastTickSec: -1,
    hammer: { x: -999, y: -999, swing: 0, show: 0 },
    bgTime: 0,
    bgBubbles: Array.from({ length: 26 }, () => ({
      x: Math.random() * 400,
      y: Math.random() * 600,
      r: 2 + Math.random() * 5,
      speed: 12 + Math.random() * 24,
      seed: Math.random() * 10,
    })),
    layout: null,
    width: 360,
    height: 480,
    dpr: 1,
    assets: {
      scary: { bg: null, normal: null, diamond: null, bomb: null, hammer: null },
      cute: { bg: null, normal: null, diamond: null, bomb: null, hammer: null },
    },
  });

  // Keep gameRef mode synchronized
  useEffect(() => {
    gameRef.current.mode = mode;
  }, [mode]);

  // Safe rounded rect helper
  const drawRoundedRect = (ctx: CanvasRenderingContext2D, x: number, y: number, width: number, height: number, radius: number) => {
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.lineTo(x + width - radius, y);
    ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
    ctx.lineTo(x + width, y + height - radius);
    ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
    ctx.lineTo(x + radius, y + height);
    ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
    ctx.lineTo(x, y + radius);
    ctx.quadraticCurveTo(x, y, x + radius, y);
    ctx.closePath();
    ctx.fill();
  };

  const showBanner = useCallback((text: string) => {
    setBannerText(text);
    const timer = setTimeout(() => {
      setBannerText(null);
    }, 2200);
    return () => clearTimeout(timer);
  }, []);

  const triggerShake = (val: number) => {
    gameRef.current.shake = Math.min(24, gameRef.current.shake + val);
  };

  const triggerFlash = (val: number, color: string) => {
    gameRef.current.flash = Math.max(gameRef.current.flash, val);
    gameRef.current.flashColor = color;
  };

  const addParticles = (x: number, y: number, count: number, colors: string[], power: number, kind: Particle['kind']) => {
    const list = gameRef.current.particles;
    for (let i = 0; i < count; i++) {
      const a = Math.random() * Math.PI * 2;
      const sp = (0.35 + Math.random()) * power;
      list.push({
        x,
        y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp - power * 0.35,
        life: 0.45 + Math.random() * 0.45,
        max: 0.9,
        r: (kind === 'smoke' ? 7 : 3.5) + Math.random() * 4,
        c: colors[(Math.random() * colors.length) | 0],
        kind: kind || 'dot',
        rot: Math.random() * 6.3,
        vr: (Math.random() - 0.5) * 12,
      });
    }
    if (list.length > 260) {
      list.splice(0, list.length - 260);
    }
  };

  const addPop = (x: number, y: number, text: string, c: string, size = 26) => {
    const pops = gameRef.current.pops;
    pops.push({
      id: Math.random(),
      x,
      y,
      text,
      c,
      life: 0.95,
      size,
      vy: -52,
    });
    if (pops.length > 24) pops.shift();
  };

  const molePopProgress = (m: Hole) => {
    if (m.state === 'hit') return 1;
    if (m.state !== 'up') return 0;
    const riseT = 0.12;
    const sinkT = 0.16;
    if (m.time < riseT) {
      const k = m.time / riseT;
      return 1 - Math.pow(1 - k, 3);
    }
    if (m.time > m.dur - sinkT) {
      const k2 = Math.max(0, (m.dur - m.time) / sinkT);
      return k2 * k2;
    }
    return 1;
  };

  const multiplier = (cmb: number) => Math.min(8, 1 + Math.floor(cmb / 3));

  const hitMole = (idx: number) => {
    const g = gameRef.current;
    const m = g.holes[idx];
    const L = g.layout;
    if (!L) return;

    const c = L.cells[idx];
    const pop = molePopProgress(m);
    const mx = c.cx;
    const my = c.cy - L.rise * pop * 0.55;
    const isCute = g.mode === 'cute';

    if (m.type === 'bomb') {
      m.state = 'hit';
      m.hitTime = 0;
      g.score = Math.max(0, g.score - 20);
      g.lives -= 1;
      g.combo = 0;
      setScore(g.score);
      setLives(g.lives);
      setCombo(0);

      triggerShake(22);
      triggerFlash(0.65, isCute ? '244,114,182' : '239,68,68');
      g.hitstop = 0.1;
      addParticles(mx, my, 32, isCute ? ['#1e1b4b', '#f43f5e', '#ec4899', '#6366f1'] : ['#020617', '#ef4444', '#7f1d1d'], 340, 'smoke');
      addPop(mx, my - 12, isCute ? '삐진 먹물 뿜기! -20' : '먹물 폭탄! -20', '#f43f5e', 30);
      sounds.playBomb();

      if (g.lives <= 0) {
        setTimeout(() => triggerGameOver(), 260);
      }
      return;
    }

    g.combo += 1;
    if (g.combo > g.maxCombo) g.maxCombo = g.combo;
    g.hits += 1;

    let base = 10;
    if (m.type === 'gold') base = 50;
    else if (m.type === 'diamond') base = 150;

    const gain = base * multiplier(g.combo);
    g.score += gain;

    setScore(g.score);
    setCombo(g.combo);

    m.state = 'hit';
    m.hitTime = 0;
    g.hitstop = m.type === 'diamond' ? 0.09 : m.type === 'gold' ? 0.075 : 0.05;
    triggerShake(m.type === 'diamond' ? 14 : m.type === 'gold' ? 10 : 5);

    if (m.type === 'diamond') {
      triggerFlash(0.45, '56,189,248');
      addParticles(mx, my, 34, ['#38bdf8', '#7dd3fc', '#ffffff', '#f472b6'], 350, 'star');
      addPop(mx, my - 12, `💎 +${gain}`, '#38bdf8', 40);
      sounds.playDiamond();
    } else if (m.type === 'gold') {
      triggerFlash(0.35, '253,224,71');
      addParticles(mx, my, 28, ['#fde047', '#eab308', '#ffffff', '#f472b6'], 300, 'star');
      addPop(mx, my - 12, `✨ +${gain}`, '#fde047', 36);
      sounds.playGold();
    } else {
      addParticles(mx, my, 18, isCute ? ['#f472b6', '#fb7185', '#ffffff', '#fbcfe8'] : ['#ef4444', '#b91c1c', '#ffffff'], 260, 'dot');
      addPop(mx, my - 12, isCute ? `뿅! +${gain}` : `+${gain}`, '#ffffff', 28);
      sounds.playHit(g.combo, g.mode);
    }

    if (g.combo % 5 === 0) {
      const bonus = g.combo * 5;
      g.score += bonus;
      setScore(g.score);
      addPop(g.width * 0.5, L.top + L.ch * 0.3, `${g.combo}연속 팡팡! +${bonus}`, isCute ? '#f472b6' : '#fca5a5', 26);
      sounds.playCombo(Math.floor(g.combo / 5));
      showBanner(isCute ? `💖 ${g.combo}연속 뿅망치 피버! 점수 x${multiplier(g.combo)}` : `⚡ ${g.combo}연속 처단! 점수 x${multiplier(g.combo)}`);
    }
  };

  const swingAt = (x: number, y: number, fromKey = false) => {
    const g = gameRef.current;
    if (g.state !== 'play' || !g.layout) return;

    g.swings += 1;
    g.hammer.x = x;
    g.hammer.y = y;
    g.hammer.swing = 0.001;
    g.hammer.show = 1;

    let found = -1;
    let bestDist = 1e9;
    const L = g.layout;

    for (let i = 0; i < 9; i++) {
      const m = g.holes[i];
      if (m.state !== 'up') continue;
      const c = L.cells[i];
      const pop = molePopProgress(m);
      const my = c.cy - L.rise * pop * 0.55;
      const dx = x - c.cx;
      const dy = y - my;
      const dist = Math.sqrt(dx * dx + dy * dy);
      const maxDist = L.rx * 1.35;
      if (dist < maxDist && dist < bestDist) {
        bestDist = dist;
        found = i;
      }
    }

    if (found >= 0) {
      hitMole(found);
      return;
    }

    // Miss
    if (g.combo >= 3) {
      addPop(g.width * 0.5, L.top + L.ch * 0.4, '콤보 중단!', '#ef4444', 22);
      sounds.playEscape();
    } else {
      sounds.playMiss();
    }
    g.combo = 0;
    setCombo(0);
    addParticles(x, y, 7, ['#ffffff', '#fbcfe8'], 130, 'dot');
    if (!fromKey) {
      addPop(x, y - 8, '빗나감!', 'rgba(255,255,255,.65)', 18);
    }
    triggerShake(2.5);
  };

  const triggerGameOver = () => {
    const g = gameRef.current;
    g.state = 'over';
    setGameState('over');
    sounds.playGameOver();

    const isRecord = g.score > bestScore;
    if (isRecord) {
      setBestScore(g.score);
      try {
        localStorage.setItem(`${BEST_STORAGE_KEY_PREFIX}${g.mode}`, String(g.score));
      } catch {
        // storage save safe
      }
    }
    setIsNewRecord(isRecord);

    const acc = g.swings > 0 ? Math.round((g.hits / g.swings) * 100) : 0;
    let grd = 'F';
    let gName = '';
    let comment = '';

    if (g.mode === 'cute') {
      if (g.score >= 3500) {
        grd = 'S';
        gName = '귀여움의 신 💖👑';
        comment = '전설의 뿅망치 달인! 모든 아기 오징어들이 반했습니다!';
      } else if (g.score >= 2200) {
        grd = 'A';
        gName = '오징어 쓰담쓰담 달인 ✨';
        comment = '화려한 뿅망치 솜씨! 오징어들이 춤을 춥니다!';
      } else if (g.score >= 1400) {
        grd = 'B';
        gName = '말랑말랑 젤리손 🪸';
        comment = '멋진 솜씨예요! 조금만 더 빠르면 S등급 달성!';
      } else if (g.score >= 700) {
        grd = 'C';
        gName = '견습 뿅망치 사냥꾼 🎯';
        comment = '다이아 오징어와 콤보를 집중 공략해보세요!';
      } else {
        grd = 'D';
        gName = '말랑 아기 오징어 친구 🦑';
        comment = '먹물 폭탄을 조심하고 다시 도전해보세요!';
      }
    } else {
      if (g.score >= 3500) {
        grd = 'S';
        gName = '심해 사냥의 신 ⚡👑';
        comment = '전설의 크라켄 지배자! 경이로운 타격 실력입니다!';
      } else if (g.score >= 2200) {
        grd = 'A';
        gName = '크라켄 처단자 🗡️';
        comment = '무자비한 심해 학살자! 바다의 평화를 지켰습니다!';
      } else if (g.score >= 1400) {
        grd = 'B';
        gName = '강철 철퇴왕 🔨';
        comment = '놀라운 괴물 토벌 실력! 심해를 정복하기 직전입니다!';
      } else if (g.score >= 700) {
        grd = 'C';
        gName = '심해 사냥꾼 🎯';
        comment = '제법이지만 아직 더 빠르고 정확해야 합니다!';
      } else {
        grd = 'D';
        gName = '초보 잠수부 🤿';
        comment = '괴물 오징어들의 속도를 따라잡지 못했습니다!';
      }
    }

    setFinalStats({
      accuracy: acc,
      maxCombo: g.maxCombo,
      grade: grd,
      gradeName: gName,
      comment,
    });
  };

  const startGame = () => {
    sounds.ensureAudio();
    sounds.playStart();

    const g = gameRef.current;
    g.state = 'play';
    g.score = 0;
    g.lives = 3;
    g.combo = 0;
    g.maxCombo = 0;
    g.swings = 0;
    g.hits = 0;
    g.timeLeft = GAME_TIME;
    g.elapsed = 0;
    g.spawnTimer = 0.35;
    g.shake = 0;
    g.hitstop = 0;
    g.flash = 0;
    g.particles = [];
    g.pops = [];
    g.lastTickSec = -1;

    const isCute = g.mode === 'cute';
    g.events = isCute
      ? [
          { t: 0.1, text: '💎 반짝 다이아 아기 오징어 출현!', done: false },
          { t: 15, text: '💖 귀여운 아기 오징어 댄스 파티!', done: false },
          { t: 30, text: '💣 삐진 먹물 조심! 💎 다이아 잡기!', done: false },
          { t: 45, text: '✨ 뿅망치 팡팡 피버 타임!', done: false },
        ]
      : [
          { t: 0.1, text: '💎 다이아 오징어 대출현! 처단하세요!', done: false },
          { t: 15, text: '⚡ 심해 괴물 오징어 대폭주!', done: false },
          { t: 30, text: '💣 먹물 폭탄 주의! 💎 다이아 사냥!', done: false },
          { t: 45, text: '🔥 광란의 심해 피버 타임!', done: false },
        ];

    for (let i = 0; i < 9; i++) {
      g.holes[i] = {
        state: 'idle',
        type: 'normal',
        time: 0,
        dur: 1,
        hitTime: 0,
        seed: Math.random() * 10,
      };
    }

    setScore(0);
    setLives(3);
    setTimeLeft(GAME_TIME);
    setCombo(0);
    setGameState('play');
    showBanner(isCute ? '💖 귀여운 아기 오징어 톡톡 시작! 🔨' : '💎 괴물 오징어 처단 개시! 🔨');
  };

  // Keyboard navigation & controls
  useEffect(() => {
    const keyMap: Record<string, number> = {
      Digit1: 0,
      Digit2: 1,
      Digit3: 2,
      Digit4: 3,
      Digit5: 4,
      Digit6: 5,
      Digit7: 6,
      Digit8: 7,
      Digit9: 8,
      Numpad7: 0,
      Numpad8: 1,
      Numpad9: 2,
      Numpad4: 3,
      Numpad5: 4,
      Numpad6: 5,
      Numpad1: 6,
      Numpad2: 7,
      Numpad3: 8,
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      sounds.ensureAudio();

      if (e.code === 'Space' || e.code === 'Enter') {
        e.preventDefault();
        if (gameRef.current.state !== 'play') {
          startGame();
        }
        return;
      }

      if (gameRef.current.state === 'play' && keyMap[e.code] !== undefined) {
        e.preventDefault();
        const idx = keyMap[e.code];
        const L = gameRef.current.layout;
        if (L && L.cells && L.cells[idx]) {
          const c = L.cells[idx];
          swingAt(c.cx, c.cy - L.rise * 0.35, true);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Preload all scary and cute mode image assets
  useEffect(() => {
    loadAllGameAssets((allAssets) => {
      gameRef.current.assets = allAssets;
    });
  }, []);

  // Canvas resize and layout setup
  const updateCanvasDimensions = useCallback(() => {
    if (!containerRef.current || !canvasRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const w = Math.max(240, Math.round(rect.width));
    const h = Math.max(300, Math.round(rect.height));
    const dpr = Math.min(3, window.devicePixelRatio || 1);

    const cv = canvasRef.current;
    cv.width = Math.round(w * dpr);
    cv.height = Math.round(h * dpr);

    const ctx = cv.getContext('2d');
    if (ctx) {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }

    const padX = w * 0.08;
    const top = h * 0.18;
    const bottom = h * 0.06;
    const gridW = w - padX * 2;
    const gridH = h - top - bottom;
    const cw = gridW / 3;
    const ch = gridH / 3;
    const cells = [];
    for (let i = 0; i < 9; i++) {
      const col = i % 3;
      const row = Math.floor(i / 3);
      cells.push({
        cx: padX + cw * (col + 0.5),
        cy: top + ch * (row + 0.72),
      });
    }

    gameRef.current.width = w;
    gameRef.current.height = h;
    gameRef.current.dpr = dpr;
    gameRef.current.layout = {
      cells,
      cw,
      ch,
      top,
      rx: Math.min(cw * 0.38, ch * 0.44),
      ry: Math.min(cw * 0.38, ch * 0.44) * 0.4,
      rise: ch * 0.65,
    };
  }, []);

  useEffect(() => {
    updateCanvasDimensions();
    const observer = new ResizeObserver(() => {
      updateCanvasDimensions();
    });
    if (containerRef.current) {
      observer.observe(containerRef.current);
    }
    return () => observer.disconnect();
  }, [updateCanvasDimensions]);

  // Main 60FPS Game Loop
  useEffect(() => {
    let animId: number;
    let lastT = performance.now();

    const pickSquidType = (elapsed: number): SquidType => {
      const r = Math.random();
      let diaP = 0.36;
      if (elapsed >= 40) diaP = 0.52;
      else if (elapsed >= 15) diaP = 0.42;

      const goldP = 0.22;
      const bombP = elapsed >= 15 ? 0.15 : 0.05;

      if (r < diaP) return 'diamond';
      if (r < diaP + goldP) return 'gold';
      if (r < diaP + goldP + bombP) return 'bomb';
      return 'normal';
    };

    const upDuration = (type: SquidType, progress: number, elapsed: number) => {
      if (type === 'diamond') return 0.72 - 0.18 * progress;
      if (type === 'gold') return 0.7 - 0.2 * progress;
      if (type === 'bomb') return 1.25 - 0.35 * progress;
      if (elapsed < 3) return 1.8;
      return 1.4 - 0.7 * progress;
    };

    const spawnMole = (g: typeof gameRef.current) => {
      const free: number[] = [];
      for (let i = 0; i < 9; i++) {
        if (g.holes[i].state === 'idle') free.push(i);
      }
      if (!free.length) return;
      const idx = free[(Math.random() * free.length) | 0];
      const m = g.holes[idx];
      m.type = pickSquidType(g.elapsed);
      m.state = 'up';
      m.time = 0;
      m.dur = upDuration(m.type, Math.min(1, g.elapsed / GAME_TIME), g.elapsed);
      m.hitTime = 0;
      m.seed = Math.random() * 10;
    };

    const loop = (now: number) => {
      let dt = Math.min(0.1, (now - lastT) / 1000);
      lastT = now;
      const g = gameRef.current;
      const cv = canvasRef.current;
      const ctx = cv?.getContext('2d');
      const isCute = g.mode === 'cute';
      const activeAssets = isCute ? g.assets.cute : g.assets.scary;

      // Update state
      g.bgTime += dt;
      if (g.shake > 0) g.shake = Math.max(0, g.shake - dt * 60);
      if (g.flash > 0) g.flash = Math.max(0, g.flash - dt * 2.6);
      if (g.hammer.show > 0) g.hammer.show = Math.max(0, g.hammer.show - dt * 1.5);
      if (g.hammer.swing > 0) {
        g.hammer.swing += dt;
        if (g.hammer.swing > 0.26) g.hammer.swing = 0;
      }

      // Background floating bubbles
      for (let b = 0; b < g.bgBubbles.length; b++) {
        const bb = g.bgBubbles[b];
        bb.y -= bb.speed * dt;
        bb.x += Math.sin(g.bgTime * 2 + bb.seed) * 0.45;
        if (bb.y < -20) {
          bb.y = g.height + 20;
          bb.x = Math.random() * g.width;
        }
      }

      // Particles update
      for (let i = g.particles.length - 1; i >= 0; i--) {
        const p = g.particles[i];
        p.life -= dt;
        if (p.life <= 0) {
          g.particles.splice(i, 1);
          continue;
        }
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        p.vy += (p.kind === 'smoke' ? -180 : 900) * dt;
        p.vx *= 0.99;
        p.rot += p.vr * dt;
      }

      // Pop text update
      for (let i = g.pops.length - 1; i >= 0; i--) {
        const q = g.pops[i];
        q.life -= dt;
        if (q.life <= 0) {
          g.pops.splice(i, 1);
          continue;
        }
        q.y += q.vy * dt;
        q.vy *= 0.94;
      }

      // Title animation loop
      if (g.state === 'title') {
        g.spawnTimer -= dt;
        if (g.spawnTimer <= 0) {
          g.spawnTimer = 0.45 + Math.random() * 0.4;
          let active = 0;
          for (let i = 0; i < 9; i++) if (g.holes[i].state === 'up') active++;
          if (active < 3) {
            const free: number[] = [];
            for (let i = 0; i < 9; i++) if (g.holes[i].state === 'idle') free.push(i);
            if (free.length) {
              const idx = free[(Math.random() * free.length) | 0];
              const mm = g.holes[idx];
              mm.state = 'up';
              mm.time = 0;
              mm.dur = 1.3 + Math.random() * 0.8;
              const randT = Math.random();
              mm.type = randT < 0.5 ? 'diamond' : randT < 0.75 ? 'gold' : 'normal';
              mm.seed = Math.random() * 10;
            }
          }
        }
        for (let i = 0; i < 9; i++) {
          const tm = g.holes[i];
          if (tm.state === 'up') {
            tm.time += dt;
            if (tm.time >= tm.dur) {
              tm.state = 'idle';
              tm.time = 0;
            }
          } else if (tm.state === 'hit') {
            tm.hitTime += dt;
            if (tm.hitTime > 0.3) {
              tm.state = 'idle';
              tm.time = 0;
            }
          }
        }
      } else if (g.state === 'play') {
        if (g.hitstop > 0) {
          g.hitstop -= dt;
          dt = dt * 0.05;
        }

        g.elapsed += dt;
        g.timeLeft -= dt;
        setTimeLeft(Math.max(0, g.timeLeft));

        const sec = Math.ceil(g.timeLeft);
        if (g.timeLeft <= 10 && sec !== g.lastTickSec && sec >= 0) {
          g.lastTickSec = sec;
          sounds.playTone(sec <= 3 ? 880 : 660, 0.08, 'sawtooth', 0.22);
        }

        for (let i = 0; i < g.events.length; i++) {
          if (!g.events[i].done && g.elapsed >= g.events[i].t) {
            g.events[i].done = true;
            showBanner(g.events[i].text);
            triggerFlash(0.25, isCute ? '244,114,182' : '239,68,68');
            sounds.playCombo(2);
          }
        }

        if (g.timeLeft <= 0) {
          triggerGameOver();
        } else {
          // Spawn logic
          g.spawnTimer -= dt;
          if (g.spawnTimer <= 0) {
            let active = 0;
            for (let i = 0; i < 9; i++) if (g.holes[i].state === 'up') active++;
            const maxActive = g.elapsed < 3 ? 1 : Math.min(5, 1 + Math.floor((g.elapsed / GAME_TIME) * 3) + (g.elapsed >= 25 ? 1 : 0));
            if (active < maxActive) {
              spawnMole(g);
            }
            const baseInterval = 1.0 - 0.65 * (g.elapsed / GAME_TIME);
            g.spawnTimer = Math.max(0.18, g.elapsed >= 25 ? baseInterval * 0.75 : baseInterval);
          }

          // Active moles tick
          for (let i = 0; i < 9; i++) {
            const m = g.holes[i];
            if (m.state === 'up') {
              m.time += dt;
              if (m.time >= m.dur) {
                m.state = 'idle';
                m.time = 0;
                if (m.type !== 'bomb') {
                  if (g.combo >= 3) {
                    const topY = g.layout ? g.layout.top + g.layout.ch * 0.4 : g.height * 0.4;
                    addPop(g.width * 0.5, topY, '도망쳤다!', '#ef4444', 20);
                    sounds.playEscape();
                  }
                  g.combo = 0;
                  setCombo(0);
                }
              }
            } else if (m.state === 'hit') {
              m.hitTime += dt;
              if (m.hitTime >= 0.32) {
                m.state = 'idle';
                m.hitTime = 0;
              }
            }
          }
        }
      }

      // RENDER CANVAS
      if (ctx && g.layout) {
        ctx.clearRect(0, 0, g.width, g.height);

        ctx.save();
        if (g.shake > 0) {
          const sx = (Math.random() * 2 - 1) * g.shake;
          const sy = (Math.random() * 2 - 1) * g.shake;
          ctx.translate(sx, sy);
        }

        // 1. Background Art Layer
        if (activeAssets.bg && activeAssets.bg.complete) {
          ctx.drawImage(activeAssets.bg, 0, 0, g.width, g.height);
          if (isCute) {
            // Subtle pastel overlay for cute mode
            const grad = ctx.createRadialGradient(g.width * 0.5, g.height * 0.5, g.width * 0.25, g.width * 0.5, g.height * 0.5, g.width * 0.75);
            grad.addColorStop(0, 'rgba(15, 23, 42, 0.25)');
            grad.addColorStop(1, 'rgba(15, 23, 42, 0.65)');
            ctx.fillStyle = grad;
            ctx.fillRect(0, 0, g.width, g.height);
          } else {
            // Dark abyss vignette for scary mode
            const grad = ctx.createRadialGradient(g.width * 0.5, g.height * 0.5, g.width * 0.2, g.width * 0.5, g.height * 0.5, g.width * 0.7);
            grad.addColorStop(0, 'rgba(2, 6, 23, 0.45)');
            grad.addColorStop(1, 'rgba(2, 4, 10, 0.85)');
            ctx.fillStyle = grad;
            ctx.fillRect(0, 0, g.width, g.height);
          }
        } else {
          const grad = ctx.createLinearGradient(0, 0, 0, g.height);
          grad.addColorStop(0, isCute ? '#0f172a' : '#020617');
          grad.addColorStop(1, '#000000');
          ctx.fillStyle = grad;
          ctx.fillRect(0, 0, g.width, g.height);
        }

        // Floating bubbles
        ctx.fillStyle = isCute ? 'rgba(244, 114, 182, 0.22)' : 'rgba(148, 163, 184, 0.16)';
        ctx.strokeStyle = isCute ? 'rgba(56, 189, 248, 0.35)' : 'rgba(56, 189, 248, 0.28)';
        ctx.lineWidth = 1;
        for (let b = 0; b < g.bgBubbles.length; b++) {
          const bb = g.bgBubbles[b];
          ctx.beginPath();
          ctx.arc(bb.x, bb.y, bb.r, 0, Math.PI * 2);
          ctx.fill();
          ctx.stroke();
        }

        // 2. Render Squid Holes
        const L = g.layout;
        for (let row = 0; row < 3; row++) {
          for (let col = 0; col < 3; col++) {
            const idx = row * 3 + col;
            const c = L.cells[idx];
            const rx = L.rx;
            const ry = L.ry;

            // Draw Cavern Back Hole
            ctx.save();
            ctx.translate(c.cx, c.cy);

            ctx.fillStyle = isCute ? 'rgba(15, 23, 42, 0.92)' : 'rgba(0, 0, 0, 0.95)';
            ctx.beginPath();
            ctx.ellipse(0, 4, rx * 1.14, ry * 1.14, 0, 0, Math.PI * 2);
            ctx.fill();

            // Hole interior depth
            ctx.fillStyle = isCute ? '#0c1022' : '#01040a';
            ctx.beginPath();
            ctx.ellipse(0, 0, rx, ry, 0, 0, Math.PI * 2);
            ctx.fill();

            ctx.restore();

            // Draw Squid Emerging
            const m = g.holes[idx];
            if (m.state !== 'idle') {
              const pop = molePopProgress(m);
              const rise = L.rise * pop;
              const my = c.cy - rise * 0.55;
              const scale = 0.88 + (c.cy / g.height) * 0.18;

              ctx.save();
              ctx.translate(c.cx, my);
              ctx.scale(scale, scale);

              const sw = L.rx * 0.9;
              const sh = L.rise * 0.82;

              // Identify creature image
              let targetImg: HTMLImageElement | null = null;
              if (m.type === 'normal') targetImg = activeAssets.normal;
              else if (m.type === 'diamond') targetImg = activeAssets.diamond;
              else if (m.type === 'bomb') targetImg = activeAssets.bomb;
              else if (m.type === 'gold') targetImg = activeAssets.normal;

              if (targetImg && targetImg.complete) {
                ctx.save();
                if (m.type === 'diamond') {
                  ctx.shadowColor = '#38bdf8';
                  ctx.shadowBlur = isCute ? 20 : 18;
                } else if (m.type === 'gold') {
                  ctx.shadowColor = '#facc15';
                  ctx.shadowBlur = 18;
                } else if (m.type === 'bomb') {
                  ctx.shadowColor = isCute ? '#ec4899' : '#ef4444';
                  ctx.shadowBlur = 14;
                } else {
                  ctx.shadowColor = isCute ? '#f472b6' : '#dc2626';
                  ctx.shadowBlur = 14;
                }

                // If gold squid, apply a golden warm shimmer
                if (m.type === 'gold') {
                  ctx.filter = 'sepia(100%) saturate(320%) brightness(125%) hue-rotate(15deg)';
                }

                const imgW = sw * 1.6;
                const imgH = sh * 1.5;
                ctx.drawImage(targetImg, -imgW * 0.5, -imgH * 0.8, imgW, imgH);
                ctx.restore();

                // Animated tentacles at bottom
                const wave = Math.sin(g.bgTime * (isCute ? 10 : 14) + m.seed) * 5;
                ctx.fillStyle = isCute
                  ? m.type === 'diamond'
                    ? '#0284c7'
                    : m.type === 'bomb'
                    ? '#312e81'
                    : m.type === 'gold'
                    ? '#ca8a04'
                    : '#ec4899'
                  : m.type === 'diamond'
                  ? '#0284c7'
                  : m.type === 'bomb'
                  ? '#0f172a'
                  : m.type === 'gold'
                  ? '#ca8a04'
                  : '#991b1b';

                for (let t = -3; t <= 3; t++) {
                  const tx = t * (sw * 0.18);
                  ctx.beginPath();
                  ctx.ellipse(tx + wave * 0.4, sh * 0.12, sw * 0.08, sh * 0.32, t * 0.1 + wave * 0.05, 0, Math.PI * 2);
                  ctx.fill();
                }

                // Cute sparkles or bomb fuse
                if (m.type === 'bomb') {
                  ctx.strokeStyle = '#f97316';
                  ctx.lineWidth = 3;
                  ctx.beginPath();
                  ctx.moveTo(0, -sh * 0.85);
                  ctx.quadraticCurveTo(10, -sh * 1.05, 6, -sh * 1.25);
                  ctx.stroke();

                  const fShift = Math.sin(g.bgTime * 24 + m.seed) * 3;
                  ctx.fillStyle = '#ef4444';
                  ctx.beginPath();
                  ctx.arc(6 + fShift, -sh * 1.28, 6.5, 0, Math.PI * 2);
                  ctx.fill();
                  ctx.fillStyle = '#fde047';
                  ctx.beginPath();
                  ctx.arc(6 + fShift, -sh * 1.28, 3, 0, Math.PI * 2);
                  ctx.fill();
                }

                // Hit reaction visual
                if (m.state === 'hit') {
                  ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
                  drawRoundedRect(ctx, -sw * 0.6, -sh * 0.7, sw * 1.2, sh * 1.1, 12);
                  ctx.font = '24px sans-serif';
                  ctx.textAlign = 'center';
                  ctx.fillText(isCute ? '💫' : '💥', 0, -sh * 0.85);
                }
              }

              ctx.restore();
            }

            // Draw Cavern Front Rim (covers lower part of rising squid)
            ctx.save();
            ctx.translate(c.cx, c.cy);

            const gFront = ctx.createLinearGradient(0, -ry * 0.2, 0, ry * 1.3);
            if (isCute) {
              gFront.addColorStop(0, '#334155');
              gFront.addColorStop(0.5, '#1e293b');
              gFront.addColorStop(1, '#0f172a');
            } else {
              gFront.addColorStop(0, '#1e293b');
              gFront.addColorStop(0.5, '#0f172a');
              gFront.addColorStop(1, '#020617');
            }

            ctx.fillStyle = gFront;
            ctx.beginPath();
            ctx.ellipse(0, ry * 0.35, rx * 1.1, ry * 0.78, 0, 0, Math.PI);
            ctx.fill();

            // Sand/Rock decorative dots
            ctx.fillStyle = isCute ? '#475569' : '#020617';
            ctx.beginPath();
            ctx.arc(-rx * 0.6, ry * 0.25, 3.5, 0, Math.PI * 2);
            ctx.fill();
            ctx.beginPath();
            ctx.arc(rx * 0.6, ry * 0.3, 4, 0, Math.PI * 2);
            ctx.fill();

            ctx.restore();
          }
        }

        // 3. Render Particles
        for (let i = 0; i < g.particles.length; i++) {
          const p = g.particles[i];
          const alpha = Math.max(0, p.life / p.max);
          ctx.save();
          ctx.globalAlpha = alpha;
          ctx.fillStyle = p.c;
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rot);

          if (p.kind === 'star') {
            ctx.beginPath();
            for (let k = 0; k < 5; k++) {
              ctx.lineTo(Math.cos(((18 + k * 72) * Math.PI) / 180) * p.r, -Math.sin(((18 + k * 72) * Math.PI) / 180) * p.r);
              ctx.lineTo(Math.cos(((54 + k * 72) * Math.PI) / 180) * (p.r * 0.5), -Math.sin(((54 + k * 72) * Math.PI) / 180) * (p.r * 0.5));
            }
            ctx.closePath();
            ctx.fill();
          } else {
            ctx.beginPath();
            ctx.arc(0, 0, p.r, 0, Math.PI * 2);
            ctx.fill();
          }
          ctx.restore();
        }

        // 4. Render Pop Floating Text
        ctx.save();
        for (let i = 0; i < g.pops.length; i++) {
          const p = g.pops[i];
          const alpha = Math.max(0, p.life / 0.95);
          ctx.globalAlpha = alpha;
          ctx.font = `900 ${p.size}px sans-serif`;
          ctx.textAlign = 'center';
          ctx.fillStyle = '#000000';
          ctx.fillText(p.text, p.x + 2, p.y + 2);
          ctx.fillStyle = p.c;
          ctx.fillText(p.text, p.x, p.y);
        }
        ctx.restore();

        // 5. Render Hammer Weapon (Cute Squeaky Toy Hammer vs Scary Titan Hammer)
        if (g.hammer.show > 0 && g.hammer.x > -100) {
          ctx.save();
          ctx.translate(g.hammer.x, g.hammer.y);
          ctx.scale(1.25, 1.25);
          ctx.rotate((g.hammer.swing > 0 ? -0.75 : -0.15) * Math.PI);

          if (activeAssets.hammer && activeAssets.hammer.complete) {
            ctx.shadowColor = isCute ? 'rgba(244, 114, 182, 0.8)' : 'rgba(239, 68, 68, 0.7)';
            ctx.shadowBlur = 16;
            const hw = 66;
            const hh = 66;
            ctx.drawImage(activeAssets.hammer, -hw * 0.5, -hh * 0.9, hw, hh);
          } else {
            // Procedural fallback
            ctx.fillStyle = '#1e293b';
            ctx.fillRect(-5, -45, 10, 45);
            ctx.fillStyle = isCute ? '#facc15' : '#475569';
            drawRoundedRect(ctx, -24, -64, 48, 26, 6);
          }
          ctx.restore();
        }

        // 6. Flash screen overlay
        if (g.flash > 0) {
          ctx.fillStyle = `rgba(${g.flashColor},${g.flash.toFixed(2)})`;
          ctx.fillRect(-20, -20, g.width + 40, g.height + 40);
        }

        ctx.restore();
      }

      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, []);

  const getStageCoordinates = (e: React.MouseEvent | React.TouchEvent) => {
    if (!containerRef.current) return { x: 0, y: 0 };
    const rect = containerRef.current.getBoundingClientRect();
    let clientX = 0;
    let clientY = 0;

    if ('touches' in e && e.touches.length > 0) {
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else if ('changedTouches' in e && e.changedTouches.length > 0) {
      clientX = e.changedTouches[0].clientX;
      clientY = e.changedTouches[0].clientY;
    } else if ('clientX' in e) {
      clientX = e.clientX;
      clientY = e.clientY;
    }

    const g = gameRef.current;
    return {
      x: (clientX - rect.left) * (g.width / rect.width),
      y: (clientY - rect.top) * (g.height / rect.height),
    };
  };

  const handlePointerDown = (e: React.MouseEvent | React.TouchEvent) => {
    sounds.ensureAudio();
    if (gameState !== 'play') return;
    const pos = getStageCoordinates(e);
    swingAt(pos.x, pos.y, false);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    const pos = getStageCoordinates(e);
    gameRef.current.hammer.x = pos.x;
    gameRef.current.hammer.y = pos.y;
    gameRef.current.hammer.show = 1;
  };

  const toggleSound = (e: React.MouseEvent) => {
    e.stopPropagation();
    const muted = sounds.toggleMute();
    setIsMuted(muted);
  };

  const switchMode = (newMode: GameMode) => {
    setMode(newMode);
    gameRef.current.mode = newMode;
    sounds.ensureAudio();
    sounds.playTone(newMode === 'cute' ? 880 : 330, 0.1, newMode === 'cute' ? 'sine' : 'sawtooth', 0.25);
  };

  const isCute = mode === 'cute';
  const currentAssets = ASSET_SOURCES[mode];

  return (
    <div className="flex h-screen w-full select-none items-center justify-center bg-radial from-slate-950 via-slate-900 to-black p-2 font-sans text-slate-100 overflow-hidden">
      {/* Main Container */}
      <div className="w-full max-w-[460px] h-full max-h-[720px] flex items-center justify-center">
        <div
          ref={containerRef}
          id="stage"
          onMouseDown={handlePointerDown}
          onTouchStart={handlePointerDown}
          onMouseMove={handleMouseMove}
          className={`relative w-full aspect-[9/11] max-h-[calc(100vh-20px)] rounded-2xl overflow-hidden bg-slate-950 shadow-2xl shadow-black ring-2 ${
            isCute ? 'ring-pink-500/40' : 'ring-red-500/30'
          } cursor-crosshair touch-manipulation`}
        >
          {/* Canvas Viewport */}
          <canvas ref={canvasRef} id="cv" className="block w-full h-full" />

          {/* Top HUD */}
          <div className="absolute left-0 right-0 top-0 p-3 pt-2.5 flex items-start justify-between gap-1.5 pointer-events-none z-10">
            <div
              className={`rounded-xl border ${
                isCute ? 'border-pink-500/40 bg-slate-900/90' : 'border-red-500/40 bg-slate-950/85'
              } px-3 py-1 shadow-lg backdrop-blur-md text-center`}
            >
              <span className={`block text-[10px] font-extrabold tracking-wider ${isCute ? 'text-pink-300' : 'text-red-400'}`}>점수</span>
              <span className="text-xl font-black text-white">{score}</span>
            </div>

            <div
              className={`rounded-xl border ${
                isCute ? 'border-pink-500/40 bg-slate-900/90' : 'border-red-500/40 bg-slate-950/85'
              } px-3 py-1 shadow-lg backdrop-blur-md text-center`}
            >
              <span className={`block text-[10px] font-extrabold tracking-wider ${isCute ? 'text-pink-300' : 'text-red-400'}`}>목숨</span>
              <span className="text-lg tracking-widest font-black">
                {Array.from({ length: 3 }).map((_, i) => (
                  <span key={i} className="inline-block transition-transform duration-200">
                    {i < lives ? (isCute ? '💖' : '❤️') : '🖤'}
                  </span>
                ))}
              </span>
            </div>

            <div
              className={`rounded-xl border ${
                isCute ? 'border-pink-500/40 bg-slate-900/90' : 'border-red-500/40 bg-slate-950/85'
              } px-3 py-1 shadow-lg backdrop-blur-md text-center`}
            >
              <span className={`block text-[10px] font-extrabold tracking-wider ${isCute ? 'text-pink-300' : 'text-red-400'}`}>시간</span>
              <span className={`text-xl font-black ${timeLeft <= 10 ? 'text-red-500 animate-pulse' : 'text-white'}`}>
                {Math.ceil(timeLeft)}
              </span>
            </div>
          </div>

          {/* Time Bar */}
          <div className="absolute left-3.5 right-3.5 top-[62px] h-2 rounded-full border border-slate-700 bg-slate-950/80 overflow-hidden pointer-events-none z-10">
            <div
              className={`h-full rounded-full transition-all duration-150 ${
                isCute
                  ? timeLeft <= 10
                    ? 'bg-gradient-to-r from-orange-400 to-rose-600'
                    : 'bg-gradient-to-r from-sky-400 via-pink-400 to-rose-500'
                  : timeLeft <= 10
                  ? 'bg-gradient-to-r from-orange-500 to-red-600'
                  : 'bg-gradient-to-r from-sky-400 to-red-500'
              }`}
              style={{ width: `${Math.max(0, Math.min(100, (timeLeft / GAME_TIME) * 100))}%` }}
            />
          </div>

          {/* Combo Indicator */}
          {combo >= 2 && (
            <div className="absolute left-0 right-0 top-20 text-center pointer-events-none z-10 transition-transform duration-200">
              <span
                className={`inline-block text-2xl font-black ${
                  isCute ? 'text-pink-300 drop-shadow-[0_2px_12px_rgba(244,114,182,0.85)]' : 'text-red-300 drop-shadow-[0_2px_12px_rgba(239,68,68,0.85)]'
                } animate-bounce`}
              >
                {isCute ? '💖' : '⚡'} {combo}콤보 x{multiplier(combo)}
              </span>
            </div>
          )}

          {/* Banner message */}
          {bannerText && (
            <div className="absolute left-0 right-0 top-[38%] text-center pointer-events-none z-20">
              <span
                className={`inline-block rounded-2xl border-2 ${
                  isCute ? 'border-pink-400 bg-gradient-to-b from-slate-900 to-indigo-950 text-pink-300' : 'border-red-500 bg-gradient-to-b from-slate-800 to-slate-950 text-red-400'
                } px-4 py-2 font-black text-sm md:text-base shadow-2xl animate-pulse`}
              >
                {bannerText}
              </span>
            </div>
          )}

          {/* Mute and In-game Mode Toggle Buttons */}
          <div className="absolute right-3 bottom-3 flex items-center gap-2 z-30">
            {gameState === 'play' && (
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  switchMode(mode === 'cute' ? 'scary' : 'cute');
                }}
                className={`px-3 py-1.5 rounded-xl border text-xs font-bold shadow-lg backdrop-blur-md active:scale-95 transition-transform cursor-pointer ${
                  isCute
                    ? 'border-pink-400 bg-pink-950/80 text-pink-200 hover:bg-pink-900'
                    : 'border-red-500 bg-red-950/80 text-red-200 hover:bg-red-900'
                }`}
              >
                {isCute ? '✨ 귀여운 모드' : '💀 무서운 모드'}
              </button>
            )}

            <button
              id="muteBtn"
              type="button"
              onClick={toggleSound}
              aria-label="소리 설정"
              className="w-10 h-10 rounded-xl border border-slate-700 bg-slate-900/90 text-white flex items-center justify-center shadow-lg hover:bg-slate-800 active:scale-90 transition-transform cursor-pointer"
            >
              {isMuted ? <VolumeX className="w-5 h-5 text-red-400" /> : <Volume2 className="w-5 h-5 text-emerald-400" />}
            </button>
          </div>

          {/* START TITLE SCREEN */}
          {gameState === 'title' && (
            <div className="absolute inset-0 z-40 flex flex-col items-center justify-center p-5 text-center bg-radial from-slate-900/96 via-slate-950/98 to-black/99 backdrop-blur-md">
              {/* Mode Selector Tabs */}
              <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-slate-900/90 border border-slate-700 mb-3 shadow-lg">
                <button
                  type="button"
                  onClick={() => switchMode('cute')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer ${
                    isCute
                      ? 'bg-gradient-to-r from-pink-500 to-rose-500 text-white shadow-md shadow-pink-500/40'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Smile className="w-3.5 h-3.5" /> 귀여운 모드 ✨
                </button>
                <button
                  type="button"
                  onClick={() => switchMode('scary')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer ${
                    !isCute
                      ? 'bg-gradient-to-r from-red-600 to-rose-700 text-white shadow-md shadow-red-600/40'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Skull className="w-3.5 h-3.5" /> 무서운 모드 💀
                </button>
              </div>

              {/* Title Asset Preview Row */}
              <div className="flex items-center gap-3 mb-1">
                <img
                  src={currentAssets.diamond}
                  alt="다이아"
                  className={`w-9 h-9 rounded-lg border ${
                    isCute ? 'border-sky-300 shadow-sky-400/30' : 'border-sky-500 shadow-sky-600/40'
                  } shadow-md object-cover`}
                  referrerPolicy="no-referrer"
                />
                <img
                  src={currentAssets.normal}
                  alt="오징어"
                  className={`w-11 h-11 rounded-lg border ${
                    isCute ? 'border-pink-400 shadow-pink-500/50' : 'border-red-500 shadow-red-600/50'
                  } shadow-lg object-cover animate-pulse`}
                  referrerPolicy="no-referrer"
                />
                <img
                  src={currentAssets.hammer}
                  alt="망치"
                  className={`w-9 h-9 rounded-lg border ${
                    isCute ? 'border-amber-300 shadow-amber-400/30' : 'border-slate-500 shadow-slate-600/40'
                  } shadow-md object-cover`}
                  referrerPolicy="no-referrer"
                />
              </div>

              <h1
                className={`text-2xl sm:text-3xl font-black tracking-tight mb-1 ${
                  isCute
                    ? 'text-pink-300 drop-shadow-[0_4px_16px_rgba(244,114,182,0.8)]'
                    : 'text-red-400 drop-shadow-[0_4px_16px_rgba(239,68,68,0.7)]'
                }`}
              >
                {isCute ? '말랑말랑 오징어 톡톡 🦑🔨' : '심해 괴물 오징어 잡기 🦑🔨'}
              </h1>

              <p className="text-xs text-slate-300 leading-relaxed mb-3 max-w-[320px]">
                {isCute ? (
                  <>
                    <b>✨ 말랑말랑 귀여운 아기 오징어 등장! ✨</b>
                    <br />
                    알록달록 뿅망치로 아기 오징어를 톡톡 두드려주세요!
                  </>
                ) : (
                  <>
                    <b>⚠️ 흉측한 심해 괴물 오징어 대출현! ⚠️</b>
                    <br />
                    어두운 암흑 바닷속에서 솟구치는 괴물을 철퇴로 처단하세요!
                  </>
                )}
              </p>

              {/* Character Cards with Real Assets */}
              <div className="grid grid-cols-2 gap-2 w-full max-w-[340px] mb-4 text-left">
                <div className="flex items-center gap-2 rounded-xl border border-sky-500/30 bg-slate-900/80 p-2 text-[11px]">
                  <img
                    src={currentAssets.diamond}
                    alt="다이아"
                    className="w-8 h-8 rounded-md border border-sky-400 object-cover shrink-0"
                    referrerPolicy="no-referrer"
                  />
                  <div>
                    <div className="font-bold text-sky-400 flex items-center gap-1">
                      <Gem className="w-3 h-3" /> 다이아 오징어
                    </div>
                    <div className="text-white font-extrabold">+150점</div>
                  </div>
                </div>

                <div className="flex items-center gap-2 rounded-xl border border-amber-500/30 bg-slate-900/80 p-2 text-[11px]">
                  <div className="w-8 h-8 rounded-md border border-amber-400 bg-amber-950 flex items-center justify-center font-bold text-amber-300 text-sm shrink-0">
                    🥇
                  </div>
                  <div>
                    <div className="font-bold text-amber-400 flex items-center gap-1">
                      <Sparkles className="w-3 h-3" /> 황금 오징어
                    </div>
                    <div className="text-white font-extrabold">+50점</div>
                  </div>
                </div>

                <div className="flex items-center gap-2 rounded-xl border border-pink-500/30 bg-slate-900/80 p-2 text-[11px]">
                  <img
                    src={currentAssets.normal}
                    alt="오징어"
                    className={`w-8 h-8 rounded-md border ${isCute ? 'border-pink-400' : 'border-red-500'} object-cover shrink-0`}
                    referrerPolicy="no-referrer"
                  />
                  <div>
                    <div className={`font-bold ${isCute ? 'text-pink-300' : 'text-red-400'} flex items-center gap-1`}>
                      {isCute ? <Heart className="w-3 h-3" /> : <Zap className="w-3 h-3" />}{' '}
                      {isCute ? '말랑 오징어' : '괴물 오징어'}
                    </div>
                    <div className="text-white font-extrabold">+10점</div>
                  </div>
                </div>

                <div className="flex items-center gap-2 rounded-xl border border-orange-500/30 bg-slate-900/80 p-2 text-[11px]">
                  <img
                    src={currentAssets.bomb}
                    alt="폭탄"
                    className="w-8 h-8 rounded-md border border-orange-500 object-cover shrink-0"
                    referrerPolicy="no-referrer"
                  />
                  <div>
                    <div className="font-bold text-orange-400 flex items-center gap-1">
                      <ShieldAlert className="w-3 h-3" /> 먹물 오징어
                    </div>
                    <div className="text-rose-400 font-extrabold">-20점 (목숨 차감)</div>
                  </div>
                </div>
              </div>

              {/* Start Button */}
              <button
                id="startBtn"
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  startGame();
                }}
                className={`w-full max-w-[260px] py-3 rounded-2xl ${
                  isCute
                    ? 'bg-gradient-to-b from-pink-500 to-rose-600 border-2 border-pink-300/80 shadow-pink-900/50'
                    : 'bg-gradient-to-b from-red-600 to-red-800 border-2 border-red-400/80 shadow-red-900/50'
                } text-white font-black text-lg shadow-xl hover:brightness-110 active:scale-95 transition-transform flex items-center justify-center gap-2 cursor-pointer`}
              >
                <Play className="w-5 h-5 fill-current" /> {isCute ? '뿅망치 놀이 시작 🔨' : '괴물 퇴치 시작 🔨'}
              </button>

              <div className={`mt-3 text-xs font-bold ${isCute ? 'text-pink-300' : 'text-red-300'}`}>
                최고 기록: {bestScore}점 ({isCute ? '귀여운 모드' : '무서운 모드'})
              </div>
              <div className="mt-1 text-[11px] text-slate-400">
                마우스·터치로 타격 / 키보드 <span className="px-1.5 py-0.5 rounded bg-slate-800 text-pink-300 font-bold">1</span>~
                <span className="px-1.5 py-0.5 rounded bg-slate-800 text-pink-300 font-bold">9</span> 또는 넘패드
              </div>
            </div>
          )}

          {/* GAME OVER SCREEN */}
          {gameState === 'over' && (
            <div className="absolute inset-0 z-40 flex flex-col items-center justify-center p-5 text-center bg-radial from-slate-900/96 via-slate-950/98 to-black/99 backdrop-blur-md">
              <div
                className="text-5xl font-black mb-1 drop-shadow-[0_4px_16px_currentColor]"
                style={{
                  color:
                    finalStats.grade === 'S'
                      ? '#38bdf8'
                      : finalStats.grade === 'A'
                      ? isCute
                        ? '#f472b6'
                        : '#f87171'
                      : finalStats.grade === 'B'
                      ? '#fde047'
                      : '#94a3b8',
                }}
              >
                {finalStats.grade}
              </div>

              <div className="text-base font-bold text-slate-200 mb-1">{finalStats.gradeName}</div>

              <div
                className={`text-4xl font-black my-1 ${
                  isCute
                    ? 'text-pink-300 drop-shadow-[0_3px_0_#9d174d]'
                    : 'text-red-400 drop-shadow-[0_3px_0_#991b1b]'
                }`}
              >
                {score}점
              </div>

              <div className="text-xs text-slate-300 mb-2">
                명중률 {finalStats.accuracy}% · 최고 {finalStats.maxCombo}콤보 ({isCute ? '귀여운 모드' : '무서운 모드'})
              </div>

              <div className="text-sm font-extrabold text-amber-300 mb-4 max-w-[280px]">
                {isNewRecord ? '🎉 최고 기록 경신!' : finalStats.comment}
              </div>

              <div className="flex flex-col sm:flex-row items-center gap-2 w-full max-w-[280px]">
                <button
                  id="againBtn"
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    startGame();
                  }}
                  className={`w-full py-2.5 rounded-2xl ${
                    isCute
                      ? 'bg-gradient-to-b from-pink-500 to-rose-600 border-2 border-pink-300'
                      : 'bg-gradient-to-b from-red-600 to-red-800 border-2 border-red-400'
                  } text-white font-black text-base shadow-xl hover:brightness-110 active:scale-95 transition-transform flex items-center justify-center gap-1.5 cursor-pointer`}
                >
                  <RotateCcw className="w-4 h-4" /> 다시 하기 🔨
                </button>

                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setGameState('title');
                  }}
                  className="w-full py-2.5 rounded-2xl bg-slate-800 border border-slate-600 text-slate-200 font-bold text-sm hover:bg-slate-700 active:scale-95 transition-transform cursor-pointer"
                >
                  모드 변경하기
                </button>
              </div>

              <p className="mt-3 text-[11px] text-slate-400">스페이스바 또는 화면을 탭하면 바로 다시 시작</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
