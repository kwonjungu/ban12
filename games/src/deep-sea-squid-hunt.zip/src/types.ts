export type GameMode = 'scary' | 'cute';

export type SquidType = 'normal' | 'diamond' | 'gold' | 'bomb';

export type HoleState = 'idle' | 'up' | 'hit';

export interface Hole {
  state: HoleState;
  type: SquidType;
  time: number;
  dur: number;
  hitTime: number;
  seed: number;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  r: number;
  c: string;
  kind: 'dot' | 'star' | 'smoke' | 'spark' | 'ink';
  rot: number;
  vr: number;
}

export interface PopText {
  id: number;
  x: number;
  y: number;
  text: string;
  c: string;
  life: number;
  size: number;
  vy: number;
}

export interface CellCoord {
  cx: number;
  cy: number;
}

export interface GridLayout {
  cells: CellCoord[];
  cw: number;
  ch: number;
  top: number;
  rx: number;
  ry: number;
  rise: number;
}

export interface GameStats {
  score: number;
  best: number;
  lives: number;
  combo: number;
  maxCombo: number;
  swings: number;
  hits: number;
  timeLeft: number;
}
