export enum GameState {
  TITLE = 'TITLE',
  READY = 'READY',
  PLAY = 'PLAY',
  DYING = 'DYING',
  OVER = 'OVER',
  PAUSE = 'PAUSE',
}

export interface BirdEntity {
  x: number;
  y: number;
  vy: number;
  rot: number;
  pop: number;
  stretch: number;
  wing: number;
  alive: boolean;
  inv: number; // Invincibility timer
}

export interface PipeEntity {
  x: number;
  baseY: number;
  y: number;
  gap: number;
  amp: number;
  phase: number;
  scored: boolean;
  w: number;
}

export interface StarEntity {
  pipe: PipeEntity;
  off: number;
  x: number;
  y: number;
  got: boolean;
  spin: number;
  edge: boolean;
}

export interface ParticleEntity {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  life: number;
  max: number;
  c: string;
  g: number;
}

export interface FloatTextEntity {
  x: number;
  y: number;
  t: string;
  c: string;
  s: number;
  life: number;
  max: number;
  vy: number;
}

export interface CloudEntity {
  x: number;
  y: number;
  s: number;
  sp: number;
}

export interface NightStarEntity {
  x: number;
  y: number;
  r: number;
  tw: number;
}

export interface ThemeColors {
  skyTop: [number, number, number];
  skyBot: [number, number, number];
  hill: [number, number, number];
  hill2: [number, number, number];
  pipe: [number, number, number];
  pipeDark: [number, number, number];
  ground: [number, number, number];
  groundDark: [number, number, number];
  night: number;
}

export interface GameEvent {
  t: number;
  p: number;
  msg: string;
  act: () => void;
}

export interface MedalInfo {
  icon: string;
  name: string;
}
