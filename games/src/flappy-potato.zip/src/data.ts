import { ThemeColors, MedalInfo } from './types';

export const THEMES: ThemeColors[] = [
  // Theme 0: Cute Pastel Day
  {
    skyTop: [216, 243, 220],
    skyBot: [255, 229, 236],
    hill: [181, 226, 203],
    hill2: [149, 213, 178],
    pipe: [184, 224, 210],
    pipeDark: [120, 185, 165],
    ground: [255, 241, 230],
    groundDark: [254, 217, 183],
    night: 0,
  },
  // Theme 1: Peach Sunset
  {
    skyTop: [255, 202, 212],
    skyBot: [255, 229, 217],
    hill: [242, 166, 178],
    hill2: [224, 130, 150],
    pipe: [255, 181, 167],
    pipeDark: [225, 130, 120],
    ground: [254, 217, 183],
    groundDark: [240, 180, 145],
    night: 0,
  },
  // Theme 2: Dreamy Lavender Night
  {
    skyTop: [112, 108, 168],
    skyBot: [175, 163, 212],
    hill: [90, 85, 140],
    hill2: [70, 65, 115],
    pipe: [200, 180, 235],
    pipeDark: [150, 125, 190],
    ground: [140, 130, 180],
    groundDark: [105, 95, 145],
    night: 1,
  },
];

export function getMedal(score: number): MedalInfo {
  if (score >= 40) return { icon: '👑', name: '전설의 신선한 감자왕!' };
  if (score >= 25) return { icon: '🍟', name: '노릇노릇 명품 감자튀김!' };
  if (score >= 12) return { icon: '🧈', name: '고소한 버터구이 감자!' };
  if (score >= 5) return { icon: '🥔', name: '동글동글 찐감자!' };
  return { icon: '🌱', name: '아기 감자! 조금만 더 힘내보자!' };
}

export const BASE_HEIGHT = 600;
export const BASE_WIDTH = 430;
export const GROUND_HEIGHT = 84;
export const PIPE_WIDTH = 62;
export const BIRD_RADIUS = 18;
