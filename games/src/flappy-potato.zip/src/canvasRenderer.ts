import {
  BirdEntity,
  PipeEntity,
  StarEntity,
  ParticleEntity,
  FloatTextEntity,
  CloudEntity,
  NightStarEntity,
  ThemeColors,
  GameState,
} from './types';

// Safe rounded rectangle drawing to avoid TypeError in browsers without ctx.roundRect
export function drawRoundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  radius: number | number[]
): void {
  const r = typeof radius === 'number' ? radius : radius[0] || 0;
  if (typeof ctx.roundRect === 'function') {
    try {
      ctx.roundRect(x, y, width, height, r);
      return;
    } catch {
      // Fallback if roundRect fails with invalid params
    }
  }
  const rad = Math.min(r, Math.abs(width) / 2, Math.abs(height) / 2);
  ctx.moveTo(x + rad, y);
  ctx.lineTo(x + width - rad, y);
  ctx.arcTo(x + width, y, x + width, y + height, rad);
  ctx.lineTo(x + width, y + height - rad);
  ctx.arcTo(x + width, y + height, x, y + height, rad);
  ctx.lineTo(x + rad, y + height);
  ctx.arcTo(x, y + height, x, y, rad);
  ctx.lineTo(x, y + rad);
  ctx.arcTo(x, y, x + width, y, rad);
}

export function lerpColor(c1: [number, number, number], c2: [number, number, number], t: number): [number, number, number] {
  return [
    Math.round(c1[0] + (c2[0] - c1[0]) * t),
    Math.round(c1[1] + (c2[1] - c1[1]) * t),
    Math.round(c1[2] + (c2[2] - c1[2]) * t),
  ];
}

export function rgb(c: [number, number, number]): string {
  return `rgb(${c[0]},${c[1]},${c[2]})`;
}

export function drawBackground(
  ctx: CanvasRenderingContext2D,
  BW: number,
  BH: number,
  groundH: number,
  tf: ThemeColors,
  tt: ThemeColors,
  themeMix: number,
  nightStars: NightStarEntity[],
  clouds: CloudEntity[],
  groundX: number,
  nowSec: number
): void {
  const sTop = lerpColor(tf.skyTop, tt.skyTop, themeMix);
  const sBot = lerpColor(tf.skyBot, tt.skyBot, themeMix);
  const h1 = lerpColor(tf.hill, tt.hill, themeMix);
  const h2 = lerpColor(tf.hill2, tt.hill2, themeMix);

  const grad = ctx.createLinearGradient(0, -20, 0, BH - groundH);
  grad.addColorStop(0, rgb(sTop));
  grad.addColorStop(1, rgb(sBot));
  ctx.fillStyle = grad;
  ctx.fillRect(-50, -50, BW + 100, BH + 100);

  const nightVal = tf.night + (tt.night - tf.night) * themeMix;
  if (nightVal > 0.01) {
    ctx.save();
    ctx.fillStyle = '#ffffff';
    for (let j = 0; j < nightStars.length; j++) {
      const ns = nightStars[j];
      const alpha = (0.3 + 0.7 * Math.sin(nowSec * 3 + ns.tw)) * nightVal;
      ctx.globalAlpha = Math.max(0, Math.min(1, alpha));
      ctx.beginPath();
      ctx.arc(ns.x * BW, ns.y * BH, ns.r, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  }

  // Draw floating cute clouds
  for (let i = 0; i < clouds.length; i++) {
    const c = clouds[i];
    ctx.save();
    ctx.translate(c.x, c.y);
    ctx.scale(c.s, c.s);
    ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
    ctx.beginPath();
    ctx.arc(0, 0, 22, 0, Math.PI * 2);
    ctx.arc(20, -10, 18, 0, Math.PI * 2);
    ctx.arc(40, 0, 22, 0, Math.PI * 2);
    ctx.arc(20, 8, 16, 0, Math.PI * 2);
    ctx.fill();

    // Cute cloud smiley eyes
    ctx.fillStyle = '#8d7b68';
    ctx.beginPath();
    ctx.arc(15, -2, 2, 0, Math.PI * 2);
    ctx.arc(25, -2, 2, 0, Math.PI * 2);
    ctx.fill();

    // Rosy cloud cheeks
    ctx.fillStyle = 'rgba(255, 180, 190, 0.7)';
    ctx.beginPath();
    ctx.arc(11, 2, 3, 0, Math.PI * 2);
    ctx.arc(29, 2, 3, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  }

  // Rolling hills in background
  const groundY = BH - groundH;
  ctx.fillStyle = rgb(h2);
  ctx.beginPath();
  ctx.moveTo(0, groundY);
  for (let x = 0; x <= BW + 20; x += 20) {
    const hy = groundY - 45 - Math.sin((x + groundX * 0.15) * 0.012) * 22;
    ctx.lineTo(x, hy);
  }
  ctx.lineTo(BW, BH);
  ctx.lineTo(0, BH);
  ctx.fill();

  ctx.fillStyle = rgb(h1);
  ctx.beginPath();
  ctx.moveTo(0, groundY);
  for (let x2 = 0; x2 <= BW + 20; x2 += 20) {
    const hy2 = groundY - 25 - Math.sin((x2 + groundX * 0.35) * 0.02) * 16;
    ctx.lineTo(x2, hy2);
  }
  ctx.lineTo(BW, BH);
  ctx.lineTo(0, BH);
  ctx.fill();
}

export function drawPipes(
  ctx: CanvasRenderingContext2D,
  pipes: PipeEntity[],
  BH: number,
  groundH: number,
  tf: ThemeColors,
  tt: ThemeColors,
  themeMix: number
): void {
  const cMain = rgb(lerpColor(tf.pipe, tt.pipe, themeMix));
  const cDark = rgb(lerpColor(tf.pipeDark, tt.pipeDark, themeMix));
  const groundY = BH - groundH;

  for (let i = 0; i < pipes.length; i++) {
    const p = pipes[i];
    const topH = p.y - p.gap / 2;
    const botY = p.y + p.gap / 2;
    const botH = groundY - botY;
    const capH = 26;

    ctx.save();

    const gTop = ctx.createLinearGradient(p.x, 0, p.x + p.w, 0);
    gTop.addColorStop(0, cDark);
    gTop.addColorStop(0.3, cMain);
    gTop.addColorStop(0.7, '#ffffff');
    gTop.addColorStop(0.85, cMain);
    gTop.addColorStop(1, cDark);

    ctx.fillStyle = gTop;

    // Top pipe shaft
    ctx.fillRect(p.x, 0, p.w, Math.max(0, topH - capH));

    // Top pipe cap
    ctx.beginPath();
    drawRoundRect(ctx, p.x - 5, topH - capH, p.w + 10, capH, 8);
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.7)';
    ctx.lineWidth = 2.5;
    ctx.stroke();

    // Bottom pipe shaft
    ctx.fillRect(p.x, botY + capH, p.w, Math.max(0, botH - capH));

    // Bottom pipe cap
    ctx.beginPath();
    drawRoundRect(ctx, p.x - 5, botY, p.w + 10, capH, 8);
    ctx.fill();
    ctx.stroke();

    ctx.restore();
  }
}

export function drawStars(
  ctx: CanvasRenderingContext2D,
  stars: StarEntity[],
  butterImg: HTMLImageElement | null
): void {
  for (let i = 0; i < stars.length; i++) {
    const st = stars[i];
    if (st.got) continue;

    ctx.save();
    ctx.translate(st.x, st.y);

    if (butterImg && butterImg.complete && butterImg.naturalWidth > 0) {
      // Draw glowing butter shield item
      const size = 38;
      ctx.save();
      // Outer aura glow
      const aura = 24 + Math.sin(st.spin * 2) * 3;
      const grad = ctx.createRadialGradient(0, 0, 4, 0, 0, aura);
      grad.addColorStop(0, 'rgba(255, 235, 120, 0.8)');
      grad.addColorStop(0.6, 'rgba(255, 200, 50, 0.4)');
      grad.addColorStop(1, 'rgba(255, 200, 50, 0)');
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(0, 0, aura, 0, Math.PI * 2);
      ctx.fill();

      // Circular clipped butter badge
      ctx.beginPath();
      ctx.arc(0, 0, size / 2, 0, Math.PI * 2);
      ctx.clip();
      ctx.drawImage(butterImg, -size / 2, -size / 2, size, size);
      ctx.restore();

      // Golden outer ring
      ctx.strokeStyle = '#ffe27a';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.arc(0, 0, size / 2, 0, Math.PI * 2);
      ctx.stroke();
    } else {
      // Vector star fallback
      ctx.rotate(st.spin);
      ctx.fillStyle = '#ffe27a';
      ctx.strokeStyle = '#f39c12';
      ctx.lineWidth = 2;
      ctx.beginPath();
      for (let k = 0; k < 5; k++) {
        ctx.lineTo(
          Math.cos(((18 + k * 72) * Math.PI) / 180) * 14,
          -Math.sin(((18 + k * 72) * Math.PI) / 180) * 14
        );
        ctx.lineTo(
          Math.cos(((54 + k * 72) * Math.PI) / 180) * 6,
          -Math.sin(((54 + k * 72) * Math.PI) / 180) * 6
        );
      }
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
    }

    ctx.restore();
  }
}

export function drawGround(
  ctx: CanvasRenderingContext2D,
  BW: number,
  BH: number,
  groundH: number,
  tf: ThemeColors,
  tt: ThemeColors,
  themeMix: number,
  groundX: number
): void {
  const gMain = rgb(lerpColor(tf.ground, tt.ground, themeMix));
  const gDark = rgb(lerpColor(tf.groundDark, tt.groundDark, themeMix));
  const groundY = BH - groundH;

  ctx.fillStyle = gMain;
  ctx.fillRect(0, groundY, BW, groundH);

  ctx.fillStyle = gDark;
  ctx.fillRect(0, groundY, BW, 12);

  ctx.fillStyle = 'rgba(255, 255, 255, 0.22)';
  const stripW = 24;
  const offset = groundX % stripW;
  for (let x = offset - stripW; x < BW + stripW; x += stripW) {
    ctx.beginPath();
    ctx.moveTo(x, groundY + 12);
    ctx.lineTo(x + 12, groundY + 12);
    ctx.lineTo(x + 2, groundY + groundH);
    ctx.lineTo(x - 10, groundY + groundH);
    ctx.closePath();
    ctx.fill();
  }
}

export function drawBird(
  ctx: CanvasRenderingContext2D,
  bird: BirdEntity,
  birdRadius: number,
  shields: number,
  nowSec: number,
  potatoImg: HTMLImageElement | null
): void {
  ctx.save();
  ctx.translate(bird.x, bird.y);
  ctx.rotate(bird.rot);

  const scaleX = bird.pop / bird.stretch;
  const scaleY = bird.pop * bird.stretch;
  ctx.scale(scaleX, scaleY);

  if (bird.inv > 0 && Math.floor(nowSec * 25) % 2 === 0) {
    ctx.globalAlpha = 0.45;
  }

  // Butter Shield Aura
  if (shields > 0 && bird.alive) {
    ctx.save();
    const shieldGlow = 28 + Math.sin(nowSec * 8) * 3;
    const sGrad = ctx.createRadialGradient(0, 0, 10, 0, 0, shieldGlow);
    sGrad.addColorStop(0, 'rgba(255, 243, 176, 0.25)');
    sGrad.addColorStop(0.75, 'rgba(255, 220, 100, 0.65)');
    sGrad.addColorStop(1, 'rgba(255, 235, 150, 0.95)');
    ctx.fillStyle = sGrad;
    ctx.strokeStyle = '#fff3b0';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(0, 0, shieldGlow, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.restore();
  }

  const renderW = (birdRadius + 5) * 2;
  const renderH = (birdRadius + 3) * 2;

  if (potatoImg && potatoImg.complete && potatoImg.naturalWidth > 0) {
    // Render the generated cute potato sprite
    ctx.save();
    // Rounded oval crop for seamless potato outline
    ctx.beginPath();
    ctx.ellipse(0, 1, birdRadius + 4, birdRadius + 1, 0.1, 0, Math.PI * 2);
    ctx.clip();
    ctx.drawImage(potatoImg, -renderW / 2, -renderH / 2, renderW, renderH);
    ctx.restore();

    // Outline
    ctx.strokeStyle = '#824c23';
    ctx.lineWidth = 2.2;
    ctx.beginPath();
    ctx.ellipse(0, 1, birdRadius + 4, birdRadius + 1, 0.1, 0, Math.PI * 2);
    ctx.stroke();

    // Cute animated fluttering little wing on top
    ctx.save();
    ctx.translate(-8, 2);
    const handAngle = bird.wing > 0 ? -0.85 : Math.sin(nowSec * 12) * 0.25;
    ctx.rotate(handAngle);
    ctx.fillStyle = '#fff4cf';
    ctx.strokeStyle = '#d4a373';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    drawRoundRect(ctx, -7, -3, 10, 7, 3);
    ctx.fill();
    ctx.stroke();
    ctx.restore();

    // If dead, draw cute spiral/cross eyes overlay
    if (!bird.alive) {
      ctx.lineWidth = 2.8;
      ctx.strokeStyle = '#4a2c11';
      ctx.beginPath();
      ctx.moveTo(3, -5); ctx.lineTo(11, 1);
      ctx.moveTo(11, -5); ctx.lineTo(3, 1);
      ctx.stroke();
    }
  } else {
    // Procedural cute potato fallback
    const bodyGrad = ctx.createRadialGradient(-3, -4, 3, 0, 0, birdRadius + 3);
    bodyGrad.addColorStop(0, '#fceade');
    bodyGrad.addColorStop(0.45, '#e0a96d');
    bodyGrad.addColorStop(0.85, '#c3834c');
    bodyGrad.addColorStop(1, '#9e6030');

    ctx.fillStyle = bodyGrad;
    ctx.beginPath();
    ctx.ellipse(0, 1, birdRadius + 3, birdRadius, 0.1, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#824c23';
    ctx.lineWidth = 2;
    ctx.stroke();

    // Potato speckles
    ctx.fillStyle = 'rgba(130, 76, 35, 0.35)';
    ctx.beginPath();
    ctx.arc(-8, -6, 1.5, 0, Math.PI * 2);
    ctx.arc(-11, 4, 1.2, 0, Math.PI * 2);
    ctx.arc(3, 9, 1.5, 0, Math.PI * 2);
    ctx.arc(-2, -10, 1.3, 0, Math.PI * 2);
    ctx.fill();

    // Sprout leaf on top
    ctx.save();
    const leafWiggle = Math.sin(nowSec * 10) * 0.15;
    ctx.translate(0, -birdRadius + 1);
    ctx.rotate(leafWiggle);
    ctx.strokeStyle = '#4d8b31';
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.moveTo(0, 2);
    ctx.quadraticCurveTo(-2, -6, -4, -11);
    ctx.stroke();

    ctx.fillStyle = '#70c1b3';
    ctx.beginPath();
    ctx.ellipse(-7, -12, 5, 3, -0.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#247ba0';
    ctx.beginPath();
    ctx.ellipse(-1, -13, 5, 3, 0.6, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // Blushing cheeks
    ctx.fillStyle = 'rgba(255, 130, 150, 0.65)';
    ctx.beginPath();
    ctx.arc(2, 5, 4.5, 0, Math.PI * 2);
    ctx.arc(13, 3, 4.5, 0, Math.PI * 2);
    ctx.fill();

    if (!bird.alive) {
      ctx.lineWidth = 2.5;
      ctx.strokeStyle = '#4a2c11';
      ctx.beginPath();
      ctx.moveTo(4, -5); ctx.lineTo(10, 1);
      ctx.moveTo(10, -5); ctx.lineTo(4, 1);
      ctx.stroke();
    } else {
      ctx.fillStyle = '#3a2312';
      ctx.beginPath();
      ctx.arc(7, -3, 3.8, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(8.5, -4.5, 1.5, 0, Math.PI * 2);
      ctx.arc(6.2, -1.8, 0.8, 0, Math.PI * 2);
      ctx.fill();

      ctx.strokeStyle = '#4a2c11';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(8, 3, 3.5, 0.1, Math.PI - 0.2);
      ctx.stroke();
    }

    // Wing flap
    ctx.save();
    ctx.translate(-6, 3);
    const handAngle = bird.wing > 0 ? -0.9 : Math.sin(nowSec * 10) * 0.3;
    ctx.rotate(handAngle);
    ctx.fillStyle = '#ffe066';
    ctx.strokeStyle = '#d4a373';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    drawRoundRect(ctx, -8, -2, 10, 7, 3);
    ctx.fill();
    ctx.stroke();
    ctx.restore();
  }

  ctx.restore();
}

export function drawEffects(
  ctx: CanvasRenderingContext2D,
  parts: ParticleEntity[],
  floats: FloatTextEntity[],
  flashWhite: number,
  BW: number,
  BH: number
): void {
  for (let i = 0; i < parts.length; i++) {
    const p = parts[i];
    const alpha = Math.max(0, p.life / p.max);
    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.fillStyle = p.c;
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  for (let j = 0; j < floats.length; j++) {
    const f = floats[j];
    const fAlpha = Math.max(0, f.life / f.max);
    ctx.save();
    ctx.globalAlpha = fAlpha;
    ctx.font = `${f.s}px 'Jua', 'Gamja Flower', sans-serif`;
    ctx.textAlign = 'center';
    ctx.fillStyle = f.c;
    ctx.strokeStyle = '#000000';
    ctx.lineWidth = 4;
    ctx.strokeText(f.t, f.x, f.y);
    ctx.fillText(f.t, f.x, f.y);
    ctx.restore();
  }

  if (flashWhite > 0) {
    ctx.save();
    ctx.globalAlpha = Math.min(0.65, flashWhite);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, BW, BH);
    ctx.restore();
  }
}

export function drawScoreInGame(
  ctx: CanvasRenderingContext2D,
  score: number,
  combo: number,
  state: GameState,
  BW: number
): void {
  if (state === GameState.PLAY || state === GameState.DYING || state === GameState.READY) {
    ctx.save();
    ctx.font = "48px 'Jua', 'Gamja Flower', sans-serif";
    ctx.textAlign = 'center';
    ctx.fillStyle = '#ffffff';
    ctx.strokeStyle = 'rgba(0,0,0,0.5)';
    ctx.lineWidth = 6;
    ctx.strokeText(String(score), BW / 2, 72);
    ctx.fillText(String(score), BW / 2, 72);

    if (combo > 1) {
      ctx.font = "20px 'Jua', 'Gamja Flower', sans-serif";
      ctx.fillStyle = '#ffe27a';
      ctx.strokeStyle = '#000';
      ctx.lineWidth = 3.5;
      const comboTxt = `${combo}연속 완벽!`;
      ctx.strokeText(comboTxt, BW / 2, 102);
      ctx.fillText(comboTxt, BW / 2, 102);
    }
    ctx.restore();
  }
}
