import React from 'react';
import { MedalInfo } from '../types';
import potatoImg from '../assets/images/cute_flying_potato_1789882012417.jpg';

interface GameOverOverlayProps {
  score: number;
  best: number;
  passed: number;
  starCount: number;
  bestCombo: number;
  newRecord: boolean;
  medal: MedalInfo;
  onRestart: () => void;
}

export const GameOverOverlay: React.FC<GameOverOverlayProps> = ({
  score,
  best,
  passed,
  starCount,
  bestCombo,
  newRecord,
  medal,
  onRestart,
}) => {
  const diff = best - score;
  let regretText = '';
  if (newRecord) {
    regretText = '우와! 최고의 감자가 나타났다! 🎉';
  } else if (diff <= 0) {
    regretText = '최고 기록이랑 똑같아! 1점만 더!';
  } else if (diff <= 3) {
    regretText = `아깝다! 최고 기록까지 ${diff}점!`;
  } else if (diff <= 8) {
    regretText = `조금만 더! 최고 기록까지 ${diff}점 남았어!`;
  } else {
    regretText = `최고 기록까지 ${diff}점! 다시 둥둥 가보자!`;
  }

  return (
    <div
      id="game-over-screen"
      className="absolute inset-0 flex flex-col items-center justify-center p-4 text-center bg-gradient-to-b from-rose-100/60 via-indigo-100/70 to-indigo-200/80 backdrop-blur-xs z-30 overflow-y-auto"
    >
      <h1
        id="game-over-title"
        className="text-2xl sm:text-3xl font-black text-rose-500 mb-2"
        style={{ textShadow: '0 2px 0 #fff, 0 4px 10px rgba(244, 63, 94, 0.25)' }}
      >
        {newRecord ? '감자 신기록! 🎉' : '앗, 부딪혔어!'}
      </h1>

      <div
        id="score-card"
        className="bg-white/95 text-stone-800 rounded-3xl p-5 shadow-xl shadow-rose-200/30 border-4 border-rose-200 max-w-[320px] w-full"
      >
        <div className="relative inline-block mb-1">
          <img
            src={potatoImg}
            alt="감자 결과"
            className="w-16 h-16 rounded-full object-cover border-2 border-amber-300 shadow-md mx-auto"
            referrerPolicy="no-referrer"
          />
          <span className="absolute -bottom-1 -right-1 text-2xl filter drop-shadow">
            {medal.icon}
          </span>
        </div>

        <div id="medal-name" className="text-sm font-black text-amber-800 mt-1">
          {medal.name}
        </div>

        <div
          id="final-score"
          className="text-5xl font-black text-rose-400 my-1 tracking-tight"
        >
          {score}
          <span className="text-xl font-bold text-rose-300 ml-1">점</span>
        </div>

        <div
          id="detailed-stats"
          className="text-xs font-bold text-stone-600 bg-stone-50 rounded-xl py-2 px-3 my-2 border border-stone-100"
        >
          통과 {passed}개 · 별 {starCount}개 · 콤보 {bestCombo}회
          <div className="text-amber-700 font-extrabold mt-0.5">최고 기록: {best}점</div>
        </div>

        <div
          id="encouragement-text"
          className={`text-sm font-extrabold my-2 ${newRecord ? 'text-teal-600 font-black' : 'text-rose-600'}`}
        >
          {regretText}
        </div>
      </div>

      <button
        id="restart-game-button"
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          onRestart();
        }}
        className="mt-4 px-8 py-2.5 text-base sm:text-lg font-black text-amber-900 bg-gradient-to-b from-rose-100 to-rose-200 hover:from-rose-200 hover:to-rose-300 border-0 border-b-4 border-rose-400 rounded-2xl shadow-lg shadow-rose-300/40 cursor-pointer active:translate-y-1 active:border-b-2 transition-transform"
      >
        다시 하기
      </button>

      <div className="text-xs font-extrabold text-stone-600 mt-2 animate-pulse" style={{ textShadow: '0 1px 2px rgba(255,255,255,0.8)' }}>
        스페이스나 탭 한 번이면 바로 다시!
      </div>
    </div>
  );
};
