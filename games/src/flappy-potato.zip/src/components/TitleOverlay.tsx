import React from 'react';
import bannerImg from '../assets/images/flappy_potato_banner_1789882042064.jpg';
import potatoImg from '../assets/images/cute_flying_potato_1789882012417.jpg';
import butterImg from '../assets/images/potato_butter_shield_1789882026812.jpg';

interface TitleOverlayProps {
  onStart: () => void;
}

export const TitleOverlay: React.FC<TitleOverlayProps> = ({ onStart }) => {
  return (
    <div
      id="title-screen"
      className="absolute inset-0 flex flex-col items-center justify-center p-4 text-center bg-gradient-to-b from-rose-100/50 via-sky-100/60 to-indigo-200/70 backdrop-blur-xs z-30 overflow-y-auto"
    >
      <div className="w-full max-w-[320px] mb-2 overflow-hidden rounded-2xl border-3 border-amber-200 shadow-md shadow-amber-200/50">
        <img
          src={bannerImg}
          alt="파닥파닥 감자 게임 배너"
          className="w-full h-28 object-cover"
          referrerPolicy="no-referrer"
        />
      </div>

      <div className="flex items-center gap-2 mb-1">
        <img
          src={potatoImg}
          alt="귀여운 감자 캐릭터"
          className="w-8 h-8 rounded-full border-2 border-amber-400 shadow-sm object-cover animate-bounce"
          referrerPolicy="no-referrer"
        />
        <h1
          id="game-title"
          className="text-2xl sm:text-3xl font-black text-amber-600 tracking-tight"
          style={{ textShadow: '0 2px 0 #fff, 0 4px 10px rgba(217, 119, 36, 0.25)' }}
        >
          파닥파닥 감자
        </h1>
      </div>

      <p className="text-xs sm:text-sm font-bold text-stone-700 mb-3" style={{ textShadow: '0 1px 2px rgba(255,255,255,0.8)' }}>
        톡 치면 둥둥! 귀여운 감자의 하늘 여행!
      </p>

      <div
        id="instructions-card"
        className="bg-white/95 text-stone-800 rounded-2xl p-4 shadow-lg shadow-rose-200/30 border-3 border-rose-200 max-w-[320px] w-full text-left"
      >
        <div className="flex items-center gap-2.5 pb-2 mb-2 border-b border-rose-100">
          <img
            src={potatoImg}
            alt="감자"
            className="w-7 h-7 rounded-full object-cover border border-amber-300"
            referrerPolicy="no-referrer"
          />
          <span className="text-xs sm:text-sm font-bold text-stone-700">
            <b>화면 톡</b> 또는 <b>스페이스바</b>로 점프!
          </span>
        </div>

        <div className="flex items-center gap-2.5 pb-2 mb-2 border-b border-rose-100">
          <span className="text-lg">🌷</span>
          <span className="text-xs sm:text-sm font-bold text-stone-700">
            파이프를 통과하면 <b className="text-amber-600">+1점</b> (가운데 통과시 완벽 <b className="text-amber-600">+2점</b>)
          </span>
        </div>

        <div className="flex items-center gap-2.5">
          <img
            src={butterImg}
            alt="버터 방패"
            className="w-7 h-7 rounded-full object-cover border border-amber-300"
            referrerPolicy="no-referrer"
          />
          <span className="text-xs sm:text-sm font-bold text-stone-700">
            버터 별을 먹으면 <b className="text-amber-600">+3점</b>과 <b className="text-amber-700">보호 방패</b> 획득!
          </span>
        </div>
      </div>

      <button
        id="start-game-button"
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          onStart();
        }}
        className="mt-4 px-8 py-2.5 text-base sm:text-lg font-black text-amber-900 bg-gradient-to-b from-rose-100 to-rose-200 hover:from-rose-200 hover:to-rose-300 border-0 border-b-4 border-rose-400 rounded-2xl shadow-lg shadow-rose-300/40 cursor-pointer active:translate-y-1 active:border-b-2 transition-transform"
      >
        시작하기
      </button>

      <div className="text-xs font-extrabold text-stone-600 mt-2 animate-pulse" style={{ textShadow: '0 1px 2px rgba(255,255,255,0.8)' }}>
        아무 데나 톡 치면 바로 시작해!
      </div>
    </div>
  );
};
