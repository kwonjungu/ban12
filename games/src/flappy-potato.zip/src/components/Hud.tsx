import React from 'react';
import butterShieldImg from '../assets/images/potato_butter_shield_1789882026812.jpg';

interface HudProps {
  runTime: number;
  starCount: number;
  shields: number;
  best: number;
  isMuted: boolean;
  toastMsg: string | null;
  onToggleMute: (e: React.MouseEvent) => void;
}

export const Hud: React.FC<HudProps> = ({
  runTime,
  starCount,
  shields,
  best,
  isMuted,
  toastMsg,
  onToggleMute,
}) => {
  return (
    <>
      <div
        id="hud"
        className="absolute left-0 right-0 top-0 flex gap-2 items-center px-3 py-2.5 text-xs sm:text-sm font-extrabold pointer-events-none z-10"
        style={{ textShadow: '0 2px 0 rgba(0,0,0,0.18)' }}
      >
        <span
          id="chip-time"
          className="bg-white/60 border-2 border-white/90 text-stone-800 rounded-full px-2.5 py-1 whitespace-nowrap backdrop-blur-sm shadow-sm"
        >
          ⏱ {Math.floor(runTime)}초
        </span>

        <span
          id="chip-star"
          className="bg-white/60 border-2 border-white/90 text-stone-800 rounded-full px-2.5 py-1 whitespace-nowrap backdrop-blur-sm shadow-sm"
        >
          ⭐ {starCount}
        </span>

        <span
          id="chip-shield"
          className={`flex items-center gap-1 border-2 rounded-full px-2.5 py-1 whitespace-nowrap backdrop-blur-sm shadow-sm transition-all duration-300 ${
            shields > 0
              ? 'bg-amber-200/90 border-amber-300 text-amber-900 shadow-amber-300/40 ring-2 ring-amber-300/60'
              : 'bg-white/60 border-white/90 text-stone-800'
          }`}
        >
          <img
            src={butterShieldImg}
            alt="버터"
            className="w-4 h-4 rounded-full object-cover inline-block"
            referrerPolicy="no-referrer"
          />
          <span>{shields}</span>
        </span>

        <div className="flex-1" />

        <span
          id="chip-best"
          className="bg-white/60 border-2 border-white/90 text-stone-800 rounded-full px-2.5 py-1 whitespace-nowrap backdrop-blur-sm shadow-sm"
        >
          🏆 {best}
        </span>

        <button
          id="mute-button"
          type="button"
          onClick={onToggleMute}
          className="pointer-events-auto cursor-pointer font-bold text-stone-800 bg-white/70 hover:bg-white border-2 border-white/90 rounded-full px-2.5 py-1 shadow-sm transition-transform active:scale-95"
          aria-label={isMuted ? '음소거 해제' : '음소거'}
        >
          {isMuted ? '🔇' : '🔊'}
        </button>
      </div>

      {/* Floating toast notification */}
      <div
        id="toast-notification"
        className={`absolute left-1/2 top-[16%] -translate-x-1/2 bg-white/95 border-2 border-rose-300 text-stone-800 font-black text-sm sm:text-base px-4 py-2 rounded-2xl pointer-events-none whitespace-nowrap z-20 shadow-lg shadow-rose-200/40 transition-all duration-200 ${
          toastMsg ? 'opacity-100 scale-100 translate-y-0' : 'opacity-0 scale-90 translate-y-2 pointer-events-none'
        }`}
      >
        {toastMsg}
      </div>
    </>
  );
};
