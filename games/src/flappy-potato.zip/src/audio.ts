// Web Audio API Synthesizer for Flappy Potato

let AC: AudioContext | null = null;
let master: GainNode | null = null;
let noiseBuf: AudioBuffer | null = null;
let isMuted = false;

const SCALE_NOTES = [523.25, 587.33, 659.25, 698.46, 783.99, 880.0, 987.77, 1046.5, 1174.7, 1318.5];

export function setMuted(muted: boolean): void {
  isMuted = muted;
}

export function getMuted(): boolean {
  return isMuted;
}

export function audioReady(): boolean {
  if (typeof window === 'undefined') return false;
  if (!AC) {
    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return false;
    try {
      AC = new AudioCtx();
      master = AC.createGain();
      master.gain.value = 0.5;
      master.connect(AC.destination);
    } catch {
      AC = null;
      return false;
    }
  }
  if (AC && AC.state === 'suspended' && AC.resume) {
    try {
      AC.resume().catch(() => {});
    } catch {
      // ignore
    }
  }
  return true;
}

function tone(f: number, dur = 0.14, type: OscillatorType = 'square', vol = 0.16, delay = 0, f2?: number): void {
  if (isMuted || !AC || !master) return;
  try {
    const t0 = AC.currentTime + delay;
    const d = dur;
    const osc = AC.createOscillator();
    const g = AC.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(f, t0);
    if (f2) osc.frequency.exponentialRampToValueAtTime(Math.max(20, f2), t0 + d);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(Math.max(0.001, vol), t0 + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + d);
    osc.connect(g);
    g.connect(master);
    osc.start(t0);
    osc.stop(t0 + d + 0.05);
  } catch {
    // ignore
  }
}

function noiseHit(dur = 0.2, vol = 0.2, delay = 0, cutoff = 1400): void {
  if (isMuted || !AC || !master) return;
  try {
    if (!noiseBuf) {
      const len = Math.floor(AC.sampleRate * 0.5);
      noiseBuf = AC.createBuffer(1, len, AC.sampleRate);
      const data = noiseBuf.getChannelData(0);
      for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
    }
    const t0 = AC.currentTime + delay;
    const d = dur;
    const src = AC.createBufferSource();
    src.buffer = noiseBuf;
    const lp = AC.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.setValueAtTime(cutoff, t0);
    lp.frequency.exponentialRampToValueAtTime(180, t0 + d);
    const g = AC.createGain();
    g.gain.setValueAtTime(vol, t0);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + d);
    src.connect(lp);
    lp.connect(g);
    g.connect(master);
    src.start(t0);
    src.stop(t0 + d + 0.05);
  } catch {
    // ignore
  }
}

export function sndFlap(): void {
  tone(660, 0.09, 'triangle', 0.18, 0, 300);
  noiseHit(0.08, 0.07, 0, 900);
}

export function sndScore(comboIndex: number): void {
  const n = SCALE_NOTES[Math.min(comboIndex, SCALE_NOTES.length - 1)];
  tone(n, 0.11, 'square', 0.16);
  tone(n * 2, 0.09, 'triangle', 0.08, 0.02);
}

export function sndPerfect(comboIndex: number): void {
  const n = SCALE_NOTES[Math.min(comboIndex, SCALE_NOTES.length - 1)];
  tone(n, 0.09, 'square', 0.16);
  tone(n * 1.5, 0.10, 'square', 0.13, 0.07);
  tone(n * 2, 0.14, 'triangle', 0.12, 0.14);
}

export function sndStar(): void {
  tone(880, 0.07, 'triangle', 0.16);
  tone(1318, 0.07, 'triangle', 0.15, 0.06);
  tone(1760, 0.14, 'triangle', 0.13, 0.12);
}

export function sndShieldBreak(): void {
  tone(240, 0.18, 'sawtooth', 0.16, 0, 90);
  tone(880, 0.22, 'sine', 0.12, 0.02, 300);
  noiseHit(0.22, 0.16, 0, 2400);
}

export function sndHit(): void {
  noiseHit(0.28, 0.30, 0, 2200);
  tone(180, 0.22, 'square', 0.22, 0, 60);
}

export function sndFall(): void {
  tone(420, 0.55, 'sawtooth', 0.16, 0.10, 70);
}

export function sndStart(): void {
  tone(523, 0.10, 'square', 0.15, 0.00);
  tone(659, 0.10, 'square', 0.15, 0.09);
  tone(784, 0.10, 'square', 0.15, 0.18);
  tone(1046, 0.20, 'square', 0.15, 0.27);
}

export function sndEvent(): void {
  tone(659, 0.10, 'triangle', 0.15);
  tone(988, 0.16, 'triangle', 0.14, 0.09);
}

export function sndMedal(): void {
  tone(523, 0.12, 'square', 0.15, 0.00);
  tone(659, 0.12, 'square', 0.15, 0.12);
  tone(784, 0.12, 'square', 0.15, 0.24);
  tone(1046, 0.30, 'square', 0.16, 0.36);
  tone(1318, 0.30, 'triangle', 0.12, 0.36);
}
