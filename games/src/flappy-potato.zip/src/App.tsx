/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import {
  GameState,
  BirdEntity,
  PipeEntity,
  StarEntity,
  ParticleEntity,
  FloatTextEntity,
  CloudEntity,
  NightStarEntity,
} from './types';
import {
  THEMES,
  getMedal,
  BASE_HEIGHT,
  BASE_WIDTH,
  GROUND_HEIGHT,
  PIPE_WIDTH,
  BIRD_RADIUS,
} from './data';
import {
  audioReady,
  setMuted,
  getMuted,
  sndFlap,
  sndScore,
  sndPerfect,
  sndStar,
  sndShieldBreak,
  sndHit,
  sndFall,
  sndStart,
  sndEvent,
  sndMedal,
} from './audio';
import {
  drawBackground,
  drawPipes,
  drawStars,
  drawGround,
  drawBird,
  drawEffects,
  drawScoreInGame,
} from './canvasRenderer';
import { Hud } from './components/Hud';
import { TitleOverlay } from './components/TitleOverlay';
import { GameOverOverlay } from './components/GameOverOverlay';

import cutePotatoUrl from './assets/images/cute_flying_potato_1789882012417.jpg';
import butterShieldUrl from './assets/images/potato_butter_shield_1789882026812.jpg';

const STORAGE_BEST = 'flappy-potato-best';
const STORAGE_MUTE = 'flappy-potato-mute';

function circleRect(cx: number, cy: number, r: number, rx: number, ry: number, rw: number, rh: number): boolean {
  const nx = Math.max(rx, Math.min(cx, rx + rw));
  const ny = Math.max(ry, Math.min(cy, ry + rh));
  const dx = cx - nx;
  const dy = cy - ny;
  return dx * dx + dy * dy < r * r;
}

export default function App() {
  const stageRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Loaded image elements for canvas rendering
  const potatoImgRef = useRef<HTMLImageElement | null>(null);
  const butterImgRef = useRef<HTMLImageElement | null>(null);

  // Game UI State
  const [gameState, setGameState] = useState<GameState>(GameState.TITLE);
  const [score, setScore] = useState(0);
  const [starCount, setStarCount] = useState(0);
  const [shields, setShields] = useState(0);
  const [runTime, setRunTime] = useState(0);
  const [best, setBest] = useState(() => {
    try {
      const v = localStorage.getItem(STORAGE_BEST);
      return v ? parseInt(v, 10) || 0 : 0;
    } catch {
      return 0;
    }
  });
  const [isMuteState, setIsMuteState] = useState(() => {
    try {
      return localStorage.getItem(STORAGE_MUTE) === '1';
    } catch {
      return false;
    }
  });
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const [passedCount, setPassedCount] = useState(0);
  const [bestComboCount, setBestComboCount] = useState(0);
  const [isNewRecord, setIsNewRecord] = useState(false);

  // Mutable Game References for 60fps Loop
  const stateRef = useRef(GameState.TITLE);
  stateRef.current = gameState;

  const dimsRef = useRef({
    BW: BASE_WIDTH,
    BH: BASE_HEIGHT,
    scale: 1,
    cssW: BASE_WIDTH,
    cssH: BASE_HEIGHT,
  });

  const birdRef = useRef<BirdEntity>({
    x: 120,
    y: 300,
    vy: 0,
    rot: 0,
    pop: 1,
    stretch: 1,
    wing: 0,
    alive: true,
    inv: 0,
  });

  const pipesRef = useRef<PipeEntity[]>([]);
  const starsRef = useRef<StarEntity[]>([]);
  const particlesRef = useRef<ParticleEntity[]>([]);
  const floatsRef = useRef<FloatTextEntity[]>([]);
  const cloudsRef = useRef<CloudEntity[]>([]);
  const nightStarsRef = useRef<NightStarEntity[]>([]);

  const gameStatsRef = useRef({
    score: 0,
    combo: 0,
    bestCombo: 0,
    starCount: 0,
    shields: 0,
    passed: 0,
    runTime: 0,
    groundX: 0,
    shake: 0,
    hitStop: 0,
    flashWhite: 0,
    overWait: 0,
    eventIdx: 0,
    extraSpeed: 0,
    windOn: false,
    starBoost: false,
    spawnedTotal: 0,
    themeIdx: 0,
    themeFrom: 0,
    themeTo: 0,
    themeMix: 1,
  });

  // Preload asset images
  useEffect(() => {
    const pImg = new Image();
    pImg.src = cutePotatoUrl;
    pImg.onload = () => {
      potatoImgRef.current = pImg;
    };

    const bImg = new Image();
    bImg.src = butterShieldUrl;
    bImg.onload = () => {
      butterImgRef.current = bImg;
    };

    setMuted(isMuteState);
  }, [isMuteState]);

  // Toast trigger helper
  const showToast = useCallback((msg: string) => {
    setToastMsg(msg);
    setTimeout(() => {
      setToastMsg((prev) => (prev === msg ? null : prev));
    }, 2200);
  }, []);

  const setTheme = useCallback((targetIdx: number) => {
    const stats = gameStatsRef.current;
    stats.themeFrom = stats.themeIdx;
    stats.themeTo = targetIdx;
    stats.themeIdx = targetIdx;
    stats.themeMix = 0;
  }, []);

  // Spawn pipe helper
  const spawnPipe = useCallback((x: number, forceY?: number) => {
    const stats = gameStatsRef.current;
    const { BH } = dimsRef.current;
    const passed = stats.passed;

    // Dynamic gap height
    const gh = passed < 5 ? 236 : Math.max(154, 236 - (passed - 5) * 2.3);
    const groundY = BH - GROUND_HEIGHT;
    const minY = gh / 2 + 54;
    const maxY = Math.max(minY, groundY - gh / 2 - 26);

    let y: number;
    if (typeof forceY === 'number') {
      y = forceY;
    } else if (stats.spawnedTotal < 3) {
      y = birdRef.current.y + (Math.random() * 60 - 30);
    } else {
      y = minY + Math.random() * (maxY - minY);
    }
    y = Math.max(minY, Math.min(maxY, y));

    let amp = 0;
    if (stats.windOn && stats.spawnedTotal > 4 && Math.random() < 0.5) {
      amp = 18 + Math.random() * 22;
      const room = Math.min(y - minY, maxY - y);
      amp = Math.min(amp, Math.max(0, room));
    }

    const newPipe: PipeEntity = {
      x,
      baseY: y,
      y,
      gap: gh,
      amp,
      phase: Math.random() * Math.PI * 2,
      scored: false,
      w: PIPE_WIDTH,
    };
    pipesRef.current.push(newPipe);
    stats.spawnedTotal++;

    // Chance to spawn star / butter
    const chance = stats.starBoost ? 0.65 : 0.45;
    if (stats.spawnedTotal > 2 && Math.random() < chance) {
      const edge = Math.random() < 0.72 ? (Math.random() < 0.5 ? -1 : 1) : 0;
      const off = edge * (gh / 2 - 26);
      starsRef.current.push({
        pipe: newPipe,
        off,
        x: x + PIPE_WIDTH * 0.5,
        y: y + off,
        got: false,
        spin: Math.random() * Math.PI * 2,
        edge: edge !== 0,
      });
    }
  }, []);

  // Particle burst helper
  const addBurst = useCallback((x: number, y: number, n: number, colors: string[], spd: number, life: number) => {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      const v = spd * (0.35 + Math.random() * 0.9);
      particlesRef.current.push({
        x,
        y,
        vx: Math.cos(a) * v,
        vy: Math.sin(a) * v - 30,
        r: 2.2 + Math.random() * 3.6,
        life,
        max: life,
        c: colors[(Math.random() * colors.length) | 0],
        g: 260 + Math.random() * 200,
      });
    }
  }, []);

  // Float text helper
  const addFloatText = useCallback((x: number, y: number, text: string, color: string, size = 22) => {
    floatsRef.current.push({
      x,
      y,
      t: text,
      c: color,
      s: size,
      life: 0.95,
      max: 0.95,
      vy: -70,
    });
  }, []);

  // Flap jump
  const flap = useCallback(() => {
    const bird = birdRef.current;
    bird.vy = -430;
    bird.wing = 1;
    bird.pop = 1.34;
    bird.stretch = 1.18;
    bird.rot = -0.45;
    sndFlap();
    addBurst(bird.x - 10, bird.y + 8, 9, ['#fff6d0', '#ffe27a', '#ffffff'], 150, 0.5);
    addBurst(bird.x - 16, bird.y + 12, 4, ['#ffffff', '#e8f4ff'], 60, 0.35);

    if (!getMuted() && typeof navigator !== 'undefined' && navigator.vibrate) {
      try {
        navigator.vibrate(10);
      } catch {
        // ignore
      }
    }
  }, [addBurst]);

  // Shield break
  const loseShield = useCallback(() => {
    const bird = birdRef.current;
    const stats = gameStatsRef.current;
    stats.shields = Math.max(0, stats.shields - 1);
    bird.inv = 1.3;
    bird.vy = -430;
    stats.shake = 16;
    stats.hitStop = 0.09;
    stats.flashWhite = 0.5;
    sndShieldBreak();
    addBurst(bird.x, bird.y, 26, ['#fff3b0', '#ffe5ec', '#ffffff', '#fec5bb'], 240, 0.7);
    addFloatText(bird.x, bird.y - 34, '버터가 방어했어! 🧈', '#e07a5f', 20);
    stats.combo = 0;
    setShields(stats.shields);
  }, [addBurst, addFloatText]);

  // Die
  const die = useCallback(() => {
    const bird = birdRef.current;
    if (!bird.alive) return;
    bird.alive = false;
    const stats = gameStatsRef.current;
    setGameState(GameState.DYING);
    if (bird.vy < -140) bird.vy = -140;
    stats.shake = 22;
    stats.hitStop = 0.1;
    stats.flashWhite = 0.8;
    sndHit();
    sndFall();
    addBurst(bird.x, bird.y, 30, ['#f4a261', '#e76f51', '#ffffff', '#e9c46a'], 260, 0.85);
  }, [addBurst]);

  // Show Game Over Overlay
  const triggerGameOver = useCallback(() => {
    setGameState(GameState.OVER);
    const stats = gameStatsRef.current;
    stats.overWait = 0.25;

    const currentScore = stats.score;
    let isRecord = false;
    if (currentScore > best) {
      setBest(currentScore);
      isRecord = true;
      setIsNewRecord(true);
      try {
        localStorage.setItem(STORAGE_BEST, String(currentScore));
      } catch {
        // ignore
      }
      sndMedal();
    } else {
      setIsNewRecord(false);
      if (currentScore >= 5) sndMedal();
    }

    setPassedCount(stats.passed);
    setBestComboCount(stats.bestCombo);
  }, [best]);

  // Reset Run
  const resetRun = useCallback(() => {
    const { BW, BH } = dimsRef.current;
    pipesRef.current = [];
    starsRef.current = [];
    particlesRef.current = [];
    floatsRef.current = [];

    birdRef.current = {
      x: Math.max(90, BW * 0.28),
      y: BH * 0.42,
      vy: 0,
      rot: 0,
      pop: 1,
      stretch: 1,
      wing: 0,
      alive: true,
      inv: 0,
    };

    gameStatsRef.current = {
      score: 0,
      combo: 0,
      bestCombo: 0,
      starCount: 0,
      shields: 0,
      passed: 0,
      runTime: 0,
      groundX: 0,
      shake: 0,
      hitStop: 0,
      flashWhite: 0,
      overWait: 0,
      eventIdx: 0,
      extraSpeed: 0,
      windOn: false,
      starBoost: false,
      spawnedTotal: 0,
      themeIdx: 0,
      themeFrom: 0,
      themeTo: 0,
      themeMix: 1,
    };

    setScore(0);
    setStarCount(0);
    setShields(0);
    setRunTime(0);
    setIsNewRecord(false);

    spawnPipe(BW + 30, BH * 0.42);
  }, [spawnPipe]);

  // Start game
  const startGame = useCallback(() => {
    audioReady();
    resetRun();
    setGameState(GameState.READY);
    sndStart();
    showToast('준비! 톡 치면 감자 출발! 🥔');
  }, [resetRun, showToast]);

  // Main interaction press handler
  const handleInteraction = useCallback(() => {
    audioReady();
    const st = stateRef.current;
    if (st === GameState.TITLE) {
      startGame();
      return;
    }
    if (st === GameState.READY) {
      setGameState(GameState.PLAY);
      flap();
      return;
    }
    if (st === GameState.PLAY) {
      flap();
      return;
    }
    if (st === GameState.PAUSE) {
      setGameState(GameState.PLAY);
      showToast('계속 가자! 🥔');
      return;
    }
    if (st === GameState.OVER) {
      if (gameStatsRef.current.overWait <= 0) {
        startGame();
      }
    }
  }, [startGame, flap, showToast]);

  // Resize calculation & Canvas scaling
  useEffect(() => {
    const stage = stageRef.current;
    const canvas = canvasRef.current;
    if (!stage || !canvas) return;

    // Decor clouds & night stars initialization
    cloudsRef.current = [];
    for (let i = 0; i < 6; i++) {
      cloudsRef.current.push({
        x: Math.random() * 500,
        y: 40 + Math.random() * 220,
        s: 0.6 + Math.random() * 0.7,
        sp: 8 + Math.random() * 12,
      });
    }

    nightStarsRef.current = [];
    for (let j = 0; j < 34; j++) {
      nightStarsRef.current.push({
        x: Math.random(),
        y: Math.random() * 0.62,
        r: 0.9 + Math.random() * 1.6,
        tw: Math.random() * Math.PI * 2,
      });
    }

    const updateSize = () => {
      const r = stage.getBoundingClientRect();
      const cssW = Math.max(120, Math.round(r.width));
      const cssH = Math.max(160, Math.round(r.height));
      const dpr = Math.min(window.devicePixelRatio || 1, 3);

      canvas.width = Math.round(cssW * dpr);
      canvas.height = Math.round(cssH * dpr);
      canvas.style.width = `${cssW}px`;
      canvas.style.height = `${cssH}px`;

      const scale = cssH / BASE_HEIGHT;
      const BW = cssW / scale;

      dimsRef.current = {
        BW,
        BH: BASE_HEIGHT,
        scale,
        cssW,
        cssH,
      };
    };

    updateSize();

    let ro: ResizeObserver | null = null;
    if (typeof ResizeObserver !== 'undefined') {
      ro = new ResizeObserver(updateSize);
      ro.observe(stage);
    }
    window.addEventListener('resize', updateSize);

    return () => {
      if (ro) ro.disconnect();
      window.removeEventListener('resize', updateSize);
    };
  }, []);

  // Keyboard events
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const k = e.key;
      if (
        k === ' ' ||
        k === 'Spacebar' ||
        k === 'ArrowUp' ||
        k === 'ArrowDown' ||
        k === 'ArrowLeft' ||
        k === 'ArrowRight' ||
        k === 'Enter'
      ) {
        e.preventDefault();
      }
      if (k === ' ' || k === 'Spacebar' || k === 'ArrowUp' || k === 'Enter' || k === 'w' || k === 'W') {
        if (e.repeat) return;
        handleInteraction();
      }
      if (k === 'm' || k === 'M') {
        setIsMuteState((prev) => {
          const next = !prev;
          setMuted(next);
          try {
            localStorage.setItem(STORAGE_MUTE, next ? '1' : '0');
          } catch {
            // ignore
          }
          return next;
        });
      }
    };

    window.addEventListener('keydown', handleKeyDown, { passive: false });
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleInteraction]);

  // Main 60FPS Game Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let lastTime = performance.now();

    const gameEvents = [
      { t: 8, p: 3, msg: '🌇 감자밭에 노을이 물들었어!', act: () => setTheme(1) },
      { t: 16, p: 6, msg: '🌬️ 살랑바람 불어온다! 파이프가 둥실~', act: () => { gameStatsRef.current.windOn = true; } },
      { t: 30, p: 10, msg: '🌙 반짝반짝 밤이야! 별이 쏟아져!', act: () => { setTheme(2); gameStatsRef.current.starBoost = true; } },
      { t: 46, p: 16, msg: '🌅 신나는 아침! 감자가 더 신났어!', act: () => { setTheme(0); gameStatsRef.current.extraSpeed += 8; } },
      { t: 62, p: 24, msg: '⚡ 슈퍼 감자 모드! 빠르게 둥둥!', act: () => { setTheme(1); gameStatsRef.current.extraSpeed += 12; } },
      { t: 78, p: 32, msg: '⚡⚡ 더 빨라진다!', act: () => { setTheme(0); gameStatsRef.current.extraSpeed += 12; } },
    ];

    const loop = (now: number) => {
      const nowSec = now / 1000;
      const dt = Math.min(0.06, (now - lastTime) / 1000);
      lastTime = now;

      const stats = gameStatsRef.current;
      const bird = birdRef.current;
      const { BW, BH, scale } = dimsRef.current;
      const groundY = BH - GROUND_HEIGHT;
      const dpr = Math.min(window.devicePixelRatio || 1, 3);

      // Decay screen shakes & transitions
      if (stats.shake > 0) stats.shake = Math.max(0, stats.shake - dt * 55);
      if (stats.flashWhite > 0) stats.flashWhite = Math.max(0, stats.flashWhite - dt * 2.6);
      if (stats.themeMix < 1) stats.themeMix = Math.min(1, stats.themeMix + dt * 1.2);
      bird.pop += (1 - bird.pop) * Math.min(1, dt * 9);
      bird.wing = Math.max(0, bird.wing - dt * 3.4);

      // Move background clouds
      for (let cIdx = 0; cIdx < cloudsRef.current.length; cIdx++) {
        const c = cloudsRef.current[cIdx];
        c.x -= c.sp * dt;
        if (c.x < -120) c.x = BW + 80;
      }

      // Update particles
      const parts = particlesRef.current;
      for (let i = parts.length - 1; i >= 0; i--) {
        const p = parts[i];
        p.life -= dt;
        if (p.life <= 0) {
          parts.splice(i, 1);
          continue;
        }
        p.vy += p.g * dt;
        p.x += p.vx * dt;
        p.y += p.vy * dt;
      }

      // Update floating texts
      const floats = floatsRef.current;
      for (let j = floats.length - 1; j >= 0; j--) {
        const f = floats[j];
        f.life -= dt;
        if (f.life <= 0) {
          floats.splice(j, 1);
          continue;
        }
        f.y += f.vy * dt;
        f.vy += 40 * dt;
      }

      const st = stateRef.current;

      if (st === GameState.TITLE) {
        bird.x = BW * 0.5;
        bird.y = BH * 0.44 + Math.sin(nowSec * 2.4) * 12;
        bird.rot = Math.sin(nowSec * 2.4) * 0.18;
        stats.groundX -= 60 * dt;
      } else if (st === GameState.READY) {
        bird.x = Math.max(90, BW * 0.28);
        bird.y = BH * 0.42 + Math.sin(nowSec * 3) * 8;
        bird.rot = Math.sin(nowSec * 3) * 0.1;
        stats.groundX -= 60 * dt;
      } else if (st === GameState.DYING) {
        bird.vy += 1500 * dt;
        bird.y += bird.vy * dt;
        bird.rot = Math.min(1.6, bird.rot + dt * 4.2);
        const floorY = groundY - BIRD_RADIUS;
        if (bird.y >= floorY) {
          bird.y = floorY;
          addBurst(bird.x, bird.y + 10, 14, ['#e2c882', '#c9a95f', '#fff'], 160, 0.5);
          stats.shake = Math.max(stats.shake, 10);
          triggerGameOver();
        }
      } else if (st === GameState.PLAY) {
        if (stats.hitStop > 0) {
          stats.hitStop -= dt;
        } else {
          stats.runTime += dt;
          setRunTime(stats.runTime);

          if (bird.inv > 0) bird.inv -= dt;

          // Milestone Events Check
          while (
            stats.eventIdx < gameEvents.length &&
            (stats.runTime >= gameEvents[stats.eventIdx].t || stats.passed >= gameEvents[stats.eventIdx].p)
          ) {
            const ev = gameEvents[stats.eventIdx];
            ev.act();
            showToast(ev.msg);
            sndEvent();
            stats.shake = Math.max(stats.shake, 8);
            stats.eventIdx++;
          }

          // Physics update
          bird.vy += 1500 * dt;
          if (bird.vy > 720) bird.vy = 720;
          bird.y += bird.vy * dt;
          bird.rot = Math.max(-0.55, Math.min(1.5, bird.vy / 520));
          bird.x += (Math.max(90, BW * 0.28) - bird.x) * Math.min(1, dt * 5);

          // Ceiling clamp
          if (bird.y < BIRD_RADIUS + 4) {
            bird.y = BIRD_RADIUS + 4;
            if (bird.vy < 0) bird.vy = 0;
          }

          // Speed & pipe movement
          const currentPipeSpeed = 150 + Math.min(stats.passed, 45) * 2.1 + stats.extraSpeed;
          stats.groundX -= currentPipeSpeed * dt;

          // Pipes update
          const pipes = pipesRef.current;
          for (let pi = pipes.length - 1; pi >= 0; pi--) {
            const pp = pipes[pi];
            pp.x -= currentPipeSpeed * dt;
            if (pp.amp > 0) {
              pp.y = pp.baseY + Math.sin(stats.runTime * 1.15 + pp.phase) * pp.amp;
            } else {
              pp.y = pp.baseY;
            }

            // Scoring pass
            if (!pp.scored && pp.x + pp.w < bird.x) {
              pp.scored = true;
              stats.passed++;
              setPassedCount(stats.passed);

              const dist = Math.abs(bird.y - pp.y);
              const perfect = dist < pp.gap * 0.19;
              if (perfect) {
                stats.combo++;
                if (stats.combo > stats.bestCombo) stats.bestCombo = stats.combo;
                stats.score += 2;
                setScore(stats.score);
                sndPerfect(stats.combo);
                addFloatText(bird.x + 26, bird.y - 30, '완벽! +2', '#ffe27a', 22);
                addBurst(pp.x + pp.w * 0.5, pp.y, 16, ['#ffe27a', '#ffffff', '#ffb703'], 190, 0.6);
                stats.shake = Math.max(stats.shake, 9);
              } else {
                stats.combo = 0;
                stats.score += 1;
                setScore(stats.score);
                sndScore(Math.min(7, stats.passed % 8));
                addFloatText(bird.x + 26, bird.y - 30, '+1', '#ffffff', 20);
                addBurst(pp.x + pp.w * 0.5, pp.y, 8, ['#ffffff', '#e0f2fe'], 110, 0.45);
              }
            }

            // Collision check with pipes
            if (bird.alive && bird.inv <= 0) {
              const topH = pp.y - pp.gap / 2;
              const botY = pp.y + pp.gap / 2;
              const botH = groundY - botY;

              const hitTop = circleRect(bird.x, bird.y, BIRD_RADIUS - 2, pp.x, 0, pp.w, topH);
              const hitBot = circleRect(bird.x, bird.y, BIRD_RADIUS - 2, pp.x, botY, pp.w, botH);

              if (hitTop || hitBot) {
                if (stats.shields > 0) loseShield();
                else die();
              }
            }

            // Despawn off-screen pipes
            if (pp.x < -PIPE_WIDTH - 40) {
              pipes.splice(pi, 1);
            }
          }

          // Spawn new pipe when needed
          const pipeSpacing = stats.passed < 5 ? 345 : Math.max(258, 345 - (stats.passed - 5) * 2.0);
          const lastPipe = pipes[pipes.length - 1];
          if (!lastPipe || lastPipe.x <= BW - pipeSpacing) {
            spawnPipe(BW + 20);
          }

          // Stars / Butter pickups update
          const stars = starsRef.current;
          for (let si = stars.length - 1; si >= 0; si--) {
            const st = stars[si];
            st.x = st.pipe.x + st.pipe.w * 0.5;
            st.y = st.pipe.y + st.off;
            st.spin += dt * 3.5;

            if (!st.got && bird.alive) {
              const dx = bird.x - st.x;
              const dy = bird.y - st.y;
              if (dx * dx + dy * dy < (BIRD_RADIUS + 18) * (BIRD_RADIUS + 18)) {
                st.got = true;
                stats.starCount++;
                stats.score += 3;
                stats.shields++;
                setStarCount(stats.starCount);
                setScore(stats.score);
                setShields(stats.shields);
                sndStar();
                addBurst(st.x, st.y, 22, ['#ffe27a', '#ffffff', '#ff9f1c', '#4fa8e0'], 220, 0.7);
                addFloatText(st.x, st.y - 20, '⭐+3 & 🛡️방패!', '#ffe27a', 22);
                stats.shake = Math.max(stats.shake, 11);
              }
            }

            if (st.pipe.x < -PIPE_WIDTH - 40 || st.got) {
              stars.splice(si, 1);
            }
          }

          // Ground collision check
          if (bird.alive && bird.inv <= 0 && bird.y >= groundY - BIRD_RADIUS) {
            bird.y = groundY - BIRD_RADIUS;
            if (stats.shields > 0) loseShield();
            else die();
          }
        }
      } else if (st === GameState.OVER) {
        if (stats.overWait > 0) stats.overWait = Math.max(0, stats.overWait - dt);
      }

      // Render on Canvas
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      let sx = 0;
      let sy = 0;
      if (stats.shake > 0) {
        sx = (Math.random() - 0.5) * stats.shake;
        sy = (Math.random() - 0.5) * stats.shake;
      }
      ctx.setTransform(dpr * scale, 0, 0, dpr * scale, sx * dpr * scale, sy * dpr * scale);

      const tf = THEMES[stats.themeFrom];
      const tt = THEMES[stats.themeTo];

      drawBackground(
        ctx,
        BW,
        BH,
        GROUND_HEIGHT,
        tf,
        tt,
        stats.themeMix,
        nightStarsRef.current,
        cloudsRef.current,
        stats.groundX,
        nowSec
      );

      drawPipes(ctx, pipesRef.current, BH, GROUND_HEIGHT, tf, tt, stats.themeMix);
      drawStars(ctx, starsRef.current, butterImgRef.current);
      drawGround(ctx, BW, BH, GROUND_HEIGHT, tf, tt, stats.themeMix, stats.groundX);
      drawBird(ctx, bird, BIRD_RADIUS, stats.shields, nowSec, potatoImgRef.current);
      drawEffects(ctx, particlesRef.current, floatsRef.current, stats.flashWhite, BW, BH);
      drawScoreInGame(ctx, stats.score, stats.combo, st, BW);

      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [addBurst, addFloatText, die, loseShield, setTheme, showToast, spawnPipe, triggerGameOver]);

  const toggleMute = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsMuteState((prev) => {
      const next = !prev;
      setMuted(next);
      try {
        localStorage.setItem(STORAGE_MUTE, next ? '1' : '0');
      } catch {
        // ignore
      }
      return next;
    });
  };

  return (
    <div className="w-full h-full min-h-screen flex items-center justify-center p-2 sm:p-4 bg-radial from-rose-200 via-sky-200 to-indigo-300 font-['Jua','Gamja_Flower',cursive,sans-serif] text-white select-none touch-manipulation overflow-hidden">
      <div
        id="stage"
        ref={stageRef}
        onPointerDown={(e) => {
          let target = e.target as HTMLElement | null;
          while (target && target !== stageRef.current) {
            if (target.tagName === 'BUTTON') return;
            target = target.parentElement;
          }
          e.preventDefault();
          handleInteraction();
        }}
        className="relative h-[min(92vh,680px)] aspect-[5/7] max-w-full rounded-3xl overflow-hidden bg-emerald-50 shadow-2xl shadow-indigo-900/30 ring-4 ring-white/60 cursor-pointer touch-none"
      >
        <canvas id="cv" ref={canvasRef} className="block w-full h-full" />

        {/* HUD Bar with status chips */}
        <Hud
          runTime={runTime}
          starCount={starCount}
          shields={shields}
          best={best}
          isMuted={isMuteState}
          toastMsg={toastMsg}
          onToggleMute={toggleMute}
        />

        {/* Start / Title Screen Overlay */}
        {gameState === GameState.TITLE && <TitleOverlay onStart={startGame} />}

        {/* Game Over Screen Overlay */}
        {gameState === GameState.OVER && (
          <GameOverOverlay
            score={score}
            best={best}
            passed={passedCount}
            starCount={starCount}
            bestCombo={bestComboCount}
            newRecord={isNewRecord}
            medal={getMedal(score)}
            onRestart={startGame}
          />
        )}
      </div>
    </div>
  );
}
